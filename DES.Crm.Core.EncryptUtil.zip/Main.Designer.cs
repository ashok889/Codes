﻿namespace DES.Crm.Core.EncryptUtil
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.txtEncrypt = new System.Windows.Forms.TextBox();
            this.txtDecrypt = new System.Windows.Forms.TextBox();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.butCopyDecrypt = new System.Windows.Forms.Button();
            this.butCopyEncrypt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Location = new System.Drawing.Point(366, 28);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(75, 23);
            this.btnEncrypt.TabIndex = 2;
            this.btnEncrypt.Text = "Encrypt >>>";
            this.btnEncrypt.UseVisualStyleBackColor = true;
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // txtEncrypt
            // 
            this.txtEncrypt.HideSelection = false;
            this.txtEncrypt.Location = new System.Drawing.Point(60, 27);
            this.txtEncrypt.Multiline = true;
            this.txtEncrypt.Name = "txtEncrypt";
            this.txtEncrypt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtEncrypt.Size = new System.Drawing.Size(300, 60);
            this.txtEncrypt.TabIndex = 1;
            this.txtEncrypt.TextChanged += new System.EventHandler(this.txtEncrypt_TextChanged);
            // 
            // txtDecrypt
            // 
            this.txtDecrypt.HideSelection = false;
            this.txtDecrypt.Location = new System.Drawing.Point(447, 28);
            this.txtDecrypt.Multiline = true;
            this.txtDecrypt.Name = "txtDecrypt";
            this.txtDecrypt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDecrypt.Size = new System.Drawing.Size(300, 60);
            this.txtDecrypt.TabIndex = 4;
            this.txtDecrypt.TextChanged += new System.EventHandler(this.txtDecrypt_TextChanged);
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(366, 64);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(75, 23);
            this.btnDecrypt.TabIndex = 3;
            this.btnDecrypt.Text = "<<< Decrypt";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            this.btnDecrypt.Visible = false;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // butCopyDecrypt
            // 
            this.butCopyDecrypt.Location = new System.Drawing.Point(762, 44);
            this.butCopyDecrypt.Name = "butCopyDecrypt";
            this.butCopyDecrypt.Size = new System.Drawing.Size(42, 23);
            this.butCopyDecrypt.TabIndex = 5;
            this.butCopyDecrypt.Text = "Copy";
            this.butCopyDecrypt.UseVisualStyleBackColor = true;
            this.butCopyDecrypt.Click += new System.EventHandler(this.butCopyDecrypt_Click);
            // 
            // butCopyEncrypt
            // 
            this.butCopyEncrypt.Location = new System.Drawing.Point(12, 44);
            this.butCopyEncrypt.Name = "butCopyEncrypt";
            this.butCopyEncrypt.Size = new System.Drawing.Size(42, 23);
            this.butCopyEncrypt.TabIndex = 5;
            this.butCopyEncrypt.Text = "Copy";
            this.butCopyEncrypt.UseVisualStyleBackColor = true;
            this.butCopyEncrypt.Click += new System.EventHandler(this.butCopyEncrypt_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 114);
            this.Controls.Add(this.butCopyEncrypt);
            this.Controls.Add(this.butCopyDecrypt);
            this.Controls.Add(this.btnDecrypt);
            this.Controls.Add(this.txtDecrypt);
            this.Controls.Add(this.txtEncrypt);
            this.Controls.Add(this.btnEncrypt);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(700, 100);
            this.Name = "Main";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Encrypt/Decrypt";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEncrypt;
        private System.Windows.Forms.TextBox txtEncrypt;
        private System.Windows.Forms.TextBox txtDecrypt;
        private System.Windows.Forms.Button btnDecrypt;
        private System.Windows.Forms.Button butCopyDecrypt;
        private System.Windows.Forms.Button butCopyEncrypt;
    }
}

