﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DES.Crm.Core.Common.Security;

namespace DES.Crm.Core.EncryptUtil
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            txtDecrypt.Text = DES.Crm.Core.Common.Security.DataProtect.EncryptString(txtEncrypt.Text);

            if (ModifierKeys.HasFlag(Keys.Control))
            {
                btnDecrypt.Visible = true;
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            txtEncrypt.Text = DES.Crm.Core.Common.Security.DataProtect.DecryptString(txtDecrypt.Text);
        }

        private void butCopyDecrypt_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtDecrypt.Text);
        }

        private void butCopyEncrypt_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtEncrypt.Text);
        }

        private void Main_Enter(object sender, EventArgs e)
        {

        }

        private void txtDecrypt_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEncrypt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
