﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LotusNotes
{
    class Model
    {
        private string _dealname;
        private string _classification;
        private string _clcode;
        private string _codecis;
        private string _companyname;
        private string _country;

        public string DealName {
            get { return _dealname; }
            set { _dealname = value; }
        }

        public string Classification
        {
            get { return _classification; }
            set { _classification = value; }
        }

        public string Clcode
        {
            get { return _clcode; }
            set { _clcode = value; }
        }

        public string Codecis
        {
            get { return _codecis; }
            set { _codecis = value; }
        }

        public string Companyname
        {
            get { return _companyname; }
            set { _companyname = value; }
        }

        public string Country
        {
            get { return _country; }
            set { _country = value; }
        }
        
    }
}
