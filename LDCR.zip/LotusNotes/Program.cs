﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domino;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;
using System.IO;


namespace LotusNotes
{
    class Program
    {
        static NotesSession session; // Notes Session Object  
        static NotesDatabase db;
        static NotesView view;
        static NotesViewEntryCollection collection;
        static NotesViewNavigator viewnavigator;
        static WIP_DEV2Entities dbcontext;
        static int counter = 0;
        static private string ViewName = "";
        static List<LotusNotesOpportunityExt> opplist = new List<LotusNotesOpportunityExt>();
        static List<LotusNotesClient> clientlist = new List<LotusNotesClient>();
        static DataTable dealteamtable = new DataTable();

        static void Main(string[] args)
        {

            //List<dynamic> lst = new List<dynamic>();
            List<Model> deals = new List<Model>();
            // Databse context
            dbcontext = new WIP_DEV2Entities();
            try
            {
                InitializeDataMigration(ref deals);
            }
            catch (Exception ex)
            {
                Console.WriteLine("operation failed at counter : ", counter);
                Console.ReadLine();
                InitializeDataMigration(ref deals);
            }
        }

        private static void InitializeDataMigration(ref List<Model> deals)
        {
            session = new NotesSession();
            session.Initialize("greek2me"); // Notes Password for your Notes Id  
            db = session.GetDatabase(@"Stubbs/Server/Domino", @"CRM\gcrmddr.nsf", false);
            GetAllViews(ref deals);
        }

        private static void GetAllViews(ref List<Model> deals)
        {
            //dynamic views = db.Views;
            List<string> Viewnames = new List<string>();

            //Viewnames.Add("e) Lost & Declined\\1. Date by Team");
            //Viewnames.Add("e) Lost & Declined\\2. Date by Reason");
            //Viewnames.Add("e) Lost & Declined\\9. In Competition");
            //Viewnames.Add("Conflict Check, very secure");
            //Viewnames.Add("Debt Size FDT&DCM");
            //Viewnames.Add("Master Deal \\ DRAFT \\ Open By RM");
            //Viewnames.Add("EO \\ 1. Live WIP Ccy");
            //Viewnames.Add("EO \\ 3. Completed Ccy");
            //Viewnames.Add("EO \\ 5. Lost Ccy");
            //Viewnames.Add("EO \\ 4. On Hold Ccy");
            //Viewnames.Add("GS By Structurer Lost/Declined 1");
            //Viewnames.Add("l.) Financial Sponsors Secure");
            //Viewnames.Add("All Sponsor Excel Report");
            //Viewnames.Add("l.) LF\\3. Completed Year By Team");
            //Viewnames.Add("l.) LF\\4. Completed - CDO");
            //Viewnames.Add("CSG\\1. WIP Revenue");
            //Viewnames.Add("CSG\\2. Completed");
            //Viewnames.Add("CSG\\3. Lost");
            //Viewnames.Add("CSG\\4. On Hold");
            //Viewnames.Add("EO\\1. Live WIP Ccy");
            //Viewnames.Add("EO\\3. Completed Ccy");
            //Viewnames.Add("EO\\5. Lost Ccy");
            //Viewnames.Add("EO\\4. On Hold Ccy");
            //Viewnames.Add("FI Sales\\1. Live £");
            //Viewnames.Add("FI Sales\\1. Live Ccy");
            //Viewnames.Add("FI Sales\\2. Completed £");
            //Viewnames.Add("FI Sales\\3. Lost £");
            //Viewnames.Add("I.) Financial Sponsors Secure");
            //Viewnames.Add("All Sponser Excel Report");
            //Viewnames.Add("I.) LF\\4. Completed - CDO");
            //Viewnames.Add("I.) LF\\5. Equity");
            //Viewnames.Add("LF Lost Mandated");
            //Viewnames.Add("n.) Syndication\\1 Live");
            //Viewnames.Add("n.) Syndication\\1.Live Corp by RM");
            //Viewnames.Add("n.) Syndication\\2.Completed");
            //Viewnames.Add("n.) Syndication\\2.Completed Ccy");
            //Viewnames.Add("n.) Syndication\\3.On Hold");
            //Viewnames.Add("n.) Syndication\\1.Live SF Shadow");
            //Viewnames.Add("n.) Syndication\\1.Live SF Shdw by RM");
            //Viewnames.Add("n.) Syndication\\7.Shadow Completed");
            //Viewnames.Add("n.) Syndication\\7.Shadow Completed Ccy");
            //Viewnames.Add("n.) Syndication\\3.Shdw On Hold");
            //Viewnames.Add("MA ccy All");
            //Viewnames.Add("ABS\\ 1.Live WIP Ccy");
            //Viewnames.Add("ABS\\ 1.Live WIP Ccy-By Deal Captain");
            //Viewnames.Add("ABS\\ 2.Completed WIP Ccy");
            //Viewnames.Add("ABS\\ 3.Lost WIP Ccy");
            //Viewnames.Add("ABS\\ 4.On - Hold WIP Ccy");
            //Viewnames.Add("ABS\\ Full Data \\ All WIP Ccy");
            //Viewnames.Add("NIG Sponser Banking");
            //Viewnames.Add("Non Core\\3.Live");
            //Viewnames.Add("Non Core\\3.Completed");
            //Viewnames.Add("Non Core\\3.Aborted");
            //Viewnames.Add("Non Core\\3.On Hold");
            //Viewnames.Add(" PEF Exec WIP Report");
            //Viewnames.Add("PEF Completed Year By Team");
            //Viewnames.Add("PEF Lost Declined\\1.Date by Team");
            //Viewnames.Add("PI\\1.Closed");
            //Viewnames.Add("PI\\1.Lost");
            //Viewnames.Add("j.) SPFG\\3.Completed Year By Team");
            //Viewnames.Add("SES\\1.Live Exec WIP Ccy");
            //Viewnames.Add("SES\\1.Live Est Comp");
            //Viewnames.Add("SES\\1.Live £");
            //Viewnames.Add("SES\\2.Completed Ccy");
            //Viewnames.Add("SES\\2.Completed £");
            //Viewnames.Add("SES\\3.Lost Ccy");
            //Viewnames.Add("SES\\3.Lost £");
            //Viewnames.Add("SES\\4.On Hold Ccy");
            //Viewnames.Add("SES\\4.On Hold £");
            //Viewnames.Add("r.) Helicopter\\1. Reports by Region");
            //Viewnames.Add("LM Completed Review");
            //Viewnames.Add("n.) Syndication\\LM Launch Review");
            //Viewnames.Add("n.) Syndication\\Admin Corp");
            //Viewnames.Add("n.) Syndication\\Admin Shadow");
            //Viewnames.Add("n.) Syndication\\Review Corp");
            //Viewnames.Add("LM Excel Report");
            //Viewnames.Add("LM Redesignated");
            //Viewnames.Add("ABS \\ MABS Executives \\ All Live WIP Ccy");
            //Viewnames.Add("CDO EMEA WIP Report");
            //Viewnames.Add("REF Lost Declined");
            //Viewnames.Add("SPM One Pager - New");
            //Viewnames.Add("SPM Asset Management");
            //Viewnames.Add("x) All by Sector");
            //Viewnames.Add("i) Fee Forecast\\4. Year by Date By Division");
            //Viewnames.Add("x) Edit History V2");
            //Viewnames.Add("x) IAS - Finance");
            //Viewnames.Add("Country of Team");
            //Viewnames.Add("Country of Client");

            foreach (string viewname in Viewnames)
            {
                // Get View
                view = db.GetView(viewname); // View name  
                if (view == null)
                {
                    Console.WriteLine("View : " + viewname + " is null !!");
                    continue;
                }

                view.AutoUpdate = false;
                PopulateFields(view);
            }
            Console.ReadLine();
        }

        private static void PopulateFields(NotesView view)
        {
            // All deals of a view
            // Entries mean deals
            NotesViewEntryCollection collection = view.AllEntries;
            Console.WriteLine("View Name : " + view.Name);
            Console.WriteLine("Total Count : " + collection.Count);

            if (dealteamtable.Columns.Count == 0)
            {
                dealteamtable.Columns.Add("DealName", typeof(string));
                dealteamtable.Columns.Add("MemberName", typeof(string));
                dealteamtable.Columns.Add("Role", typeof(string));
                dealteamtable.Columns.Add("Team", typeof(string));
                dealteamtable.Columns.Add("DateAware", typeof(string));
                dealteamtable.Columns.Add("Reason", typeof(string));
                dealteamtable.Columns.Add("Division", typeof(string));
                dealteamtable.Columns.Add("MemberType", typeof(string));
                dealteamtable.Columns.Add("ProjectName", typeof(string));
            }

            int batch = 0;
            for (int counter = 1; counter <= collection.Count; counter++)
            {
                if (batch == 0)
                    batch = counter + 499;

                NotesViewEntry nthentry = collection.GetNthEntry(counter);
                PopulateFieldData(nthentry);

                if (counter == batch || counter == collection.Count)
                {
                    sqlbulkcopy();
                    if (dealteamtable.Rows.Count > 0)
                        insertDealTeamMember(dealteamtable);
                    batch = 0;

                    if (counter == collection.Count)
                        break;
                }
            }

            dealteamtable.Dispose();
            opplist.Clear();
            clientlist.Clear();
        }

        private static void GetDealDataFromSingleLevelCategory(List<Model> deals, NotesView view)
        {
            try
            {
                viewnavigator = view.CreateViewNav();
                string categoryname = string.Empty;
                NotesViewEntry Category = viewnavigator.GetFirst();
                categoryname = Category.ColumnValues[0];
                Console.WriteLine("Total Count : " + view.EntryCount);
                //Console.WriteLine(categoryname);

                for (int categorycount = 1; categorycount <= view.TopLevelEntryCount; categorycount++)
                {
                    Console.WriteLine(categoryname);
                    collection = view.GetAllEntriesByKey(categoryname);
                    int recordcount = collection.Count;
                    for (int counter = 1; counter <= recordcount; counter++)
                    {
                        NotesViewEntry Nthentry = collection.GetNthEntry(counter);
                        DealsFromLotusNotes dealmdl = new DealsFromLotusNotes();
                        DealTeamFromLotusNotes dealteammdl = new DealTeamFromLotusNotes();
                        dealmdl.ViewName = view.Name;
                        dealmdl.CategoryName = categoryname;
                        Console.WriteLine(Nthentry.Document.GetItemValue("DispDealRef")[0]);
                        PopulateFieldData(Nthentry, ref dealmdl, ref dealteammdl);
                    }
                    Category = viewnavigator.GetNextCategory(null);
                    categoryname = Category.ColumnValues[0];
                }
            }
            catch (Exception e)
            { throw new Exception(e.Message); }
        }

        private static void GetFieldData(dynamic items, int row)
        {
            Microsoft.Office.Interop.Excel.Application oXL = null;
            Microsoft.Office.Interop.Excel._Workbook oWB = null;
            Microsoft.Office.Interop.Excel._Worksheet oSheet = null;

            try
            {
                string sheetName = "Sheet1";
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oWB = oXL.Workbooks.Open(@"C:\LotusNotes\FieldData.xlsx");
                oSheet = String.IsNullOrEmpty(sheetName) ? (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet : (Microsoft.Office.Interop.Excel._Worksheet)oWB.Worksheets[sheetName];

                foreach (dynamic item in items)
                {
                    string value = Convert.ToString(item.Values[0]);
                    oSheet.Cells[row, 1] = item.Name;
                    oSheet.Cells[row, 2] = value;
                    row++;
                }

                oWB.Save();
            }
            catch (Exception ex)
            { }
            finally
            {
                if (oWB != null)
                    oWB.Close();
            }

        }

        private static void PopulateFieldData(NotesViewEntry Nthentry, ref DealsFromLotusNotes dealmdl, ref DealTeamFromLotusNotes dealteammdl)
        {
            try
            {
                dealmdl.DealName = Nthentry.Document.GetItemValue("DispDealRef")[0];
                dealmdl.DealType = Nthentry.Document.GetItemValue("Deal_Type")[0];
                dealmdl.TargetCompany = Nthentry.Document.GetItemValue("target_company")[0];
                dealmdl.DealVendor = Nthentry.Document.GetItemValue("DealVendor")[0];
                dealmdl.IsTargetCompanyListed = Nthentry.Document.GetItemValue("TargetCompanyListed")[0];
                dealmdl.Acquisition = Nthentry.Document.GetItemValue("Acquisition")[0];
                dealmdl.ResearchGuidelines = Nthentry.Document.GetItemValue("ResearchGuidelines")[0];
                dealmdl.TreedTransaction = Nthentry.Document.GetItemValue("TreedTransaction")[0];
                dealmdl.AcquisitionDetail = Nthentry.Document.GetItemValue("AcquisitionDetails")[0];
                dealmdl.IntroducerType = Nthentry.Document.GetItemValue("Introducer_type")[0];
                dealmdl.IntroducerName = Nthentry.Document.GetItemValue("Introducer_Name")[0];
                dealmdl.Who_Introduced_Deal = Nthentry.Document.GetItemValue("Who_Introduced_Deal")[0];
                dealmdl.Region_Based = Nthentry.Document.GetItemValue("Region_Based")[0];
                dealmdl.RegionBasedCode = Nthentry.Document.GetItemValue("regionbasedcode")[0];
                dealmdl.Sponser = Nthentry.Document.GetItemValue("Spon")[0];
                dealmdl.SAFDealLocation = Nthentry.Document.GetItemValue("SAFDealLoc")[0];
                dealmdl.Rencap = Nthentry.Document.GetItemValue("Rencap")[0];
                dealmdl.RencapComments = Nthentry.Document.GetItemValue("RencapComments")[0];
                dealmdl.BankOfChinaInvolvement = Nthentry.Document.GetItemValue("China")[0];
                dealmdl.BOCRole = Nthentry.Document.GetItemValue("BoCRole")[0];
                dealmdl.EPC = Nthentry.Document.GetItemValue("EPC")[0];
                dealmdl.SBDA = Nthentry.Document.GetItemValue("SBDA")[0];
                dealmdl.Trantype = Nthentry.Document.GetItemValue("trantype")[0];
                dealmdl.Pefsponser = Nthentry.Document.GetItemValue("pefspon")[0];
                dealmdl.DealCommenceDate = Convert.ToString(Nthentry.Document.GetItemValue("dealcommsdate")[0]);
                dealmdl.EstimatedCompletedDate = Convert.ToString(Nthentry.Document.GetItemValue("Est_Completion_Date")[0]);
                dealmdl.ExclusivelySigned = Nthentry.Document.GetItemValue("Exlcusivity_Signed")[0];
                dealmdl.HelicopterReg = Nthentry.Document.GetItemValue("HelicoptorReg")[0];
                dealmdl.CodeCIS = Nthentry.Document.GetItemValue("CodeCIS")[0];
                dealmdl.ConflictedDeal = Nthentry.Document.GetItemValue("Conflicted_Deal")[0];
                dealmdl.PriceSensitive = Nthentry.Document.GetItemValue("Price_Sensitive")[0];
                dealmdl.TeamPriceSensitive = Nthentry.Document.GetItemValue("Team_Price_Sensitive")[0];
                dealmdl.CISVal = Nthentry.Document.GetItemValue("CISVal")[0];
                dealmdl.ParentName = Nthentry.Document.GetItemValue("ParentName")[0];
                dealmdl.RMNames = Nthentry.Document.GetItemValue("TXTRMNAMES")[0];
                dealmdl.RMracf = Nthentry.Document.GetItemValue("TXTRMRACFIDS")[0];
                dbcontext.DealsFromLotusNotes.Add(dealmdl);
                dbcontext.SaveChanges();

                int dealteammembercount = 1;
                int otherrbsstaffcount = 1;

                for (dealteammembercount = 1; dealteammembercount <= 25; dealteammembercount++)
                {
                    string membernm = Nthentry.Document.GetItemValue("Staff_id_" + Convert.ToString(dealteammembercount))[0];

                    if (string.IsNullOrEmpty(membernm))
                        continue;

                    dealteammdl.DealId = Nthentry.Document.GetItemValue("DispDealRef")[0];
                    dealteammdl.MemberName = Nthentry.Document.GetItemValue("Staff_id_" + Convert.ToString(dealteammembercount))[0];
                    dealteammdl.Role = Nthentry.Document.GetItemValue("Staff_role_" + Convert.ToString(dealteammembercount))[0];
                    dealteammdl.Team = Nthentry.Document.GetItemValue("team_" + Convert.ToString(dealteammembercount))[0];
                    dealteammdl.DateAware = Convert.ToString(Nthentry.Document.GetItemValue("Aware_" + Convert.ToString(dealteammembercount))[0]);
                    dbcontext.DealTeamFromLotusNotes.Add(dealteammdl);
                    dbcontext.SaveChanges();
                    membernm = "";
                }

                for (otherrbsstaffcount = 1; otherrbsstaffcount <= 20; otherrbsstaffcount++)
                {
                    string membername = Nthentry.Document.GetItemValue("ExSF_" + Convert.ToString(otherrbsstaffcount))[0];

                    if (string.IsNullOrEmpty(membername))
                        continue;

                    dealteammdl.DealId = Nthentry.Document.GetItemValue("DispDealRef")[0];
                    dealteammdl.MemberName = Nthentry.Document.GetItemValue("ExSF_" + Convert.ToString(otherrbsstaffcount))[0];
                    dealteammdl.Reason = Nthentry.Document.GetItemValue("ExSFReason_" + Convert.ToString(otherrbsstaffcount))[0];
                    dealteammdl.Division = Nthentry.Document.GetItemValue("Div_" + Convert.ToString(otherrbsstaffcount))[0];
                    dealteammdl.MemberType = "OtherRBSStaff";
                    dealteammdl.DateAware = Convert.ToString(Nthentry.Document.GetItemValue("DateAware_" + Convert.ToString(otherrbsstaffcount))[0]);
                    dbcontext.DealTeamFromLotusNotes.Add(dealteammdl);
                    dbcontext.SaveChanges();
                    membername = "";
                }
            }
            catch (Exception ex)
            { }
        }

        private static void PopulateFieldData(NotesViewEntry Nthentry)
        {
            try
            {
                LotusNotesOpportunityExt opp = new LotusNotesOpportunityExt();
                LotusNotesClient client = new LotusNotesClient();
                DealTeamFromLotusNotes dealteam = new DealTeamFromLotusNotes();

                #region Opportunity

                opp.DealId = Convert.ToString(Nthentry.Document.GetItemValue("DispDealRef")[0]);
                opp.DealDescription = Convert.ToString(Nthentry.Document.GetItemValue("DealDesc")[0]);
                opp.DealCurrency = Convert.ToString(Nthentry.Document.GetItemValue("Deal_Currency")[0]);
                opp.ProjectName = Convert.ToString(Nthentry.Document.GetItemValue("Customer_Code_Keep")[0]);
                opp.PriceSensitive = Convert.ToString(Nthentry.Document.GetItemValue("Price_Sensitive")[0]);
                opp.ExclusivitySigned = Convert.ToString(Nthentry.Document.GetItemValue("Exlcusivity_Signed")[0]);
                opp.DealStatus = Convert.ToString(Nthentry.Document.GetItemValue("Current_Position")[0]);
                opp.DealType = Convert.ToString(Nthentry.Document.GetItemValue("Deal_Type")[0]);
                opp.TargetCompany = Convert.ToString(Nthentry.Document.GetItemValue("target_company")[0]);
                opp.VendorCompany = Convert.ToString(Nthentry.Document.GetItemValue("DealVendor")[0]);
                opp.FinancialSponser = Convert.ToString(Nthentry.Document.GetItemValue("Spon")[0]);
                opp.TargetCompanyListed = Convert.ToString(Nthentry.Document.GetItemValue("TargetCompanyListed")[0]);
                opp.AcquisitionRelated = Convert.ToString(Nthentry.Document.GetItemValue("Acquisition")[0]);
                opp.AcquisitionDetails = Convert.ToString(Nthentry.Document.GetItemValue("AcquisitionDetails")[0]);
                opp.TreedTransaction = Convert.ToString(Nthentry.Document.GetItemValue("TreedTransaction")[0]);
                opp.BondsProgramme = Convert.ToString(Nthentry.Document.GetItemValue("Takedown")[0]);


                string dealcomments = Convert.ToString(Nthentry.Document.GetItemValue("DealComments")[0]);
                string dealcommentsext = string.Empty;

                if (dealcomments.Length > 8000)
                {
                    opp.DealComments = dealcomments.Substring(0, 7999);
                    opp.DealCommentsExtended = dealcomments.Substring(7999);
                }
                else
                {
                    opp.DealComments = dealcomments;
                    opp.DealCommentsExtended = null;
                }


                opp.DealCommentsExtended = dealcommentsext;
                opp.Probability = Convert.ToString(Nthentry.Document.GetItemValue("DealProb")[0]);
                opp.Deal_Size = Convert.ToString(Nthentry.Document.GetItemValue("dtst")[0]);
                opp.Total_Debt_Size = Convert.ToString(Nthentry.Document.GetItemValue("dsst")[0]);
                opp.Fee = Convert.ToString(Nthentry.Document.GetItemValue("dast")[0]);
                opp.CompletedLostDate = Convert.ToString(Nthentry.Document.GetItemValue("Date_Completed")[0]);
                opp.ReasonLost = Convert.ToString(Nthentry.Document.GetItemValue("Reason_Lossed")[0]);
                opp.ReasonLostDetail = Convert.ToString(Nthentry.Document.GetItemValue("Reason_Lost_Detail")[0]);
                opp.StartDate = Convert.ToString(Nthentry.Document.GetItemValue("Start_Date")[0]);
                opp.ConflictClearanceStatus = Convert.ToString(Nthentry.Document.GetItemValue("HelicoptorReg")[0]);
                opp.ConflictDeal = Convert.ToString(Nthentry.Document.GetItemValue("Conflicted_Deal")[0]);
                opp.ViewName = view.Name;
                
                opplist.Add(opp);
                #endregion

                #region Client

                client.DealId = opp.DealId;
                client.ProjectName = opp.ProjectName;
                client.L4CompanyName = Convert.ToString(Nthentry.Document.GetItemValue("CompanyName")[0]);
                client.L4CompanyCISCode = Convert.ToString(Nthentry.Document.GetItemValue("CISCode")[0]);
                client.L4SDMCode = Convert.ToString(Nthentry.Document.GetItemValue("TXSDMCODE")[0]);
                client.L4CompnaySectoor = Convert.ToString(Nthentry.Document.GetItemValue("TXSECTOR")[0]);
                client.L4CompanySectorID = Convert.ToString(Nthentry.Document.GetItemValue("TXSECTORID")[0]);
                client.L4CompanyCountry = Convert.ToString(Nthentry.Document.GetItemValue("COUNTRY")[0]);
                client.L4CompanyCountryCode = Convert.ToString(Nthentry.Document.GetItemValue("countrycode")[0]);
                client.L4CompanyRegion = Convert.ToString(Nthentry.Document.GetItemValue("intreg")[0]);
                client.L1CompanyID = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL1ID")[0]);
                client.L1CompanyName = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL1NAME")[0]);
                client.L1CompanySDMId = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL1SDMID")[0]);
                client.L2CompanyID = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL2ID")[0]);
                client.L2CompanyName = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL2NAME")[0]);
                client.L2CompanySDMID = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL2SDMID")[0]);
                client.L3CompanyId = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL3ID")[0]);
                client.L3CompanyName = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL3NAME")[0]);
                client.L3CompanySDMID = Convert.ToString(Nthentry.Document.GetItemValue("TXLEVEL3SDMID")[0]);
                
                clientlist.Add(client);

                #endregion

                #region DealTeam

                int dealteammembercount = 1;
                for (dealteammembercount = 1; dealteammembercount <= 25; dealteammembercount++)
                {
                    string membernm = Convert.ToString(Nthentry.Document.GetItemValue("Staff_id_" + Convert.ToString(dealteammembercount))[0]);

                    if (string.IsNullOrEmpty(membernm))
                        continue;

                    dealteam.DealId = opp.DealId;
                    dealteam.ProjectName = opp.ProjectName;
                    dealteam.MemberName = membernm;
                    dealteam.Role = Convert.ToString(Nthentry.Document.GetItemValue("Staff_role_" + Convert.ToString(dealteammembercount))[0]);
                    dealteam.Team = Convert.ToString(Nthentry.Document.GetItemValue("team_" + Convert.ToString(dealteammembercount))[0]);
                    dealteam.DateAware = Convert.ToString(Nthentry.Document.GetItemValue("Aware_" + Convert.ToString(dealteammembercount))[0]);
                    dealteamtable.Rows.Add(dealteam.DealId, dealteam.MemberName, dealteam.Role, dealteam.Team, dealteam.DateAware, null, null, null, dealteam.ProjectName);
                    membernm = "";
                }

                int otherrbsstaffcount = 0;
                string membername = "";
                do
                {
                    if (otherrbsstaffcount == 0)
                    {
                        membername = Convert.ToString(Nthentry.Document.GetItemValue("ExSF")[0]);

                        if (!string.IsNullOrEmpty(membername))
                        {

                            dealteam.DealId = opp.DealId;
                            dealteam.ProjectName = opp.ProjectName;
                            dealteam.MemberName = membername;
                            dealteam.Role = Convert.ToString(Nthentry.Document.GetItemValue("Staff_role")[0]);
                            dealteam.Reason = Convert.ToString(Nthentry.Document.GetItemValue("ExSFReason")[0]);
                            dealteam.Division = Convert.ToString(Nthentry.Document.GetItemValue("Div")[0]);
                            dealteam.MemberType = "OtherRBSStaff";
                            dealteam.DateAware = Convert.ToString(Nthentry.Document.GetItemValue("DateAware")[0]);

                            dealteamtable.Rows.Add(dealteam.DealId, dealteam.MemberName, dealteam.Role, null, dealteam.DateAware, dealteam.Reason, dealteam.Division, dealteam.MemberType, dealteam.ProjectName);
                        }
                    }
                    else
                    {
                        membername = Convert.ToString(Nthentry.Document.GetItemValue("ExSF_" + Convert.ToString(otherrbsstaffcount))[0]);

                        if (!string.IsNullOrEmpty(membername))
                        {
                            dealteam.DealId = opp.DealId;
                            dealteam.ProjectName = opp.ProjectName;
                            dealteam.MemberName = Convert.ToString(Nthentry.Document.GetItemValue("ExSF_" + Convert.ToString(otherrbsstaffcount))[0]);
                            dealteam.Role = Convert.ToString(Nthentry.Document.GetItemValue("Staff_role_" + Convert.ToString(dealteammembercount))[0]);
                            dealteam.Reason = Convert.ToString(Nthentry.Document.GetItemValue("ExSFReason_" + Convert.ToString(otherrbsstaffcount))[0]);
                            dealteam.Division = Convert.ToString(Nthentry.Document.GetItemValue("Div_" + Convert.ToString(otherrbsstaffcount))[0]);
                            dealteam.MemberType = "OtherRBSStaff";
                            dealteam.DateAware = Convert.ToString(Nthentry.Document.GetItemValue("DateAware_" + Convert.ToString(otherrbsstaffcount))[0]);

                            dealteamtable.Rows.Add(dealteam.DealId, dealteam.MemberName, dealteam.Role, null, dealteam.DateAware, dealteam.Reason, dealteam.Division, dealteam.MemberType, dealteam.ProjectName);
                        }
                    }
                    membername = "";
                    otherrbsstaffcount++;
                } while (otherrbsstaffcount <= 20);

                #endregion
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void GetDealDataFromTwoLevelCategory(List<Model> deals, NotesView view)
        {
            try
            {
                viewnavigator = view.CreateViewNav();
                NotesViewEntry Category = viewnavigator.GetFirst();
                Console.WriteLine("Total Count : " + view.EntryCount);
                string CategoryName = string.Empty;
                for (int counter = 1; counter <= view.TopLevelEntryCount; counter++)
                {
                    Category = viewnavigator.GetNth(counter);
                    CategoryName = Convert.ToString(Category.ColumnValues[0]);
                    NotesViewNavigator viewnavfromnav = view.CreateViewNavFromCategory(CategoryName);
                    NotesViewEntry nvfirstsubcategory = viewnavfromnav.GetFirst();

                    for (int subcategorycounter = 1; subcategorycounter <= nvfirstsubcategory.SiblingCount; subcategorycounter++)
                    {
                        NotesViewEntry nvsubcategory = viewnavfromnav.GetNth(subcategorycounter);
                        NotesViewEntry nventry = null;
                        int childcount = 1;
                        DealsFromLotusNotes dealmdl = new DealsFromLotusNotes();
                        DealTeamFromLotusNotes dealteammdl = new DealTeamFromLotusNotes();
                        dealmdl.ViewName = view.Name;
                        dealmdl.CategoryName = CategoryName + @"\" + nvsubcategory.ColumnValues[1];
                        Console.WriteLine("Subcategory : " + nvsubcategory.ColumnValues[1]);
                        Console.WriteLine("child count : " + nvsubcategory.ChildCount);

                        do
                        {
                            nventry = viewnavfromnav.GetNextDocument(null);
                            Console.WriteLine(nventry.Document.GetItemValue("DispDealRef")[0]);
                            PopulateFieldData(nventry, ref dealmdl, ref dealteammdl);
                            childcount++;
                        } while (childcount <= nvsubcategory.ChildCount);

                    }
                    Console.WriteLine("Category : " + CategoryName);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception(e.Message);
            }
        }

        private static void GetDealDataFromThreeLevelCategory(List<Model> deals, NotesView view)
        {
            try
            {
                viewnavigator = view.CreateViewNav();
                string categoryname = string.Empty;
                NotesViewEntry Category = viewnavigator.GetFirst();
                categoryname = Category.ColumnValues[0];
                Console.WriteLine(categoryname);

                for (int categorycount = 1; categorycount <= view.TopLevelEntryCount; categorycount++)
                {

                    collection = view.GetAllEntriesByKey(categoryname);
                    int recordcount = collection.Count;

                    for (int counter = 1; counter <= recordcount; counter++)
                    {

                        NotesViewEntry Nthentry = collection.GetNthEntry(counter);

                        //LotusnotesToWIP mdl = new LotusnotesToWIP();
                        //mdl.ViewName = view.Name;
                        //mdl.CategoryName = categoryname;
                        //mdl.DealName_Prefix = Nthentry.Document.GetItemValue("Customer_Code_Keep")[0];
                        //mdl.Classification = Nthentry.Document.GetItemValue("classification")[0];
                        //mdl.clcode = Nthentry.Document.GetItemValue("clcode")[0];
                        //mdl.CodeCis = Nthentry.Document.GetItemValue("CodeCIS")[0];
                        //mdl.CompanyName = Nthentry.Document.GetItemValue("CompanyName")[0];
                        //mdl.Country = Nthentry.Document.GetItemValue("Country")[0];
                        //dbcontext.LotusnotesToWIP.Add(mdl);
                        //dbcontext.SaveChanges();

                    }

                    //NotesViewEntry lastentry = view..GetNthEntry(recordcount+1);
                    Category = viewnavigator.GetNextCategory(null);
                    categoryname = Category.ColumnValues[0];
                    //Console.WriteLine(categoryname);
                }

                //dbcontext.SaveChanges();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        private static void UpdateExcel(int row, string fieldname, string fieldvalue)
        {
            Microsoft.Office.Interop.Excel.Application oXL = null;
            Microsoft.Office.Interop.Excel._Workbook oWB = null;
            Microsoft.Office.Interop.Excel._Worksheet oSheet = null;

            try
            {
                string sheetName = "Sheet1";
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oWB = oXL.Workbooks.Open(@"C:\LotusNotes\FieldData.xlsx");
                oSheet = String.IsNullOrEmpty(sheetName) ? (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet : (Microsoft.Office.Interop.Excel._Worksheet)oWB.Worksheets[sheetName];
                oSheet.Cells[row, 1] = fieldname;
                oSheet.Cells[row, 2] = fieldvalue;
                oWB.Save();
            }
            catch (Exception ex)
            { }
            finally
            {
                if (oWB != null)
                    oWB.Close();
            }
        }

        private static void insertDealTeamMember(DataTable dealteamtable)
        {
            try
            {
                SqlConnection connection = new SqlConnection(@"Data Source= lonms11691\dmlnfarm01;Initial Catalog=WIP_DEV2;persist security info=True;user id=dlmuser-dev;password=DLmus01$34try;MultipleActiveResultSets=True;");
                connection.Open();
                SqlCommand cmd = new SqlCommand("InsertDealTeamMemberFromLotusNotes", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                //Pass table Valued parameter to Store Procedure
                SqlParameter sqlParam = cmd.Parameters.AddWithValue("@dealteammembers", dealteamtable);
                sqlParam.SqlDbType = SqlDbType.Structured;
                cmd.ExecuteNonQuery();
                connection.Close();
                dealteamtable.Rows.Clear();
                //Console.Write("Data Save Successfully.");
            }
            catch (Exception ex)
            { throw new Exception(ex.Message); }
        }

        private static void sqlbulkcopy()
        {
            using (var connection = new SqlConnection(@"Data Source= lonms11691\dmlnfarm01;Initial Catalog=WIP_DEV2;persist security info=True;user id=dlmuser-dev;password=DLmus01$34try;MultipleActiveResultSets=True;"))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    bulkCopy.BatchSize = 1000;
                    try
                    {
                        bulkCopy.DestinationTableName = "dbo.LotusNotesOpportunityExt";
                        bulkCopy.WriteToServer(opplist.AsDataTable());
                        opplist.Clear();
                        //Console.WriteLine("opportunity saved.");
                        bulkCopy.DestinationTableName = "dbo.LotusNotesClientExt";
                        bulkCopy.WriteToServer(clientlist.AsDataTable());
                        clientlist.Clear();
                        //Console.WriteLine("Clients saved.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                    }
                }
                transaction.Commit();
            }

        }

    }


    public static class IEnumerableExtensions
    {
        public static DataTable AsDataTable<T>(this IEnumerable<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            var table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
    }
}

