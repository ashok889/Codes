﻿using Domino;
using NordiskRentingLotusNotesToSQL.LSFrom;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL
{
    public class FormFactory
    {
        public IFormOpration CreateInstanace(string formName)
        {
            if (formName.Equals("Incoming"))
            {
                FormCount("Incoming");
                return new EmailForm();
            }
            else if (formName.Equals("Meeting"))
            {
                FormCount("Meeting");
                return new EmailForm();
            }
            else if (formName.Equals("Misc"))
            {
                FormCount("Misc");
                return new EmailForm();
            }
            else if (formName.Equals("Outgoing"))
            {
                FormCount("Outgoing");
                return new EmailForm();
            }
            else if (formName.Equals("Response"))
            {
                FormCount("Response");
                return new EmailForm();
            }
            else if (formName.Equals("Call"))
            {
                FormCount("Call");
                return new CallForm();
            }
            else if (formName.Equals("Contact"))
            {
                FormCount("Contact");
                return new ContactForm();
            }
            else if (formName.Equals("CreditMemo"))
            {
                FormCount("CreditMemo");
                return new CreditMemoForm();
            }
            else if (formName.Equals("Customer"))
            {
                FormCount("Customer");
                return new CustomerForm();
            }
            else if (formName.Equals("Deal Documents"))
            {
                FormCount("Deal Documents");
                return new DealDocumentsForm();
            }


            //if (formName.Equals("ExProf"))
            //{
            //    FormCount("ExProf");
            //    return new ExProfForm();
            //} 

            return null;
        }

        static string logFilePath = ConfigurationManager.AppSettings["formAttachmentDirPath"];
        public static void FormCount(string fileName)
        {
            StreamWriter writeFile = new StreamWriter(logFilePath + fileName + ".txt", true);
            writeFile.WriteLine("1");
            writeFile.Close();
        }
    }
}
