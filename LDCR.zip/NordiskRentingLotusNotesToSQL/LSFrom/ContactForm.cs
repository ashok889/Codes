﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class ContactForm : DocumentProperties, IFormOpration
    {

        public FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            try
            {
                FormModel formModelObj = new FormModel();
                string form = GetDocumentText(noDocument, "Form");

                formModelObj.UniqueChildDocumentsId = noDocument.UniversalID;
                formModelObj.SystemGUID = sysGuid;
                formModelObj.Form = form;
                formModelObj.Ref = GetDocumentText(noDocument, "$REF");
                formModelObj.UpdatedBy = GetDocumentText(noDocument, "$UpdatedBy");
                formModelObj.Body = GetDocumentText(noDocument, "BODY");
                formModelObj.CompanyName = GetDocumentText(noDocument, "COMPANYNAME");
                formModelObj.ComposeDate = GetDocumentText(noDocument, "ComposeDate");
                formModelObj.ContactAddress = GetDocumentText(noDocument, "ContactAddress");
                formModelObj.ContactCity = GetDocumentText(noDocument, "ContactCity");
                formModelObj.ContactDivision = GetDocumentText(noDocument, "ContactDivision");
                formModelObj.ContactEmail = GetDocumentText(noDocument, "ContactEmail");
                formModelObj.ContactFAX = GetDocumentText(noDocument, "ContactFAX");
                formModelObj.ContactMobile = GetDocumentText(noDocument, "ContactMobile");
                formModelObj.ContactName = GetDocumentText(noDocument, "ContactName");
                formModelObj.ContactPhone = GetDocumentText(noDocument, "ContactPhone");
                formModelObj.ContactSalutation = GetDocumentText(noDocument, "ContactSalutation");
                formModelObj.ContactState = GetDocumentText(noDocument, "ContactState");
                formModelObj.ContactTitle = GetDocumentText(noDocument, "ContactTitle");
                formModelObj.ContactZIP = GetDocumentText(noDocument, "ContactZIP");
                formModelObj.Form = GetDocumentText(noDocument, "Form");

                // Attachment list
                DownloadDocumentFiles(noDocument, sysGuid, form);

                return formModelObj;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching Contact Form data from lotus notes. Error message: "+ ex.Message, "ERROR");
                throw;
            }
        }
    }
}
