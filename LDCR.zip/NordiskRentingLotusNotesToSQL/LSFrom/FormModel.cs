﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class FormModel
    {
        public string Prof { get; set; }
        public int Count { get; set; }
        public string SystemGUID { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string UpdatedBy { get; set; }
        public string AccountManager  { get; set; }
        public string ActivityDate { get; set; }
        public string ARRReport { get; set; }
        public string Attendees { get; set; }
        public string Author5 { get; set; }
        public string BoardMinutes { get; set; }
        public string BoardSubmission { get; set; }
        public string Body { get; set; }
        public string CallDate { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyAddress2 { get; set; }
        public string CompanyCity { get; set; }
        public string CompanyFAX { get; set; }
        public string CompanyName { get; set; }
        public string CompanyPhone { get; set; }
        public string CompanyRepName { get; set; }
        public string CompanyState { get; set; }
        public string CompanyZIP { get; set; }
        public string CompletionChecklist { get; set; }
        public string ComposeDate { get; set; }
        public string ConfidentialityAgreement { get; set; }
        public string ContactAddress { get; set; }
        public string ContactCity { get; set; }
        public string ContactDivision { get; set; }
        public string ContactEmail { get; set; }
        public string ContactFAX { get; set; }
        public string ContactMobile { get; set; }
        public string ContactName { get; set; }
        public string ContactPhone { get; set; }
        public string ContactSalutation { get; set; }
        public string ContactState { get; set; }
        public string ContactTitle { get; set; }
        public string ContactZIP { get; set; }
        public string CorrespondenceDate { get; set; }
        public string CorrespondenceType { get; set; }
        public string Country { get; set; }
        public string CreditRecommendations { get; set; }
        public string CreditMinutes { get; set; }
        public string SubmissionAndReviewPaper { get; set; }
        public string DueDeligenceReports { get; set; }
        public string DocAuthor { get; set; }
        public string NumberOfDocuments { get; set; }
        public string DueDiligence { get; set; }
        public string FacilityAgreement { get; set; }
        public string FinalDocs { get; set; }
        public string Form { get; set; }
        public string From { get; set; }
        public string HeadsOfTerms { get; set; }
        public string InfoMemo { get; set; }
        public string Initiator { get; set; }
        public string KYC_Review { get; set; }
        public string LawyerInstruction { get; set; }
        public string LoanMarketsdocs { get; set; }
        public string MeetingDate { get; set; }
        public string KYC_Misc_Docs { get; set; }
        public string Model { get; set; }
        public string MonitoringInstruction { get; set; }
        public string OnePager { get; set; }
        public string KYC_Org_Chart { get; set; }
        public string OurRepName { get; set; }
        public string Portfolio_cashflow { get; set; }
        public string Portfolio_handover_checklist { get; set; }
        public string Portfolio_hedging { get; set; }
        public string Portfolio_management_Info { get; set; }
        public string Portfolio_Financial_Covenant_Monitoring { get; set; }
        public string Portfolio_other { get; set; }
        public string PostCompletionMemo { get; set; }
        public string PreCompletionMemo { get; set; }
        public string Progress { get; set; }
        public string RecipientName { get; set; }
        public string SenderName { get; set; }
        public string Status { get; set; }
        public string Subject { get; set; }
        public string TransferCertificates { get; set; }
        public string ValuerInstruction { get; set; }
        public string WhomCalledWhom { get; set; }
        //public List<AttachmentModel> Attachements { get; set; }

    }

    public class AttachmentModel
    {
        public string SysGuid { get; set; }        
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileExtention { get; set; }
        public byte[] FileData { get; set; }
    }
}
