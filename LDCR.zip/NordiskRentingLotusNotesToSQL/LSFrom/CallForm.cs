﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class CallForm : DocumentProperties, IFormOpration
    {
        
        public FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            try
            {
                FormModel formModelObj = new FormModel();
                string form = GetDocumentText(noDocument, "Form");

                formModelObj.UniqueChildDocumentsId = noDocument.UniversalID;
                formModelObj.SystemGUID = sysGuid;
                formModelObj.Form = form;
                formModelObj.Ref = GetDocumentText(noDocument, "$REF");
                formModelObj.Author5 = GetDocumentText(noDocument, "Author5");
                formModelObj.ComposeDate = GetDocumentText(noDocument, "ComposeDate");
                formModelObj.Initiator = GetDocumentText(noDocument, "Initiator");
                formModelObj.CompanyName = GetDocumentText(noDocument, "COMPANYNAME");
                formModelObj.OurRepName = GetDocumentText(noDocument, "OurRepName");
                formModelObj.CompanyRepName = GetDocumentText(noDocument, "CompanyRepName");
                formModelObj.CallDate = GetDocumentText(noDocument, "CallDate");
                formModelObj.Subject = GetDocumentText(noDocument, "Subject");
                formModelObj.Body = GetDocumentText(noDocument, "BODY");
                formModelObj.WhomCalledWhom = GetDocumentText(noDocument, "WhomCalledWhom");
                formModelObj.UpdatedBy = GetDocumentText(noDocument, "$UpdatedBy");
                formModelObj.From = GetDocumentText(noDocument, "From");

                // Attachment list
                DownloadDocumentFiles(noDocument, sysGuid, form);
                return formModelObj;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching Call Form data from lotus notes. Error message" + ex.Message, "ERROR");
                throw;
            }
            
        }
    }
}
