﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class CreditMemoForm : DocumentProperties, IFormOpration
    {

        public FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            try
            {
                FormModel formModelObj = new FormModel();
                string form = GetDocumentText(noDocument, "Form");

                formModelObj.UniqueChildDocumentsId = noDocument.UniversalID;
                formModelObj.Form = form;
                formModelObj.SystemGUID = sysGuid;
                formModelObj.Ref = GetDocumentText(noDocument, "$REF");
                formModelObj.UpdatedBy = GetDocumentText(noDocument, "$UpdatedBy");
                formModelObj.ActivityDate = GetDocumentText(noDocument, "ActivityDate");
                formModelObj.Body = GetDocumentText(noDocument, "BODY");
                formModelObj.CompanyName = GetDocumentText(noDocument, "COMPANYNAME");
                formModelObj.ComposeDate = GetDocumentText(noDocument, "ComposeDate");
                formModelObj.DocAuthor = GetDocumentText(noDocument, "DocAuthor");
                formModelObj.Subject = GetDocumentText(noDocument, "Subject");
                formModelObj.Form = form;

                // Attachment list
                DownloadDocumentFiles(noDocument, sysGuid, form);

                return formModelObj;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching CreditMemo Form data from lotus notes.Error message : "+ ex.Message, "ERROR");
                throw;
            }
        }
    }
}