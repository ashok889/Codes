﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class CheckListModel
    {
        public Opportunity Opportunity { get; set; }
        public List<OtherRBSStaff> OtherRBSStaffList { get; set; }
        public Deal Deal { get; set; }
        public List<DealTeam> DealTeam { get; set; }
        public Senior Senior { get; set; }
        public List<SeniorFacility> SeniorFacilityList { get; set; }
        public Mezzanine Mezzanine { get; set; }
        public List<MezzanineFacility> MezzanineFacilityList { get; set; }
        public Equity Equity { get; set; }
        public List<EquityFacility> EquityFacilityList { get; set; }
        public Other Other { get; set; }
        public List<OtherFacility> OtherFacilityList { get; set; }
        public PostCompletion PostCompletion { get; set; }

    }

    public class Opportunity
    {
        public string Id { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        /// <summary>
        /// CompanyName
        /// </summary>
        public string CompanyName { get; set; }
        /// <summary>
        /// CISCode
        /// </summary>
        public string CISCode { get; set; }
        /// <summary>
        /// Team_Price_Sensitive
        /// </summary>
        public string PriceSensitive { get; set; }
        public string ProjectName { get; set; }
        /// <summary>
        /// DealBrief
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// DealComments
        /// </summary>
        public string DealComments { get; set; }
    }
    public class Deal
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string Deal_Type { get; set; }
        public string Target_Company { get; set; }
        public string DealVendor { get; set; }
        public string Source { get; set; }
        public string Introducer_Name { get; set; }
        public string Int_Corp { get; set; }
        public string Int_SF { get; set; }
        public string Gov { get; set; }
        /// <summary>
        /// Resi
        /// </summary>
        public string PropCoResidentialDeal { get; set; }
        public string NRDateBoard { get; set; }
        public string DebtType { get; set; }
        public string WIPDealAmount { get; set; }
        public string Deal_Currency { get; set; }
    }
    public class DealTeam
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        /// <summary>
        /// Staff1, Staff2, Staff_Id_2, Staff_Id_3 ……. Staff_Id_24
        /// </summary>
        public string Staff { get; set; }
        /// <summary>
        /// Team1, Team_1, Team_2, Team_3 ….. Team_24
        /// </summary>
        public string Team { get; set; }
        /// <summary>
        /// Aware, Aware_1, Aware_2, Aware_3  …… Aware_24
        /// </summary>
        public string Aware { get; set; }
        /// <summary>
        /// Staff_role, Staff_role_1, Staff_role_2  …… Staff_role_24
        /// </summary>
        public string StaffRole { get; set; }

    }
    public class OtherRBSStaff
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        /// <summary>
        /// ExSF, ExSF_1, ExSF_2  ……   ExSF_19
        /// </summary>
        public string ExSF { get; set; }
        /// <summary>
        /// Div, Div_1, Div_2  …….  Div_19
        /// </summary>
        public string Div { get; set; }
        /// <summary>
        /// DateAware , DateAware_1 , DateAware_2  …..  DateAware_19
        /// </summary>
        public string DateAware { get; set; }
        /// <summary>
        /// ExSFReason , ExSFReason_1 , ExSFReason_2 …… ExSFReason_19
        /// </summary>
        public string ExSFReasone { get; set; }
    }
    public class Senior
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        /// <summary>
        /// Progress_deal
        /// </summary>
        public string SeniorDealPosition { get; set; }
        /// <summary>
        /// role
        /// </summary>
        public string MarketRole { get; set; }
        /// <summary>
        /// SF_Role
        /// </summary>
        public string SFRole { get; set; }
        /// <summary>
        /// Total_debt_size
        /// </summary>
        public string Total_debt_size { get; set; }
        /// <summary>
        /// DealProb
        /// </summary>
        public string DealProb { get; set; }
        public string DateEstCompletion { get; set; }
        public string DateCompletion { get; set; }
        /// <summary>
        /// Reason_Lossed
        /// </summary>
        public string ReasonLost { get; set; }
        /// <summary>
        /// Loss_to
        /// </summary>
        public string LostTo { get; set; }
        /// <summary>
        /// Reason_Lost_Detail
        /// </summary>
        public string DetailedReasonLost { get; set; }
        /// <summary>
        /// Lost_comp
        /// </summary>
        public string Competitor { get; set; }

    }
    public class SeniorFacility
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string Line { get; set; }
        public string FacilityType { get; set; }
        public string ProductOwnerCode { get; set; }
        public string Term { get; set; }
        public string Currency { get; set; }
        public string Day1GrossCommit { get; set; }
        public string LMCurrentPosition { get; set; }
        public string ExpectedFinalHold { get; set; }
        public string Day1Utilisation { get; set; }
        public string Month1Utilisation { get; set; }
        public string Month3Utilisation { get; set; }
        public string Margin { get; set; }
        public string GrossFee { get; set; }
        public string NetFee { get; set; }
        public string RecurringFeeType { get; set; }
        public string RecurringFee { get; set; }
        public string CommitmentFee { get; set; }
        public string CommitedUncommited { get; set; }
        public string ProbabilityOfDefault { get; set; }
        public string LossGivenDefault { get; set; }
        public string SanctionedGrossCommit { get; set; }
        public string SanctionedHold { get; set; }
        public string PRisMFacilityID { get; set; }
        public string Securitisation { get; set; }
    }

    public class Mezzanine
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string SeniorDealPosition { get; set; }
        public string MarketRole { get; set; }
        public string SFRole { get; set; }
        public string TotalDebtSize { get; set; }
        public string DealProbability { get; set; }
        public string ExtCompletionDate { get; set; }
        public string ActualCompletionDate { get; set; }
        public string ReasonLost { get; set; }
        public string LostTo { get; set; }
        public string DetailedReasonLost { get; set; }
        public string Competitor { get; set; }
    }

    public class MezzanineFacility
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string Line { get; set; }
        public string FacilityType { get; set; }
        public string ProductOwnerCode { get; set; }
        public string Term { get; set; }
        public string Currency { get; set; }
        public string Day1GrossCommit { get; set; }
        public string LMCurrentPosition { get; set; }
        public string ExpectedFinalHold { get; set; }
        public string Day1Utilisation { get; set; }
        public string Month1Utilisation { get; set; }
        public string Month3Utilisation { get; set; }
        public string Margin { get; set; }
        public string GrossFee { get; set; }
        public string NetFee { get; set; }
        public string RecurringFeeType { get; set; }
        public string RecurringFee { get; set; }
        public string CommitmentFee { get; set; }
        public string CommitedUncommited { get; set; }
        public string ProbabilityOfDefault { get; set; }
        public string LossGivenDefault { get; set; }
        public string SanctionedGrossCommit { get; set; }
        public string SanctionedHold { get; set; }
        public string PRisMFacilityID { get; set; }
        public string Securitisation { get; set; }

    }

    public class Equity
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string SeniorDealPosition { get; set; }
        public string MarketRole { get; set; }
        public string SFRole { get; set; }
        public string TotalDebtSize { get; set; }
        public string DealProbability { get; set; }
        public string ExtCompletionDate { get; set; }
        public string ActualCompletionDate { get; set; }
        public string ReasonLost { get; set; }
        public string LostTo { get; set; }
        public string DetailedReasonLost { get; set; }
        public string Competitor { get; set; }
    }

    public class EquityFacility
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string Line { get; set; }
        public string FacilityType { get; set; }
        public string ProductOwnerCode { get; set; }
        public string Term { get; set; }
        public string Currency { get; set; }
        public string Day1GrossCommit { get; set; }
        public string LMCurrentPosition { get; set; }
        public string ExpectedFinalHold { get; set; }
        public string Day1Utilisation { get; set; }
        public string Month1Utilisation { get; set; }
        public string Month3Utilisation { get; set; }
        public string Margin { get; set; }
        public string GrossFee { get; set; }
        public string NetFee { get; set; }
        public string RecurringFeeType { get; set; }
        public string RecurringFee { get; set; }
        public string CommitmentFee { get; set; }
        public string CommitedUncommited { get; set; }
        public string ProbabilityOfDefault { get; set; }
        public string LossGivenDefault { get; set; }
        public string SanctionedGrossCommit { get; set; }
        public string SanctionedHold { get; set; }
        public string PRisMFacilityID { get; set; }
        public string Securitisation { get; set; }
    }

    public class Other
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string SeniorDealPosition { get; set; }
        public string MarketRole { get; set; }
        public string SFRole { get; set; }
        public string TotalDebtSize { get; set; }
        public string DealProbability { get; set; }
        public string ExtCompletionDate { get; set; }
        public string ActualCompletionDate { get; set; }
        public string ReasonLost { get; set; }
        public string LostTo { get; set; }
        public string DetailedReasonLost { get; set; }
        public string Competitor { get; set; }

    }

    public class OtherFacility
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string Line { get; set; }
        public string FacilityType { get; set; }
        public string ProductOwnerCode { get; set; }
        public string Term { get; set; }
        public string Currency { get; set; }
        public string Day1GrossCommit { get; set; }
        public string LMCurrentPosition { get; set; }
        public string ExpectedFinalHold { get; set; }
        public string Day1Utilisation { get; set; }
        public string Month1Utilisation { get; set; }
        public string Month3Utilisation { get; set; }
        public string Margin { get; set; }
        public string GrossFee { get; set; }
        public string NetFee { get; set; }
        public string RecurringFeeType { get; set; }
        public string RecurringFee { get; set; }
        public string CommitmentFee { get; set; }
        public string CommitedUncommited { get; set; }
        public string ProbabilityOfDefault { get; set; }
        public string LossGivenDefault { get; set; }
        public string SanctionedGrossCommit { get; set; }
        public string SanctionedHold { get; set; }
        public string PRisMFacilityID { get; set; }
        public string Securitisation { get; set; }
    }

    public class PostCompletion
    {
        public string OpportunityId { get; set; }
        public string UniqueChildDocumentsId { get; set; }
        public string Ref { get; set; }
        public string DealReportable { get; set; }
        public string AssestTransferredtoPortfolioRM { get; set; }
        public string AssestTransferDate { get; set; }
        public string RepaymentDate { get; set; }
        public string RepaymentRoute { get; set; }
    }

}
