﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NordiskRentingLotusNotesToSQL.LSFrom;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class CheckListForm : DocumentProperties
    {
        NotesDocument _noDocument;
        //string _noDocument.UniversalID;
        string _sysGuid;
        public CheckListModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            _noDocument = noDocument;
            _sysGuid = sysGuid;

            CheckListModel checkListModel = new CheckListModel();
            checkListModel.Opportunity = GetOpportunity();
            checkListModel.Deal = GetDeal();
            checkListModel.DealTeam = GetDealTeam();
            checkListModel.OtherRBSStaffList = GetOtherRBSStaffList();
            checkListModel.Senior = GetSenior();
            checkListModel.SeniorFacilityList = GetSeniorFacilityList();
            checkListModel.Mezzanine = GetMezzanine();
            checkListModel.MezzanineFacilityList = GetMezzanineFacilityList();
            checkListModel.Equity = GetEquity();
            checkListModel.EquityFacilityList = GetEquityFacility();
            checkListModel.Other = GetOther();
            checkListModel.OtherFacilityList = GetOtherFacility();
            checkListModel.PostCompletion = GetPostCompletion();

            // Attachment list
            DownloadDocumentFiles(noDocument, sysGuid, "Checklist");

            return checkListModel;
        }


        private PostCompletion GetPostCompletion()
        {
            Logger.FileLogger("Getting PostCompletion...");
            PostCompletion postCompletion = new PostCompletion();
            postCompletion.OpportunityId = _sysGuid;
            postCompletion.UniqueChildDocumentsId = _noDocument.UniversalID;
            postCompletion.Ref = GetDocumentText(_noDocument, "$REF");
            postCompletion.DealReportable = GetDocumentText(_noDocument, "Conflicted_Deal_1");
            postCompletion.AssestTransferredtoPortfolioRM = GetDocumentText(_noDocument, "DealType");
            postCompletion.AssestTransferDate = GetDocumentText(_noDocument, "Date_to_Port");
            postCompletion.RepaymentDate = GetDocumentText(_noDocument, "Exitdate");
            postCompletion.RepaymentRoute = GetDocumentText(_noDocument, "reason");
            Logger.FileLogger("Got PostCompletion...");
            return postCompletion;
        }

        private List<OtherFacility> GetOtherFacility()
        {
            List<OtherFacility> OtherFacilityList = new List<OtherFacility>();
            Logger.FileLogger("Getting OtherFacility...");
            for (int i = 1; i <= 4; i++)
            {
                string Line = GetDocumentText(_noDocument, "ln" + i + "_3");
                string FacilityType = GetDocumentText(_noDocument, "fc" + i + "_3");
                string ProductOwnerCode = GetDocumentText(_noDocument, "po" + i + "_3");
                string Term = GetDocumentText(_noDocument, "t" + i + "_3");
                string Currency = GetDocumentText(_noDocument, "cy" + i + "_3");
                string Day1GrossCommit = GetDocumentText(_noDocument, "u" + i + "_3");
                string LMCurrentPosition = GetDocumentText(_noDocument, "cc" + i + "_3");
                string ExpectedFinalHold = GetDocumentText(_noDocument, "h" + i + "_3");
                string Day1Utilisation = GetDocumentText(_noDocument, "du" + i + "_3");
                string Month1Utilisation = GetDocumentText(_noDocument, "m" + (i + 20) + "_3");
                string Month3Utilisation = GetDocumentText(_noDocument, "m" + (i + 30) + "_3");
                string Margin = GetDocumentText(_noDocument, "m" + i + "_3");
                string GrossFee = GetDocumentText(_noDocument, "g" + i + "_3");
                string NetFee = GetDocumentText(_noDocument, "n" + i + "_3");
                string RecurringFeeType = GetDocumentText(_noDocument, "nr" + i + "_3");
                string RecurringFee = GetDocumentText(_noDocument, "o" + i + "_3");
                string CommitmentFee = GetDocumentText(_noDocument, "p" + i + "_3");
                string CommitedUncommited = GetDocumentText(_noDocument, "co" + i + "_3");
                string ProbabilityOfDefault = GetDocumentText(_noDocument, "pd" + i + "_3");
                string LossGivenDefault = GetDocumentText(_noDocument, "lg" + i + "_3");
                string SanctionedGrossCommit = GetDocumentText(_noDocument, "cu" + i + "_3");
                string SanctionedHold = GetDocumentText(_noDocument, "ch" + i + "_3");
                string PRisMFacilityID = GetDocumentText(_noDocument, "prismID" + i + "_3");
                string Securitisation = GetDocumentText(_noDocument, "secu" + i + "_3");

                if (string.IsNullOrEmpty(Line) && string.IsNullOrEmpty(FacilityType) && string.IsNullOrEmpty(ProductOwnerCode) &&
                    string.IsNullOrEmpty(Term) && string.IsNullOrEmpty(Currency) && string.IsNullOrEmpty(Day1GrossCommit) &&
                    string.IsNullOrEmpty(LMCurrentPosition) && string.IsNullOrEmpty(ExpectedFinalHold) && string.IsNullOrEmpty(Day1Utilisation) &&
                    string.IsNullOrEmpty(Month1Utilisation) && string.IsNullOrEmpty(Month3Utilisation) && string.IsNullOrEmpty(Margin) &&
                    string.IsNullOrEmpty(GrossFee) && string.IsNullOrEmpty(NetFee) && string.IsNullOrEmpty(RecurringFeeType) && string.IsNullOrEmpty(RecurringFee) &&
                    string.IsNullOrEmpty(CommitmentFee) && string.IsNullOrEmpty(CommitedUncommited) && string.IsNullOrEmpty(ProbabilityOfDefault) &&
                    string.IsNullOrEmpty(LossGivenDefault) && string.IsNullOrEmpty(SanctionedGrossCommit) && string.IsNullOrEmpty(SanctionedHold) &&
                    string.IsNullOrEmpty(PRisMFacilityID) && string.IsNullOrEmpty(Securitisation))
                    continue;

                OtherFacility OtherFacility = new OtherFacility()
                {
                    UniqueChildDocumentsId = _noDocument.UniversalID,
                    Ref = GetDocumentText(_noDocument, "$REF"),
                    CommitedUncommited = CommitedUncommited,
                    CommitmentFee = CommitmentFee,
                    Currency = Currency,
                    Day1GrossCommit = Day1GrossCommit,
                    Day1Utilisation = Day1Utilisation,
                    ExpectedFinalHold = ExpectedFinalHold,
                    FacilityType = FacilityType,
                    GrossFee = GrossFee,
                    Line = Line,
                    LMCurrentPosition = LMCurrentPosition,
                    LossGivenDefault = LossGivenDefault,
                    Margin = Margin,
                    Month1Utilisation = Month1Utilisation,
                    Month3Utilisation = Month3Utilisation,
                    NetFee = NetFee,
                    OpportunityId = _sysGuid,
                    PRisMFacilityID = PRisMFacilityID,
                    ProbabilityOfDefault = ProbabilityOfDefault,
                    ProductOwnerCode = ProductOwnerCode,
                    RecurringFee = RecurringFee,
                    RecurringFeeType = RecurringFeeType,
                    SanctionedGrossCommit = SanctionedGrossCommit,
                    SanctionedHold = SanctionedHold,
                    Securitisation = Securitisation,
                    Term = Term
                };
                OtherFacilityList.Add(OtherFacility);
            }
            Logger.FileLogger("Got OtherFacility...");
            return OtherFacilityList;
        }

        private Other GetOther()
        {
            Logger.FileLogger("Getting Other...");
            Other Other = new Other();
            Other.OpportunityId = _sysGuid;
            Other.UniqueChildDocumentsId = _noDocument.UniversalID; ;
            Other.Ref = GetDocumentText(_noDocument, "$REF");
            Other.SeniorDealPosition = GetDocumentText(_noDocument, "Progress_deal_3");
            Other.MarketRole = GetDocumentText(_noDocument, "role_3");
            Other.SFRole = GetDocumentText(_noDocument, "SF_Role_3");
            Other.TotalDebtSize = GetDocumentText(_noDocument, "Total_debt_size_3");
            Other.DealProbability = GetDocumentText(_noDocument, "DealProb_3");
            Other.ExtCompletionDate = GetDocumentText(_noDocument, "DateEstCompletion_3");
            Other.ActualCompletionDate = GetDocumentText(_noDocument, "DateCompletion_3");
            Other.ReasonLost = GetDocumentText(_noDocument, "Reason_Lossed_3");
            Other.LostTo = GetDocumentText(_noDocument, "Loss_to_3");
            Other.DetailedReasonLost = GetDocumentText(_noDocument, "Reason_Lost_Detail_3");
            Other.Competitor = GetDocumentText(_noDocument, "Lost_comp_3");
            Logger.FileLogger("Got Other...");
            return Other;
        }

        private List<EquityFacility> GetEquityFacility()
        {
            List<EquityFacility> EquityFacilityList = new List<EquityFacility>();
            Logger.FileLogger("Getting EquityFacility...");
            for (int i = 1; i <= 3; i++)
            {
                string Line = GetDocumentText(_noDocument, "ln" + i + "_2");
                string FacilityType = GetDocumentText(_noDocument, "fc" + i + "_2");
                string ProductOwnerCode = GetDocumentText(_noDocument, "po" + i + "_2");
                string Term = GetDocumentText(_noDocument, "t" + i + "_2");
                string Currency = GetDocumentText(_noDocument, "cy" + i + "_2");
                string Day1GrossCommit = GetDocumentText(_noDocument, "u" + i + "_2");
                string LMCurrentPosition = GetDocumentText(_noDocument, "cc" + i + "_2");
                string ExpectedFinalHold = GetDocumentText(_noDocument, "h" + i + "_2");
                string Day1Utilisation = GetDocumentText(_noDocument, "du" + i + "_2");
                string Month1Utilisation = GetDocumentText(_noDocument, "m" + (i + 20) + "_2");
                string Month3Utilisation = GetDocumentText(_noDocument, "m" + (i + 30) + "_2");
                string Margin = GetDocumentText(_noDocument, "m" + i + "_2");
                string GrossFee = GetDocumentText(_noDocument, "g" + i + "_2");
                string NetFee = GetDocumentText(_noDocument, "n" + i + "_2");
                string RecurringFeeType = GetDocumentText(_noDocument, "nr" + i + "_2");
                string RecurringFee = GetDocumentText(_noDocument, "o" + i + "_2");
                string CommitmentFee = GetDocumentText(_noDocument, "p" + i + "_2");
                string CommitedUncommited = GetDocumentText(_noDocument, "co" + i + "_2");
                string ProbabilityOfDefault = GetDocumentText(_noDocument, "pd" + i + "_2");
                string LossGivenDefault = GetDocumentText(_noDocument, "lg" + i + "_2");
                string SanctionedGrossCommit = GetDocumentText(_noDocument, "cu" + i + "_2");
                string SanctionedHold = GetDocumentText(_noDocument, "ch" + i + "_2");
                string PRisMFacilityID = GetDocumentText(_noDocument, "prismID" + i + "_2");
                string Securitisation = GetDocumentText(_noDocument, "secu" + i + "_2");

                if (string.IsNullOrEmpty(Line) && string.IsNullOrEmpty(FacilityType) && string.IsNullOrEmpty(ProductOwnerCode) &&
                    string.IsNullOrEmpty(Term) && string.IsNullOrEmpty(Currency) && string.IsNullOrEmpty(Day1GrossCommit) &&
                    string.IsNullOrEmpty(LMCurrentPosition) && string.IsNullOrEmpty(ExpectedFinalHold) && string.IsNullOrEmpty(Day1Utilisation) &&
                    string.IsNullOrEmpty(Month1Utilisation) && string.IsNullOrEmpty(Month3Utilisation) && string.IsNullOrEmpty(Margin) &&
                    string.IsNullOrEmpty(GrossFee) && string.IsNullOrEmpty(NetFee) && string.IsNullOrEmpty(RecurringFeeType) && string.IsNullOrEmpty(RecurringFee) &&
                    string.IsNullOrEmpty(CommitmentFee) && string.IsNullOrEmpty(CommitedUncommited) && string.IsNullOrEmpty(ProbabilityOfDefault) &&
                    string.IsNullOrEmpty(LossGivenDefault) && string.IsNullOrEmpty(SanctionedGrossCommit) && string.IsNullOrEmpty(SanctionedHold) &&
                    string.IsNullOrEmpty(PRisMFacilityID) && string.IsNullOrEmpty(Securitisation))
                    continue;

                EquityFacility EquityFacility = new EquityFacility()
                {
                    OpportunityId = _sysGuid,
                    UniqueChildDocumentsId = _noDocument.UniversalID,
                    Ref = GetDocumentText(_noDocument, "$REF"),
                    CommitedUncommited = CommitedUncommited,
                    CommitmentFee = CommitmentFee,
                    Currency = Currency,
                    Day1GrossCommit = Day1GrossCommit,
                    Day1Utilisation = Day1Utilisation,
                    ExpectedFinalHold = ExpectedFinalHold,
                    FacilityType = FacilityType,
                    GrossFee = GrossFee,
                    Line = Line,
                    LMCurrentPosition = LMCurrentPosition,
                    LossGivenDefault = LossGivenDefault,
                    Margin = Margin,
                    Month1Utilisation = Month1Utilisation,
                    Month3Utilisation = Month3Utilisation,
                    NetFee = NetFee,                    
                    PRisMFacilityID = PRisMFacilityID,
                    ProbabilityOfDefault = ProbabilityOfDefault,
                    ProductOwnerCode = ProductOwnerCode,
                    RecurringFee = RecurringFee,
                    RecurringFeeType = RecurringFeeType,
                    SanctionedGrossCommit = SanctionedGrossCommit,
                    SanctionedHold = SanctionedHold,
                    Securitisation = Securitisation,
                    Term = Term
                };
                EquityFacilityList.Add(EquityFacility);
            }
            Logger.FileLogger("Got EquityFacility...");
            return EquityFacilityList;
        }

        private Equity GetEquity()
        {
            Logger.FileLogger("Getting Equity...");
            Equity equity = new Equity();
            equity.OpportunityId = _sysGuid;
            equity.UniqueChildDocumentsId = _noDocument.UniversalID;
            equity.Ref = GetDocumentText(_noDocument, "$REF");
            equity.SeniorDealPosition = GetDocumentText(_noDocument, "Progress_deal_2");
            equity.MarketRole = GetDocumentText(_noDocument, "role_2");
            equity.SFRole = GetDocumentText(_noDocument, "SF_Role_2");
            equity.TotalDebtSize = GetDocumentText(_noDocument, "Total_debt_size_2");
            equity.DealProbability = GetDocumentText(_noDocument, "DealProb_2");
            equity.ExtCompletionDate = GetDocumentText(_noDocument, "DateEstCompletion_2");
            equity.ActualCompletionDate = GetDocumentText(_noDocument, "DateCompletion_2");
            equity.ReasonLost = GetDocumentText(_noDocument, "Reason_Lossed_2");
            equity.LostTo = GetDocumentText(_noDocument, "Loss_to_2");
            equity.DetailedReasonLost = GetDocumentText(_noDocument, "Reason_Lost_Detail_2");
            equity.Competitor = GetDocumentText(_noDocument, "Lost_comp_2");
            Logger.FileLogger("Got Equity...");
            return equity;
        }

        private List<MezzanineFacility> GetMezzanineFacilityList()
        {
            List<MezzanineFacility> MezzanineFacilityList = new List<MezzanineFacility>();
            Logger.FileLogger("Getting MezzanineFacility...");
            for (int i = 1; i <= 3; i++)
            {
                string Line = GetDocumentText(_noDocument, "ln" + i + "_1");
                string FacilityType = GetDocumentText(_noDocument, "fc" + i + "_1");
                string ProductOwnerCode = GetDocumentText(_noDocument, "po" + i + "_1");
                string Term = GetDocumentText(_noDocument, "t" + i + "_1");
                string Currency = GetDocumentText(_noDocument, "cy" + i + "_1");
                string Day1GrossCommit = GetDocumentText(_noDocument, "u" + i + "_1");
                string LMCurrentPosition = GetDocumentText(_noDocument, "cc" + i + "_1");
                string ExpectedFinalHold = GetDocumentText(_noDocument, "h" + i + "_1");
                string Day1Utilisation = GetDocumentText(_noDocument, "du" + i + "_1");
                string Month1Utilisation = GetDocumentText(_noDocument, "m" + (i + 20) + "_1");
                string Month3Utilisation = GetDocumentText(_noDocument, "m" + (i + 30) + "_1");
                string Margin = GetDocumentText(_noDocument, "m" + i + "_1");
                string GrossFee = GetDocumentText(_noDocument, "g" + i + "_1");
                string NetFee = GetDocumentText(_noDocument, "n" + i + "_1");
                string RecurringFeeType = GetDocumentText(_noDocument, "nr" + i + "_1");
                string RecurringFee = GetDocumentText(_noDocument, "o" + i + "_1");
                string CommitmentFee = GetDocumentText(_noDocument, "p" + i + "_1");
                string CommitedUncommited = GetDocumentText(_noDocument, "co" + i + "_1");
                string ProbabilityOfDefault = GetDocumentText(_noDocument, "pd" + i + "_1");
                string LossGivenDefault = GetDocumentText(_noDocument, "lg" + i + "_1");
                string SanctionedGrossCommit = GetDocumentText(_noDocument, "cu" + i + "_1");
                string SanctionedHold = GetDocumentText(_noDocument, "ch" + i + "_1");
                string PRisMFacilityID = GetDocumentText(_noDocument, "prismID" + i + "_1");
                string Securitisation = GetDocumentText(_noDocument, "secu" + i + "_1");

                if (string.IsNullOrEmpty(Line) && string.IsNullOrEmpty(FacilityType) && string.IsNullOrEmpty(ProductOwnerCode) &&
                    string.IsNullOrEmpty(Term) && string.IsNullOrEmpty(Currency) && string.IsNullOrEmpty(Day1GrossCommit) &&
                    string.IsNullOrEmpty(LMCurrentPosition) && string.IsNullOrEmpty(ExpectedFinalHold) && string.IsNullOrEmpty(Day1Utilisation) &&
                    string.IsNullOrEmpty(Month1Utilisation) && string.IsNullOrEmpty(Month3Utilisation) && string.IsNullOrEmpty(Margin) &&
                    string.IsNullOrEmpty(GrossFee) && string.IsNullOrEmpty(NetFee) && string.IsNullOrEmpty(RecurringFeeType) && string.IsNullOrEmpty(RecurringFee) &&
                    string.IsNullOrEmpty(CommitmentFee) && string.IsNullOrEmpty(CommitedUncommited) && string.IsNullOrEmpty(ProbabilityOfDefault) &&
                    string.IsNullOrEmpty(LossGivenDefault) && string.IsNullOrEmpty(SanctionedGrossCommit) && string.IsNullOrEmpty(SanctionedHold) &&
                    string.IsNullOrEmpty(PRisMFacilityID) && string.IsNullOrEmpty(Securitisation))
                    continue;

                MezzanineFacility MezzanineFacility = new MezzanineFacility()
                {
                    Ref = GetDocumentText(_noDocument, "$REF"),
                    UniqueChildDocumentsId = _noDocument.UniversalID,
                    CommitedUncommited = CommitedUncommited,
                    CommitmentFee = CommitmentFee,
                    Currency = Currency,
                    Day1GrossCommit = Day1GrossCommit,
                    Day1Utilisation = Day1Utilisation,
                    ExpectedFinalHold = ExpectedFinalHold,
                    FacilityType = FacilityType,
                    GrossFee = GrossFee,
                    Line = Line,
                    LMCurrentPosition = LMCurrentPosition,
                    LossGivenDefault = LossGivenDefault,
                    Margin = Margin,
                    Month1Utilisation = Month1Utilisation,
                    Month3Utilisation = Month3Utilisation,
                    NetFee = NetFee,
                    OpportunityId = _sysGuid,
                    PRisMFacilityID = PRisMFacilityID,
                    ProbabilityOfDefault = ProbabilityOfDefault,
                    ProductOwnerCode = ProductOwnerCode,
                    RecurringFee = RecurringFee,
                    RecurringFeeType = RecurringFeeType,
                    SanctionedGrossCommit = SanctionedGrossCommit,
                    SanctionedHold = SanctionedHold,
                    Securitisation = Securitisation,
                    Term = Term
                };
                MezzanineFacilityList.Add(MezzanineFacility);
            }
            Logger.FileLogger("Got MezzanineFacility...");
            return MezzanineFacilityList;
        }

        private Mezzanine GetMezzanine()
        {
            Logger.FileLogger("Getting Mezzanine...");
            Mezzanine mezzanine = new Mezzanine();
            mezzanine.OpportunityId = _sysGuid;
            mezzanine.UniqueChildDocumentsId = _noDocument.UniversalID;
            mezzanine.Ref = GetDocumentText(_noDocument, "$REF");
            mezzanine.SeniorDealPosition = GetDocumentText(_noDocument, "Progress_deal_1");
            mezzanine.MarketRole = GetDocumentText(_noDocument, "role_1");
            mezzanine.SFRole = GetDocumentText(_noDocument, "SF_Role_1");
            mezzanine.TotalDebtSize = GetDocumentText(_noDocument, "Total_debt_size_1");
            mezzanine.DealProbability = GetDocumentText(_noDocument, "DealProb_1");
            mezzanine.ExtCompletionDate = GetDocumentText(_noDocument, "DateEstCompletion_1");
            mezzanine.ActualCompletionDate = GetDocumentText(_noDocument, "DateCompletion_1");
            mezzanine.ReasonLost = GetDocumentText(_noDocument, "Reason_Lossed_1");
            mezzanine.LostTo = GetDocumentText(_noDocument, "Loss_to_1");
            mezzanine.DetailedReasonLost = GetDocumentText(_noDocument, "Reason_Lost_Detail_1");
            mezzanine.Competitor = GetDocumentText(_noDocument, "Lost_comp_1");
            Logger.FileLogger("Got Mezzanine...");
            return mezzanine;
        }

        private List<SeniorFacility> GetSeniorFacilityList()
        {
            Logger.FileLogger("Getting SeniorFacility...");
            List<SeniorFacility> SeniorFacilityList = new List<SeniorFacility>();

            for (int i = 1; i <= 10; i++)
            {
                string Line = GetDocumentText(_noDocument, "ln" + i);
                string FacilityType = GetDocumentText(_noDocument, "fc" + i);
                string ProductOwnerCode = GetDocumentText(_noDocument, "po" + i);
                string Term = GetDocumentText(_noDocument, "t" + i);
                string Currency = GetDocumentText(_noDocument, "cy" + i);
                string Day1GrossCommit = GetDocumentText(_noDocument, "u" + i);
                string LMCurrentPosition = GetDocumentText(_noDocument, "cc" + i);
                string ExpectedFinalHold = GetDocumentText(_noDocument, "h" + i);
                string Day1Utilisation = GetDocumentText(_noDocument, "du" + i);
                string Month1Utilisation = GetDocumentText(_noDocument, "m" + (i + 20));
                string Month3Utilisation = GetDocumentText(_noDocument, "m" + (i + 30));
                string Margin = GetDocumentText(_noDocument, "m" + i);
                string GrossFee = GetDocumentText(_noDocument, "g" + i);
                string NetFee = GetDocumentText(_noDocument, "n" + i);
                string RecurringFeeType = GetDocumentText(_noDocument, "nr" + i);
                string RecurringFee = GetDocumentText(_noDocument, "o" + i);
                string CommitmentFee = GetDocumentText(_noDocument, "p" + i);
                string CommitedUncommited = GetDocumentText(_noDocument, "co" + i);
                string ProbabilityOfDefault = GetDocumentText(_noDocument, "pd" + i);
                string LossGivenDefault = GetDocumentText(_noDocument, "lg" + i);
                string SanctionedGrossCommit = GetDocumentText(_noDocument, "cu" + i);
                string SanctionedHold = GetDocumentText(_noDocument, "ch" + i);
                string PRisMFacilityID = GetDocumentText(_noDocument, "prismID" + i);
                string Securitisation = GetDocumentText(_noDocument, "secu" + i);

                if (string.IsNullOrEmpty(Line) && string.IsNullOrEmpty(FacilityType) && string.IsNullOrEmpty(ProductOwnerCode) &&
                    string.IsNullOrEmpty(Term) && string.IsNullOrEmpty(Currency) && string.IsNullOrEmpty(Day1GrossCommit) &&
                    string.IsNullOrEmpty(LMCurrentPosition) && string.IsNullOrEmpty(ExpectedFinalHold) && string.IsNullOrEmpty(Day1Utilisation) &&
                    string.IsNullOrEmpty(Month1Utilisation) && string.IsNullOrEmpty(Month3Utilisation) && string.IsNullOrEmpty(Margin) &&
                    string.IsNullOrEmpty(GrossFee) && string.IsNullOrEmpty(NetFee) && string.IsNullOrEmpty(RecurringFeeType) && string.IsNullOrEmpty(RecurringFee) &&
                    string.IsNullOrEmpty(CommitmentFee) && string.IsNullOrEmpty(CommitedUncommited) && string.IsNullOrEmpty(ProbabilityOfDefault) &&
                    string.IsNullOrEmpty(LossGivenDefault) && string.IsNullOrEmpty(SanctionedGrossCommit) && string.IsNullOrEmpty(SanctionedHold) &&
                    string.IsNullOrEmpty(PRisMFacilityID) && string.IsNullOrEmpty(Securitisation))
                    continue;

                SeniorFacility seniorFacility = new SeniorFacility()
                {
                    Ref = GetDocumentText(_noDocument, "$REF"),
                    UniqueChildDocumentsId = _noDocument.UniversalID,
                    CommitedUncommited = CommitedUncommited,
                    CommitmentFee = CommitmentFee,
                    Currency = Currency,
                    Day1GrossCommit = Day1GrossCommit,
                    Day1Utilisation = Day1Utilisation,
                    ExpectedFinalHold = ExpectedFinalHold,
                    FacilityType = FacilityType,
                    GrossFee = GrossFee,
                    Line = Line,
                    LMCurrentPosition = LMCurrentPosition,
                    LossGivenDefault = LossGivenDefault,
                    Margin = Margin,
                    Month1Utilisation = Month1Utilisation,
                    Month3Utilisation = Month3Utilisation,
                    NetFee = NetFee,
                    OpportunityId = _sysGuid,
                    PRisMFacilityID = PRisMFacilityID,
                    ProbabilityOfDefault = ProbabilityOfDefault,
                    ProductOwnerCode = ProductOwnerCode,
                    RecurringFee = RecurringFee,
                    RecurringFeeType = RecurringFeeType,
                    SanctionedGrossCommit = SanctionedGrossCommit,
                    SanctionedHold = SanctionedHold,
                    Securitisation = Securitisation,
                    Term = Term
                };

                SeniorFacilityList.Add(seniorFacility);
            }
            Logger.FileLogger("Got SeniorFacility...");
            return SeniorFacilityList;
        }

        private Senior GetSenior()
        {
            Logger.FileLogger("Getting Senior...");
            Senior Senior = new Senior();
            Senior.OpportunityId = _sysGuid;
            Senior.UniqueChildDocumentsId = _noDocument.UniversalID;
            Senior.Ref = GetDocumentText(_noDocument, "$REF");
            Senior.SeniorDealPosition = GetDocumentText(_noDocument, "Progress_deal");
            Senior.MarketRole = GetDocumentText(_noDocument, "role");
            Senior.SFRole = GetDocumentText(_noDocument, "SF_Role");
            Senior.Total_debt_size = GetDocumentText(_noDocument, "Total_debt_size");
            Senior.DealProb = GetDocumentText(_noDocument, "DealProb");
            Senior.DateEstCompletion = GetDocumentText(_noDocument, "DateEstCompletion");
            Senior.DateCompletion = GetDocumentText(_noDocument, "DateCompletion");
            Senior.ReasonLost = GetDocumentText(_noDocument, "Reason_Lossed");
            Senior.LostTo = GetDocumentText(_noDocument, "Loss_to");
            Senior.DetailedReasonLost = GetDocumentText(_noDocument, "Reason_Lost_Detail");
            Senior.SFRole = GetDocumentText(_noDocument, "SF_Role");
            Senior.Competitor = GetDocumentText(_noDocument, "Lost_comp");
            Logger.FileLogger("Got Senior...");
            return Senior;
        }

        private List<OtherRBSStaff> GetOtherRBSStaffList()
        {
            Logger.FileLogger("Getting OtherRBSStaff...");
            List<OtherRBSStaff> otherStaffList = new List<OtherRBSStaff>();

            string ExSF1 = GetDocumentText(_noDocument, "ExSF");
            string Div1 = GetDocumentText(_noDocument, "Div");
            string DateAware1 = GetDocumentText(_noDocument, "DateAware");
            string ExSFReasone1 = GetDocumentText(_noDocument, "ExSFReason");
            if (string.IsNullOrEmpty(ExSF1) && string.IsNullOrEmpty(Div1) && string.IsNullOrEmpty(DateAware1) && string.IsNullOrEmpty(ExSFReasone1))
            {
                Logger.FileLogger("Other staff 1 is empty...");
            }
            else
            {
                OtherRBSStaff objOtherRBSStaff = new OtherRBSStaff();
                objOtherRBSStaff.OpportunityId = _sysGuid;
                objOtherRBSStaff.UniqueChildDocumentsId = _noDocument.UniversalID;
                objOtherRBSStaff.Ref = GetDocumentText(_noDocument, "$REF");
                objOtherRBSStaff.ExSF = ExSF1;
                objOtherRBSStaff.Div = Div1;
                objOtherRBSStaff.DateAware = DateAware1;
                objOtherRBSStaff.ExSFReasone = ExSFReasone1;

                otherStaffList.Add(objOtherRBSStaff);
            }


            for (int i = 1; i < 19; i++)
            {

                OtherRBSStaff otherRBSStaff = new OtherRBSStaff();

                string ExSF = GetDocumentText(_noDocument, "ExSF_" + i);
                string Div = GetDocumentText(_noDocument, "Div_" + i);
                string DateAware = GetDocumentText(_noDocument, "DateAware_" + i);
                string ExSFReasone = GetDocumentText(_noDocument, "ExSFReason_" + i);

                if (string.IsNullOrEmpty(ExSF) && string.IsNullOrEmpty(DateAware) && string.IsNullOrEmpty(Div)
                    && string.IsNullOrEmpty(ExSFReasone))
                    continue;

                otherRBSStaff.OpportunityId = _sysGuid;
                otherRBSStaff.UniqueChildDocumentsId = _noDocument.UniversalID;
                otherRBSStaff.Ref = GetDocumentText(_noDocument,"$REF");
                otherRBSStaff.ExSF = ExSF;
                otherRBSStaff.Div = Div;
                otherRBSStaff.DateAware = DateAware;
                otherRBSStaff.ExSFReasone = ExSFReasone;

                otherStaffList.Add(otherRBSStaff);
            }
            Logger.FileLogger("Got OtherRBSStaff...");
            return otherStaffList;
        }

        private List<DealTeam> GetDealTeam()
        {
            Logger.FileLogger("Getting DealTeam...");
            List<DealTeam> dealTeamList = new List<DealTeam>();
            string Staff1 = GetDocumentText(_noDocument, "Staff1");
            string Team1 = GetDocumentText(_noDocument, "Team1");
            string Aware1 = GetDocumentText(_noDocument, "Aware");
            string StaffRole1 = GetDocumentText(_noDocument, "Staff_role");

            if (string.IsNullOrEmpty(Staff1) && string.IsNullOrEmpty(Team1) && string.IsNullOrEmpty(Aware1) && string.IsNullOrEmpty(StaffRole1))
            {
                Logger.FileLogger("DealTeam 1 empty..");
            }
            else
            {
                DealTeam objDealTeam = new DealTeam()
                {
                    OpportunityId = _sysGuid,
                    UniqueChildDocumentsId = _noDocument.UniversalID,
                    Ref = GetDocumentText(_noDocument, "$REF"),
                    Aware = Aware1,
                    Staff = Staff1,
                    StaffRole = StaffRole1,
                    Team = Team1
                };
                dealTeamList.Add(objDealTeam);
            }

            string Staff2 = GetDocumentText(_noDocument, "Staff2");
            string Team2 = GetDocumentText(_noDocument, "Team_1");
            string Aware2 = GetDocumentText(_noDocument, "Aware_1");
            string StaffRole2 = GetDocumentText(_noDocument, "Staff_role_1");

            if (string.IsNullOrEmpty(Staff2) && string.IsNullOrEmpty(Team2) && string.IsNullOrEmpty(Aware2) && string.IsNullOrEmpty(StaffRole2))
            {
                Logger.FileLogger("DealTeam 2 empty..");
            }
            else
            {
                DealTeam objDealTeam1 = new DealTeam()
                {
                    OpportunityId = _sysGuid,
                    UniqueChildDocumentsId = _noDocument.UniversalID,
                    Ref = GetDocumentText(_noDocument, "$REF"),
                    Aware = Aware2,
                    Staff = Staff2,
                    StaffRole = StaffRole2,
                    Team = Team2
                };
                dealTeamList.Add(objDealTeam1);
            }


            for (int i = 2; i <= 24; i++)
            {
                DealTeam dealTeam = new DealTeam();
                string Staff = GetDocumentText(_noDocument, "Staff_Id_" + i);
                string Team = GetDocumentText(_noDocument, "Team_" + i);
                string Aware = GetDocumentText(_noDocument, "Aware_" + i);
                string StaffRole = GetDocumentText(_noDocument, "Staff_role_" + i);

                if (string.IsNullOrEmpty(Staff) && string.IsNullOrEmpty(Team) && string.IsNullOrEmpty(Aware) && string.IsNullOrEmpty(StaffRole))
                    continue;

                dealTeam.OpportunityId = _sysGuid;
                dealTeam.UniqueChildDocumentsId = _noDocument.UniversalID;
                dealTeam.Ref = GetDocumentText(_noDocument, "$REF");
                dealTeam.Staff = Staff;
                dealTeam.Team = Team;
                dealTeam.Aware = Aware;
                dealTeam.StaffRole = StaffRole;

                dealTeamList.Add(dealTeam);
            }
            Logger.FileLogger("Got DealTeam...");
            return dealTeamList;
        }

        private Deal GetDeal()
        {
            Logger.FileLogger("Getting Deal...");
            Deal objDeal = new Deal();

            objDeal.OpportunityId = _sysGuid;
            objDeal.UniqueChildDocumentsId = _noDocument.UniversalID;
            objDeal.Ref = GetDocumentText(_noDocument, "$REF");

            objDeal.Deal_Type = GetDocumentText(_noDocument, "Deal_Type");
            objDeal.Target_Company = GetDocumentText(_noDocument, "Target_Company");
            objDeal.DealVendor = GetDocumentText(_noDocument, "DealVendor");
            objDeal.Source = GetDocumentText(_noDocument, "Source");
            objDeal.Introducer_Name = GetDocumentText(_noDocument, "Introducer_Name");
            objDeal.Int_Corp = GetDocumentText(_noDocument, "Int_Corp");
            objDeal.Int_SF = GetDocumentText(_noDocument, "Int_SF");
            objDeal.Gov = GetDocumentText(_noDocument, "Gov");
            objDeal.PropCoResidentialDeal = GetDocumentText(_noDocument, "Resi");
            objDeal.NRDateBoard = GetDocumentText(_noDocument, "NRDateBoard");
            objDeal.DebtType = GetDocumentText(_noDocument, "DebtType");
            objDeal.WIPDealAmount = GetDocumentText(_noDocument, "WIPDealAmount");
            objDeal.Deal_Currency = GetDocumentText(_noDocument, "Deal_Currency");
            Logger.FileLogger("Got all Deal...");
            return objDeal;
        }

        private Opportunity GetOpportunity()
        {
            Logger.FileLogger("Getting Opportunity...");
            Opportunity objOpportunity = new Opportunity();

            objOpportunity.Id = _sysGuid;
            objOpportunity.UniqueChildDocumentsId = _noDocument.UniversalID;
            objOpportunity.Ref = GetDocumentText(_noDocument, "$REF");
            objOpportunity.CompanyName = GetDocumentText(_noDocument, "CompanyName");
            objOpportunity.CISCode = GetDocumentText(_noDocument, "CodeCIS");
            objOpportunity.PriceSensitive = GetDocumentText(_noDocument, "Team_Price_Sensitive");
            objOpportunity.ProjectName = GetDocumentText(_noDocument, "ProjectName");
            objOpportunity.Description = GetDocumentText(_noDocument, "DealBrief");
            objOpportunity.DealComments = GetDocumentText(_noDocument, "DealComments");
            Logger.FileLogger("Got all Opportunity...");

            return objOpportunity;
        }
    }
}
