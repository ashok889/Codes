﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class DealDocumentsForm : DocumentProperties, IFormOpration
    {

        public FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            try
            {
                FormModel formModelObj = new FormModel();

                string form = GetDocumentText(noDocument, "Form");

                formModelObj.UniqueChildDocumentsId = noDocument.UniversalID;
                formModelObj.SystemGUID = sysGuid;
                formModelObj.Form = form;
                formModelObj.Ref = GetDocumentText(noDocument, "$REF");
                formModelObj.UpdatedBy = GetDocumentText(noDocument, "$UpdatedBy");
                formModelObj.ARRReport = GetDocumentText(noDocument, "ARRReport");
                formModelObj.BoardMinutes = GetDocumentText(noDocument, "BoardMinutes");
                formModelObj.BoardSubmission = GetDocumentText(noDocument, "BoardSub");
                formModelObj.CompanyName = GetDocumentText(noDocument, "COMPANYNAME");
                formModelObj.CompletionChecklist = GetDocumentText(noDocument, "CompChklist");
                formModelObj.ConfidentialityAgreement = GetDocumentText(noDocument, "ConfidentialityAgreement");
                formModelObj.CreditRecommendations = GetDocumentText(noDocument, "Creditcomm");
                formModelObj.CreditMinutes = GetDocumentText(noDocument, "CreditMinutes");
                formModelObj.SubmissionAndReviewPaper = GetDocumentText(noDocument, "CreditPaper");
                formModelObj.DueDeligenceReports = GetDocumentText(noDocument, "ddreports");
                formModelObj.NumberOfDocuments = GetDocumentText(noDocument, "Docs");
                formModelObj.DueDiligence = GetDocumentText(noDocument, "DueDiligence");
                formModelObj.FacilityAgreement = GetDocumentText(noDocument, "FacilityAgreement");
                formModelObj.FinalDocs = GetDocumentText(noDocument, "FinalDocs");
                formModelObj.HeadsOfTerms = GetDocumentText(noDocument, "HeadsOfTerms");
                formModelObj.InfoMemo = GetDocumentText(noDocument, "InfoMemo");
                formModelObj.KYC_Review = GetDocumentText(noDocument, "KYC_Review");
                formModelObj.LawyerInstruction = GetDocumentText(noDocument, "LawyerInstruction");
                formModelObj.LoanMarketsdocs = GetDocumentText(noDocument, "lmdocs");
                formModelObj.KYC_Misc_Docs = GetDocumentText(noDocument, "misc_kyc");
                formModelObj.Model = GetDocumentText(noDocument, "Model");
                formModelObj.MonitoringInstruction = GetDocumentText(noDocument, "MonitoringInstruction");
                formModelObj.OnePager = GetDocumentText(noDocument, "OnePager");
                formModelObj.KYC_Org_Chart = GetDocumentText(noDocument, "Org_Chart");
                formModelObj.Portfolio_cashflow = GetDocumentText(noDocument, "Port_cashflow");
                formModelObj.Portfolio_handover_checklist = GetDocumentText(noDocument, "Port_hand");
                formModelObj.Portfolio_hedging = GetDocumentText(noDocument, "Port_hedg");
                formModelObj.Portfolio_management_Info = GetDocumentText(noDocument, "Port_man");
                formModelObj.Portfolio_Financial_Covenant_Monitoring = GetDocumentText(noDocument, "Port_mon");
                formModelObj.Portfolio_other = GetDocumentText(noDocument, "Port_oth");
                formModelObj.PostCompletionMemo = GetDocumentText(noDocument, "PostCompletionMemo");
                formModelObj.PreCompletionMemo = GetDocumentText(noDocument, "PreCompletionMemo");
                formModelObj.Progress = GetDocumentText(noDocument, "Progress");
                formModelObj.TransferCertificates = GetDocumentText(noDocument, "transfer");
                formModelObj.ValuerInstruction = GetDocumentText(noDocument, "ValuerInstruction");
                formModelObj.Form = form;

                // Attachment list
                DownloadDocumentFiles(noDocument, sysGuid, form);

                return formModelObj;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching DealDocument Form data from lotus notes. Error message : "+ ex.Message, "ERROR");
                throw;
            }
            
        }
    }
}
