﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public interface IFormOpration
    {
        FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid);
    }
}
