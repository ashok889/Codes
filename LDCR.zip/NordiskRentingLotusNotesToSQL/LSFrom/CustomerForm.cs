﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class CustomerForm : DocumentProperties, IFormOpration
    {

        public FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            try
            {
                FormModel formModelObj = new FormModel();

                string form = GetDocumentText(noDocument, "Form");

                formModelObj.UniqueChildDocumentsId = noDocument.UniversalID;
                formModelObj.SystemGUID = sysGuid;
                formModelObj.Form = form;
                formModelObj.Ref = GetDocumentText(noDocument, "$REF");
                formModelObj.UpdatedBy = GetDocumentText(noDocument, "$UpdatedBy");
                formModelObj.AccountManager = GetDocumentText(noDocument, "AccountManager");
                formModelObj.Body = GetDocumentText(noDocument, "BODY");
                formModelObj.CompanyName = GetDocumentText(noDocument, "COMPANYNAME");
                formModelObj.CompanyAddress = GetDocumentText(noDocument, "CompanyAddress");
                formModelObj.CompanyAddress2 = GetDocumentText(noDocument, "CompanyAddress2");
                formModelObj.CompanyCity = GetDocumentText(noDocument, "CompanyCity");
                formModelObj.CompanyFAX = GetDocumentText(noDocument, "CompanyFAX");
                formModelObj.CompanyPhone = GetDocumentText(noDocument, "CompanyPhone");
                formModelObj.CompanyState = GetDocumentText(noDocument, "CompanyState");
                formModelObj.CompanyZIP = GetDocumentText(noDocument, "CompanyZIP");
                formModelObj.ComposeDate = GetDocumentText(noDocument, "ComposeDate");
                formModelObj.Country = GetDocumentText(noDocument, "Country");
                formModelObj.Status = GetDocumentText(noDocument, "STATUS");
                formModelObj.Form = form;

               // Attachment list
                DownloadDocumentFiles(noDocument, sysGuid, form);

                return formModelObj;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching Customer Form data from lotus notes. Error message : "+ ex.Message, "ERROR");
                throw;
            }
        }
    }
}
