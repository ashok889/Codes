﻿using Domino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public class EmailForm : DocumentProperties, IFormOpration
    {

        public FormModel GetLotusNotesValue(NotesDocument noDocument, string sysGuid)
        {
            try
            {
                FormModel formModelObj = new FormModel();

                string form = GetDocumentText(noDocument, "Form");

                formModelObj.UniqueChildDocumentsId = noDocument.UniversalID;
                formModelObj.SystemGUID = sysGuid;
                formModelObj.Form = form;
                formModelObj.Ref = GetDocumentText(noDocument, "$REF");
                formModelObj.UpdatedBy = GetDocumentText(noDocument, "$UpdatedBy");
                formModelObj.ActivityDate = GetDocumentText(noDocument, "ActivityDate");
                formModelObj.Attendees = GetDocumentText(noDocument, "ATTENDEES");
                formModelObj.Body = GetDocumentText(noDocument, "BODY");
                formModelObj.CompanyName = GetDocumentText(noDocument, "COMPANYNAME");
                formModelObj.ComposeDate = GetDocumentText(noDocument, "ComposeDate");
                formModelObj.ContactName = GetDocumentText(noDocument, "ContactName");
                formModelObj.CorrespondenceDate = GetDocumentText(noDocument, "CorrDate");
                formModelObj.CorrespondenceType = GetDocumentText(noDocument, "CorrType");
                formModelObj.DocAuthor = GetDocumentText(noDocument, "DocAuthor");
                formModelObj.MeetingDate = GetDocumentText(noDocument, "MeetingDate");
                formModelObj.RecipientName = GetDocumentText(noDocument, "RecipientName");
                formModelObj.SenderName = GetDocumentText(noDocument, "SenderName");
                formModelObj.Subject = GetDocumentText(noDocument, "Subject");
                formModelObj.Form = form;

               // Attachment list
               DownloadDocumentFiles(noDocument, sysGuid, form);

                return formModelObj;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching Email Form data from lotus notes. Error message : "+ ex.Message, "ERROR");
                throw;
            }
            
        }
    }
}