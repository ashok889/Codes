﻿using Domino;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.LSFrom
{
    public abstract class DocumentProperties
    {
        string attachementLocation = ConfigurationManager.AppSettings["formAttachmentDirPath"];

        /// <summary>
        /// Get the Document FILE
        /// $FILE etc
        /// </summary>
        /// <param name="noDocument">NotesDocument</param>
        /// <returns></returns>
        public bool DownloadDocumentFiles(NotesDocument noDocument, string sysGuid, string formName)
        {
            var allDocItems = noDocument.Items;
            try
            {
                foreach (NotesItem ditem in allDocItems)
                {
                    if (ditem.Name == "$FILE")
                    {
                        var fileName = ditem.Values[0]; // It will contain the File name
                        if (String.IsNullOrEmpty(fileName))
                            continue;
                        NotesEmbeddedObject attachment = noDocument.GetAttachment(fileName);
                        if (attachment != null)
                        {
                            //List<AttachmentModel> attachmentList = new List<AttachmentModel>();
                            string attachmentDir = attachementLocation + formName + @"\" + sysGuid + @"\";
                            // Create directory with GUID
                            if (Directory.Exists(attachmentDir) == false)
                                Directory.CreateDirectory(attachmentDir);

                            Logger.FileLogger("Attachment directory Path : " + attachmentDir);

                            Logger.FileLogger("Start downloading the file name : "+ fileName);
                            //AttachmentModel attachmentModel = new AttachmentModel();
                            // Rename file name if already exist
                            if(File.Exists(attachmentDir + @"\" + fileName))
                            {
                                Logger.FileLogger("File already exist : "+ attachmentDir + @"\" + fileName);
                                Random rand = new Random();
                                File.Move(attachmentDir + @"\" + fileName, Path.GetFileNameWithoutExtension(fileName) + "_" + rand.Next(1,9999) + Path.GetExtension(fileName));
                                Logger.FileLogger("Old file name changed into : " + Path.GetFileNameWithoutExtension(fileName) + "_" + rand.Next(1, 9999) + Path.GetExtension(fileName));
                            }
                            //*** Download the attachement   
                            attachment.ExtractFile(attachmentDir + @"\" + fileName);
                            Logger.FileLogger("File name '" + fileName + "' has been downloaded.");                            
                        }
                    }
                }
                //return attachmentList;
                return true;
            }
            catch (Exception)
            {
                Logger.FileLogger("Error while fetching $FILE. GetDocumentFiles()", "ERROR");
                throw;
            }
            
        }
        /// <summary>
        /// Get value from TEXT
        /// COMPANYNAME
        /// </summary>
        /// <param name="noDocument"></param>
        /// <param name="documentPropertyName"></param>
        /// <returns></returns>
        public string GetDocumentText(NotesDocument noDocument, string documentPropertyName)
        {
            try
            {
                NotesItem noteItemsObj = noDocument.GetFirstItem(documentPropertyName);

                if (noteItemsObj == null)
                    return string.Empty;

                return noteItemsObj.Text;
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Error while fetching docuement property '" + documentPropertyName + "' in GetDocumentText(). Error detail : " + ex.Message, "ERROR");
                throw;
            }            
        }
    }
}
