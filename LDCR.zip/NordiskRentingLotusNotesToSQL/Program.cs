﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domino;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;
using System.IO;
using NordiskRentingLotusNotesToSQL;
using NordiskRentingLotusNotesToSQL.LSFrom;
using NordiskRentingLotusNotesToSQL.DAL;
using System.Configuration;

namespace LotusNotes
{
    class Program
    {
        static NotesSession session; // Notes Session Object  
        static NotesDatabase noDatabase;
        static NotesView noView;
        static DataTable dealteamtable = new DataTable();

        //const string attachementLocation = @"H:\Repositories\LotusNotesToSQL\Resources\Attachments\";

        const string warning = "WARNING";
        const string errors = "ERROR";
        string newFormFilePath = ConfigurationManager.AppSettings["newFormFilePath"];
        Int32 documentCount = 0;

        // All form list 
        List<string> allFormList = new List<string>()
        {
            "Call",
            "Checklist",
            "Contact",
            "CreditMemo",
            "Customer",
            "Deal Documents",
            "ExProf",
            "Incoming",
            "Meeting",
            "Misc",
            "Outgoing",
            "Response"
        };


        // Company list that we don't need to fetch the data
        List<string> ignoredCompanyList = new List<string>() {
            "0. Business Administration & Templates",
            "1. General Research",
            "1. Polices",
            "2. EGi / Press Cuttings",
            "3. Economic Information",
            "4. Legal Information",
            "5. Maps",
            "6. General Property Sector Information",
            "7. General Banking Market Information",
            "8. Miscellaneous Useful People",
            "9. Miscellaneous"
        };

        List<FormModel> formModelList = new List<FormModel>();
        List<CheckListModel> checkListModelList = new List<CheckListModel>();

        static void Main(string[] args)
        {

            #region Insert form attachements

            InsertAttachmentInSQL objInsertAttachmentInSQL = new InsertAttachmentInSQL();
            objInsertAttachmentInSQL.GetAttachement("Call", "LotusNotesCallAttachments", "LotusNotesCallId");
            objInsertAttachmentInSQL.GetAttachement("CreditMemo", "LotusNotesCreditMemoAttachments", "LotusNotesCreditMemoId");
            objInsertAttachmentInSQL.GetAttachement("Deal Documents", "LotusNotesDealDocumentsAttachments", "LotusNotesDealDocumentsId");
            objInsertAttachmentInSQL.GetAttachement("Incoming", "LotusNotesEmailAttachments", "LotusNotesEmailId");
            objInsertAttachmentInSQL.GetAttachement("Meeting", "LotusNotesEmailAttachments", "LotusNotesEmailId");
            objInsertAttachmentInSQL.GetAttachement("Misc", "LotusNotesEmailAttachments", "LotusNotesEmailId");
            objInsertAttachmentInSQL.GetAttachement("Outgoing", "LotusNotesEmailAttachments", "LotusNotesEmailId");
            objInsertAttachmentInSQL.GetAttachement("Response", "LotusNotesEmailAttachments", "LotusNotesEmailId");

            objInsertAttachmentInSQL.GetAttachement("Checklist", "ChecklistAttachments", "ChecklistOpportunityId");

            Console.WriteLine("Attachements has been saved into the database.");
            Console.ReadLine();


            #endregion


            try
            {
                Logger.FileLogger("Establishing connection with the database..");
                EstablishConnectionWithLotusNotesDB("***", @"Stubbs/Server/Domino", @"refg\nordisk renting.nsf");
                Logger.FileLogger("Connection established successfully with the database");


                Dictionary<string, string> formTypesDictionary = new Dictionary<string, string>();
                //formTypesDictionary.Add("Call", "Call");
                //formTypesDictionary.Add("Contact", "Contact");
                //formTypesDictionary.Add("CreditMemo", "CreditMemo");
                //formTypesDictionary.Add("Customer", "Customer");
                //formTypesDictionary.Add("Deal Documents", "Deal Documents");
                //formTypesDictionary.Add("Incoming", "Email");
                //formTypesDictionary.Add("Meeting", "Email");
                //formTypesDictionary.Add("Misc", "Email");
                //formTypesDictionary.Add("Outgoing", "Email");
                //formTypesDictionary.Add("Response", "Email");

                //formTypesDictionary.Add("Checklist", "Checklist");

                Program obj = new Program();
                //obj.GetLotusNotesValuesByFormName(@"All \ 1. Activities by Client - Deal", formTypesDictionary);
                //obj.SQLBulkInsertion();

                Console.WriteLine("Please press enter to exit...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Logger.FileLogger("Exception occured. Error : " + ex.Message, errors);
                Console.ReadLine();
            }
        }

        public void SQLBulkInsertion()
        {
            BulkInsertion objBulkInsertion = new BulkInsertion(formModelList, checkListModelList);
            objBulkInsertion.CallFormSQLOprations();
            objBulkInsertion.ContactSQLOprations();
            objBulkInsertion.CreditMemoSQLOprations();
            objBulkInsertion.CustomerSQLOprations();
            objBulkInsertion.DealDocumentSQLOprations();
            objBulkInsertion.EmailSQLOprations();
            objBulkInsertion.ChecklistSQLOprations();
        }



        /// <summary>
        /// Get Lotus Notes docuement property
        /// </summary>
        /// <param name="viewName">View Name</param>
        /// <param name="formTypesDictionary">Form Type</param>
        public void GetLotusNotesValuesByFormName(string viewName, Dictionary<string, string> formTypesDictionary)
        {

            FormFactory factoryInstance = new FormFactory();
            Logger.FileLogger("Start downloading the documents of View name: " + viewName);
            // Create instance of the VIEW           
            noView = noDatabase.GetView(viewName);
            NotesDocument noDocument = noView.GetFirstDocument();
            try
            {
                var documentCountWithIgnorCountry = 0;
                var validDocumentCount = 0;

                // Iterate through all the documents in the view.
                while (noDocument != null)
                {
                    documentCount++;

                    Logger.FileLogger("----------------------------");
                    Logger.FileLogger("Document Number : " + documentCount);
                    Logger.FileLogger("----------------------------");

                    #region DATA RULE 1 - If companyname mactch with the vvalue in the list then no need to fetch the data

                    Logger.FileLogger("Fetching Company Name.");

                    NotesItem companyName = noDocument.GetFirstItem("COMPANYNAME");
                    if (companyName != null)
                    {
                        string company = companyName.Text;
                        if (ignoredCompanyList.Contains(company))
                        {
                            Logger.FileLogger("IGNORED COMPANY '" + company + "' found.");
                            documentCountWithIgnorCountry++;
                            // Get next document in the view
                            noDocument = noView.GetNextDocument(noDocument);
                            continue;
                        }
                    }
                    Logger.FileLogger("Company Name is valid.");

                    #endregion

                    #region Get FORM docuement property value

                    NotesItem formValues = noDocument.GetFirstItem("FORM");
                    string formName = string.Empty;
                    if (formValues != null)
                    {
                        formName = formValues.Text;
                        Logger.FileLogger(string.Format("FORM = " + formName));
                        validDocumentCount++;
                    }

                    #endregion

                    #region Intiate instance against to the Form name 

                    if (formTypesDictionary.ContainsKey(formName))
                    {
                        Logger.FileLogger("Start fetching valued from Lotus Noted for Form name: " + formName);
                        if (formName == "Checklist")
                        {
                            CheckListForm objCheckList = new CheckListForm();
                            var checList = objCheckList.GetLotusNotesValue(noDocument, Guid.NewGuid().ToString());
                            checkListModelList.Add(checList);
                        }
                        else
                        {
                            IFormOpration instance = factoryInstance.CreateInstanace(formName);
                            if (instance != null)
                            {
                                var form = instance.GetLotusNotesValue(noDocument, Guid.NewGuid().ToString());
                                form.Count = documentCount;
                                formModelList.Add(form);
                            }
                        }

                        Logger.FileLogger("Value successfully fetch from Lotus Notes for Form name: " + formName);
                    }
                    else // check is any new Form name found in the view
                    {
                        if (!allFormList.Contains(formName))
                        {
                            StreamWriter writeFile = new StreamWriter(newFormFilePath, true);
                            Logger.FileLogger("[NOTE] New FORM found with name: " + formName);
                            var allDocItems = noDocument.Items;
                            foreach (NotesItem ditem in allDocItems)
                            {
                                writeFile.WriteLine("       " + ditem.Name);
                            }
                            writeFile.WriteLine(formName);
                            writeFile.Close();
                        }
                    }

                    #endregion

                    // Get next document in the view
                    noDocument = noView.GetNextDocument(noDocument);
                }
                Logger.FileLogger("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Logger.FileLogger("Total ignored country documents counts = " + documentCountWithIgnorCountry);
                Logger.FileLogger("Total valid documents counts = " + validDocumentCount);
                Logger.FileLogger("Total documents counts = " + documentCount);
                Logger.FileLogger("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This function is used to establish the connection with the Domino Lotus Notes server
        /// </summary>
        private static void EstablishConnectionWithLotusNotesDB(string password, string pServer, string pFile)
        {
            session = new NotesSession();
            session.Initialize(password); // Notes Password for your Notes Id  
            noDatabase = session.GetDatabase(pServer, pFile, false);
        }



        //public static void DownloadViewAttacments(string viewName)
        //{
        //    FileLogger("Start downloading the documents of View name: " + viewName);
        //    // Create instance of the VIEW           
        //    noView = noDatabase.GetView(viewName);
        //    try
        //    {

        //        // 'Get the first document in the defined view.
        //        noDocument = noView.GetFirstDocument();
        //        int documentCount = 1;


        //        // Iterate through all the e-mails in the view.
        //        while (noDocument != null)
        //        {
        //            FileLogger("Document No. ", documentCount.ToString());

        //            int attachementCount = 0;

        //            #region Docuement property

        //            NotesItem refNumberValues = noDocument.GetFirstItem("$REF");

        //            string refNumber = string.Empty;
        //            if (refNumberValues != null)
        //            {
        //                refNumber = refNumberValues.Values(0).ToString();
        //                //FileLogger(string.Format("Item name - {0}. REF Value - {1}", "$REF", refNumber));
        //                Console.WriteLine(string.Format("Item name - {0}. REF Value - {1}", "$REF", refNumber));
        //                if (Directory.Exists(attachementLocation + refNumber + @"\") == false)
        //                    Directory.CreateDirectory(attachementLocation + refNumber + @"\");
        //            }

        //            foreach (NotesItem ditem in noDocument.Items)
        //            {

        //                if (ditem.Name == "$FILE")
        //                {
        //                    var vals = ditem.Values;
        //                    foreach (var docName in vals)
        //                    {
        //                        // FileLogger(string.Format("{2}. Item name {0}. Name - {1}", ditem.Name, docName, documentCount.ToString()));

        //                        NotesEmbeddedObject attachement = noDocument.GetAttachment(docName);
        //                        // attachement.ExtractFile(attachementLocation + refNumber + "\" + docName)
        //                        if (attachement != null)
        //                        {
        //                            totalSize = attachement.FileSize + totalSize;

        //                            //FileLogger(string.Format("{3}. Item name {0}. Name - {1}, Size - {2} bytes", ditem.Name, docName, attachement.FileSize.ToString(), documentCount.ToString()));
        //                        }
        //                        else
        //                            //FileLogger("File not found in lotus notes - " + docName);
        //                            Console.WriteLine("File not found in lotus notes - " + docName);
        //                    }
        //                    attachementCount = attachementCount + 1;
        //                }
        //            }

        //            #endregion


        //            // FileLogger("TOTAL ATACHEMENTS in this document  = " + attachementCount.ToString());
        //            //FileLogger("-----------------------------------------------------");
        //            documentCount = documentCount + 1;

        //            // Get next document in the view
        //            noNextDocument = noView.GetNextDocument(noDocument);
        //            noDocument = noNextDocument;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //FileLogger("Error message - " + ex.Message + ". Discription - " + ex.StackTrace.ToString(), errors);
        //    }
        //}





    }
}
