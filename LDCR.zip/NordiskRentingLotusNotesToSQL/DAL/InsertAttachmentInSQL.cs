﻿using NordiskRentingLotusNotesToSQL.LSFrom;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.DAL
{
    public class InsertAttachmentInSQL
    {
        string formAttachmentDirPath = ConfigurationManager.AppSettings["formAttachmentDirPath"];
        string _connectionString = ConfigurationManager.AppSettings["connectionString"];

        List<AttachmentModel> AttachmentModelList = new List<AttachmentModel>();

        public void GetAttachement(string formName, string tableName, string fk)
        {
            if (string.IsNullOrEmpty(formName) || string.IsNullOrEmpty(formName))
            {
                Logger.FileLogger("Form name and Table name should not NULL or empty");
                return;
            }
            int totalFiles = 0;
            Logger.FileLogger("Start inserting the Attachement of form name : " + formName + "In database table name : " + tableName);
            // Get GUID directories
            string[] subdirectoryEntries = Directory.GetDirectories(formAttachmentDirPath + formName);
            foreach (var subDirectory in subdirectoryEntries)
            {
                try
                {
                    string guid = Path.GetFileName(subDirectory);
                    Logger.FileLogger("GUID :" + guid);
                    // Get files from the subdirectories
                    var files = Directory.GetFiles(subDirectory);
                    foreach (var file in files)
                    {
                        Logger.FileLogger("File path : " + file);
                        AttachmentModel objAttachmentModel = new AttachmentModel();
                        objAttachmentModel.SysGuid = guid;
                        objAttachmentModel.FileName = Path.GetFileName(file);
                        objAttachmentModel.FilePath = file;
                        objAttachmentModel.FileExtention = Path.GetExtension(file);

                        byte[] fileByes;

                        using (var stream = new FileStream(file, FileMode.Open, FileAccess.Read))
                        {
                            using (var reader = new BinaryReader(stream))
                            {
                                fileByes = reader.ReadBytes((int)stream.Length);
                            }
                            stream.Close();
                        }
                        objAttachmentModel.FileData = fileByes;

                        totalFiles++;
                        if (InsertFiles(objAttachmentModel, tableName, fk))
                        {
                            System.IO.File.Move(file, Path.GetDirectoryName(file) + "/" + Path.GetFileNameWithoutExtension(file) + "_DONE" + Path.GetExtension(file));
                            Logger.FileLogger("File '" + file + "' has successfully inserted into database.");
                        }
                        else
                        {
                            System.IO.File.Move(file, Path.GetDirectoryName(file) + "/" + Path.GetFileNameWithoutExtension(file) + "_ERROR" + Path.GetExtension(file));
                            Logger.FileLogger("Somthing went wrong while inserting the file: '" + file + "' in the database", "Error");
                        }
                    }

                }
                catch (Exception ex)
                {
                    Logger.FileLogger("Error " + ex.Message, "ERROR");
                    throw;
                }
            }
            Logger.FileLogger("Total files : " + totalFiles);
        }

        /// <summary>
        /// Takes a list of files and inserts them into a table with a delegate
        /// which provides the caller information to see what's going on in real time.
        /// </summary>
        /// <param name="files">List of files including their path</param>
        /// <returns>Success or failure</returns>
        private bool InsertFiles(AttachmentModel objAttachmentModel, string tableName, string fk)
        {
            Logger.FileLogger("Start inserting the file in to the database table : " + objAttachmentModel.FilePath);
            using (var cn = new SqlConnection() { ConnectionString = _connectionString })
            {
                string statement = "INSERT INTO " + tableName + " (" + fk + ", AttachementName, AttachmentData, AttachmentExtension) VALUES (@" + fk + ",@AttachementName, @AttachmentData, @AttachmentExtension);";

                using (var cmd = new SqlCommand() { Connection = cn, CommandText = statement })
                {
                    cmd.Parameters.AddWithValue("@" + fk, objAttachmentModel.SysGuid);
                    cmd.Parameters.AddWithValue("@AttachementName", objAttachmentModel.FileName);
                    cmd.Parameters.Add("@AttachmentData", SqlDbType.VarBinary, objAttachmentModel.FileData.Length).Value = objAttachmentModel.FileData;
                    cmd.Parameters.AddWithValue("@AttachmentExtension", objAttachmentModel.FileExtention);

                    try
                    {
                        cn.Open();

                        Convert.ToInt32(cmd.ExecuteScalar());
                        cn.Close();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        cn.Close();
                        return false;
                    }
                }
            }
        }
    }

    //public bool InsertAttachementInSql()
    //    {
    //        try
    //        {
    //            #region Inserting data into LotusNotesCallAttachments table 

    //            var callAttachmentTable = new DataTable();
    //            callAttachmentTable.Columns.Add("LotusNotesCallId", typeof(string));
    //            callAttachmentTable.Columns.Add("AttachementName", typeof(string));
    //            callAttachmentTable.Columns.Add("AttachmentData", typeof(string));
    //            callAttachmentTable.Columns.Add("AttachmentExtension", typeof(Byte));

    //            foreach (var callList in callFormList)
    //            {
    //                if (callList.Attachements == null)
    //                    continue;
    //                foreach (var attachment in callList.Attachements)
    //                {
    //                    DataRow calAttachmentTblRow = callAttachmentTable.NewRow();
    //                    calAttachmentTblRow["LotusNotesCallId"] = string.IsNullOrEmpty(attachment.SysGuid) ? "" : attachment.SysGuid;
    //                    calAttachmentTblRow["AttachementName"] = string.IsNullOrEmpty(attachment.FileName) ? "" : attachment.FileName;
    //                    calAttachmentTblRow["AttachmentData"] = attachment.FileData;
    //                    calAttachmentTblRow["AttachmentExtension"] = string.IsNullOrEmpty(attachment.FileExtention) ? "" : attachment.FileExtention;

    //                    callAttachmentTable.Rows.Add(calAttachmentTblRow);
    //                }
    //            }

    //            return true;
    //            #endregion
    //        }
    //        catch (Exception)
    //        {
    //            throw;
    //        }
    //    }


    //}
}
