﻿using NordiskRentingLotusNotesToSQL.LSFrom;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.DAL
{
    public class BulkInsertion
    {
        List<FormModel> _formModelList = new List<FormModel>();
        List<CheckListModel> _checkModelList = new List<CheckListModel>();
        string _connectionString = ConfigurationManager.AppSettings["connectionString"]; //@"Data Source=lonms11691\dmlnfarm01;Initial Catalog=NordiskRenting_DEV1;User Id = dlmuser-dev; Password = DLmus01$34try";
        const int bulkInsertBatchSize = 1000;
        public BulkInsertion(List<FormModel> formModelList, List<CheckListModel> checkModelList)
        {
            _formModelList = formModelList;
            _checkModelList = checkModelList;
        }

        /// <summary>
        /// Insert Call form Lotus notes data into SQL
        /// </summary>
        /// <returns></returns>
        public bool CallFormSQLOprations()
        {
            // Get Call Form items from the _formModelList
            List<FormModel> callFormList = _formModelList.Where(x => x.Form.Equals("Call")).ToList();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        sqlBulkCopy.DestinationTableName = "LotusNotesCall";

                        var callTable = new DataTable();
                        callTable.Columns.Add("Id", typeof(string));
                        callTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        callTable.Columns.Add("Ref", typeof(string));
                        callTable.Columns.Add("Author", typeof(string));
                        callTable.Columns.Add("ComposeDate", typeof(DateTime));
                        callTable.Columns.Add("Initiator", typeof(string));
                        callTable.Columns.Add("CompanyName", typeof(string));
                        callTable.Columns.Add("OurRepName", typeof(string));
                        callTable.Columns.Add("CompanyRepName", typeof(string));
                        callTable.Columns.Add("CallDate", typeof(string));
                        callTable.Columns.Add("Subject", typeof(string));
                        callTable.Columns.Add("Body", typeof(string));
                        callTable.Columns.Add("WhomCalledWhom", typeof(string));
                        callTable.Columns.Add("UpdatedBy", typeof(string));
                        callTable.Columns.Add("From", typeof(string));


                        foreach (var item in callFormList)
                        {
                            DataRow calTblRow = callTable.NewRow();
                            calTblRow["Id"] = string.IsNullOrEmpty(item.SystemGUID) ? "" : item.SystemGUID;
                            calTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(item.UniqueChildDocumentsId) ? "" : item.UniqueChildDocumentsId;
                            calTblRow["Ref"] = string.IsNullOrEmpty(item.Ref) ? "" : item.Ref;
                            calTblRow["Author"] = string.IsNullOrEmpty(item.Author5) ? "" : item.Author5;

                            DateTime composeDate;
                            if (DateTime.TryParse(item.ComposeDate, out composeDate))
                                calTblRow["ComposeDate"] = composeDate;
                            else
                                calTblRow["ComposeDate"] = DBNull.Value;

                            calTblRow["Initiator"] = string.IsNullOrEmpty(item.Initiator) ? "" : item.Initiator;
                            calTblRow["CompanyName"] = string.IsNullOrEmpty(item.CompanyName) ? "" : item.CompanyName;
                            calTblRow["OurRepName"] = string.IsNullOrEmpty(item.OurRepName) ? "" : item.OurRepName;
                            calTblRow["CompanyRepName"] = string.IsNullOrEmpty(item.CompanyRepName) ? "" : item.CompanyRepName;

                            DateTime callDate;
                            if (DateTime.TryParse(item.CallDate, out callDate))
                                calTblRow["CallDate"] = callDate;
                            else
                                calTblRow["CallDate"] = DBNull.Value;

                            calTblRow["Subject"] = string.IsNullOrEmpty(item.Subject) ? "" : item.Subject;
                            calTblRow["Body"] = string.IsNullOrEmpty(item.Body) ? "" : item.Body;
                            calTblRow["WhomCalledWhom"] = string.IsNullOrEmpty(item.WhomCalledWhom) ? "" : item.WhomCalledWhom;
                            calTblRow["UpdatedBy"] = string.IsNullOrEmpty(item.UpdatedBy) ? "" : item.UpdatedBy;
                            calTblRow["From"] = string.IsNullOrEmpty(item.From) ? "" : item.From;

                            callTable.Rows.Add(calTblRow);
                        }

                        // Write to server
                        sqlBulkCopy.WriteToServer(callTable);

                        callFormList.Clear();
                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// Contact Form SQL bulk insertion
        /// </summary>
        /// <returns></returns>
        public bool ContactSQLOprations()
        {
            // Get Call Form items from the _formModelList
            List<FormModel> contactFormList = _formModelList.Where(x => x.Form.Equals("Contact")).ToList();
            if (contactFormList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in Contact Form");
                return true;
            }


            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        sqlBulkCopy.DestinationTableName = "LotusNotesContact";

                        var contactTable = new DataTable();
                        contactTable.Columns.Add("Id", typeof(string));
                        contactTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        contactTable.Columns.Add("Ref", typeof(string));
                        contactTable.Columns.Add("UpdatedBy", typeof(string));
                        contactTable.Columns.Add("Body", typeof(string));
                        contactTable.Columns.Add("CompanyName", typeof(string));
                        contactTable.Columns.Add("ComposeDate", typeof(DateTime));
                        contactTable.Columns.Add("ContactAddress", typeof(string));
                        contactTable.Columns.Add("ContactCity", typeof(string));
                        contactTable.Columns.Add("ContactDivision", typeof(string));
                        contactTable.Columns.Add("ContactEmail", typeof(string));
                        contactTable.Columns.Add("ContactFAX", typeof(string));
                        contactTable.Columns.Add("ContactMobile", typeof(string));
                        contactTable.Columns.Add("ContactName", typeof(string));
                        contactTable.Columns.Add("ContactPhone", typeof(string));
                        contactTable.Columns.Add("ContactSalutation", typeof(string));
                        contactTable.Columns.Add("ContactState", typeof(string));
                        contactTable.Columns.Add("ContactTitle", typeof(string));
                        contactTable.Columns.Add("ContactZIP", typeof(string));
                        contactTable.Columns.Add("Form", typeof(string));
                        contactTable.Columns.Add("Count", typeof(string));

                        foreach (var item in contactFormList)
                        {
                            DataRow contactTblRow = contactTable.NewRow();
                            contactTblRow["Id"] = string.IsNullOrEmpty(item.SystemGUID) ? "" : item.SystemGUID;
                            contactTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(item.UniqueChildDocumentsId) ? "" : item.UniqueChildDocumentsId;
                            contactTblRow["Ref"] = string.IsNullOrEmpty(item.Ref) ? "" : item.Ref;
                            contactTblRow["UpdatedBy"] = string.IsNullOrEmpty(item.UpdatedBy) ? "" : item.UpdatedBy;
                            contactTblRow["Body"] = string.IsNullOrEmpty(item.Body) ? "" : item.Body;
                            contactTblRow["CompanyName"] = string.IsNullOrEmpty(item.CompanyName) ? "" : item.CompanyName;
                            DateTime composeDate;
                            if (DateTime.TryParse(item.ComposeDate, out composeDate))
                                contactTblRow["ComposeDate"] = composeDate;
                            else
                                contactTblRow["ComposeDate"] = DBNull.Value;
                            contactTblRow["ContactAddress"] = string.IsNullOrEmpty(item.ContactAddress) ? "" : item.ContactAddress;
                            contactTblRow["ContactCity"] = string.IsNullOrEmpty(item.ContactCity) ? "" : item.ContactCity;
                            contactTblRow["ContactDivision"] = string.IsNullOrEmpty(item.ContactDivision) ? "" : item.ContactDivision;
                            contactTblRow["ContactEmail"] = string.IsNullOrEmpty(item.ContactEmail) ? "" : item.ContactEmail;
                            contactTblRow["ContactFAX"] = string.IsNullOrEmpty(item.ContactFAX) ? "" : item.ContactFAX;
                            contactTblRow["ContactMobile"] = string.IsNullOrEmpty(item.ContactMobile) ? "" : item.ContactMobile;
                            contactTblRow["ContactName"] = string.IsNullOrEmpty(item.ContactName) ? "" : item.ContactName;
                            contactTblRow["ContactPhone"] = string.IsNullOrEmpty(item.ContactPhone) ? "" : item.ContactPhone;
                            contactTblRow["ContactSalutation"] = string.IsNullOrEmpty(item.ContactSalutation) ? "" : item.ContactSalutation;
                            contactTblRow["ContactState"] = string.IsNullOrEmpty(item.ContactState) ? "" : item.ContactState;
                            contactTblRow["ContactTitle"] = string.IsNullOrEmpty(item.ContactTitle) ? "" : item.ContactTitle;
                            contactTblRow["ContactZIP"] = string.IsNullOrEmpty(item.ContactZIP) ? "" : item.ContactZIP;
                            contactTblRow["Form"] = string.IsNullOrEmpty(item.Form) ? "" : item.Form;
                            contactTblRow["Count"] = item.Count;

                            contactTable.Rows.Add(contactTblRow);
                        }

                        // Write to server
                        sqlBulkCopy.WriteToServer(contactTable);

                        contactFormList.Clear();
                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// CreaditMemo Form SQL bulk insertions
        /// </summary>
        /// <returns></returns>
        public bool CreditMemoSQLOprations()
        {
            // Get Call Form items from the _formModelList
            List<FormModel> creditMemoFormList = _formModelList.Where(x => x.Form.Equals("CreditMemo")).ToList();
            if (creditMemoFormList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in Credit Memo Form");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        sqlBulkCopy.DestinationTableName = "LotusNotesCreditMemo";

                        var creditMemoTable = new DataTable();
                        creditMemoTable.Columns.Add("Id", typeof(string));
                        creditMemoTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        creditMemoTable.Columns.Add("Ref", typeof(string));
                        creditMemoTable.Columns.Add("UpdatedBy", typeof(string));
                        creditMemoTable.Columns.Add("ActivityDate", typeof(DateTime));
                        creditMemoTable.Columns.Add("Body", typeof(string));
                        creditMemoTable.Columns.Add("CompanyName", typeof(string));
                        creditMemoTable.Columns.Add("ComposeDate", typeof(DateTime));
                        creditMemoTable.Columns.Add("DocAuthor", typeof(string));
                        creditMemoTable.Columns.Add("Subject", typeof(string));
                        creditMemoTable.Columns.Add("Form", typeof(string));
                        creditMemoTable.Columns.Add("Count", typeof(string));

                        foreach (var item in creditMemoFormList)
                        {
                            DataRow creditMemoTblRow = creditMemoTable.NewRow();
                            creditMemoTblRow["Id"] = string.IsNullOrEmpty(item.SystemGUID) ? "" : item.SystemGUID;
                            creditMemoTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(item.UniqueChildDocumentsId) ? "" : item.UniqueChildDocumentsId;
                            creditMemoTblRow["Ref"] = string.IsNullOrEmpty(item.Ref) ? "" : item.Ref;
                            creditMemoTblRow["UpdatedBy"] = string.IsNullOrEmpty(item.UpdatedBy) ? "" : item.UpdatedBy;

                            DateTime ActivityDate;
                            if (DateTime.TryParse(item.ActivityDate, out ActivityDate))
                                creditMemoTblRow["ActivityDate"] = ActivityDate;
                            else
                                creditMemoTblRow["ActivityDate"] = DBNull.Value;

                            creditMemoTblRow["Body"] = string.IsNullOrEmpty(item.Body) ? "" : item.Body;
                            creditMemoTblRow["CompanyName"] = string.IsNullOrEmpty(item.CompanyName) ? "" : item.CompanyName;

                            DateTime composeDate;
                            if (DateTime.TryParse(item.ComposeDate, out composeDate))
                                creditMemoTblRow["ComposeDate"] = composeDate;
                            else
                                creditMemoTblRow["ComposeDate"] = DBNull.Value;

                            creditMemoTblRow["DocAuthor"] = string.IsNullOrEmpty(item.DocAuthor) ? "" : item.DocAuthor;
                            creditMemoTblRow["Subject"] = string.IsNullOrEmpty(item.Subject) ? "" : item.Subject;
                            creditMemoTblRow["Form"] = string.IsNullOrEmpty(item.Form) ? "" : item.Form;
                            creditMemoTblRow["Count"] = item.Count;

                            creditMemoTable.Rows.Add(creditMemoTblRow);
                        }

                        // Write to server
                        sqlBulkCopy.WriteToServer(creditMemoTable);

                        creditMemoFormList.Clear();
                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// Customer Form SQL bulk insertion
        /// </summary>
        /// <returns></returns>
        public bool CustomerSQLOprations()
        {
            // Get Call Form items from the _formModelList
            List<FormModel> customerFormList = _formModelList.Where(x => x.Form.Equals("Customer")).ToList();

            if (customerFormList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in Customer Form");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        sqlBulkCopy.DestinationTableName = "LotusNotesCustomer";

                        var customerTable = new DataTable();
                        customerTable.Columns.Add("Id", typeof(string));
                        customerTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        customerTable.Columns.Add("Ref", typeof(string));
                        customerTable.Columns.Add("UpdatedBy", typeof(string));
                        customerTable.Columns.Add("AccountManager", typeof(string));
                        customerTable.Columns.Add("Body", typeof(string));
                        customerTable.Columns.Add("CompanyName", typeof(string));
                        customerTable.Columns.Add("CompanyAddress", typeof(string));
                        customerTable.Columns.Add("CompanyAddress2", typeof(string));
                        customerTable.Columns.Add("CompanyCity", typeof(string));
                        customerTable.Columns.Add("CompanyFAX", typeof(string));
                        customerTable.Columns.Add("CompanyPhone", typeof(string));
                        customerTable.Columns.Add("CompanyState", typeof(string));
                        customerTable.Columns.Add("CompanyZIP", typeof(string));
                        customerTable.Columns.Add("ComposeDate", typeof(DateTime));
                        customerTable.Columns.Add("Country", typeof(string));
                        customerTable.Columns.Add("Status", typeof(string));
                        customerTable.Columns.Add("Form", typeof(string));
                        customerTable.Columns.Add("Count", typeof(string));

                        foreach (var item in customerFormList)
                        {
                            DataRow customerTblRow = customerTable.NewRow();
                            customerTblRow["Id"] = string.IsNullOrEmpty(item.SystemGUID) ? "" : item.SystemGUID;
                            customerTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(item.UniqueChildDocumentsId) ? "" : item.UniqueChildDocumentsId;
                            customerTblRow["Ref"] = string.IsNullOrEmpty(item.Ref) ? "" : item.Ref;
                            customerTblRow["UpdatedBy"] = string.IsNullOrEmpty(item.UpdatedBy) ? "" : item.UpdatedBy;
                            customerTblRow["AccountManager"] = string.IsNullOrEmpty(item.AccountManager) ? "" : item.AccountManager;
                            customerTblRow["Body"] = string.IsNullOrEmpty(item.Body) ? "" : item.Body;
                            customerTblRow["CompanyName"] = string.IsNullOrEmpty(item.CompanyName) ? "" : item.CompanyName;
                            customerTblRow["CompanyAddress"] = string.IsNullOrEmpty(item.CompanyAddress) ? "" : item.CompanyAddress;
                            customerTblRow["CompanyAddress2"] = string.IsNullOrEmpty(item.CompanyAddress2) ? "" : item.CompanyAddress2;
                            customerTblRow["CompanyCity"] = string.IsNullOrEmpty(item.CompanyCity) ? "" : item.CompanyCity;
                            customerTblRow["CompanyFAX"] = string.IsNullOrEmpty(item.CompanyFAX) ? "" : item.CompanyFAX;
                            customerTblRow["CompanyPhone"] = string.IsNullOrEmpty(item.CompanyPhone) ? "" : item.CompanyPhone;
                            customerTblRow["CompanyState"] = string.IsNullOrEmpty(item.CompanyState) ? "" : item.CompanyState;
                            customerTblRow["CompanyZIP"] = string.IsNullOrEmpty(item.CompanyZIP) ? "" : item.CompanyZIP;

                            DateTime composeDate;
                            if (DateTime.TryParse(item.ComposeDate, out composeDate))
                                customerTblRow["ComposeDate"] = composeDate;
                            else
                                customerTblRow["ComposeDate"] = DBNull.Value;

                            customerTblRow["Country"] = string.IsNullOrEmpty(item.Country) ? "" : item.Country;
                            customerTblRow["Status"] = string.IsNullOrEmpty(item.Status) ? "" : item.Status;
                            customerTblRow["Form"] = string.IsNullOrEmpty(item.Form) ? "" : item.Form;
                            customerTblRow["Count"] = item.Count;


                            customerTable.Rows.Add(customerTblRow);
                        }

                        // Write to server
                        sqlBulkCopy.WriteToServer(customerTable);

                        customerFormList.Clear();
                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        /// <summary>
        /// Insert 
        /// Meeting, Incoming, Misc, Outgoing and Response FORM data
        /// </summary>
        /// <returns></returns>
        public bool EmailSQLOprations()
        {
            // Get Call Form items from the _formModelList
            List<FormModel> emailFormList = _formModelList.Where(x => x.Form.Equals("Incoming") || x.Form.Equals("Meeting") || x.Form.Equals("Misc") || x.Form.Equals("Outgoing") || x.Form.Equals("Response")).ToList();

            if (emailFormList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in Email Form");
                return true;
            }
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        sqlBulkCopy.DestinationTableName = "LotusNotesEmail";

                        var emailTable = new DataTable();
                        emailTable.Columns.Add("Id", typeof(string));
                        emailTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        emailTable.Columns.Add("Ref", typeof(string));
                        emailTable.Columns.Add("UpdatedBy", typeof(string));
                        emailTable.Columns.Add("ActivityDate", typeof(DateTime));
                        emailTable.Columns.Add("Attendees", typeof(string));
                        emailTable.Columns.Add("Body", typeof(string));
                        emailTable.Columns.Add("CompanyName", typeof(string));
                        emailTable.Columns.Add("ComposeDate", typeof(DateTime));
                        emailTable.Columns.Add("ContactName", typeof(string));
                        emailTable.Columns.Add("CorrespondenceDate", typeof(DateTime));
                        emailTable.Columns.Add("CorrespondenceType", typeof(string));
                        emailTable.Columns.Add("DocAuthor", typeof(string));
                        emailTable.Columns.Add("MeetingDate", typeof(DateTime));
                        emailTable.Columns.Add("RecipientName", typeof(string));
                        emailTable.Columns.Add("SenderName", typeof(string));
                        emailTable.Columns.Add("Subject", typeof(string));
                        emailTable.Columns.Add("Form", typeof(string));
                        emailTable.Columns.Add("Count", typeof(string));


                        foreach (var item in emailFormList)
                        {
                            DataRow emailTblRow = emailTable.NewRow();
                            emailTblRow["Id"] = string.IsNullOrEmpty(item.SystemGUID) ? "" : item.SystemGUID;
                            emailTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(item.UniqueChildDocumentsId) ? "" : item.UniqueChildDocumentsId;
                            emailTblRow["Ref"] = string.IsNullOrEmpty(item.Ref) ? "" : item.Ref;
                            emailTblRow["UpdatedBy"] = string.IsNullOrEmpty(item.UpdatedBy) ? "" : item.UpdatedBy;

                            DateTime ActivityDate;
                            if (DateTime.TryParse(item.ActivityDate, out ActivityDate))
                                emailTblRow["ActivityDate"] = ActivityDate;
                            else
                                emailTblRow["ActivityDate"] = DBNull.Value;
                            emailTblRow["Attendees"] = string.IsNullOrEmpty(item.Attendees) ? "" : item.Attendees;
                            emailTblRow["Body"] = string.IsNullOrEmpty(item.Body) ? "" : item.Body;
                            emailTblRow["CompanyName"] = string.IsNullOrEmpty(item.CompanyName) ? "" : item.CompanyName;

                            DateTime composeDate;
                            if (DateTime.TryParse(item.ComposeDate, out composeDate))
                                emailTblRow["ComposeDate"] = composeDate;
                            else
                                emailTblRow["ComposeDate"] = DBNull.Value;

                            emailTblRow["ContactName"] = string.IsNullOrEmpty(item.ContactName) ? "" : item.ContactName;
                            DateTime CorrDate;
                            if (DateTime.TryParse(item.CorrespondenceDate, out CorrDate))
                                emailTblRow["CorrespondenceDate"] = CorrDate;
                            else
                                emailTblRow["CorrespondenceDate"] = DBNull.Value;

                            emailTblRow["CorrespondenceType"] = string.IsNullOrEmpty(item.CorrespondenceType) ? "" : item.CorrespondenceType;
                            emailTblRow["DocAuthor"] = string.IsNullOrEmpty(item.DocAuthor) ? "" : item.DocAuthor;


                            DateTime MeetingDate;
                            if (DateTime.TryParse(item.MeetingDate, out MeetingDate))
                                emailTblRow["MeetingDate"] = MeetingDate;
                            else
                                emailTblRow["MeetingDate"] = DBNull.Value;

                            emailTblRow["RecipientName"] = string.IsNullOrEmpty(item.RecipientName) ? "" : item.RecipientName;

                            emailTblRow["SenderName"] = string.IsNullOrEmpty(item.SenderName) ? "" : item.SenderName;


                            emailTblRow["Subject"] = string.IsNullOrEmpty(item.Subject) ? "" : item.Subject;
                            emailTblRow["Form"] = string.IsNullOrEmpty(item.Form) ? "" : item.Form;
                            emailTblRow["Count"] = item.Count;

                            emailTable.Rows.Add(emailTblRow);
                        }

                        // Write to server
                        sqlBulkCopy.WriteToServer(emailTable);

                        emailFormList.Clear();
                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool DealDocumentSQLOprations()
        {
            // Get Call Form items from the _formModelList
            List<FormModel> dealDocumentFormList = _formModelList.Where(x => x.Form.Equals("Deal Documents")).ToList();

            if (dealDocumentFormList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in Deal Document Form");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        sqlBulkCopy.DestinationTableName = "LotusNotesDealDocuments";

                        var dealDocumentTable = new DataTable();
                        dealDocumentTable.Columns.Add("Id", typeof(string));
                        dealDocumentTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        dealDocumentTable.Columns.Add("Ref", typeof(string));
                        dealDocumentTable.Columns.Add("UpdatedBy", typeof(string));
                        dealDocumentTable.Columns.Add("ARRReport", typeof(string));
                        dealDocumentTable.Columns.Add("BoardMinutes", typeof(string));
                        dealDocumentTable.Columns.Add("BoardSubmission", typeof(string));
                        dealDocumentTable.Columns.Add("CompanyName", typeof(string));
                        dealDocumentTable.Columns.Add("CompletionChecklist", typeof(string));
                        dealDocumentTable.Columns.Add("ConfidentialityAgreement", typeof(string));
                        dealDocumentTable.Columns.Add("CreditRecommendations", typeof(string));
                        dealDocumentTable.Columns.Add("CreditMinutes", typeof(string));
                        dealDocumentTable.Columns.Add("SubmissionAndReviewPaper", typeof(string));
                        dealDocumentTable.Columns.Add("DueDeligenceReports", typeof(string));
                        dealDocumentTable.Columns.Add("NumberOfDocuments", typeof(string));
                        dealDocumentTable.Columns.Add("DueDiligence", typeof(string));
                        dealDocumentTable.Columns.Add("FacilityAgreement", typeof(string));
                        dealDocumentTable.Columns.Add("FinalDocs", typeof(string));
                        dealDocumentTable.Columns.Add("HeadsOfTerms", typeof(string));
                        dealDocumentTable.Columns.Add("InfoMemo", typeof(string));
                        dealDocumentTable.Columns.Add("KYC_Review", typeof(string));
                        dealDocumentTable.Columns.Add("LawyerInstruction", typeof(string));
                        dealDocumentTable.Columns.Add("LoanMarketsdocs", typeof(string));
                        dealDocumentTable.Columns.Add("KYC_Misc_Docs", typeof(string));
                        dealDocumentTable.Columns.Add("Model", typeof(string));
                        dealDocumentTable.Columns.Add("MonitoringInstruction", typeof(string));
                        dealDocumentTable.Columns.Add("OnePager", typeof(string));
                        dealDocumentTable.Columns.Add("KYC_Org_Chart", typeof(string));
                        dealDocumentTable.Columns.Add("Portfolio_cashflow", typeof(string));
                        dealDocumentTable.Columns.Add("Portfolio_handover_checklist", typeof(string));
                        dealDocumentTable.Columns.Add("Portfolio_hedging", typeof(string));
                        dealDocumentTable.Columns.Add("Portfolio_management_Info", typeof(string));
                        dealDocumentTable.Columns.Add("Portfolio_Financial_Covenant_Monitoring", typeof(string));
                        dealDocumentTable.Columns.Add("Portfolio_other", typeof(string));
                        dealDocumentTable.Columns.Add("PostCompletionMemo", typeof(string));
                        dealDocumentTable.Columns.Add("PreCompletionMemo", typeof(string));
                        dealDocumentTable.Columns.Add("Progress", typeof(string));
                        dealDocumentTable.Columns.Add("TransferCertificates", typeof(string));
                        dealDocumentTable.Columns.Add("ValuerInstruction", typeof(string));
                        dealDocumentTable.Columns.Add("Form", typeof(string));
                        dealDocumentTable.Columns.Add("Count", typeof(string));


                        foreach (var item in dealDocumentFormList)
                        {
                            DataRow dealDocumentTblRow = dealDocumentTable.NewRow();
                            dealDocumentTblRow["Id"] = string.IsNullOrEmpty(item.SystemGUID) ? "" : item.SystemGUID;
                            dealDocumentTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(item.UniqueChildDocumentsId) ? "" : item.UniqueChildDocumentsId;
                            dealDocumentTblRow["Ref"] = string.IsNullOrEmpty(item.Ref) ? "" : item.Ref;
                            dealDocumentTblRow["UpdatedBy"] = string.IsNullOrEmpty(item.UpdatedBy) ? "" : item.UpdatedBy;
                            dealDocumentTblRow["ARRReport"] = string.IsNullOrEmpty(item.ARRReport) ? "" : item.ARRReport;
                            dealDocumentTblRow["BoardMinutes"] = string.IsNullOrEmpty(item.BoardMinutes) ? "" : item.BoardMinutes;
                            dealDocumentTblRow["BoardSubmission"] = string.IsNullOrEmpty(item.BoardSubmission) ? "" : item.BoardSubmission;
                            dealDocumentTblRow["CompanyName"] = string.IsNullOrEmpty(item.CompanyName) ? "" : item.CompanyName;
                            dealDocumentTblRow["CompletionChecklist"] = string.IsNullOrEmpty(item.CompletionChecklist) ? "" : item.CompletionChecklist;
                            dealDocumentTblRow["ConfidentialityAgreement"] = string.IsNullOrEmpty(item.ConfidentialityAgreement) ? "" : item.ConfidentialityAgreement;
                            dealDocumentTblRow["CreditRecommendations"] = string.IsNullOrEmpty(item.CreditRecommendations) ? "" : item.CreditRecommendations;
                            dealDocumentTblRow["CreditMinutes"] = string.IsNullOrEmpty(item.CreditMinutes) ? "" : item.CreditMinutes;
                            dealDocumentTblRow["SubmissionAndReviewPaper"] = string.IsNullOrEmpty(item.SubmissionAndReviewPaper) ? "" : item.SubmissionAndReviewPaper;
                            dealDocumentTblRow["DueDeligenceReports"] = string.IsNullOrEmpty(item.DueDeligenceReports) ? "" : item.DueDeligenceReports;
                            dealDocumentTblRow["NumberOfDocuments"] = string.IsNullOrEmpty(item.NumberOfDocuments) ? "" : item.NumberOfDocuments;
                            dealDocumentTblRow["DueDiligence"] = string.IsNullOrEmpty(item.DueDiligence) ? "" : item.DueDiligence;

                            dealDocumentTblRow["FacilityAgreement"] = string.IsNullOrEmpty(item.FacilityAgreement) ? "" : item.FacilityAgreement;
                            dealDocumentTblRow["FinalDocs"] = string.IsNullOrEmpty(item.FinalDocs) ? "" : item.FinalDocs;
                            dealDocumentTblRow["HeadsOfTerms"] = string.IsNullOrEmpty(item.HeadsOfTerms) ? "" : item.HeadsOfTerms;
                            dealDocumentTblRow["InfoMemo"] = string.IsNullOrEmpty(item.InfoMemo) ? "" : item.InfoMemo;
                            dealDocumentTblRow["KYC_Review"] = string.IsNullOrEmpty(item.KYC_Review) ? "" : item.KYC_Review;

                            dealDocumentTblRow["LawyerInstruction"] = string.IsNullOrEmpty(item.LawyerInstruction) ? "" : item.LawyerInstruction;
                            dealDocumentTblRow["LoanMarketsdocs"] = string.IsNullOrEmpty(item.LoanMarketsdocs) ? "" : item.LoanMarketsdocs;
                            dealDocumentTblRow["KYC_Misc_Docs"] = string.IsNullOrEmpty(item.KYC_Misc_Docs) ? "" : item.KYC_Misc_Docs;
                            dealDocumentTblRow["Model"] = string.IsNullOrEmpty(item.Model) ? "" : item.Model;
                            dealDocumentTblRow["MonitoringInstruction"] = string.IsNullOrEmpty(item.MonitoringInstruction) ? "" : item.MonitoringInstruction;
                            dealDocumentTblRow["OnePager"] = string.IsNullOrEmpty(item.OnePager) ? "" : item.OnePager;
                            dealDocumentTblRow["KYC_Org_Chart"] = string.IsNullOrEmpty(item.KYC_Org_Chart) ? "" : item.KYC_Org_Chart;
                            dealDocumentTblRow["Portfolio_cashflow"] = string.IsNullOrEmpty(item.Portfolio_cashflow) ? "" : item.Portfolio_cashflow;
                            dealDocumentTblRow["Portfolio_handover_checklist"] = string.IsNullOrEmpty(item.Portfolio_handover_checklist) ? "" : item.Portfolio_handover_checklist;
                            dealDocumentTblRow["Portfolio_hedging"] = string.IsNullOrEmpty(item.Portfolio_hedging) ? "" : item.Portfolio_hedging;
                            dealDocumentTblRow["Portfolio_management_Info"] = string.IsNullOrEmpty(item.Portfolio_management_Info) ? "" : item.Portfolio_management_Info;
                            dealDocumentTblRow["Portfolio_Financial_Covenant_Monitoring"] = string.IsNullOrEmpty(item.Portfolio_Financial_Covenant_Monitoring) ? "" : item.Portfolio_Financial_Covenant_Monitoring;
                            dealDocumentTblRow["Portfolio_other"] = string.IsNullOrEmpty(item.Portfolio_other) ? "" : item.Portfolio_other;
                            dealDocumentTblRow["PostCompletionMemo"] = string.IsNullOrEmpty(item.PostCompletionMemo) ? "" : item.PostCompletionMemo;
                            dealDocumentTblRow["PreCompletionMemo"] = string.IsNullOrEmpty(item.PreCompletionMemo) ? "" : item.PreCompletionMemo;
                            dealDocumentTblRow["Progress"] = string.IsNullOrEmpty(item.Progress) ? "" : item.Progress;
                            dealDocumentTblRow["TransferCertificates"] = string.IsNullOrEmpty(item.TransferCertificates) ? "" : item.TransferCertificates;
                            dealDocumentTblRow["ValuerInstruction"] = string.IsNullOrEmpty(item.ValuerInstruction) ? "" : item.ValuerInstruction;
                            dealDocumentTblRow["Form"] = string.IsNullOrEmpty(item.Form) ? "" : item.Form;
                            dealDocumentTblRow["Count"] = item.Count;

                            dealDocumentTable.Rows.Add(dealDocumentTblRow);
                        }

                        // Write to server
                        sqlBulkCopy.WriteToServer(dealDocumentTable);

                        dealDocumentFormList.Clear();
                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }


        public bool ExProSQLOprations()
        {

            return true;
        }

        public bool ChecklistSQLOprations()
        {
            CheckList objCheckList = new CheckList(_checkModelList);
            objCheckList.Opportunity();
            objCheckList.Deal();
            objCheckList.DealTeam();
            objCheckList.Equity();
            objCheckList.EquityFacility();
            objCheckList.Mezzanine();
            objCheckList.MezzanineFacility();
            objCheckList.Other();
            objCheckList.OtherFacility();
            objCheckList.PostCompletion();
            objCheckList.RbsStaff();
            objCheckList.Senior();
            objCheckList.SeniorFasility();

            return true;
        }

        

    }
}
