﻿using NordiskRentingLotusNotesToSQL.LSFrom;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL.DAL
{
    public class CheckList
    {
        List<CheckListModel> _checkModelList = new List<CheckListModel>();
        string _connectionString = ConfigurationManager.AppSettings["connectionString"]; //@"Data Source=lonms11691\dmlnfarm01;Initial Catalog=NordiskRenting_DEV1;User Id = dlmuser-dev; Password = DLmus01$34try";
        const int bulkInsertBatchSize = 1000;
        
        public CheckList(List<CheckListModel> checkModelList)
        {
            _checkModelList = checkModelList;
            
        }
        public bool Opportunity()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var opportunityTable = new DataTable();
                        opportunityTable.Columns.Add("Id", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Id", "Id");
                        opportunityTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                        opportunityTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");
                        opportunityTable.Columns.Add("CompanyName", typeof(string));
                        opportunityTable.Columns.Add("CISCode", typeof(string));
                        opportunityTable.Columns.Add("PriceSensitive", typeof(string));
                        opportunityTable.Columns.Add("ProjectName", typeof(string));
                        opportunityTable.Columns.Add("Description", typeof(string));
                        opportunityTable.Columns.Add("DealComments", typeof(string));

                        foreach (var item in _checkModelList)
                        {
                            #region Opportunity table

                            DataRow opportunityTblRow = opportunityTable.NewRow();
                            if (item.Opportunity != null)
                            {
                                var checkListOpportunity = item.Opportunity;

                                opportunityTblRow["Id"] = string.IsNullOrEmpty(checkListOpportunity.Id) ? "" : checkListOpportunity.Id;
                                opportunityTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(checkListOpportunity.UniqueChildDocumentsId) ? "" : checkListOpportunity.UniqueChildDocumentsId;
                                opportunityTblRow["Ref"] = string.IsNullOrEmpty(checkListOpportunity.Ref) ? "" : checkListOpportunity.Ref;
                                opportunityTblRow["CompanyName"] = string.IsNullOrEmpty(checkListOpportunity.CompanyName) ? "" : checkListOpportunity.CompanyName;
                                opportunityTblRow["CISCode"] = string.IsNullOrEmpty(checkListOpportunity.CISCode) ? "" : checkListOpportunity.CISCode;
                                opportunityTblRow["PriceSensitive"] = string.IsNullOrEmpty(checkListOpportunity.PriceSensitive) ? "" : checkListOpportunity.PriceSensitive;
                                opportunityTblRow["ProjectName"] = string.IsNullOrEmpty(checkListOpportunity.ProjectName) ? "" : checkListOpportunity.ProjectName;
                                opportunityTblRow["Description"] = string.IsNullOrEmpty(checkListOpportunity.Description) ? "" : checkListOpportunity.Description;
                                opportunityTblRow["DealComments"] = string.IsNullOrEmpty(checkListOpportunity.DealComments) ? "" : checkListOpportunity.DealComments;

                                opportunityTable.Rows.Add(opportunityTblRow);
                            }

                            #endregion                           

                        }

                        // Opportunity
                        sqlBulkCopy.DestinationTableName = "ChecklistOpportunity";
                        sqlBulkCopy.WriteToServer(opportunityTable);
                        Logger.FileLogger("Opportunity saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool Deal()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                    sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                    sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");
                    sqlBulkCopy.ColumnMappings.Add("DealType", "DealType");
                    sqlBulkCopy.ColumnMappings.Add("DealVendor", "DealVendor");
                    sqlBulkCopy.ColumnMappings.Add("Source", "Source");
                    sqlBulkCopy.ColumnMappings.Add("IntroducerName", "IntroducerName");
                    sqlBulkCopy.ColumnMappings.Add("IntCorp", "IntCorp");
                    sqlBulkCopy.ColumnMappings.Add("IntSF", "IntSF");
                    sqlBulkCopy.ColumnMappings.Add("Gov", "Gov");
                    sqlBulkCopy.ColumnMappings.Add("PropCoResidentialDeal", "PropCoResidentialDeal");
                    sqlBulkCopy.ColumnMappings.Add("NRDateBoard", "NRDateBoard");
                    sqlBulkCopy.ColumnMappings.Add("DebtType", "DebtType");
                    sqlBulkCopy.ColumnMappings.Add("WIPDealAmount", "WIPDealAmount");
                    sqlBulkCopy.ColumnMappings.Add("Deal_Currency", "Deal_Currency");

                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var dealTable = new DataTable();
                        dealTable.Columns.Add("OpportunityId", typeof(string));
                        dealTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        dealTable.Columns.Add("Ref", typeof(string));
                        dealTable.Columns.Add("DealType", typeof(string));
                        dealTable.Columns.Add("DealVendor", typeof(string));
                        dealTable.Columns.Add("Source", typeof(string));
                        dealTable.Columns.Add("IntroducerName", typeof(string));
                        dealTable.Columns.Add("IntCorp", typeof(string));
                        dealTable.Columns.Add("IntSF", typeof(string));
                        dealTable.Columns.Add("Gov", typeof(string));
                        dealTable.Columns.Add("PropCoResidentialDeal", typeof(string));
                        dealTable.Columns.Add("NRDateBoard", typeof(string));
                        dealTable.Columns.Add("DebtType", typeof(string));
                        dealTable.Columns.Add("WIPDealAmount", typeof(string));
                        dealTable.Columns.Add("Deal_Currency", typeof(string));


                        foreach (var item in _checkModelList)
                        {
                            #region Deal table

                            if (item.Deal != null)
                            {
                                var checkListdeals = item.Deal;

                                DataRow dealTblRow = dealTable.NewRow();

                                dealTblRow["OpportunityId"] = string.IsNullOrEmpty(checkListdeals.OpportunityId) ? "" : checkListdeals.OpportunityId;
                                dealTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(checkListdeals.UniqueChildDocumentsId) ? "" : checkListdeals.UniqueChildDocumentsId;
                                dealTblRow["Ref"] = string.IsNullOrEmpty(checkListdeals.Ref) ? "" : checkListdeals.Ref;
                                dealTblRow["DealType"] = string.IsNullOrEmpty(checkListdeals.Deal_Type) ? "" : checkListdeals.Deal_Type;
                                dealTblRow["DealVendor"] = string.IsNullOrEmpty(checkListdeals.DealVendor) ? "" : checkListdeals.DealVendor;
                                dealTblRow["Source"] = string.IsNullOrEmpty(checkListdeals.Source) ? "" : checkListdeals.Source;
                                dealTblRow["IntroducerName"] = string.IsNullOrEmpty(checkListdeals.Introducer_Name) ? "" : checkListdeals.Introducer_Name;
                                dealTblRow["IntCorp"] = string.IsNullOrEmpty(checkListdeals.Int_Corp) ? "" : checkListdeals.Int_Corp;
                                dealTblRow["IntSF"] = string.IsNullOrEmpty(checkListdeals.Int_SF) ? "" : checkListdeals.Int_SF;
                                dealTblRow["Gov"] = string.IsNullOrEmpty(checkListdeals.Gov) ? "" : checkListdeals.Gov;
                                dealTblRow["PropCoResidentialDeal"] = string.IsNullOrEmpty(checkListdeals.PropCoResidentialDeal) ? "" : checkListdeals.PropCoResidentialDeal;
                                dealTblRow["NRDateBoard"] = string.IsNullOrEmpty(checkListdeals.NRDateBoard) ? "" : checkListdeals.NRDateBoard;
                                dealTblRow["DebtType"] = string.IsNullOrEmpty(checkListdeals.DebtType) ? "" : checkListdeals.DebtType;
                                dealTblRow["WIPDealAmount"] = string.IsNullOrEmpty(checkListdeals.WIPDealAmount) ? "" : checkListdeals.WIPDealAmount;
                                dealTblRow["Deal_Currency"] = string.IsNullOrEmpty(checkListdeals.Deal_Currency) ? "" : checkListdeals.Deal_Currency;

                                dealTable.Rows.Add(dealTblRow);
                            }

                            #endregion
                            
                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistDeal";
                        sqlBulkCopy.WriteToServer(dealTable);
                        Logger.FileLogger("Deal saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool DealTeam()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;

                    sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                    sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                    sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");
                    sqlBulkCopy.ColumnMappings.Add("Staff", "Staff");
                    sqlBulkCopy.ColumnMappings.Add("Team", "Team");
                    sqlBulkCopy.ColumnMappings.Add("Aware", "Aware");
                    sqlBulkCopy.ColumnMappings.Add("StaffRole", "StaffRole");

                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var dealTeamTable = new DataTable();
                        dealTeamTable.Columns.Add("OpportunityId", typeof(string));
                        dealTeamTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        dealTeamTable.Columns.Add("Ref", typeof(string));
                        dealTeamTable.Columns.Add("Staff", typeof(string));
                        dealTeamTable.Columns.Add("Team", typeof(string));
                        dealTeamTable.Columns.Add("Aware", typeof(string));
                        dealTeamTable.Columns.Add("StaffRole", typeof(string));

                        foreach (var item in _checkModelList)
                        {
                            #region Deal Team table

                            if (item.DealTeam != null)
                            {
                                var checkListdealTeam = item.DealTeam;

                                foreach (var dealTeam in checkListdealTeam)
                                {
                                    DataRow dealTeamTblRow = dealTeamTable.NewRow();
                                    dealTeamTblRow["OpportunityId"] = string.IsNullOrEmpty(dealTeam.OpportunityId) ? "" : dealTeam.OpportunityId;
                                    dealTeamTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(dealTeam.UniqueChildDocumentsId) ? "" : dealTeam.UniqueChildDocumentsId;
                                    dealTeamTblRow["Ref"] = string.IsNullOrEmpty(dealTeam.Ref) ? "" : dealTeam.Ref;
                                    
                                    dealTeamTblRow["Staff"] = string.IsNullOrEmpty(dealTeam.Staff) ? "" : dealTeam.Staff;
                                    dealTeamTblRow["Team"] = string.IsNullOrEmpty(dealTeam.Team) ? "" : dealTeam.Team;
                                    dealTeamTblRow["Aware"] = string.IsNullOrEmpty(dealTeam.Aware) ? "" : dealTeam.Aware;
                                    dealTeamTblRow["StaffRole"] = string.IsNullOrEmpty(dealTeam.StaffRole) ? "" : dealTeam.StaffRole;

                                    dealTeamTable.Rows.Add(dealTeamTblRow);
                                }
                            }

                            #endregion

                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistDealTeam";
                        sqlBulkCopy.WriteToServer(dealTeamTable);
                        Logger.FileLogger("DealTeam saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool RbsStaff()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                    sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                    sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                    sqlBulkCopy.ColumnMappings.Add("ExSF", "ExSF");
                    sqlBulkCopy.ColumnMappings.Add("Div", "Div");
                    sqlBulkCopy.ColumnMappings.Add("DateAware", "DateAware");
                    sqlBulkCopy.ColumnMappings.Add("ExSFReason", "ExSFReason");
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var otherRbsStaffTable = new DataTable();
                        otherRbsStaffTable.Columns.Add("OpportunityId", typeof(string));
                        otherRbsStaffTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        otherRbsStaffTable.Columns.Add("Ref", typeof(string));

                        otherRbsStaffTable.Columns.Add("ExSF", typeof(string));
                        otherRbsStaffTable.Columns.Add("Div", typeof(string));
                        otherRbsStaffTable.Columns.Add("DateAware", typeof(string));
                        otherRbsStaffTable.Columns.Add("ExSFReason", typeof(string));

                        foreach (var item in _checkModelList)
                        {

                            #region OtherRBSStaff table

                            if (item.OtherRBSStaffList != null)
                            {
                                var checklistOtherRBSStaffList = item.OtherRBSStaffList;

                                foreach (var otherrbsStaff in checklistOtherRBSStaffList)
                                {
                                    DataRow otherrbsStaffTblRow = otherRbsStaffTable.NewRow();

                                    otherrbsStaffTblRow["OpportunityId"] = string.IsNullOrEmpty(otherrbsStaff.OpportunityId) ? "" : otherrbsStaff.OpportunityId;
                                    otherrbsStaffTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(otherrbsStaff.UniqueChildDocumentsId) ? "" : otherrbsStaff.UniqueChildDocumentsId;
                                    otherrbsStaffTblRow["Ref"] = string.IsNullOrEmpty(otherrbsStaff.Ref) ? "" : otherrbsStaff.Ref;

                                    otherrbsStaffTblRow["ExSF"] = string.IsNullOrEmpty(otherrbsStaff.ExSF) ? "" : otherrbsStaff.ExSF;
                                    otherrbsStaffTblRow["Div"] = string.IsNullOrEmpty(otherrbsStaff.Div) ? "" : otherrbsStaff.Div;
                                    otherrbsStaffTblRow["DateAware"] = string.IsNullOrEmpty(otherrbsStaff.DateAware) ? "" : otherrbsStaff.DateAware;
                                    otherrbsStaffTblRow["ExSFReason"] = string.IsNullOrEmpty(otherrbsStaff.ExSFReasone) ? "" : otherrbsStaff.ExSFReasone;

                                    otherRbsStaffTable.Rows.Add(otherrbsStaffTblRow);
                                }
                            }

                            #endregion

                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistOtherRBSStaff";
                        sqlBulkCopy.WriteToServer(otherRbsStaffTable);
                        Logger.FileLogger("OtherRBSStaff saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool Senior()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;


                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var seniorTable = new DataTable();
                        seniorTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");

                        seniorTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");

                        seniorTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");


                        seniorTable.Columns.Add("SeniorDealPosition", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SeniorDealPosition", "SeniorDealPosition");
                        seniorTable.Columns.Add("MarketRole", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("MarketRole", "MarketRole");
                        seniorTable.Columns.Add("SFRole", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SFRole", "SFRole");
                        seniorTable.Columns.Add("Total_debt_size", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Total_debt_size", "Total_debt_size");
                        seniorTable.Columns.Add("DealProb", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DealProb", "DealProb");
                        seniorTable.Columns.Add("DateEstCompletion", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DateEstCompletion", "DateEstCompletion");
                        seniorTable.Columns.Add("DateCompletion", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DateCompletion", "DateCompletion");
                        seniorTable.Columns.Add("ReasonLost", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ReasonLost", "ReasonLost");
                        seniorTable.Columns.Add("LostTo", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LostTo", "LostTo");
                        seniorTable.Columns.Add("DetailedReasonLost", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DetailedReasonLost", "DetailedReasonLost");
                        seniorTable.Columns.Add("Competitor", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Competitor", "Competitor");


                        foreach (var item in _checkModelList)
                        {

                            #region Senior table

                            if (item.Senior != null)
                            {
                                var seniorData = item.Senior;

                                DataRow seniorTblRow = seniorTable.NewRow();

                                seniorTblRow["OpportunityId"] = string.IsNullOrEmpty(seniorData.OpportunityId) ? "" : seniorData.OpportunityId;
                                seniorTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(seniorData.UniqueChildDocumentsId) ? "" : seniorData.UniqueChildDocumentsId;

                                seniorTblRow["Ref"] = string.IsNullOrEmpty(seniorData.Ref) ? "" : seniorData.Ref;
                                seniorTblRow["SeniorDealPosition"] = string.IsNullOrEmpty(seniorData.SeniorDealPosition) ? "" : seniorData.SeniorDealPosition;
                                seniorTblRow["SFRole"] = string.IsNullOrEmpty(seniorData.SFRole) ? "" : seniorData.SFRole;
                                seniorTblRow["MarketRole"] = string.IsNullOrEmpty(seniorData.MarketRole) ? "" : seniorData.MarketRole;
                                seniorTblRow["Total_debt_size"] = string.IsNullOrEmpty(seniorData.Total_debt_size) ? "" : seniorData.Total_debt_size;
                                seniorTblRow["DealProb"] = string.IsNullOrEmpty(seniorData.DealProb) ? "" : seniorData.DealProb;
                                seniorTblRow["DateEstCompletion"] = string.IsNullOrEmpty(seniorData.DateEstCompletion) ? "" : seniorData.DateEstCompletion;
                                seniorTblRow["DateCompletion"] = string.IsNullOrEmpty(seniorData.DateCompletion) ? "" : seniorData.DateCompletion;
                                seniorTblRow["ReasonLost"] = string.IsNullOrEmpty(seniorData.ReasonLost) ? "" : seniorData.ReasonLost;
                                seniorTblRow["LostTo"] = string.IsNullOrEmpty(seniorData.LostTo) ? "" : seniorData.LostTo;
                                seniorTblRow["DetailedReasonLost"] = string.IsNullOrEmpty(seniorData.DetailedReasonLost) ? "" : seniorData.DetailedReasonLost;
                                seniorTblRow["Competitor"] = string.IsNullOrEmpty(seniorData.Competitor) ? "" : seniorData.Competitor;

                                seniorTable.Rows.Add(seniorTblRow);
                            }

                            #endregion

                        }

                        // Opportunity                        
                        Logger.FileLogger("OtherRBSStaff saved...");
                        sqlBulkCopy.DestinationTableName = "ChecklistSenior";
                        sqlBulkCopy.WriteToServer(seniorTable);
                        Logger.FileLogger("Senior saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool SeniorFasility()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                    sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                    sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                    sqlBulkCopy.ColumnMappings.Add("Line", "Line");
                    sqlBulkCopy.ColumnMappings.Add("FacilityType", "FacilityType");
                    sqlBulkCopy.ColumnMappings.Add("ProductOwnerCode", "ProductOwnerCode");
                    sqlBulkCopy.ColumnMappings.Add("Term", "Term");
                    sqlBulkCopy.ColumnMappings.Add("Currency", "Currency");
                    sqlBulkCopy.ColumnMappings.Add("Day1GrossCommit", "Day1GrossCommit");
                    sqlBulkCopy.ColumnMappings.Add("LMCurrentPosition", "LMCurrentPosition");
                    sqlBulkCopy.ColumnMappings.Add("ExpectedFinalHold", "ExpectedFinalHold");
                    sqlBulkCopy.ColumnMappings.Add("Day1Utilisation", "Day1Utilisation");
                    sqlBulkCopy.ColumnMappings.Add("Month1Utilisation", "Month1Utilisation");
                    sqlBulkCopy.ColumnMappings.Add("Month3Utilisation", "Month3Utilisation");
                    sqlBulkCopy.ColumnMappings.Add("Margin", "Margin");
                    sqlBulkCopy.ColumnMappings.Add("GrossFee", "GrossFee");
                    sqlBulkCopy.ColumnMappings.Add("NetFee", "NetFee");
                    sqlBulkCopy.ColumnMappings.Add("RecurringFeeType", "RecurringFeeType");
                    sqlBulkCopy.ColumnMappings.Add("RecurringFee", "RecurringFee");
                    sqlBulkCopy.ColumnMappings.Add("CommitmentFee", "CommitmentFee");
                    sqlBulkCopy.ColumnMappings.Add("CommitedUncommited", "CommitedUncommited");
                    sqlBulkCopy.ColumnMappings.Add("ProbabilityOfDefault", "ProbabilityOfDefault");
                    sqlBulkCopy.ColumnMappings.Add("LossGivenDefault", "LossGivenDefault");
                    sqlBulkCopy.ColumnMappings.Add("SanctionedGrossCommit", "SanctionedGrossCommit");
                    sqlBulkCopy.ColumnMappings.Add("SanctionedHold", "SanctionedHold");
                    sqlBulkCopy.ColumnMappings.Add("PRisMFacilityID", "PRisMFacilityID");
                    sqlBulkCopy.ColumnMappings.Add("Securitisation", "Securitisation");

                    try
                    {
                        #region Inserting data into LotusNotesCall table 


                        var seniorFacilityTable = new DataTable();
                        seniorFacilityTable.Columns.Add("OpportunityId", typeof(string));
                        seniorFacilityTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        seniorFacilityTable.Columns.Add("Ref", typeof(string));

                        seniorFacilityTable.Columns.Add("Line", typeof(string));
                        seniorFacilityTable.Columns.Add("FacilityType", typeof(string));
                        seniorFacilityTable.Columns.Add("ProductOwnerCode", typeof(string));
                        seniorFacilityTable.Columns.Add("Term", typeof(string));
                        seniorFacilityTable.Columns.Add("Currency", typeof(string));
                        seniorFacilityTable.Columns.Add("Day1GrossCommit", typeof(string));
                        seniorFacilityTable.Columns.Add("LMCurrentPosition", typeof(string));
                        seniorFacilityTable.Columns.Add("ExpectedFinalHold", typeof(string));
                        seniorFacilityTable.Columns.Add("Day1Utilisation", typeof(string));
                        seniorFacilityTable.Columns.Add("Month1Utilisation", typeof(string));
                        seniorFacilityTable.Columns.Add("Month3Utilisation", typeof(string));
                        seniorFacilityTable.Columns.Add("Margin", typeof(string));
                        seniorFacilityTable.Columns.Add("GrossFee", typeof(string));
                        seniorFacilityTable.Columns.Add("NetFee", typeof(string));
                        seniorFacilityTable.Columns.Add("RecurringFeeType", typeof(string));
                        seniorFacilityTable.Columns.Add("RecurringFee", typeof(string));
                        seniorFacilityTable.Columns.Add("CommitmentFee", typeof(string));
                        seniorFacilityTable.Columns.Add("CommitedUncommited", typeof(string));
                        seniorFacilityTable.Columns.Add("ProbabilityOfDefault", typeof(string));
                        seniorFacilityTable.Columns.Add("LossGivenDefault", typeof(string));
                        seniorFacilityTable.Columns.Add("SanctionedGrossCommit", typeof(string));
                        seniorFacilityTable.Columns.Add("SanctionedHold", typeof(string));
                        seniorFacilityTable.Columns.Add("PRisMFacilityID", typeof(string));
                        seniorFacilityTable.Columns.Add("Securitisation", typeof(string));



                        foreach (var item in _checkModelList)
                        {

                            #region SeniorFacility table

                            if (item.SeniorFacilityList != null)
                            {
                                var checklistSeniorFacilityList = item.SeniorFacilityList;

                                foreach (var seniorFacilityList in checklistSeniorFacilityList)
                                {
                                    DataRow SeniorFacilityListTblRow = seniorFacilityTable.NewRow();

                                    SeniorFacilityListTblRow["OpportunityId"] = string.IsNullOrEmpty(seniorFacilityList.OpportunityId) ? "" : seniorFacilityList.OpportunityId;
                                    SeniorFacilityListTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(seniorFacilityList.UniqueChildDocumentsId) ? "" : seniorFacilityList.UniqueChildDocumentsId;
                                    SeniorFacilityListTblRow["Ref"] = string.IsNullOrEmpty(seniorFacilityList.Ref) ? "" : seniorFacilityList.Ref;

                                    SeniorFacilityListTblRow["Line"] = string.IsNullOrEmpty(seniorFacilityList.Line) ? "" : seniorFacilityList.Line;
                                    SeniorFacilityListTblRow["FacilityType"] = string.IsNullOrEmpty(seniorFacilityList.FacilityType) ? "" : seniorFacilityList.FacilityType;
                                    SeniorFacilityListTblRow["ProductOwnerCode"] = string.IsNullOrEmpty(seniorFacilityList.ProductOwnerCode) ? "" : seniorFacilityList.ProductOwnerCode;
                                    SeniorFacilityListTblRow["Term"] = string.IsNullOrEmpty(seniorFacilityList.Term) ? "" : seniorFacilityList.Term;
                                    SeniorFacilityListTblRow["Currency"] = string.IsNullOrEmpty(seniorFacilityList.Currency) ? "" : seniorFacilityList.Currency;
                                    SeniorFacilityListTblRow["Day1GrossCommit"] = string.IsNullOrEmpty(seniorFacilityList.Day1GrossCommit) ? "" : seniorFacilityList.Day1GrossCommit;
                                    SeniorFacilityListTblRow["LMCurrentPosition"] = string.IsNullOrEmpty(seniorFacilityList.LMCurrentPosition) ? "" : seniorFacilityList.LMCurrentPosition;
                                    SeniorFacilityListTblRow["ExpectedFinalHold"] = string.IsNullOrEmpty(seniorFacilityList.ExpectedFinalHold) ? "" : seniorFacilityList.ExpectedFinalHold;
                                    SeniorFacilityListTblRow["Day1Utilisation"] = string.IsNullOrEmpty(seniorFacilityList.Day1Utilisation) ? "" : seniorFacilityList.Day1Utilisation;
                                    SeniorFacilityListTblRow["Month1Utilisation"] = string.IsNullOrEmpty(seniorFacilityList.Month1Utilisation) ? "" : seniorFacilityList.Month1Utilisation;
                                    SeniorFacilityListTblRow["Month3Utilisation"] = string.IsNullOrEmpty(seniorFacilityList.Month3Utilisation) ? "" : seniorFacilityList.Month3Utilisation;
                                    SeniorFacilityListTblRow["Margin"] = string.IsNullOrEmpty(seniorFacilityList.Margin) ? "" : seniorFacilityList.Margin;
                                    SeniorFacilityListTblRow["GrossFee"] = string.IsNullOrEmpty(seniorFacilityList.GrossFee) ? "" : seniorFacilityList.GrossFee;
                                    SeniorFacilityListTblRow["NetFee"] = string.IsNullOrEmpty(seniorFacilityList.NetFee) ? "" : seniorFacilityList.NetFee;
                                    SeniorFacilityListTblRow["RecurringFeeType"] = string.IsNullOrEmpty(seniorFacilityList.RecurringFeeType) ? "" : seniorFacilityList.RecurringFeeType;
                                    SeniorFacilityListTblRow["RecurringFee"] = string.IsNullOrEmpty(seniorFacilityList.RecurringFee) ? "" : seniorFacilityList.RecurringFee;
                                    SeniorFacilityListTblRow["CommitmentFee"] = string.IsNullOrEmpty(seniorFacilityList.CommitmentFee) ? "" : seniorFacilityList.CommitmentFee;
                                    SeniorFacilityListTblRow["CommitedUncommited"] = string.IsNullOrEmpty(seniorFacilityList.CommitedUncommited) ? "" : seniorFacilityList.CommitedUncommited;
                                    SeniorFacilityListTblRow["ProbabilityOfDefault"] = string.IsNullOrEmpty(seniorFacilityList.ProbabilityOfDefault) ? "" : seniorFacilityList.ProbabilityOfDefault;
                                    SeniorFacilityListTblRow["LossGivenDefault"] = string.IsNullOrEmpty(seniorFacilityList.LossGivenDefault) ? "" : seniorFacilityList.LossGivenDefault;
                                    SeniorFacilityListTblRow["SanctionedGrossCommit"] = string.IsNullOrEmpty(seniorFacilityList.SanctionedGrossCommit) ? "" : seniorFacilityList.SanctionedGrossCommit;
                                    SeniorFacilityListTblRow["SanctionedHold"] = string.IsNullOrEmpty(seniorFacilityList.SanctionedHold) ? "" : seniorFacilityList.SanctionedHold;
                                    SeniorFacilityListTblRow["PRisMFacilityID"] = string.IsNullOrEmpty(seniorFacilityList.PRisMFacilityID) ? "" : seniorFacilityList.PRisMFacilityID;
                                    SeniorFacilityListTblRow["Securitisation"] = string.IsNullOrEmpty(seniorFacilityList.Securitisation) ? "" : seniorFacilityList.Securitisation;


                                    seniorFacilityTable.Rows.Add(SeniorFacilityListTblRow);
                                }
                            }

                            #endregion


                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistSeniorFacility";
                        sqlBulkCopy.WriteToServer(seniorFacilityTable);
                        Logger.FileLogger("seniorFacility saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool Mezzanine()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                    sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                    sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                    sqlBulkCopy.ColumnMappings.Add("SeniorDealPosition", "SeniorDealPosition");
                    sqlBulkCopy.ColumnMappings.Add("MarketRole", "MarketRole");
                    sqlBulkCopy.ColumnMappings.Add("SFRole", "SFRole");
                    sqlBulkCopy.ColumnMappings.Add("TotalDebtSize", "TotalDebtSize");
                    sqlBulkCopy.ColumnMappings.Add("DealProbability", "DealProbability");
                    sqlBulkCopy.ColumnMappings.Add("ExtCompletionDate", "ExtCompletionDate");
                    sqlBulkCopy.ColumnMappings.Add("ActualCompletionDate", "ActualCompletionDate");
                    sqlBulkCopy.ColumnMappings.Add("ReasonLost", "ReasonLost");
                    sqlBulkCopy.ColumnMappings.Add("LostTo", "LostTo");
                    sqlBulkCopy.ColumnMappings.Add("DetailedReasonLost", "DetailedReasonLost");
                    sqlBulkCopy.ColumnMappings.Add("Competitor", "Competitor");

                    try
                    {
                        var mezzanineTable = new DataTable();
                        mezzanineTable.Columns.Add("OpportunityId", typeof(string));
                        mezzanineTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        mezzanineTable.Columns.Add("Ref", typeof(string));

                        mezzanineTable.Columns.Add("SeniorDealPosition", typeof(string));
                        mezzanineTable.Columns.Add("MarketRole", typeof(string));
                        mezzanineTable.Columns.Add("SFRole", typeof(string));
                        mezzanineTable.Columns.Add("TotalDebtSize", typeof(string));
                        mezzanineTable.Columns.Add("DealProbability", typeof(string));
                        mezzanineTable.Columns.Add("ExtCompletionDate", typeof(string));
                        mezzanineTable.Columns.Add("ActualCompletionDate", typeof(string));
                        mezzanineTable.Columns.Add("ReasonLost", typeof(string));
                        mezzanineTable.Columns.Add("LostTo", typeof(string));
                        mezzanineTable.Columns.Add("DetailedReasonLost", typeof(string));
                        mezzanineTable.Columns.Add("Competitor", typeof(string));

                        foreach (var item in _checkModelList)
                        {

                            #region mezzanine table

                            if (item.Mezzanine != null)
                            {
                                var mezzanineData = item.Mezzanine;

                                DataRow mezzanineTblRow = mezzanineTable.NewRow();

                                mezzanineTblRow["OpportunityId"] = string.IsNullOrEmpty(mezzanineData.OpportunityId) ? "" : mezzanineData.OpportunityId;
                                mezzanineTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(mezzanineData.UniqueChildDocumentsId) ? "" : mezzanineData.Ref;
                                mezzanineTblRow["Ref"] = string.IsNullOrEmpty(mezzanineData.Ref) ? "" : mezzanineData.OpportunityId;

                                mezzanineTblRow["SeniorDealPosition"] = string.IsNullOrEmpty(mezzanineData.SeniorDealPosition) ? "" : mezzanineData.SeniorDealPosition;
                                mezzanineTblRow["MarketRole"] = string.IsNullOrEmpty(mezzanineData.MarketRole) ? "" : mezzanineData.MarketRole;
                                mezzanineTblRow["SFRole"] = string.IsNullOrEmpty(mezzanineData.SFRole) ? "" : mezzanineData.SFRole;
                                mezzanineTblRow["TotalDebtSize"] = string.IsNullOrEmpty(mezzanineData.TotalDebtSize) ? "" : mezzanineData.TotalDebtSize;
                                mezzanineTblRow["DealProbability"] = string.IsNullOrEmpty(mezzanineData.DealProbability) ? "" : mezzanineData.DealProbability;
                                mezzanineTblRow["ExtCompletionDate"] = string.IsNullOrEmpty(mezzanineData.ExtCompletionDate) ? "" : mezzanineData.ExtCompletionDate;
                                mezzanineTblRow["ActualCompletionDate"] = string.IsNullOrEmpty(mezzanineData.ActualCompletionDate) ? "" : mezzanineData.ActualCompletionDate;
                                mezzanineTblRow["ReasonLost"] = string.IsNullOrEmpty(mezzanineData.ReasonLost) ? "" : mezzanineData.ReasonLost;
                                mezzanineTblRow["LostTo"] = string.IsNullOrEmpty(mezzanineData.LostTo) ? "" : mezzanineData.LostTo;
                                mezzanineTblRow["DetailedReasonLost"] = string.IsNullOrEmpty(mezzanineData.DetailedReasonLost) ? "" : mezzanineData.DetailedReasonLost;
                                mezzanineTblRow["Competitor"] = string.IsNullOrEmpty(mezzanineData.Competitor) ? "" : mezzanineData.Competitor;

                                mezzanineTable.Rows.Add(mezzanineTblRow);
                            }

                            #endregion

                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistMezzanine";
                        sqlBulkCopy.WriteToServer(mezzanineTable);
                        Logger.FileLogger("mezzanine saved...");

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool MezzanineFacility()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var mezzanineFacilityTable = new DataTable();
                        mezzanineFacilityTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");

                        mezzanineFacilityTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                        mezzanineFacilityTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                        mezzanineFacilityTable.Columns.Add("Line", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Line", "Line");
                        mezzanineFacilityTable.Columns.Add("FacilityType", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("FacilityType", "FacilityType");
                        mezzanineFacilityTable.Columns.Add("ProductOwnerCode", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ProductOwnerCode", "ProductOwnerCode");
                        mezzanineFacilityTable.Columns.Add("Term", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Term", "Term");
                        mezzanineFacilityTable.Columns.Add("Currency", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Currency", "Currency");
                        mezzanineFacilityTable.Columns.Add("Day1GrossCommit", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Day1GrossCommit", "Day1GrossCommit");
                        mezzanineFacilityTable.Columns.Add("LMCurrentPosition", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LMCurrentPosition", "LMCurrentPosition");
                        mezzanineFacilityTable.Columns.Add("ExpectedFinalHold", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ExpectedFinalHold", "ExpectedFinalHold");
                        mezzanineFacilityTable.Columns.Add("Day1Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Day1Utilisation", "Day1Utilisation");
                        mezzanineFacilityTable.Columns.Add("Month1Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Month1Utilisation", "Month1Utilisation");
                        mezzanineFacilityTable.Columns.Add("Month3Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Month3Utilisation", "Month3Utilisation");
                        mezzanineFacilityTable.Columns.Add("Margin", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Margin", "Margin");
                        mezzanineFacilityTable.Columns.Add("GrossFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("GrossFee", "GrossFee");
                        mezzanineFacilityTable.Columns.Add("NetFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("NetFee", "NetFee");
                        mezzanineFacilityTable.Columns.Add("RecurringFeeType", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RecurringFeeType", "RecurringFeeType");
                        mezzanineFacilityTable.Columns.Add("RecurringFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RecurringFee", "RecurringFee");
                        mezzanineFacilityTable.Columns.Add("CommitmentFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("CommitmentFee", "CommitmentFee");
                        mezzanineFacilityTable.Columns.Add("CommitedUncommited", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("CommitedUncommited", "CommitedUncommited");
                        mezzanineFacilityTable.Columns.Add("ProbabilityOfDefault", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ProbabilityOfDefault", "ProbabilityOfDefault");
                        mezzanineFacilityTable.Columns.Add("LossGivenDefault", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LossGivenDefault", "LossGivenDefault");
                        mezzanineFacilityTable.Columns.Add("SanctionedGrossCommit", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SanctionedGrossCommit", "SanctionedGrossCommit");
                        mezzanineFacilityTable.Columns.Add("SanctionedHold", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SanctionedHold", "SanctionedHold");
                        mezzanineFacilityTable.Columns.Add("PRisMFacilityID", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("PRisMFacilityID", "PRisMFacilityID");
                        mezzanineFacilityTable.Columns.Add("Securitisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Securitisation", "Securitisation");

                        foreach (var item in _checkModelList)
                        {
                            #region MezzanineFacility table

                            if (item.MezzanineFacilityList != null)
                            {
                                var checklistMezzanineFacility = item.MezzanineFacilityList;

                                foreach (var mezzanine in checklistMezzanineFacility)
                                {
                                    DataRow mezzanineFacilityListTblRow = mezzanineFacilityTable.NewRow();

                                    mezzanineFacilityListTblRow["OpportunityId"] = string.IsNullOrEmpty(mezzanine.OpportunityId) ? "" : mezzanine.OpportunityId;
                                    mezzanineFacilityListTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(mezzanine.UniqueChildDocumentsId) ? "" : mezzanine.UniqueChildDocumentsId;
                                    mezzanineFacilityListTblRow["Ref"] = string.IsNullOrEmpty(mezzanine.Ref) ? "" : mezzanine.Ref;

                                    mezzanineFacilityListTblRow["Line"] = string.IsNullOrEmpty(mezzanine.Line) ? "" : mezzanine.Line;
                                    mezzanineFacilityListTblRow["FacilityType"] = string.IsNullOrEmpty(mezzanine.FacilityType) ? "" : mezzanine.FacilityType;
                                    mezzanineFacilityListTblRow["ProductOwnerCode"] = string.IsNullOrEmpty(mezzanine.ProductOwnerCode) ? "" : mezzanine.ProductOwnerCode;
                                    mezzanineFacilityListTblRow["Term"] = string.IsNullOrEmpty(mezzanine.Term) ? "" : mezzanine.Term;
                                    mezzanineFacilityListTblRow["Currency"] = string.IsNullOrEmpty(mezzanine.Currency) ? "" : mezzanine.Currency;
                                    mezzanineFacilityListTblRow["Day1GrossCommit"] = string.IsNullOrEmpty(mezzanine.Day1GrossCommit) ? "" : mezzanine.Day1GrossCommit;
                                    mezzanineFacilityListTblRow["LMCurrentPosition"] = string.IsNullOrEmpty(mezzanine.LMCurrentPosition) ? "" : mezzanine.LMCurrentPosition;
                                    mezzanineFacilityListTblRow["ExpectedFinalHold"] = string.IsNullOrEmpty(mezzanine.ExpectedFinalHold) ? "" : mezzanine.ExpectedFinalHold;
                                    mezzanineFacilityListTblRow["Day1Utilisation"] = string.IsNullOrEmpty(mezzanine.Day1Utilisation) ? "" : mezzanine.Day1Utilisation;
                                    mezzanineFacilityListTblRow["Month1Utilisation"] = string.IsNullOrEmpty(mezzanine.Month1Utilisation) ? "" : mezzanine.Month1Utilisation;
                                    mezzanineFacilityListTblRow["Month3Utilisation"] = string.IsNullOrEmpty(mezzanine.Month3Utilisation) ? "" : mezzanine.Month3Utilisation;
                                    mezzanineFacilityListTblRow["Margin"] = string.IsNullOrEmpty(mezzanine.Margin) ? "" : mezzanine.Margin;
                                    mezzanineFacilityListTblRow["GrossFee"] = string.IsNullOrEmpty(mezzanine.GrossFee) ? "" : mezzanine.GrossFee;
                                    mezzanineFacilityListTblRow["NetFee"] = string.IsNullOrEmpty(mezzanine.NetFee) ? "" : mezzanine.NetFee;
                                    mezzanineFacilityListTblRow["RecurringFeeType"] = string.IsNullOrEmpty(mezzanine.RecurringFeeType) ? "" : mezzanine.RecurringFeeType;
                                    mezzanineFacilityListTblRow["RecurringFee"] = string.IsNullOrEmpty(mezzanine.RecurringFee) ? "" : mezzanine.RecurringFee;
                                    mezzanineFacilityListTblRow["CommitmentFee"] = string.IsNullOrEmpty(mezzanine.CommitmentFee) ? "" : mezzanine.CommitmentFee;
                                    mezzanineFacilityListTblRow["CommitedUncommited"] = string.IsNullOrEmpty(mezzanine.CommitedUncommited) ? "" : mezzanine.CommitedUncommited;
                                    mezzanineFacilityListTblRow["ProbabilityOfDefault"] = string.IsNullOrEmpty(mezzanine.ProbabilityOfDefault) ? "" : mezzanine.ProbabilityOfDefault;
                                    mezzanineFacilityListTblRow["LossGivenDefault"] = string.IsNullOrEmpty(mezzanine.LossGivenDefault) ? "" : mezzanine.LossGivenDefault;
                                    mezzanineFacilityListTblRow["SanctionedGrossCommit"] = string.IsNullOrEmpty(mezzanine.SanctionedGrossCommit) ? "" : mezzanine.SanctionedGrossCommit;
                                    mezzanineFacilityListTblRow["SanctionedHold"] = string.IsNullOrEmpty(mezzanine.SanctionedHold) ? "" : mezzanine.SanctionedHold;
                                    mezzanineFacilityListTblRow["PRisMFacilityID"] = string.IsNullOrEmpty(mezzanine.PRisMFacilityID) ? "" : mezzanine.PRisMFacilityID;
                                    mezzanineFacilityListTblRow["Securitisation"] = string.IsNullOrEmpty(mezzanine.Securitisation) ? "" : mezzanine.Securitisation;

                                    mezzanineFacilityTable.Rows.Add(mezzanineFacilityListTblRow);
                                }
                            }

                            #endregion

                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistMezzanineFacility";
                        sqlBulkCopy.WriteToServer(mezzanineFacilityTable);
                        Logger.FileLogger("mezzanineFacility saved...");


                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool Equity()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var equityTable = new DataTable();
                        equityTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");

                        equityTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");

                        equityTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                        equityTable.Columns.Add("SeniorDealPosition", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SeniorDealPosition", "SeniorDealPosition");
                        equityTable.Columns.Add("MarketRole", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("MarketRole", "MarketRole");
                        equityTable.Columns.Add("SFRole", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SFRole", "SFRole");
                        equityTable.Columns.Add("TotalDebtSize", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("TotalDebtSize", "TotalDebtSize");
                        equityTable.Columns.Add("DealProbability", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DealProbability", "DealProbability");
                        equityTable.Columns.Add("ExtCompletionDate", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ExtCompletionDate", "ExtCompletionDate");
                        equityTable.Columns.Add("ActualCompletionDate", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ActualCompletionDate", "ActualCompletionDate");
                        equityTable.Columns.Add("ReasonLost", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ReasonLost", "ReasonLost");
                        equityTable.Columns.Add("LostTo", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LostTo", "LostTo");
                        equityTable.Columns.Add("DetailedReasonLost", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DetailedReasonLost", "DetailedReasonLost");
                        equityTable.Columns.Add("Competitor", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Competitor", "Competitor");

                        foreach (var item in _checkModelList)
                        {
                            #region Equity table

                            if (item.Equity != null)
                            {
                                var equityData = item.Equity;

                                DataRow equityTblRow = equityTable.NewRow();

                                equityTblRow["OpportunityId"] = string.IsNullOrEmpty(equityData.OpportunityId) ? "" : equityData.OpportunityId;
                                equityTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(equityData.UniqueChildDocumentsId) ? "" : equityData.UniqueChildDocumentsId;
                                equityTblRow["Ref"] = string.IsNullOrEmpty(equityData.Ref) ? "" : equityData.Ref;

                                equityTblRow["SeniorDealPosition"] = string.IsNullOrEmpty(equityData.SeniorDealPosition) ? "" : equityData.SeniorDealPosition;
                                equityTblRow["MarketRole"] = string.IsNullOrEmpty(equityData.MarketRole) ? "" : equityData.MarketRole;
                                equityTblRow["SFRole"] = string.IsNullOrEmpty(equityData.SFRole) ? "" : equityData.SFRole;
                                equityTblRow["TotalDebtSize"] = string.IsNullOrEmpty(equityData.TotalDebtSize) ? "" : equityData.TotalDebtSize;
                                equityTblRow["DealProbability"] = string.IsNullOrEmpty(equityData.DealProbability) ? "" : equityData.DealProbability;
                                equityTblRow["ExtCompletionDate"] = string.IsNullOrEmpty(equityData.ExtCompletionDate) ? "" : equityData.ExtCompletionDate;
                                equityTblRow["ActualCompletionDate"] = string.IsNullOrEmpty(equityData.ActualCompletionDate) ? "" : equityData.ActualCompletionDate;
                                equityTblRow["ReasonLost"] = string.IsNullOrEmpty(equityData.ReasonLost) ? "" : equityData.ReasonLost;
                                equityTblRow["LostTo"] = string.IsNullOrEmpty(equityData.LostTo) ? "" : equityData.LostTo;
                                equityTblRow["DetailedReasonLost"] = string.IsNullOrEmpty(equityData.DetailedReasonLost) ? "" : equityData.DetailedReasonLost;
                                equityTblRow["Competitor"] = string.IsNullOrEmpty(equityData.Competitor) ? "" : equityData.Competitor;

                                equityTable.Rows.Add(equityTblRow);
                            }

                            #endregion

                        }

                        // Opportunity                        
                        sqlBulkCopy.DestinationTableName = "ChecklistEquity";
                        sqlBulkCopy.WriteToServer(equityTable);
                        Logger.FileLogger("mezzanineFacility saved...");

                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool EquityFacility()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        var equityFacilityTable = new DataTable();
                        equityFacilityTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");

                        equityFacilityTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                        equityFacilityTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                        equityFacilityTable.Columns.Add("Line", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Line", "Line");
                        equityFacilityTable.Columns.Add("FacilityType", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("FacilityType", "FacilityType");
                        equityFacilityTable.Columns.Add("ProductOwnerCode", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ProductOwnerCode", "ProductOwnerCode");
                        equityFacilityTable.Columns.Add("Term", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Term", "Term");
                        equityFacilityTable.Columns.Add("Currency", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Currency", "Currency");
                        equityFacilityTable.Columns.Add("Day1GrossCommit", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Day1GrossCommit", "Day1GrossCommit");
                        equityFacilityTable.Columns.Add("LMCurrentPosition", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LMCurrentPosition", "LMCurrentPosition");
                        equityFacilityTable.Columns.Add("ExpectedFinalHold", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ExpectedFinalHold", "ExpectedFinalHold");
                        equityFacilityTable.Columns.Add("Day1Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Day1Utilisation", "Day1Utilisation");
                        equityFacilityTable.Columns.Add("Month1Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Month1Utilisation", "Month1Utilisation");
                        equityFacilityTable.Columns.Add("Month3Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Month3Utilisation", "Month3Utilisation");
                        equityFacilityTable.Columns.Add("Margin", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Margin", "Margin");
                        equityFacilityTable.Columns.Add("GrossFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("GrossFee", "GrossFee");
                        equityFacilityTable.Columns.Add("NetFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("NetFee", "NetFee");
                        equityFacilityTable.Columns.Add("RecurringFeeType", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RecurringFeeType", "RecurringFeeType");
                        equityFacilityTable.Columns.Add("RecurringFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RecurringFee", "RecurringFee");
                        equityFacilityTable.Columns.Add("CommitmentFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("CommitmentFee", "CommitmentFee");
                        equityFacilityTable.Columns.Add("CommitedUncommited", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("CommitedUncommited", "CommitedUncommited");
                        equityFacilityTable.Columns.Add("ProbabilityOfDefault", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ProbabilityOfDefault", "ProbabilityOfDefault");
                        equityFacilityTable.Columns.Add("LossGivenDefault", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LossGivenDefault", "LossGivenDefault");
                        equityFacilityTable.Columns.Add("SanctionedGrossCommit", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SanctionedGrossCommit", "SanctionedGrossCommit");
                        equityFacilityTable.Columns.Add("SanctionedHold", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SanctionedHold", "SanctionedHold");
                        equityFacilityTable.Columns.Add("PRisMFacilityID", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("PRisMFacilityID", "PRisMFacilityID");
                        equityFacilityTable.Columns.Add("Securitisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Securitisation", "Securitisation");

                        foreach (var item in _checkModelList)
                        {
                            #region Equity Facility table

                            if (item.EquityFacilityList != null)
                            {
                                var checklistEquityFacility = item.EquityFacilityList;

                                foreach (var equityFacility in checklistEquityFacility)
                                {
                                    DataRow equityFacilityTblRow = equityFacilityTable.NewRow();

                                    equityFacilityTblRow["OpportunityId"] = string.IsNullOrEmpty(equityFacility.OpportunityId) ? "" : equityFacility.OpportunityId;
                                    equityFacilityTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(equityFacility.UniqueChildDocumentsId) ? "" : equityFacility.UniqueChildDocumentsId;
                                    equityFacilityTblRow["Ref"] = string.IsNullOrEmpty(equityFacility.Ref) ? "" : equityFacility.Ref;

                                    equityFacilityTblRow["Line"] = string.IsNullOrEmpty(equityFacility.Line) ? "" : equityFacility.Line;
                                    equityFacilityTblRow["FacilityType"] = string.IsNullOrEmpty(equityFacility.FacilityType) ? "" : equityFacility.FacilityType;
                                    equityFacilityTblRow["ProductOwnerCode"] = string.IsNullOrEmpty(equityFacility.ProductOwnerCode) ? "" : equityFacility.ProductOwnerCode;
                                    equityFacilityTblRow["Term"] = string.IsNullOrEmpty(equityFacility.Term) ? "" : equityFacility.Term;
                                    equityFacilityTblRow["Currency"] = string.IsNullOrEmpty(equityFacility.Currency) ? "" : equityFacility.Currency;
                                    equityFacilityTblRow["Day1GrossCommit"] = string.IsNullOrEmpty(equityFacility.Day1GrossCommit) ? "" : equityFacility.Day1GrossCommit;
                                    equityFacilityTblRow["LMCurrentPosition"] = string.IsNullOrEmpty(equityFacility.LMCurrentPosition) ? "" : equityFacility.LMCurrentPosition;
                                    equityFacilityTblRow["ExpectedFinalHold"] = string.IsNullOrEmpty(equityFacility.ExpectedFinalHold) ? "" : equityFacility.ExpectedFinalHold;
                                    equityFacilityTblRow["Day1Utilisation"] = string.IsNullOrEmpty(equityFacility.Day1Utilisation) ? "" : equityFacility.Day1Utilisation;
                                    equityFacilityTblRow["Month1Utilisation"] = string.IsNullOrEmpty(equityFacility.Month1Utilisation) ? "" : equityFacility.Month1Utilisation;
                                    equityFacilityTblRow["Month3Utilisation"] = string.IsNullOrEmpty(equityFacility.Month3Utilisation) ? "" : equityFacility.Month3Utilisation;
                                    equityFacilityTblRow["Margin"] = string.IsNullOrEmpty(equityFacility.Margin) ? "" : equityFacility.Margin;
                                    equityFacilityTblRow["GrossFee"] = string.IsNullOrEmpty(equityFacility.GrossFee) ? "" : equityFacility.GrossFee;
                                    equityFacilityTblRow["NetFee"] = string.IsNullOrEmpty(equityFacility.NetFee) ? "" : equityFacility.NetFee;
                                    equityFacilityTblRow["RecurringFeeType"] = string.IsNullOrEmpty(equityFacility.RecurringFeeType) ? "" : equityFacility.RecurringFeeType;
                                    equityFacilityTblRow["RecurringFee"] = string.IsNullOrEmpty(equityFacility.RecurringFee) ? "" : equityFacility.RecurringFee;
                                    equityFacilityTblRow["CommitmentFee"] = string.IsNullOrEmpty(equityFacility.CommitmentFee) ? "" : equityFacility.CommitmentFee;
                                    equityFacilityTblRow["CommitedUncommited"] = string.IsNullOrEmpty(equityFacility.CommitedUncommited) ? "" : equityFacility.CommitedUncommited;
                                    equityFacilityTblRow["ProbabilityOfDefault"] = string.IsNullOrEmpty(equityFacility.ProbabilityOfDefault) ? "" : equityFacility.ProbabilityOfDefault;
                                    equityFacilityTblRow["LossGivenDefault"] = string.IsNullOrEmpty(equityFacility.LossGivenDefault) ? "" : equityFacility.LossGivenDefault;
                                    equityFacilityTblRow["SanctionedGrossCommit"] = string.IsNullOrEmpty(equityFacility.SanctionedGrossCommit) ? "" : equityFacility.SanctionedGrossCommit;
                                    equityFacilityTblRow["SanctionedHold"] = string.IsNullOrEmpty(equityFacility.SanctionedHold) ? "" : equityFacility.SanctionedHold;
                                    equityFacilityTblRow["PRisMFacilityID"] = string.IsNullOrEmpty(equityFacility.PRisMFacilityID) ? "" : equityFacility.PRisMFacilityID;
                                    equityFacilityTblRow["Securitisation"] = string.IsNullOrEmpty(equityFacility.Securitisation) ? "" : equityFacility.Securitisation;

                                    equityFacilityTable.Rows.Add(equityFacilityTblRow);
                                }
                            }

                            #endregion
                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistEquityFacility";
                        sqlBulkCopy.WriteToServer(equityFacilityTable);
                        Logger.FileLogger("equityFacilityTable saved...");

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool Other()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        var otherTable = new DataTable();
                        otherTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                        otherTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                        otherTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                        otherTable.Columns.Add("SeniorDealPosition", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SeniorDealPosition", "SeniorDealPosition");
                        otherTable.Columns.Add("MarketRole", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("MarketRole", "MarketRole");
                        otherTable.Columns.Add("SFRole", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SFRole", "SFRole");
                        otherTable.Columns.Add("TotalDebtSize", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("TotalDebtSize", "TotalDebtSize");
                        otherTable.Columns.Add("DealProbability", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DealProbability", "DealProbability");
                        otherTable.Columns.Add("ExtCompletionDate", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ExtCompletionDate", "ExtCompletionDate");
                        otherTable.Columns.Add("ActualCompletionDate", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ActualCompletionDate", "ActualCompletionDate");
                        otherTable.Columns.Add("ReasonLost", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ReasonLost", "ReasonLost");
                        otherTable.Columns.Add("LostTo", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LostTo", "LostTo");
                        otherTable.Columns.Add("DetailedReasonLost", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DetailedReasonLost", "DetailedReasonLost");
                        otherTable.Columns.Add("Competitor", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Competitor", "Competitor");

                        foreach (var item in _checkModelList)
                        {
                            #region Other table

                            if (item.Other != null)
                            {
                                var otherData = item.Other;

                                DataRow otherTblRow = otherTable.NewRow();

                                otherTblRow["OpportunityId"] = string.IsNullOrEmpty(otherData.OpportunityId) ? "" : otherData.OpportunityId;
                                otherTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(otherData.UniqueChildDocumentsId) ? "" : otherData.UniqueChildDocumentsId;
                                otherTblRow["Ref"] = string.IsNullOrEmpty(otherData.Ref) ? "" : otherData.Ref;

                                otherTblRow["SeniorDealPosition"] = string.IsNullOrEmpty(otherData.SeniorDealPosition) ? "" : otherData.SeniorDealPosition;
                                otherTblRow["MarketRole"] = string.IsNullOrEmpty(otherData.MarketRole) ? "" : otherData.MarketRole;
                                otherTblRow["SFRole"] = string.IsNullOrEmpty(otherData.SFRole) ? "" : otherData.SFRole;
                                otherTblRow["TotalDebtSize"] = string.IsNullOrEmpty(otherData.TotalDebtSize) ? "" : otherData.TotalDebtSize;
                                otherTblRow["DealProbability"] = string.IsNullOrEmpty(otherData.DealProbability) ? "" : otherData.DealProbability;
                                otherTblRow["ExtCompletionDate"] = string.IsNullOrEmpty(otherData.ExtCompletionDate) ? "" : otherData.ExtCompletionDate;
                                otherTblRow["ActualCompletionDate"] = string.IsNullOrEmpty(otherData.ActualCompletionDate) ? "" : otherData.ActualCompletionDate;
                                otherTblRow["ReasonLost"] = string.IsNullOrEmpty(otherData.ReasonLost) ? "" : otherData.ReasonLost;
                                otherTblRow["LostTo"] = string.IsNullOrEmpty(otherData.LostTo) ? "" : otherData.LostTo;
                                otherTblRow["DetailedReasonLost"] = string.IsNullOrEmpty(otherData.DetailedReasonLost) ? "" : otherData.DetailedReasonLost;
                                otherTblRow["Competitor"] = string.IsNullOrEmpty(otherData.Competitor) ? "" : otherData.Competitor;

                                otherTable.Rows.Add(otherTblRow);
                            }

                            #endregion
                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistOther";
                        sqlBulkCopy.WriteToServer(otherTable);
                        Logger.FileLogger("ChecklistOther saved...");

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }
        public bool OtherFacility()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {

                        var otherFacilityTable = new DataTable();
                        otherFacilityTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                        otherFacilityTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                        otherFacilityTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                        otherFacilityTable.Columns.Add("Line", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Line", "Line");
                        otherFacilityTable.Columns.Add("FacilityType", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("FacilityType", "FacilityType");
                        otherFacilityTable.Columns.Add("ProductOwnerCode", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ProductOwnerCode", "ProductOwnerCode");
                        otherFacilityTable.Columns.Add("Term", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Term", "Term");
                        otherFacilityTable.Columns.Add("Currency", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Currency", "Currency");
                        otherFacilityTable.Columns.Add("Day1GrossCommit", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Day1GrossCommit", "Day1GrossCommit");
                        otherFacilityTable.Columns.Add("LMCurrentPosition", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LMCurrentPosition", "LMCurrentPosition");
                        otherFacilityTable.Columns.Add("ExpectedFinalHold", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ExpectedFinalHold", "ExpectedFinalHold");
                        otherFacilityTable.Columns.Add("Day1Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Day1Utilisation", "Day1Utilisation");
                        otherFacilityTable.Columns.Add("Month1Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Month1Utilisation", "Month1Utilisation");
                        otherFacilityTable.Columns.Add("Month3Utilisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Month3Utilisation", "Month3Utilisation");
                        otherFacilityTable.Columns.Add("Margin", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Margin", "Margin");
                        otherFacilityTable.Columns.Add("GrossFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("GrossFee", "GrossFee");
                        otherFacilityTable.Columns.Add("NetFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("NetFee", "NetFee");
                        otherFacilityTable.Columns.Add("RecurringFeeType", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RecurringFeeType", "RecurringFeeType");
                        otherFacilityTable.Columns.Add("RecurringFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RecurringFee", "RecurringFee");
                        otherFacilityTable.Columns.Add("CommitmentFee", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("CommitmentFee", "CommitmentFee");
                        otherFacilityTable.Columns.Add("CommitedUncommited", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("CommitedUncommited", "CommitedUncommited");
                        otherFacilityTable.Columns.Add("ProbabilityOfDefault", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("ProbabilityOfDefault", "ProbabilityOfDefault");
                        otherFacilityTable.Columns.Add("LossGivenDefault", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("LossGivenDefault", "LossGivenDefault");
                        otherFacilityTable.Columns.Add("SanctionedGrossCommit", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SanctionedGrossCommit", "SanctionedGrossCommit");
                        otherFacilityTable.Columns.Add("SanctionedHold", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("SanctionedHold", "SanctionedHold");
                        otherFacilityTable.Columns.Add("PRisMFacilityID", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("PRisMFacilityID", "PRisMFacilityID");
                        otherFacilityTable.Columns.Add("Securitisation", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Securitisation", "Securitisation");

                        foreach (var item in _checkModelList)
                        {

                            #region Other Facility table

                            if (item.OtherFacilityList != null)
                            {
                                var checklistOtherFacilityList = item.OtherFacilityList;

                                foreach (var otherFacilityList in checklistOtherFacilityList)
                                {
                                    DataRow otherFacilityTblRow = otherFacilityTable.NewRow();

                                    otherFacilityTblRow["OpportunityId"] = string.IsNullOrEmpty(otherFacilityList.OpportunityId) ? "" : otherFacilityList.OpportunityId;
                                    otherFacilityTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(otherFacilityList.UniqueChildDocumentsId) ? "" : otherFacilityList.UniqueChildDocumentsId;
                                    otherFacilityTblRow["Ref"] = string.IsNullOrEmpty(otherFacilityList.Ref) ? "" : otherFacilityList.Ref;

                                    otherFacilityTblRow["Line"] = string.IsNullOrEmpty(otherFacilityList.Line) ? "" : otherFacilityList.Line;
                                    otherFacilityTblRow["FacilityType"] = string.IsNullOrEmpty(otherFacilityList.FacilityType) ? "" : otherFacilityList.FacilityType;
                                    otherFacilityTblRow["ProductOwnerCode"] = string.IsNullOrEmpty(otherFacilityList.ProductOwnerCode) ? "" : otherFacilityList.ProductOwnerCode;
                                    otherFacilityTblRow["Term"] = string.IsNullOrEmpty(otherFacilityList.Term) ? "" : otherFacilityList.Term;
                                    otherFacilityTblRow["Currency"] = string.IsNullOrEmpty(otherFacilityList.Currency) ? "" : otherFacilityList.Currency;
                                    otherFacilityTblRow["Day1GrossCommit"] = string.IsNullOrEmpty(otherFacilityList.Day1GrossCommit) ? "" : otherFacilityList.Day1GrossCommit;
                                    otherFacilityTblRow["LMCurrentPosition"] = string.IsNullOrEmpty(otherFacilityList.LMCurrentPosition) ? "" : otherFacilityList.LMCurrentPosition;
                                    otherFacilityTblRow["ExpectedFinalHold"] = string.IsNullOrEmpty(otherFacilityList.ExpectedFinalHold) ? "" : otherFacilityList.ExpectedFinalHold;
                                    otherFacilityTblRow["Day1Utilisation"] = string.IsNullOrEmpty(otherFacilityList.Day1Utilisation) ? "" : otherFacilityList.Day1Utilisation;
                                    otherFacilityTblRow["Month1Utilisation"] = string.IsNullOrEmpty(otherFacilityList.Month1Utilisation) ? "" : otherFacilityList.Month1Utilisation;
                                    otherFacilityTblRow["Month3Utilisation"] = string.IsNullOrEmpty(otherFacilityList.Month3Utilisation) ? "" : otherFacilityList.Month3Utilisation;
                                    otherFacilityTblRow["Margin"] = string.IsNullOrEmpty(otherFacilityList.Margin) ? "" : otherFacilityList.Margin;
                                    otherFacilityTblRow["GrossFee"] = string.IsNullOrEmpty(otherFacilityList.GrossFee) ? "" : otherFacilityList.GrossFee;
                                    otherFacilityTblRow["NetFee"] = string.IsNullOrEmpty(otherFacilityList.NetFee) ? "" : otherFacilityList.NetFee;
                                    otherFacilityTblRow["RecurringFeeType"] = string.IsNullOrEmpty(otherFacilityList.RecurringFeeType) ? "" : otherFacilityList.RecurringFeeType;
                                    otherFacilityTblRow["RecurringFee"] = string.IsNullOrEmpty(otherFacilityList.RecurringFee) ? "" : otherFacilityList.RecurringFee;
                                    otherFacilityTblRow["CommitmentFee"] = string.IsNullOrEmpty(otherFacilityList.CommitmentFee) ? "" : otherFacilityList.CommitmentFee;
                                    otherFacilityTblRow["CommitedUncommited"] = string.IsNullOrEmpty(otherFacilityList.CommitedUncommited) ? "" : otherFacilityList.CommitedUncommited;
                                    otherFacilityTblRow["ProbabilityOfDefault"] = string.IsNullOrEmpty(otherFacilityList.ProbabilityOfDefault) ? "" : otherFacilityList.ProbabilityOfDefault;
                                    otherFacilityTblRow["LossGivenDefault"] = string.IsNullOrEmpty(otherFacilityList.LossGivenDefault) ? "" : otherFacilityList.LossGivenDefault;
                                    otherFacilityTblRow["SanctionedGrossCommit"] = string.IsNullOrEmpty(otherFacilityList.SanctionedGrossCommit) ? "" : otherFacilityList.SanctionedGrossCommit;
                                    otherFacilityTblRow["SanctionedHold"] = string.IsNullOrEmpty(otherFacilityList.SanctionedHold) ? "" : otherFacilityList.SanctionedHold;
                                    otherFacilityTblRow["PRisMFacilityID"] = string.IsNullOrEmpty(otherFacilityList.PRisMFacilityID) ? "" : otherFacilityList.PRisMFacilityID;
                                    otherFacilityTblRow["Securitisation"] = string.IsNullOrEmpty(otherFacilityList.Securitisation) ? "" : otherFacilityList.Securitisation;

                                    otherFacilityTable.Rows.Add(otherFacilityTblRow);
                                }
                            }

                            #endregion

                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "ChecklistOtherFacility";
                        sqlBulkCopy.WriteToServer(otherFacilityTable);
                        Logger.FileLogger("ChecklistOther saved...");

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }

        public bool PostCompletion()
        {
            if (_checkModelList.Count() == 0)
            {
                Logger.FileLogger("No record to insert in CheckList Form becuase it is empty");
                return true;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {
                    sqlBulkCopy.BatchSize = bulkInsertBatchSize;
                    try
                    {
                        #region Inserting data into LotusNotesCall table 

                        var postCompletionTable = new DataTable();
                        postCompletionTable.Columns.Add("OpportunityId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("OpportunityId", "OpportunityId");
                        postCompletionTable.Columns.Add("UniqueChildDocumentsId", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("UniqueChildDocumentsId", "UniqueChildDocumentsId");
                        postCompletionTable.Columns.Add("Ref", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("Ref", "Ref");

                        postCompletionTable.Columns.Add("DealReportable", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("DealReportable", "DealReportable");
                        postCompletionTable.Columns.Add("AssestTransferredtoPortfolioRM", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("AssestTransferredtoPortfolioRM", "AssestTransferredtoPortfolioRM");
                        postCompletionTable.Columns.Add("AssestTransferDate", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("AssestTransferDate", "AssestTransferDate");
                        postCompletionTable.Columns.Add("RepaymentDate", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RepaymentDate", "RepaymentDate");
                        postCompletionTable.Columns.Add("RepaymentRoute", typeof(string));
                        sqlBulkCopy.ColumnMappings.Add("RepaymentRoute", "RepaymentRoute");

                        foreach (var item in _checkModelList)
                        {

                            #region PostCompletion table

                            if (item.PostCompletion != null)
                            {
                                DataRow PostCompletionTblRow = postCompletionTable.NewRow();
                                var checkListpostCompletionTable = item.PostCompletion;

                                PostCompletionTblRow["OpportunityId"] = string.IsNullOrEmpty(checkListpostCompletionTable.OpportunityId) ? "" : checkListpostCompletionTable.OpportunityId;
                                PostCompletionTblRow["UniqueChildDocumentsId"] = string.IsNullOrEmpty(checkListpostCompletionTable.UniqueChildDocumentsId) ? "" : checkListpostCompletionTable.UniqueChildDocumentsId;
                                PostCompletionTblRow["Ref"] = string.IsNullOrEmpty(checkListpostCompletionTable.Ref) ? "" : checkListpostCompletionTable.Ref;

                                PostCompletionTblRow["DealReportable"] = string.IsNullOrEmpty(checkListpostCompletionTable.DealReportable) ? "" : checkListpostCompletionTable.DealReportable;
                                PostCompletionTblRow["AssestTransferredtoPortfolioRM"] = string.IsNullOrEmpty(checkListpostCompletionTable.AssestTransferredtoPortfolioRM) ? "" : checkListpostCompletionTable.AssestTransferredtoPortfolioRM;
                                PostCompletionTblRow["AssestTransferDate"] = string.IsNullOrEmpty(checkListpostCompletionTable.AssestTransferDate) ? "" : checkListpostCompletionTable.AssestTransferDate;
                                PostCompletionTblRow["RepaymentDate"] = string.IsNullOrEmpty(checkListpostCompletionTable.RepaymentDate) ? "" : checkListpostCompletionTable.RepaymentDate;
                                PostCompletionTblRow["RepaymentRoute"] = string.IsNullOrEmpty(checkListpostCompletionTable.RepaymentRoute) ? "" : checkListpostCompletionTable.RepaymentRoute;

                                postCompletionTable.Rows.Add(PostCompletionTblRow);
                            }


                            #endregion

                        }

                        // Opportunity

                        sqlBulkCopy.DestinationTableName = "CheckListPostCompletion";
                        sqlBulkCopy.WriteToServer(postCompletionTable);
                        Logger.FileLogger("postCompletion saved...");



                        #endregion

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        connection.Close();
                        Console.WriteLine(ex.Message);
                        Console.WriteLine(ex.StackTrace);
                        return false;
                    }
                }
            }
        }
    }
}
