﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordiskRentingLotusNotesToSQL
{
    static class Logger
    {
        static string logFilePath = ConfigurationManager.AppSettings["logFilePath"]; 
        public static void FileLogger(string messages, string mesgType = "")
        {
            string paths = Path.GetDirectoryName(logFilePath);

            if ((Directory.Exists(paths) == false) | (string.IsNullOrEmpty(logFilePath) == true))
            {
                Console.WriteLine("[ERROR] Log file directory not found or exist...");

                return;
            }

            if (mesgType == string.Empty)
                mesgType = "DEBUGE";

            StreamWriter writeFile = new StreamWriter(logFilePath, true);
            Console.WriteLine("[ " + mesgType + " ] " + messages);
            writeFile.WriteLine("[ " + mesgType + " ] " + messages);
            writeFile.Close();
        }
    }
}
