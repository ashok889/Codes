﻿// <copyright file="Utilities.cs" company="Microsoft">
// Copyright (c) 2016 All Rights Reserved
// </copyright>
// <author>Microsoft</author>
// <date>11/23/2016 4:21:08 PM</date>
// <summary>Implements the Utilities Workflow Activity.</summary>
namespace Rbs.Crm.UBASU.Workflow
{
    using System;
    using System.Activities;
    using System.ServiceModel;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Workflow;
    using Microsoft.VisualBasic;

    public sealed class PMT : WorkFlowActivityBase
    {
        /// <summary>
        /// Executes the workflow activity.
        /// </summary>
        /// <param name="executionContext">The execution context.</param>
        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            tracingService.Trace("Entered Utilities.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}",
                executionContext.ActivityInstanceId,
                executionContext.WorkflowInstanceId);

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            tracingService.Trace("Utilities.Execute(), Correlation Id: {0}, Initiating User: {1}",
                context.CorrelationId,
                context.InitiatingUserId);

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {

                var rate = this.Rate.Get(executionContext);
                var nper = this.Nper.Get(executionContext);
                var pv = this.Pv.Get(executionContext);

                var payment = Financial.Pmt(rate, nper, pv);
                this.Payment.Set(executionContext, payment);


            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                tracingService.Trace("Exception: {0}", e.ToString());

                // Handle the exception.
                throw;
            }

            tracingService.Trace("Exiting Utilities.Execute(), Correlation Id: {0}", context.CorrelationId);
        }

        // Define Input/Output Arguments
        [RequiredArgument]
        [Input("Rate")]
        public InArgument<double> Rate { get; set; }

        [RequiredArgument]
        [Input("Nper")]
        public InArgument<double> Nper { get; set; }

        [RequiredArgument]
        [Input("Pv")]
        public InArgument<double> Pv { get; set; }

        [Output("Payment")]
        public OutArgument<double> Payment { get; set; }

    }
}