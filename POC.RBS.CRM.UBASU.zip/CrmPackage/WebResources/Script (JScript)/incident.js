if (typeof (Rbs) == "undefined") {
    Rbs = {};
}

if (typeof (Rbs.Crm) == "undefined") {
    Rbs.Crm = {};
}

if (typeof (Rbs.Crm.UBASU) == "undefined") {
    Rbs.Crm.UBASU = {};
}

Rbs.Crm.UBASU.Incident = {
    onLoad: function () {
        var incomeTab = false;
        
        var customerIncomeSubGridOnLoad = function () {
            try {
                if (incomeTab == true) {
                    Xrm.Page.ui.tabs.get("tab_customer_income").setFocus();
                    incomeTab = false;
                }

                var recordCount = Xrm.Page.getControl("subgrid_income").getGrid().getTotalRecordCount();
                if (recordCount == -1) {
                    setTimeout(customerIncomeSubGridOnLoad, 200);
                }
                else {
                    if (recordCount > 0 && (Xrm.Page.getAttribute("rbsm_numberofcustomersincome").getValue() == 0 || Xrm.Page.getAttribute("rbsm_numberofcustomersincome").getValue() == null) ||
                        recordCount !== Xrm.Page.getAttribute("rbsm_numberofcustomersincome").getValue()) {
                        incomeTab = true;
                        Xrm.Page.data.refresh();
                        
                    }
                }
            }
            catch (e) {
            }
        };
        try {
            Xrm.Page.getControl("subgrid_income").addOnLoad(customerIncomeSubGridOnLoad);
        }
        catch (e)
        { }

        Rbs.Crm.UBASU.Incident.defaultCustomer();
        Rbs.Crm.UBASU.Incident.restrictARA();
    },

    defaultCustomer: function () {
        Xrm.Page.getControl("customerid").addPreSearch(Rbs.Crm.UBASU.Incident.addFilterToCustomerOnForm);
        Xrm.Page.getControl("header_process_customerid").addPreSearch(Rbs.Crm.UBASU.Incident.addFilterToCustomerOnBPF);
    },

    restrictARA: function(){
        Xrm.Page.getControl("rbsm_selectedaraid").addPreSearch(Rbs.Crm.UBASU.Incident.addFilterToSelectedARA);
        Xrm.Page.getControl("header_process_rbsm_selectedaraid").addPreSearch(Rbs.Crm.UBASU.Incident.addFilterToSelectedARAOnBPF);
    },

    addFilterToCustomerOnForm: function () {
        var customerAccountFilter = "<filter type='and'><condition attribute='contactid' operator='null' /></filter>";
        Xrm.Page.getControl("customerid").addCustomFilter(customerAccountFilter, "contact");
    },

    addFilterToCustomerOnBPF: function () {
        var customerAccountFilter = "<filter type='and'><condition attribute='contactid' operator='null' /></filter>";
        Xrm.Page.getControl("header_process_customerid").addCustomFilter(customerAccountFilter, "contact");
    },
   

    addFilterToSelectedARA: function () {
        var incidentId = Xrm.Page.data.entity.getId();
        var customerARAFilter = "<filter type='and'><condition attribute='rbsm_caseid' operator='eq' value='" + incidentId + "' /></filter>";
        Xrm.Page.getControl("rbsm_selectedaraid").addCustomFilter(customerARAFilter, "rbsm_alternativerepaymentarrangement");
    },

    addFilterToSelectedARAOnBPF: function () {
        var incidentId = Xrm.Page.data.entity.getId();
        var customerARAFilter = "<filter type='and'><condition attribute='rbsm_caseid' operator='eq' value='" + incidentId + "' /></filter>";
        if (Xrm.Page.getControl("header_process_rbsm_selectedaraid") != null){
            Xrm.Page.getControl("header_process_rbsm_selectedaraid").addCustomFilter(customerARAFilter, "rbsm_alternativerepaymentarrangement");
        }
    },

}