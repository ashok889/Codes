﻿function checkSecurityRole() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description:. The function is to check whether the user has a particular role or not.");
    js.push("\n");
    js.push("  //*******************************************************************");
    js.push("\n");
    js.push("function CheckSecurityRole() {");
    js.push("debbuger;");
    //js.push("var formContext = executionContext.getFormContext();");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    js.push("try {");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        js.push("var " + parameter + "= ['" + labelValue + "']; \n");
    }
    js.push("  var returnFlag = false;");
    js.push("  var count = 0;");
    // js.push("var currentUserRoles = formContext.context.getUserRoles();");
    js.push("var currentUserRoles = globalContext.userSettings.securityRoles;");
    js.push(" for (var i = 0; i < currentUserRoles.length; i++) {");
    js.push(" var userRoleId = currentUserRoles[i];");
    js.push(" var userRoleName = GetRoleName(userRoleId);");
    js.push("        for (var j = 0; j <= Roles.length; j++)");
    js.push("        {");
    js.push("            if (userRoleName == Roles[j]) {");
    js.push("                returnFlag = true;");
    js.push("                count++;");
    js.push("                break;");
    js.push("            }");
    js.push("            else ");
    js.push("                returnFlag = false;");
    js.push("        }");
    js.push("        if(count == Roles.length)");
    js.push("            break;");
    js.push("    }");
    js.push("    return returnFlag;");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in checkSecurityRole\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("\n");
    js.push("//Get Rolename based on RoleId");
    js.push("\n");
    js.push(" function GetRoleName(roleId) {");
    js.push("try {");
    js.push(" var name;");
    js.push("var req = new XMLHttpRequest();");
    js.push(" req.open(\"GET\", Xrm.Utility.getGlobalContext().getClientUrl() + \"/api/data/v9.0/roles(\" + roleId + \")?$select=name,roleid\", false);");
    js.push("  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");");
    js.push("req.setRequestHeader(\"OData-Version\", \"4.0\");");
    js.push("  req.setRequestHeader(\"Accept\", \"application/json\");");
    js.push(" req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");");
    js.push(" req.setRequestHeader(\"Prefer\", \"odata.include-annotations=\"*\"\");");
    js.push(" req.onreadystatechange = function () {");
    js.push(" if (this.readyState === 4) {");
    js.push(" req.onreadystatechange = null;");
    js.push(" if (this.status === 200) {");
    js.push("   var result = JSON.parse(this.response);");
    js.push("  name = result[\"name\"];");
    js.push("  var roleid = result[\"roleid\"];");
    js.push("  return name;");
    js.push("  } else {");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text:\"Error: \" + (e.message || e.description)};") // TODO : error msg
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");
   // js.push(" Xrm.Navigation.alertDialog(this.statusText);");
    js.push("  }");
    js.push(" }");
    js.push(" };");
    js.push("req.send();");
    js.push(" return name;");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in GetRoleName\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" };");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
    return true;
}

function ValidateEmailAddress() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: This function is to validate email addresses.");
    js.push("\n");
    js.push("  //*******************************************************************");
    js.push("\n");
    js.push("function ValidateEmailAddress(executionContext,emailField) {");
    js.push("var formContext = executionContext.getFormContext();");
    js.push("var emailVar = null;");
    js.push("try {");
    js.push("if (formContext.getAttribute(emailField) != null && formContext.getAttribute(emailField) != undefined) {");
    js.push("emailVar = formContext.getAttribute(emailField).getValue();");
    js.push("if (emailVar != null) {");
    js.push("var myEmailRegex = /^[_a-zA-Z0-9]+(\\.[_a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*(\\.[a-zA-Z]{2,15})$/;");
    js.push("if (myEmailRegex.test(emailVar)) {");
    js.push("formContext.getControl(emailField).clearNotification(\"EMAIL\");");
    js.push("formContext.getAttribute(emailField).setValue(emailVar.toLowerCase());");
    js.push("}");
    js.push("else {");
    js.push("formContext.getControl(emailField).setNotification(\"Please enter the valid email\", \"EMAIL\");");
    js.push("}");
    js.push("}");
    js.push("\n");
    js.push("else {");
    js.push("formContext.getControl(emailField).clearNotification(\"EMAIL\");");
    js.push("}");
    js.push("}");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch (e) {");
    js.push("\n");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text:\"Error: \" + (e.message || e.description)};")  // TODO : error msg
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");
    js.push("\n");
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");

    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function ValidatePhoneNumber() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: This function validates a phone number of 10 digits");
    js.push("\n");
    js.push(" // Provide phoneNumberField ");
    js.push("\n");
    js.push("  //*******************************************************************");
    js.push("\n");
    js.push("function ValidatePhoneNumber(executionContext,phoneNumberField) {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("var phoneVar = null;");
    js.push("try {");
    js.push("if (formContext.getAttribute(phoneNumberField) != null && formContext.getAttribute(phoneNumberField) != undefined) {");
    js.push("phoneVar = formContext.getAttribute(phoneNumberField).getValue();");
    js.push("if (phoneVar != null) {");
    js.push("var myPhoneRegex = /^((\\+91[\\-\\s]?)|[0]|(91))?[789]\\d{9}$/g;");
    js.push("var myLandLine1 = /^((91)|[0])?\\d{4}\\d{6}$/;");
    js.push("var myLandLine2 = /^((91)|[0])?\\d{3}\\d{7}$/;");
    js.push("var myLandLine3 = /^((91)|[0])?\\d{2}\\d{8}$/;");
    js.push("if (myPhoneRegex.test(phoneVar) || myLandLine1.test(phoneVar) || myLandLine2.test(phoneVar) || myLandLine3.test(phoneVar)) {");
    js.push("formContext.getControl(phoneNumberField).clearNotification(\"PH\");");
    js.push("}");
    js.push("else {");
    js.push("formContext.getControl(phoneNumberField).setNotification(\"Please enter the valid contact number\", \"PH\");");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("else {");
    js.push("formContext.getControl(phoneNumberField).clearNotification(\"PH\");");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("// try ends here");
    js.push("\n");
    js.push("catch (e) {");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text: \"Error: \" + (e.message || e.description)};")  // TODO : error msg
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");
   // js.push("Xrm.Navigation.alertDialog(\"Error: \" + (e.message || e.description));");
    js.push("}");
    js.push("// catch ends here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function GetFieldValue() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: This function is to get field value");
    js.push("\n");
    js.push("  //*******************************************************************");
    js.push("\n");
    js.push(" function GetFieldValue(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("  var value=null;");
    js.push("   var attribute = formContext.getAttribute(\"fieldName\");");
    js.push("   if(attribute != null){");
    js.push("   var value = attribute.getValue();");
    js.push(" }");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in GetFieldValue\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function SetFieldValue() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: This function is to set field value");
    js.push("\n");
    js.push("  //*******************************************************************");
    js.push("\n");
    js.push("function SetFieldValue(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push(" var value = \"Demo\";");
    js.push("  formContext.getAttribute(\"fieldName\").setValue(value);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in SetFieldValue\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function FilterSubGrid() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to filter the sub grid dynamically based on category of current record and show related records.");
    js.push("\n");
    js.push(" // Replace lookuplogicalname, subgridname and fetchXmlQuery.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function filterSubGrid(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("  var entityName, entityId, entityLabel, lookupFieldObject;");
    js.push(" lookupFieldObject = formContext.data.entity.attributes.get(\"lookuplogicalname\"); // Replace lookuplogicalname");
    js.push("\n");
    js.push(" if (lookupFieldObject.getValue() != null) {");
    js.push("  entityId = lookupFieldObject.getValue()[0].id;");
    js.push(" entityName = lookupFieldObject.getValue()[0].entityType;");
    js.push(" entityLabel = lookupFieldObject.getValue()[0].name;");
    js.push(" }");
    js.push(" var ReqInvenDetails = window.parent.document.getElementById(\"subgridname\"); // Replace subgridname");
    js.push("\n");
    js.push("   var currentInvenWshId = formContext.data.entity.getId();");
    js.push(" if (ReqInvenDetails == null) {");
    js.push(" setTimeout(function () { filterSubGrid(); }, 2000);");
    js.push(" return;");
    js.push("  }");
    js.push("\n");
    js.push("// Replace fetchXmlQuery with your fetch xml code ");
    js.push("\n");
    js.push("  var fetchXml = fetchXmlQuery;");
    js.push("   if (ReqInvenDetails.control != null) {");
    js.push("   ReqInvenDetails.control.SetParameter(\"fetchXml\", fetchXml); //set the fetch xml to the sub grid   ");
    js.push("\n");
    js.push(" ReqInvenDetails.control.refresh(); //refresh the sub grid using the new fetch xml");
    js.push("\n");
    js.push("        }");
    js.push("else");
    js.push("\n");
    js.push("setTimeout(filterSubGrid, 500);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in FilterSubGrid\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("    }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function SendReportByEmail() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to generate a PDF of report, attach the PDF and email it to the Customer.");
    js.push("\n");
    js.push("// In the function getReportingSession(), if your report does not contain any parameter remove ");
    js.push("\n");
    js.push(" // Change the entitylogicalname and recordid per your requirements.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");    
    js.push("function createEmail() {");
    js.push("try {");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    //js.push(" var formContext = executionContext.getFormContext();");
    js.push("var serverURL = globalContext.getClientUrl();");
    js.push("var email = {};");
    js.push("email[\"subject\"] = \"Subject\";");
    js.push("email[\"description\"] = \"description\";");
    js.push("\n");
    js.push("// email[\"regardingobjectid_entitylogicalname@odata.bind\"] = \"/entitylogicalname(recordid)\";");
    js.push("\n");
    js.push("email[\"regardingobjectid_entitylogicalname@odata.bind\"] = \"/entitylogicalname(recordid)\";");
    js.push("\n");
    js.push("//activityparty collection");
    js.push("\n");
    js.push("  var activityparties = [];");
    js.push("\n");
    js.push(" //from party");
    js.push("\n");
    js.push(" var from = {};");
    js.push("\n");
    js.push(" // from[\"partyid_entitylogicalname@odata.bind\"] = \"/entitylogicalname(recordid)\";");
    js.push("\n");
    js.push(" from[\"partyid_entitylogicalname@odata.bind\"] = \"/entitylogicalname(recordid)\";");
    js.push(" from[\"participationtypemask\"] = 1;");
    js.push("\n");
    js.push(" //to party");
    js.push("\n");
    js.push(" var to = {};");
    js.push(" // to[\"partyid_contact@odata.bind\"] = \"/contacts(DC25F349-7F26-E711-811F-5065F38C1521)\";");
    js.push("\n");
    js.push(" to[\"partyid_entitylogicalname@odata.bind\"] = \"/entitylogicalname(recordid)\";");
    js.push(" to[\"participationtypemask\"] = 2;");
    js.push(" activityparties.push(to);");
    js.push(" activityparties.push(from);");
    js.push(" //set to and from to email");
    js.push("\n");
    js.push(" email[\"email_activity_parties\"] = activityparties;");
    js.push(" var req = new XMLHttpRequest();");
    js.push(" req.open(\"POST\", serverURL + \"/api/data/v9.0/emails\", true);");
    js.push("  req.setRequestHeader(\"Accept\", \"application/json\");");
    js.push("  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");");
    js.push(" req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");");
    js.push("  req.setRequestHeader(\"OData-Version\", \"4.0\");");
    js.push("  //  req.setRequestHeader(\"Prefer\", \"return=representation\");");
    js.push("\n");
    js.push("  req.onreadystatechange = function () {");
    js.push(" if (this.readyState == 4 /* complete */) {");
    js.push("   req.onreadystatechange = null;");
    js.push("  if (this.status === 204) {");
    js.push("  var uri = this.getResponseHeader(\"OData-EntityId\");");
    js.push("   var regExp = /\((.*?)\)/;");
    js.push("    var matches = regExp.exec(uri);");
    js.push("   var newEntityId = matches[1];");
    js.push(" var params = getReportingSession();");
    js.push(" EncodePdf(newEntityId, params);");
    js.push("   }");
    js.push(" else {");
    js.push("  var error = JSON.parse(this.response).error;");
    js.push("   alert(error.message);");
    js.push("        }");
    js.push("  }");
    js.push("    };");
    js.push("   req.send(JSON.stringify(email));");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in createEmail\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");

    js.push(" // Change the ReportName and ReportGuid. ");
    js.push("\n");
    js.push(" function getReportingSession() {");
    js.push("try {");
    js.push("\n");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        js.push("var " + parameter + "= \"" + labelValue + "\" \n");
    }
    js.push("\n");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    js.push("\n");
    js.push("  var pth = globalContext.getClientUrl() + \"/CRMReports/rsviewer/QuirksReportViewer.aspx\";");
    js.push("  var retrieveEntityReq = new XMLHttpRequest();");
    js.push("retrieveEntityReq.open(\"POST\", pth, false);");
    js.push("  retrieveEntityReq.setRequestHeader(\"Accept\", \"*\/*\");");
    js.push("  retrieveEntityReq.setRequestHeader(\"Content-Type\", \"application/x-www-form-urlencoded\");");
    js.push("  rptPathString = \"id=%7B\" + ReportGuid + \"%7D\" +");
    js.push("\n");
    js.push("\"&uniquename=\" + globalContext.organizationSettings.uniqueName +");
    js.push("\n");
    js.push("\"&iscustomreport=true&reportnameonsrs=&reportName=\" + ReportName +");
    js.push("\n");
    js.push("\"&isScheduledReport=false\"+");
    js.push("\n");
    js.push(" // \"&p:parameterName=\" + ParameterValue;");
    js.push("\n");
    js.push("retrieveEntityReq.send(rptPathString);");
    js.push("   var x = retrieveEntityReq.responseText.lastIndexOf(\"ReportSession=\");");
    js.push("   var ret = new Array();");
    js.push(" ret[0] = retrieveEntityReq.responseText.substr(x + 14, 24);   //Report session id");
    js.push("\n");
    js.push(" x = retrieveEntityReq.responseText.lastIndexOf(\"ControlID=\");");
    js.push(" ret[1] = retrieveEntityReq.responseText.substr(x + 10, 32);   //Report control id");
    js.push("\n");
    js.push("  return ret;");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in getReportingSession\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n")
    js.push(" }");

    js.push("  // Encode data into PDF file ");
    js.push("\n");
    js.push(" function EncodePdf(emailActivityId, params) {");
    js.push("try {");
    js.push(" var retrieveEntityReq = new XMLHttpRequest();");
    //js.push("  var pth = parent.Xrm.Page.context.getClientUrl() + \"/Reserved.ReportViewerWebControl.axd?ReportSession=\" + params[0] +");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    js.push("\n");
    js.push("  var pth = globalContext.getClientUrl() + \"/Reserved.ReportViewerWebControl.axd?ReportSession=\" + params[0] +");
    js.push("  \"&Culture=1033&CultureOverrides=True&UICulture=1033&UICultureOverrides=True&ReportStack=1&ControlID=\" + params[1] +");
    js.push("  \"&OpType=Export&FileName=Public&ContentDisposition=OnlyHtmlInline&Format=PDF\";");
    js.push("   retrieveEntityReq.open('GET', pth, true);");
    js.push(" retrieveEntityReq.setRequestHeader(\"Accept\", \"*\/*\");");
    js.push(" retrieveEntityReq.responseType = \"arraybuffer\";");
    js.push(" retrieveEntityReq.onreadystatechange = function () {");
    js.push("  if (this.status == 200) {");
    js.push("   var uInt8Array = new Uint8Array(this.response);");
    js.push("    var fileData = Encode64(uInt8Array);");
    js.push("  if (uInt8Array.byteLength > 0) {");
    js.push("  CreateEmailAttachment(emailActivityId, fileData); //Create attachment for the created email");
    js.push("\n");
    js.push("  }");
    js.push("   }");
    js.push("};");
    js.push("   retrieveEntityReq.send();");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in EncodePdf\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");

    js.push("function Encode64(input) {");
    js.push("try {");
    js.push(" var keyStr = \"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\";");
    js.push("var output = StringMaker();");
    js.push(" var chr1, chr2, chr3;");
    js.push(" var enc1, enc2, enc3, enc4;");
    js.push(" var i = 0;");
    js.push("while (i < input.length) {");
    js.push("chr1 = input[i++];");
    js.push("chr2 = input[i++];");
    js.push("chr3 = input[i++];");
    js.push("  enc1 = chr1 >> 2;");
    js.push("   enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);");
    js.push("  enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);");
    js.push("  enc4 = chr3 & 63;");
    js.push("if (isNaN(chr2)) {");
    js.push("enc3 = enc4 = 64;");
    js.push(" } else if (isNaN(chr3)) {");
    js.push("  enc4 = 64;");
    js.push(" }");
    js.push(" output.append(keyStr.charAt(enc1) + keyStr.charAt(enc2) + keyStr.charAt(enc3) + keyStr.charAt(enc4));");
    js.push(" }");
    js.push(" return output.toString();");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in Encode64\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");

    js.push("function StringMaker() {");
    js.push("try {");
    js.push("   var oStr = {};");
    js.push(" oStr.parts = [];");
    js.push("oStr.length = 0;");
    js.push(" oStr.append = function (s) {");
    js.push("  oStr.parts.push(s);");
    js.push("oStr.length += s.length;");
    js.push("}");
    js.push("oStr.prepend = function (s) {");
    js.push(" oStr.parts.unshift(s);");
    js.push("oStr.length += s.length;");
    js.push("    }");
    js.push("oStr.toString = function () {");
    js.push("return oStr.parts.join('');");
    js.push("  }");
    js.push(" return oStr;");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in StringMaker\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");


    js.push("function CreateEmailAttachment(emailId, fileData) {"); // tod0 : pass variable/ declare local variable
    js.push("try {");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();");
   // js.push(" var formContext = executionContext.getFormContext();");
    js.push("var entity = {};");
    js.push(" entity[\"objectid_activitypointer@odata.bind\"] = \"/activitypointers(\" + emailId + \")\";");
    js.push(" entity.objecttypecode = 'email';");
    js.push(" entity.subject = \"File Attachment\";");
    js.push(" entity.body = fileData;");
    js.push("entity.filename = \"pdffilename.pdf\"; // change Pdffilename with the actual file name ");
    js.push("\n");
    js.push(" entity.mimetype = \"application/pdf\";");
    js.push("var req = new XMLHttpRequest();");
    js.push(" req.open(\"POST\", globalContext.getClientUrl() + \"/api/data/v9.0/activitymimeattachments\", true);");
    js.push("  req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");");
    js.push(" req.setRequestHeader(\"OData-Version\", \"4.0\");");
    js.push("   req.setRequestHeader(\"Accept\", \"application/json\");");
    js.push("  req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");");
    js.push("  req.onreadystatechange = function () {");
    js.push("  if (this.readyState === 4) {");
    js.push(" req.onreadystatechange = null;");
    js.push(" if (this.status === 204) {");
    js.push("    var uri = this.getResponseHeader(\"OData-EntityId\");");
    js.push("   var regExp = /\(([^)]+)\)/;");
    js.push("   var matches = regExp.exec(uri);");
    js.push("    var newEntityId = matches[1];");
    js.push("  } else {");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text: this.statusText};") // error msg
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");
    //js.push(" Xrm.Navigation.alertDialog(this.statusText);");
    js.push("  }");
    js.push("   }");
    js.push("};");
    js.push("req.send(JSON.stringify(entity));");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in CreateEmailAttachment\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function OpenReport() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to generate report, and it takes the record’s GUID, ReportName and ReportGuid as its parameter.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function OpenOrderReport(executionContext) {");
    js.push("try {");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();");
   js.push(" var formContext = executionContext.getFormContext();");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        js.push("var " + parameter + "= \"" + labelValue + "\"; \n");
    }
    js.push("var objectTypeCode = formContext.data.attributes.etc;"); // TDOO : test the value
    //js.push("var objectTypeCode = formContext.context.getQueryStringParameters().etc;");
    js.push("var entityGuid =formContext.data.entity.getId();");
    js.push(" var url = globalContext.getClientUrl() + \"/crmreports/viewer/viewer.aspx?action=run&context=records&helpID=\" + ReportName + \".rdl&id={\" + ReportId + \"}&records=\" + entityGuid + \"&recordstype=\" + objectTypeCode;");
    js.push(" window.open(url, null, 800, 600, true, false, null);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in OpenReport\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function SetLookupValue() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push("// *** FUNCTION: SetLookUp");
    js.push("\n");
    js.push("// *** PARAMS:");
    js.push("\n");
    js.push("// ***    fieldName = The name of the lookup field ");
    js.push("\n");
    js.push("// ***    fieldType = The type of field (contact, account etc)");
    js.push("\n");
    js.push("// ***    fieldGUId = The ID of the value to set (GUID)");
    js.push("\n");
    js.push("// ***    value = the value(name) to set");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function SetLookUp(executionContext,fieldName, fieldType, fieldGUId, value) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("var lookupField = formContext.getAttribute(\"fieldName\");");
    js.push("if(lookupField != null){");
    js.push("   var object = new Array();");
    js.push("   object[0] = new Object();");
    js.push(" object[0].id = fieldGUId;");
    js.push(" object[0].name = value;");
    js.push(" object[0].entityType = fieldType;");
    js.push("   lookupField.setValue(object);");
    js.push(" }");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in SetLookupValue\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function ShowHideField() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to enable or disable selected fields");
    js.push("\n");
    js.push(" // Change the parentfieldlogicalname and childfieldlogicalname per our requirement.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function ShowHideField(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push(" var parentfield = formContext.getAttribute(\"parentfieldlogicalname\");");
    js.push(" if (parentfield != null && parentfield.getValue() != null)");
    js.push("\n");
    js.push(" formContext.getControl(\"childfieldlogicalname\").setDisabled(false);");
    js.push(" else");
    js.push("\n");
    js.push(" formContext.getControl(\"childfieldlogicalname\").setDisabled(true);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in ShowHideField\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function HideOptionSetOption() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to dynamically hide the options from option set.");
    js.push("\n");
    js.push(" // Change the \"optionsetlogicalname\" with appropriate field's logical name");
    js.push("\n");
    js.push(" // and value should be the index value(1, 2 or ..) of the option.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function HideOptionSetOption(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("  formContext.getControl(\"optionsetlogicalname\").removeOption(value);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in HideOptionSetOption\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function ShowOptionSetOption() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to dynamically show the options from option set.");
    js.push("\n");
    js.push(" // Change value(1, 2 or ..) and index(1, 2 or ..) and \"optionsetlogicalname\" with appropriate field's logical name.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function ShowOptionSetOption(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push(" var optionValue = formContext.getAttribute(\"optionsetlogicalname\").getOption(value)");
    js.push("\n");
    js.push("  if (optionValue != null) {");
    js.push(" var advanceOption = new Option();");
    js.push(" advanceOption.value = optionValue.value;");
    js.push(" advanceOption.text = optionValue.text;");
    js.push("formContext.getControl(\"optionsetlogicalname\").addOption(advanceOption, index);");
    js.push("}");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in ShowOptionSetOption\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function ShowHideTab() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to set visiblity of tab");
    js.push("\n");
    js.push("// Provide tabname and visible(true/false)");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function ShowHideTab(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        if (parameter.toLowerCase() == 'visible') {
            js.push(" //parameter " + parameter + " must contain value true/false ");
            js.push("\n");
            js.push("var " + parameter + "= " + labelValue + "; \n");
        }
        else {
            js.push("var " + parameter + "= \"" + labelValue + "\"; \n");
        }
    }
    js.push(" formContext.ui.tabs.get(tabname).setVisible(visible);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in ShowHideTab\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function ShowHideSection() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to enable or disable selected tab");
    js.push("\n");
    js.push(" // Provide tab name, section name and visible(true/false)");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function ShowHideSection(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        if (parameter.toLowerCase() == 'visible') {
            js.push(" //parameter " + parameter + " must contain value true/false ");
            js.push("\n");
            js.push("var " + parameter + "= " + labelValue + "; \n");
        }
        else {
            js.push("var " + parameter + "= \"" + labelValue + "\"; \n");
        }
    }
    js.push("  formContext.ui.tabs.get(tabname).sections.get(sectionname).setVisible(visible);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in ShowHideSection\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function FilterLookup() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to apply custom filter to the lookup field. Filter a lookup based on the value of another field on the form.");
    js.push("\n");
    js.push(" // Provide lookup1, lookup2, lookup2 entity name, view display name, Custom fetch Xml and Custom Layout XML.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function FilterLookup(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("   var lookup1 = formContext.getAttribute(\"lookup1\").getValue();");
    js.push(" if (lookup1 != null) {");
    js.push(" lookup1Id = lookup1[0].id.slice(1, -1);");
    js.push(" var viewId = \"{00000000-0000-0000-0000-000000000021}\";");
    js.push("var entityName = \"lookup2Entityname\"");
    js.push("var viewDisplayName = \"DisplayNameForLookup\";");
    js.push("\n");
    js.push("//custom xml");
    js.push("\n");
    js.push("\n");
    js.push("//Fetch XML for filtered records");
    js.push("\n");
    js.push("\n");
    js.push("//Repace these parameters in fetchXml");
    js.push("\n");
    js.push("// entitylogicalname is logical name of entity");
    js.push("\n");
    js.push("// attribute1 is name of entity attribute(field)");
    js.push("\n");
    js.push("// attribute2 is name of entity attribute(field)");
    js.push("\n");
    js.push("// order attribute value contains attribute name according to which sorting is done");
    js.push("\n");

    js.push("\n");
    js.push("var fetchXml = ");
    js.push("\"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>\"+");
    js.push("\n");
    js.push("\"<entity name='entitylogicalname'>\" +");
    js.push("\n");
    js.push("\"<attribute name='attribute1' />\" +");
    js.push("\n");
    js.push("\"<attribute name='attribute2' />\" +");
    js.push("\n");
    js.push("\"<order attribute='attribute name' descending='false' />\" +");
    js.push("\n");
    js.push("\"</entity>\" +");
    js.push("\n");
    js.push("\"</fetch>\";");
    js.push("\n");
    js.push("\n");
    js.push("//Grid Layout for filtered records");
    js.push("\n");
    js.push("\n");
    js.push("//Repace these parameters in layoutXml");
    js.push("\n");
    js.push("// jump Contains the name of the attribute used to filter rows");
    js.push("\n");
    js.push("// id is primarykey of entity for filter");
    js.push("\n");
    js.push("// column1 is name of first column of view");
    js.push("\n");
    js.push("// column2 is name of second column of view");
    js.push("\n");
    js.push("// column3 is name of third column of view");
    js.push("\n");
    js.push("\n");
    js.push("var layoutXml = ");
    js.push("\"<grid name='resultset' object='4230' jump='name' select='1' icon='1' preview='1'>\"+");
    js.push("\n");
    js.push("\"<row name='result' id='primarykey'>\"+");
    js.push("\n");
    js.push("\"<cell name='column1' width='300' />\"+");
    js.push("\n");
    js.push("\"<cell name='column2' width='100' />\"+");
    js.push("\n");
    js.push("\"<cell name='column3' width='100' />\"+");
    js.push("\n");
    js.push("\"</row>\"+");
    js.push("\n");
    js.push("\"</grid>\";");
    js.push("\n");
    js.push("\n");
    js.push("// add the custom view for the lookup field");
    js.push("\n");
    js.push("   formContext.getControl(\"lookup2\").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);");
    js.push("  }");
    js.push("else{");
    js.push("\n");
    js.push("formContext.getAttribute(\"lookup2\").setValue(null);");
    js.push("  }");
    js.push("\n");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in FilterLookup\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}


function SetSubmitMode() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to force an attribute value to be submitted whether it has changed or not.");
    js.push("\n");
    js.push(" // Provide field logical name and mode(always,never or dirty).");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function SetSubmitMode(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        js.push("var " + parameter + "= \"" + labelValue + "\"; \n");
    }
    js.push(" formContext.getAttribute(\"fieldLogicalName\").setSubmitMode(mode);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in SetSubmitMode\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function openEntityForm() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description:Function is used to open an entity form for a new or existing entity record using the options you set as parameters..");
    js.push("\n");
    js.push(" // Provide Entity name, record guid, parameters (all parameters are optional) or windowoptions.");
    js.push("\n");
    js.push(" // Please check below url for details");
    js.push("\n");
    js.push(" //https://community.dynamics.com/crm/b/mscrmcustomization/archive/2016/10/25/xrm-utility-functions-openentityform");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function openEntityForm() {");
    js.push("try {");
    
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        js.push("var " + parameter + "= \"" + labelValue + "\"; \n");
    }

    js.push("var parameters = {};"); js.push("// Parameters are optional");
    js.push("\n");
    js.push("\n");
    js.push("/*Set Text parameters */");
    js.push("\n");
    js.push("parameters[\"Fieldlogicalname\"] = \"John\";"); js.push("//Replace value ");
    js.push("\n");
    js.push("\n");
    js.push("/*Set Option set parameters */");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"optionsetlogicalname\"] = \"1\";"); js.push("//Replace value of optionset  ");
    js.push("\n");
    js.push("\n");
    js.push("/*Set Date time parameters*/");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"datefieldlogicalname\"] = \"10/28/1985\";"); js.push("//Replace value with date");
    js.push("\n");
    js.push("\n");
    js.push("/*Set Number parameters*/");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"fieldlogicalname\"] = \"10000\";"); js.push("//Replace value ");
    js.push("\n");
    js.push("\n");
    js.push("/*Set Customer - Lookup parameters*/");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"<lookuplogicalname>\"] = \"00000000-0000-0000-0000-000000000000\";"); js.push("//Replace lookupid ");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"<lookuplogicalname>name\"] = \"Contoso\";"); js.push("//Replace lookupname ");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"<lookuplogicalname>type\"] = \"account\";"); js.push("//Replace lookuptype ");
    js.push("\n");
    js.push("\n");
    js.push("/*Set simple - Lookup parameters*/");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"<lookuplogicalname>\"] = \"00000000-0000-0000-0000-000000000000\";"); js.push("//Replace lookupid ");
    js.push("\n");
    js.push("\n");
    js.push("parameters[\"<lookuplogicalname>name\"] = \"Contoso Inc\";"); js.push("//Replace lookupname ");
    js.push("\n");
    js.push("\n");
    js.push("var windowOptions ={openInNewWindow: true};");
    // js.push("  Xrm.Navigation.openEntityForm(entityName, recordguid, parameters, windowOptions);");
    js.push("Xrm.Navigation.openForm(entityName).then(function (success) {console.log(success);},function (error) { console.log(error);});") // TODO : 1. Change function pass object 2. Identify entityName reference
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in openEntityForm\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function ChangeForm() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: ChangeForm function is used to change the currently selected form.");
    js.push("\n");
    js.push(" // Provide Form Name.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function ChangeForm(executionContext) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    for (var i = 0; i < $("#InputParameters tbody tr").length; i++) {
        var tr = $("#InputParameters tbody tr")[i];
        var parameter = $(tr).find("td:eq(0)").text();
        var labelValue = $(tr).find("input:first").val();
        js.push("var " + parameter + "= \"" + labelValue + "\"; \n");
    }
    js.push(" var currentForm = formContext.ui.formSelector.getCurrentItem();");
    js.push(" var availableForms = formContext.ui.formSelector.items.get();");
    js.push("if (currentForm.getLabel().toLowerCase() != formName.toLowerCase()) {");
    js.push(" for (var i in availableForms) {");
    js.push(" var form = availableForms[i];");
    js.push(" // try to find a form based on the name");
    js.push("\n");
    js.push("if (form.getLabel().toLowerCase() == formName.toLowerCase()) {");
    js.push("    form.navigate();");
    js.push("  return true;");
    js.push(" }");
    js.push("}  ");
    js.push("}");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in ChangeForm\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function GetLocalLanguage() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function to get the LCID (Locale Id) of User and Organization Base Language.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function GetLocalLanguage() {");
    js.push("try {");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    //js.push(" var formContext = executionContext.getFormContext();");
    js.push("\n");
    js.push(" // Current User Language ID");
    js.push("\n");
    //js.push(" var currUserLcid = formContext.context.getUserLcid();");
    js.push(" var currUserLcid = globalContext.userSettings.languageId;");
    js.push("\n");
    js.push("  // Organization Base Language ID");
    js.push("\n");
    //js.push("  var orgLcid = formContext.context.getOrgLcid();");
    js.push("  var orgLcid = globalContext.organizationSettings.languageId;");
    js.push("\n");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in GetLocalLanguage\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function MultiSelectCheckBox() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function(Unsupported) to convert option set to multi select checkbox list.");
    js.push("\n");
    js.push(" // Please follow below link for configurations");
    js.push("\n");
    js.push(" // http://msdynamicscrm4all.blogspot.in/2011/12/how-create-multi-select-option-set-in.html");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function ConvertToMultiSelect(executionContext,var_sc_optionset, var_sc_optionsetvalue) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push(" var optionSetObj = formContext.getAttribute(var_sc_optionset);");
    js.push("if (optionSetObj != null) {");
    js.push("  var options = optionSetObj.getOptions();");
    js.push("  if (options != null) {");
    js.push(" parent.document.getElementById(var_sc_optionset).style.display = \"none\";");
    js.push("  // Create a DIV container");
    js.push("\n");
    js.push("var addDiv = document.createElement(\"div\");");
    js.push("addDiv.id = var_sc_optionsetvalue + \"_m\";");
    js.push("addDiv.style.width = \"100%\";");
    js.push("addDiv.style.height = \"80px\";");
    js.push("addDiv.style.background = \"#ffffff\";");
    js.push("addDiv.style.color = \"white\";");
    js.push("addDiv.style.overflow = \"auto\";");
    js.push("addDiv.style.border = \"1px #6699cc solid\";");
    js.push("parent.document.getElementById(var_sc_optionset).parentNode.appendChild(addDiv);");
    js.push("// Declaration of variables will be used in the loop depending upon the browser");
    js.push("\n");
    js.push("var initialValue = 0,");
    js.push("maxValue = 0,");
    js.push("nAgt = navigator.userAgent;");
    js.push("if (nAgt.indexOf(\"Firefox\") != -1) { // If the broswer is \"Firefox\"");
    js.push("\n");
    js.push("   initialValue = 1;");
    js.push("maxValue = options.length;");
    js.push("}");
    js.push("else if (nAgt.indexOf(\"Chrome\") != -1 || nAgt.indexOf(\"IE\") != -1) { // If the browser is Chrome or IE");
    js.push("\n");
    js.push(" initialValue = 0;");
    js.push(" maxValue = options.length - 1;");
    js.push("}");
    js.push("else if (nAgt.indexOf(\"Safari\") != -1) { // If the browser is \"Safari\"");
    js.push("\n");
    js.push(" initialValue = 1;");
    js.push(" maxValue = options.length;");
    js.push("}");
    js.push("\n");
    js.push("// Initialize checkbox controls");
    js.push("\n");
    js.push("for (var i = initialValue; i < maxValue; i++) {");
    js.push("var pOption = options[i];");
    js.push("  if (!IsChecked(pOption.value, var_sc_optionsetvalue)) {");
    js.push("var addInput = document.createElement(\"input\");");
    js.push("addInput.type = \"checkbox\";");
    js.push(" addInput.style.border = \"none\";");
    js.push("addInput.style.width = \"25px\";");
    js.push("  addInput.style.align = \"left\";");
    js.push("addInput.style.color = \"#000000\";");
    js.push("  addInput.onclick = function () {");
    js.push(" OnSave(var_sc_optionset, var_sc_optionsetvalue);");
    js.push(" createTable(var_sc_optionsetvalue);");
    js.push("}");
    js.push("}");
    js.push("else {");
    js.push(" var addInput = document.createElement(\"input\");");
    js.push(" addInput.type = \"checkbox\";");
    js.push(" addInput.checked = true;");
    js.push("  addInput.setAttribute(\"checked\", true);");
    js.push(" addInput.checked = \"checked\";");
    js.push(" addInput.defaultChecked = true;");
    js.push("addInput.style.border = \"none\";");
    js.push(" addInput.style.width = \"25px\";");
    js.push(" addInput.style.align = \"left\";");
    js.push(" addInput.style.color = \"#000000\";");
    js.push(" addInput.onclick = function () {");
    js.push(" OnSave(var_sc_optionset, var_sc_optionsetvalue);");
    js.push(" createTable(var_sc_optionsetvalue);");
    js.push(" }");
    js.push(" }");
    js.push("\n");
    js.push("//Create Label");
    js.push("\n");
    js.push(" var addLabel = document.createElement(\"label\");");
    js.push(" addLabel.style.color = \"#000000\";");
    js.push(" addLabel.innerHTML = pOption.text;");
    js.push(" var addBr = document.createElement(\"br\"); // it's a ‘br' flag");
    js.push("\n");
    js.push(" parent.document.getElementById(var_sc_optionset).nextSibling.appendChild(addInput);");
    js.push(" parent.document.getElementById(var_sc_optionset).nextSibling.appendChild(addLabel);");
    js.push(" parent.document.getElementById(var_sc_optionset).nextSibling.appendChild(addBr);");
    js.push("}");
    js.push("}");
    js.push("}");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in MultiSelectCheckBox\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("// Check if it is selected");
    js.push("\n");
    js.push(" function IsChecked(executionContext,pText, optionSetValue) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("  var selectedValue = formContext.getAttribute(optionSetValue).getValue();");
    js.push("  if (selectedValue != \"\" && selectedValue != null) {");
    js.push("  var OSVT = selectedValue.split(\",\");");
    js.push(" for (var i = 0; i < OSVT.length; i++) {");
    js.push("  if (OSVT[i] == pText)");
    js.push(" return true;");
    js.push("  }");
    js.push(" }");
    js.push("return false;");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in IsChecked\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    js.push("\n");
    js.push("\n");
    js.push("// var_sc_optionsetvalue >> Provide logical-name for field which will");
    js.push("\n");
    js.push("  //                         store the multi selected values for Option Set");
    js.push("\n");
    js.push("   // optionSet>> Provide logical-name of Option Set field");
    js.push("\n");
    js.push(" function OnSave(executionContext,optionSet, var_sc_optionsetvalue) {");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("  var OS = parent.document.getElementById(optionSet),");
    js.push("  options = formContext.getAttribute(optionSet).getOptions(),");
    js.push(" getInput = OS.nextSibling.getElementsByTagName(\"input\"),");
    js.push(" result = \"\",");
    js.push(" result1 = \"\";");
    js.push("   var nAgt = navigator.userAgent;");
    js.push(" for (var i = 0; i < getInput.length; i++) {");
    js.push("  if (getInput[i].checked) {");
    js.push("  result += getInput[i].nextSibling.innerHTML + \",\";");
    js.push("  if (nAgt.indexOf(\"Firefox\") != -1) { //If the broswer is \"Firefox\"");
    js.push("\n");
    js.push("  result1 += options[i + 1].value + \",\";");
    js.push(" }");
    js.push(" else if (nAgt.indexOf(\"Chrome\") != -1 || nAgt.indexOf(\"IE\") != -1) { //If the browser is Chrome or IE");
    js.push("\n");
    js.push(" result1 += options[i].value + \",\";");
    js.push("  }");
    js.push("else if (nAgt.indexOf(\"Safari\") != -1) { //If the browser is \"Safari\"");
    js.push("\n");
    js.push("  result1 += options[i + 1].value + \",\";");
    js.push("  }");
    js.push(" }");
    js.push("}");
    js.push(" //save value");
    js.push("\n");
    js.push(" formContext.getAttribute(var_sc_optionsetvalue).setValue(result1);");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in OnSave\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push(" }");
    js.push("\n");
    js.push("\n");
    js.push("// var_sc_optionsetvalue >> Provide logical-name for field which will");
    js.push("\n");
    js.push("  //                         store the multi selected values for Option Set");
    js.push("\n");
    js.push("  function createTable(executionContextvar_sc_optionsetvalue) {   ");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("// Get OptionSet value");
    js.push("\n");
    js.push(" var OptionValue = formContext.getAttribute(var_sc_optionsetvalue),");
    js.push(" c_OptionValue = formContext.getControl(var_sc_optionsetvalue),");
    js.push(" d_OptionValue = var_sc_optionsetvalue + \"_d\";");
    js.push("    if (OptionValue.getValue() != null) {");
    js.push("var OptionValueHtml = \"<div style=\\\"overflow-y:auto;width:100%;display: none; min-height: 5em; max-height: 1000px;\\\">\";");
    js.push("OptionValueHtml += \"<table style='width:100%;height: 100%;'>\",");
    js.push(" OptionValueV = OptionValue.getValue(),");
    js.push("  OptionValueT = OptionValueV.split(\",\"),");
    js.push("cols = 0;");
    js.push(" for (var row = 0; row < OptionValueT.length - 1; row++) {");
    js.push(" OptionValueHtml += \"<tr style='height:20px;'>\";");
    js.push(" for (var i = cols; i < cols + 3; i++) {");
    js.push(" OptionValueHtml += \"<td style='width:33%;'>\";");
    js.push(" if (OptionValueT[i] != null || OptionValueT[i] != undefined) {");
    js.push(" OptionValueHtml += OptionValueT[i];");
    js.push(" }");
    js.push(" OptionValueHtml += \"</td>\";");
    js.push(" }");
    js.push("cols = cols + 3;");
    js.push("  OptionValueHtml += \"</tr>\";");
    js.push("  if (cols >= OptionValueT.length) {");
    js.push(" break;");
    js.push("  }");
    js.push("}");
    js.push("OptionValueHtml += \"</table>\";");
    js.push("OptionValueHtml += \"</div>\";");
    js.push("document.getElementById(d_OptionValue).innerHTML = OptionValueHtml;");
    js.push("}");
    js.push("}//ends try here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("\n")
    js.push("console.log(\"Error in createTable\" + ex.message);");
    js.push("\n")
    js.push("}//ends catch here");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}


function MultiSelectCheckBoxHTML() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function(Supported) to convert option set to multi select checkbox list.");
    js.push("\n");
    js.push(" // Please follow below link for configurations");
    js.push("\n");
    js.push(" // https://mahadeomatre.blogspot.in/2015/02/convert-option-set-to-multi-select.html");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("<html>");
    js.push("<head>");
    js.push("<title><title/>");
    js.push('<script type="text/javascript" src="lat_/CRMRESTBuilder/scripts/jquery1.9.1.min.js"/>');
    js.push("\n");
    js.push(' <script type="text/javascript">');
    js.push("\n");
    js.push("//function will be called when web resource is loaded on Form.");
    js.push("\n");
    js.push(" $(document).ready(function () {");
    js.push(" ConvertDropDownToCheckBoxList();");
    js.push(" });");
    js.push("\n");
    js.push(" //Coverts option list to checkbox list.");
    js.push("\n");
    js.push(" function ConvertDropDownToCheckBoxList(executionContext) {");
    js.push("try{");
    js.push("\n");
   // js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    js.push(" var formContext = executionContext.getFormContext();");
    //js.push(" var dropdownOptions = parent.Xrm.Page.getAttribute(\"optionsetlogicalname\").getOptions();");
    js.push(" var dropdownOptions = formContext.getAttribute(\"optionsetlogicalname\").getOptions();");
   // js.push(" var dropdownOptions = globalContext.getAttribute(\"optionsetlogicalname\").getOptions();");
    // js.push(" var selectedValue = parent.Xrm.Page.getAttribute(\"valuelogicalname\").getValue();");
    //js.push(" var selectedValue = globalContext.getAttribute(\"valuelogicalname\").getValue();");
    js.push(" var selectedValue = formContexte.getAttribute(\"valuelogicalname\").getValue();");
    js.push(" $(dropdownOptions).each(function (i, e) {");
    js.push(" var rText = $(this)[0].text;");
    js.push(" var rvalue = $(this)[0].value;");
    js.push("  var isChecked = false;");
    js.push(" if (rText != '') {");
    js.push("if (selectedValue != null && selectedValue.indexOf(rvalue) != -1)");
    js.push(" isChecked = true;");
    js.push(" /* Remove spaces before input, label word and end tags of input & label*/");
    js.push("   var checkbox = \"<input type='checkbox' name='r'/><label>\" + rText + \"</label>\"");
    js.push("$(checkbox)");
    js.push("  .attr(\"value\", rvalue)");
    js.push(" .attr(\"checked\", isChecked)");
    js.push("  .attr(\"id\", \"id\" + rvalue)");
    js.push(" .click(function () {");
    js.push(" //To Set Picklist Select Values");
    js.push("\n");
    //js.push("  var selectedOption = parent.Xrm.Page.getAttribute(\"valuelogicalname\").getValue();");
    js.push("  var selectedOption = formContext.getAttribute(\"valuelogicalname\").getValue();");
    //js.push("  var selectedOption = globalContext.getAttribute(\"valuelogicalname\").getValue();");
    js.push(" if (this.checked) {");
    js.push(" if (selectedOption == null)");
    js.push("  selectedOption = rvalue+\"\";");
    js.push(" else");
    js.push("  selectedOption = selectedOption + \",\" + rvalue");
    js.push(" }");
    js.push("else {");
    js.push("  var tempSelected = rvalue + \",\";");
    js.push("  if (selectedOption != null) {");
    js.push(" if (selectedOption.indexOf(tempSelected) != -1)");
    js.push("  selectedOption = selectedOption.replace(tempSelected, \"\");");
    js.push(" else");
    js.push(" selectedOption = selectedOption.replace(rvalue, \"\");");
    js.push(" }");
    js.push("}");
    
    // js.push(" globalContext.getAttribute(\"valuelogicalname\").setValue(selectedOption);");
    js.push(" formContext.getAttribute(\"valuelogicalname\").setValue(selectedOption);");
    //js.push("  parent.Xrm.Page.getAttribute(\"valuelogicalname\").setValue(selectedOption);");
    js.push("\n");
    js.push(" //To Set Picklist Select Text");
    js.push("\n");
    //js.push(" var selectedYear = parent.Xrm.Page.getAttribute(\"textlogicalname\").getValue();");
    js.push(" var selectedYear =formContext.getAttribute(\"textlogicalname\").getValue();");
    js.push("  if (this.checked) {");
    js.push("  if (selectedYear == null)");
    js.push("   selectedYear = rText+\"\";");
    js.push("  else");
    js.push("  selectedYear = selectedYear + \",\" + rText");
    js.push(" }");
    js.push("   else {");
    js.push("var tempSelectedtext = rText + \",\";");
    js.push(" if (selectedYear != null) {");
    js.push("if (selectedYear.indexOf(tempSelectedtext) != -1)");
    js.push("  selectedYear = selectedYear.replace(tempSelectedtext, \"\");");
    js.push("  else");
    js.push(" selectedYear = selectedYear.replace(rText, \"\");");
    js.push(" }");
    js.push("}");
    //js.push("parent.Xrm.Page.getAttribute(\"pcl_selectedyeartext\").setValue(selectedYear);");
    js.push("formContext.getAttribute(\"pcl_selectedyeartext\").setValue(selectedYear);");
    js.push("})");
    js.push(" .appendTo(checkboxList);");
    js.push("}");
    js.push("});");
    js.push("}// try ends here");
    js.push("\n");
    js.push("catch(ex) {");
    js.push("console.log(\"Error in MultiSelectCheckBoxHTML\" + ex.message);");
    js.push("}");
    js.push("}");
    js.push("\n");
    js.push("</script>");
    js.push("<meta charset=\"utf-8\">");
    js.push("<meta><meta><meta><meta>");
    js.push("</head>");
    js.push("<body style=\"word-wrap: break-word;\">");
    js.push(" <div id=\"checkboxList\">");
    js.push(" </div>");
    js.push("</body>");
    js.push("</html>");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function compositeNameFieldValidation() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function used to validate compositename fields (firstname,lastname,fullname) so only alphabets are allowed.");
    js.push("\n");
    js.push("// Replace (textFieldName1,textFieldName2,textFieldName3) with logical name of fields.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push(" function compositeNameFieldValidation(executionContext,textFieldName1, textFieldName2, textFieldName3) {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("var globalContext= Xrm.Utility.getGlobalContext();")
    js.push("var isCrmForMobile = (globalContext.client.getClient() == \"Mobile\");");
    js.push("if (!isCrmForMobile) {");
    js.push("try {");
    js.push("var textField1 = null;");
    js.push("if (formContext.getAttribute(textFieldName1) != null && formContext.getAttribute(textFieldName1) != undefined) {");
    js.push("textField1 = formContext.getAttribute(textFieldName1).getValue();");
    js.push("}");
    js.push("var textField2 = null;");
    js.push("if (formContext.getAttribute(textFieldName2) != null && formContext.getAttribute(textFieldName2) != undefined) {");
    js.push("textField2 = formContext.getAttribute(textFieldName2).getValue();");
    js.push("}");
    js.push("var textField3 = null;");
    js.push("if (formContext.getAttribute(textFieldName3) != null && formContext.getAttribute(textFieldName3) != undefined) {");
    js.push("textField3 = formContext.getAttribute(textFieldName3).getValue();");
    js.push("}");
    js.push("if ((textField1 != null || textField2 != null || textField3 != null)) {");
    js.push("var validateRegex = /[^a-z|^A-Z|^\s]/;");
    js.push("if (!validateRegex.test(textField1) && !validateRegex.test(textField2)) {");
    js.push("formContext.getControl(textFieldName3).clearNotification(\"TXT\");");
    js.push("}");
    js.push(" else {");
    js.push(" formContext.getControl(textFieldName3).setNotification(\"Please enter only alphabets (a to z) or (A to Z) with spaces\", \"TXT\");");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("//try ends here");
    js.push("\n");
    js.push(" catch (e) {");
    js.push("\n");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text: \"Error: \" + (e.message || e.description)};")
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");

    //js.push("Xrm.Utility.alertDialog(\"Error: \" + (e.message || e.description));");
    js.push("}");
    js.push("// catch ends here");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

function textFieldValidation() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function is used to validate text field so that only aphabets are allowed.");
    js.push("\n");
    js.push("// Replace (textFieldName) with logical name of fields.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function textFieldValidation(executionContext,textFieldName) {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("var textField = null;");
    js.push("try {");
    js.push("if (formContext.getAttribute(textFieldName) != null && formContext.getAttribute(textFieldName) != undefined) {");
    js.push("textField = formContext.getAttribute(textFieldName).getValue();");
    js.push("}");
    js.push("if (textField != null) {");
    js.push("var validateRegex = /[^a-z|^A-Z|^\s]/;");
    js.push("if (!validateRegex.test(textField)) {");
    js.push("formContext.getControl(textFieldName).clearNotification(\"TXTONLY\");");
    js.push("}");
    js.push("\n");
    js.push("else {");
    js.push("formContext.getControl(textFieldName).setNotification(\"Please enter only alphabets (a to z) or (A to Z) with spaces\", \"TXTONLY\");");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("// try ends here");
    js.push("\n");
    js.push("\n");
    js.push("catch (e) {");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text:\"Error: \" + (e.message || e.description)};")
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");

    //js.push("Xrm.Navigation.alertDialog(\"Error: \" + (e.message || e.description));");
    js.push("}");
    js.push("// catch ends here");
    js.push("\n");
    js.push("}");
    js.push("\n");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}


function validatePastDate() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function used to validate selected date is past date or not. ");
    js.push("\n");
    js.push("// Replace (dateFieldName) with logical name of field.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function validatePastDate(executionContext,dateFieldName) {");
    js.push("var dateFiledValue = null;");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("if (formContext.getAttribute(dateFieldName) != null && formContext.getAttribute(dateFieldName) != undefined) {");
    js.push("dateFiledValue = formContext.getAttribute(dateFieldName).getValue();");
    js.push("}");
    js.push("if (dateFiledValue != null) {");
    js.push("var currentDate = new Date();");
    js.push("if (currentDate >= dateFiledValue) {");
    js.push("formContext.getControl(dateFieldName).clearNotification(\"PASTDATE\");");
    js.push("}");
    js.push(" else {");
    js.push("formContext.getControl(dateFieldName).setNotification(\"Date must be past date\", \"PASTDATE\");");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("// try ends here");
    js.push("\n");
    js.push("catch (e) {");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text: \"Error: \" + (e.message || e.description)};")
    js.push("var alertOptions = { height: 120, width: 260 };")
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");

    //js.push("Xrm.Navigation.alertDialog(\"Error: \" + (e.message || e.description));");
    js.push("}");
    js.push("// catch ends here");
    js.push("\n");
    js.push("}");
    js.push("\n");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}


function validateFutureDate() {
    var js = [];
    js.push("//********************************************************************");
    js.push("\n");
    js.push("// Author: ");
    js.push("\n");
    js.push("// Created on: ");
    js.push("\n");
    js.push(" // Description: Function used to validate selected date is future date.");
    js.push("\n");
    js.push("// Replace (dateFieldName) with logical name of field.");
    js.push("\n");
    js.push(" //*******************************************************************");
    js.push("\n");
    js.push("function validateFutureDate(executionContext,dateFieldName) {");
    js.push("var dateFiledValue = null;");
    js.push("try {");
    js.push(" var formContext = executionContext.getFormContext();");
    js.push("if (formContext.getAttribute(dateFieldName) != null && formContext.getAttribute(dateFieldName) != undefined) {");
    js.push("dateFiledValue = formContext.getAttribute(dateFieldName).getValue();");
    js.push("}");
    js.push("if (dateFiledValue != null) {");
    js.push("var currentDate = new Date();");
    js.push("if (currentDate <= dateFiledValue) {");
    js.push("formContext.getControl(dateFieldName).clearNotification(\"FUTUREDATE\");");
    js.push("}");
    js.push("else {");
    js.push("formContext.getControl(dateFieldName).setNotification(\"Date must be future date\", \"FUTUREDATE\");");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("\n");
    js.push("}");
    js.push("// try ends here");
    js.push("\n");
    js.push(" catch (e) {");
    js.push("var alertString={confirmButtonLabel:\"Yes\", text: \"Error: \" + (e.message || e.description)};")
    js.push("var alertOptions = { height: 120, width: 260 };")
    //js.push("Xrm.Navigation.openAlertDialog(\"Error: \" + (e.message || e.description),alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);};"); // TODO : pass msg as  object
    js.push("Xrm.Navigation.openAlertDialog(alertString,alertOptions).then(function success(result) {console.log(\"Alert dialog closed\");}, function (error) { console.log(error.message);});");
    

    //js.push("Xrm.Navigation.alertDialog(\"Error: \" + (e.message || e.description));");
    js.push("\n");
    js.push("}");
    js.push("// catch ends here");
    js.push("\n");
    js.push("}");
    js.push("\n");
    Xrm.RESTBuilder.DisplayOutPut(window.js_beautify(js.join(""), { indent_size: 4 }));
}

