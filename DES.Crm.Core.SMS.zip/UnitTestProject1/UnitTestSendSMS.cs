﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DES.Crm.Core.SMS.Workflow;
using DES.Crm.Core.Common.Security;
using FakeXrmEasy;
using Microsoft.Xrm.Sdk;
using DES.Crm.Core.SMS.Common.CRMClasses;
using System.Collections.Generic;

namespace DES.Crm.Core.SMS.UnitTest
{
    [TestClass]
    public class UnitTestSendSMS
    {
        [TestMethod]
        public void SendSimpleMessage()
        {
            var fakedContext = new XrmFakedContext { };

            var entityProvider = new rbs_SMSProvider() { Id = Guid.NewGuid() }; ;
            var provider = new rbs_SMSProvider
            {
                Id = Guid.NewGuid(),
                rbs_Name = "IMIMobile",
                StatusCodeEnum = rbs_SMSProvider_StatusCode.Active
            };
            var param1 = new rbs_SMSProviderParameter
            {
                Id = Guid.NewGuid(),
                rbs_SMSProviderId = provider.ToEntityReference(),
                rbs_Key = "SMSFunctionUri",
                rbs_Encrypt = false,
                StatusCodeEnum = rbs_SMSProviderParameter_StatusCode.Active,
                rbs_Value = "https://hbpsmstest.azurewebsites.net/api/SendSMS?code=l5yhUAeR2aA//kSkU8N2luCYZSjiAWdRAFL21BQRCMHUNoJ1IOzj0Q=="
            };

            var param2 = new rbs_SMSProviderParameter
            {
                Id = Guid.NewGuid(),
                rbs_SMSProviderId = provider.ToEntityReference(),
                rbs_Key = "AlphaTag",
                rbs_Encrypt = false,
                StatusCodeEnum = rbs_SMSProviderParameter_StatusCode.Active,
                rbs_Value = "UlsterBank"
            };

            var param3 = new rbs_SMSProviderParameter
            {
                Id = Guid.NewGuid(),
                rbs_SMSProviderId = provider.ToEntityReference(),
                rbs_Key = "ZeroReplaceCode",
                rbs_Encrypt = false,
                StatusCodeEnum = rbs_SMSProviderParameter_StatusCode.Active,
                rbs_Value = "44"
            };

            fakedContext.Initialize(new List<Entity>() {
               provider, param1, param2, param3
            });

            var fakedWorkflowContext = fakedContext.GetDefaultWorkflowContext();

            var inputs = new Dictionary<string, object>
            {
                {"NumericDestination", "07816978385"},
                {"Message", "Hello Ant"}
            };

            var workflow = new SendSMS();

            fakedContext.ExecuteCodeActivity(fakedWorkflowContext, inputs, workflow);
           
        }
    }
}

