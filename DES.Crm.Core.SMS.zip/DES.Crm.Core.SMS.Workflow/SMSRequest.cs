﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DES.Crm.Core.SMS.Workflow
{
    public class SMSRequest
    {
        public string NumericDestination { get; set; }
        public string Message { get; set; }
        public string AlphaTag { get; set; }
    }
}
