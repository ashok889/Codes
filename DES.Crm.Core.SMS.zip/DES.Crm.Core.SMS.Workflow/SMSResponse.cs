﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace DES.Crm.Core.SMS.Workflow
{
    [DataContract]
    public class SMSResponse
    {
        public SMSResponse()
        {

        }

        [DataMember(Name = "mtMessageId")]
        public int MessageId { get; set; }
        [DataMember(Name = "status")]
        public ResponseStatus Status { get; set; }
        [DataMember(Name = "custMessageId")]
        public int CustMessageId { get; set; }
        [DataMember(Name = "custMessageRef")]
        public object CustMessageRef { get; set; }
    }

    [DataContract]
    public class ResponseStatus
    {
        [DataMember(Name = "value")]
        public int Value { get; set; }
        [DataMember(Name = "code")]
        public string Code { get; set; }
        [DataMember(Name = "text")]
        public string Text { get; set; }
    }

}
