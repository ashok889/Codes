﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.SMS.Common.CRMClasses;
using Microsoft.Xrm.Sdk;

namespace DES.Crm.Core.SMS.Workflow
{
    public static class SMSMessageFactory
    {
        public static ISMSMessageService GetSMSService(string provider, List<rbs_SMSProviderParameter> parameters, IOrganizationService crmService, ITracingService crmTracing)
        {
            ISMSMessageService service = null;

            switch (provider)
            {
                case "IMIMobile":
                    service = new IMIMobileSMSService(parameters, crmService, crmTracing);
                    break;
                default:
                    break;
            }

            return service;
        }
    }
}
