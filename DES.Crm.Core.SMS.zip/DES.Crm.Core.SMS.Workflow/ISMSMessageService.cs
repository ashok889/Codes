﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.SMS.Workflow
{
    public interface ISMSMessageService
    {
        Task<string> Send(SMSRequest request);
    }
}
