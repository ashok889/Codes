﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.SMS.Common.CRMClasses;
using DES.Crm.Core.Common.Security;
using System.Linq;
using Microsoft.Xrm.Sdk;
using System.Net;

namespace DES.Crm.Core.SMS.Workflow
{
    public class IMIMobileSMSService : ISMSMessageService
    {
        private readonly rbs_SMSProviderParameter functionEndpoint;
        private readonly rbs_SMSProviderParameter alphaTag;
        private readonly rbs_SMSProviderParameter zeroReplaceCode;
        private readonly IOrganizationService service;
        private readonly ITracingService tracing;

        public IMIMobileSMSService(List<rbs_SMSProviderParameter> parameters, IOrganizationService service, ITracingService tracing)
        {
            // decrypt parameters if encrypted
            foreach (var parameter in parameters)
            {
                parameter.rbs_Value = (parameter.rbs_Encrypt == true ? DataProtect.DecryptString(parameter.rbs_Value) : parameter.rbs_Value);
            }

            this.functionEndpoint = parameters.SingleOrDefault(a => a.rbs_Key == "SMSFunctionUri");
            this.alphaTag = parameters.SingleOrDefault(a => a.rbs_Key == "AlphaTag");
            this.zeroReplaceCode = parameters.SingleOrDefault(a => a.rbs_Key == "ZeroReplaceCode");
            this.service = service;
            this.tracing = tracing;

            if (this.functionEndpoint == null)
            { 
                throw new Exception("Missing provider parameter: SMSFunctionUri");
            }
            if (this.alphaTag == null)
            {
                throw new Exception("Missing provider parameter: AlphaTag");
            }
            if (this.zeroReplaceCode == null)
            {
                throw new Exception("Missing provider parameter: ZeroReplaceCode");
            }
        }


        public async Task<string> Send(SMSRequest request)
        {
            var mobileNumber = request.NumericDestination;
            if (mobileNumber != null && mobileNumber.Length > 0 && this.zeroReplaceCode.rbs_Value.Length > 0)
            {
                if (mobileNumber.StartsWith("0"))
                    {
                        var noZeroMobileNumber = mobileNumber.TrimStart(new char[] { '0' });
                        mobileNumber = this.zeroReplaceCode.rbs_Value + noZeroMobileNumber;
                    }
            }

            using (HttpClient httpClient = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                
                var JSON = "{\"alphaTag\": \"" + this.alphaTag.rbs_Value + "\",\"numericDestination\":" + mobileNumber +
                    ",\"messageText\":\"" + request.Message + "\"}";
                var content = new StringContent(JSON,
                    Encoding.ASCII, "application/json");
                var result = await httpClient.PostAsync(functionEndpoint.rbs_Value, content);
                string outputContent = null;
                if (result.Content != null)
                {
                    outputContent = await result.Content.ReadAsStringAsync();
                }
                return outputContent;
            }
        }
    }
}