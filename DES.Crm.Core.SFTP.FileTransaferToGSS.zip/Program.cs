﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace DES.Crm.Core.SFTP.FileTransaferToGSS
{
    class Program
    {
        static void Main(string[] args)
        {
            coreFunctions objCoreFunctions = new coreFunctions();
            //Declare variables required to connect SFTP server
            string host = "";
            int port = 22;
            string localPath = "";
            string sFTPFolder = "";
            int retryCount = 0;
            int maxRetry = 1;
            string userName = "";

            //assign values from App config 
            //Number of times connect can retried if failed
            maxRetry = int.Parse(System.Configuration.ConfigurationSettings.AppSettings["MaxRetries"].ToString());
            //port to connect with SFTP
            port = int.Parse(System.Configuration.ConfigurationSettings.AppSettings["port"].ToString());
            //local path of folder to pick files and do the SFTP tranfer
            localPath = System.Configuration.ConfigurationSettings.AppSettings["LocalFileLocation"].ToString();
            //sFTP folder to move the file
            sFTPFolder = System.Configuration.ConfigurationSettings.AppSettings["sFTPFolder"].ToString();
            host= System.Configuration.ConfigurationSettings.AppSettings["hostname"].ToString();
            userName= System.Configuration.ConfigurationSettings.AppSettings["username"].ToString();
            //get the name of files from the local folder to be tranferred to SFTP server
            string[] fileList = Directory.GetFiles(localPath);
            foreach (string file in fileList)
            {
                objCoreFunctions.sFTPTransfer(host, port, localPath, sFTPFolder, userName, maxRetry, retryCount);
            }


        }
    }
}
