﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Renci.SshNet;
namespace DES.Crm.Core.SFTP.FileTransaferToGSS
{
    class coreFunctions
    {
        /// <summary>
        /// Transfer file from Local Server to SFTP destination server
        /// </summary>
        /// <returns></returns>
        internal void sFTPTransfer(string host, int port, string localPath, string sFTPFolder, string userName, int maxRetryCount, int retryCount)
        {
            // set the retry to 0

            try
            {


                // Connect to sFTP server
                Console.WriteLine("Create client Object");
                //     SftpClient sftpClient = new SftpClient(host, port, userName, new PrivateKeyFile(@"C:\TEMP\RBS\Projects\JADE\PuttyGen\NewOpenSSHPrivateKey"));

                SftpClient sftpClient = new SftpClient(host, port, userName, new PrivateKeyFile(System.Configuration.ConfigurationSettings.AppSettings["SFTPPrivateKeypath"].ToString()));

                if (!sftpClient.IsConnected)
                {
                    try
                    {
                        sftpClient.Connect();
                        Console.WriteLine("Connect to server");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Unable to connect the GSS server -" + ex.Message);
                    }
                }

                // change the directory respective to bank
                sftpClient.ChangeDirectory("/" + sFTPFolder);
                Console.WriteLine("Creating FileStream object to stream a file");

                FileStream fs = new FileStream(localPath, FileMode.Open);

                // sftpClient.BufferSize = 1024;
                // Upload the files
                sftpClient.UploadFile(fs, Path.GetFileName(localPath));
                Console.WriteLine("File uploaded to server");
                //Dispose the SFTP connection
                sftpClient.Dispose();
                Console.WriteLine("Connection disposed with GSS server");

            }
            catch (Exception ex)
            {
                if (retryCount < maxRetryCount)
                {
                    retryCount++;
                    sFTPTransfer(host, port, localPath, sFTPFolder, userName, maxRetryCount, retryCount);
                }
                throw new Exception(string.Format("Retried for {0} times.Error: Unable to transfer file to sFTP location" + ex.Message, retryCount));
            }
        }
    }
}
