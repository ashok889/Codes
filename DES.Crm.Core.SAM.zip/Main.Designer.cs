﻿namespace DES.Crm.Core.SAM
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbOrganisation = new System.Windows.Forms.ComboBox();
            this.lblOrganisation = new System.Windows.Forms.Label();
            this.lblInstructionsL1 = new System.Windows.Forms.Label();
            this.lblInstructionsL2 = new System.Windows.Forms.Label();
            this.lblInstructionsL3 = new System.Windows.Forms.Label();
            this.lstUsers = new System.Windows.Forms.ListBox();
            this.lblUsers = new System.Windows.Forms.Label();
            this.lstMainPosition = new System.Windows.Forms.ListBox();
            this.lstOtherPositions = new System.Windows.Forms.ListBox();
            this.lstAvailablePositions = new System.Windows.Forms.ListBox();
            this.lblMainPosition = new System.Windows.Forms.Label();
            this.lblOtherPositions = new System.Windows.Forms.Label();
            this.lblAvailablePositions = new System.Windows.Forms.Label();
            this.btnAddMainPosition = new System.Windows.Forms.Button();
            this.btnAddOtherPosition = new System.Windows.Forms.Button();
            this.btnRemoveMainPosition = new System.Windows.Forms.Button();
            this.btnRemoveOtherPosition = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbOrganisation
            // 
            this.cmbOrganisation.FormattingEnabled = true;
            this.cmbOrganisation.Location = new System.Drawing.Point(123, 86);
            this.cmbOrganisation.Name = "cmbOrganisation";
            this.cmbOrganisation.Size = new System.Drawing.Size(270, 21);
            this.cmbOrganisation.TabIndex = 1;
            this.cmbOrganisation.SelectedIndexChanged += new System.EventHandler(this.cmbOrganisation_SelectedIndexChanged);
            // 
            // lblOrganisation
            // 
            this.lblOrganisation.AutoSize = true;
            this.lblOrganisation.Location = new System.Drawing.Point(12, 88);
            this.lblOrganisation.Name = "lblOrganisation";
            this.lblOrganisation.Size = new System.Drawing.Size(99, 13);
            this.lblOrganisation.TabIndex = 2;
            this.lblOrganisation.Text = "Select Organisation";
            // 
            // lblInstructionsL1
            // 
            this.lblInstructionsL1.AutoSize = true;
            this.lblInstructionsL1.Location = new System.Drawing.Point(12, 9);
            this.lblInstructionsL1.Name = "lblInstructionsL1";
            this.lblInstructionsL1.Size = new System.Drawing.Size(330, 13);
            this.lblInstructionsL1.TabIndex = 3;
            this.lblInstructionsL1.Text = "Welcome to the SAM Application for EE BAS Dynamics 365 Projects";
            // 
            // lblInstructionsL2
            // 
            this.lblInstructionsL2.AutoSize = true;
            this.lblInstructionsL2.Location = new System.Drawing.Point(12, 33);
            this.lblInstructionsL2.Name = "lblInstructionsL2";
            this.lblInstructionsL2.Size = new System.Drawing.Size(474, 13);
            this.lblInstructionsL2.TabIndex = 4;
            this.lblInstructionsL2.Text = "Please select the Organisation you want to manage to load Users and Positions in " +
    "one Organisation";
            // 
            // lblInstructionsL3
            // 
            this.lblInstructionsL3.AutoSize = true;
            this.lblInstructionsL3.Location = new System.Drawing.Point(12, 61);
            this.lblInstructionsL3.Name = "lblInstructionsL3";
            this.lblInstructionsL3.Size = new System.Drawing.Size(255, 13);
            this.lblInstructionsL3.TabIndex = 5;
            this.lblInstructionsL3.Text = "Use buttons to Add/Remove Main or Other Positions";
            // 
            // lstUsers
            // 
            this.lstUsers.FormattingEnabled = true;
            this.lstUsers.Location = new System.Drawing.Point(123, 124);
            this.lstUsers.Name = "lstUsers";
            this.lstUsers.Size = new System.Drawing.Size(270, 264);
            this.lstUsers.TabIndex = 7;
            this.lstUsers.SelectedIndexChanged += new System.EventHandler(this.lstUsers_SelectedIndexChanged);
            // 
            // lblUsers
            // 
            this.lblUsers.AutoSize = true;
            this.lblUsers.Location = new System.Drawing.Point(12, 126);
            this.lblUsers.Name = "lblUsers";
            this.lblUsers.Size = new System.Drawing.Size(62, 13);
            this.lblUsers.TabIndex = 8;
            this.lblUsers.Text = "Select User";
            // 
            // lstMainPosition
            // 
            this.lstMainPosition.FormattingEnabled = true;
            this.lstMainPosition.Location = new System.Drawing.Point(417, 124);
            this.lstMainPosition.Name = "lstMainPosition";
            this.lstMainPosition.Size = new System.Drawing.Size(270, 56);
            this.lstMainPosition.TabIndex = 9;
            // 
            // lstOtherPositions
            // 
            this.lstOtherPositions.FormattingEnabled = true;
            this.lstOtherPositions.Location = new System.Drawing.Point(417, 212);
            this.lstOtherPositions.Name = "lstOtherPositions";
            this.lstOtherPositions.Size = new System.Drawing.Size(270, 173);
            this.lstOtherPositions.TabIndex = 10;
            // 
            // lstAvailablePositions
            // 
            this.lstAvailablePositions.FormattingEnabled = true;
            this.lstAvailablePositions.Location = new System.Drawing.Point(731, 124);
            this.lstAvailablePositions.Name = "lstAvailablePositions";
            this.lstAvailablePositions.Size = new System.Drawing.Size(270, 264);
            this.lstAvailablePositions.TabIndex = 11;
            this.lstAvailablePositions.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lstAvailablePositions_MouseDown);
            // 
            // lblMainPosition
            // 
            this.lblMainPosition.AutoSize = true;
            this.lblMainPosition.Location = new System.Drawing.Point(414, 108);
            this.lblMainPosition.Name = "lblMainPosition";
            this.lblMainPosition.Size = new System.Drawing.Size(70, 13);
            this.lblMainPosition.TabIndex = 12;
            this.lblMainPosition.Text = "Main Position";
            // 
            // lblOtherPositions
            // 
            this.lblOtherPositions.AutoSize = true;
            this.lblOtherPositions.Location = new System.Drawing.Point(414, 199);
            this.lblOtherPositions.Name = "lblOtherPositions";
            this.lblOtherPositions.Size = new System.Drawing.Size(78, 13);
            this.lblOtherPositions.TabIndex = 13;
            this.lblOtherPositions.Text = "Other Positions";
            // 
            // lblAvailablePositions
            // 
            this.lblAvailablePositions.AutoSize = true;
            this.lblAvailablePositions.Location = new System.Drawing.Point(728, 108);
            this.lblAvailablePositions.Name = "lblAvailablePositions";
            this.lblAvailablePositions.Size = new System.Drawing.Size(95, 13);
            this.lblAvailablePositions.TabIndex = 14;
            this.lblAvailablePositions.Text = "Available Positions";
            // 
            // btnAddMainPosition
            // 
            this.btnAddMainPosition.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddMainPosition.Location = new System.Drawing.Point(693, 126);
            this.btnAddMainPosition.Name = "btnAddMainPosition";
            this.btnAddMainPosition.Size = new System.Drawing.Size(32, 28);
            this.btnAddMainPosition.TabIndex = 15;
            this.btnAddMainPosition.Text = "<<";
            this.btnAddMainPosition.UseVisualStyleBackColor = true;
            this.btnAddMainPosition.Click += new System.EventHandler(this.btnAddMainPosition_Click);
            // 
            // btnAddOtherPosition
            // 
            this.btnAddOtherPosition.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddOtherPosition.Location = new System.Drawing.Point(693, 212);
            this.btnAddOtherPosition.Name = "btnAddOtherPosition";
            this.btnAddOtherPosition.Size = new System.Drawing.Size(32, 28);
            this.btnAddOtherPosition.TabIndex = 16;
            this.btnAddOtherPosition.Text = "<<";
            this.btnAddOtherPosition.UseVisualStyleBackColor = true;
            this.btnAddOtherPosition.Click += new System.EventHandler(this.btnAddOtherPosition_Click);
            // 
            // btnRemoveMainPosition
            // 
            this.btnRemoveMainPosition.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRemoveMainPosition.Location = new System.Drawing.Point(693, 154);
            this.btnRemoveMainPosition.Name = "btnRemoveMainPosition";
            this.btnRemoveMainPosition.Size = new System.Drawing.Size(32, 28);
            this.btnRemoveMainPosition.TabIndex = 17;
            this.btnRemoveMainPosition.Text = ">>";
            this.btnRemoveMainPosition.UseVisualStyleBackColor = true;
            this.btnRemoveMainPosition.Click += new System.EventHandler(this.btnRemoveMainPosition_Click);
            // 
            // btnRemoveOtherPosition
            // 
            this.btnRemoveOtherPosition.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRemoveOtherPosition.Location = new System.Drawing.Point(693, 240);
            this.btnRemoveOtherPosition.Name = "btnRemoveOtherPosition";
            this.btnRemoveOtherPosition.Size = new System.Drawing.Size(32, 28);
            this.btnRemoveOtherPosition.TabIndex = 18;
            this.btnRemoveOtherPosition.Text = ">>";
            this.btnRemoveOtherPosition.UseVisualStyleBackColor = true;
            this.btnRemoveOtherPosition.Click += new System.EventHandler(this.btnRemoveOtherPosition_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 406);
            this.Controls.Add(this.btnRemoveOtherPosition);
            this.Controls.Add(this.btnRemoveMainPosition);
            this.Controls.Add(this.btnAddOtherPosition);
            this.Controls.Add(this.btnAddMainPosition);
            this.Controls.Add(this.lblAvailablePositions);
            this.Controls.Add(this.lblOtherPositions);
            this.Controls.Add(this.lblMainPosition);
            this.Controls.Add(this.lstAvailablePositions);
            this.Controls.Add(this.lstOtherPositions);
            this.Controls.Add(this.lstMainPosition);
            this.Controls.Add(this.lblUsers);
            this.Controls.Add(this.lstUsers);
            this.Controls.Add(this.lblInstructionsL3);
            this.Controls.Add(this.lblInstructionsL2);
            this.Controls.Add(this.lblInstructionsL1);
            this.Controls.Add(this.lblOrganisation);
            this.Controls.Add(this.cmbOrganisation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Main";
            this.ShowIcon = false;
            this.Text = "EE BAS CRM - System Access Management";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbOrganisation;
        private System.Windows.Forms.Label lblOrganisation;
        private System.Windows.Forms.Label lblInstructionsL1;
        private System.Windows.Forms.Label lblInstructionsL2;
        private System.Windows.Forms.Label lblInstructionsL3;
        private System.Windows.Forms.ListBox lstUsers;
        private System.Windows.Forms.Label lblUsers;
        private System.Windows.Forms.ListBox lstMainPosition;
        private System.Windows.Forms.ListBox lstOtherPositions;
        private System.Windows.Forms.ListBox lstAvailablePositions;
        private System.Windows.Forms.Label lblMainPosition;
        private System.Windows.Forms.Label lblOtherPositions;
        private System.Windows.Forms.Label lblAvailablePositions;
        private System.Windows.Forms.Button btnAddMainPosition;
        private System.Windows.Forms.Button btnAddOtherPosition;
        private System.Windows.Forms.Button btnRemoveMainPosition;
        private System.Windows.Forms.Button btnRemoveOtherPosition;
    }
}

