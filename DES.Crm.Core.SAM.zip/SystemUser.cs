﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.SAM
{
    class SystemUser
    {
       public Boolean UpdateMainPosition(Guid MainPosition, Guid SystemUser, string ErrorMessage)
        {
            return true;
        }
        public Boolean AddOtherPosition(Guid OtherPosition, Guid SystemUser, string ErrorMessage)
        {
            return true;
        }
        public Boolean RemoveOtherPosition(Guid OtherPosition, Guid SystemUser, string ErrorMessage)
        {
            return true;
        }
    }
}
