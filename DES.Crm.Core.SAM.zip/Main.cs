﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DES.Crm.Core.SAM
{
    public partial class Main : Form
    {

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            //Load organisations in cmbOrganisation from config file
        }

        private void cmbOrganisation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Clear lstMainPosition
            //Clear lstOtherPositions

            //Load Users in lstUsers
            //Load Available Positions in lstAvailablePositions
        }

        private void lstUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Load Main Position in lstMainPosition
            //Load Other Positions in lstOtherPositions
        }

        private void btnAddMainPosition_Click(object sender, EventArgs e)
        {
            SystemUser SU = new SystemUser();
            Guid mainPosition = new Guid();
            Guid systemUser = new Guid();
            string errorMesssage = "";

            if (SU.UpdateMainPosition(mainPosition, systemUser, errorMesssage) == false)
            {
                Console.WriteLine(errorMesssage);
                MessageBox.Show(errorMesssage, "Error adding the Main Position", MessageBoxButtons.OK);
            }
            else
            {
                //Add selected position in lstAvailablePositions to lstMainPosition
            }
        }

        private void btnRemoveMainPosition_Click(object sender, EventArgs e)
        {
            SystemUser SU = new SystemUser();
            Guid mainPosition = new Guid();
            Guid systemUser = new Guid();
            string errorMesssage = "";

            if (SU.UpdateMainPosition(mainPosition, systemUser, errorMesssage) == false)
            {
                Console.WriteLine(errorMesssage);
                MessageBox.Show(errorMesssage, "Error removing the Main Position", MessageBoxButtons.OK);
            }
            else
            {
                //Remove Main Position in lstMainPosition
                //Add selected position in lstAvailablePositions to lstMainPosition
            }
        }


        private void btnAddOtherPosition_Click(object sender, EventArgs e)
        {
            SystemUser SU = new SystemUser();
            Guid otherPosition = new Guid();
            Guid systemUser = new Guid();
            string errorMesssage = "";

            if (SU.AddOtherPosition(otherPosition, systemUser, errorMesssage) == false)
            {
                Console.WriteLine(errorMesssage);
                MessageBox.Show(errorMesssage, "Error addin Other Position", MessageBoxButtons.OK);
            }
            else
            {
                //Add selected position in lstAvailablePositions to lstOtherPositions
            }
        }


        private void btnRemoveOtherPosition_Click(object sender, EventArgs e)
        {
            SystemUser SU = new SystemUser();
            Guid otherPosition = new Guid();
            Guid systemUser = new Guid();
            string errorMesssage = "";

            if (SU.RemoveOtherPosition(otherPosition, systemUser, errorMesssage) == false)
            {
                Console.WriteLine(errorMesssage);
                MessageBox.Show(errorMesssage, "Error addin Other Position", MessageBoxButtons.OK);
            }
            else
            {
                //Remove Selected Other Position in lstOtherPositions
            }
        }

    }
}
