﻿module.exports.someFunction = function () {
    console.log('testing');
};