﻿var accountForm = require('../webresources/basic.js' );

it("Should find & call onLoad", function () {
    accountForm.onLoad();
});
