﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xunit;

namespace FakeXrmEasy.EdgeProxy.v9.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void TestMethod1()
        {

        }
    }
}
