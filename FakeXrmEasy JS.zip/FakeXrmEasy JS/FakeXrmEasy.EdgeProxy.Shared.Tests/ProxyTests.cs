﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FakeXrmEasy.EdgeProxy.Shared.Tests
{
    class ProxyTests
    {
    }
}
