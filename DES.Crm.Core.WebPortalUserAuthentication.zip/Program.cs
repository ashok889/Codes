﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Net.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Net;

namespace OAuthExample
{
    class Program
    {

        static void Main(string[] args)
        {
            var execute = Task.Run(async () => await Auth());
            Task.WaitAll(execute);
        }


        public static async Task Auth()
        {

            //SET VARIABLES
            var aadInstance = "https://login.microsoftonline.com/";
            var tenantID = "7c917db0-71f2-438e-9554-388ffcab8764";

            var organizationUrl = "https://cpbblueuat.crm4.dynamics.com";
            var api = "https://cpbblueuat.api.crm4.dynamics.com/api/data/v9.1/";
            var clientId = "89750cf5-281d-4195-a1ee-5004bee6eeb8";
            var appKey = "t7l*@OcV[*Zz?kV.]!Z(*Dnm1[_z)TJu(L$Z+tk=}DH";

            //var organizationUrl = "https://cpbblueprd.crm4.dynamics.com";
            //var api = "https://cpbblueprd.api.crm4.dynamics.com/api/data/v9.1/";
            //var clientId = "f0c2b517-fabe-4644-8101-68835bc22de6";
            //var appKey = "8EfXyW9cCwwkuLF9SdbP7mDs5M2ZqB0jeUaaMyvyiWU=";

            //GET AUTHENTICATION TOKEN
            var clientcred = new ClientCredential(clientId, appKey);
            var authenticationContext = new AuthenticationContext(aadInstance + tenantID);

            var token = authenticationContext.AcquireTokenAsync(organizationUrl, clientcred).Result.AccessToken;

            //SET HTTPCLIENT PROPERTIES
            HttpClient httpClient = null;
            httpClient = new HttpClient();

            //Default Request Headers needed to be added in the HttpClient Object
            httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
            httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            //Set the Authorization header with the Access Token received specifying the Credentials
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            httpClient.BaseAddress = new Uri(api);

            //RETRIEVE OPERATION
            //https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/webapi/retrieve-entity-using-web-api#retrieve-specific-properties
            string userName = "juan.ribes.andres@gmail.com";
            string password= "12345.aa";

            //var rbs_digitalcontenttrainingid = "52A5594B-144A-E911-A994-000D3A2ACC1E";
            //var query = "rbs_digitalcontenttrainings(" + rbs_digitalcontenttrainingid + ")?$select=rbs_digitalcontenttrainingid,rbs_currentchapter,rbs_lastprogessupdate";

            //https://cpbblueuat.crm4.dynamics.com/api/data/v9.1/contacts?$top=1&$select=contactid,adx_identity_logonenabled,adx_identity_passwordhash&$filter=adx_identity_username eq 'test@vmail.com' 
            var query = "contacts?$select=contactid,adx_identity_logonenabled,adx_identity_passwordhash&$filter=adx_identity_username%20eq%20%27" + userName + "%27";

            var response = httpClient.GetAsync(query).Result;
            if (response.IsSuccessStatusCode)
            {
                var responseResult = response.Content.ReadAsStringAsync().Result;
                JObject Jobj = JObject.Parse(responseResult);
                
                string passwordhash = (string)Jobj["rbs_digitalcontenttrainingid"];
                //Assigns the variables
                string Digitalcontenttrainingid = ""; //rbs_digitalcontenttrainingid

                string contactid = "";
                string logonEnabled = "false";
                if (VerifyHashedPassword(passwordhash, password))
                {
                    var result = "OK";
                }

            }

        }

        public static bool VerifyHashedPassword(string hashedPassword, string password)
        {
            byte[] buffer4;
            if (hashedPassword == null)
            {
                return false;
            }
            if (password == null)
            {
                throw new ArgumentNullException("Password missing");
            }
            var src = Convert.FromBase64String(hashedPassword);
            if ((src.Length != 0x31) || (src[0] != 0))
            {
                return false;
            }
            var dst = new byte[0x10];
            Buffer.BlockCopy(src, 1, dst, 0, 0x10);
            var buffer3 = new byte[0x20];
            Buffer.BlockCopy(src, 0x11, buffer3, 0, 0x20);
            using (var bytes = new System.Security.Cryptography.Rfc2898DeriveBytes(password, dst, 0x3e8))
            {
                buffer4 = bytes.GetBytes(0x20);
            }
            return ByteArraysEqual(buffer3, buffer4);
        }

        private static bool ByteArraysEqual(byte[] firstHash, byte[] secondHash)
        {
            int _minHashLength = firstHash.Length <= secondHash.Length ? firstHash.Length : secondHash.Length;
            var xor = firstHash.Length ^ secondHash.Length;
            for (int i = 0; i < _minHashLength; i++)
                xor |= firstHash[i] ^ secondHash[i];
            return 0 == xor;
        }


    }

}
