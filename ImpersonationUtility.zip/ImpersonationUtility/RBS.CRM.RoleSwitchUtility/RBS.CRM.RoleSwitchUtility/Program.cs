﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RBS.CRM.RoleSwitchUtility
{
    class Program
    {
        static void Main(string[] args)
        {
            RoleSwitch obj = new RoleSwitch();
            // string[] arg = { "ravinder.kumar2@rbs.co.uk", "Risk,Sales Manager", "Alan Hanks Team,Sales" };
            if (args.Length == 3)
            {


                RoleSwitch.UserRoleSwitch(args);
            }
            else {
                try {

                    throw new System.Exception("Invalid Input arguments");

                }
                catch (Exception ex)
                {
                    RoleSwitch.ErrorLogging(ex, "Program", "Main");
                }

            } }
    }
}
