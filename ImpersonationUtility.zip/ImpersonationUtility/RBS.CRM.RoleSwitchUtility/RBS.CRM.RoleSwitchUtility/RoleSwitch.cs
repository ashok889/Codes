﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RBS.CRM.RoleSwitchUtility
{
    class RoleSwitch
    {
        #region Class Level Members
        static OrganizationServiceProxy _serviceProxy;
        static Guid businessunitId;
        static string path;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name=""></param>
        public static void UserRoleSwitch(string[] args)
        {
            try
            {


                //// Obtain the target organization's Web address and client logon 
                //// credentials from the user.
                ServerConnection serverConnect = new ServerConnection();
                ServerConnection.Configuration serverConfig = serverConnect.GetServerConfiguration();



                //<snippetExecuteMultiple1>
                // Get a reference to the organization service.
                using (_serviceProxy = new OrganizationServiceProxy(serverConfig.OrganizationUri,
                    serverConfig.HomeRealmUri,
                    serverConfig.Credentials, serverConfig.DeviceCredentials))
                {
                    // Enable early-bound type support to add/update entity records required for this sample.
                    _serviceProxy.EnableProxyTypes();

                    path = ConfigurationManager.AppSettings["ErrorLogPath"];

                    //  Console.WriteLine("Enter UserName");
                    string domainName = args[0];// Console.ReadLine();

                    //  Console.WriteLine("Enter User Role");
                    string roleName = args[1];// Console.ReadLine();
                    string[] roleNames = roleName.Split(',');

                    // Console.WriteLine("Enter User Team");
                    string teamName = args[2];// Console.ReadLine();
                    string[] teamNames = teamName.Split(',');

                    if (!String.IsNullOrEmpty(domainName))
                    {
                        //Retrieve user Guid
                        Guid userId = RetrieveUserId(domainName, _serviceProxy);
                        if (userId != Guid.Empty)
                        {
                            //Remove roles and teams from user
                            RemoveRolesAndTeams(userId, _serviceProxy);


                            #region //Retrieve teamIDS
                            EntityCollection teamEC = RetrieveTeams(teamNames, userId, _serviceProxy);

                            //Check for multiple default teams
                            var isDefaultTeamCount = (teamEC.Entities.Where(cus => (Boolean)cus["isdefault"] == true)).Count();

                            if (isDefaultTeamCount > 1)
                                throw new System.Exception("Can not add multiple default teams");


                            if (teamEC != null && teamEC.Entities != null && teamEC.Entities.Count > 0)
                            {
                                if (teamEC.Entities.Count == teamNames.Count())
                                {
                                    foreach (Entity team in teamEC.Entities)
                                    {
                                        Guid teamId = new Guid(team["teamid"].ToString());
                                        if (teamId != Guid.Empty)
                                            // check if team is default business unit team
                                            if (team["isdefault"] != null)
                                            {


                                                if ((Boolean)(team["isdefault"]) == true)
                                                {
                                                    EntityReference bunitER = (EntityReference)(team["businessunitid"]);
                                                    Entity systemUserObj = new Entity();
                                                    systemUserObj.LogicalName = "systemuser";
                                                    systemUserObj.Id = userId;
                                                    systemUserObj["businessunitid"] = bunitER;

                                                    if (businessunitId == ((EntityReference)bunitER).Id)
                                                        continue;

                                                    _serviceProxy.Update(systemUserObj);
                                                    //set updated user business unit guid
                                                    businessunitId = ((EntityReference)bunitER).Id;
                                                }
                                                else
                                                {
                                                    //Assign team to user

                                                    AssignTeamToUser(userId, teamId, _serviceProxy);

                                                }

                                            }
                                    }


                                }
                                else
                                {
                                    Console.WriteLine("Error");
                                    Console.WriteLine(teamEC + " Team Not Found");
                                }
                                #endregion


                                foreach (string rName in roleNames)
                                {

                                    if (!String.IsNullOrEmpty(rName))
                                    {
                                        //Retrieve Security Roles
                                        Guid roleId = RetrieveRoleId(rName, _serviceProxy);
                                        if (roleId != Guid.Empty)
                                        {
                                            //Assign role to user record
                                            AssignRoleToUser(userId, roleId, _serviceProxy);
                                        }
                                        else
                                        {
                                            Console.WriteLine("Error");
                                            Console.WriteLine(rName + " Role Not Found");
                                        }
                                    }


                                }



                            }
                            
                        }
                        else
                        {
                            Console.WriteLine("Error");
                            Console.WriteLine("User doen't Exist or User is Disabled");
                        }
                    }
                    Console.WriteLine("Completed Successfully");
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "UserRoleSwitch");
                Console.WriteLine("Error");
                Console.WriteLine("Config Data not correct");

            }
        }


        //Assign team to user
        public static void AssignTeamToUser(Guid userId, Guid teamId, IOrganizationService service)
        {
            try
            {
                Guid[] users = { userId };

                // Create the AddMembersTeamRequest object.
                AddMembersTeamRequest addRequest = new AddMembersTeamRequest();
                // Set the AddMembersTeamRequest TeamID property to the object ID of an existing team.
                addRequest.TeamId = teamId;

                // Set the AddMembersTeamRequest MemberIds property to an array of GUIDs that contains the object IDs of one or more system users.
                addRequest.MemberIds = users;

                // Execute the request.
                service.Execute(addRequest);
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "AssignTeamToUser");
                Console.WriteLine("Error");
            }
        }

        //Remove roles and teams from user record
        public static void RemoveRolesAndTeams(Guid userId, IOrganizationService service)
        {
            try
            {
                // Retrieve all roles 
                string retrieveRolefetchXml =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
  <entity name='role'>
    <attribute name='roleid' />
    <link-entity name='systemuserroles' from='roleid' to='roleid' visible='false' intersect='true'>
      <link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='aa'>
        <filter type='and'>
          <condition attribute='systemuserid' operator='eq' value='" + userId + @"' />
        </filter>
      </link-entity>
    </link-entity>
  </entity>
</fetch>";
                EntityCollection ecRoles = service.RetrieveMultiple(new FetchExpression(retrieveRolefetchXml));

                if (ecRoles != null && ecRoles.Entities != null && ecRoles.Entities.Count > 0)
                {
                    //Remove all the roles from user record
                    foreach (Entity role in ecRoles.Entities)
                    {
                        Guid roleId = new Guid(role["roleid"].ToString());
                        service.Disassociate(
                            "systemuser",
                            userId,
                            new Relationship("systemuserroles_association"),
                            new EntityReferenceCollection() { new EntityReference("role", roleId) });
                    }
                }

                /////////
                // Retrieve all teams 
                string retrieveTeamfetchXml =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
  <entity name='team'>
    <attribute name='teamid' />
<filter type='and'>
 <condition attribute='isdefault' operator='ne' value='1' />
        </filter>
    <link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>
      <link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='ab'>
        <filter type='and'>
          <condition attribute='systemuserid' operator='like' value='" + userId + @"' />
        </filter>
      </link-entity>
    </link-entity>
  </entity>
</fetch>";
                EntityCollection ecTeams = service.RetrieveMultiple(new FetchExpression(retrieveTeamfetchXml));

                if (ecTeams != null && ecTeams.Entities != null && ecTeams.Entities.Count > 0)
                {
                    //Remove all the roles from user record

                    foreach (Entity team in ecTeams.Entities)
                    {

                        Guid[] users = { userId };
                        Guid teamId = new Guid(team["teamid"].ToString());

                        //Remove user from team
                        // Create the AddMembersTeamRequest object.
                        RemoveMembersTeamRequest addRequest = new RemoveMembersTeamRequest();
                        // Set the AddMembersTeamRequest TeamID property to the object ID of an existing team.
                        addRequest.TeamId = teamId;

                        // Set the AddMembersTeamRequest MemberIds property to an array of GUIDs that contains the object IDs of one or more system users.
                        addRequest.MemberIds = users;

                        // Execute the request.
                        service.Execute(addRequest);

                    }

                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "RemoveRolesAndTeams");
                Console.WriteLine("Error");
            }
        }



        //Assign role to user
        public static void AssignRoleToUser(Guid userId, Guid roleId, IOrganizationService service)
        {
            try
            {
                if (roleId != Guid.Empty && userId != Guid.Empty)
                {
                    // Associate the user with the role.

                    service.Associate(
                        "systemuser",
                        userId,
                        new Relationship("systemuserroles_association"),
                        new EntityReferenceCollection() { new EntityReference("role", roleId) });
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "AssignRoleToUser");
                Console.WriteLine("Error");
            }
        }


        //Retrieve user record
        public static Guid RetrieveUserId(string domainName, IOrganizationService service)
        {
            Guid userId = Guid.Empty;
            try
            {
                string fetchXML =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='systemuser'>
 <attribute name='businessunitid'/>
    <attribute name='systemuserid' />
    <filter type='and'>
      <condition attribute='domainname' operator='eq' value='" + domainName + @"' />
    </filter>
  </entity>
</fetch>";
                EntityCollection ecUsers = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecUsers != null && ecUsers.Entities != null && ecUsers.Entities.Count > 0)
                {
                    userId = new Guid(ecUsers.Entities[0]["systemuserid"].ToString());
                    businessunitId = ((EntityReference)ecUsers.Entities[0]["businessunitid"]).Id;
                }



            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "RetrieveUserId");
                Console.WriteLine("Error");
            }

            return userId;
        }

        //Retrieve team ids
        public static EntityCollection RetrieveTeams(string[] teamName, Guid userId, IOrganizationService service)
        {
            EntityCollection ecTeams = null;
            try
            {
                string condition = "";

                if (teamName != null)
                {
                    foreach (string tName in teamName)
                    {
                        condition = condition + "<condition attribute='name' operator='eq' value='" + tName + @"' />";
                    }
                }


                string fetchXML =
                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='team'>
    <attribute name='teamid' />
<attribute name='isdefault' />
<attribute name='businessunitid' />
<order attribute='isdefault' descending='true' />
    <filter type='and'> <filter type='or'>" + condition +
       @"</filter>
</filter>
  </entity>
</fetch>";
                ecTeams = service.RetrieveMultiple(new FetchExpression(fetchXML));
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "RetrieveTeams");
                Console.WriteLine("Error");
            }
            return ecTeams;
        }
        //Retrieve team GUID
        public static Guid RetrieveTeamId(String teamName, Guid userId, IOrganizationService service)
        {
            Guid teamId = Guid.Empty;
            try
            {
                string fetchXML =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='team'>
    <attribute name='teamid' />
<attribute name='isdefault' />
<attribute name='businessunitid' />
    <filter type='and'>
      <condition attribute='name' operator='eq' value='" + teamName + @"' />
 <condition attribute='isdefault' operator='ne' value='1' />
    </filter>
  </entity>
</fetch>";
                EntityCollection ecTeams = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecTeams != null && ecTeams.Entities != null && ecTeams.Entities.Count > 0)
                {
                    // check if team is default business unit team
                    if (ecTeams.Entities[0]["isdefault"] != null)
                    {
                        if ((Boolean)(ecTeams.Entities[0]["isdefault"]) == true)
                        {
                            EntityReference bunitER = (EntityReference)(ecTeams.Entities[0]["businessunitid"]);
                            Entity teamObj = new Entity();
                            teamObj["BusinessUnitId"] = bunitER;
                            service.Update(teamObj);

                        }
                        else
                        {
                            teamId = new Guid(ecTeams.Entities[0]["teamid"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "RetrieveTeamId");
                Console.WriteLine("Error");
            }


            return teamId;
        }

        //Check teams business unit with user's business unit
        public static void UpdateUserBusinessUnitId(Guid businessUId, Guid userId, IOrganizationService service)
        {

            Guid roleId = Guid.Empty;
            try
            {

                Entity systemUserId = new Entity();
                systemUserId.LogicalName = "systemuser";
                systemUserId.Id = userId;
                systemUserId["businessunitid"] = new EntityReference("systemuser", businessUId);
                service.Update(systemUserId);

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "UpdateUserBusinessUnitId");
                Console.WriteLine("Error");
            }
        }
        //Retrieve team GUID
        public static Guid RetrieveRoleId(String roleName, IOrganizationService service)
        {
            Guid roleId = Guid.Empty;
            try
            {
                string fetchXML =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='role'>
    <attribute name='roleid' />
    <filter type='and'>
      <condition attribute='name' operator='eq' value='" + roleName + @"' />
<condition attribute='businessunitid' operator='eq' value='" + businessunitId + @"' />
    </filter>
  </entity>
</fetch>";
                EntityCollection ecRoles = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecRoles != null && ecRoles.Entities != null && ecRoles.Entities.Count > 0)
                {
                    roleId = new Guid(ecRoles.Entities[0]["roleid"].ToString());
                }

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "RoleSwitch", "RetrieveRoleId");
                Console.WriteLine("Error");
            }

            return roleId;
        }

        public static void ErrorLogging(Exception ex, string className, string methodName)
        {
            string strPath = path + "Log.txt";
            //string strPath = @"C:\\RoleSwitchLogs\\Log.txt";
            if (!File.Exists(strPath))
            {
                File.Create(strPath).Dispose();
            }
            using (StreamWriter sw = File.AppendText(strPath))
            {
                sw.WriteLine("=============Error Logging ===========");
                sw.WriteLine("===========Start============= " + DateTime.Now);
                sw.WriteLine("Class Name: " + className + ", Method Name: " + methodName);
                sw.WriteLine("Error Message: " + ex.Message);
                sw.WriteLine("Inner Exception: " + ex.InnerException);
                sw.WriteLine("Stack Trace: " + ex.StackTrace);
                sw.WriteLine("===========End============= " + DateTime.Now);

            }
        }
    }
}
