﻿using System.Configuration;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using Microsoft.Crm.Sdk.Messages;

namespace RBS.CRM.TestDataCreationUtility
{
    class AutomaticStageMovement
    {
        public static void Newv9AutomaticBPFStageMovement(string stageName, Guid caseId, String EntityName, IOrganizationService service, EntityMetadata[] entityMetadata)
        {
            Guid _processCase1Id = Guid.Empty;
            Guid stageId = Guid.Empty;
            string _procInstanceLogicalName = string.Empty;
            string stageIds = "";
            string[] stageNames = stageName.Split(',');
            int count = 0;

            try
            {

                foreach (string sName in stageNames)
                {
                    if (count == 0)
                    {
                        stageId = GetStageId(sName, service);
                        stageIds = stageIds + stageId;
                    }
                    else
                    {
                        stageId = GetStageId(sName, service);
                        stageIds = stageIds + "," + stageId;
                        //stageIds = stageIds.Substring(0, stageIds.Length - 1);
                        // Set the active process and the phase if defined
                        // mention the business process flow name to be updated 


                        RetrieveProcessInstancesRequest procCaseReq = new RetrieveProcessInstancesRequest
                        {
                            EntityId = caseId,
                            EntityLogicalName = EntityName
                        };
                        RetrieveProcessInstancesResponse procCaseResp = (RetrieveProcessInstancesResponse)service.Execute(procCaseReq);

                        Entity processCaseInstance = null;
                        if (procCaseResp.Processes.Entities.Count > 0)
                        {
                            processCaseInstance = procCaseResp.Processes.Entities[0];
                            Console.WriteLine("Process instance automatically created for the new case record: '{0}'", processCaseInstance["name"]);

                            _processCase1Id = processCaseInstance.Id; // Id of the active process instance, which will be used
                                                                      // later to retrieve the active path of the process instance

                            Console.WriteLine("Current active process instance for the Opportunity record: '{0}'", processCaseInstance["name"].ToString());
                            _procInstanceLogicalName = processCaseInstance["name"].ToString().Replace(" ", string.Empty).ToLower();


                            //EntityMetadata entityMetad = null;
                            //entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == _procInstanceLogicalName.ToLower()).FirstOrDefault();
                            //if (entityMetad == null)
                            //    entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == _procInstanceLogicalName.ToLower()).FirstOrDefault();
                            //if (entityMetad != null)
                            //{
                            //    bool? isActivity = entityMetad.IsActivity;
                            //    _procInstanceLogicalName = entityMetad.LogicalName;
                            //}

                            // adding prefix =  rbs

                            _procInstanceLogicalName = "rbs_" + _procInstanceLogicalName;
                        }
                        else
                        {
                            Console.WriteLine("No processes found for the case record; aborting the sample.");
                            Environment.Exit(1);
                        }
                        ColumnSet cols1 = new ColumnSet();
                        cols1.AddColumn("activestageid");

                        Entity retrievedProcessInstance = service.Retrieve("rbs_cddcaseprocessflow", _processCase1Id, cols1);

                        // Update the active stage to the next stage
                        retrievedProcessInstance["activestageid"] = new EntityReference("processstage", stageId);
                        retrievedProcessInstance["traversedpath"] = stageIds;
                        service.Update(retrievedProcessInstance);

                    }
                    Entity entityToUpdate = new Entity();
                    // entityToUpdate.LogicalName = "incident";
                    entityToUpdate.LogicalName = EntityName;
                    entityToUpdate.Id = caseId;
                    entityToUpdate["traversedpath"] = stageIds;
                    entityToUpdate["stageid"] = stageId;
                    service.Update(entityToUpdate);

                    count++;
                }

            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "AutomaticStageMovement", "Newv9AutomaticBPFStageMovement");

            }


        }

        public static void AutomaticBPFStageMovement(string stageName, Guid caseId, IOrganizationService service)
        {
            Guid stageId = Guid.Empty;

            try
            {
                string stageIds = "";
                string[] stageNames = stageName.Split(',');
                int count = 0;
                foreach (string sName in stageNames)
                {
                    if (count == 0)
                    {
                        stageId = GetStageId(sName, service);
                        stageIds = stageIds + stageId;
                    }
                    else
                    {
                        stageId = GetStageId(sName, service);
                        stageIds = stageIds + "," + stageId;
                        //stageIds = stageIds.Substring(0, stageIds.Length - 1);
                        // Set the active process and the phase if defined
                        Entity entityToUpdate = new Entity();
                        entityToUpdate.LogicalName = "incident";
                        entityToUpdate.Id = caseId;
                        entityToUpdate["traversedpath"] = stageIds;
                        entityToUpdate["stageid"] = stageId;
                        service.Update(entityToUpdate);
                    }

                    count++;
                }
            }
            catch (Exception ex)
            {

                TestDataCreation.ErrorLogging(ex, "TestDataCreation" + caseId.ToString() + "" , "AutomaticBPFStageMovement");

            }

          
            
        }
        public static Guid GetStageId(string stageName, IOrganizationService service)
        {
            Guid stageId = Guid.Empty;

            try
            {

                string fetchXML =
                           @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='processstage'>
    <attribute name='processstageid' />
    <filter type='and'>
      <condition attribute='stagename' operator='eq' value='" + stageName + @"' />
    </filter>
  </entity>
</fetch>";
                EntityCollection entityC = service.RetrieveMultiple(new FetchExpression(fetchXML));

                // Retrieve the metadata for the current stageId
                stageId = new Guid(entityC.Entities[0]["processstageid"].ToString());
            }

            catch (Exception ex)
            {


                TestDataCreation.ErrorLogging(ex, "TestDataCreation", "GetStageId");
            }


            return stageId;
        }
        public static string GetCaseTraversedPath(Guid stageId, Guid caseId, IOrganizationService service)
        {


            string traversePath = string.Empty;


            try

            {
                Entity caseEn = (Entity)service.Retrieve("incident", caseId, new ColumnSet(new string[] { "traversedpath" }));
                if (caseEn.Attributes.Contains("traversedpath") && !string.IsNullOrEmpty(caseEn["traversedpath"].ToString()))
                    traversePath = caseEn["traversedpath"].ToString();
            }
            catch (Exception ex)

            {
                TestDataCreation.ErrorLogging(ex, "TestDataCreation", "GetCaseTraversedPath");
            }
         

            return traversePath;
        }
    }
}
