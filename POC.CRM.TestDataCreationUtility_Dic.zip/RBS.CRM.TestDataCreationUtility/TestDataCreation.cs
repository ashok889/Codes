﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Office.Interop.Excel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;

/// <summary>
/// //CDD//
/// </summary>
namespace RBS.CRM.TestDataCreationUtility
{
    class TestDataCreation
    {
        #region Class Level Members
        static OrganizationServiceProxy _serviceProxy;
        static string path;
        public static List<DataDetailsKeyCriteriaClass> AutomationList = new List<DataDetailsKeyCriteriaClass>();
        // Contains all the values from the Automation excel list
        public static List<DataDetailsKeyCriteriaClass> UpdatedAutomationList = new List<DataDetailsKeyCriteriaClass>();
        // Contains the Created / Updated Values for the Data Excel(Renuka)
        #endregion


        /// This Function will read data from Automtation Excel file and store in List <Class> data structure
        public static void ReadAutoExcel()
        {

            try
            {

                //    List<DataDetailsKeyCriteriaClass> AutomationList = new List<DataDetailsKeyCriteriaClass>();

                Application xlAutomationApp = new Application();

                String Automationsheet = ConfigurationManager.AppSettings["ExcelLogicPath"];
                String AutoXLId = ConfigurationManager.AppSettings["AutoXLId"];
                String AutoXLAttribute = ConfigurationManager.AppSettings["AutoXLAttribute"];
                int returnvalueindex = Int32.Parse(ConfigurationManager.AppSettings["AutoXLReturnValueindex"]);
                //  string excelpath = "C:\\Projects\\Test1.xlsx";
                Workbook xlAutoWorkbook = xlAutomationApp.Workbooks.Open(Automationsheet);

                if (xlAutoWorkbook.Sheets.Count > 0)
                {
                    foreach (_Worksheet xlWorksheet in xlAutoWorkbook.Sheets)
                    {

                        Range xlRange = xlWorksheet.UsedRange;
                        int rowCount = xlRange.Rows.Count;
                        int colCount = xlRange.Columns.Count;

                        List<string> attributes = new List<string>();
                        for (int i = 1; i <= colCount; i++)
                        {

                            //write the value to the Grid  

                            if (xlRange.Cells[1, i] != null && xlRange.Cells[1, i].Value2 != null)
                            {
                                attributes.Add(xlRange.Cells[1, i].Value2.ToString().Trim());

                            }
                        }

                        if (attributes != null && attributes.Count > 0)
                        {
                            for (int i = 2; i <= rowCount; i++)
                            {

                                DataDetailsKeyCriteriaClass Details = new DataDetailsKeyCriteriaClass();

                                for (int j = 1; j <= colCount; j++)
                                {
                                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)

                                    {
                                        string att = attributes[j - 1];

                                        if (att == AutoXLId)
                                        {

                                            Details.TestId = xlRange.Cells[i, j].Value2.ToString().Trim();

                                        }
                                        if (att == AutoXLAttribute)
                                        {
                                            Details.AttributeName = xlRange.Cells[i, j].Value2.ToString().Trim();

                                        }
                                        //if (att == "ReturnValue") 
                                        //{
                                        //    // Details.AttributeName = xlRange.Cells[i, j].Value2.ToString().Trim();

                                        //}
                                    }
                                }

                                Details.SheetName = xlWorksheet.Name;

                                Details.RowNo = i;
                                Details.ColumnNo = returnvalueindex;

                                AutomationList.Add(Details);

                            }
                        }
                        //cleanup  
                        GC.Collect();
                        GC.WaitForPendingFinalizers();

                        //rule of thumb for releasing com objects:  
                        //  never use two dots, all COM objects must be referenced and released individually  
                        //  ex: [somthing].[something].[something] is bad  

                        //release com objects to fully kill excel process from running in the background  
                        Marshal.ReleaseComObject(xlRange);
                        Marshal.ReleaseComObject(xlWorksheet);
                    }

                }
                //close and release  
                xlAutoWorkbook.Close();
                Marshal.ReleaseComObject(xlAutoWorkbook);

                //quit and release  
                xlAutomationApp.Quit();
                Marshal.ReleaseComObject(xlAutomationApp);
            }

            catch (Exception ex)
            {

                ErrorLogging(ex, "TestDataCreation", "ReadAutoExcel");
            }



        }
        /// <summary>
        /// This function will read data from Excel file 
        /// </summary>
        /// <param name="arg"></param>
        /// 
        public static void createpost(IOrganizationService service)
        {
            Entity Post = new Entity("post");
            Post["regardingobjectid"] = new EntityReference("incident", new Guid("8764F239-F584-E811-8112-3863BB343BF8"));
            Post["text"] = "This lead was created for a sample.";
            Guid PostID = service.Create(Post);
        }
        public static void ReadDataFromExcel(string[] arg)
        {
            try
            {

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                //// Obtain the target organization's Web address and client logon 
                //// credentials from the user.
                ServerConnection serverConnect = new ServerConnection();
                ServerConnection.Configuration serverConfig = serverConnect.GetServerConfiguration();


                // Get a reference to the organization service.
                using (_serviceProxy = new OrganizationServiceProxy(serverConfig.OrganizationUri,
                    serverConfig.HomeRealmUri,
                    serverConfig.Credentials, serverConfig.DeviceCredentials))
                {
                    // Enable early-bound type support to add/update entity records required for this sample.
                    _serviceProxy.EnableProxyTypes();

                    EntityMetadata[] entityMetadata1 = GetEntities(_serviceProxy);

                    //// ams  unit Testing
                    //List<AttributeMetadata> attributeMetadata2 = RetrieveAttributeMetadata(_serviceProxy, "incident");
                    //String value = GetAttributeValue("Senior Management Sign Off", attributeMetadata2,entityMetadata1,"incident",new Guid("E7588DCD-5170-E711-80DF-3863BB341BF8"),_serviceProxy);

                    path = ConfigurationManager.AppSettings["ErrorLogPath"];

                    //Retrieve excel data
                    Application xlApp = new Application();
                    //string excelpath = arg[0];

                    String RenukaSheet = ConfigurationManager.AppSettings["ExcelDataPath"];
                    Workbook xlWorkbook = xlApp.Workbooks.Open(RenukaSheet);
                    if (xlWorkbook.Sheets.Count > 0)
                    {

                        foreach (_Worksheet xlWorksheet in xlWorkbook.Sheets)
                        {

                            EntityMetadata[] entityMetadata = GetEntities(_serviceProxy);
                            string name = xlWorksheet.Name;
                            EntityMetadata entityMetad = null;
                            entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == name.ToLower()).FirstOrDefault();
                            if (entityMetad == null)
                                entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == name.ToLower()).FirstOrDefault();
                            if (entityMetad != null)
                            {
                                bool? isActivity = entityMetad.IsActivity;
                                string entityName = entityMetad.LogicalName;
                                //Retrieve Attribute Metadata
                                List<AttributeMetadata> attributeMetadata = RetrieveAttributeMetadata(_serviceProxy, entityName);


                                Range xlRange = xlWorksheet.UsedRange;
                                int rowCount = xlRange.Rows.Count;
                                int colCount = xlRange.Columns.Count;


                                List<string> attributes = new List<string>();
                                for (int i = 1; i <= colCount; i++)
                                {

                                    //write the value to the Grid  


                                    if (xlRange.Cells[1, i] != null && xlRange.Cells[1, i].Value2 != null)
                                    {
                                        attributes.Add(xlRange.Cells[1, i].Value2.ToString().Trim());
                                    }
                                }

                                if (attributes != null && attributes.Count > 0)
                                {
                                    // Create entity record
                                    EntityRecord(entityName, attributeMetadata, attributes, xlRange, entityMetadata, isActivity, _serviceProxy);
                                }
                                xlWorkbook.Save();

                                GC.Collect();
                                GC.WaitForPendingFinalizers();

                                //rule of thumb for releasing com objects:  
                                //  never use two dots, all COM objects must be referenced and released individually  
                                //  ex: [somthing].[something].[something] is bad  

                                //release com objects to fully kill excel process from running in the background  
                                Marshal.ReleaseComObject(xlRange);
                                Marshal.ReleaseComObject(xlWorksheet);
                            }
                        }
                    }

                    //close and release  
                    xlWorkbook.Close();
                    Marshal.ReleaseComObject(xlWorkbook);

                    //quit and release  
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "ReadDataFromExcel");
            }
        }

        /// <summary>
        /// This finction will perform curd operations in CRM 
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="attributeMetadata"></param>
        /// <param name="attribute"></param>
        /// <param name="xlRange"></param>
        /// <param name="entityMetadata"></param>
        /// <param name="isActivity"></param>
        /// <param name="service"></param>
        /// 

        public static void ReadAutomationData(String UniqueID, IOrganizationService service, Guid RecordId, EntityMetadata[] entityMetadata, String entityName, List<AttributeMetadata> attributeMetadata)
        {

            try

            {
                //ams
                //Retrieve excel data
                Application xlAutomationApp = new Application();

                String Automationsheet = ConfigurationManager.AppSettings["ExcelLogicPath"];
                //  string excelpath = "C:\\Projects\\Test1.xlsx";
                Workbook xlAutoWorkbook = xlAutomationApp.Workbooks.Open(Automationsheet);

                if (xlAutoWorkbook.Sheets.Count > 0)
                {
                    foreach (_Worksheet xlWorksheet in xlAutoWorkbook.Sheets)
                    {
                        Range xlAutoIDRange1 = xlWorksheet.UsedRange.Columns["A:A"];
                        List<string> xLDataIds = new List<string>();
                        int rowCount = xlAutoIDRange1.Rows.Count;
                        int colCount = xlAutoIDRange1.Columns.Count;

                        for (int x = 1; x <= rowCount; x++)
                        {
                            //write the value to the Grid  
                            // Make sure Data picked is Id // change column number as per requirement 

                            if (xlAutoIDRange1.Cells[x, 1] != null && xlAutoIDRange1.Cells[x, 1].Value2 != null)
                            {
                                xLDataIds.Add(xlAutoIDRange1.Cells[x, 1].Value2.Trim().ToString());
                            }
                        }
                        int rownumber = 0;

                        //int idx = ID.IndexOf("Case_Automation_001");
                        int idx = xLDataIds.IndexOf(UniqueID);


                        if (idx > 0)
                        {
                            rownumber = idx + 1;

                            Range xlRange = xlWorksheet.UsedRange;
                            string AttributeName = string.Empty;

                            // HArdcoded Attribute Name = 2
                            int returnvalueindex = Int32.Parse(ConfigurationManager.AppSettings["AutoXLReturnValueindex"]);
                            int DataXLIdindex = Int32.Parse(ConfigurationManager.AppSettings["DataXLIdindex"]);


                            if (xlRange.Cells[rownumber, DataXLIdindex] != null && xlAutoIDRange1.Cells[rownumber, DataXLIdindex].Value2 != null)
                            {
                                AttributeName = xlRange[rownumber, DataXLIdindex].Value2.Trim().ToString();


                                string ReturnValue = GetAttributeValue(AttributeName, attributeMetadata, entityMetadata, entityName, RecordId, service);

                                xlRange.Cells[rownumber, returnvalueindex].Value2 = ReturnValue.ToString();
                                xlAutoWorkbook.Save();

                                break;
                            }
                        }
                        else
                        {
                            // Did not find the record in sheet 1 
                            Console.WriteLine(UniqueID + "Not Present in Automation Sheet");
                        }
                    }
                }

                xlAutoWorkbook.Close();
                xlAutomationApp.Quit();

            }

            catch (Exception ex)
            {

                ErrorLogging(ex, "TestDataCreation", "ReadAutomationData");
            }
        }

        public static string GetAttributeValue(String AttributeName, List<AttributeMetadata> attributeMetadata, EntityMetadata[] entityMetadata, String entityName, Guid primaryKey, IOrganizationService service)

        {
            String ReturnValue = String.Empty;

            //Retrieve attribute from AttributeMetadata

            // AttributeMetadata attMetadata = attributeMetadata.Find(x => x.DisplayName.LocalizedLabels.Count>0 && x.DisplayName.LocalizedLabels[0] !=null && x.DisplayName.LocalizedLabels[0].Label == att);


            try
            {
                // Set activity for activity type of entities


                //                string fetchXML =
                //                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                //  <entity name='" + entityName + @"'>
                //    <attribute name='" + AttributeName + @"' />

                AttributeMetadata attMetadata = attributeMetadata.Find(x => x.LogicalName == AttributeName || (x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == AttributeName.ToLower()));


                if (attMetadata != null)
                {
                    AttributeName = attMetadata.LogicalName;
                }
                //  </entity>
                //</fetch>";

                Entity entity = service.Retrieve(entityName, primaryKey, new ColumnSet(AttributeName));
                //EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (entity != null)
                {
                    if (entity.Attributes.Contains(AttributeName))
                    {

                        if (attMetadata.AttributeType == AttributeTypeCode.Boolean)
                        {
                            Boolean IsBilled = (Boolean)entity[AttributeName];
                            //    ReturnValue = IsBilled.ToString();
                            //     int value = ((OptionSetValue)entity[AttributeName]).Value;
                            ReturnValue = entity.FormattedValues[AttributeName].ToString();


                            //  Generic Label to be displayed
                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Decimal)
                        {
                            // ReturnValue = entity.GetAttributeValue<decimal>(AttributeName).ToString();
                            ReturnValue = entity[AttributeName].ToString();
                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Double)
                        {
                            ReturnValue = entity[AttributeName].ToString();
                            // Left
                            // Not Tested

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.DateTime)
                        {
                            //                        ReturnValue = ((DateTime)(entity[AttributeName])).ToString();
                            //   ReturnValue = ((DateTime)(entity[AttributeName])).ToString(); // correct
                            ReturnValue = Convert.ToDateTime(entity.Attributes[AttributeName].ToString()).ToString();

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.String)
                        {
                            ReturnValue = entity[AttributeName].ToString();
                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Picklist)
                        {
                            int value = ((OptionSetValue)entity[AttributeName]).Value;
                            ReturnValue = entity.FormattedValues[AttributeName].ToString();

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Lookup)
                        {
                            ReturnValue = ((EntityReference)entity[AttributeName]).Name.ToString();


                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Money)
                        {
                            ReturnValue = ((Money)entity[AttributeName]).Value.ToString();

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Memo)
                        {
                            ReturnValue = entity[AttributeName].ToString();
                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Integer)
                        {
                            ReturnValue = Convert.ToInt32(entity.Attributes[AttributeName].ToString()).ToString();
                            // Tested
                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.BigInt)
                        {
                            ReturnValue = Convert.ToInt64(entity.Attributes[AttributeName].ToString()).ToString();
                            // Tested
                        }

                        else if (attMetadata.AttributeType == AttributeTypeCode.Uniqueidentifier)
                        {
                            ReturnValue = entity.Attributes[AttributeName].ToString();
                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Status)
                        {
                            int value = ((OptionSetValue)entity[AttributeName]).Value;
                            ReturnValue = entity.FormattedValues[AttributeName].ToString();

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.State)
                        {
                            int value = ((OptionSetValue)entity[AttributeName]).Value;
                            ReturnValue = entity.FormattedValues[AttributeName].ToString();

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Customer)
                        {
                            EntityReference customer = new EntityReference();
                            customer.Id = ((EntityReference)(entity.Attributes[AttributeName])).Id;
                            ReturnValue = ((EntityReference)(entity.Attributes[AttributeName])).Name.ToString();
                            //   ReturnValue = customer.LogicalName.ToString();

                        }
                        else if (attMetadata.AttributeType == AttributeTypeCode.Owner)
                        {
                            EntityReference owner = new EntityReference();
                            ReturnValue = ((EntityReference)(entity.Attributes[AttributeName])).Id.ToString();
                            ReturnValue = ((EntityReference)(entity.Attributes[AttributeName])).Name.ToString();
                            //  ReturnValue = owner.LogicalName.ToString();
                        }
                    }

                }


            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "GetAttributeValue");
            }
            return ReturnValue;
        }

        public static Guid EntityRecord(string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid RecordID = Guid.Empty;
            try
            {


                int rowCount = xlRange.Rows.Count;
                int colCount = xlRange.Columns.Count;

                for (int i = 2; i <= rowCount; i++)
                {
                    Console.WriteLine(i);

                    string action = string.Empty;

                    if (xlRange.Cells[i, 1] != null && xlRange.Cells[i, 1].Value2 != null)
                    {
                        string value = xlRange.Cells[i, 1].Value2.Trim();
                        if (value.ToLower() == "c")
                        {
                            //Create record
                            RecordID = CreateEntityRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);
                            action = "C";
                        }
                        else if (value.ToLower() == "u")
                        {
                            //Update record
                            RecordID = UpdateEntityRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);
                            action = "U";
                        }
                        else if (value.ToLower() == "d")
                        {
                            //Delete record
                            RecordID = DeleteEntityRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);
                            action = "D";
                        }

                    }

                    if (RecordID != Guid.Empty || entityName.ToUpper() == "INCIDENT")

                    {
                        int DataXLstartindex = Int32.Parse(ConfigurationManager.AppSettings["DataXLstartindex"]);
                        if (xlRange.Cells[i, DataXLstartindex] != null && xlRange.Cells[i, DataXLstartindex].Value2 != null)
                        {
                            string TestScriptName = string.Empty;
                            string Attribute = string.Empty;
                            string ReturnXLValue = string.Empty;

                            if (xlRange.Cells[i, DataXLstartindex - 2] != null && xlRange.Cells[i, DataXLstartindex - 2].Value2 != null)
                            {
                                Attribute = xlRange.Cells[i, DataXLstartindex - 2].Value2.Trim();
                            }

                            ReturnXLValue = GetAttributeValue(Attribute, attributeMetadata, entityMetadata, entityName, RecordID, service);

                            if (action != "d")
                            {
                                xlRange.Cells[i, DataXLstartindex - 1].Value2 = ReturnXLValue.ToString();
                            }
                            else
                            {
                                xlRange.Cells[i, DataXLstartindex - 1].Value2 = "";
                            }
                            //    xlAutoWorkbook.Save();
                            int DataXLIdindex = Int32.Parse(ConfigurationManager.AppSettings["DataXLIdindex"]);


                            if (xlRange.Cells[i, DataXLIdindex] != null && xlRange.Cells[i, DataXLIdindex].Value2 != null)

                            {
                                TestScriptName = xlRange.Cells[i, DataXLIdindex].Value2.Trim();

                                //    ReadAutomationData(TestScriptName,service,RecordID,entityMetadata, entityName, attributeMetadata);

                                DataDetailsKeyCriteriaClass result = AutomationList.Find(x => x.TestId == TestScriptName);
                                if (result != null)

                                {
                                    if (result.AttributeName != null && result.AttributeName != "")
                                    {
                                        string ReturnValue = GetAttributeValue(result.AttributeName, attributeMetadata, entityMetadata, entityName, RecordID, service);
                                        result.ReturnValue = ReturnValue;
                                        result.Action = action;
                                        UpdatedAutomationList.Add(result);

                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "EntityRecord");
            }
            return RecordID;

        }

        /// <summary>
        /// This function will delete record from CRM
        /// </summary>
        /// <param name="i"></param>
        /// <param name="colCount"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeMetadata"></param>
        /// <param name="attribute"></param>
        /// <param name="xlRange"></param>
        /// <param name="entityMetadata"></param>
        /// <param name="isActivity"></param>
        /// <param name="service"></param>
        /// 

        public static void UpdateAutoExcel()
        {

            try
            {
                Application xlAutomationApp = new Application();

                String Automationsheet = ConfigurationManager.AppSettings["ExcelLogicPath"];
                int returnvalueindex = Int32.Parse(ConfigurationManager.AppSettings["AutoXLReturnValueindex"]);
                //  string excelpath = "C:\\Projects\\Test1.xlsx";
                Workbook xlAutoWorkbook = xlAutomationApp.Workbooks.Open(Automationsheet);

                //  List<string> xLSheets = new List<string>();
                if (xlAutoWorkbook.Sheets.Count > 0)
                {
                    foreach (_Worksheet xlWorksheet in xlAutoWorkbook.Sheets)
                    {
                        Range xlAutoIDRange1 = xlWorksheet.UsedRange;
                        String SheetName = xlWorksheet.Name.ToString();

                        List<string> xLDataIds = new List<string>();
                        int rowCount = xlAutoIDRange1.Rows.Count;
                        int colCount = xlAutoIDRange1.Columns.Count;


                        for (int x = 2; x <= rowCount; x++)
                        {
                            if (xlAutoIDRange1.Cells[x, 1] != null && xlAutoIDRange1.Cells[x, 1].Value2 != null)
                            {
                                String AutoId = xlAutoIDRange1[x, 1].Value2.ToString().Trim();

                                DataDetailsKeyCriteriaClass result = UpdatedAutomationList.Find(y => y.TestId == AutoId);
                                if (result != null)

                                {
                                    if (result.Action.ToLower() == "d")
                                    {
                                        xlAutoIDRange1.Cells[x, returnvalueindex].Value2 = "";
                                    }
                                    if (result.ReturnValue != null && result.ReturnValue != "")
                                    {
                                        xlAutoIDRange1.Cells[x, returnvalueindex].Value2 = result.ReturnValue.ToString();
                                        xlAutoWorkbook.Save();
                                    }
                                }

                            }
                        }                    //ams

                        // ams 
                        //cleanup  
                        //GC.Collect();
                        //GC.WaitForPendingFinalizers();

                        ////rule of thumb for releasing com objects:  
                        ////  never use two dots, all COM objects must be referenced and released individually  
                        ////  ex: [somthing].[something].[something] is bad  

                        ////release com objects to fully kill excel process from running in the background  
                        //Marshal.ReleaseComObject(xlAutoIDRange1);
                        //Marshal.ReleaseComObject(xlAutoWorkbook);
                    }
                }
                xlAutoWorkbook.Close();
                xlAutomationApp.Quit();
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "UpdateAutoExcel");
            }
        }

        public static Guid DeleteEntityRecord(int i, int colCount, string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid RecordID = Guid.Empty;

            try
            {
                /// mention the unique column name ams hardcoded
                /// 
                int j = Int32.Parse(ConfigurationManager.AppSettings["DataXLstartindex"]);
                if (xlRange.Cells[i, j - 1] != null && xlRange.Cells[i, j - 1].Value2 != null) // hardcoded
                {
                    string value = xlRange.Cells[i, 4].Value2.ToString().Trim();  // hardcoded
                    string att = attribute[j - 1]; // hardcoded
                    //Retrieve attribute from AttributeMetadata

                    // AttributeMetadata attMetadata = attributeMetadata.Find(x => x.DisplayName.LocalizedLabels.Count>0 && x.DisplayName.LocalizedLabels[0] !=null && x.DisplayName.LocalizedLabels[0].Label == att);
                    AttributeMetadata attMetadata = attributeMetadata.Find(x => x.LogicalName == att || (x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == att.ToLower()));


                    if (attMetadata != null)
                    {

                        // Search record from Unique attribute
                        EntityCollection entityC = RetrieveEntityCollection(entityName, attMetadata.LogicalName, value, isActivity, _serviceProxy);
                        if (entityC != null && entityC.Entities != null && entityC.Entities.Count > 0)
                        {
                            foreach (Entity entity in entityC.Entities)
                            {
                                Guid recordId = entity.Id;
                                service.Delete(entityName, recordId);
                                Console.WriteLine("Entity Deleted successfully");
                                RecordID = recordId;
                            }
                        }
                    }
                }
                return RecordID;
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "DeleteEntityRecord");
                return RecordID;
            }
        }

        /// <summary>
        /// This Function will create record from CRM
        /// </summary>
        /// <param name="i"></param>
        /// <param name="colCount"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeMetadata"></param>
        /// <param name="attribute"></param>
        /// <param name="xlRange"></param>
        /// <param name="entityMetadata"></param>
        /// <param name="isActivity"></param>
        /// <param name="service"></param>
        public static Guid CreateEntityRecord(int i, int colCount, string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {

            Guid entityId = Guid.Empty;
            try
            {
                Entity objEntity = new Entity();
                objEntity.LogicalName = entityName;
                string stageName = string.Empty;
                string assign = string.Empty;
                int Count = 0;

                for (int j = Int32.Parse(ConfigurationManager.AppSettings["DataXLstartindex"]); j <= colCount; j++) // Put J =  index from where we want to read in excel.
                {

                    //write the value to the Grid  

                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                    {
                        string value = xlRange.Cells[i, j].Value2.ToString().Trim();
                        string att = attribute[j - 1];
                        //Retrieve attribute from AttributeMetadata

                        // AttributeMetadata attMetadata = attributeMetadata.Find(x => x.DisplayName.LocalizedLabels.Count>0 && x.DisplayName.LocalizedLabels[0] !=null && x.DisplayName.LocalizedLabels[0].Label == att);
                        AttributeMetadata attMetadata = attributeMetadata.Find(x => x.LogicalName == att || (x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == att.ToLower()));


                        if (attMetadata != null)
                        {
                            att = attMetadata.LogicalName;

                            //if (Count == 0)
                            //{
                            //    Guid recordId = RetrieveEntityRecord(entityName, attMetadata.LogicalName, value, isActivity, _serviceProxy);
                            //    if (recordId != Guid.Empty)
                            //    {
                            //        break;
                            //    }
                            //}
                            if (attMetadata.AttributeType == AttributeTypeCode.Boolean)
                            {
                                if (value.ToLower() == "yes")
                                    objEntity[att] = true;
                                else if (value.ToLower() == "no")
                                    objEntity[att] = false;
                                else
                                    objEntity[att] = (Boolean)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Decimal)
                            {
                                objEntity[att] = (Decimal)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Double)
                            {
                                objEntity[att] = (Double)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.DateTime)
                            {
                                double d = (Double)(xlRange.Cells[i, j].Value2);
                                DateTime dateTime = DateTime.FromOADate(d).Date;
                                objEntity[att] = dateTime;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.String)
                            {
                                objEntity[att] = value.Trim();
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Picklist)
                            {
                                int? optionSetValue = GetOptionsSetValueForLabel(_serviceProxy, entityName, att, xlRange.Cells[i, j].Value2.ToString().Trim());
                                if (optionSetValue != null)
                                {
                                    int optionsetValue = Convert.ToInt32(optionSetValue);
                                    objEntity[att] = new OptionSetValue(optionsetValue);
                                }
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Lookup)
                            {
                                string parentEntity = string.Empty;

                                if (att == "regardingobjectid")
                                {
                                    String[] values = value.Split(',');

                                    EntityMetadata entityMetad = null;
                                    entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == values[0].ToLower()).FirstOrDefault();
                                    if (entityMetad == null)
                                        entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == values[0].ToLower()).FirstOrDefault();
                                    if (entityMetad != null)
                                    {

                                        parentEntity = entityMetad.LogicalName;
                                        isActivity = entityMetad.IsActivity;
                                        value = values[1].ToString();
                                    }

                                }
                                else
                                {
                                    parentEntity = ((LookupAttributeMetadata)attMetadata).Targets[0];

                                }


                                EntityMetadata entityMetad_PE = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
                                if (entityMetad_PE != null)
                                {
                                    if (entityMetad_PE.PrimaryNameAttribute != null)
                                    {
                                        //Retrieve Record
                                        Guid parentEntityId = RetrieveEntityRecord(parentEntity, entityMetad_PE.PrimaryNameAttribute, value, entityMetadata, entityMetad_PE.IsActivity, _serviceProxy);
                                        if (parentEntityId != Guid.Empty)
                                            objEntity[att] = new EntityReference(parentEntity, parentEntityId);
                                    }
                                }


                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Money)
                            {
                                objEntity[att] = new Money((Decimal)xlRange.Cells[i, j].Value2);
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Memo)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.BigInt)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Uniqueidentifier)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Status)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.State)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Customer)
                            {
                                if (((LookupAttributeMetadata)attMetadata).Targets.Count() > 0)
                                {
                                    foreach (string ent in ((LookupAttributeMetadata)attMetadata).Targets)
                                    {
                                        string parentEntity = ent;

                                        EntityMetadata entityMetad = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
                                        if (entityMetad != null)
                                        {
                                            if (entityMetad.PrimaryNameAttribute != null)
                                            {
                                                //Retrieve Record
                                                Guid parentEntityId = RetrieveEntityRecord(parentEntity, entityMetad.PrimaryNameAttribute, value, entityMetadata, isActivity, _serviceProxy);

                                                if (parentEntityId != Guid.Empty)
                                                {
                                                    objEntity[att] = new EntityReference(parentEntity, parentEntityId);
                                                    break;
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Owner)
                            {

                                Guid userId = RetrieveUserId(value, _serviceProxy);
                                if (userId != Guid.Empty)
                                {
                                    objEntity[att] = new EntityReference("systemuser", userId);
                                }
                                else
                                {
                                    Guid teamId = RetrieveTeamId(value, _serviceProxy);
                                    if (teamId != Guid.Empty)
                                    {
                                        objEntity[att] = new EntityReference("team", teamId);
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (att != null && att.ToLower() == "stage")
                            {
                                stageName = value;
                            }
                            else if (att != null && att.ToLower() == "assign")
                            {
                                assign = value;
                            }

                        }

                    }

                    Count++;

                }

                entityId = service.Create(objEntity);


                if (!string.IsNullOrEmpty(assign))
                {

                    Guid userId = RetrieveUserId(assign, _serviceProxy);
                    if (userId != Guid.Empty)
                    {
                        // Create the Request Object and Set the Request Object's Properties  
                        AssignRequest assignowner = new AssignRequest
                        {
                            Assignee = new EntityReference("systemuser", userId),
                            Target = new EntityReference(entityName, entityId)
                        };
                        // Execute the Request  
                        service.Execute(assignowner);
                    }
                    else
                    {
                        Guid teamId = RetrieveTeamId(assign, _serviceProxy);
                        if (teamId != Guid.Empty)
                        {

                            // Create the Request Object and Set the Request Object's Properties  
                            AssignRequest assignowner = new AssignRequest
                            {
                                Assignee = new EntityReference("team", teamId),
                                Target = new EntityReference(entityName, entityId)
                            };
                            // Execute the Request  
                            service.Execute(assignowner);

                        }
                    }

                }
                if (!string.IsNullOrEmpty(stageName))
                {
                    // stageName = "CDD Analysis,Customer Contact,Non Respondent Customer";


                    //  AutomaticStageMovement.AutomaticBPFStageMovement(stageName, entityId, _serviceProxy);
                    AutomaticStageMovement.Newv9AutomaticBPFStageMovement(stageName, entityId, objEntity.LogicalName, _serviceProxy, entityMetadata);
                }






                Console.WriteLine("Entity created successfully");


            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "CreateEntityRecord");
            }

            return entityId;

        }

        public static Guid RetrieveUserId(string name, IOrganizationService service)
        {
            Guid userId = Guid.Empty;
            try
            {
                string fetchXML =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='systemuser'>
    <attribute name='systemuserid' />
    <filter type='and'>
      <condition attribute='fullname' operator='eq' value='" + name + @"' />
    </filter>
  </entity>
</fetch>";
                EntityCollection ecUsers = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecUsers != null && ecUsers.Entities != null && ecUsers.Entities.Count > 0)
                {
                    userId = new Guid(ecUsers.Entities[0]["systemuserid"].ToString());

                }

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveUserId");
                Console.WriteLine("Error");
            }

            return userId;
        }
        public static Guid RetrieveTeamId(string name, IOrganizationService service)
        {
            Guid teamId = Guid.Empty;
            try
            {
                string fetchXML =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='team'>
    <attribute name='teamid' />
    <filter type='and'>
      <condition attribute='name' operator='eq' value='" + name + @"' />
    </filter>
  </entity>
</fetch>";
                EntityCollection ecTeams = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecTeams != null && ecTeams.Entities != null && ecTeams.Entities.Count > 0)
                {
                    teamId = new Guid(ecTeams.Entities[0]["teamid"].ToString());

                }

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveTeamId");
                Console.WriteLine("Error");
            }

            return teamId;
        }

        /// <summary>
        /// This function will update record in CRM
        /// </summary>
        /// <param name="i"></param>
        /// <param name="colCount"></param>
        /// <param name="entityName"></param>
        /// <param name="attributeMetadata"></param>
        /// <param name="attribute"></param>
        /// <param name="xlRange"></param>
        /// <param name="entityMetadata"></param>
        /// <param name="isActivity"></param>
        /// <param name="service"></param>
        public static Guid UpdateEntityRecord(int i, int colCount, string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid RecordId = Guid.Empty;
            try
            {
                Entity objEntity = new Entity();
                objEntity.LogicalName = entityName;
                string stageName = string.Empty;
                string assign = string.Empty;
                int Count = 0;


                Guid recordId = Guid.Empty;
                for (int j = Int32.Parse(ConfigurationManager.AppSettings["DataXLstartindex"]); j <= colCount; j++)  //   Start from unique column name on which filtering required ams 
                {


                    //write the value to the Grid  


                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                    {
                        string value = xlRange.Cells[i, j].Value2.ToString().Trim();
                        string att = attribute[j - 1];
                        //Retrieve attribute from AttributeMetadata

                        // AttributeMetadata attMetadata = attributeMetadata.Find(x => x.DisplayName.LocalizedLabels.Count>0 && x.DisplayName.LocalizedLabels[0] !=null && x.DisplayName.LocalizedLabels[0].Label == att);
                        AttributeMetadata attMetadata = attributeMetadata.Find(x => x.LogicalName == att || (x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == att.ToLower()));

                        if (Count == 0)
                        {
                            // Search record from Unique attribute
                            recordId = RetrieveEntityRecord(entityName, attMetadata.LogicalName, value, entityMetadata, isActivity, _serviceProxy);
                            objEntity.Id = recordId;
                            Count++;
                            continue;
                        }

                        if (recordId == Guid.Empty)
                        {
                            break;
                        }
                        else
                        {
                            RecordId = recordId;

                        }
                        if (attMetadata != null)
                        {
                            att = attMetadata.LogicalName;


                            if (attMetadata.AttributeType == AttributeTypeCode.Boolean)
                            {

                                if (value.ToLower() == "yes")
                                    objEntity[att] = true;
                                else if (value.ToLower() == "no")
                                    objEntity[att] = false;
                                else
                                    objEntity[att] = (Boolean)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Decimal)
                            {
                                objEntity[att] = (Decimal)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Double)
                            {
                                objEntity[att] = (Double)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.DateTime)
                            {
                                double d = (Double)(xlRange.Cells[i, j].Value2);
                                DateTime dateTime = DateTime.FromOADate(d).Date;
                                objEntity[att] = dateTime;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.String)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Picklist)
                            {
                                int optionSetValue = GetOptionsSetValueForLabel(_serviceProxy, entityName, att, xlRange.Cells[i, j].Value2.Trim());
                                if (optionSetValue != 0)
                                    objEntity[att] = new OptionSetValue(optionSetValue);
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Lookup)
                            {
                                string parentEntity = ((LookupAttributeMetadata)attMetadata).Targets[0];

                                EntityMetadata entityMetad = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
                                if (entityMetad != null)
                                {
                                    if (entityMetad.PrimaryNameAttribute != null)
                                    {
                                        //Retrieve Record
                                        Guid parentEntityId = RetrieveEntityRecord(parentEntity, entityMetad.PrimaryNameAttribute, value, entityMetadata, isActivity, _serviceProxy);
                                        if (parentEntityId != Guid.Empty)
                                            objEntity[att] = new EntityReference(parentEntity, parentEntityId);
                                    }
                                }

                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Money)
                            {
                                objEntity[att] = new Money((Decimal)xlRange.Cells[i, j].Value2);
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Memo)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.BigInt)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Uniqueidentifier)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Status)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.State)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Customer)
                            {
                                if (((LookupAttributeMetadata)attMetadata).Targets.Count() > 0)
                                {
                                    foreach (string ent in ((LookupAttributeMetadata)attMetadata).Targets)
                                    {
                                        string parentEntity = ent;

                                        EntityMetadata entityMetad = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
                                        if (entityMetad != null)
                                        {
                                            if (entityMetad.PrimaryNameAttribute != null)
                                            {
                                                //Retrieve Record
                                                Guid parentEntityId = RetrieveEntityRecord(parentEntity, entityMetad.PrimaryNameAttribute, value, entityMetadata, isActivity, _serviceProxy);

                                                if (parentEntityId != Guid.Empty)
                                                {
                                                    objEntity[att] = new EntityReference(parentEntity, parentEntityId);
                                                    break;
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Owner)
                            {

                                Guid userId = RetrieveUserId(value, _serviceProxy);
                                if (userId != Guid.Empty)
                                {
                                    objEntity[att] = new EntityReference("systemuser", userId);
                                }
                                else
                                {
                                    Guid teamId = RetrieveTeamId(value, _serviceProxy);
                                    if (teamId != Guid.Empty)
                                    {
                                        objEntity[att] = new EntityReference("team", teamId);
                                    }
                                }
                            }

                        }
                        else
                        {
                            if (att != null && att.ToLower() == "stage")
                            {
                                stageName = value;
                            }
                            else if (att != null && att.ToLower() == "assign")
                            {
                                assign = value;
                            }

                        }

                    }

                    Count++;

                }
                if (recordId != Guid.Empty)
                {
                    service.Update(objEntity);

                    if (recordId != Guid.Empty)
                    {
                        if (!string.IsNullOrEmpty(assign))
                        {

                            Guid userId = RetrieveUserId(assign, _serviceProxy);
                            if (userId != Guid.Empty)
                            {
                                // Create the Request Object and Set the Request Object's Properties  
                                AssignRequest assignowner = new AssignRequest
                                {
                                    Assignee = new EntityReference("systemuser", userId),
                                    Target = new EntityReference(entityName, recordId)
                                };
                                // Execute the Request  
                                service.Execute(assignowner);
                            }
                            else
                            {
                                Guid teamId = RetrieveTeamId(assign, _serviceProxy);
                                if (teamId != Guid.Empty)
                                {

                                    // Create the Request Object and Set the Request Object's Properties  
                                    AssignRequest assignowner = new AssignRequest
                                    {
                                        Assignee = new EntityReference("team", teamId),
                                        Target = new EntityReference(entityName, recordId)
                                    };
                                    // Execute the Request  
                                    service.Execute(assignowner);

                                }
                            }

                        }
                        if (!string.IsNullOrEmpty(stageName))
                        {
                            // stageName = "CDD Analysis,Customer Contact,Non Respondent Customer";

                            AutomaticStageMovement.Newv9AutomaticBPFStageMovement(stageName, recordId, objEntity.LogicalName, _serviceProxy, entityMetadata);
                            // AutomaticStageMovement.AutomaticBPFStageMovement(stageName, recordId, _serviceProxy);
                        }
                    }
                    Console.WriteLine("Entity Updated successfully");
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "UpdateEntityRecord");
            }
            return RecordId;
        }

        /// <summary>
        /// This function will retrieve entitycollection data from CRM
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="attribute"></param>
        /// <param name="value"></param>
        /// <param name="isActivity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static EntityCollection RetrieveEntityCollection(string entityName, string attribute, string value, bool? isActivity, IOrganizationService service)
        {
            string primaryKey = entityName;
            EntityCollection entityC = null;
            try
            {
                // Set activity for activity type of entities
                if (isActivity != null && isActivity == true)
                    primaryKey = "activity";

                string fetchXML =
                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + primaryKey + @"id' />
    <filter type='and'>
      <condition attribute='" + attribute + @"' operator='eq' value='" + value + @"' />
<condition attribute='statecode' operator='eq' value='0' />
    </filter>
  </entity>
</fetch>";
                entityC = service.RetrieveMultiple(new FetchExpression(fetchXML));

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveEntityCollection");
            }
            return entityC;
        }

        /// <summary>
        /// This function will retrieve record from CRM
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="attribute"></param>
        /// <param name="value"></param>
        /// <param name="isActivity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static Guid RetrieveEntityRecord(string entityName, string attribute, string value, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            string primaryKey = entityName;

            Guid parentId = Guid.Empty;
            try
            {
                EntityMetadata entityMetad = null;
                entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == entityName.ToLower()).FirstOrDefault();
                if (entityMetad == null)
                    entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == entityName.ToLower()).FirstOrDefault();
                if (entityMetad != null)
                {
                    isActivity = entityMetad.IsActivity;

                }


                // Set activity for activity type of entities
                if (isActivity != null && isActivity == true)
                    primaryKey = "activity";

                string fetchXML =
                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + primaryKey + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter type='and'>
      <condition attribute='" + attribute + @"' operator='eq' value='" + value + @"' />
    </filter>
  </entity>
</fetch>";




                EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                {
                    parentId = new Guid(ecEntities.Entities[0][primaryKey + "id"].ToString());
                }

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveEntityRecord");
            }
            return parentId;
        }
        public static int? GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)
        {
            int? selectedOptionValue = null;
            try
            {
                RetrieveAttributeRequest retrieveAttributeRequest = new
                RetrieveAttributeRequest
                {
                    EntityLogicalName = entityName,
                    LogicalName = attributeName,
                    RetrieveAsIfPublished = true
                };
                // Execute the request.
                RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
                // Access the retrieved attribute.
                Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
                retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
                OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();

                foreach (OptionMetadata oMD in optionList)
                {
                    if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                    {
                        selectedOptionValue = oMD.Value.Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "GetOptionsSetValueForLabel");
            }
            return selectedOptionValue;

        }

        /// <summary>
        /// This function will retrieve attribute metadata of an entity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <returns></returns>
        public static List<AttributeMetadata> RetrieveAttributeMetadata(IOrganizationService service, string entityName)
        {
            List<AttributeMetadata> attributeMetadata = null;
            try
            {
                RetrieveEntityRequest req = new RetrieveEntityRequest();
                req.RetrieveAsIfPublished = true;
                req.LogicalName = entityName;
                req.EntityFilters = EntityFilters.Attributes;

                RetrieveEntityResponse resp = (RetrieveEntityResponse)service.Execute(req);
                attributeMetadata = resp.EntityMetadata.Attributes.ToList();

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveAttributeMetadata");
            }
            return attributeMetadata;
        }

        /// <summary>
        /// This function will retrieve entity metadata
        /// </summary>
        /// <param name="organizationService"></param>
        /// <returns></returns>
        public static EntityMetadata[] GetEntities(IOrganizationService organizationService)
        {
            EntityMetadata[] entities = null;
            try
            {

                RetrieveAllEntitiesRequest metaDataRequest = new RetrieveAllEntitiesRequest();
                RetrieveAllEntitiesResponse metaDataResponse = new RetrieveAllEntitiesResponse();
                metaDataRequest.EntityFilters = EntityFilters.Entity;

                // Execute the request.

                metaDataResponse = (RetrieveAllEntitiesResponse)organizationService.Execute(metaDataRequest);

                entities = metaDataResponse.EntityMetadata;


            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "GetEntities");
            }
            return entities;
        }

        /// <summary>
        /// This function will write error log in text file
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="className"></param>
        /// <param name="methodName"></param>
        public static void ErrorLogging(Exception ex, string className, string methodName)
        {
            try
            {

                string strPath = path + "Log.txt";
                //string strPath = @"C:\\RoleSwitchLogs\\Log.txt";
                if (!File.Exists(strPath))
                {
                    File.Create(strPath).Dispose();
                }
                using (StreamWriter sw = File.AppendText(strPath))
                {
                    sw.WriteLine("=============Error Logging ===========");
                    sw.WriteLine("===========Start============= " + DateTime.Now);
                    sw.WriteLine("Class Name: " + className + ", Method Name: " + methodName);
                    sw.WriteLine("Error Message: " + ex.Message);
                    sw.WriteLine("Inner Exception: " + ex.InnerException);
                    sw.WriteLine("Stack Trace: " + ex.StackTrace);
                    sw.WriteLine("===========End============= " + DateTime.Now);

                }
            }

            catch (Exception er)
            {

                throw er;
            }

        }
    }
}
