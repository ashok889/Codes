﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RBS.CRM.TestDataCreationUtility
{

    class DataDetailsKeyCriteriaClass
    {
        public int RowNo { get; set; }
        public int ColumnNo { get; set; }
        public string SheetName { get; set; }
        public string TestId { get; set; }
        public string AttributeName { get; set; }
        public string ReturnValue { get; set; }
        
    }


    /// <summary>
    ///  Prerequisites
    /// only compatible with 8.2
    /// 1. CRMOrgName , USername , Password 
    /// Automation Excelfile Path , DataExcel path needs to be updated 
    /// </summary>
    class Program
    {
        static void Main(string[] arg)
         {
            //Test date excel,
            string[] args = { "C:\\Projects\\CD.xlsx" };

            if (args.Count() == 1)
            {

                TestDataCreation.ReadAutoExcel();

                

                 TestDataCreation.ReadDataFromExcel(args);


                TestDataCreation.UpdateAutoExcel();


                // Microsoft.Office.Interop.Excel.Worksheet Sheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlApp.ActiveSheet;

            }

            }
        }
    
}
