﻿using Microsoft.Office.Interop.Excel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace RBS.CRM.TestDataCreationUtility
{
    class ASU_Functions
    {

        public static Guid RetreiveCaseId(string entityName, String Mvalue, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;

            try
            {
                Guid MortgageId = Guid.Empty;
                Guid CaseId = Guid.Empty;


                MortgageId = TestDataCreation.RetrieveEntityRecord("rbs_mortgage", "rbs_accountnumber", Mvalue, entityMetadata, isActivity, service);

                recordId = TestDataCreation.RetrieveEntityRecord("incident", "rbs_mortgageid", MortgageId.ToString(), entityMetadata, isActivity, service);

                if (recordId == Guid.Empty)
                {
                    Mvalue = Mvalue + "-Snapshot";
                    MortgageId = TestDataCreation.RetrieveEntityRecord("rbs_mortgage", "rbs_accountnumber" , Mvalue , entityMetadata, isActivity, service);
                    recordId = TestDataCreation.RetrieveEntityRecord("incident", "rbs_mortgageid", MortgageId.ToString(), entityMetadata, isActivity, service);

                }


            }
            catch (Exception ex)
            {

                TestDataCreation.ErrorLogging(ex, "ASU_Functions", "RetreiveCaseId");
            }

            return recordId;
        }
        public static Guid RetreiveSTD(string entityName, String CI, String No, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;

            try
            {

                String Attribute1 = "rbs_id";
                String Attribute2 = "rbs_customerinformationid";
                //write the value to the Grid  

                {
                    string fetchXML =
                                  @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter>
<condition attribute='" + Attribute1 + @"' operator='eq' value='" + No + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CI + @"' />
    </filter>
  </entity>
</fetch>";


                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }
            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveSTD");

            }
            return recordId;

        }
        public static Guid RetreiveDI(string entityName, String CI, String No, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;

            try
            {

                String Attribute1 = "rbs_name";
                String Attribute2 = "rbs_customerinformationid";
                //write the value to the Grid  

                {
                    string fetchXML =
                                  @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter>
<condition attribute='" + Attribute1 + @"' operator='eq' value='" + No + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CI + @"' />
    </filter>
  </entity>
</fetch>";


                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }
            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveDI");

            }
            return recordId;

        }
        public static Guid RetreiveCE(string entityName, String CI, String No, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;

            try
            {

                String Attribute1 = "rbs_id";
                String Attribute2 = "rbs_customerinformationid";
                //write the value to the Grid  

                {
                    string fetchXML =
                                  @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter>
<condition attribute='" + Attribute1 + @"' operator='eq' value='" + No + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CI + @"' />
    </filter>
  </entity>
</fetch>";


                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }

            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveCE");

            }
            return recordId;
        }
        public static Guid RetreiveCINC(string entityName, String CI, String IncomeType, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;

            try
            {
                Guid IncomeTypeId = Guid.Empty;

                String Attribute1 = "rbs_incometypeid";
                String Attribute2 = "rbs_customerinformationid";
                //write the value to the Grid  
                IncomeTypeId = TestDataCreation.RetrieveEntityRecord("rbs_incomeexpenditurecatalogue", "rbs_name", IncomeType, entityMetadata, isActivity, service);


                {
                    string fetchXML =
                                  @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter>
<condition attribute='" + Attribute1 + @"' operator='eq' value='" + IncomeTypeId + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CI + @"' />
    </filter>
  </entity>
</fetch>";


                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }
            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveCINC");

            }
            return recordId;

        }
        public static Guid RetreivePA(string entityName, String CI, String No, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;
            try
            {


                String Attribute1 = "rbs_id";
                String Attribute2 = "rbs_customerinformationid";
                //write the value to the Grid  

                {
                    string fetchXML =
                                  @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter>
<condition attribute='" + Attribute1 + @"' operator='eq' value='" + No + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CI + @"' />
    </filter>
  </entity>
</fetch>";


                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }
            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreivePA");

            }
            return recordId;

        }
        public static Guid RetreiveNPA(string entityName, String CI, String No, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;
            try
            {


                String Attribute1 = "rbs_id";
            String Attribute2 = "rbs_customerinformationid";
                //write the value to the Grid  

                {
                    string fetchXML =
                                  @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter>
<condition attribute='" + Attribute1 + @"' operator='eq' value='" + No + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CI + @"' />
    </filter>
  </entity>
</fetch>";


                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }
            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreivenNPA");

            }
            return recordId;

        }
        public static Guid RetreiveCI( string entityName, String Mvalue, String Cvalue,  EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;
            Guid MortgageId = Guid.Empty;
            Guid CaseId = Guid.Empty;
            Guid ContactId = Guid.Empty;
            try
            {
                String Attribute1 = "rbs_caseid";
            String Attribute2 = "rbs_contactid";
            //write the value to the Grid  

           
                MortgageId = TestDataCreation.RetrieveEntityRecord("rbs_mortgage", "rbs_accountnumber", Mvalue, entityMetadata, isActivity, service);

                CaseId = TestDataCreation.RetrieveEntityRecord("incident", "rbs_mortgageid", MortgageId.ToString(), entityMetadata, isActivity, service);
           

                ContactId = TestDataCreation.RetrieveEntityRecord("contact", "fullname", Cvalue, entityMetadata, isActivity, service);
           

            if (CaseId != Guid.Empty && ContactId != Guid.Empty)
            {
                string fetchXML =
               @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter type='and'>
      <condition attribute='" + Attribute1 + @"' operator='eq' value='" + CaseId + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + ContactId + @"' />
    </filter>
  </entity>
</fetch>";




                EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                {
                    recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                }

               
            }

            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveCI");

            }
            return recordId;




        }

        public static Guid RetreiveCCTR(string entityName, String Mvalue, String TreatReason, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;
            Guid MortgageId = Guid.Empty;
            Guid CaseId = Guid.Empty;
            Guid TreatReasonId = Guid.Empty;
            try
            { 
                String Attribute1 = "rbs_caseid";
                String Attribute2 = "rbs_treatmentreasonid";
                //write the value to the Grid  


                MortgageId = TestDataCreation.RetrieveEntityRecord("rbs_mortgage", "rbs_accountnumber", Mvalue, entityMetadata, isActivity, service);

                CaseId = TestDataCreation.RetrieveEntityRecord("incident", "rbs_mortgageid", MortgageId.ToString(), entityMetadata, isActivity, service);

                TreatReasonId = TestDataCreation.RetrieveEntityRecord("rbs_customertreatmentreason","rbs_reason",TreatReason,entityMetadata,isActivity,service);
            


                if (CaseId != Guid.Empty && TreatReasonId != Guid.Empty)
                {
                    string fetchXML =
                   @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter type='and'>
      <condition attribute='" + Attribute1 + @"' operator='eq' value='" + CaseId + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + TreatReasonId + @"' />
    </filter>
  </entity>
</fetch>";




                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }

            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveCI");

            }
            return recordId;




        }

        public static Guid RetreiveCCS(string entityName, String Mvalue, String Condition, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        {
            Guid recordId = Guid.Empty;
            Guid MortgageId = Guid.Empty;
            Guid CaseId = Guid.Empty;
            Guid CaseConditionId = Guid.Empty;
            try
            {
                String Attribute1 = "rbs_caseid";
                String Attribute2 = "rbs_conditionid";
                //write the value to the Grid  


                MortgageId = TestDataCreation.RetrieveEntityRecord("rbs_mortgage", "rbs_accountnumber", Mvalue, entityMetadata, isActivity, service);

                CaseId = TestDataCreation.RetrieveEntityRecord("incident", "rbs_mortgageid", MortgageId.ToString(), entityMetadata, isActivity, service);

                CaseConditionId = TestDataCreation.RetrieveEntityRecord("rbs_conditionsofsanctionlist", "rbs_id", Condition, entityMetadata, isActivity, service);



                if (CaseId != Guid.Empty && CaseConditionId != Guid.Empty)
                {
                    string fetchXML =
                   @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + entityName + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter type='and'>
      <condition attribute='" + Attribute1 + @"' operator='eq' value='" + CaseId + @"' />
      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + CaseConditionId + @"' />
    </filter>
  </entity>
</fetch>";




                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                    {
                        recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
                    }


                }

            }
            catch (Exception ex)
            {
                TestDataCreation.ErrorLogging(ex, "ASU Functions", "RetreiveCI");

            }
            return recordId;




        }

        //        public static Guid ASUEntityRecord(string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        //        {
        //            Guid RecordID = Guid.Empty;
        //            try
        //            {


        //                int rowCount = xlRange.Rows.Count;
        //                int colCount = xlRange.Columns.Count;

        //                for (int i = 2; i <= rowCount; i++)
        //                {
        //                    Console.WriteLine(i);

        //                    if (xlRange.Cells[i, 1] != null && xlRange.Cells[i, 1].Value2 != null)
        //                    {
        //                        string value = xlRange.Cells[i, 1].Value2.Trim();
        //                        if (value.ToLower() == "c")
        //                        {
        //                            //Create record
        //                            RecordID = TestDataCreation.CreateEntityRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);
        //                        }
        //                        else if (value.ToLower() == "u")
        //                        {//Update record
        //                            RecordID = ASUUpdateEntityRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);

        //                        }
        //                        else if (value.ToLower() == "d")
        //                        {
        //                            //Delete record
        //                            TestDataCreation.DeleteEntityRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);
        //                        }

        //                    }

        //                    if (RecordID != Guid.Empty)

        //                    {
        //                        int DataXLstartindex = Int32.Parse(ConfigurationManager.AppSettings["DataXLstartindex"]);
        //                        if (xlRange.Cells[i, DataXLstartindex] != null && xlRange.Cells[i, DataXLstartindex].Value2 != null)
        //                        {
        //                            string TestScriptName = string.Empty;
        //                            string Attribute = string.Empty;
        //                            string ReturnXLValue = string.Empty;

        //                            if (xlRange.Cells[i, DataXLstartindex - 2] != null && xlRange.Cells[i, DataXLstartindex - 2].Value2 != null)
        //                            {
        //                                Attribute = xlRange.Cells[i, DataXLstartindex - 2].Value2.Trim();
        //                            }

        //                            ReturnXLValue = TestDataCreation.GetAttributeValue(Attribute, attributeMetadata, entityMetadata, entityName, RecordID, service);

        //                            xlRange.Cells[i, DataXLstartindex - 1].Value2 = ReturnXLValue.ToString();
        //                            //    xlAutoWorkbook.Save();
        //                            int DataXLIdindex = Int32.Parse(ConfigurationManager.AppSettings["DataXLIdindex"]);

        //                            TestScriptName = xlRange.Cells[i, DataXLIdindex].Value2.Trim();

        //                            //    ReadAutomationData(TestScriptName,service,RecordID,entityMetadata, entityName, attributeMetadata);

        //                            DataDetailsKeyCriteriaClass result = TestDataCreation.AutomationList.Find(x => x.TestId == TestScriptName);
        //                            if (result != null)

        //                            {
        //                                if (result.AttributeName != null && result.AttributeName != "")
        //                                {
        //                                    string ReturnValue = TestDataCreation.GetAttributeValue(result.AttributeName, attributeMetadata, entityMetadata, entityName, RecordID, service);
        //                                    result.ReturnValue = ReturnValue;
        //                                    TestDataCreation.UpdatedAutomationList.Add(result);

        //                                }
        //                            }





        //                        }

        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                TestDataCreation.ErrorLogging(ex, "TestDataCreation", "EntityRecord");
        //            }
        //            return RecordID;

        //        }

        //        public static Guid ASURetrieveEntityRecord(string entityName, string attribute, string value, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        //        {
        //            string primaryKey = entityName;

        //            Guid parentId = Guid.Empty;

        //            if (primaryKey == "rbs_customerinformation")
        //            {
        //                Guid CaseId = Guid.Empty;
        //                Guid ContactId = Guid.Empty;



        //                EntityMetadata entityMetad = null;
        //                entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == entityName.ToLower()).FirstOrDefault();
        //                if (entityMetad == null)
        //                    entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == entityName.ToLower()).FirstOrDefault();
        //                if (entityMetad != null)
        //                {
        //                    isActivity = entityMetad.IsActivity;

        //                }


        //                // Set activity for activity type of entities
        //                if (isActivity != null && isActivity == true)
        //                    primaryKey = "activity";

        //                string fetchXML =
        //                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //  <entity name='" + entityName + @"'>
        //    <attribute name='" + primaryKey + @"id' />
        //  <attribute name='createdon' />
        //  <order attribute='createdon' descending='true' />
        //  <filter type='and'>
        //      <condition attribute='" + attribute + @"' operator='eq' value='" + value + @"' />
        //    </filter>
        //  </entity>
        //</fetch>";




        //                EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

        //                if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
        //                {
        //                    parentId = new Guid(ecEntities.Entities[0][primaryKey + "id"].ToString());
        //                }


        //            }

        //            else
        //            {


        //                try
        //                {
        //                    EntityMetadata entityMetad = null;
        //                    entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == entityName.ToLower()).FirstOrDefault();
        //                    if (entityMetad == null)
        //                        entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == entityName.ToLower()).FirstOrDefault();
        //                    if (entityMetad != null)
        //                    {
        //                        isActivity = entityMetad.IsActivity;

        //                    }


        //                    // Set activity for activity type of entities
        //                    if (isActivity != null && isActivity == true)
        //                        primaryKey = "activity";

        //                    string fetchXML =
        //                            @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //  <entity name='" + entityName + @"'>
        //    <attribute name='" + primaryKey + @"id' />
        //  <attribute name='createdon' />
        //  <order attribute='createdon' descending='true' />
        //  <filter type='and'>
        //      <condition attribute='" + attribute + @"' operator='eq' value='" + value + @"' />
        //    </filter>
        //  </entity>
        //</fetch>";




        //                    EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

        //                    if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
        //                    {
        //                        parentId = new Guid(ecEntities.Entities[0][primaryKey + "id"].ToString());
        //                    }

        //                }
        //                catch (Exception ex)
        //                {
        //                    TestDataCreation.ErrorLogging(ex, "TestDataCreation", "RetrieveEntityRecord");
        //                }
        //            }
        //            return parentId;
        //        }

        //        public static Guid ASUUpdateEntityRecord(int i, int colCount, string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, bool? isActivity, IOrganizationService service)
        //        {
        //            Guid RecordId = Guid.Empty;
        //            try
        //            {
        //                Entity objEntity = new Entity();
        //                objEntity.LogicalName = entityName;
        //                string stageName = string.Empty;
        //                string assign = string.Empty;
        //                int Count = 0;


        //                Guid recordId = Guid.Empty;
        //                Guid MortgageId = Guid.Empty;
        //                Guid CaseId = Guid.Empty;
        //                Guid ContactId = Guid.Empty;
        //                for (int j = Int32.Parse(ConfigurationManager.AppSettings["DataXLstartindex"]); j <= colCount; j++)  //   Start from unique column name on which filtering required ams 
        //                {

        //                    if (Count == 0)
        //                    {

        //                        String Attribute1 = "rbs_caseid";
        //                        String Attribute2 = "rbs_contactid";
        //                        //write the value to the Grid  

        //                        if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
        //                        {
        //                            string value = xlRange.Cells[i, j].Value2.ToString().Trim();
        //                            MortgageId = ASURetrieveEntityRecord("rbs_mortgage", "rbs_accountnumber", value, entityMetadata, isActivity, service);

        //                            CaseId = ASURetrieveEntityRecord("incident", "rbs_mortgageid", MortgageId.ToString(), entityMetadata, isActivity, service);
        //                        }
        //                        if (xlRange.Cells[i, j + 1] != null && xlRange.Cells[i, j + 1].Value2 != null)
        //                        {
        //                            string value = xlRange.Cells[i, j + 1].Value2.ToString().Trim();

        //                            ContactId = ASURetrieveEntityRecord("contact", "fullname", value, entityMetadata, isActivity, service);
        //                        }

        //                        if (CaseId != Guid.Empty && ContactId != Guid.Empty)
        //                        {
        //                            string fetchXML =
        //                           @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //  <entity name='" + entityName + @"'>
        //    <attribute name='" + entityName + @"id' />
        //  <attribute name='createdon' />
        //  <order attribute='createdon' descending='true' />
        //  <filter type='and'>
        //      <condition attribute='" + Attribute1 + @"' operator='eq' value='" + CaseId + @"' />
        //      <condition attribute='" + Attribute2 + @"' operator='eq' value='" + ContactId + @"' />
        //    </filter>
        //  </entity>
        //</fetch>";




        //                            EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

        //                            if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
        //                            {
        //                                recordId = new Guid(ecEntities.Entities[0][entityName + "id"].ToString());
        //                            }



        //                        }
        //                        objEntity.Id = recordId;
        //                        Count++;
        //                        continue;

        //                    }





        //                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
        //                    {
        //                        string value = xlRange.Cells[i, j].Value2.ToString().Trim();
        //                        string att = attribute[j - 1];
        //                        //Retrieve attribute from AttributeMetadata

        //                        // AttributeMetadata attMetadata = attributeMetadata.Find(x => x.DisplayName.LocalizedLabels.Count>0 && x.DisplayName.LocalizedLabels[0] !=null && x.DisplayName.LocalizedLabels[0].Label == att);
        //                        AttributeMetadata attMetadata = attributeMetadata.Find(x => x.LogicalName == att || (x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == att.ToLower()));

        //                        if (Count == 0)
        //                        {
        //                            // Search record from Unique attribute
        //                            recordId = ASURetrieveEntityRecord(entityName, attMetadata.LogicalName, value, entityMetadata, isActivity, service);
        //                            objEntity.Id = recordId;
        //                            Count++;
        //                            continue;
        //                        }

        //                        if (recordId == Guid.Empty)
        //                        {
        //                            break;
        //                        }
        //                        else
        //                        {
        //                            RecordId = recordId;

        //                        }
        //                        if (attMetadata != null)
        //                        {
        //                            att = attMetadata.LogicalName;


        //                            if (attMetadata.AttributeType == AttributeTypeCode.Boolean)
        //                            {

        //                                if (value.ToLower() == "yes")
        //                                    objEntity[att] = true;
        //                                else if (value.ToLower() == "no")
        //                                    objEntity[att] = false;
        //                                else
        //                                    objEntity[att] = (Boolean)xlRange.Cells[i, j].Value2;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Decimal)
        //                            {
        //                                objEntity[att] = (Decimal)xlRange.Cells[i, j].Value2;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Double)
        //                            {
        //                                objEntity[att] = (Double)xlRange.Cells[i, j].Value2;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.DateTime)
        //                            {
        //                                double d = (Double)(xlRange.Cells[i, j].Value2);
        //                                DateTime dateTime = DateTime.FromOADate(d).Date;
        //                                objEntity[att] = dateTime;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.String)
        //                            {
        //                                objEntity[att] = value;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Picklist)
        //                            {
        //                                int optionSetValue = TestDataCreation.GetOptionsSetValueForLabel(service, entityName, att, xlRange.Cells[i, j].Value2.Trim());
        //                                if (optionSetValue != 0)
        //                                    objEntity[att] = new OptionSetValue(optionSetValue);
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Lookup)
        //                            {
        //                                string parentEntity = ((LookupAttributeMetadata)attMetadata).Targets[0];

        //                                EntityMetadata entityMetad = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
        //                                if (entityMetad != null)
        //                                {
        //                                    if (entityMetad.PrimaryNameAttribute != null)
        //                                    {
        //                                        //Retrieve Record
        //                                        Guid parentEntityId = ASURetrieveEntityRecord(parentEntity, entityMetad.PrimaryNameAttribute, value, entityMetadata, isActivity, service);
        //                                        if (parentEntityId != Guid.Empty)
        //                                            objEntity[att] = new EntityReference(parentEntity, parentEntityId);
        //                                    }
        //                                }

        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Money)
        //                            {
        //                                objEntity[att] = new Money((Decimal)xlRange.Cells[i, j].Value2);
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Memo)
        //                            {
        //                                objEntity[att] = value;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.BigInt)
        //                            {
        //                                objEntity[att] = value;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Uniqueidentifier)
        //                            {
        //                                objEntity[att] = value;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Status)
        //                            {
        //                                objEntity[att] = value;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.State)
        //                            {
        //                                objEntity[att] = value;
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Customer)
        //                            {
        //                                if (((LookupAttributeMetadata)attMetadata).Targets.Count() > 0)
        //                                {
        //                                    foreach (string ent in ((LookupAttributeMetadata)attMetadata).Targets)
        //                                    {
        //                                        string parentEntity = ent;

        //                                        EntityMetadata entityMetad = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
        //                                        if (entityMetad != null)
        //                                        {
        //                                            if (entityMetad.PrimaryNameAttribute != null)
        //                                            {
        //                                                //Retrieve Record
        //                                                Guid parentEntityId = ASURetrieveEntityRecord(parentEntity, entityMetad.PrimaryNameAttribute, value, entityMetadata, isActivity, service);

        //                                                if (parentEntityId != Guid.Empty)
        //                                                {
        //                                                    objEntity[att] = new EntityReference(parentEntity, parentEntityId);
        //                                                    break;
        //                                                }

        //                                            }
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                            else if (attMetadata.AttributeType == AttributeTypeCode.Owner)
        //                            {

        //                                Guid userId = TestDataCreation.RetrieveUserId(value, service);
        //                                if (userId != Guid.Empty)
        //                                {
        //                                    objEntity[att] = new EntityReference("systemuser", userId);
        //                                }
        //                                else
        //                                {
        //                                    Guid teamId = TestDataCreation.RetrieveTeamId(value, service);
        //                                    if (teamId != Guid.Empty)
        //                                    {
        //                                        objEntity[att] = new EntityReference("team", teamId);
        //                                    }
        //                                }
        //                            }

        //                        }
        //                        else
        //                        {
        //                            if (att != null && att.ToLower() == "stage")
        //                            {
        //                                stageName = value;
        //                            }
        //                            else if (att != null && att.ToLower() == "assign")
        //                            {
        //                                assign = value;
        //                            }

        //                        }

        //                    }

        //                    Count++;

        //                }
        //                if (recordId != Guid.Empty)
        //                {
        //                    service.Update(objEntity);

        //                    if (recordId != Guid.Empty)
        //                    {
        //                        if (!string.IsNullOrEmpty(assign))
        //                        {

        //                            Guid userId = TestDataCreation.RetrieveUserId(assign, service);
        //                            if (userId != Guid.Empty)
        //                            {
        //                                // Create the Request Object and Set the Request Object's Properties  
        //                                AssignRequest assignowner = new AssignRequest
        //                                {
        //                                    Assignee = new EntityReference("systemuser", userId),
        //                                    Target = new EntityReference(entityName, recordId)
        //                                };
        //                                // Execute the Request  
        //                                service.Execute(assignowner);
        //                            }
        //                            else
        //                            {
        //                                Guid teamId = TestDataCreation.RetrieveTeamId(assign, service);
        //                                if (teamId != Guid.Empty)
        //                                {

        //                                    // Create the Request Object and Set the Request Object's Properties  
        //                                    AssignRequest assignowner = new AssignRequest
        //                                    {
        //                                        Assignee = new EntityReference("team", teamId),
        //                                        Target = new EntityReference(entityName, recordId)
        //                                    };
        //                                    // Execute the Request  
        //                                    service.Execute(assignowner);

        //                                }
        //                            }

        //                        }
        //                        if (!string.IsNullOrEmpty(stageName))
        //                        {
        //                            // stageName = "CDD Analysis,Customer Contact,Non Respondent Customer";


        //                            AutomaticStageMovement.AutomaticBPFStageMovement(stageName, recordId, service);
        //                        }
        //                    }
        //                    Console.WriteLine("Entity Updated successfully");
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                TestDataCreation.ErrorLogging(ex, "TestDataCreation", "UpdateEntityRecord");
        //            }
        //            return RecordId;
        //        }
    }
}

