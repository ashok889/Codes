﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;
using System.Xml.Linq;
using System.Text;

namespace DES.Crm.Core.XmlConfigHelper
{
    public static class SystemConfiguration
    {   
        /// <summary>
        /// System Configuration Entity Name
        /// </summary>
        const string SystemConfigurationEntityName = "rbsm_SystemConfiguration";
        /// <summary>
        /// System Configuration WebResource Name
        /// </summary>
        const string SystemConfigurationWebResourceName = "new_XMLSystemConfiguration";
        /// <summary>
        /// Returns string array of values corresponding to the configuration setting key.
        /// </summary>
        /// <param name="key">Configuration key</param>
        /// <returns></returns>
        static string Retrieve(IOrganizationService service, string key)
        {
            //Sample format of XML File
            ///
            // string XML = 
            //
            //              <?xml version="1.0" encoding="utf-8" ?>
            //                  <SystemConfiguration>
            //                          <Configuration Key="USMailBox" Value="USMail@US.com"></Configuration>
            //                          <Configuration Key="UKMailBox" Value="UKMail@UK.com"></Configuration>
            //                  </SystemConfiguration>
            //

            if (!String.IsNullOrEmpty(key))
                throw new Exception("Configuration Key does not exist in request.");   

            try
            {
                if (service != null)
                {                    
                    XDocument xDocSystemConfigs = XDocument.Parse(GetWebResource(service, SystemConfigurationEntityName, SystemConfigurationWebResourceName));                                        

                    var SystemConfigurations = from systemconfiguration in xDocSystemConfigs.Descendants("SystemConfiguration")
                                               let configuration = from configuration in systemconfiguration.Descendants("Configuration")
                                                                   let configKey = configuration.Attribute("Key").Value
                                                                   let configValue = configuration.Attribute("Value").Value
                                                                   select new { Key = configKey, Value = configValue }
                                               select new { configuration };
                    
                    foreach (var Systemconfiguration in SystemConfigurations)
                    {                     
                         var Value = Systemconfiguration.configuration.Where(obj => obj.Key == key).FirstOrDefault().Value;
                         
                        if (String.IsNullOrEmpty(Value))
                                throw new Exception("Configuration Settings does not exist for the key - '" + key + "'.");

                         return Value;                        
                    }    
                }
                else
                    throw new Exception("CRM Service object has not been initialised.");

                return null;

            }
            catch (Exception ex)
            {
                throw ex;
            }            
        }        

        /// <summary>
        /// Dynamically Get the Web Resource from Service Object
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entityName"></param>
        /// <param name="webresourceName"></param>
        /// <returns></returns>
        private static string GetWebResource(IOrganizationService service, string entityName, string webresourceName)
        {
            ColumnSet cols = new ColumnSet();
            cols.AddColumn("content");
            QueryByAttribute requestWebResource = new QueryByAttribute
            {
                EntityName = entityName,
                ColumnSet = cols
            };
            requestWebResource.Attributes.AddRange("name");
            requestWebResource.Values.AddRange(webresourceName);

            Entity webResourceEntity = null;
            string resourceContent = null;

            try
            {
                EntityCollection webResourceEntityCollection = service.RetrieveMultiple(requestWebResource);                

                if (webResourceEntityCollection.Entities.Count > 0)
                {
                    webResourceEntity = webResourceEntityCollection.Entities[0];
                    byte[] binary = Convert.FromBase64String(webResourceEntity.Attributes["content"].ToString());
                    resourceContent = System.Text.Encoding.UTF8.GetString(binary);
                    string byteOrderMarkUtf8 = Encoding.UTF8.GetString(Encoding.UTF8.GetPreamble());
                    if (resourceContent.StartsWith(byteOrderMarkUtf8))
                    {
                        resourceContent = resourceContent.Remove(0, byteOrderMarkUtf8.Length);
                    }
                }
                else
                    throw new Exception("Web Resource object not exist in CRM Service.");
            }
            catch (Exception ex)
            {
                throw ex;
            }   
            return resourceContent;
        }
    }   
}
