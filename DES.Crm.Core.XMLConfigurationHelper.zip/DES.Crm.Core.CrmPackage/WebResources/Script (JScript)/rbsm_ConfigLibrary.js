﻿var xhttp;
var xmlFile;
var xmlString;
var xmlDoc;
function CreateHttpObject() {
    if (xhttp != null)
        return xhttp;

    if (window.ActiveXObject) {
        xhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        xhttp = new XMLHttpRequest();
    }
    return xhttp;
}

function loadXMLDoc() {
    CreateHttpObject();
    xhttp.open("GET", "http://localhost:2071/XmlConfig/1", false);
    try {
        xhttp.setRequestHeader("Content-Type", "application/xml");
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4) {
                if (xhttp.status == 200) {
                    return xhttp.responseXML;
                }
            }
        }
        xhttp.send();
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = false;
        xmlDoc.loadXML(xhttp.responseText);
    } catch (err) { }
}

function transformXsl(filename) {
    CreateHttpObject();
    xhttp.open("GET", filename, false);
    try {
        xhttp.setRequestHeader("Content-Type", "application/xml");
    } catch (err) { }
    xhttp.send("");
    return xhttp.responseXML;
}

function displayResult() {
    document.getElementById("Categories").innerHTML = "";
    loadXMLDoc();
    xml = xhttp.responseXML;
    xsl = transformXsl("../xml/Categories.xslt");
    if (window.ActiveXObject || xhttp.responseType == "msxml-document") {
        ex = xml.transformNode(xsl);
        document.getElementById("Categories").innerHTML = ex;
    }
    else if (document.implementation && document.implementation.createDocument) {
        xsltProcessor = new XSLTProcessor();
        xsltProcessor.importStylesheet(xsl);
        resultDocument = xsltProcessor.transformToFragment(xml, document);
        document.getElementById("Categories").appendChild(resultDocument);
    }
}

function defineStructure()
{
    var config = xmlDoc.getElementsByTagName('Configuration');
    for (var i = 0, len = config.length; i < (len-1); i++) {
        var key = config[i].getAttribute('Key');
            xmlDoc.documentElement.removeChild(config[i]);
        }
}

function CreateXMLNode(K, V) {
    if (K != null && K.length > 0 && V != null && V.length > 0) {
        var config;
        var Keytxt;
        loadXMLDoc();
        debugger;
        defineStructure();

        var data = [];
        var str = "";
        var table = document.getElementById('XmlTable');
        var rows = table.getElementsByTagName('tr');
        for (var row = 0; row < (rows.length - 1) ; row++) {
            var input = rows[row].getElementsByTagName('input');
                config = xmlDoc.createElement("Configuration");
                config.setAttribute("Key", input[0].id);
                config.setAttribute("Value", input[1].value);
                xmlDoc.documentElement.appendChild(config);
        }
        //var configuration = xmlDoc.getElementsByTagName('Configuration');
        //for (i = 0; i < configuration.length; i++) {
        //    Keytxt = configuration[i].getAttribute('Key');
        //    if (Keytxt == K) {
        //        alert("Key exist");
        //        return;
        //    }
        //}
        //var count = xmlDoc.evaluate('count(//*Configuration[@Key=' + K + ']', xmlDoc, null, XPathResult.ANY_TYPE, null);
        //config = xmlDoc.createElement("Configuration");
        //config.setAttribute("Key", K);
        //config.setAttribute("Value", V);
        //xmlDoc.documentElement.appendChild(config);
        //doPost();
        window.close();
    }
}

function EditXMLNode() {
    loadXMLDoc();
    debugger;
    defineStructure();

    var data = [];
    var str = "";
    var table = document.getElementById('XmlTable');
    var rows = table.getElementsByTagName('tr');
    for (var row = 0; row < (rows.length - 1) ; row++) {
        var input = rows[row].getElementsByTagName('input');
        config = xmlDoc.createElement("Configuration");
        for (var col = 0; col < input.length; col++) {
            config.setAttribute("Key", input[col].id);
            config.setAttribute("Value", input[col].id);
            xmlDoc.documentElement.appendChild(config);
        }
    }
        //var KeyTxt, ValueTxt;
    //KeyTxt = document.getElementById(K).value;
    //ValueTxt = document.getElementById(V).value;
    //{
    //    config = xmlDoc.getElementsByTagName('Configuration');
    //    for (var i = 0, len = config.length; i < len; i++) {
    //        var key = config[i].getAttribute('Key');
    //        if (key == KeyTxt) {
    //            config[i].setAttribute("Value", ValueTxt);
    //            break;
    //        }
    //        else {

    //        }
    //    }
    //}
    doPost();
}
function doPost(){
    xhttp.open("POST", "http://localhost:2071/XmlConfig", true);
        try {
            xhttp.setRequestHeader("Content-Type", "text/xml");
            xhttp.setRequestHeader("Content-length", xmlDoc.xml.length);
            xhttp.onreadystatechange = function () {
                if (xhttp.readyState == 4) {
                    if (xhttp.status == 200) {
                        return xhttp;
                    }
                }
            }
            debugger;
            xhttp.send(xmlDoc.xml);
            //xhttp.send('Xml='+xmlDoc.xml+'&Keyname='+K+'&Keyval='+V);
    } catch (err) { }
}
function RemoveXMLNode(K) {
    if (K != null && K.length > 0) {
        var config;
        loadXMLDoc();
        var config = xmlDoc.getElementsByTagName('Configuration');
        for (var i = 0, len = config.length; i < len; i++) {
            var key = config[i].getAttribute('Key');
            if (key == K) {
                xmlDoc.documentElement.removeChild(config[i]);
                break;
            }
        }
        var V = "";
        doPost(K,V);
    }
}
