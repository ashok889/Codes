﻿function Retrieve(key) {

    var configurationValue;
    var XMLDoc = $.parseXML(LoadWebResource('new_XMLSystemConfiguration'));
    if (!(typeof XMLDoc === 'undefined' || XMLDoc === null)) {
        try {
                configNode = xmlDoc.getElementsByTagName('Configuration');
                if (!(typeof configNode === 'undefined' || configNode === null)) {
                    for (i = 0; i < configNode.length; i++) {
                        if (configNode[i].getAttribute('Key') == key) {
                            configurationValue = configNode[i].getAttribute('Value');
                        }
                    }
                }
                else
                    alert("Configuration Settings does not exist for the key - '" + key + "'.");
            }
            catch (e) {
                alert("Error while retrieving XML from WebResource" + e.description);
        }
    }
    return configurationValue;
}

function LoadWebResource(webResource) {
    var httpRequest = null;
    try {
            if (window.XMLHttpRequest) {  
                httpRequest = new XMLHttpRequest();
        }
    else{  
            httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
        }

        var serverUrl= Xrm.Page.context.getServerUrl(); 
        if (serverUrl.match(/\/$/)) {
            serverUrl = serverUrl.substring(0, serverUrl.length - 1);
        }

        httpRequest.open("GET", serverUrl + "/webresources/" + webResource, false);
        httpRequest.send(null);

        eval(httpRequest.responseText);
    }
    catch (e) {
        alert("LoadWebResource >> Error loading " + webResource + ":\n" + e.description);
    }
}