﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;

namespace DES.Crm.Core.ConfigHelperUI
{
    public partial class ConfigUI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string xml = Request.Form[0].ToString();
            //XmlDocument doc = new XmlDocument();
            //doc.LoadXml(xml);
            //doc.Save(@"..\DES.Crm.Core.CrmPackage\WebResources\XML\Categories.xml");
        }
        public void Save()
        {
            string xml = Request.Form[0].ToString();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            doc.Save(@"..\DES.Crm.Core.CrmPackage\WebResources\XML\Categories.xml");
        }
    }
}