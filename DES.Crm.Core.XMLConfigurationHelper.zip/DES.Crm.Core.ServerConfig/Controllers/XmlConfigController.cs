﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Http;
using System.Xml;
using Microsoft.Xrm.Sdk;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Text;
using System.Net;
using System.Xml.Linq;
using System.Linq;
namespace DES.Crm.Core.ServerConfig.Controllers
{
    public class XmlConfigController : ApiController
    {
        string FetchXml()
        {
            string xml = "";
            _service = GetOrganization();
            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                    <entity name='webresource' >
                                        <filter type='and' >
                                            <condition attribute='name' operator='eq' value='new_XmlConfiguration' />
                                        </filter>
                                    </entity>
                              </fetch>";
            EntityCollection WebResource = _service.RetrieveMultiple(new FetchExpression(sFetch));
            if (WebResource != null && WebResource.Entities != null)
            {
                Entity enWebResourceToUpdate = new Entity("webresource");
                enWebResourceToUpdate.Id = WebResource.Entities[0].Id;
                if (WebResource.Entities[0].Attributes.Contains("content"))
                {
                    byte[] binary = Convert.FromBase64String(WebResource.Entities[0].Attributes["content"].ToString());
                    xml = UnicodeEncoding.UTF8.GetString(binary);
                }
            }
            return xml;
        }
        [HttpGet]
        public HttpResponseMessage Get(int id)
        {
            string xml = FetchXml();
            var msg = new HttpResponseMessage() 
              { 
                Content = new StringContent(xml, Encoding.UTF8, "application/xml")                 
              };

            return msg;
                   
        }

        [HttpPost]
        public void Post(HttpRequestMessage value)
        {
            string xml = FetchXml();
            //XDocument xdoc = XDocument.Load(xml);
            //var nodes = from configuration in xdoc.Descendants("Configuration")
            //                     where configuration.Element("Configuration").Attribute("Key").Value == K
            //                     select configuration;
            XmlDocument doc = new XmlDocument();
            doc.Load(value.Content.ReadAsStreamAsync().Result);
            _service = GetOrganization();
            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                    <entity name='webresource' >
                                        <filter type='and' >
                                            <condition attribute='name' operator='eq' value='new_XmlConfiguration' />
                                        </filter>
                                    </entity>
                              </fetch>";
            EntityCollection WebResource = _service.RetrieveMultiple(new FetchExpression(sFetch));
            if (WebResource != null && WebResource.Entities != null)
            {
                Entity enWebResourceToUpdate = new Entity("webresource");
                enWebResourceToUpdate.Id = WebResource.Entities[0].Id;
                byte[] byteArr = new byte[doc.InnerXml.Length];
                char[] charArr=doc.InnerXml.ToCharArray();
                for (int i = 0; i < charArr.Length;i++ )
                {
                    byteArr[i] = (byte)charArr[i];
                }
                string XmlData = Convert.ToBase64String(byteArr, 0, byteArr.Length);
                enWebResourceToUpdate.Attributes["content"] = XmlData;
                UpdateRequest updaterequest = new UpdateRequest { Target = enWebResourceToUpdate };
                _service.Execute(updaterequest);
                string webResctag = "<webresource>" + enWebResourceToUpdate.Id + "</webresource>";
                string webrescXml = "<importexportxml><webresources>" + webResctag + "</webresources></importexportxml>";

                PublishXmlRequest publishxmlrequest = new PublishXmlRequest
                {

                    ParameterXml = String.Format(webrescXml)

                };
                _service.Execute(publishxmlrequest);

            }
        }
        public IOrganizationService _service=null;
        public IOrganizationService GetOrganization()
        {
            System.Uri organizationUri = new Uri("http://lonms14572/RBSMARKETSDEMO01/XRMServices/2011/Organization.svc");
            var cred = new ClientCredentials();
            OrganizationServiceProxy _serviceproxy = new OrganizationServiceProxy(organizationUri, null, cred, null);
            _service = (IOrganizationService)_serviceproxy;
            return _service;
        }

        public void Put(int id, [FromBody] string value)
        {
        }

        public void Delete(int id)
        {
        }
    }
}