﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using System.Net;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Query;
using System.DirectoryServices.AccountManagement;

namespace RBS.EE.CRM.Common
{
    public class CRMPositionAssignment
    {

        public static void AddMainPositions(string user, string password, string addUserRacf, string positionName, string exceptionEmailTo, string instanceUri)
        {
            try
            {
                IOrganizationService service = CommonFunctions.GetConnections(user, password, instanceUri);
                
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                string emailTo = MSFlowEmail.FindEmailAddressByRacf(ctx, addUserRacf, exceptionEmailTo);
                //Retreive users
                QueryExpression query = new QueryExpression
                {
                    EntityName = "systemuser",
                    ColumnSet = new ColumnSet("systemuserid","isdisabled")
                };
                query.Criteria.AddCondition("domainname", ConditionOperator.Equal, emailTo);
                query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                var users = service.RetrieveMultiple(query);
                Guid positionId = RetreiveMainPositions(service, positionName);

                if (users.Entities.Count == 1)
                {
                    foreach (Entity userEntity in users.Entities)
                    {
                        Guid userId = userEntity.Id;
                        if (positionId != Guid.Empty)
                        {
                            userEntity["positionid"] = new EntityReference("position", positionId);
                            service.Update(userEntity);
                        }
                        else
                        {
                            throw new Exception(positionName + "Position Does Not Exist While Assinging To User " + addUserRacf);
                        }
                    }

                }
                else
                {
                    throw new Exception(addUserRacf + "Either in Disabled state or Not activated");
                }
            }
            catch(Exception ex)
            {
                throw new Exception(addUserRacf + "Adding Main Position failed");
            }

        }
        public static void AddAdditionalPositions(string user, string password, string addUserRacf, string positionName, string exceptionEmailTo, string instanceUri)
        {
            try
            {
                IOrganizationService service = CommonFunctions.GetConnections(user, password, instanceUri);
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                string emailTo = MSFlowEmail.FindEmailAddressByRacf(ctx, addUserRacf, exceptionEmailTo);
                QueryExpression query = new QueryExpression
                {
                    EntityName = "systemuser",
                    ColumnSet = new ColumnSet("systemuserid", "isdisabled")
                };
                query.Criteria.AddCondition("domainname", ConditionOperator.Equal, emailTo);
                query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                var users = service.RetrieveMultiple(query);
                Guid positionId = RetreiveMainPositions(service, positionName);
                if (users.Entities.Count == 1)
                {
                    foreach (Entity userEntity in users.Entities)
                    {
                        Guid userId = userEntity.Id;
                        if (positionId != Guid.Empty)
                        {
                            Entity userPositions = new Entity("rbs_userposition");
                            userPositions["rbs_positionid"] = new EntityReference("position", positionId);
                            userPositions["rbs_userid"] = new EntityReference("systemuser", userId);
                            service.Create(userPositions);
                        }
                        else
                        {
                            throw new Exception(positionName + "Position Does Not Exist While Assinging To User " + addUserRacf);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw new Exception(addUserRacf + "Adding Additional Position Failed");
            }
        }
        public static void RemoveMainPositions(string user, string password, string removeUserRacf, string positionName, string exceptionEmailTo, string instanceUri)
        {
            try
            {
                IOrganizationService service = CommonFunctions.GetConnections(user, password, instanceUri);
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                string emailTo = MSFlowEmail.FindEmailAddressByRacf(ctx, removeUserRacf, exceptionEmailTo);
                //Retreive users
                QueryExpression query = new QueryExpression
                {
                    EntityName = "systemuser",
                    ColumnSet = new ColumnSet("systemuserid", "isdisabled")
                };
                query.Criteria.AddCondition("domainname", ConditionOperator.Equal, emailTo);
                query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                var users = service.RetrieveMultiple(query);
                //Guid positionId = RetreiveMainPositions(service, positionName);

                if (users.Entities.Count == 1)
                {
                    foreach (Entity userEntity in users.Entities)
                    {
                        Guid userId = userEntity.Id;

                        //if (positionId != Guid.Empty)
                        //{
                        userEntity["positionid"] = null;
                        service.Update(userEntity);
                    }
                }
            }
            catch(Exception ex)
            {
                throw new Exception(removeUserRacf + "Removal of Main Position failed ");
            }
        }
        public static void RemoveAdditionalPositions(string user, string password, string removeUserRacf, string positionName, string exceptionEmailTo, string instanceUri)
        {
            try
            {
                IOrganizationService service = CommonFunctions.GetConnections(user, password, instanceUri);
                Guid positionId = RetreiveMainPositions(service, positionName);
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                string emailTo = MSFlowEmail.FindEmailAddressByRacf(ctx, removeUserRacf, exceptionEmailTo);
                //Retreive users
                QueryExpression query = new QueryExpression
                {
                    EntityName = "systemuser",
                    ColumnSet = new ColumnSet("systemuserid", "isdisabled")
                };
                query.Criteria.AddCondition("domainname", ConditionOperator.Equal, emailTo);
                query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);
                var users = service.RetrieveMultiple(query);
                if (users.Entities.Count == 1)
                {
                    foreach (Entity userEntity in users.Entities)
                    {
                        Guid userId = userEntity.Id;
                        //Retrieve User Positions
                        QueryExpression queryUserPositions = new QueryExpression
                        {
                            EntityName = "rbs_userposition",
                            ColumnSet = new ColumnSet("rbs_userpositionid")
                        };
                        queryUserPositions.Criteria.AddCondition("rbs_userpositionid", ConditionOperator.Equal, positionId);
                        queryUserPositions.Criteria.AddCondition("rbs_userid", ConditionOperator.Equal, userId);
                        var userPositions = service.RetrieveMultiple(queryUserPositions);
                        if (userPositions.Entities.Count == 1)
                        {
                            foreach (Entity userPositionEntity in userPositions.Entities)
                            {
                                Guid userPositionId = userPositionEntity.Id;
                                service.Delete("rbs_userposition", userPositionId);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw new Exception(removeUserRacf + "Removal of Additional Position Failed");
            }

        }
        public static Guid RetreiveMainPositions(IOrganizationService service, string positionName)
        {
            try
            {
                Guid positionId = Guid.Empty;
                QueryExpression query = new QueryExpression
                {
                    EntityName = "position",
                    ColumnSet = new ColumnSet("positionid", "name")
                };
                //query.Criteria.AddCondition("name", ConditionOperator.Equal, positionName);
                var positionCollection = service.RetrieveMultiple(query);
                if (positionCollection.Entities.Count == 1)
                {
                    positionId = (Guid)positionCollection[0].Attributes["positionid"];

                }
                foreach (Entity positionEntity in positionCollection.Entities)
                {
                    string positionEntityName = (positionEntity["name"].ToString()).Replace(" ", string.Empty);
                    if (positionEntityName == positionName)
                    {
                        return positionEntity.Id;
                    }
                }
                return positionId;
            }
            catch (Exception ex)
            {
                throw new Exception("Retrieval of Main Position Failed");
            }
        }
        public static IOrganizationService GetConnections(string user, string password, string instanceUri)
        {
            try
            {
                IOrganizationService organizationService = null;
                ClientCredentials clientCredentials = new ClientCredentials();
                clientCredentials.UserName.UserName = user + "@rbos.co.uk";
                clientCredentials.UserName.Password = password;
                instanceUri = "https://descrmdev.api.crm4.dynamics.com/XRMServices/2011/Organization.svc";


                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                OrganizationServiceProxy proxy = new OrganizationServiceProxy(new Uri(instanceUri), null, clientCredentials, null);
                proxy.EnableProxyTypes();

                using (proxy)
                {
                    organizationService = (IOrganizationService)proxy;
                }
               

                if (organizationService != null)
                {
                    Guid userId = ((WhoAmIResponse)organizationService.Execute(new WhoAmIRequest())).UserId;
                }


                return organizationService;

            }
            catch (Exception ex)
            {
                return null;
            }
        }
      
    }
}
