﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace RBS.EE.CRM.Common
{
    public class ADAction
    {
        /// <summary>
        /// PreReq: Acquire delegated permissions on the group
        /// Add Member or Group to the respective AD groupd
        /// </summary>
        /// <param name="racf"></param>
        /// <param name="ldapfilter"></param>
        /// <param name="ADGroup"></param>
        /// <param name="ldapQuery"></param>
        /// <param name="user"></param>
        /// <param name="password"></param>
        /// <param name="exceptionEmailTo"></param>
        /// <param name="isEnabled"></param>
        /// <param name="isGroup"></param>
        /// <param name="requestAzureUriString"></param>
        /// <param name="proxyAddress"></param>
        public static void LdapAddQueryExecution(string basefolderLocation, string racf, string ldapfilter, string ADGroup, string ldapQuery, string user, string password, string exceptionEmailTo, string isEnabled, bool isGroup, string requestAzureUriString, string proxyAddress)
        {
            try
            {
                // Additional trace to be passed to email message
                string errorAdd = string.Empty;
                errorAdd += "Group Name: " + ADGroup + "\n";

                //Directory Entry Action
                using (DirectoryEntry entry = new DirectoryEntry(ldapQuery, user, password, AuthenticationTypes.Secure))
                {
                    DirectorySearcher ds = new DirectorySearcher(entry);
                    ds.SearchScope = SearchScope.Subtree;

                    // Find members or groups Ldap Path and email address
                    using (PrincipalContext ctx = new PrincipalContext(ContextType.Domain))
                    {
                        errorAdd += "Member Name: " + racf + "\n";
                        errorAdd += "Action: ADD" + "\n";

                        ds.Filter = string.Format(ldapfilter, ADGroup);
                        ds.PropertiesToLoad.Add("member");
                        SearchResult result = ds.FindOne();

                        if (result != null)
                        {
                            bool isUserMemberOfADGroup = false;
                            foreach (var mem in result.Properties["member"])
                            {
                                using (DirectoryEntry mementry = new DirectoryEntry("LDAP://" + mem))
                                {
                                    if (racf == mementry.Properties["cn"].Value.ToString())
                                    {
                                        isUserMemberOfADGroup = true;
                                        break;
                                    }
                                }
                            }

                            try
                            {
                                if (!isUserMemberOfADGroup && isEnabled.ToLower() == "true")
                                {
                                    string userLdapPath = string.Empty;
                                    if (isGroup)
                                        userLdapPath = FindGroupLdapPathByRacf(ctx, racf);
                                    else
                                        userLdapPath = FindUserLdapPathByRacf(ctx, racf);
                                    if (entry != null) { entry.Invoke("Add", new object[] { userLdapPath }); }
                                }
                            }
                            catch (Exception ex)
                            {
                                errorAdd += ex.InnerException.Message;
                                //Send Email
                                MSFlowEmail.SendExceptionEmail(basefolderLocation, exceptionEmailTo, ex.Message, ex.StackTrace, errorAdd, requestAzureUriString, proxyAddress);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Send Email
                MSFlowEmail.SendExceptionEmail(basefolderLocation, exceptionEmailTo, ex.Message, ex.StackTrace, ex.InnerException.Message, requestAzureUriString, proxyAddress);
            }
        }

        /// <summary>
        /// PreReq: Acquire delegated permissions on the group
        /// Remove Member or Group to the respective AD groupd
        /// </summary>
        /// <param name="racf"></param>
        /// <param name="ldapfilter"></param>
        /// <param name="ADGroup"></param>
        /// <param name="ldapQuery"></param>
        /// <param name="user"></param>
        /// <param name="password"></param>
        /// <param name="exceptionEmailTo"></param>
        /// <param name="isEnabled"></param>
        /// <param name="isGroup"></param>
        /// <param name="requestAzureUriString"></param>
        /// <param name="proxyAddress"></param>
        public static void LdapRemoveQueryExecution(string basefolderLocation, string racf, string ldapfilter, string ADGroup, string ldapQuery, string user, string password, string exceptionEmailTo, string isEnabled, bool isGroup, string requestAzureUriString, string proxyAddress)
        {
            try
            {
                // Additional trace to be passed to email message
                string errorAdd = string.Empty;
                errorAdd += "Group Name: " + ADGroup + "\n";

                //Directory Entry Action
                using (DirectoryEntry entry = new DirectoryEntry(ldapQuery, user, password, AuthenticationTypes.None))
                {
                    DirectorySearcher ds = new DirectorySearcher(entry);
                    ds.SearchScope = SearchScope.Subtree;

                    using (PrincipalContext ctx = new PrincipalContext(ContextType.Domain))
                    {
                        errorAdd += "Member Name: " + racf + "\n";
                        errorAdd += "Action: REMOVE" + "\n";

                        ds.Filter = string.Format(ldapfilter, ADGroup);
                        ds.PropertiesToLoad.Add("member");
                        SearchResult result = ds.FindOne();

                        if (result != null)
                        {
                            bool isUserMemberOfADGroup = false;
                            foreach (var mem in result.Properties["member"])
                            {
                                using (DirectoryEntry mementry = new DirectoryEntry("LDAP://" + mem))
                                {
                                    if (racf == mementry.Properties["cn"].Value.ToString())
                                    {
                                        isUserMemberOfADGroup = true;
                                        break;
                                    }
                                }
                            }

                            try
                            {
                                if (isUserMemberOfADGroup && isEnabled.ToLower() == "true")
                                {
                                    string userLdapPath = string.Empty;
                                    if (isGroup)
                                        userLdapPath = FindGroupLdapPathByRacf(ctx, racf);
                                    else
                                        userLdapPath = FindUserLdapPathByRacf(ctx, racf);
                                    if (entry != null) { entry.Invoke("Remove", new object[] { userLdapPath }); }
                                }
                            }
                            catch (Exception ex)
                            {
                                //Send Email
                                MSFlowEmail.SendExceptionEmail(basefolderLocation, exceptionEmailTo, ex.Message, ex.StackTrace, ex.InnerException.Message, requestAzureUriString, proxyAddress);
                            }

                            //Send Email
                            //string emailTo = FindEmailAddressByRacf(Variables.RemoveUserRacf);
                            //string emailSubject = "SLX Email Notification";
                            //string emailBody = racf + " added to security group " + ADGroup;
                            //MSFlowEmail.sendEmail(racf, emailSubject, emailBody, requestAzureUriString, proxyAddress, exceptionEmailTo);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Send Email
                MSFlowEmail.SendExceptionEmail(basefolderLocation, exceptionEmailTo, ex.Message, ex.StackTrace, ex.InnerException.Message, requestAzureUriString, proxyAddress);
            }
        }

        public static string FindUserLdapPathByRacf(PrincipalContext ctx, string UserRacf)
        {
            UserPrincipal currentUser = UserPrincipal.FindByIdentity(ctx, UserRacf);
            string userLdapPath = currentUser.DistinguishedName;
            return "LDAP://" + userLdapPath;
        }

        public static string FindGroupLdapPathByRacf(PrincipalContext ctx, string GroupRacf)
        {
            GroupPrincipal currentUser = GroupPrincipal.FindByIdentity(ctx, GroupRacf);
            string groupLdapPath = currentUser.DistinguishedName;
            return "LDAP://" + groupLdapPath;
        }

        public static ArrayList FindDeltaUsersAndADCopy(string path, string pathADUsers, string instanceNameList, string user, string password, DateTime succesTime)
        {
            // Set Proxy 
            WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //Initialize Variables
            ArrayList lstDeltaUsersAndADCopy = new ArrayList();
            ArrayList lstDeltaPositionUsers = new ArrayList();
            ArrayList lstDeltaADCopy = new ArrayList();
            string[] instanceNameGroups = instanceNameList.Split(new char[] { ',' });

            foreach (var instanceName in instanceNameGroups)
            {
                //Get Delta Position Groups based on last success time
                List<DirectoryEntry> deltaADPositionGroups = getADDeltaPositionGroups(instanceName, user, password, succesTime);

                //Get LocalCopy Details
                List<string[]> deltaLocalPositionGroups = getLocalDeltaPositionGroups(deltaADPositionGroups, pathADUsers);

                foreach (var deltaADPositionGroup in deltaADPositionGroups)
                {
                    //Initialize
                    bool isPositionGroupChanged = false;
                    string deltaADPositionGroupName = deltaADPositionGroup.Properties["cn"].Value.ToString();
                    ArrayList lstADPositionCopy = new ArrayList();
                    lstADPositionCopy.Add(deltaADPositionGroupName);

                    //AD MembersList
                    List<string> lstADMembers = new List<string>();
                    foreach (var mem in deltaADPositionGroup.Properties["member"])
                    {
                        using (DirectoryEntry mementry = new DirectoryEntry("LDAP://" + mem))
                        {
                            lstADMembers.Add(mementry.Properties["cn"].Value.ToString());
                            lstADPositionCopy.Add(mementry.Properties["cn"].Value.ToString());
                        }
                    }


                    //LocalMembers List
                    List<string> lstLocalMembers = new List<string>();
                    foreach (var deltaLocalPositionGroup in deltaLocalPositionGroups)
                    {
                        if (deltaADPositionGroupName == deltaLocalPositionGroup[0])
                        {
                            lstLocalMembers.AddRange(deltaLocalPositionGroup[1].Split(new char[] { '&' }));
                        }
                    }

                    //Find Add Users for the position group : Compare AD members to Local Copy
                    var lstADDMembers = lstADMembers.Where(c => !lstLocalMembers.Contains(c));
                    foreach (var lstADDMember in lstADDMembers)
                    {
                        List<string> lstDeltaPositionUser = new List<string>();
                        lstDeltaPositionUser.Add(instanceName); //Add InstanceName
                        lstDeltaPositionUser.Add(deltaADPositionGroupName); //Add PositionName
                        lstDeltaPositionUser.Add(lstADDMember); //Add Member
                        lstDeltaPositionUser.Add(""); //Remove Member
                        lstDeltaPositionUsers.Add(lstDeltaPositionUser);

                        isPositionGroupChanged = true;
                    }

                    //Find Remove Users for the position group : Compare LocalCopy to AD members
                    var lstREMOVEMembers = lstLocalMembers.Where(c => !lstADMembers.Contains(c));
                    foreach (var lstREMOVEMember in lstREMOVEMembers)
                    {
                        if (lstREMOVEMember != string.Empty)
                        {
                            List<string> lstDeltaPositionUser = new List<string>();
                            lstDeltaPositionUser.Add(instanceName); //Add InstanceName
                            lstDeltaPositionUser.Add(deltaADPositionGroupName); //Add PositionName
                            lstDeltaPositionUser.Add(""); //Add Member
                            lstDeltaPositionUser.Add(lstREMOVEMember); //Remove Member
                            lstDeltaPositionUsers.Add(lstDeltaPositionUser);

                            isPositionGroupChanged = true;
                        }
                    }

                    if(isPositionGroupChanged)
                        lstDeltaADCopy.Add(lstADPositionCopy);
                }
            }
            lstDeltaUsersAndADCopy.Add(lstDeltaPositionUsers);
            lstDeltaUsersAndADCopy.Add(lstDeltaADCopy);
            return lstDeltaUsersAndADCopy;
        }

        private static List<string[]> getLocalDeltaPositionGroups(List<DirectoryEntry> deltaADPositionGroups, string pathADUsers)
        {
            // Initialize Variables
            List<string[]> lstDeltaPositionGroups = new List<string[]>();
            var lines = File.ReadAllLines(pathADUsers);

            foreach (var line in lines)
            {
                //string lineDetails = Regex.Replace(line, "[^A-Za-z0-9,-,&]", string.Empty);
                string[] linesListColumns = line.Split(new char[] { ',' });
                
                if (deltaADPositionGroups.Where(c=>c.Properties["cn"][0].ToString() == linesListColumns[0]).Count() > 0)
                {
                    lstDeltaPositionGroups.Add(linesListColumns);
                }
            }

            return lstDeltaPositionGroups;
        }

        private static List<DirectoryEntry> getADDeltaPositionGroups(string instanceName, string user, string password, DateTime succesTime)
        {
            // Initialize Variables
            List<DirectoryEntry> lstDeltaPositionGroups = new List<DirectoryEntry>();

            string ldapQuery = "LDAP://cn=" + instanceName + ",ou=AADC Synced,ou=Groups,dc=europa,dc=rbsgrp,dc=net";

            DirectoryEntry de = new
                  DirectoryEntry(ldapQuery, user, password, AuthenticationTypes.Secure);

            foreach (string SDN in de.Properties["member"])
            {
                DirectoryEntry deMember = new DirectoryEntry("LDAP://" + SDN);
                if ((deMember.SchemaClassName == "group"))
                {
                    DateTime whenChangedGroup = ((DateTime)deMember.Properties["whenChanged"][0]).ToLocalTime();
                    if (whenChangedGroup > succesTime)
                    {
                        lstDeltaPositionGroups.Add(deMember);
                    }
                }
            }

            return lstDeltaPositionGroups;
        }
    }
}
