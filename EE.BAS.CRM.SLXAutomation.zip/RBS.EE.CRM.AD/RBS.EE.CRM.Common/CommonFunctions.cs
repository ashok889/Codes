﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace RBS.EE.CRM.Common
{
    public class CommonFunctions
    {
        //Function to Push Data to file
        public static void PushLog(string filePath, string message)
        {
            try
            {
                string logFilePath = filePath + "\\Data\\activityLogs.txt";
                if (File.Exists(logFilePath))
                {

                    File.AppendAllText(logFilePath, message + Environment.NewLine);
                }
            }
            catch(Exception ex)
            {
                throw new Exception("Pushing Logs to Text file Failed");
            }
        }
        public static void PushLogCSVArray(string filePath, string[] message)
        {
            try
            {
                string logFilePath = filePath + "\\Data\\activityLogs" + DateTime.Now.ToString("ddMMyyyy") + ".csv";
                List<string> lines = new List<string>();
                if (File.Exists(logFilePath))
                {
                    string[] linesColumns;
                    string[] linesList;

                    using (StreamReader sr = new StreamReader(logFilePath))
                    {
                        var lines1 = File.ReadAllLines(logFilePath);
                        string[] linesListNewN;
                        var line = "";
                        foreach (var lineValue in lines1)
                        {
                            lines.Add(lineValue);
                        }
                        linesListNewN = lines1[1].Split(new char[] { ',' });
                        for (var i = 0; i < message.Length; i++)
                        {

                            linesListNewN[i] = message[i].ToString();
                            line = string.Join(",", linesListNewN);

                        }
                        lines.Add(line);
                    }
                    using (StreamWriter sw = new StreamWriter(logFilePath, false))
                    {
                        for (var i = 0; i < lines.Count; i++)
                        {
                            sw.WriteLine(lines[i]);
                        }
                    }

                }
                else
                {
                    string[] linesColumnsNew;
                    string[] linesListNew;
                    string logFilePathTemplate = filePath + "\\Data\\activityLogs.csv";
                    var linesNew = File.ReadAllLines(logFilePathTemplate);
                    linesColumnsNew = linesNew[0].Split(new char[] { ',' });
                    linesListNew = linesNew[1].Split(new char[] { ',' });
                    var lineColumns = string.Join(",", linesColumnsNew);
                    lines.Add(lineColumns);
                    var line = "";
                    for (var i = 0; i < message.Length; i++)
                    {

                        linesListNew[i] = message[i].ToString();
                        line = string.Join(",", linesListNew);

                    }
                    lines.Add(line);


                    //Creation of New file
                    string newFilePath = filePath + "\\Data\\activityLogs" + DateTime.Now.ToString("ddMMyyyy") + ".csv";
                    using (StreamWriter sw = new StreamWriter(newFilePath, false))
                    {
                        for (var i = 0; i < lines.Count; i++)
                        {
                            sw.WriteLine(lines[i]);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw new Exception("Pushing Logs to CSV failed");
            }
        }
        //Function for Pushing the data to CSV
        public static void PushLogCSV(string filePath, string message,int columnPosition)
        {
            try
            {
                string logFilePath = filePath + "\\Data\\activityLogs" + DateTime.Now.ToString("ddMMyyyy") + ".csv";

                List<string> lines = new List<string>();
                if (File.Exists(logFilePath))
                {

                    string[] linesColumns;
                    string[] linesList;
                    using (StreamReader sr = new StreamReader(logFilePath))
                    {
                        var lines1 = File.ReadAllLines(logFilePath);
                        foreach (var lineValue in lines1)
                        {
                            lines.Add(lineValue);
                        }

                        linesList = lines1[1].Split(new char[] { ',' });
                        linesList[columnPosition] = message;
                        var line = string.Join(",", linesList);

                        lines.Add(line);
                        sr.Close();
                    }
                    using (StreamWriter sw = new StreamWriter(logFilePath, false))
                    {
                        for (var i = 0; i < lines.Count; i++)
                        {
                            sw.WriteLine(lines[i]);
                        }
                        sw.Close();
                    }
                }
                else
                {
                    string[] linesColumnsNew;
                    string[] linesListNew;
                    string logFilePathTemplate = filePath + "\\Data\\activityLogs.csv";
                    var linesNew = File.ReadAllLines(logFilePathTemplate);
                    linesColumnsNew = linesNew[0].Split(new char[] { ',' });
                    var lineColumns = string.Join(",", linesColumnsNew);
                    linesListNew = linesNew[1].Split(new char[] { ',' });
                    linesListNew[columnPosition] = message;
                    var line = string.Join(",", linesListNew);
                    lines.Add(lineColumns);
                    lines.Add(line);
                    //Creation of New file
                    string newFilePath = filePath + "\\Data\\activityLogs" + DateTime.Now.ToString("ddMMyyyy") + ".csv";
                    using (StreamWriter sw = new StreamWriter(newFilePath, false))
                    {
                        for (var i = 0; i < lines.Count; i++)
                        {
                            sw.WriteLine(lines[i]);
                        }
                        sw.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in CSV Logs");
            }

        }
       
        //Function for returning Position Assignment type
        public static string AssignmentType(string positionName)
            {
            try
            {
                string positionType = string.Empty;
                if (positionName.Contains("MAIN"))
                {
                    positionType = "MAIN";

                }
                else if (positionName.Contains("ADD"))
                {
                    positionType = "ADD";

                }
                return positionType;
            }
            catch(Exception ex)
            {
                throw new Exception("Returning Assignment type Failed");
            }
       }

        //Connecting to CRM , Returning the OrgService 
        public static IOrganizationService GetConnections(string user, string password, string instanceUri)
        {
            try
            {
                IOrganizationService organizationService = null;
               
                var connectionString = string.Format("RequireNewInstance=true;Url=https://"+instanceUri+".crm4.dynamics.com;Username="+user+";Password="+password+";authtype=Office365");
                WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                organizationService = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);
                return organizationService;

            }
            catch (Exception ex)
            {
                throw new Exception("Could not connect to CRM. ");
            }
        }
        //Function for returning the count of Positions
        public static bool GetTotalPositions(string userName,string password,string instanceUri,string removeUserRacf,string exceptionEmailTo)
        {
            try
            {
                bool positionCount = false;
                IOrganizationService service = GetConnections(userName, password, instanceUri);
                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                string emailTo = MSFlowEmail.FindEmailAddressByRacf(ctx, removeUserRacf, exceptionEmailTo);
                //Retreive users
                QueryExpression query = new QueryExpression
                {
                    EntityName = "systemuser",
                    ColumnSet = new ColumnSet("systemuserid","positionid")
                };
                query.Criteria.AddCondition("domainname", ConditionOperator.Equal, emailTo);
                var users = service.RetrieveMultiple(query);
                if (users.Entities.Count == 1)
                {
                    foreach (Entity userEntity in users.Entities)
                    {
                        Guid userId = userEntity.Id;
                       
                        Guid userPositionId = ((Microsoft.Xrm.Sdk.EntityReference)(userEntity["positionid"])).Id;
                        //check for UserPositions
                        QueryExpression queryUserPositions = new QueryExpression
                        {
                            EntityName = "rbs_userposition",
                            ColumnSet = new ColumnSet("rbs_positionid", "rbs_userid")
                        };
                        queryUserPositions.Criteria.AddCondition("rbs_userid", ConditionOperator.Equal, userId);
                        var positionUserCollection = service.RetrieveMultiple(queryUserPositions);

                        if(userPositionId ==null && positionUserCollection.TotalRecordCount == 0)
                        {
                            positionCount = true;
                        }
                    }
                }
                return positionCount;
            }
            catch(Exception ex)
            {
                throw new Exception("Error in finding positions ");
            }
        }
    }
}
