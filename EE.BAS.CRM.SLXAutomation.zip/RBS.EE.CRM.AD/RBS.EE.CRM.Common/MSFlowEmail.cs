﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RBS.EE.CRM.Common
{
    public class MSFlowEmail
    {
        public static void InitiateEmailNotification(string basefolderLocation, string requestAzureUriString, string proxy, string EmailTo, string EmailSubject, string EmailBody)
        {
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
            WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(requestAzureUriString);
                request.Method = "POST";
                request.ContentType = "application/json";

                //request.Credentials = CredentialCache.DefaultCredentials;

                //WebProxy webProxy = new WebProxy(proxy, true)
                //{
                //    Credentials = CredentialCache.DefaultCredentials,
                //    UseDefaultCredentials = true
                //};

                //request.Proxy = webProxy;

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    //Sample
                    //string json = "{\"emailadress\":\"Arvind.Sharma@rbs.co.uk\"," +
                    //                "\"emailSubject\":\"Test Mail From Flow\"," +
                    //              "\"emailBody\":\"SLX EMAIL AUTOMATION\"}";

                    string json = "{\"emailadress\":\"" + EmailTo + "\"," +
                                    "\"emailSubject\":\"" + EmailSubject + "\"," +
                                  "\"emailBody\":\"" + EmailBody + "\"}";

                    streamWriter.Write(json);
                }

                var response = (HttpWebResponse)request.GetResponse();

                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                Console.WriteLine(responseString);

            }
            catch (Exception ex)
            {
                string innerException = string.Empty;
                Exception _Exception = ex.InnerException;
                if (_Exception != null) innerException = _Exception.Message;
                CommonFunctions.PushLog(basefolderLocation, ex.Message + "  innerException:" + innerException);
            }
        }

        public static void SendExceptionEmail(string basefolderLocation, string exceptionEmailTo, string message, string stackTrace, string innerException, string requestAzureUriString, string proxyAddress)
        {
            string emailSubject = "SLX Automation (BAS CRM) - Exception";
            string emailBody = "Exception Message: " + message + "\\n" +
                "InnerException: " + innerException + "\\n";
            //"StackTrace: " + stackTrace;
            sendEmail(basefolderLocation, exceptionEmailTo, emailSubject, emailBody, requestAzureUriString, proxyAddress, exceptionEmailTo);
        }

        public static void sendEmail(string basefolderLocation, string emailTo, string emailSubject, string emailBody, string requestAzureUriString, string proxyAddress, string exceptionEmailTo)
        {
            using (PrincipalContext ctx = new PrincipalContext(ContextType.Domain))
            {
                emailTo = FindEmailAddressByRacf(ctx, emailTo, exceptionEmailTo);
                InitiateEmailNotification(basefolderLocation, requestAzureUriString, proxyAddress, emailTo, emailSubject, emailBody);
            }
        }

        public static string FindEmailAddressByRacf(PrincipalContext ctx, string UserRacf, string exceptionEmailTo)
        {
            try
            {
                UserPrincipal currentUser = UserPrincipal.FindByIdentity(ctx, UserRacf);
                return currentUser.EmailAddress;
            }
            catch (Exception ex)
            {
                UserPrincipal currentUser = UserPrincipal.FindByIdentity(ctx, exceptionEmailTo);
                return currentUser.EmailAddress;
            }
        }
    }
}
