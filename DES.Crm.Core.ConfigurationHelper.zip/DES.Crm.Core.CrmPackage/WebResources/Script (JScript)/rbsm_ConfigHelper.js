﻿function RetrieveConfiguration(XrmServiceToolkit, key) {

    var domainArray = [];
    var configurationSettingFetchXML = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true" >' +
										  '<entity name="rbsm_configurationsetting" >' +
											'<attribute name="rbsm_key" />' +
											'<attribute name="rbsm_value" />' +
											'<attribute name="statecode" />' +
											'<filter type="and" >' +
												'<condition attribute="rbsm_key" operator="eq" value="' + key + '" />' +
											'</filter>' +
										  '</entity>' +
										'</fetch>';

    var fetchconfigurationSettingRecord = XrmServiceToolkit.Soap.Fetch(configurationSettingFetchXML);

    if (fetchconfigurationSettingRecord.length > 0) {

        for (var i = 0; i < fetchconfigurationSettingRecord.length; i++) {

            if (fetchconfigurationSettingRecord[i].attributes.rbsm_key != undefined && fetchconfigurationSettingRecord[i].attributes.rbsm_value != undefined) {
                if (fetchconfigurationSettingRecord[i].attributes.statecode.value == 0) {
                    if (fetchconfigurationSettingRecord[i].attributes.rbsm_value.value != "") {

                        domainArray.push(fetchconfigurationSettingRecord[i].attributes.rbsm_value.value);
                    }
                }
            }
        }

        if (domainArray.length > 0)
            return domainArray;
        else
            return null;
    }
    else
        alert("Configuration Settings does not exist for the key - '" + key + "'.");
}