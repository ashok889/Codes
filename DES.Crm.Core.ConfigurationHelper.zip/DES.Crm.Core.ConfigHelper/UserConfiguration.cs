﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;
using System.Collections.Generic;

namespace DES.Crm.Core.ConfigHelper
{
    public static class UserConfiguration
    {
        const string configurationSettingEntityName = "rbsm_configurationsetting";
        const string keyAttribute = "rbsm_key";
        const string valueAttribute = "rbsm_value";

        #region fetchxmls

        private const string FetchConfigurationSetting = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                                              <entity name='" + configurationSettingEntityName + @"'> 
                                                                <attribute name='" + keyAttribute + @"' />
                                                                <attribute name='" + valueAttribute + @"' /> 
                                                                <attribute name='statecode' />
                                                                <filter type='and'> 
                                                                        <condition attribute='" + keyAttribute + @"' operator='eq' value='#key#' /> 
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

        #endregion

        /// <summary>
        /// Returns string array of values corresponding to the configuration setting key.
        /// </summary>
        /// <param name="service">CRM service object</param>
        /// <param name="key">Configuration key</param>
        /// <returns></returns>
        public static string[] Retrieve(IOrganizationService service, string key)
        {
            EntityCollection enCollConfigSettings = null;

            try
            {
                if (service != null)
                {
                    enCollConfigSettings = service.RetrieveMultiple(new FetchExpression(FetchConfigurationSetting.Replace("#key#", key)));

                    if (enCollConfigSettings != null && enCollConfigSettings.Entities != null && enCollConfigSettings.Entities.Count > 0)
                    {
                        IEnumerable<Entity> enConfigs = enCollConfigSettings.Entities.Where(w => ((OptionSetValue)w.Attributes["statecode"]).Value == 0 && w.Attributes.Contains(valueAttribute));

                        if (enConfigs.Count() > 0)
                            return enConfigs.Select(s => s.Attributes[valueAttribute].ToString()).ToArray<string>();
                        else
                            return null;
                    }
                    else
                        throw new Exception("Configuration Settings does not exist for the key - '" + key + "'.");
                }
                else
                    throw new Exception("CRM Service object has not been initialised.");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
