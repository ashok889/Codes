﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.SanitizeData.Workflows
{
    public class DeactivateParentCase : CodeActivity
    {
        [Input("State")]        
        [RequiredArgument]
        public InArgument<int> State { get; set; }

        [Input("Status")]                
        [RequiredArgument]
        public InArgument<int> Status { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            tracingService.Trace("Entered DeactivateParentCase.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}",
                executionContext.ActivityInstanceId,
                executionContext.WorkflowInstanceId);

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            tracingService.Trace("DeactivateParentCase.Execute(), Correlation Id: {0}, Initiating User: {1}",
                context.CorrelationId,
                context.InitiatingUserId);

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                Entity enCase = new Entity(context.PrimaryEntityName);
                enCase.Id = context.PrimaryEntityId;

                int state = State.Get<int>(executionContext);
                int status = Status.Get<int>(executionContext);

                EntityCollection enColActiveChildCases = RetrieveChildCases(service, 0, context.PrimaryEntityId);

                if (state == 2) //Cancelled
                {
                    if (enColActiveChildCases != null && enColActiveChildCases.Entities != null && enColActiveChildCases.Entities.Count > 0)
                    {
                        foreach (Entity enActiveCase in enColActiveChildCases.Entities)
                            CancelCase(tracingService, service, enActiveCase, 2, 6); //Cancelled
                    }

                    CancelCase(tracingService, service, enCase, 2, 6); //Cancelled                    
                }
                else if (state == 1) //Resolved
                {
                    if (enColActiveChildCases != null && enColActiveChildCases.Entities != null && enColActiveChildCases.Entities.Count > 0)
                    {
                        foreach (Entity enActiveCase in enColActiveChildCases.Entities)
                            ResolveCase(tracingService, service, enActiveCase, 5); //Resolved
                    }

                    ResolveCase(tracingService, service, enCase, 5); //Resolved                   
                }

                if (enColActiveChildCases != null && enColActiveChildCases.Entities != null && enColActiveChildCases.Entities.Count > 0)
                {
                    foreach (Entity enActiveCase in enColActiveChildCases.Entities)
                        ReOpenCase(tracingService, service, enActiveCase, 0, 1); //In-Progress
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid State and Status combination. " + ex.Message);
            }

            tracingService.Trace("Exiting DeactivateParentCase.Execute(), Correlation Id: {0}", context.CorrelationId);
        }

        private EntityCollection RetrieveChildCases(IOrganizationService service, int state, Guid caseId)
        {
            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='incident'>
                                <attribute name='incidentid' />
                                <filter type='and'>
                                  <condition attribute='parentcaseid' operator='eq' value='#parentcaseid#' />
                                  <condition attribute='statecode' operator='eq' value='#state#' />
                                </filter>
                              </entity>
                            </fetch>";

            return service.RetrieveMultiple(new FetchExpression(sFetch.Replace("#parentcaseid#", caseId.ToString()).Replace("#state#", state.ToString())));
        }

        private void ReOpenCase(ITracingService tracingService, IOrganizationService service, Entity enCase, int state, int status)
        {
            Entity enCaseToUpdate = new Entity(enCase.LogicalName);
            enCaseToUpdate.Id = enCase.Id;
            enCaseToUpdate.Attributes["statecode"] = new OptionSetValue(state);
            enCaseToUpdate.Attributes["statuscode"] = new OptionSetValue(status);

            tracingService.Trace("Going to Re-Open Case - " + enCase.Id + "with Status - " + status.ToString());

            service.Update(enCaseToUpdate);

            tracingService.Trace("Case Updated!");
        }

        private void CancelCase(ITracingService tracingService, IOrganizationService service, Entity enCase, int state, int status)
        {
            Entity enCaseToUpdate = new Entity(enCase.LogicalName);
            enCaseToUpdate.Id = enCase.Id;
            enCaseToUpdate.Attributes["statecode"] = new OptionSetValue(state);
            enCaseToUpdate.Attributes["statuscode"] = new OptionSetValue(status);

            tracingService.Trace("Going to Cancel Case - " + enCase.Id + "with Status - " + status.ToString());

            service.Update(enCaseToUpdate);

            tracingService.Trace("Case Updated!");
        }

        private void ResolveCase(ITracingService tracingService, IOrganizationService service, Entity enCase, int status)
        {
            //Initialize Case Resolution Request
            Entity CaseResolution = new Entity("incidentresolution");
            CaseResolution["incidentid"] = new EntityReference("incident", enCase.Id);
            CaseResolution["subject"] = "Data Munging Done";            

            //Initialize Incident Closure Request
            CloseIncidentRequest closeRequest = new CloseIncidentRequest();
            closeRequest.IncidentResolution = CaseResolution;
            closeRequest.Status = new OptionSetValue(status);
            closeRequest.RequestName = "CloseIncident";

            tracingService.Trace("Going to Resolve Case - " + enCase.Id + " with Status - " + status.ToString());

            //Execute the Request
            CloseIncidentResponse response = (CloseIncidentResponse)service.Execute(closeRequest);

            tracingService.Trace("Case Updated!");
        }
    }
}
