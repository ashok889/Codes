﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.SanitizeData.Workflows
{
    public class UpdateIncrementor : CodeActivity
    {
        [Input("Increment Value to Set")]        
        [RequiredArgument]
        public InArgument<string> IncrementValueToSet { get; set; }

        [Input("Increment Value Record")]
        [ReferenceTarget("rbsm_configurationsetting")]
        [RequiredArgument]
        public InArgument<EntityReference> IncrementValueRecord { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            tracingService.Trace("Entered UpdateIncrementor.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}",
                executionContext.ActivityInstanceId,
                executionContext.WorkflowInstanceId);

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            tracingService.Trace("UpdateIncrementor.Execute(), Correlation Id: {0}, Initiating User: {1}",
                context.CorrelationId,
                context.InitiatingUserId);

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                EntityReference configSetting = IncrementValueRecord.Get<EntityReference>(executionContext);

                string key = service.Retrieve(configSetting.LogicalName, configSetting.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("rbsm_key")).Attributes["rbsm_key"].ToString();
                string value = IncrementValueToSet.Get<string>(executionContext);

                Entity enToupdate = new Entity(configSetting.LogicalName);
                enToupdate.Id = configSetting.Id;
                enToupdate.Attributes["rbsm_value"] = value;

                service.Update(enToupdate);

                tracingService.Trace("Configuration Setting with Key - " + key + "updated with Value - " + value + ".");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            tracingService.Trace("Exiting UpdateIncrementor.Execute(), Correlation Id: {0}", context.CorrelationId);
        }
    }
}
