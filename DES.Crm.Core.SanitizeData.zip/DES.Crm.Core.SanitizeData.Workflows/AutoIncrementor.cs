﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.ConfigHelper;

namespace DES.Crm.Core.SanitizeData.Workflows
{
    public class AutoIncrementor : CodeActivity
    {

        [Input("Last Increment Value Record")]
        [ReferenceTarget("rbsm_configurationsetting")]
        [RequiredArgument]
        public InArgument<EntityReference> LastIncrementValueRecord { get; set; }

        [Output("Next Increment Value (String)")]
        public OutArgument<string> NextIncrementValue { get; set; }

        [Output("Next Increment Value (Decimal)")]
        public OutArgument<decimal> NextIncrementValueDecimal { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            tracingService.Trace("Entered AutoIncrementor.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}",
                executionContext.ActivityInstanceId,
                executionContext.WorkflowInstanceId);

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            tracingService.Trace("AutoIncrementor.Execute(), Correlation Id: {0}, Initiating User: {1}",
                context.CorrelationId,
                context.InitiatingUserId);

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                EntityReference configSetting = LastIncrementValueRecord.Get<EntityReference>(executionContext);
                string key = service.Retrieve(configSetting.LogicalName, configSetting.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("rbsm_key")).Attributes["rbsm_key"].ToString();

                tracingService.Trace("Key - " + key);

                string[] values = ConfigHelper.UserConfiguration.Retrieve(service, key);

                if(values.Count() > 0)
                {
                    int lastIncrementValue;

                    if (int.TryParse(values[0], out lastIncrementValue))
                    {
                        tracingService.Trace("Value - " + lastIncrementValue);

                        NextIncrementValue.Set(executionContext, (lastIncrementValue + 1).ToString());
                    }
                    else
                        tracingService.Trace("Value present is not a valid integer.");

                    decimal dlastIncrementValue;

                    if (decimal.TryParse(values[0], out dlastIncrementValue))
                    {
                        tracingService.Trace("Value - " + dlastIncrementValue);

                        NextIncrementValueDecimal.Set(executionContext, (dlastIncrementValue + 1));
                    }
                    else
                        tracingService.Trace("Value present is not a valid decimal.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            tracingService.Trace("Exiting AutoIncrementor.Execute(), Correlation Id: {0}", context.CorrelationId);
        }
    }
}
