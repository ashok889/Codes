openfeedback = function () {
    // 1. Applied custom CSS for the Popup
    $(window.top.document.head).append('<link href="' + Xrm.Page.context.getClientUrl() + '//WebResources/new_jqueryui.css" rel="stylesheet" type="text/css">');

    // 2. Add div on CRM window body for the open popup window
    if (parent.parent.$('body').find('#iframe_handle').length === 0) {
        $(window.top.document.body).find("div:first").after("<div id='iframe_handle' style='display:none;overflow:hidden'></div>");
    }
    //3. Parameter pass as querystring 
    var customParameters = encodeURIComponent("caseid=" + Xrm.Page.data.entity.getId().replace(/[{}]/g, "") + "&casename=" + Xrm.Page.getAttribute("title").getValue());


    var dialobox = new CustomeDialog();

    dialobox.showDialog({
        page: "new_feedback.html?Data=" + customParameters
    });
	
}


var CustomeDialog = function () {
    var _hideEle = [],
        iframeEle = $('<iframe id="dialogIframe" frameBorder="0" ></iframe>'),
        pageBtns = ['#selectionButtons button'],
        dialogWidth = $(top.window).width() * 0.65,
        dialogHeight = $(top.window).height() * 0.65,
        btns = [],
        _dialogBtns = [],
        _dialogTitle = '',
        _iframeContentBody,
        _iframeContent,
        domElement,
        dialogContainerID,
        dialogUseVersion,
        dialogReloadParent,
        dialogCallBackFunction,
        page;

    function loadPageToIframe() {
        dialogContainerID.append(iframeEle);

        var pageurl = "/{636355328760000207}/WebResources/" + page;
        if (!dialogUseVersion) {
            pageurl = page;
        }

        iframeEle.attr({ 'height': '100%', 'width': '100%', "src": pageurl });

        // when page loaded in Iframe
        dialogContainerID.find("iframe").load(function () {
            // further process loaded page
            processLoadedPage();
        });
    }

    var processLoadedPage = function () {
        var i;
        // get references of Dom elements of loaded page
        _iframeContentBody = dialogContainerID.find('iframe').contents().find("body");
        _iframeContent = dialogContainerID.find('iframe');

        // get title of load page to show and set as dialog box title
        _dialogTitle = $(_iframeContent).contents().find('head title').html();
        dialogContainerID.dialog("option", { title: _dialogTitle });
        // Change color to dialog title
        dialogContainerID.closest(".ui-dialog").find("#ui-dialog-title-iframe_handle").css({ "color": "#fff", "font-size": '17px' });

        if ($.trim(_iframeContentBody.find("h1").html()).length == 0)
            _iframeContentBody.find("h1").remove();
        if (_dialogBtns.length) {
            // Add buttons on dialog box
            addButtons();
        }
        if (_hideEle.length) {
            hidePageEle();
        }
        if (dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").find('#loadingprogress').length > 0) {
            dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").find('#loadingprogress').hide();
        }
        iframeEle.show();
    };

    var hidePageEle = function () {
        var count;
        for (count = 0; count < _hideEle.length; count++) {
            // .hide will not work as we are diplaying controls on page using HidePrgressing()
            _iframeContentBody.find(_hideEle[count]).html(" ");
        }
    };

    var addButtons = function () {
        // Get buttons of loading page
        btns = $(_iframeContentBody).find(pageBtns.toString());
        // Hide button on page laoded in Iframe
        btns.hide();
    };

    var closeDialog = function () {
    };
    var openDialogBox = function () {
        dialogContainerID.dialog({
            width: dialogWidth,
            height: dialogHeight,
            buttons: _dialogBtns,
            title: "",
            modal: true,
            create: function (event, ui) {
                dialogContainerID.addClass("customeDialogBoxContainer");

                dialogContainerID.closest(".ui-dialog").find(".ui-dialog-titlebar-close").before('<a role="button" class="ui-dialog-titlebar-refresh ui-corner-all" href="#"><span style="color: rgb(255, 255, 255); font-size: 17px;" class="ui-icon ui-icon-refresh">close</span></a>');

                if (dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").find('#loadingprogress').length == 0) {
                    dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").append('<div style="position: absolute;text-align: center;height: 100%;width: 100%;z-index: 9999;top:0px !important;" id="loadingprogress"><table style="height:100%;width:100%;background-color:#FFFFFF"><tbody><tr><td align="center" style="vertical-align: middle"><img width="36" height="36" src="/_imgs/AdvFind/progress.gif" alt="" id="loading"><br>Loading...</td></tr></tbody></table></div>');
                } else {
                    dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").find('#loadingprogress').show();
                }

                dialogContainerID.closest(".ui-dialog").find(".ui-dialog-titlebar-refresh").on('mouseover', function () {
                    dialogContainerID.closest(".ui-dialog").find(".ui-dialog-titlebar-refresh").addClass('ui-state-hover');
                });

                dialogContainerID.closest(".ui-dialog").find(".ui-dialog-titlebar-refresh").on('mouseout', function () {
                    dialogContainerID.closest(".ui-dialog").find(".ui-dialog-titlebar-refresh").removeClass('ui-state-hover');
                });

                dialogContainerID.closest(".ui-dialog").find(".ui-dialog-titlebar-refresh").on('click', function () {
                    dialogContainerID.closest(".ui-dialog").find("#dialogIframe").contents()[0].location.reload();
                    //var lnk = dialogContainerID.closest(".ui-dialog").find("#dialogIframe").contents()[0].location.toString().split('/');
                    //dialogContainerID.closest(".ui-dialog").find("#dialogIframe").attr("src", '/WebResources/' + lnk[lnk.length - 1]);
                });

            },
            open: function () {
                if (dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").find('#loadingprogress').length == 0) {
                    dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").append('<div style="position: absolute;text-align: center;height: 100%;width: 100%;z-index: 9999;top:0px !important;" id="loadingprogress"><table style="height:100%;width:100%;background-color:#FFFFFF"><tbody><tr><td align="center" style="vertical-align: middle"><img width="36" height="36" src="/_imgs/AdvFind/progress.gif" alt="" id="loading"><br>Loading...</td></tr></tbody></table></div>');
                } else {
                    dialogContainerID.closest(".ui-dialog").find(".ui-dialog-content").find('#loadingprogress').show();
                }

                if (dialogCallBackFunction && $.isFunction(dialogCallBackFunction)) {
                    dialogCallBackFunction();
                }
            },
            beforeClose: function (event, ui) {
                beforeDialogClose();
            }
        });
    };

    var beforeDialogClose = function () {
        // set content of dialogbox container to blank
        dialogContainerID.html(" ");
        if (!parent.Xrm.Page.data) {
            // reset top.opener to refer connexx.html on dialog box close event
            if (top.opener.mainSlab) {
                $.extend(top.opener.CCX, top.opener.mainSlab.restoreTempCCX());
            }
            else {
                if (top.opener.frames[0] && top.opener.frames[0].CCX) {
                    $.extend(top.opener.frames[0].CCX, top.opener.CCX);
                    top.opener = top.opener.frames[0];
                }
                else {
                    $.extend(top.opener.frames[1].CCX, top.opener.CCX);
                    top.opener = top.opener.frames[1];
                }

            }
        } else {
            // top.opener.CCX.postProcessing();
        }

        if (dialogReloadParent) {
            top.opener.CCX.postProcessing();
        }
    }

    this.showDialog = function (args) {
        var dlg1, i;

        // Check if we are on main slab page (new_connexx.html)
        if (parent.frames.length && parent.frames.Xrm && parent.frames.Xrm.Page && parent.frames.Xrm.Page.data) {
            // get DOM element which created on system main screen to show dialog box
            dialogContainerID = parent.parent.$('body').find('#iframe_handle');
        }
        else if (parent.frames.length) {
            // get DOM element which created on system main screen to show dialog box
            dialogContainerID = parent.parent.$('body').find('#iframe_handle');
        }
        if (args.hasOwnProperty('page')) {
            page = args.page;
        }
        else {
            alert("Please provide page you want to load using this library");
            return false;
        }
        if (args.hasOwnProperty('dialogContainerID')) {
            dialogContainerID = $(args.dialogContainerID);
        }
        if (args.hasOwnProperty('removeEle')) {
            _hideEle.push(args.removeEle);
        }
        if (args.hasOwnProperty('dialogBtns')) {
            _dialogBtns = args.dialogBtns;
        }
        if (args.hasOwnProperty('containerWidth')) {
            dialogWidth = args.containerWidth;
        }
        if (args.hasOwnProperty('containerHeight')) {
            dialogHeight = args.containerHeight;
        }
        if (args.hasOwnProperty('dialogUseVersion')) {
            dialogUseVersion = args.dialogUseVersion;
        }
        else {
            dialogUseVersion = true;
        }
        if (args.hasOwnProperty('dialogReloadParent')) {
            dialogReloadParent = args.dialogReloadParent;
        } else {
            dialogReloadParent = false;
        }
        if (args.hasOwnProperty('dialogCallBackFunction')) {
            dialogCallBackFunction = $(args.dialogCallBackFunction);
        }
        // reset dialog title
        _dialogTitle = "Loading...";
        // show dialog box
        openDialogBox();
        loadPageToIframe();
    };
};