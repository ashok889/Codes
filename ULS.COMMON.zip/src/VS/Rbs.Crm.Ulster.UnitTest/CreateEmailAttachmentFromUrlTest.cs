﻿using System;
using FakeXrmEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using System.Collections.Generic;
using Rbs.Crm.Ulster.Workflow;
using System.Net.Http;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Crm.Sdk.Messages;

namespace Rbs.Crm.Ulster.UnitTest
{
    [TestClass]
    public class CreateEmailAttachmentFromUrlTest
    {

        [TestMethod]
        public void TestMortgageSnapshotWithMultipleTopUp()
        {
            var fakedContext = new XrmFakedContext { };
            var httpClient = new HttpClient();

            var emailId = Guid.NewGuid();
            var email = new Entity("email", emailId);
            var fileUrl = @"https://digital.ulsterbank.ie/content/dam/Ulster/documents/RI-Region/ri-personal-ulst-brochures/your-step-by-step-mortgage-guide-ULST7971RI.pdf";
            var mimeType = "application/pdf";
            var fileName = "test.pdf";


            fakedContext.Initialize(new List<Entity>() {
               email
            });

            var fakedWorkflowContext = fakedContext.GetDefaultWorkflowContext();

            var inputs = new Dictionary<string, object>
            {
                    {"Email", email.ToEntityReference()},
                    {"FileUrl", fileUrl},
                    {"FileName", fileName},
                    {"MimeType", mimeType}
            };

            fakedContext.ExecuteCodeActivity(fakedWorkflowContext, inputs, new CreateEmailAttachmentFromUrl());

            Assert.IsTrue(fakedContext.Data["activitymimeattachment"].Count == 1);


        }

        public static async Task<string> GetDocumentFromUrl(string url, HttpClient httpClient)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            byte[] outputContent = null;
            var result = await httpClient.GetAsync(url);
            if (result.Content != null)
            {
                outputContent = await result.Content.ReadAsByteArrayAsync();
            }
            return Convert.ToBase64String(outputContent);
        }
    }
}
