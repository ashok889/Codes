﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;

namespace Rbs.Crm.Ulster.Workflow
{
    public class Common
    {
        public static async Task<string> GetDocumentFromUrl(string url, HttpClient httpClient)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            byte[] outputContent = null;
            var result = await httpClient.GetAsync(url);
            if (result.Content != null)
            {
                outputContent = await result.Content.ReadAsByteArrayAsync();
            }
            return Convert.ToBase64String(outputContent);
        }
    }
}
