﻿// <copyright file="GetHBPConfiguration.cs" company="Microsoft">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>Microsoft</author>
// <date>7/12/2019 4:36:09 PM</date>
// <summary>Implements the GetHBPConfiguration Workflow Activity.</summary>
namespace Rbs.Crm.Ulster.Workflow
{
    using System;
    using System.Activities;
    using System.Linq;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Workflow;
    using CRMClasses;

    public sealed class GetHBPConfiguration : WorkFlowActivityBase
    {
        #region properties
        [Output("Configuration")]
        [ReferenceTarget(rbs_HBPConfiguration.EntityLogicalName)]
        public OutArgument<EntityReference> Configuration { get; set; }

        #endregion

        /// <summary>
        /// Executes the WorkFlow.
        /// </summary>
        /// <param name="crmWorkflowContext">The <see cref="LocalWorkflowContext"/> which contains the
        /// <param name="executionContext" > <see cref="CodeActivityContext"/>
        /// </param>       
        /// <remarks>
        /// For improved performance, Microsoft Dynamics 365 caches WorkFlow instances.
        /// The WorkFlow's Execute method should be written to be stateless as the constructor
        /// is not called for every invocation of the WorkFlow. Also, multiple system threads
        /// could execute the WorkFlow at the same time. All per invocation state information
        /// is stored in the context. This means that you should not use global variables in WorkFlows.
        /// </remarks>
        public override void ExecuteCRMWorkFlowActivity(CodeActivityContext executionContext, LocalWorkflowContext crmWorkflowContext)
        {
            if (crmWorkflowContext == null)
            {
                throw new ArgumentNullException("crmWorkflowContext");
            }

            var service = crmWorkflowContext.OrganizationService;
            var tracing = crmWorkflowContext.TracingService;

            var serviceContext = new CrmServiceContext(service);

            var configuration = (from config in serviceContext.rbs_HBPConfigurationSet
                                 where config.rbs_Id == "HBP Configuration"
                                 select config).SingleOrDefault();

            if (configuration == null)
            {
                throw new InvalidPluginExecutionException("Can't find an HBP Configuration record");
            }

            Configuration.Set(executionContext, configuration.ToEntityReference());
        }
    }
}