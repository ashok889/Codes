﻿// <copyright file="GetASUConfiguration.cs" company="Microsoft">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>Microsoft</author>
// <date>4/6/2019 2:06:47 PM</date>
// <summary>Implements the GetASUConfiguration Workflow Activity.</summary>
namespace Rbs.Crm.Ulster.Workflow
{
    using System;
    using System.Activities;
    using System.ServiceModel;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Workflow;
    using CRMClasses;
    using System.Linq;

    public sealed class GetASUConfiguration : WorkFlowActivityBase
    {
        #region properties
        [Output("ASU Configuration")]
        [ReferenceTarget(rbs_ASUConfiguration.EntityLogicalName)]
        public OutArgument<EntityReference> ASUConfiguration { get; set; }

        #endregion

        /// <summary>
        /// Executes the WorkFlow.
        /// </summary>
        /// <param name="crmWorkflowContext">The <see cref="LocalWorkflowContext"/> which contains the
        /// <param name="executionContext" > <see cref="CodeActivityContext"/>
        /// </param>       
        /// <remarks>
        /// For improved performance, Microsoft Dynamics 365 caches WorkFlow instances.
        /// The WorkFlow's Execute method should be written to be stateless as the constructor
        /// is not called for every invocation of the WorkFlow. Also, multiple system threads
        /// could execute the WorkFlow at the same time. All per invocation state information
        /// is stored in the context. This means that you should not use global variables in WorkFlows.
        /// </remarks>
        public override void ExecuteCRMWorkFlowActivity(CodeActivityContext executionContext, LocalWorkflowContext crmWorkflowContext)
        {
            if (crmWorkflowContext == null)
            {
                throw new ArgumentNullException("crmWorkflowContext");
            }

            var service = crmWorkflowContext.OrganizationService;
            var tracing = crmWorkflowContext.TracingService;

            var serviceContext = new CrmServiceContext(service);

            var asuConfiguration = (from config in serviceContext.rbs_ASUConfigurationSet
                                    select new rbs_ASUConfiguration
                                    {
                                        Id = config.Id,
                                        rbs_PortalCreatedDefaultOwningTeamId = config.rbs_PortalCreatedDefaultOwningTeamId
                                    }).SingleOrDefault();

            if (asuConfiguration == null)
            {
                throw new InvalidPluginExecutionException("Can't find an ASU Configuration record");
            }

            ASUConfiguration.Set(executionContext, asuConfiguration.ToEntityReference());

        }

    }
}