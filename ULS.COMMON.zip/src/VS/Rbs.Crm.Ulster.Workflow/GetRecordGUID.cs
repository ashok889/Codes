﻿// <copyright file="GetRecordGUID.cs" company="Microsoft">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <author>Microsoft</author>
// <date>2/18/2020 2:15:34 PM</date>
// <summary>Implements the GetRecordGUID Workflow Activity.</summary>
namespace Rbs.Crm.Ulster.Workflow
{
    using System;
    using System.Activities;
    using System.ServiceModel;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Workflow;

    public sealed class GetRecordGUID : WorkFlowActivityBase
    {
        #region Properties         
        [Output("Current Record GUID")]
        public OutArgument<string> CurrentRecordGUID { get; set; }
        #endregion

        /// <summary>
        /// Executes the workflow activity.
        /// </summary>
        /// <param name="executionContext">The execution context.</param>
        public override void ExecuteCRMWorkFlowActivity(CodeActivityContext executionContext, LocalWorkflowContext crmWorkflowContext)
        {

            if (crmWorkflowContext == null)
            {
                throw new ArgumentNullException("crmWorkflowContext");
            }

            try
            {
                var service = crmWorkflowContext.OrganizationService;
                var tracing = crmWorkflowContext.TracingService;                

                string recordId = Guid.Empty.ToString();
                if (crmWorkflowContext != null && crmWorkflowContext.WorkflowExecutionContext != null && crmWorkflowContext.WorkflowExecutionContext.PrimaryEntityId != null)
                {
                    recordId = crmWorkflowContext.WorkflowExecutionContext.PrimaryEntityId.ToString();
                }

                CurrentRecordGUID.Set(executionContext, recordId);

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                // Handle the exception.
                throw e;
            }
        }
    }
}