﻿// <copyright file="PreOperationCaseUpdateTests.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PreValidationCaseAssignTests Class.</summary>

namespace UnitTestProject1
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Fakes;
    using System.Linq;
    using System.Reflection;
    using Cocacola.D365.Plugins;
    using FakeXrmEasy;
    using FakeXrmEasy.Extensions;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Fakes;
    using Microsoft.Xrm.Sdk.Messages;
    using Microsoft.Xrm.Sdk.Query;
    using Shouldly;

    [TestClass]
    public class PreValidationAssignCaseTest
    {
        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException), "User is not a member of the case assigned team. Please assign the case to the appropriate team instead of the individual.")]
        public void AssignOwnerUser()
        {
            var fakeContext = new XrmFakedContext();
            var service = fakeContext.GetOrganizationService();
          

            //Get a target Entity
            var targetEntity = new EntityReference(Incident.EntityLogicalName, Guid.NewGuid());
            //Get a assignee Entity User
            var assigneeEntity  = new EntityReference(SystemUser.EntityLogicalName, Guid.NewGuid());

            


            //Create input Parameter
            var inputParameter = new ParameterCollection();
            inputParameter.Add("Target", targetEntity);
            inputParameter.Add("Assignee", assigneeEntity);



            //Create plugin execution context
            var fakePluginExecutionContext = new XrmFakedPluginExecutionContext()
            {
                MessageName = "Assign",
                Stage = 10,
                UserId = Guid.NewGuid(),
                PrimaryEntityName = "incident",
                InputParameters = inputParameter
            };

            //Then setup your initial state with a single system user, for example
            var user1 = assigneeEntity.Id;
            var sysUser = new SystemUser();
            sysUser.Id = user1;
            sysUser.FirstName = "Ashok";
            sysUser.LastName = "Singh";
            fakeContext.Initialize(new List<Entity> { sysUser });

            fakeContext.AddRelationship("teammembership_association", new XrmFakedRelationship
            {
                IntersectEntity = "teammembership",
                Entity1LogicalName = SystemUser.EntityLogicalName,
                Entity1Attribute = "systemuserid",
                Entity2LogicalName = Team.EntityLogicalName,
                Entity2Attribute = "teamid"
            });


            var preImage = new Incident
            {                
                OwnerId = new EntityReference(Team.EntityLogicalName, Guid.NewGuid())
            };

            if (preImage != null)
            {
                fakePluginExecutionContext.PreEntityImages = new EntityImageCollection();
                fakePluginExecutionContext.PreEntityImages.Add("PreImage", preImage);
            }
            
            // Execute
            fakeContext.ExecutePluginWith<PreValidationAssignCase>(fakePluginExecutionContext);
                   



        }

      
    }
}
