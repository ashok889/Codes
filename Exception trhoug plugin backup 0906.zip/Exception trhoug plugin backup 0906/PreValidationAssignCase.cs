﻿// <copyright file="PostOperationCaseCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationCaseCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    [CrmPluginRegistration(MessageNameEnum.Assign, "incident", StageEnum.PreValidation, ExecutionModeEnum.Synchronous, "", "PreValidationAssignCase", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationCaseCreate Plugin.
    /// </summary>
    public class PreValidationAssignCase : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreValidationCaseAssign"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Incident preImage = context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage") ?
               context.PreEntityImages["PreImage"].ToEntity<Incident>() : null;
           
            if (context.Depth > 1)
            {
                tracingService.Trace("Depth return: " + context.Depth);
                return;
            }

            var caseHelper = new CaseHelper();
            EntityReference target = null;
            EntityReference assignee = null;
             

         

            if (context.InputParameters != null)
            {
                if (context.InputParameters.Contains("Target"))
                {
                    if (context.InputParameters["Target"] is EntityReference)
                    {
                        target = (EntityReference)context.InputParameters["Target"];
                    }
                }
                if (context.InputParameters.Contains("Assignee"))
                {
                    if (context.InputParameters["Assignee"] is EntityReference)
                    {
                        assignee = (EntityReference)context.InputParameters["Assignee"];
                    }
                }
            }

            //test
            if (target != null && assignee != null && (assignee.LogicalName == "systemuser"))
            {
                Guid assigneeID = assignee.Id;
                string assigneeLogicalName = assignee.LogicalName;


                tracingService.Trace(assigneeID.ToString());
                tracingService.Trace("Assignee Name:" + assignee.Name);
                tracingService.Trace("Assignee LogicalName:" + assigneeLogicalName);
                tracingService.Trace(target.LogicalName);
                caseHelper.CheckAssigneeTeam(context, service, adminService, tracingService, target, assigneeID, assigneeLogicalName, preImage);
                               
            }
            }
        }
    
}
