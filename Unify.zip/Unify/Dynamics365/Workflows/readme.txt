This is a base folder for all D365 custom workflow activities built for the Unify application

There should be only one solution in this folder and each custom workflow activity should have its own project/subfolder.