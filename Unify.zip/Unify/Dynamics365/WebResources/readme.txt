This is a base folder for all D365 WebResources built for the Unify application

There should be only one solution in this folder with one Assets project/subfolder. All JavaScript, HTML, CSS and other web resources for Unify application should be tracked in this one asset folder