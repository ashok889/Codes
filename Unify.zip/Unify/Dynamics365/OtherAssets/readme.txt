This is a base folder for D365 assets (such as sitemap, charts...etc.) other than WebResources built for the Unify application

There should be only one solution in this folder with one Assets project/subfolder. All sitemap definitions, charts, ribbon diff and other types of assets apart from web resources for Unify application should be tracked in this one folder