This is a base folder for all D365 plugins built for the Unify application

There should be only one solution in this folder and each plugin should have its own project/subfolder.