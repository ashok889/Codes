﻿using Adoxio.Dynamics.Connect;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace CSYW.UNIFY.D365.Configs.Tests
{
    class TestHelpers
    {
        private CrmContext d365Service;
        private EntityCollection recordsToBeCleaned;

        internal TestHelpers()
        {
            d365Service = new CrmContext();
            recordsToBeCleaned = new EntityCollection();
        }

        /// <summary>
        /// A generic helper to create any D365 record type and store the record in the temp recordsToBeCleaned list
        /// </summary>
        /// <param name="record">The record to be created</param>
        /// <returns>A Guid representing the newly created record id</returns>
        internal Guid CreateRecord(Entity record)
        {
            Guid id = d365Service.WebProxyClient.Create(record);
            recordsToBeCleaned.Entities.Add(new Entity(record.LogicalName) { Id = id});
            return id;
        }

        internal Entity QueryRecordById(string entityLogicalName, Guid id, params string[] columns)
        {
            return d365Service.WebProxyClient.Retrieve(entityLogicalName, id, new ColumnSet(columns));
            
        }

        /// <summary>
        /// Create a contact/person record and optionally set the firstname, lastname or the contactid
        /// </summary>
        /// <param name="firstName">Optional string representing the contact's First Name value</param>
        /// <param name="lastName">Optional string representing the contact's Last Name value</param>
        /// <param name="id">Optional GUID representing the contactid</param>
        /// <returns></returns>
        internal EntityReference CreateContact(string firstName = null, string lastName = null, Guid? id = null)
        {
            Entity person = new Entity("contact");
            person["firstname"] = firstName;
            person["lastname"] = lastName;
            person.Id = id ?? Guid.Empty;
            Guid newlyCreatedContactId = d365Service.WebProxyClient.Create(person);
            if (!person.Id.Equals(newlyCreatedContactId))
            {
                person.Id = newlyCreatedContactId;
            }
            recordsToBeCleaned.Entities.Add(person);
            return new EntityReference("contact", newlyCreatedContactId);
        }

        /// <summary>
        /// Initialise an EntityReference type based on the Department of Justice Source using the alternate key match
        /// </summary>
        /// <returns>An EntityReference type of the DOE referenced record</returns>
        internal EntityReference GetDOESource()
        {
            return new EntityReference("sw_source", "sw_name", "Department of Education");
        }

        /// <summary>
        /// Attempt to check System Jobs for a given job name and a regarding target record and call successCallBack handler when the job is completed
        /// </summary>
        /// <param name="intervalSeconds">Intervals in seconds between each service call/check</param>
        /// <param name="successCallBack">The handler to be executed when the job finished its execution</param>
        /// <param name="targetRecordId">The target record unique ID for the regardingobjectid of the system job</param>
        /// <param name="jobName">The system job name to be checked</param>
        internal void CheckBackgroundJobRun(int intervalSeconds, Action<EntityReference> successCallBack, Guid targetRecordId, string jobName)
        {
            int totalCount = 0;
            while (totalCount <= 10)
            {
                EntityReference regardingRecordIsFound = QuerySysJobsAndValidateBasedOnCompleteStatus(targetRecordId, jobName);
                if (regardingRecordIsFound != null)
                {
                    successCallBack(regardingRecordIsFound);
                    return;
                }
                System.Threading.Thread.Sleep(intervalSeconds * 1000);
                totalCount++;
            }

            //It means we attempted 10 tries to query system job within given interval but it wasn't completed in time.
            //thus execute successCallBack based on an empty EntityReference object
            successCallBack(new EntityReference());
        }

        /// <summary>
        /// Query the SystemJobs table for a given jobName and regardingObjectId and return the referenced record if the job is completed
        /// </summary>
        /// <param name="regardingObjectId">The target record of the system job to be queried</param>
        /// <param name="jobName">The name of the system job to be queried</param>
        /// <returns>An EntityReference representing the referenced of the regardingObjectId</returns>
        private EntityReference QuerySysJobsAndValidateBasedOnCompleteStatus(Guid regardingObjectId, string jobName)
        {
            string query = $@"<fetch distinct='false' mapping='logical' count='1' no-lock='true'>
                                <entity name='asyncoperation'>
                                    <attribute name='asyncoperationid'/>
                                    <attribute name='regardingobjectid'/>
                                    <attribute name='statecode'/>
                                    <filter type='and'>
                                        <condition attribute='name' value='{jobName}' operator='eq'/>
                                        <condition attribute='operationtype' value='10' operator='eq'/>
                                        <condition attribute='regardingobjectid' value='{regardingObjectId}' operator='eq' />
                                    </filter>
                                </entity>
                            </fetch>";

            EntityCollection sysJobs = d365Service.WebProxyClient.RetrieveMultiple(new FetchExpression(query));
            foreach (Entity job in sysJobs.Entities)
            {
                if(job.GetAttributeValue<OptionSetValue>("statecode").Value == 3)   // 3 = Completed
                {
                    return job.GetAttributeValue<EntityReference>("regardingobjectid");
                }
            }

            return null;
        }

        /// <summary>
        /// Dispose the TestHelper class and close any open service connection with Dynamics 365 instance
        /// </summary>
        internal void Dispose()
        {
            d365Service.Dispose();
            recordsToBeCleaned.Entities.Clear();
        }

        /// <summary>
        /// Call this function to delete all the records previously registered in the recordsToBeCleaned temp list
        /// </summary>
        internal void CleanUpRecords()
        {
            try
            {
                ExecuteMultipleRequest executeMultipleRequest = InitialiseExecMultiRequestObject();
                AddRecordsToBeDeletedToExecMultiRequestObject(executeMultipleRequest);

                // Execute all the requests in the request collection using a single web method call.
                var response = (ExecuteMultipleResponse)d365Service.WebProxyClient.Execute(executeMultipleRequest);
            }
            catch // ignore errors thrown by the delete service as the record might not have been created due to an error or already deleted via parental relationship
            {   }
        }

        /// <summary>
        /// Add the records to be deleted to the ExecuteMultipleRequest requests bag
        /// </summary>
        /// <param name="executeMultipleRequest">An instance of the ExecuteMultipleRequest object</param>
        private void AddRecordsToBeDeletedToExecMultiRequestObject(ExecuteMultipleRequest executeMultipleRequest)
        {
            foreach (Entity record in recordsToBeCleaned.Entities)
            {
                executeMultipleRequest.Requests.Add(
                    new DeleteRequest() {
                        Target = record.ToEntityReference()
                    }
                );
            }
        }

        /// <summary>
        /// Initialise a new ExecuteMultipleRequest object
        /// </summary>
        /// <returns>The newly initialised ExecuteMultipleRequest object</returns>
        private ExecuteMultipleRequest InitialiseExecMultiRequestObject()
        {
            ExecuteMultipleRequest executeMultipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true, // it is OK to ignore delete errors because the record might have already been deleted or not created at the first place
                    ReturnResponses = false
                },
                // Create an empty organization request collection.
                Requests = new OrganizationRequestCollection()
            };
            return executeMultipleRequest;
        }
    }
}
