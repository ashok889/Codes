<h1>D365 Security</h1>

Read this article to understand more about the security model in Dynamics 365 and how to use role-based security such as security roles, privileges, access levels, as well as an understanding of the record based security such as access rights, sharing, assigning and ownership, teams and business units scope.   
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/security-dev/security-model


## D365 Security Roles
**Recommendation**: Aim to create a **CORE** security role that can be assigned to all users in the system. Such CORE security role will implement the basic privileges that any user in the system should at least have. This role will be assigned by default to all users. Then implement specific roles for any added functionality over the CORE privileges. Security roles are additive in nature so you can stack more than one security role to achieve a grant more access to the system. 

- Do not use standard CRM roles! Create a copy + limit permissions (future updates might update the OOB roles).
- Do not create a security role from scratch. Always start by copying an existing security role from the system (i.e. Sales Person) and then customise it as required. There are lots of internal rules that should be included by default and by copying an existing role, you'll ensure such configurations are preserved. However, ensure to clean the role and test it properly prior to use.
- Always create security roles at the root BU.
- Prefix roles (easy to recognise). For instance: "UNIFY RIS Manager"
- Assign roles on user level + Limit team use: team members can be cross-BU (breaks security/performance).


## General
- Limit update/delete permissions for management users (they mostly use read anyways).
- If you disable a BU in CRM – all users in that BU and the BU’s below cannot access CRM. Disabled users can still run workflows for end-users.
- Disable sharing of records if possible (breaks security logic and is bad for performance). Try to use Access Teams for sharing (more preferred).
- Try to limit the amount of business units (performance). Try not go over 3 levels of BUs if possible.
- Have a number of base roles + have extra roles with little privileges.
