<h1>User interface Guidelines</h1>

The design of the user interface is an important to producing an efficient and accepted application that supports the needs of the business. This page provides design guidelines when working with Dynamics 365 Customer Engagement.

[[_TOC_]]

The following are the key recommended practices related to the design of the Dynamics 365 user interface.
| Practice | Description |
|:---------|:------------|
| Utilise App Modules | App Modules allow a subset of the Unify functionality to be available for a specific user community. By reducing the functionality, users become more focused on those elements that are important to perform their role and are not distracted by functionality that is rarely required. |
| Design for task based users and also power users | Some users will require a limited set of functionality that supports business processes that are executed repetitively and are therefore suited to a task based design. Other users will need the ability to handle more complex cases, more information and more flexibility and are therefore suited to a richer user interface. Both of these styles of user interface can co-exist and implement the same business rules. |
| Business Process Flows | Utilise business process flows to guide a task based user through the normal flow of a specific business process. Used wisely, business process flows can increase efficiency and reduce training effort required for users. |
| Tab based forms | Design forms that organise data over tabs rather than designing for scrolling on a single page. Designing with tabs, and loading minimal entities on the first tab, reduce page load times and improve the overall user experience. Place infrequently used attributes on tabs that are rarely used to reduce page load times and make the most of space on the form. |
| Persona Dashboards | Create Dashboard for each role or persona's that gives the user the information they need to be successful. |
| Embedded Canvass Applications | Utilise embedded canvass applications for specific and unique user interface needs. | 

## 2 Application Modules
The App Designer allows the creation of an application module that exposes a subset of functionality for a specific user community. Using this technique allows menu's, form, view and dashboards to be limited to the specific elements required for a user to perform their role. This can be an effective technique to improve usability for a specific user community but should not result users constantly switching between applications. For example, the program will consider the creation of an application for the RIS CSO's.  
The following images shows how applications could be created based upon the specific needs of a group of users within the departments. Potential applications could include those for the RIS, I&A Team, Placements Team and an application for administrators / power users that has all the available functionality.

![dynamics-applications.png](./images/dynamics-applications.png)

Each application has it's own menu structure that is designed around the needs of that specific group of users. An example is shown below.

![dynamics-uci-menu.png](./images/dynamics-uci-menu.png)

Further information on application modules can be found on the Microsoft Docs site on the [Design an app using the App Designer](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/design-custom-business-apps-using-app-designer) page.

## 3 Business Process Flows
Business process flows allow a sequence of steps to be defined to complete a given task or business process. At each step the common required information and activities can be presented to the user to guide them through the most efficient path. 

The following design guidelines are to be followed:
- For common tasks / business processes define a business process flow to guide the user through the normal steps that are required
- Restrict the business process flows by security role

The example below show a sample business process flow for Intake.

![dynamics-intake-bpf.png](./images/dynamics-intake-bpf.png)

Further information on can be found on the Microsoft Docs site on the [When to use business process flows](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/guide-staff-through-common-tasks-processes#when-to-use-business-process-flows) page.

## 4 Forms
Forms are used to display and update information regarding a specific business entity, such as Person, and it's related information. Forms are organised into tabs with each tab only loading the relevant information when selected. 

The following design guidelines are to be followed:
- Create forms based upon the business workflow of the intended users. It is likely that there will be multiple forms per entity while recognising that each form will require additional maintenance effort to configure and test.
- Limit forms for users through application modules and security roles to avoid confusion and target to the users specific needs.
- Utilise tabs to organise data and reduce scrolling. Minimise the number of entities that need to be queried on the first tab to improve page load times.
- Use quick create views to allow related information to be created without forcing the user to leave the current form
- Use quick view and canvass applications to meet the needs of specific user interface requirements
- Use business process flows to guide a user through repeatable and task based processes

The example below shows a sample case form that uses tabs and also a business process flow.

![dynamics-uci-case-form.png](./images/dynamics-person-form.png)

Further information on can be found on the Microsoft Docs site on the [Create and design forms](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/create-design-forms) page.


## 5 Views
View are used to produce lists of information that can be sorted, searched and filtered. 

The following design guidelines are to be followed:
- Create views based upon the specific needs of the business users and their needs.
- Restrict the views available within an application module to avoid complexity and improve the user experience.

The example below shows a sample view.

![dynamics-contacts-view.png](./images/dynamics-contacts-view.png)

Further information on can be found on the Microsoft Docs site on the [Create or edit view](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/create-edit-views) page.

## 6 Dashboards
Dashboards are useful way to present a user with the information required to be successful in their role on a single page. 

The following design guidelines are to be followed:
- Create a dashboards per role / persona that shows the information required to be successful in their role
- Include charts on the dashboards to indicate metrics relevant to the individual and their team.
- Include lists (views) that show the outstanding data (ie tasks) that needs to be addressed by the individual, alerts and team based work
- Secure dashboards by security role to reduce complexity

Further information on dashboards can be found on the Microsoft Docs site on the [Create or edit Dashboards](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/create-edit-dashboards) page.

## 7 Canvass Applications (PowerApps)
Canvass applications can be used to bring together informations from within Dynamics 365 and external information into a custom user component. Canvass applications can also be embedded within the model driven Dynamics 365 user interface. When used appropriately canvass applications can be a powerful design option. 

The following design guidelines are to be followed:
- Create a canvass application and embed it within the Dynamics 365 Customer Engagement user interface when specific needs can't be met by the model driven user interface
- Don't select canvass applications when the model driven user interface meets the business needs  

Further information on canvass applications can be found at https://docs.microsoft.com/en-us/business-applications-release-notes/october18/powerapps/extend-dynamics-365-entity-forms-with-embedded-canvas-apps

## 8 PowerApps Control Framework
The PowerApps Control Framework allows professional developers to create components that can be used to provide specific visualisations of the Dynamics 365 data within the model driven or canvass applications user interface. PowerApps Control Framework provides developers significant flexibility and power but will require significant effort. 

The following design guidelines are to be followed:
- Only use the PowerApps Control Framework where there is a specific visualisation need that is likely to be required multiple times within the applications 

