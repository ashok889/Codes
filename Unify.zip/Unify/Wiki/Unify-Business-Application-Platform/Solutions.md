<h1>Solution Management</h1>
Solutions are how customisers and developers author, package, and maintain units of software that extend Dynamics 365 apps. Customisers and developers distribute solutions so that organisations can use Dynamics 365 apps to install and uninstall the business functionality defined by the solution. Solutions can include, package and transport the following components:

![solution-components.png](./images/solution-components.png)

Before reading the below practices when dealing with Dynamics 365 solutions, make sure to read and familiarise yourself with its concept and the various types [here](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/introduction-solutions).

[[_TOC_]]

## Solution Publisher
- Solutions require a Publisher
- Publisher can be associated with multiple solutions
- A default publisher is included in Dynamics 365 Customer Engagement. However, it is a recommended practice to create your own and not use the default publisher
- The publisher dictates the customisations prefix and option set values

**Important**: When importing new assets through a managed solution – the publisher “owns” those assets.

## Unmanaged vs Managed
This is a simple comparison between Unmanaged and Managed solutions:

|Unmanaged Solution | Managed Solution |
|:------------------|:-----------------|
| Acts as a container of customizations that exist on top of the system and other managed solutions<br/><br/>Unmanaged solutions are “Open”<ul><li>They allow direct customization to components</li><li>They hold references to customization and components but do not own them</li><li>They do not delete or remove components if the solution is deleted </li></ul> | A “version complete” unmanaged solution that has been exported as managed<br/><br/>Managed solutions are “Closed”<ul><li>The identity of the solution cannot be modified</li><li>Components cannot be added or removed</li><li>They exist within their own discrete layer</li><li>They merge with other layers and the system layers to present application behaviour to the user</li><li>They can be uninstalled (deleted) and they do delete components that they directly own</li><li>They can be upgraded and serviced as separate discrete layers allowing ISVs or multiple departments to provide multiple applications to a shared environment </li></ul>|

In general, this if the rule that should be followed:
- **Managed solution** is used in **Test **and **Production** instances
- **Unmanaged solution** is used in **Development** instances only 

It is very important to understand solution layering because this could result in some modifications overruled or get hidden by other configurations in a different layer. Consider this:
- Layering occurs on import of solutions when a specific component is affected by change within one or more solution
- Layers describe the dependency chain of component from the root solution introducing it, through each solution that extends or changes the component’s behaviour
- Layers are created through extension of an existing component (taking a dependency on it) or through creation of a new component or version of a solution. 
- **Important**: Layers should be considered on a per-component basis. Although typically drawn to convey the effect of a solution on another solution, this is always at a component or sub-component level.

## Solution Segmentation
- Include only the assets/sub assets that have changed – not the entire entity
- This reduces size and complexity of solution imported == reduced import time
- By default, new custom entities will have all assets included in the solution it was created under

**Important**: Solution segmentation reduces collisions caused by multiple team members working on assets of the same entity but cannot avoid it entirely. A proper communication is still required at some cases (i.e. when 2 developers are working on the same form at the same time).

General rule is:

    DONT tick "Add All Assets" when adding an entity to a solution

## Solution Patching
Use solution patching when releasing hotfixes or new features to an existing solution. Refer to this article ([Create patches to simplify solution updates](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/create-patches-simplify-solution-updates)) for a complete description for the patching concept and how to apply it.

We recommend you to read the following white paper on Solution Lifecycle Management and especially the section about updating solution components via patching (page 29): [Solution Lifecycle Management: Dynamics 365 for Customer Engagement apps](https://www.microsoft.com/en-us/download/confirmation.aspx?id=57777) 

General rule is:

    Use patching when releasing a new hotfix or implement a new feature release to an existing solution. Once the solution is stable in production, you need to clone the patch back to the main solution.

Note the following:
- a Patch will contain changes to the parent solution
- No need to include all parent's components and rather only what has been modified
- a Patch can introduce new components that were not present in the original parent solution
- When cloning a solution, all patches related to the solution are rolled up into the newly-created version of the original solution


## Version Control
Knowing who changed what when is critical for all software development including model-driven app solutions. Granular version control enables faster identification of regressions and changes to
behaviour.

Storing versions of the exported solution.zip file in source control is analogous to storing a compile binary in source control. It is not possible to easily identify what has changed, when it changed and
who changed it.

Just as the source code for a .NET binary should be stored in source control, the unpacked XML fragments of the exported solution.zip file should be stored in source control.

**How to achieve a proper solution versioning practice**

Aim to increase the solution version number when components are added or configured in that solution. Then use the [Solution Packager](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/compress-extract-solution-file-solutionpackager) tool (shipped in the D365 SDK) to extract the solution component into the same repo folder in Azure DevOps and then check-in. The solution packager is smart enough to only modify and update only the changed component's XML files. Finally, check-in the changes to Azure DevOps repo and provide a meaningful comments.

## One Solution for Unify
We recommend to reduce the number of solution created for easier release and deployment management as well as for better automated build and release cycles. If patches were created, aim to clone them back to main CORE solution as soon as the platform is tested and stable.

For DCSYW, we recommend producing **one CORE solution** that includes all the configurations and customisations required for the Unify business functionality. By following this approach, we'll make it easier for the build and release pipelines to build new development instances or deploy changes in the future.

When working in a team, each developer should ensure to get the latest version of the CORE solution from source control and he/she should make the changes in their own instance and publish the changes back to source control. A nightly build in Azure DevOps will be able to pick-up the changes and pushes it to the central development instance. In the following day, the developer should ensure to refresh their solution with customisations made by other developers in their own instances.

