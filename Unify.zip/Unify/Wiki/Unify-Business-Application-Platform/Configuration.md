<h1>Configuration Practices</h1>


In general, configurations are business functionality that can be implemented within the solution from the standard administrative settings UI; it includes field and form changes, business rules, standard reports or charts and standard workflows.

This document describes the standards which should be followed while configuring Dynamics CRM. These are a set of practices to help configuring CRM to do so in a consistent, clear, and meaningful manner.

These practices are divided into four categories: 
- DO – This should always be followed except in very rare circumstances. 
- CONSIDER  – This should usually be the case, but there are well known exceptions. 
- AVOID – This should be rarely done, but again, there are cases where it is the best option. 
- DONT – There is almost never a reason to do this. Doing so may void any support options

The purpose of this document can be summarized as follows:
- Establish and agree on configuration standards
- Follow consistent approach in configuring the system

[[_TOC_]]

## Entity Design

### Entity Creation
- While creating an entity, keep the options unticked. Some options are irreversible and can't be undone (i.e. enabling notes or activities).

- Always aim to create the schema name in lowercase. This way both the schema and logical names will be in lowercase which will make development easier.

- Do not modify the logical name of the primary field. It is preferable to keep the primary name field of all custom entities the same for easier development (i.e. sw_name). This will be helpful specially when implementing some generic code that doesn't have to guess what's the name of the primary name field. It is OK to update the display name of the primary field as needed.

- Any custom entity created in Microsoft Dynamics 365 should have an icons/images attached to it. This adds a lot of value to the quality of work and will  make the UI of Microsoft Dynamics 365 easy to follow and look rich which helps in getting a good first impression on the project.

    Use the following naming convention for naming the icon web resource: 
    
        pfx_/Images/<EntityName>Icon_16*16.jpg
    Ex: sw_/Images/AccountIcon_16*16.jpg

### Forms/Views/Fields
- When creating a field, always use lowercase for the schema name. This will simplify development and will keep both the schema and logical name the same.
- Default values on fields only apply to client side forms.
- When creating a field, ensure you are in the right solution and has the right prefix as set by the publisher (i.e. sw_)
- When changing a system option set, do not change the numerical values (might break Ms Dynamics 365 on upgrades later on).
- “Searchable” option on fields is to make field available for advanced find/reporting.
- Prefer custom entity’s over option sets (autocomplete, possible to link lookups…etc.). This is more true if the list has to be maintained by the user rather than an administrator.
- Always create “global” option sets when creating option sets if the values are common for more than one entity.
- Always create manual N-N relationships (2 x N-1) over the out of the box N-N relationships when:
    - Possibility to add intersect table fields
	- Possibility to run workflows/reports
	- Possibility to place a view of related entity fields on forms
	- Possibility of registering plugins upon association.
- Cascade relationship options: referential, restricted delete is preferred.
- Advice on D365 views: create a couple of useful generic views and let users create their own personal ones. Also you can use a View Replicator tool available in the [XrmToolbox](https://www.xrmtoolbox.com/) to replicate the view details from one view to the rest. 
- The standard tabbing in Dynamics CRM form is top to bottom per section. You can use multiple sections (1 per row) to do left to right tabbing.
- Always aim to hide by default through form configuration any fields that should be shown/hidden based on a business rule or a JavaScript logic. This way, the form will load without showing the field and when the business rule/JavaScript finished executing, the field will be either shown/hidden based on the logic. 

### Description
A short description should be added to all the Entities and Attributes created, which helps in understanding the purpose of the entity/Attribute in future. 

More importantly, the description will be shown as a tooltip when a user hover on a particular field that has a description. Always use meaningful description that tells the user about the intend of the field in context.

### Relationship Creation 
Creating a 1:N relationship between 2 entities creates a lookup data type attribute. Uniformity of the relationship attribute in CRM system is important as it helps us identify the relationship attribute name all over the system. This helps developers while coding to easily identify the relationship attribute.

Always aim to suffix the lookup field name with “id”. This aligns with out of the box lookup fields convention.

    <EntityName> + <id>

Example: 1:N Relation between Custom Entity _Property_ and _Account_. Account will have a lookup to Property entity; name of the attribute should be **sw_propertyid** not sw_property or sw_propertynameid.

## System Workflows

Workflows are good way to execute a configurable business logic at the server side either Asynchronously (in the background) or Synchronously (in real-time). The technology was introduced in the earlier versions of Dynamics CRM and for Dynamics 365 Online, the shift and preference is moving more toward using Microsoft Flow for a similar implementation. However, this is only applicable to the Asynchronous workflows.

**As a general guide, if you can implement the background logic in MS Flow, then use it, otherwise use D365 Workflows. For real-time business logic, workflows can continue to be used.**

Workflows run as part of the Asynchronous Service within Dynamics 365 Online environment and administrators do not have control over this service. This is a shared service so avoid using long process running against large volume of records in order not to degrade the performance of this service.

**Workflow Considerations**

- When creating a workflow, ensure to use an agreed prefix so that all workflows related to a certain department, product or functionality will be grouped together logically for easier maintenance.

- Keep custom workflows to small bits of functionality only (reusability).

- Use workflows only for long running processes & when you need to have a process that is started by users (on-demand).

- When having a long-running workflow, de-active workflow – change workflow – activate workflow – old workflow will still be running in the old context (versionnumber)
Workflow only gets values when the workflow is run (if a field’s value changes twice fast, the Workflow will take the last value)

- When updating numeric fields with workflow, make sure you set a default value or it will give an error.

- AVOID infinite loops. It’s possible to create logic in a workflow that initiates an infinite loop, which consumes server resources and affects performance. The typical situation where an infinite loop might occur is if you have a workflow configured to start when an attribute is updated and then updates that attribute in the logic of the workflow. The update action triggers the same workflow that updates the record and triggers the workflow again and again.

    Microsoft Dynamics 365 includes logic to detect and stop infinite loops. If a workflow process is run more than a certain number of times on a specific record in a short period, the process fails with the following error: “This workflow job was canceled because the workflow that started it included an infinite loop. Correct the workflow logic and try again”. For Microsoft Dynamics 365 (online) the limit of times is **16**. For on-premises deployments of Dynamics 365, the limit is **8**. 

- CONSIDER Using workflow templates. If you have workflows that are similar and you anticipate creating more workflows that follow the same pattern, save your workflow as a workflow template. This way, the next time you need to create a similar workflow, create the workflow using the template and avoid entering all the conditions and actions from scratch. 

- CONSIDER Using child workflows. If you apply the same logic in different workflows or in conditional branches, define that logic as a child workflow so you don’t have to replicate that logic manually in each workflow or conditional branch. This helps make your workflows easier to maintain. Instead of examining many workflows that may apply the same logic, you can just update one workflow.

- DO keep fewer logs. We recommend to configure a bulk delete job rule that will delete successful and cancelled system jobs instances older than 1 months. When creating workflows, we recommend leaving the option "**Automatically delete completed workflow jobs (to save disk space)**" unticked (disabled) so that the system will automatically delete completed jobs instance and rather DCSYW will need to delete them manually. We recommend to configure a system bulk delete job rule that is scheduled to run on nightly bases and will delete completed jobs older than 1 month. This way you have enough time to troubleshoot an issue and trace the history run in case of a production issue. Ensure that the Failed system jobs are excluded from this job and such instances should be dealt with manually and then deleted or re-executed as desired. The 1 month is just a recommended period and DCSYW can elect to increase or decrease this value as per the workload of the support team. However, you don't want to leave the completed system jobs for so long as they'll consume storage quota and will start to degrade performance.

- CONSIDER Using Notes to keep track of changes. When you edit workflows, you should use the Notes tab and type what you did and why you did it. This allows someone else to understand the changes you made.

## Business Rules
Business Rules are a client and server side technology that will help implementing various rules to help applying some validation, improve UI experience or achieve a better business processing logic.

**Considerations**
- Ensure to set the scope of Business Rules at "entity" level if you need the business rule to fire at the server side. Use this approach for validation and to ensure that the rule is met regardless of how the data was submitted to Dynamics 365.
- If you want to hide a section in a business rule, hide all the fields within it
- You'll need to cater for the Else/Otherwise condition in the business rule logic implementation. For instance, if you have a logic that will hide a field based on a status value, then you'll need an else condition to show the field back. This is needed if the user changes the values on the form multiple times.
- **DO implement logic in a business rule first if possible**. If not, then aim to use JavaScript or Plugins. There are situations where writing a JavaScript is more efficient but in a general rule, **always use Business Rules due to their configurable nature**. Consider this scenario in which a JavaScript might be a better implementation:
   - You have an optionset on a form to represent some category listing and based on its value, you need to show/hide relevant fields on the form. If you implement this in a Business Rule, then the If and Else conditions will be quite lengthy and even harder to maintain and will require more time to implement. However, you can implement a JavaScript function that will show/hide sections automatically matched to the same names of the optionset values. This script will be short and dynamic and can be reused. All you have to do is place and group the required fields in a section and let the JavaScript show/hide the section based on the selected optionset value. This design can support extendibility in which you can create and add more fields to those sections and they'll automatically show/hide with the rest of the fields in those sections/groups. If we would to implement this in a Business Rule, then any changes or addition to the fields, will require the modification to all the conditions that show/hide the fields on the form in that Business Rule.
- You cannot hide sections, tabs or controls using Business Rules in the current version of the platform.

## Auditing
Security and data auditing is an integral part of the platform. Dynamics 365 supports 2 levels of auditing:
- Traditional Audit Logging within the D365 application itself. This will audit create, update, delete as well as user access to the system but will not audit Read or metadata changes. Click [here](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/auditing-overview) for more info.
- The new Activity Logging within Office 365. Used for more advanced logging requirement and takes place at the SDK layer. This is stored outside Dynamics 365. Click [here](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/admin/enable-use-comprehensive-auditing) for more info.

We recommend enabling all the custom fields created to support the application and especially the ones visible and editable on form for auditing. We recommend enabling Auditing on all following platform assets as well.

![system-settings-auditing.png](./images/system-settings-auditing.png)

Note: this will consume storage quota but will ensure compliance is met. The DCSYW should still review the auditing configurations if storage consumption rate is high and aim to optimise it without introducing compliance issues.

Also, consider clearing old audit partitions if no longer needed as part of the organisation's audit data retention policies.

## Admin and Business Management

### Duplicate detection
Aim to configure some out of the box duplicate detection rules and agree with the business on the detection rules and when they should be applied.

Only publish the required rules. You can deactivate rules if they are no longer needed.

Aim to run duplicate detection jobs outside of business hours.

There is an aggregation limit of 50,000 when running duplicate detection rules on large dataset. Aim to segment or filter your detection query to a lower subset.  

### System Settings
One of the first configurations you need to review when setting new environment is the System Settings. Ensure the following considerations:
- Consider setting the default locale and format to Australian region.
![system-setting-format.png](./images/system-setting-format.png)
- Configure the Email tracking settings. Ensure to set the appropriate incoming and outgoing synchronisation rules and ensure to use **Server Side Synchronization**. Configure the Tracking token and update the prefix if required to "CSYW". 
- Enabling auditing settings as per the Audit section above
- Enable logging to plugin-in trace log at the "Exception" level. We recommend keeping it to none in the production system if the environment is stable. However, this might makes it harder to troubleshoot issues and you might want to consider updating it to Exception until the platform is stable again. Never set it to "All" in the production instance.
![system-setting-pluginex.png](./images/system-setting-pluginex.png)

    If you keep the level on Exception, you need to ensure to either manually delete the plugin traces after the troubleshooting period or configure Automatic and daily bulk delete job to clear the logs.

- Review the rest of the options and make any changes as desired. Most importantly, document such changes and ensure the settings are replicated on all instances. You can include the setting export feature when exporting the solution so the settings will transport with the solution file.

### Bulk Delete Jobs
Regularly configure bulk delete jobs that will clear some of the unwanted records based on conditions. These bulk delete jobs can even be configured as part of a design feature (i.e. Delete transaction logs that are older than 1 year and have the Inactive status).

In particular, we recommend to configure a bulk delete job rule that will delete successful and cancelled system jobs instances older than 1 months. Refer to the System Workflows section above.

### Financial Year Settings
For the financial year settings, ensure to specify the start date of the Australian FY period as the 1st of July 2019 and adjust the template as required.

![FY-Settings.png](./images/FY-Settings.png)

## Sitemap and Apps
Always aim to use the out of the box app designer when configuring sitemap. Grouping functionalities in Apps is highly recommended but this is subjected to the overall design of the system. Apps provide a modular approach to the design and can be controlled via security role assignments as well as selectively only add the required components. We recommend to use and create an App for any deployment even if there is only the need to create a single app.