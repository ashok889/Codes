<h1>Working in a Team</h1>
When there are multiple developers working on the same solution component a conflict might arise where changes from two developers result in changes to a single file. This occurrence is minimised by decomposing each individually editable component or subcomponent into a distinct file.

[[_TOC_]]

## If working on different components

Consider the following example.
1. Developer A and B are both working on the same solution.
1. On independent computers, they both get the latest sources of the solution from source control, pack, and import an unmanaged solution .zip file into independent Dynamics 365 for Customer Engagement Customer Engagement organisations.
1. Developer A customises the “Active Contacts” system view and the main form for the Contact entity.
1. Developer B customises the main form for the Account entity and changes the “Contact Lookup View”.
1. Both developers export an unmanaged solution .zip file and extract.
   - Developer A will need to check out one file for the Contact main form, and one file for the “Active Contacts” view.
   - Developer B will need to check out one file for the Account main form, and one file for the “Contact Lookup View”.
1. Both developers may submit, in any order, as their respective changes touched separate files.
1. After both submissions are complete, they can repeat step 2 and then continue to make further changes in their independent organisations. They each have both sets of changes, with no overwrites of their own work.

## If working on the same components

The previous example works only when there are changes to separate files. It is inevitable that independent customisations require changes within a single file. Based on the example shown above, consider that developer B customised the “Active Contacts” view while developer A was also customising it. In this new example, the order of events becomes important. The correct process to reconcile this predicament, written out in full, is as follows.
1. Developer A and B are both working on the same solution.
1. On independent computers, they both get the latest sources of the solution from source control, pack, and import an unmanaged solution .zip file into independent organisations.
1. Developer A customises the “Active Contacts” system view and the main form for the Contact entity.
1. Developer B customises the main form for the Account entity and changes the “Active Contacts”.
1. Both developers export an unmanaged solution . zip file and extract.
   - Developer A will need to check out one file for the Contact main form, and one file for the “Active Contacts” view.
   - Developer B will need to check out one file for the Account main form, and one file for the “Active Contacts” view.
1. Developer A is ready first.
   - Before he submits to source control he must get latest sources to ensure no prior check-ins conflict with his changes.
   - There are no conflicts so he is able to submit.
1. Developer B is ready next following developer A.
   - Before she submits she must get the latest sources to ensure no prior check-ins conflict with her changes.
   - There is a conflict because the file for “Active Contacts” has been modified since she last retrieved the latest sources.
   - Developer B must reconcile the conflict. It is possible the capabilities of the source control system in use may aide this process; otherwise the following choices are all viable.
      - Developer B, through source control history, if available, can see that the developer A made the prior change. Through direct communication they can discuss each change. Then developer B only has to update her organisation with the agreed resolution. She then exports, extracts, and overwrites the conflicting file and submits.
      - Allow source control to overwrite her local file. Developer B packs the solution and imports it into her organisation, then assesses the state of the view and re-customises it as necessary. Next, she may export, extract, and overwrite the conflicting file.
      - If the prior change can be deemed unnecessary, developer B allows her copy of the file to overwrite the version in source control and submits.

Whether working on a shared organisation or independent organisations, team development of Dynamics 365 for Customer Engagement solutions requires **those actively working on a common solution to be aware of the work of others**.


## Create a solution

The following procedure identifies the typical steps used when first creating a solution.
1. In a clean organisation, create a solution on Dynamics 365 for Customer Engagement server, and then add or create components as necessary.
1. When you are ready to check in, do the following.
   - Export the unmanaged solution.
   - Using the SolutionPackager tool, extract the solution into component files.
   - From those extracted component files, add the necessary files to source control.
   - Submit these changes to source control.

## Modify a solution

The following procedure identifies the typical steps used when modifying an existing solution.
1. Synchronise or get the latest solution component file sources.
1. Using the SolutionPackager tool, pack component files into an unmanaged solution .zip file.
1. Import the unmanaged solution file into an organisation.
1. Customise and edit the solution as necessary.
1. When you are ready to check the changes into source control, do the following.
   - Export the unmanaged solution.
   - Using the SolutionPackager tool, extract the exported solution into component files.
   - Synchronise or get the latest sources from source control.
   - Reconcile if any conflicts exist.
   - Submit the changes to source control.
   
Steps 2 and 3 must be done before further customisations occur in the development organisation. Within step 5, the second step must be completed before the third step.