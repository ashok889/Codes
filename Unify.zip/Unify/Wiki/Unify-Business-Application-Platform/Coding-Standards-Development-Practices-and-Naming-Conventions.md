<h1>Coding Standards, Development Practices and Naming Conventions</h1>
This section provides guidelines and standards for the structure and references for the coding and configurations for the project. It defines the set of standards that help provide structure to the way the source files are named and also the content structure of each source file. The main aim of having standards, especially a structured standard, is to enhance the code maintainability and readability.  It is crucial that everyone in the team is committed to following the standards.

[[_TOC_]]

## General Coding Language Standards

For D365 and .NET specific coding standards, refer to the following documents:
|Document Type | Location/Reference |
|:-------------|:-------------------|
| Best practices for developing with Dynamics 365 for Customer Engagement| https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/best-practices-sdk |
| Microsoft .Net and C# Coding Standards and Guidelines	| |
| JavaScript Coding Standards	| |

The above documents include all such components that are applicable for the type of coding produced. For example, for Dynamics 365 it includes .NET C# and JavaScript coding standards that will be used when writing JavaScripts Webresources or Plugins.

## Header File Comments
The following sections provide the standard comments block to be used for the project for different type of files.


### C# Common Class

    /********************** Source File Header **************************\
    Project Name: CSYW - Unity
    Module/Stream Name: <module>
    Copyright (c) CSYW. All other rights reserved.
     
    Creation Date: <date>
    Created By: <name>
    Last Modification Date: <date>
    Last Modified By: <name>
    Version: 1.0.0.1
    Purpose: <…>
    \*******************************************************************/

### C# Plugin and Custom Workflow Class

    /********************** Source File Header **************************\
    Project Name: CSYW - Unity
    Module/Stream Name: <Module>
    Copyright (c) CSYW. All other rights reserved.
     
    Creation Date: <date>
    Created By: <name>
    Last Modification Date: <date>
    Last Modified By: <name>
    Version: 1.0.0.1
    Purpose: <…>
     
    Registration Details
    Event/Message: Create, Update…etc.
    Primary Entity: Account, Contact…etc.
    Stage: Post-Create, Pre-Update
    \*******************************************************************/
 
### JavaScript Web Resource Script

    /********************** Source File Header **************************\
    Project Name: CSYW - Unity
    Module/Stream Name: <Module>
    Copyright (c) CSYW. All other rights reserved.
     
    Creation Date: <date>
    Created By: <name>
    Last Modification Date: <date>
    Last Modified By: <name>
    Version: 1.0.0.1
    Purpose: <…>
     
    Event Details
    Entity: Account, Contact…etc.
    Event: OnLoad, OnSave…etc.
    \*******************************************************************/
 
 
### HTML File

    <!--
    <description>
        Project: CSYW - Unity
        Module/Stream Name: <Module>
        Copyright (c) CSYW. All other rights reserved.
    </description>
     
    <creationDate>date</creationDate>
    <createdBy>name</createdBy>
    <lastModificationDate>date</lastModificationDate>
    <lastModifiedBy>name</lastModifiedBy>
    <Version>1.0.0.1</Version>
    <purpose>…</purpose>
    -->
     
### XML File

    <?xml version="1.0" encoding="utf-8" ?>
    <!--
    <description>
        Project: CSYW - Unity
        Module/Stream Name: <Module>
        Copyright (c) CSYW. All other rights reserved.
    </description>
     
    <creationDate>date</creationDate>
    <createdBy>name</createdBy>
    <lastModificationDate>date</lastModificationDate>
    <lastModifiedBy>name</lastModifiedBy>
    <Version>1.0.0.1</Version>
    <purpose>…</purpose>
    -->
 
### ASPX page

    `<%@ Page Title="Home Page" ... %>
    <%--
    /********************* Source File Header **************************\
    Project: CSYW - Unity
    Module/Stream Name: <Module>
    Copyright (c) CSYW. All other rights reserved.
     
    Creation Date: <date>
    Created By: <name>
    Last Modification Date: <date>
    Last Modified By: <name>
    Version: 1.0.01
    Purpose: <…>
    \*******************************************************************/
    --%>

## Naming Conventions

### General Assembly Naming Convention
When .NET assemblies are required, the following naming convention should be followed:
| Module |	Assembly Naming Convention |
|:-------|:----------------------------|
|D365 Plugins | CSYW.Unity.D365.Plugins.<Requirement> |
| D365 Plugins UTest | CSYW.Unity.D365.Plugins.<Requirement>.Test |
| D365 Custom Workflows	| CSYW.Unity.D365.Workflows.<Requirement> |
| D365 Custom Workflows UTest |	CSYW.Unity.D365.Workflows.<Requirement>.Test |
| D365 Supporting Apps | CSYW.Unity.D365.SupApp |
| D365 Supporting Apps UTest | CSYW.Unity.D365.SupApp.Test |
| D365 Reports | CSYW.Unity.D365.Reports |
| D365 Reports UTest | CSYW.Unity.D365.Reports.Test |
 
**Note**: Build each required plugin or custom workflow activity in its own and individual assembly and specify the requirement or the functionality name in the assembly naming convention. This is important for deployment and maintenance and to allow future changes to plugins and deployment without the need to retest the entire plugins code base.

A generic assembly will be created to host all the shared libraries and code as following. Note there is no reference to Plugins keyword in the assembly because the same code can be shared with workflow assemblies as well.
| Module | Assembly Naming Convention |
|:-------|:---------------------------|
| D365 Common Library | CSYW.Unity.D365.Common |
 
### D365 Web Resource Naming Convention
Virtual folder structure should be followed when creating and naming D365 web resources as following:
| Module | File Naming Convention |
|:-------|:-----------------------|
| JavaScripts for entity events | <prefix>_/Scripts/<EntityName>.js |
| JavaScripts for a general functionality | <prefix>_/Scripts/<Functionality>.js |
| HTML hosted for a specific entity | <prefix>_/HTML/<EntityName>.html |
| HTML for a general functionality | <prefix>_/HTML/<Functionality>.html |
| Style Sheets for a general functionality | <prefix>_/Styles/<Functionality>.css |
| Images | <prefix>_/Images/<ImangeName>.png |
| Entity Icons | <prefix>_/Icons/<EntityName>_16x16.png<br><prefix>_/Icons/<EntityName>_32x32.png |

### C# Naming Conventions
- DO choose easily readable identifier names. E.g., a property named HorizontalAlignment is more English-readable than AlignmentHorizontal.
- DO favour readability over brevity. E.g. The property name CanScrollHorizontally is better than ScrollableX (an obscure reference to the X-axis).
- DO NOT use underscores, hyphens, or any other non-alphanumeric characters.
- DO NOT use Hungarian notation.
- AVOID using identifiers that conflict with keywords of widely used programming languages.
- DO NOT use abbreviations or contractions as part of identifier names. For example, use GetWindow rather than GetWin.
- DO NOT use any acronyms that are not widely accepted, and even if they are, only when necessary.
- DO use semantically interesting names rather than language-specific keywords for type names.
	For example, GetLength is a better name than GetInt.
- DO use a generic CLR type name, rather than a language-specific name, in the rare cases when an identifier has no semantic meaning beyond its type.
- For example, a method converting to Int64 should be named ToInt64, not ToLong (because Int64 is a CLR name for the C#-specific alias long).
- DO use a name like the old API when creating new versions of an existing API. This helps to highlight the relationship between the APIs.
- DO prefer adding a suffix rather than a prefix to indicate a new version of an existing API. This will assist discovery when browsing documentation, or using Intellisense. The old version of the API will be organised close to the new APIs, because most browsers and Intellisense show identifiers in alphabetical order.
- CONSIDER  using a brand new, but meaningful identifier, instead of adding a suffix or a prefix.
- DO use a numeric suffix to indicate a new version of an existing API, particularly if the existing name of the API is the only name that makes sense (i.e., if it is an industry standard) and if adding any meaningful suffix (or changing the name) is not an appropriate option.
- DO NOT use the "Ex" (or a similar) suffix for an identifier to distinguish it from an earlier version of the same API.
- DO use the "64" suffix when introducing versions of APIs that operate on a 64-bit integer (a long integer) instead of a 32-bit integer. You only need to take this approach when the existing 32-bit API exists; don’t do it for brand new APIs with only a 64-bit version.
- DO choose names for your assembly DLLs that suggest large chunks of functionality, such as System.Data.
- DO prefix namespace names with a company name to prevent namespaces from different companies from having the same name.
- DO use a stable, version-independent product name at the second level of a namespace name.
- DO NOT use organisational hierarchies as the basis for names in namespace hierarchies, because group names within corporations tend to be short-lived. Organise the hierarchy of namespaces around groups of related technologies.
- DO use Pascal Casing, and separate namespace components with periods (e.g., Microsoft.Office.PowerPoint). If your brand employs non-traditional casing, you should follow the casing defined by your brand, even if it deviates from normal namespace casing.
- CONSIDER  using plural namespace names where appropriate. For example, use System.Collections instead of System. Collection. Brand names and acronyms are exceptions to this rule, however. For example, use System.IO instead of System.IOs.
- DO NOT use the same name for a namespace and a type in that namespace. For example, do not use Debug as a namespace name and then also provide a class named Debug in the same namespace. Several compilers require such types to be fully qualified.

### Solution Naming Standards
- DO use Pascal Case in the name field. The name field is driven and automatically created for you from the display name field. Once you have created a display name and tabbed out of the field, a name will get created for you with all spaces removed. You should then go in and make any changes to the name to adhere to recommended naming conventions. 
- DO use meaningful names when creating a display name for your solution. 
- AVOID creating a display name and name field combination that are drastically different and unrelated in meaning to each other. They should generally be the same. They identify the same thing just each one is viewed differently. The name entry is in there for the Metadata ID and the display name is there for the user to see in various views from within CRM. 
- AVOID the use of underscores in the display name and you should also try not to use character symbols. There in not a need to do so and underscores and symbols may change the expected sorting of the solutions list. 
- DO NOT use the name “Solution” in your Solution name. Since you are creating a solution, it is redundant and provides no added value.

**Note**: the following is the solution created by Microsoft to package the customisations made as part of the exemplar or the Mandatory Reporting module:

![solution-social-welfare.png](./images/solution-social-welfare.png)

### Publisher Naming Standards
- DO use Pascal Case in the display field. As in the solution the name field is driven and automatically created for you when tabbing out of the display field. Once it has been created you can fine tune it if needed. 
- DO change the prefix of the default system publisher before any customisations are made. The default publisher is the one that is used for unmanaged solutions. Change it to something meaningful for the unmanaged customisations. All developers within the same project should be using the same prefix to avoid creating duplicate fields. 
- DO name your Publisher and change your prefix to be reflective of the Vertical solution or “Project” that you want to group these customisations together for when creating additional publishers. 
- AVOID using long prefix names. This will become part of attribute names that will be referenced in plugin and other customisations. As a System minimum a prefix must contain at least 2 characters and start with a letter. It cannot start with “mscrm”. Recommendation is not to use more than 4 characters unless there is a compelling need to extend beyond that. The maximum is 8 alpha-numeric values. 

**Note**: the following is the publisher created by Microsoft with prefix (sw) acting as the default publisher for any customisations made for DCSYW:

![ms-publisher.png](./images/ms-publisher.png)


