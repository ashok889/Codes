# Customizations Register
This page provides a register of customizations that have been made to the Unify business applications platform and a record of approval.

| Name | Type | Description | Approval Date | Approved By |
|:-----|:-----|:------------|:--------------|:------------|
||Plugin||
||Javascript||


