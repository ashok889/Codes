<h1>Customisation Practices</h1>

In general, customisations are business functionality that requires a Code Editor to be used; it includes custom code (such JavaScripts, C# or .Net) to build plug-ins or custom workflow activities and also JavaScript or FetchXML reporting.

This document describes the standards which should be followed while customising Dynamics 365 (D365). These are a set of practices to help customising D365 to do so in a consistent, clear, and meaningful manner.

These practices are divided into four categories: 
- DO – This should always be followed except in very rare circumstances. 
- CONSIDER  – This should usually be the case, but there are well known exceptions. 
- AVOID – This should be rarely done, but again, there are cases where it is a good option. 
- DONT – There is almost never a reason to do this. Doing so may void any support options

The purpose of this document can be summarized as follows:
- Establish and agree on Coding standards
- Follow consistent approach in development

[[_TOC_]]

## Web Resources 
When writing and creating web resources, it is important to make sure use a consistent naming convention for the Web resources that reflect a virtual file structure of the project. The file structure convention should be similar to the above section “Folder Structure”. The solution publisher’s customization prefix will always be included as a prefix to the name of the Web resource. This can represent a virtual ”root” folder for all Web resources added by that publisher. You should then use the forward slash character (/) to simulate a folder structure that will be honoured by the Web server. Finally, From another Web resource, you should always use relative URLs to reference each other.
Writing useful display name and description should also be mandatory. The display name should represent the same name as the filename with spaces and capitalisation between all the words.
e.g.: To create an html web resource named as Content.html then the web resource name should look like this:

    new_/Content.html

If Content.html file is located inside Content folder then the web resource name should look like this:
    
    new_/Content/Content.html

Note that in the above cases the publisher “new” was already enforced in the naming so the only thing you need to type in was /Content…etc.

e.g.: For the Web page Web resource new_/Content/Content.html to reference the CSS Web resource new_/Styles/Styles.css, create the link (inside Content.html file) as follows:

    <link rel="stylesheet" type="text/css" href="../Styles/Styles.css" />
 
**General Notes**:
- Use extensions in webresources names, also create a “folder structure” using paths in the name to quickly identify the web resource you need.
- Use $Webresource: as a path and not the full url when creating ribbon/command buttons or actions.

    In naming resources remember that the display name that you give your resource will automatically create an attribute name and prefix it with your system prefix as well as an underscore. Using the above as a guide, if you add an image to the web resource your fields will look something like this: 

        Image Name: mypicture.jpg 
        Prefix: sw
        Web Resource Name: sw_/images/mypicture.jpg 
        Web Resource Display Name: /images/mypicture.jpg
 
- DO use the $webresource directive when referencing a web resource from a ribbon control or from a SiteMap sub area. Use the $webresource directive anywhere the XML allows a URL value. e.g.     $webresource:<name of Web Resource>
- CONSIDER  using a relative URL When referencing a web resource from areas that do not support using the $webresource: directive. From another web resource, you should always use relative URLs to reference each other. 

    For example, for the web page web resource new_/content/contentpage.htm to reference the CSS web resource new_/Styles/styles.css, create the link as follows:

        <link rel="stylesheet" type="text/css" href="../styles/styles.css" />
    For the web page web resource new_/content/contentpage.htm to open the webpage web resource isv_/foldername/dialogpage.htm, create the link as follows:

        <a href="../../isv_/foldername/dialogpage.htm">Dialog Page</a>
 
- DO NOT use a relative URL using the WebResources folder as the root path for the URL. For example, do not use this: /WebResources/<name of web resource>. When a user belongs to more than one organization on a server, this path will always refer to the users default organization. If the user is not using their default organization and the expected web resource is not included in the user’s default organization, a “File Not Found” error occurs even though the web resource does occur in the organization the user is currently working in.

- AVOID editing of web resources for managed solutions. Because of the capability for the HTML in web resources to be changed by using the text editor, it’s recommended that you use managed properties to set complex HTML web resources as not customizable for managed solutions. When viewing web resources in the solutions window, open the Managed Properties dialog box to set the Customizable property to false.

## Client Side JavaScript
Microsoft Dynamics 365 fires client side events to allow developers to extend certain functionalities using JavaScript. Having some implementation practice for JavaScript customisation helps in avoiding overlapping and redundancy of the code.

**JavaScript Events** 

Every Entity OnLoad should consist 3 of sections that should be separated by blank lines and an optional comment identifying each section. 

1. Create: CRMForm_Create_FormType
1. Update: CRMFrom_Update_FormType
1. Common: Code that needs to fired in both Create and Update.
	
Benefit: helps developer to insert their piece of code in the relevant section, will avoid clashing of 2 individual’s code, thus minimizes the effort of debugging in case of issues and also helps in maintain/support of the project.
	 

**JavaScript Comments**

A brief descriptive comments needs to be added for each block/piece of code written. 

Proposed convention:

    /*Author: XYZ, Date: 1/1/2011, Functionality: get the Current User role to hide the buttons */

Benefit: Helps other developers in understanding the necessity of that particular block of code and also helps performance tuning team.
	
**Considerations**
- Consider Use jQuery with HTML web resources. It is recommended to use jQuery together with HTML web resources to provide user interfaces because it is an excellent cross-browser library. With HTML web resources, you control the libraries that are present and there is no restriction against manipulating the DOM. Feel free to use jQuery within your HTML Web resources.

- AVOID using jQuery with form scripts or ribbon commands. It is not recommended to use jQuery in form scripts and ribbon commands. Most of the benefit provided by jQuery is that it allows for easy cross-browser manipulation of the DOM. This is explicitly unsupported within form scripts and ribbon commands. Restrict your scripts to use the Xrm.Page and Xrm.Utility libraries available in form scripts and ribbon commands. If you decide to use the remaining capabilities of jQuery that are useful with Microsoft Dynamics 365 and include the ability to use $.ajax, consider the following:
  - For best performance, don’t load jQuery in the page if you do not need it 
  - Using $.ajax to perform requests against the Microsoft Dynamics 365 web services is supported, but there are alternatives. The alternative to using $.ajax is to use the browsers XMLHttpRequest object directly. The jQuery $.ajax method is just a wrapper for this object. If you use the native XMLHttpRequest object directly, you do not need to load jQuery.
  - Each version of jQuery that is loaded in a page can be a different version. Different versions of jQuery have different behaviours and these can cause problems when multiple versions of jQuery are loaded on the same page. There is a technique to mitigate this, but it depends on editing the jQuery library and any other libraries that depend on jQuery. More information: [jQuery and jQuery UI with Dynamics CRM 2011 & 2013](https://community.dynamics.com/crm/b/develop1/archive/2013/08/08/jquery-and-jquery-ui-with-dynamics-crm-2011-amp-2013.aspx).

  - jQuery.noConflict(). Following Microsoft Dynamics CRM Online 2015 Update 1, form scripts run in a different scope than the jQuery instance used by the application. This means that there may not be an instance of jQuery available when your code attempts to use jQuery.noConflict. If you must use jQuery, you should first detect whether an instance of jQuery exists before you attempt to use jQuery.noConflict.

- Avoid including unnecessary JavaScript web resource libraries. The more scripts you add to the form, the more time it will take to download them. Usually scripts are cached in your browser after they are loaded the first time, but the performance the first time a form is viewed often creates a significant impression.

- Avoid loading all scripts in the Onload event. If you have code that only supports OnChange events for fields or the OnSave event, make sure to set the script library with the event handler for those events instead of the OnLoad event. This way loading those libraries can be deferred and increase performance when the form loads.

- CONSIDER  Using collapsed tabs to defer loading web resources. When web resources or IFRAMES are included in sections inside a collapsed tab, they will not be loaded if the tab is collapsed. They will be loaded when the tab is expanded. When the tab state changes, the TabStateChange event occurs. Any code that is required to support web resources or IFRAMEs within collapsed tabs can use event handlers for the TabStateChange event and reduce code that might otherwise have to occur in the OnLoad event.

- Avoid using form scripts in the OnLoad event that hide form elements. Instead, set the default visibility options for form elements that might be hidden to not be visible by default when the form loads. Then, use scripts in the OnLoad event to show those form elements you want to display. 

- DO group custom scripts related to an entity as opposed to global scripts, together in a single file or a series of related files and store them as a web resource. Once a web resource they can easily be added to a form to be used in OnLoad, OnSave, and OnChange methods. 

- CONSIDER  grouping common functions in a JavaScript library. When a function is reused in several forms, it is better to group this function in a common web resource that will be named according to its use (for example, CONTOSO.Common.js).

- CONSIDER  Defining a namespace for JavaScript web resources. Example:

        if (typeof CONTOSO == "undefined") {
             CONTOSO = { __namespace:true };
        }

- DO Verify the attribute before accessing it.

        if (typeof CONTOSO == "undefined") {
             CONTOSO = { __namespace:true };
        }

        CONTOSO.Common = {
            getValue: function () {
                var attribute = Xrm.Page.getAttribute('Contoso_something');
                if (attribute == null) {
                    throw new Error("This field Contoso_something is not defined on the form.");
                }
                return attribute.getValue();
            }
        };		 

- DO include functions that are of use across multiple entities in a project-wide common.js or global file and let the rest of your team know it is there. 

- DO all the assignments and initializations are to be done outside the looping constructs (FOR loop WHILE loop etc.) as much as possible. 

- DO include the columns participating in JavaScript as “dependency”. This will avoid removal of the attribute from the form. 

- DO always use Visual Studio as the editor tool. 

- DO preface variables that will hold jQuery objects with $. 

- CONSIDER  creating a global JavaScript file that can be used to hold functions that can be used across the application in many places. An example might be a phone number formatting function to make sure that phone numbers are consistently displayed across the application. This resource and function can then be added to any field that holds a phone number. 

- AVOID using the addOnChange method within the OnLoad event handler simply as a matter of convenience. While this may reduce the number of steps necessary to add your event handlers, it causes the form to load more slowly.

- AVOID including any JavaScript (other than the standard JavaScript import snippet) on a native form’s events. 

- AVOID using variables without explicitly declaring them. There are scenarios where a global variable may be necessary, but these are rare. 

- AVOID use of ActiveX controls because they have known security problems. 

- AVOID use JavaScript to perform complicated functions, use D365 plug-in instead. 

- DO NOT modify the DOM of D365 forms. Refrain from accessing or modifying the DOM elements of Dynamics D365 forms. Always use the XRM framework to access and work with Dynamics D365 in client side scripts. This is because the internal implementation of the DOM can change, and your code will need to be re-factored.

## PowerApps Component Framework
Microsoft has officially released the PowerApps Component Framework on April 2019. With this framework, developers can build custom controls and reuse them on Dynamics 365 forms, views and dashboards for an enhanced user experience for the users.

    Note: the framework is still in preview but available for public to use. Use caution when implementing custom controls using this framework.

For more information about the framework and how to create custom controls, visit this site here: [PowerApps component framework](https://docs.microsoft.com/en-us/powerapps/developer/component-framework/overview).

Since the framework is still in preview, we don't recommend using it for any production ready controls. However, the potential of this framework is great and should address lots of the UI limitations as well as provide better user experience where applicable.

In fact, all the existing out of the box controls in the existing Dynamics 365 unified interface were built using the PowerApps Component Framework. More content will be made available and more resources will be shared by the community as soon as the framework is out of the public preview.

## Server Side Plug-ins
Defining standards for Plug-ins is important, because Plug-in will be firing behind the scene and directly hits the database through service, collision of plug-in is a common in issue in any Microsoft Dynamic 365 Implementation, in order to track and manage the plug-in execution. Need to follow certain standard which helps in identifying and finding the root cause of a particular issue, especially in production where Visual studio and other development tools are not available.

Below are the set of Development Practices for Plug-in in for a successful Microsoft Dynamics 365 implementation.

**Plug-in Folder Structure** 

For any Microsoft Dynamics 365 implementation need to have a  proper folder structure for all the development we do, avoiding the mismatch and confusion about latest version of the code.

We recommend implementing each plugin in its own assembly (dll) and plugins should be named by functionality rather than by entity. For example, if we have a functionality to assign a case to a RIS by checking the report postcode, then the plugin to implement this functionality should have the name "AssignRISByPostCode" rather than the name "PostCaseCreate". The benefits to this approach are:
- Decoupling of functionalities and help to write code to only implement the required logic
- If there is any maintenance work required to the functionality, then only one assembly/plugin will be affected and usually only this plugin would need testing
- You can disable the plugin temporarily without disabling other business logic implemented by other plugins
- Easier to write Unit Tests that target specific functionalities.

With this approach, however, pay greater considerations to the execution order of plugins which you can control this via the plugin registration step.

The proposed plugin assembly structure is:

    <<Customer Name>>.<<Organisation/Project Name>>.Plugins.<<Function Name>>

For example: 
- Root folder customer name: CSYW 
- Plus project name: CSYW.Unity
- Plus plugin solution: CSYW.Unity.D365.Plugins
- Plus functionality name: CSYW.Unity.D365.Plugins.AssignRISByPostCode

**Plug-in Solution Structure**

Plug-in solution structure is for organising of the class libraries (Plugins dlls) for a Microsoft Dynamics 365 implementation. Differentiating the class files is important in Plug-in development. 
Few things to be kept in mind during Plug-in development:

1. Plugins for Dynamics 365 Online must be implemented in **Microsoft .NET Framework 4.6.2** or later.

1. CONSIDER Limiting the number of external dynamic link libraries (DLLs) that are referenced in a D365 plug-in. External DLLs that are referenced by D365 plug-ins should be limited to:
    - D365 SDK DLLs (use NuGet package: [Microsoft.CrmSdk.CoreAssemblies](https://www.nuget.org/packages/Microsoft.CrmSdk.CoreAssemblies/)).
    - .NET framework DLLs that are compatible with the isolation level of the plug-ins.
    - DLLs that are signed with a common technical basis and pre-deployed in the GAC with a standard isolation level. (Not applicable for D365 Online or if planning to eventually use D365 Online)

1. Implement the complex business logic outside the main execute method. The execute method should only be used to initialise the plugin context, service and main object and control the main flow.

1. Each class library should have a Handler file (preferably static) which will contain all methods used in development of plug-in for a particular functionality.
 
1. Strong name should be same as the name of the class library of the entity 
E.g.: if the class name is CSYW.Unity.D365.Plugins.AssignRISByPostCode, snk should also have the same name.
 
1. Optionally you can have One Common Assembly Handler to implement general static helper classes for common methods that are used in all plugins/events. Use the following naming convention when declaring this assembly:
    
        CSYW.Unity.D365.Common.dll

    All other plugins should not include the above assembly plugin directly, instead, should link to the classes within that implement the generic functiionality. Use the _Add as Link_ option when adding the common class to the current plugin project.
    ![Add-As-Link.png](./images/Add-As-Link.png)

 
**Plug-in class**

Every class should have the brief introduction about the functionality implemented and registration details (header comment).
This helps for other developer/consultants to debug and fix in case of issues.

Refer to [C#-Plugin-and-Custom-Workflow-Class](./Coding-Standards-Development-Practices-and-Naming-Conventions.md#C#-Plugin-and-Custom-Workflow-Class) for the structure of the header comment.

Implement the BasePlugin.cs approach by inheriting from a base class that handles all the context and service initialisation as well as message and event validation.
 

**Plug-in Image declaration** 

If the Plug-in is using any of the images (PreImage/PostImage), need to have a relevant naming convention will help developers/consultants in debugging and fixing issues related to Plug-in. Proposed convention:

    <<ImageType>>_Img_ + <<entity>>

Example:
        
    Pre_Img_Contact

**Considerations while implementing plugins**
- DO NOT reference external DLLs that are deployed on the file system from the D365 plug-in. This kind of referencing is not compatible with database deployment of D365 plug-ins. Having several external DLLs referenced in one plug-in is not compatible with either a sandboxed or an online solution. Consider hosting a DLL in external WebService (might be on Azure), expose required endpoints and should be consumed from plugin. 
	 
- CONSIDER  sharing of the source code among D365 plug-ins, to reuse common code among several plug-ins. This share mechanism is compatible with a database deployment of D365 plug-ins. If you have to reference items in another project, you should use the AddAsLink function to refer to those items in your plug-in. This allows you to not have to duplicate the items and makes it easier to maintain if there are required updates.

- CONSIDER  Implementing the IPlugin interface in a stateless way in a D365 plug-in. The Microsoft Dynamics 365 execution pipeline simultaneously carries out the same Microsoft Dynamics 365 plug-in instance on several concurrent threads for the occurrences of different events. Therefore, to avoid concurrent access to variables, member variables should be defined in the scopes of methods and never in the scope of their related parent class in the IPlugin interface implementation. If you use variables within a class, the code will no longer be thread-safe.

- CONSIDER  Using Secure and Unsecure configuration to pass parameters to the plugin. When registering the plugin, configuration parameters can be passed through the Plugin Registration Tool to the plugin’s constructor, and it can then be accessed only in read-only mode in the Execute method of the D365 plug-in.

- DO manage the exceptions properly during the execution of a D365 plug-in. Never let the user experience a runtime error. Always foresee such situations, and take appropriate action to either manage the situation programmatically or let the user know that an exception has occurred. Log the exception and the actions that can be taken to fix the problems.
To manage exceptions in D365 plug-ins properly:
  - Intercept execution exceptions in a D365 plug-in by using a try {…} catch(…) syntax.
  - Define a series of gradual interwoven catch () blocks to intercept exceptions from the most specific to the less specific.
  - Trace the exception condition in the D365 API trace manager.
  - Manage the exception condition specifically on a case-by-case basis.

- DO throw an InvalidPlugInExecutionException when exception condition cannot be caught. For custom workflow activities, this error will be shown in the workflow instance form. For plugins, this error will be shown directly to the user in a dialog.  It is a good practice to store exceptions with execution details (context, stack trace, etc.).  Various implementations are possible and the following list illustrates some topics to consider:
  - Save details in a custom entity in D365. This should be performed using an async Action to be outside of the executing transaction (which will be rolled back due to the exception thrown). While this option allows easy access to read the information for D365 administrators, it is not a usual practice for system administrators and monitoring tools.  A purge system should also be considered. Alternatively you can use ExecuteMultiple request to create a log entity and ensure that it doesn't participate in a transaction.
  - For on premises installation for plugins, exceptions could be stored in the Windows’ Event log which is a common storage location for system administrators and monitoring tools.  When plugins are running inside the Sandbox processing service, access to the event log isn’t allowed but calling a custom web service to delegate the operation is possible despite it adds dependencies in the overall architecture of the solution. It is important to clearly state which organization created an entry in the event log (especially for installations with multiple organizations and/or if the custom web service writes to a central event log).
  - In addition to storing the exception details on the servers, it should be considered to generate a unique identification number that can be shown to the end-user (in the message passed to InvalidPlugInExecutionException) that will also be saved in the exception details and in the D365 Trace log. This number would simplify research by the support them.
  - Changing D365’s Trace output level can be useful for debugging but can impact performance in a significant way, especially in production. One practice is to extend LocalPluginContext.Trace, that insert messages in the D365 TracingService, with a temporary collection (List<string>), that is specific to the plugin’s execution context and discarded once completed. When an exception occurs, the collection is appended to the exception log.
  - The strategy depends on the hosting location (especially for production servers), the level of details needed, who will need access to those details and how they can access it. More details can be found here: [Handle exceptions in your code (common exceptions and faults)](https://msdn.microsoft.com/en-us/library/gg327884(v=crm.6).aspx). 
  - Consider integrating Dynamics 365 with [Application Insights](https://azure.microsoft.com/en-us/services/application-insights/) on Azure to proactively detect issues through email and webhook alerts; easily diagnose exceptions and web app performance issues; perform root cause analysis with ad-hoc queries and full-text search; and, integrate with DevOps processes using Azure DevOps. This service can be integrated with web applications (hosted on Azure, other cloud services, or on-premises servers), including D365 in plug-ins, custom activities in workflows, and client side scripting (JavaScript on forms).

- DO maintain the original stack trace while rethrowing exceptions. Once an exception is thrown, part of the information it carries is the stack trace. The stack trace is a list of the method call hierarchy that starts with the method that throws the exception and ends with the method that catches the exception. If an exception is re-thrown by specifying the exception in the throw statement, the stack trace is restarted at the current method and the list of method calls between the original method that threw the exception and the current method is lost. To keep the original stack trace information with the exception, use the throw statement without specifying the exception.
		
    Bad example:
        
        catch (Exception ex)
        {
            //do something with Ex or remove the local declaration for the catch block
            throw ex;
        }

    Good example (would be better if not catching a general exception type):
        
        catch (Exception ex)
        {
            //do something with Ex or remove the local declaration for the catch block 
            throw;
        }

    Reference: [CA2200: Rethrow to preserve stack details](https://msdn.microsoft.com/query/dev12.query?appId=Dev12IDEF1&l=EN-US&k=k(CA2200);k(TargetFrameworkMoniker-.NETFramework,Version%3Dv4.0)&rd=true)
 
- AVOID use SharedVariables collection to share data among D365 plug-ins. The existing mechanism of data sharing among different D365 plugin instances based on the SharedVariables collection, produces tightly coupled Microsoft Dynamics 365 plug-ins that can damage the scalability of the solution. Use caution when using SharedVariables to pass information between plugins.

- CONSIDER implementing a base class for D365 plug-ins. Implementing a base class for D365 plug-ins enables the user to set common behaviours for them—for example:
  - Managing configuration settings that define the shared state of D365 plug-ins.
  - Managing execution exceptions within D365 plug-ins.
  - Validating the execution context of D365 plug-ins.
  - Validating the presence of a valid Target input parameters.

- CONSIDER using the Plugin Tracing Log. Use Plugin Tracing Service for debugging purposes. Under Select, System, Administration, System Settings (Customization), change the Enable logging to plug-in tracing log to the appropriate level for the current environment. See [Debug a plug-in](https://msdn.microsoft.com/en-us/library/gg328574.aspx) for details.

        ITracingService tracingService =  (ITracingService)serviceProvider.GetService(typeof(ITracingService));
        tracingService.Trace("Plugin Message " + context.MessageName.ToUpperInvariant());

- CONSIDER caching for reference values. For data that is often referred to but doesn’t change often (like configurations and reference data), consider using caching in plugins using ObjectCache in the System.Runtime.Caching namespace.
Example:

        /// <summary>
        /// Returns the string value for an Option key.
        /// </summary>
        /// <param name="xrmContext">D365 Context</param>
        /// <param name="key">Option Key</param>
        /// <returns>Option Value</returns>
        public static string RetrieveOption(XrmServiceContext xrmContext, string key)
        {
            const string NULLTOKEN = "__NULL_";
            ObjectCache cache = MemoryCache.Default;
            string option = cache[cachePrefixStringOption + key] as string;
            if (option == null)
            {
                if (xrmContext == null) throw new ArgumentNullException("xrmContext");
                option = xrmContext.mcs_optionSet.Where(o => o.mcs_key == key).Select(o => o.mcs_Value).FirstOrDefault();
                if (option == null) option = NULLTOKEN;
                cache.Add(cachePrefixStringOption + key, option, DateTime.Now.AddSeconds(30));
            }
            return option == NULLTOKEN ? null : option;
        }

- DO Verify the compliance of the input parameters of a D365 plug-in. A defensive programming strategy consists of verifying the compliance of input parameters of D365 plug-ins before you access them.

    Use the following principles to verify the conformity of input parameters in a D365 plug-in:
    - Confirm the existence of the request message property (which should be in the InputParameters collection) before you access it:
        - For example, the existence of the Target property for the CreateRequest request message class.
	    - The request message class properties are defined at the following location: https://msdn.microsoft.com/en-us/library/gg307406(v=crm.6)
    - Verify the compliance of the type of the Target property—for example:
	    - The Entity type for the Target property of the CreateRequest request message class.
	    - The EntityReference type for the Target property of the DeleteRequest request message class.
    - Verify the compliance of the logical name of the entity—for example:
	    - The Contoso_myEntity logical name.
    - Confirm the existence of the entity attribute before you access it—for example:
	    - The existence of the Contoso_myAttribute attribute on the Contoso_myEntity entity.
    - Confirm that the event that is raised is the one that you expected (Create / Update / Delete …).
		 
- DO Verify the compliance of the images of a D365 plug-in. A defensive programming strategy consists of verifying the compliance of the images of a D365 plug-in before you access them. Use the following principles to verify the compliance of the images of a D365 plug-in:

    - Confirm the existence of pre-processing or post-processing images in the respective PreEntityImages and PostEntityImages collections before you access them—for example:
      - The existence of the Contoso_myEntityPreImage property in the PreEntityImages collection.
    - Verify the compliance of the type of the image property—for example:
	  - The Entity type for the Contoso_myEntityPreImage property in the PreEntityImages collection.
		 
- DO Verify the compliance of the output parameters of a D365 plug-in. Use the following principles to verify the conformity of the output parameters of a D365 plug-in:
	
    - Confirm the existence of the response message property in the OutputParameters collection before you access it:
	   - For example, the existence of the id property of the CreateResponse response message class.
	   - The properties of the response message class are defined in the following location: https://msdn.microsoft.com/en-us/library/gg307406(v=crm.6)
 
- DO NOT access the output parameters of a D365 plug-in during the pre-processing stage. The collection of the output parameters of Microsoft Dynamics 365 plug-ins is filled by the D365 execution pipeline only during the post-processing stage.

- DO NOT update the output parameters of a D365 plug-in during the post-processing stage. The collection of the output parameters of D365 plug-ins is the result of the execution of the D365 process and should not be updated after the process.

- CONSIDER  restricting the attributes of pre-processing and post-processing images of a D365 plug-in. The D365 execution pipeline generates a SQL query during pre-processing and post-processing. This query returns the set of attributes that are specified on the images during the pre-processing and post-processing stages of D365 plug-ins. To prevent a lack of performance for those queries, the attributes of images should be restricted to only the ones that are required by business needs. Still, use images (pre or post) instead of retrieve calls where applicable. 

- CONSIDER  restricting the Filtering Attributes of a D365 plug-in. When registering D365 plug-ins, specify the Filtering Attributes in the step registration to limit the number of attributes in Dynamics 365 that trigger this plug-in. For example, when registering a plug-in that must run on the Update message for a Contact entity, specify the Filtering Attributes (for example Date of Birth) to restrict the triggering of the plug-in to only events when one of the Filtering Attributes is changed. Otherwise, any update to any attribute on the Contact would trigger the plug-in.

- AVOID the fetch of All Columns in your plug-ins. When fetching records in your D365 plug-in, specify which columns to retrieve. This becomes particularly important when you’re updating the records that are retrieved, to avoid triggering unnecessary update plug-ins registered for these entities. This is because every column retrieved in the fetch is updated during the update request, even when the value hasn’t actually changed.

- CONSIDER  limiting operations that cascade to related entities. When using the Update method or UpdateRequest message, avoid setting the OwnerId attribute on a record unless the owner has actually changed. When you set this attribute, the changes often cascade to related entities, which increases the time that is required for the update operation.

- AVOID registering plug-ins on frequently triggered messages. For example, avoid registering your plug-in on the Execute message. Since this message is triggered frequently in Dynamics 365, and your plug-in will run every time this message is triggered. This will have negative implications on the performance of the Dynamics 365 server.

- CONSIDER  defining a naming convention for pre-processing and post-processing images of a D365 plug-in. Applying a naming convention enables the user to standardize the handling of the images of a D365 plug-in—for example:
	- Name the pre-processing image for an entity named Contoso_myEntity as Contoso_myEntityPreImage
	- Name the post-processing image for an entity named Contoso_myEntity as Contoso_myEntityPostImage
 
- CONSIDER  using pre-processing and post-processing images for read-only access. The collection of pre-processing and post-processing images corresponds to the D365 entities in the database. Those images should be accessed by using read-access rights only, before and after the D365 transaction that triggered the execution of the plug-ins.
	 
- CONSIDER  the design constraints in the Sandbox isolation level. Some restrictions apply to plug-ins registered to run in Sandbox isolation mode and must be considered when these plug-ins are designed. For a complete list for these constraint, click [here](https://msdn.microsoft.com/en-us/library/gg334752(v=crm.6)). 
 
- CONSIDER  the Sandbox isolation level for execution of a D365 plug-in. The Sandbox isolation level for execution of D365 plug-ins provides the following assets in the operating environment:
  - D365 online plug-ins must run in Sandbox isolation mode
  - The D365 plug-in execution process is dedicated to a specific D365 organisation.
  - Statistics that relate to the execution of D365 plug-ins are generated automatically.
  - Execution that uses a service account is likely to have fewer access privileges than the one used in the D365 application pool.
 
- CONSIDER  the execution constraints that relate to the synchronous execution mode of a D365 plug-in. 
  - Consider the execution time that is required by D365 plug-ins in a synchronous execution mode, to define the response-time objectives for the user.
  - Optimize the response times of D365 plug-ins in a synchronous execution mode, to minimize their impact on the user response times.
  - Size the D365 platform to minimize the impact of response times that relates to the synchronous execution of D365 plug-ins on the user response times.
	 
- CONSIDER  using the synchronous execution mode for execution of a D365 plug-in.
The synchronous execution mode for D365 plug-ins provides the following assets in the operating environment:
  - It is possible to roll back the D365 operation in a transactional way that triggers the D365 plug-in.
  - Immediate feedback is provided to the user to inform the user of the status (success or failure) of the D365 operation launch.
	 
- CONSIDER  using the event pipeline pre-validation stage to apply the validation and enrichment business rules in the pre-processing stage in the input parameters of Microsoft Dynamics 365. Business rules that relate to input-parameter validation and enrichment can be (for example):
  - Confirmation that the input parameters belong to a specific list of data.
  - Calculation of some input parameters that are based on other input parameters, and pre-processing of available images.

- DO NOT use the event pipeline pre-operation stage to apply the business rules that relate to validation and enrichment of the input parameters of the Microsoft Dynamics 365 operation in the pre-processing stage. This pre-operation processing stage is completed in the Microsoft Dynamics 365 transaction that is triggered by the Microsoft Dynamics 365 operation before its execution; in terms of server resources, this is much more demanding than the pre-validation stage. Its use is limited to uncommon business rules, such as:
  - The automatic generation of a parent entity to which the child entity (that triggered the Microsoft Dynamics 365 operation) should be automatically associated.
	 
- CONSIDER  using the transactional post-operation processing stage to apply the business rules that relate to creation, update, or deletion of related D365 data in a transactional post-processing stage. This post-operation processing stage occurs in the transaction that is triggered by the D365 operation after its execution, and it enables the extension of the D365 operation in a transactional way by creating, updating, or deleting related D365 data.

    However, to prevent unwanted repetitive operations, a post-update should not refer to the record that triggered the operation.

## Custom Workflow Activity (Assembly)
Custom workflow activities can be treated same as per the plugins assembly rules above. Ensure you apply same concepts as they both share a similar implementation mechanism and follow .NET Framework. This section will only list any recommended practices not mentioned previously under the plugins section.

- CONSIDER Using the InvalidPluginExecutionException class to raise errors within specific activities. The InvalidPluginExecutionException error message will appear within the Microsoft Dynamics 365 workflow instance progress form (System Jobs) and will allow the user to identify why the workflow stopped.
- Create generic and reusable custom activities by using input and output parameters to set and retrieve values used within the logic of the workflow activity. 
- Ensure to group all custom workflow activities classes under the same friendly name in order for them to be grouped in the same list when consumed in the Workflow designer.

The proposed plugin assembly structure is:

    <<Customer Name>>.<<Organisation/Project Name>>.Workflows.<<Function Name>>

For example: 
- Root folder customer name: CSYW 
- Plus project name: CSYW.Unity
- Plus plugin solution: CSYW.Unity.D365.Workflows
- Plus functionality name: CSYW.Unity.D365.Workflows.RetrieveIfBusinessHoliday

## SSRS Reports 

Having Standard naming convention helps to differentiate between the Out of the box reports and the custom reports in D365 UI.  Need to have similar folder structure and Solution structure for Report Project. 
Folder structure for Plug-ins,

Need to have a folder by the Customer name

    <<Customer Name>>.<<Organisation/Project Name>>.Reports.<<Report Name>>

For example: 
- Root folder customer name: CSYW 
- Plus project name: CSYW.Unity
- Plus report solution: CSYW.Unity.D365.Reports
- Plus report name: CSYW.Unity.D365.Reports.CaseSummaryReport

## General Best Practices
	
### General
- Limit use of the offline client, try to use Excel instead.
- When using field level security, use teams for profiles (to decrease the administrative work).
- Use the developer toolkit when creating custom workflows and plugins.
- Have a look at the user’s personal options and change them when you feel it is needed (i.e. Disable automatically create contacts/leads for users in user profiles).
- Use Strict naming conventions (prefix, meaningful names, use comments when writing code), agree on these at the start of the project.
- When creating records through the SDK required fields are ignored.
- When creating contacts through the SDK, it is possible to re-use duplicate detections settings!
- Prefer use of early-binding (late binding is just slightly faster, but time is won back using the advantages of early-bound).
- Extra line of code is needed (.EnableProxyTypes) when connecting to the org web service using early bound.
- Advantage of using LINQ for creates: it supports transactions (note that there are some limitations with it as well).
- Plug-ins have no numeric min-max or varchar maxlenght validations – you have to code this manually.
- Clicking save will always fire the save JavaScript event, even if nothing is changed.
- Use the JavaScript shortcuts (Xrm.Page.GetControl / Xrm.Page.GetAttribute).
- Use variables for the form types in JavaScript (it’s a lot easier to read then the numbers).
- Use REST calls if you have to call web services from JavaScript.
- Use the new CRM 2011 JavaScript functions, the old CRM 4.0 functions will not support cross-browser functionalities.
- Limit #records per page in user personal options.
- Keep good eye on user personal options (there are options which have a bad impact on performance).
- When programming, limit columnset values on retrieve and update (will only update fields which are in the columnset).
- Use plug-ins over workflows (uses a lot less query’s in the event pipeline)

### Deployment
- Always use **Managed** solution for test and production instances. Use **Unmanaged** solutions for development instances. 
- Store solution zip files in source control (try to automate).
- Solution version number: use same design as CRM 5.0.X.X (5 for CRM 2011).
- Personal views cannot be exported by solutions.
- When exporting a disabled view + import again, the view is enabled again (strange behaviour and might be addressed in a future version of the platform).

### Use Connection Sharing
Connection sharing is safe when running an application as a single user—for example, if writing a program to do a bulk import for a custom entity. If the application will have multiple users, a separate application pool can be created for the program to run in, to increase the measure of safety when using connection sharing.

### Use Common Methods
The CrmService common methods are faster than using the CrmService.Execute method with the corresponding message. For example, use Create Method instead of using Create Message.
Use:
Guid accountid = crmservice.Create(accountobject)
Instead of:
createrequestobject.target = targetCreateAccountObject
CreateResponse response = crmservice.Execute(createrequestobject)

### Use Strong Types
The Dynamic Entity class is useful when code needs to work with entities and attributes not known when the code is written. However, this flexibility comes at a price of performance. If the entities are already defined at code time, then these strong types provided in the Web Service Description Language (WSDL) should be used instead of Microsoft Dynamics entities.

### Disable Plug-ins prior to importing large volume of data (migration)
When running an application that integrates bulk data or imports bulk data into the Microsoft Dynamics CRM system, enabling plug-ins significantly affects performance. Disable plug-ins if they are not necessary when importing bulk data into the system.

### Limit Data Retrieved
- When using the methods that retrieve data from the server, only retrieve the minimum amount of data needed by your application. This process is done by specifying the column set, which identifies the set of entity attributes to retrieve.
- When using the Retrieve method, use the columnSet parameter to specify the attributes you need.
- When using the RetrieveMultiple method, specify the attributes to retrieve in the query using the QueryBase.ColumnSet field.
- When using any message that uses a QueryExpression to specify the query criteria, use the QueryBase.ColumnSet property. 

### Limit Operations that Cascade to Related Entities
When using the Update method, do not set the ownerid attribute on an entity instance unless the owner has actually changed. Setting this attribute often requires changes to cascade to related entities, increasing the amount of time required for the update operation.
	
### Method Usage guidelines
When you declare a method, use the following sequence of the required elements:

    [public|protected|private] [static|abstract] returnType methodName ( paramlist)
 
The following rules outline the naming guidelines for methods: 
- Use verbs or verb phrases to name methods.
- Use Pascal case. 

The following are examples of correctly named methods:
- RemoveAll()
- GetCharArray()
- Invoke()

**Variables**

The following rules outline the naming guidelines for variables:
- Variables of general types are named logically. Variables of specialized types are named as the type (which should have a logical name).
- If you have more than one variable of the same specialized type, use logical naming for all. These logical names can be composed using the type name.
- One-character variable names should be avoided.

The following are examples of correctly-named variables:
- TargetCreateAccount targetAccount
- int iCount
- string emailMessage
- double currencyRate

The prefix of the variable can be removed if the name of the variable is still understandable.

**Classes**

The following rules outline the naming guidelines for Classes:
- Use a noun or noun phrase to name a class. 
- Use a Pascal case. 
- Use abbreviations sparingly. 
- Do not use a type prefix, such as C for class, on a class name. For example, use the class name FileStream rather than CFileStream. 
- Do not use the underscore character (_). 
- Occasionally, it is necessary to provide a class name that begins with the letter “i” even though the class is not an interface. This is appropriate as long as “i” is the first letter of an entire word that is a part of the class name. For example, the class name IdentityStore is appropriate. 
- Where appropriate, use a compound word to name a derived class. The second part of the derived class's name should be the name of the base class. For example, ApplicationException is an appropriate name for a class derived from a class named Exception, because ApplicationException is a kind of Exception. Use reasonable judgment in applying this rule. For example, Button is an appropriate name for a class derived from Control. Although a button is a kind of control, making Control a part of the class name would lengthen the name unnecessarily. 

The following are examples of correctly-named classes:
- public class FileStream
- public class Button
- public class String