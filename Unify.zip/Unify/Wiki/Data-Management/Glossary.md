The following is a glossary of terms used by the program, categorised into business and technology.

#### Business Glossary

| Business Term        | Description          | Dynamics 365 Equivalent  |
| -------------        |:-------------:       | -----:                   |
| Person               | An individual person that has interactions with the department. Could be one, or many of child, parent or professional      | Contact                  |
| Organisation         | An organisation that has interactions with the department. Could be a school, service provider, health provider or other government department.             | Account                  |
| Notifier             | A Person who is notifying the department of potential concerns regarding the safety of a child      |   |
| Subject Child | A Person who is the subject of a report or case.      |   |
| Alleged Perpetrator | A Person is alleged to be the perpetrator of harm or neglect against the subject child      |   |







The following public links provide additional definition of terms

[CSYW Child Safety Practice Manual](https://www.csyw.qld.gov.au/childsafety/child-safety-practice-manual/quicklinks/glossary-terms)

[CSYW Performance Glossary](https://www.csyw.qld.gov.au/child-family/our-performance/glossary-terms)