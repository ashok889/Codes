The Unify program applies the data quality principles described on this page.

[[_TOC_]]

The following are the key recommended practices related to data quality within the Unify program.
| Practice | Description |
|:---------|:-------------|
| Validate with external sources | Validate data with external sources where possible including addresses, organisation details and global standards for items such as countries. |
| Ensure all structured processes have consistent attribute values | Ensure that all business processes within Unify and structured data within the Enterprise Data Platform uses departmentally agreed values and categorisation for data. |
| Define data quality and management as an ongoing process | Define what data quality is for the department and then put in place measures, reports and dashboards to measure the results. Have individuals that are responsible for managing data quality. |


## Data Quality
Data Quality is being applied through the following methods.

###  Standardisation
Common attribute types are being standardised in there format and values across the Unify program. Standardisation is critical to being able to effectively operate and consistently report across applications and datasets. 

The following table lists the standardisations that are applied.
| Standardisation | Description |
|:-----------------|:-------------|
| Address | Addresses are standardised in format and also in location by utilising the xxx address validation services from the Unify application.|
| Restricted Values | Attributes with restricted values (ie Gender, Title) are enforced within the Unify application during data capture. |
| Reference Data | Reference data (ie Disabilities) is maintained with the Unify application, including any mapping to values used by other applications or external stakeholders. Reference data is then cached in the Enterprise Data Platform for use by integration, data migration, reporting and other applications. |

> Standardisation takes place before any data is stored within the Unify application or when it is made available from the Enterprise Data Platform through a structured method. Data from non-Unify sources, ICMS ODS and other applications/stakeholders, will often be stored in the Enterprise Data Platform in its raw format but will be standardised when made available through APIs and the Data Warehouse.

### Search and duplicate detection
Reducing duplicates is an essential aspect of an accurate, efficient and productive application. Person search is implemented to ensure that an existing person is identified in a high percentage of business processes and that duplicates are not common. The person search capability will operate against all person data within the enterprise data platform and not just Unify. Duplicate checking rules are also applied to give an extra validation when capturing details on a person for the first time.












