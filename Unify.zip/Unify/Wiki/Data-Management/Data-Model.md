The following describes the management practices employed, within the Unify program, for the management of the data model.

[[_TOC_]]

The following are the key recommended practices related to data model management within the Unify program.
| Practice | Description |
|:---------|:-------------|
| Produce a target state data model for the end of the program | With a multi-year program, there is the danger that data model decisions taken early in the program, without consideration of following requirements, will result in a less than optimal outcome. It is recommended that a high-level data model be agreed at the commencement of the program that takes into account all work products. |
| Centralise changes to the data model and reference data | Changes to both the data model and reference data have wide-ranging consequences and should, therefore, be managed through an architecture board.|
| Maintain a centralised logical data model | Maintain a centralised logical data model that has standard definitions for entities and attributes regardless of where they are implemented. This includes a glossary of terms used within the business.   


## Common Data Model
Microsoft has defined a Common Data Model (CDM) that has been implemented within the Dynamics 365 suite of products. This program will take this data model and extend it to support the business processes of Child Safety and Youth Justice. 

The Common Data Model is depicted below and more information can be found at the following links:
- [Common Data Model](https://docs.microsoft.com/en-us/common-data-model/)
- [Common Data Model on GitHub](https://github.com/Microsoft/CDM)
<br/>

![Common Data Model.png](../Data-Management/images/common-data-model.png)

## Reference Data 
Reference data will generally take the form of static values that rarely change, have a small number of values (less than 20) and are used across the application and department. Items that fit into this category include gender and title. 

Business domain-specific reference data has specific meaning within the organisation often has a broader range of values, and changes occur upon business need. Items that fit into this category include disabilities and health conditions.

Both types of reference data will be maintained within the Unify application and cached within the Enterprise Data Platform for use in reporting, integration and other business applications.


## Governance of the Data Model and Reference Data
Changes to either the data model or reference data can have wide-ranging consequences across the program and are therefore managed through a structured process. There is a central owner of these items with decisions to change either requiring approval on the Unify program architecture board.

The owner maintains the following artefacts:
1. A dictionary of all business data entities and attributes including data types, business name and business definition 
2. A record of each application where the business entity is implemented (ie Unify, ICMS, Data Platform)
3. A record of each business API where the business entity is implemented
4. A record of type of reference data that is maintained and used within the program

> Most of the above information could be obtained through automation from the various platforms that implement the elements 


