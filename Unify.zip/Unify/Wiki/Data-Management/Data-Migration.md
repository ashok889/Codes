<h1>Data Migration</h1>
The migration of data from existing applications, predominately ICMS, to Unify will be required throughout the duration of the program. 

The following table identifies the methods for making data available to the Unify application.
| Method | Description |
|:--------|:-------------|
| One-off migration | In this scenario, the data required will be migrated from the source application to Unify during the deployment window. The data will go through a process of extract to staging, transform and cleanse, load to target and then reconciliation. |
| Just-in-time migration |  In this scenario, the data required by Unify will be migrated as it is required through the use of an integration pattern. An example would be the creation of a Person record which has been identified as part of a Person Search. |
| Read-only access | In this scenario, read-only is required and therefore, the data is not stored in Unify but accessed when needed through an integration point. This could be also be used for historical information and needs to be accessible but never migrated and stored within Unify.

[[_TOC_]]

The following are the key recommended practices related to data migration within the Unify program.
| Practice | Description |
|:---------|:-------------|
| Start early | Start the process of defining the data migration needs, requirements and build early in each release. Incorporate data migration trials into the regular build process and test throughout the release. |
| Define a transparent approach to reconciliation | Define and precise approach to reconciling the data migration process and determining success. Automate the reconciliation process through dashboards and other automated methods to avoid subjective success criteria. |
| Cleanse data in source system | Cleanse and standardise data in the source application to make data migration, reconciliation and integration simpler.|

## One-off Migration
For data that needs to be migrated in a one-off process, during the deployment of the release, the following steps are applied:
1. Obtain a copy of the source application database in the Azure cloud either via an extract processor through the replication to an online data store (ODS).
2. Transform, translate and format the data for loading into Unify. This step includes any steps the cleanse the data, apply universal standardisation to format and value transformation using the reference data cache.
3. Load into Unify and reconcile the results in Unify to both the source application and the staging database.  

The technologies to be used in this process include:
- SQL Azure for the staging database
- SSIS / Data Factory for transformation and loading
- PowerBI for reconciliation dashboards

## Just-in-Time Migration
Just-In-Time migration is effectively utilising integration to migrate data into Unify at the point in time in which is first needed. The most likely scenarion, for the Unify program, is where a user performs a Person Search that idenifies an individual that is known outside of Unify. From the search results, the user could execute a function which would create the Person record, in Unify, from the data stored in the Enterprise Data Platform. 

## Read-only access
There are occasions where data is required for historical or read-only purposes, and in this case, the information doesn't necessarily need to be migrated. The Unify has several options for presenting read-only data without migrating and storing it in the Unify database.

The following table lists some of the options for presenting read-only data within Unify.

| Method | Description |
|:--------|:-------------|
| PowerApp Canvass application | Canvass applications can connect to over 200 different types of data sources, including those that will be provided by the Enterprise Data Platform, and then flexibly present the data. Canvass applications can be embedded within the Unify user interface. |
| PowerApps Control Framework | The PowerApps Control Framework can be used to create custom controls to visualise information, within Unify, from internal and external data sources. |
| PowerBI Dashboards | PowerBI dashboards can consolidate and present information with high-functionality which can then be embedded within the Unify user interface. |
| Virtual Entities | Virtual entities allow externally stored data to be accessible from the Unify entities, workflow and user interface components. |
