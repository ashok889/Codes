# Build & Release Management


## 1 Introduction
Azure DevOps is being used to automate the build and release processes for the Unify program. The objectives of the approach are to:
- Improve the predictability of deploying release through a consistent and automated process
- Improve the efficiency of the deployment processes
- Reduce the time taken to perform deployments

[[_TOC_]]

## 2 Environment Strategy
Further information can be found on the [Environment Strategy](./Build-And-Release-Management/Environment-Strategy.md) page.

## 3 Source Control
Further information can be found on the [Source Control](./Build-And-Release-Management/Source-Control.md) page.

## 4 Build Pipelines
Further information can be found on the [Build Pipelines](./Build-And-Release-Management/Build-Pipelines.md) page.

## 5 Release Pipelines
Further information can be found on the [Release Pipelines](./Build-And-Release-Management/Release-Pipelines.md) page.