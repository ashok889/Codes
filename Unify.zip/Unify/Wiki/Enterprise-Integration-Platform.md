# Enterprise Integration Overview

Integration is about sharing data, processes and communications across various systems to produce an orchestrated desired business outcome. Each system stores its data and logic within its building blocks and often systems needs to talk to other systems to complete certain processes or achieve a business outcome. There are various tools that allows systems to communicate and share data as well as some API and gateways acting as a data control layer. This section will describe the integration patterns, some delivery strategy, principles and standards.

[[_TOC_]]

Click [here](./Program-Architecture/Integration-Architecture.md) for a reference of the program's **Integration Architecture**.

---

## Key recommended practices
The following are the key recommended practices related to the Enterprise Integration Platform and the Integration Layer for DCSYW.

| Practice | Description | Link in Wiki |
|:---------|:------------|:-------------|
| **Use Business API**  | <ul><li>Validate incoming requests</li><li>Transforming incoming request (less desired and should be actioned in a transformation layer)</li><li>Execute business logic and communicate to Dynamics 365 via its APIs</li><li>Act as a single point of entry to Dynamics 365</li><li>Provide a central repository of the inbound integration business logics and their implementations</li><li>Performed and implemented by the application team.</li></ul> | [link](./Enterprise-Integration-Platform/Dynamics-365-Integration-Approach.md#Business-API-layer-for-Dynamics-365) |
| **Use Async and Reliable Communication** | <ul><li>Recommended to integrate Asynchronous Update with Message Queueing patterns to achieve asynchronous and reliable integration pipeline</li><li>Provide decoupling of applications</li><li>Better performance responses due to the sender will not need to await the receiver to process the logic</li><li>Usually used  when guaranteed message delivery is a key</li><li>provides reliability and high availability. If the receiver is not available to process the message, then the sender is not affected.</li></ul> | [link](./Enterprise-Integration-Platform/Integration-Patterns/Asynchronous-Update.md#Recommendations-and-Implemented-Practices) |
| **Use WebAPI D365 Endpoint**  | <ul><li>Web API will gradually replace Organization service and Organization Data service to become single web service for Dynamics 365 for Customer Engagement. Web API is the recommended choice for any new development for Dynamics 365</li><li>It is lightweight</li><li>Uses JSON and easier to work with than the SOAP based endpoint</li><li>No need for special Dynamics 365 libraries</li><li>Provides better compatibility across languages and platforms.</li><ul> | [link](./Enterprise-Integration-Platform/Dynamics-365-Integration-Approach.md#Web-API-(OData-v4))  |
| **Common Integration Design Issues** | <ul><li>Use the Business API for inbound integration with Dynamics 365. Aim to use Message Queueing (via plugin) or Data Extractions for outbound integration</li><li>Limit the exposure of internal Dynamics 365 schema or model externally. Business API should be aware of Dynamics 365 but not the rest of the integration platform</li><li>Do not process heavy transformation logic in Dynamics 365. Aim to create a transformation layer prior to loading data into Dynamics 365</li><li>Do not assume Dynamics has infinite storage and all data should reside there. Use the integration patterns (i.e. Synchronous Read) to help you determine the right approach to integrate and access such data</li><li>**Viewing all data in Dynamics 365 does not mean Storing all data in Dynamics 365.**</li></ul>  | [link](./Enterprise-Integration-Platform/Integration-Design-Issues.md)    |
| **Follow a Design Pattern** | <ul><li>Always aim to relate your design to one of the documented integration patterns for this project</li><li>Your design should specify which one or more of the patterns it uses.</li></ul> | [link](./Enterprise-Integration-Platform/Integration-Patterns.md)   |
| **Follow Systematic Integration Strategy** | Aim to centralise and isolate the Integration work into a dedicated integration team. This team is responsible for the enterprise integration layer for DCSYW. Here are some benefits:<ul><li>The team is highly skilled in integration technology, and has well established processes optimised for efficiency</li><li>The team is organised around an enterprise integration backlog. The backlog is prioritised by collaboration between business stakeholders and enterprise architecture</li><li>The team can predict when things will be done</li><li>gain economies of scale, and maintain control over IT architecture complexity</li></ul> |  [link](./Enterprise-Integration-Platform/Integration-Delivery-Strategy.md) |


Note that those set of recommended practices should be used as a guide and help when making design decisions. However, it is expected that those recommendations can change or would need to be modified as the platform evolves and the business requirements is made more available. Ensure to constantly update the recommendations and the content in this section when changes are needed.

---

## Why do we need to integrate with Dynamics 365
Often the business goes through the following process when deciding when and why to integrate:

![whyWeNeedToIntegrate.png](./Enterprise-Integration-Platform/images/whyWeNeedToIntegrate.png =600x380)

Ultimately, the business needs to challenge its processes and decision based on the following rule:

    Viewing all data in Dynamics 365 ≠ Storing all data in Dynamics 365

In another word, in order to view all data in Dynamics 365, it is not necessary that all data should be stored in Dynamics 365. 


## High Level Considerations
Although the easy decision is to host all data in Dynamics 365 in order to eliminate or minimise the need for integration with external systems, the following considerations should be discussed, analysed and based on the outcomes, a design should be created:

![overviewIntegrationConsiderations.png](./Enterprise-Integration-Platform/images/overviewIntegrationConsiderations.png  =470x350)

 Following and respecting the various integration designs, patterns, tools and methods mentioned in this section can address some of the above concerns and help to formulate a better integration design.
