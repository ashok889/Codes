<h1>Data Management</h1>
The Unify program applies the data management principles described on this page and the related subpages.

[[_TOC_]]

The following are the key recommended practices related to data management within the Unify program.
| Practice | Description |
|:---------|:-------------|
| Define the high-level data model early | Define the high-level data model, including the description of entities to be used by the business users, at the commencement of the program. Attributes and entities required for technical reasons can be designed as, but the core entities should be identified and designed early to ensure consistency with functionality to be implemented in the later stages of the program. |
| Centralise data model design | Central all data model design decisions within the program to ensure consistency. |
| Define a single owner of each set of data | Define a single application as the owner of a set of data. The set of data could by all attributes of a specific entity (i.e. Person), or it could be a subset of the attributes. If there are multiple owners, then the same business rules will need to be maintained in numerous applications and integration to synchronise changes will be involved and error-prone.

# Co-Existence
During the program the Child Safety and Youth Justice business processes will be supported by Unify and the existing ICMS application. During this period of co-existence, some of the data will need to exist in both applications to support the business processes and reporting needs.

To support co-existence, the following principles are applied by the program:
1. A set of data, a complete entity or subset of attributes, is defined as having a single owning application. The owning application is responsible for implementing all business rules for that entity as well as allocating a unique identifier where required.
2. Data that is required in a non-owning application can be copied from the owning application or accessed in real-time as the business and technical needs dictate. Any updates that are captured in the non-owning application must first pass the business rules in the owning application before being committed to the database.
3. As business functionality is migrated to Unify, significant amounts of data / transactions will need to be sent to ICMS to support following business processes and reporting concerns. the preference is to send data from the owning application to the other that require the data in an asynchronous manner to optimise end user performance.
4. New reporting requirements are to be satisfied in the Enterprise Data Platform where possible, utilising Unify and ICMS data in the ICMS ODS. 

> One of the first examples of the data ownership scenario is likely to be the Person record. In the initial stages of the program it is likely that the Person record will be owned by ICMS. Unify will be able to capture new Person details but will need to make a synchronous call to ICMS to validate the business rules and commit the update in ICMS. Only once ICMS commits the update will Unify also commit the update to it's database. In this scenario ICMS would be responsible for allocating a unique Person identifier that would be used in future transactions and also in the enterprise data platform to match Person records.

# Data Model
The data model that is being utilised for the Unify program is based upon the [Common Data Model] and has been extended to meet the needs of the Unify program and the department. The data model has been implemented within the Unify application, based upon Dynamics 365 Customer Engagement, and also within the Enterprise Data Platform.

For further information refer to the [Data Model] page.

# Data Quality
Data Quality is being applied through the following methods.

##  Standardisation
Common attribute types are being standardised in there format and values across the Unify program. Standardisation is critical to being able to effectively operate and consistently report across applications and datasets. 

The following table lists the standardisations that are applied.
| Standardisation | Description |
|:-----------------|:-------------|
| Address | Addresses are standardised in format and also in location by utilising the xxx address validation services from the Unify application.|
| Restricted Values | Attributes with restricted values (ie Gender, Title) are enforced within the Unify application during data capture. |
| Reference Data | Reference data (ie Disabilities) is maintained with the Unify application, including any mapping to values used by other applications or external stakeholders. Reference data is then cached in the Enterprise Data Platform for use by integration, data migration, reporting and other applications. |

> Standardisation takes place before any data is stored within the Unify application or when it is made available from the Enterprise Data Platform through a structured method. Data from non-Unify sources, ICMS ODS and other applications/stakeholders, will often be stored in the Enterprise Data Platform in its raw format but will be standardised when made available through APIs and the Data Warehouse.

## Search and duplicate detection
Reducing duplicates is an essential aspect of an accurate, efficient and productive application. Person search is implemented to ensure that an existing person is identified in a high percentage of business processes and that duplicates are not common. The person search capability will operate against all person data within the enterprise data platform and not just Unify. Duplicate checking rules are also applied to give an extra validation when capturing details on a person for the first time.

# Data Migration
The migration of data from existing applications, predominately ICMS, to Unify will be required throughout the duration of the program. 

The following table identifies the methods for making data available to the Unify application.
| Method | Description |
|:--------|:-------------|
| One-off migration | In this scenario, the data required will be migrated from the source application to Unify during the deployment window. The data will go through a process of extract to staging, transform and cleanse, load to target and then reconciliation. |
| Just-in-time migration |  In this scenario, the data required by Unify will be migrated as it is required through the use of an integration pattern. An example would be the creation of a Person record which has been identified as part of a Person Search. |
| Read-only access | In this scenario, read-only is required and therefore, the data is not stored in Unify but accessed when needed through an integration point. This could be also be used for historical information and needs to be accessible but never migrated and stored within Unify.
 











