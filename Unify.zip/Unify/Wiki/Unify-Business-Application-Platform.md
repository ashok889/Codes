# Unify Business Application

The Unify platform, based upon Dynamics 365 Customer Engagement, will become the main application that supports the business process needs of Child Safety and Youth Justice. 

[[_TOC_]]

## 1 Introduction
---
The Unify business application platform will be built on Dynamics 365 Customer Engagement and related products and services. The business application will support the Child Safety and Youth Justice business processes and be used by departmental staff and contractors. External stakeholder will also be able to utilise the platform through externall facing portals and message based integration.

### 2 Unify Business Application Platform Components
---
The following sections describe some of the key components and capabilities of the platform and recommendations on practices to follow.

#### 2.1 Dynamics 365 Customer Engagement applications
Dynamics 365 Customer Engagement is made up of a number of applications that are based upon the Common Data Service. The following applications are installed in the Unify instances of Dynamics 365 Customer Engagement:
- Service
- Sales
- Field Service

![Dynamics365.png](./program-architecture/images/dynamics365.png)

#### 2.2 Configuration and customization practices
Dynamics 365 Customer Engagement is a flexible business application platform that can have it's behavior modified to suit the business processes of the department. The following table provides recommendations on the approach to configuration and customization.

| Name | Description | Recommendation |
|:-----|:------------|:---------------|
| Configuration | This involves using the Dynamics 365 solution configuration user interface to change the entities, attributes, form, view and workflows to meet the business needs. | This is the preferred approach to meeting the business requirements |
| Customization through plugins | This involves developing C# code that executes server-side logic | This is the preferred method of implementing business logic when configuration (workflows & business rules) can't meet the requirement |
| Customization through Javascript | This involves developing Javascript that executes in the browser | This is the least preferred method of implementing business logic as it will not be applied through integration and also tends to be a significant cause of bugs and poor performance on projects |

It is recommended that the project has a formal review and approval process for customization's and that these approvals are kept in a register.


#### 2.3 Solutions

Solutions, in Dynamics 365 Customer Engagement, are used to group together configurations and customization for migration to other instance. The following solutions will be used to group and package changes within the program.

| Solution Name | Description |
|:--------------|:------------|
| CSYW Common   | This solution will contain any configuration or customization that is performed for the department that could be shared across projects without modification. An example would be address validation. |
| Unify         | This solution will contain any configuration and customization that is performed to support the Child Safety and Youth Justice business processes |


When working with solutions the following practices are to be followed.

| Practice | Description |
|:---------|:------------|
| Unmanaged only in development | Unmanaged solutions are to be used only in development environments for performing configuration and customization activities. Managed solutions will be created by Azure DevOps build processes and then migrated to non-development environments through Azure DevOps pipelines |
| Add only changed elements to solutions | Do **NOT** use the "Add all assets" option when adding entities to a solution. Only add those elements of an entity that have changed to the solution and therefore keep the changes small.
| Build from source | Solution packages are to be built using Azure DevOps from source control (Git) which will also include compiling plugins from the source code. Source control (Git) is the record of truth for configuration and customization. |
| Uses Patching | Use the patching capabilities of solutions for each release to keep the solution files small, quicker to import and apply as well as making it easier to identify what has changed in each release. |

Further information on Dynamics 365 Customer Engagement solutions can be found at 
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/introduction-solutions

#### 2.4 Unified Client

#### 2.5 Business Process Flows

Further information on Business Process Flows can be found at 
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/business-process-flows-overview

#### 2.6 Reporting and Business Intelligence

Dynamics 365 for Customer Engagement apps includes reports, dashboards, and support for Power BI for Office 365 that provides useful business information and visualizations to the user.

The following table provide recommendations for the various reporting options with the program.

| Report Type | Description | Practice |
|:------------|:------------|:---------|
| Paginated reports | These reports can be created using a report wizard and execute against live data in the Dynamics 365 database. These reports are useful for operational reporting on relatively small datasets. It is recommended to limit the number of reports produced using this method | 
| Dashboards |  | |
| PowerBI |  |  |

Further information on Dynamics 365 reporting can be found at 
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/analytics/reporting-analytics-with-dynamics-365


#### 2.7 Reference Data



#### 2.8 Search
To meet the needs of the business to be able to search for a person in a flexible way and across the organization a customized search capability will be implemented. This person search functionality is described further in the Data Platform section on the [Person Search](../Data-Platform/Person-Search.md) page.


#### 2.9 Client History
To meet the needs of the business to be able to view a client history that spans all information related to that person a consolidated person / client history will be implemented. This client history functionality is described further in the Data Platform section on the [Client History](../Data-Platform/Client -History.md) page.

#### 2.10 Data Quality

Refer to the Data Management section.

#### 2.11 Co-existence

Refer to the Data Management section.

#### 2.12 Application Security

The security roles that are implemented are described in the Dynamics 365 Customer Engagement section on the [Security Roles](../Dynamics365-Customer-Engagement/Security-Roles.md) page.

Further information on security roles can be found at 
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/admin/security-roles-privileges

#### 2.13 Dynamics 365 Portals

<span style="color:blue">Requires further updating</span>
Dynamics 365 Portals provides the ability to extend the business processes that are configured with Dynamics  

Further information on Dynamics 365 Customer Engagement Portals can be found at 
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/portals/administer-manage-portal-dynamics-365

#### 2.14 Admin

<span style="color:blue">Requires further updating</span>
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/admin/admin-guide

## Software List

The software products & services listed in the following table will make up the Unify business application platform

| Name   | Description |
|:--------|:-----------|
| Dynamics 365 Customer Engagement | Microsoft cloud based application that will implement the majority of business processes for Child Safety and Youth Justice |
| Azure Functions | Microsoft cloud service that allows a Business API to be produced to expose Dynamics 365 functionality and data to other applications while abstracting complex business logic |
| Azure Logic Apps | Microsoft cloud service that allows a Business API to be produced to expose Dynamics 365 functionality where limited business logic is required |
| Microsoft PowerApps | Microsoft PowerApps is a low code tool that allows another alternative for the creation of user interface components. PowerApps will be utilised to fulfill specific user interface requirements that are then embedded within the standard Dynamics 365 user interface |
| Microsoft Flow | Microsoft Flow is a business process automation and workflow tools that will be used within Dynamics 365 and across applications where required |