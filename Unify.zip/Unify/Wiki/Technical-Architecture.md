<h1>Technical Architecture</h1>

This page gives a high-level overview of the implementation of the technical architecture within Azure. 


[[_TOC_]]


## 1 Hub and Spoke Architecture
The department has implemented a Hub and Spoke topology where the enterprise level and shared resources are implemented within the hub virtual network and each application is implemented in a spoke.

![Hub and Spoke Topology](./Program-Architecture/images/hub-and-spoke-architecture.png)

## 2 IT Assets
The program is establishing three IT assets that have their own isolation boundaries, Azure configuration and potentially different release cycles. The assets are:
1. Unify - is the core business process application and is based upon Dynamics 365 Customer Engagement and several Azure service that expose business API endpoints.
2. Enterprise Integration Platform that is responsible for all orchestrating all integration
3. Enterprise Data Platform that is consolidating information for analytical reporting, consolidated services and AI / MAchine Learning purposes





