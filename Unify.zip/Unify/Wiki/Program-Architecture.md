# Program Architecture Overview
---

## 1 Introduction
The program architecture describes the components that will comprise the overall solution for Child Safety and Youth Justice that will be delivered over the coming years.

[[_TOC_]]

## 2 Program Design Criteria, Themes and Principles

### 2.1 Service Model Themes
The following Service Model Themes are to be considered during the program.
<br/>
![Unify-Service-Model-Themes.png](./program-architecture/images/unify-service-model-themes.png)


### 2.2 Design Criteria
The following design criteria will be applied throughout the program.
<br/>
![Design Criteria](./program-architecture/images/unify-design-criteria.png)


### 2.2 Architecture Principles
The following principals apply to the program architecture:
1. Leverage the capabilities of the selected business applications and technology platforms to meet the business needs, themes and design criteria
2. Apply a Configure-First approach where customisation is minimised to improve outcomes for children, efficiency, flexibility and responsiveness to business change
3. Improve application and process efficiency through automation and user interface design
4. Improve business decision making by providing the appropriate information and insights at the appropriate point within the business process
5. Master data, and associated business rules implementation, in a single application

## 2.3 Application Architecture Capability View
The following diagram identifies the stakeholders and business capabilities required as aprt of the program.
<br/>
![Solution-Architecture-Capability-View.png](./program-architecture/images/unify-capability-view.png)

### 2.3.1 Consumers

The business capabilities to be deployed will be used by a number if consumers, including:

**Staff** - of the department that will utilise the capabilities to fulfil the business processes of Child Safety and Youth Justice

**Citizens** - within the Queensland community who may be children, families, alleged perpetrators or other individuals involved with the families effected

**Service Providers** - which includes the individuals that are employed and participate in service delivery functions related to Child Safety and Youth Justice

**External Parties** - such as staff members at other government and non-government organizations that interact with CSYW within the area's of Child Safety and Youth Justice

### 2.3.2 Business Facing IT Capabilities

The IT capabilities can be grouped into the following categories.

**External Channels** - such as portals, mobile applications and message based interactions that enable external parties to effectively and efficiently interact with the department. There are expected to multiple of each of these capabilities to support different end users and scenarios.

**Line of Business Applications** - these are the core business applications which enable the CSYW business processes, within Child Safety and Youth Justice, to be supported in an effective and efficient way. The main business application, in the final target state, will be based upon Dynamics 365 Customer Engagement. The functionality within the current ICMS application will be progressively migrated to Dynamics 365 Customer Engagement. There are a number of existing applications, in addition to ICMS, some of which will remain and some will be retired once the functionality to available within Unify.

> Each line of business application will be designed and developed in a way that it is loosely coupled to other capabilities where possible. This will include any integration points being documented and published through API Management. The integration points will also be tested to ensure that other applications can have confidence in integrating based upon the published documenting. Exceptions to this are where out-of-the-box integration, to other commercial products, form a core part of the applications. These exceptions include authentication against Azure Active Directory and integration between Dynamics 365 Customer Engagement and Office 365. 

**Data Platform & Business Intelligence** - will central information from within the department and also available external data sources into a common data lake. The platform will then provide the business capabilities for search, AI / Machine Learning, consolidated client history, audit, data warehouse and analytical reporting.

**Business Productivity** - will provide common capabilities across the department for email, calendar and collaboration. Business productivity capabilities will be provided by the Office 365 suite of products and be integrated to the other capabilities using primarily out-of-the-box integrations.

## 3 Application Architecture
The following diagram depicts the significant components of the Unify application architecture.
![Unify-Application-Architecture.png](./program-architecture/images/unify-application-architecture.png)

The application architecture is described in more detail at [Application Architecture](./Program-Architecture/Application-Architecture)

## 3 Data Architecture
The data architecture describes the design of the data platform and also the methods in which data will be managed as aprt of the program. <br/>

The integration architecture is described in detail at [Data Architecture](./Program-Architecture/Data-Architecture)

## 3 Technical Architecture
The technical architecture describes the design of the Azure components to be deployed as aprt of the program and how they interact with on-premise and external applications and stakeholders.<br/>

The integration architecture is described in detail at [Technical Architecture](./Program-Architecture/Technical-Architecture)

## 3 Integration Architecture
The integration architecture describes the methods of moving data between the components of the application architecture in a controlled manner.<br/>

The integration architecture is described in detail at [Integration Architecture](./Program-Architecture/Integration-Architecture)