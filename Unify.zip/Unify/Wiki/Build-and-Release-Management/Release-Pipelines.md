# Release Pipelines

## 1 Introduction
Azure DevOps is utilised to manage the build, automated test and release processes for Unify, Enterprise Data Platform and Enterprise Integration Platform. All build and release activities after the Development environment are automated where possible. 

[[_TOC_]]


## 2 Release Pipelines

### 2.1 Unify Release Pipelines
The Unify application has two release pipelines defined, being:
1. Unify-Development-Release pipeline which takes the build artefact and manages the deployment through the environments which support the solution modelling and build phases.
2. Unify-Production-Release pipeline which takes the build artefact and manages the deployment through the environments which support the solution testing and deployment phases.

Each Unify release pipelines deploys both Dynamics 365 solutions and the associated Azure components. All environments including Production will also have tasks to execute automated test suites.

![Unify-Development-Release-Pipeline.png](./images/unify-development-release-pipeline.png)

### 2.2 Enterprise Data Platform Release Pipeline
__These release pipelines will be defined at the commencement of the program.__

### 2.3 Enterprise Integration Platform Release Pipeline
__These release pipelines will be defined at the commencement of the program.__