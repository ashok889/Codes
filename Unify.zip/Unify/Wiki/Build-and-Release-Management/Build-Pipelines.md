# Build Pipelines
----

## 1 Introduction
Azure DevOps is utilised to manage the build, automated test and release processes for Unify, Enterprise Data Platform and Enterprise Integration Platform. All build and release activities after the Development environment are automated where possible. 

[[_TOC_]]


## 2 Unify Build Pipelines
The following table and diagram describe and show the tasks that are included in the Unify build pipeline.

| Task | Description |
|:-----|:------------|
| MSCRM Tool Installer | Installs the tolls required for the subsequent tasks. |
| Build Plugins | Performs a Visual Studio build of the Dynamics 365 plugins from the source code stored in the Git repository |
| MSCRM Pack Solution | Creates a Dynamics 365 Unmanaged solution from the source code in the Git repository |
| MSCRM Import Solution | Imports the Dynamics 365 Unmanaged solution, from the previous step, into the Build environment |
| MSCRM Publish Customizations | Publishes the customizations in the Build environment |
| MSCRM Export Solution | Exports the Dynamics 365 solution from the build environment as Managed |
| Azure Deployment | Deploys the Azure components based upon an ARM template that is stored in the Git repository |
| Build Azure Functions | Builds the Azure Functions from code within the Git repository |
| Azure Function App Deploy | Deploy the Azure Functions that have been built in the previous task |
| Run Automated Tests | Execute the automated test suite |
| Publish Artefact | Publishes / stores the build artefacts to be used in the release pipelines |


![Unify-Build-Pipeline.png](./images/unify-build-pipeline.png)

## 3 Enterprise Data Platform Build Pipelines

## 4 Enterprise Integration Platform Build Pipelines