# Source Control

# 1 Introduction
This page describes how project artefacts are stored and managed in Azure DevOps.

[[_TOC_]]

# 2 Source Control Tools
All project configuration, code, automated test suites and the majority of project documentation is stored in a Git repository within the relevant DevOps project.


# 3 Branching Strategy
## 3.1 Trunk Branching Strategy
The program uses a trunk based branching strategy as practised by the Microsoft and described at the links below.

![ReleaseFlow-Branching-Strategy.png](./images/branchstrategy-releaseflow.png)

Under this branching strategy all changes to configuration, code and documentation will be committed using the following steps:
1. Create a topic branch, from master, per DevOps Task
2. Make the relevant changes in the topic branch
3. Once complete, and tested, raise a pull request to merge the changes into master
4. Reviewers enter comments and approve once quality and completeness have been validated 
5. Complete the pull request, merge into master, close the task and delete the topic branch

Once the in-scope user stories have been completed and tested then a release branch is created from master and used to perform "Solution Testing" before deploying to production.

Further information on trunk based branching strategy can be found at:
- https://trunkbaseddevelopment.com/
- https://devblogs.microsoft.com/devops/release-flow-how-we-do-branching-on-the-vsts-team/
- https://docs.microsoft.com/en-us/azure/devops/learn/devops-at-microsoft/release-flow

## 3.1 Branch Policies
There will be one Git repository for the Unify application with the following folder structure.

![Git-Folder-Structure.png](./images/git-folder-structure.png)

| Folder | Description |
|:-------|:------------|
| DataMigration | Code, configuration and automated tests for the data migration process |
| Dynamics365 | Dynamics 365 solutions (unpacked), Visual Studio solutions for Plugins and Javascript, Automated tests |
| Integration | Visual Studio solutions for the integration components |
| Azure | Azure configuration (ARM templates) for the integration and other components |
| Powershell | Powershell scripts for the project and support teams || Wiki | The markdown files that make up the project Wiki |

**Master branch policy**

For the master branch the policy is set as per the image below and includes:
1. A minimum of 1 reviewer for each pull request into master. It should be considered to increase the number of reviewer once the project team increases.
2. Require a work item to be linked to each pull request. The linked work item should be a "Task" and be enforced through process.

![Branch-Policy.png](./images/Branch-Policy.png)