# Environment Strategy

## 1 Introduction
The environment strategy defines the logical environments that will be maintained by the program for each IT asset to support the methodology and approach. Each of the environments are intended to support a specific phases and the associated activities. Each logical environment will consist of multiple technologies and services that together support the business needs.


![Environment-Strategy.png](./images/environment-strategy.png)

## 2 Environments

### 2.1 Development Environments
There will be a set of the following environments for each parallel stream of Dynamics 365 development. It is recommended to keep the environment simple and only have one stream at a time.

| Name | Purpose | URL | Security Group |
|:-----------|:-----------|:-----------|:------|
| Dev01 - DevXX | Environment dedicated to a Dynamics 365 functional analyst / developer for the purpose of producing new functionality, enhancements of support fixes. | https://unify-dev01.crm6.dynamics.com | Unify-Developers | 
| Build | Build environment that is dedicated to the DevOps build process that produces a managed solution artefact that will be used in the release pipelines. | https://unify-build.crm6.dynamics.com | Unify-Developers |
| Development | First environment where all configuration and customization changes are consolidated from each of the various analysts and developers. The managed solution, from the build process, is imported into this environment by a release pipeline. | https://unify-dev.crm6.dynamics.com | Unify-Development |
| Solution Modelling | Stable environment that is used to conduct the solution modelling workshops and showcase the application capability to business representatives. This is also the environment where Iteration testing is executed. | https://unify-solmodelling.crm6.dynamics.com | Unify-Solution-Modelling |

### 2.2 Support Environments


### 2.3 Release and Production Environments
There are one set of the following environments to be used once a release is scheduled for deployment to production. The environments will support the Solution Testing phase through to production use.

| Name | Purpose | URL | Security Group |
|:-----------|:-----------|:-----------|:------|  
| Solution Testing | Environment dedicated to the feature (process) testing and end-to-end testing that occurs within the Solution Testing phase of SureStep 365. | https://unify-soltest.crm6.dynamics.com | Unify-solution-testing |
| UAT | Environment that is to be used for users to perform the final acceptance testing prior to signoff and deployment into production. This environment can also be used for performance testing if required. | https://unify-uat.crm6.dynamics.com | Unify-UAT |  
| Staging | Environment that is used to test and validate the deployment into production. Where possible the environment should mirror production as close as possible. | https://unify-staging.crm6.dynamics.com | Unify-Production |  
| Production | This is the production environment that is accessed by end users to support the execution of business processes. | https://unify.crm6.dynamics.com | Unify-Production |