<h1>Approved Azure Services</h1>

The following table lists the approved Azure services to be used on the Unify program.


| Azure Service | Acronym |
|:--------------|:--------|
| Storage Account | sa |
| Application Service Plan | asp |
| Function App | fa |
| Application Insights | ai |
| Logic Apps | la |
| Service Bus | sb |
| Event Grid | evg |
| SQL Azure | sql |
| Data Lake | dl |
| API Management | apm |
| Resource Group | rg | 
| Key Vault | key |

