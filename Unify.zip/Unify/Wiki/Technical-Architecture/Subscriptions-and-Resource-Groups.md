<h1>Subscriptions and Resource Groups</h1>



[[_TOC_]]


## 1 Hub and Spoke Architecture
The department has implemented a Hub and Spoke architecture using the pattern described at https://docs.microsoft.com/en-us/azure/architecture/reference-architectures/hybrid-networking/hub-spoke

The Unify program will be responsible for deploying Azure resource groups and services for the Spoke components to enable integration and data platform capabilities. The departments enterprise and operations teams are deploying the Hub components and determining enterprise wide policies regarding approved services, tags, role based access control, cost control and network security.

## 2 Subscriptions
The following Azure subscriptions have beed created to support the program.
| Subscription | Description |: URL |
|:-------------|:------------|:-----|
| Development - Unify | This subscription support the Unify project teams in there development activities. | https://portal.azure.com/#@communitiesqld.onmicrosoft.com/resource/subscriptions/cc9dbf9a-92bd-4790-964c-cac26f9d0160/overview |
| Development - Integration | This subscription supports the enterprise integration platform  project team in their development activities. | https://portal.azure.com/#@communitiesqld.onmicrosoft.com/resource/subscriptions/3dcb7a59-3946-41cf-9271-2f60e5707fbc/overview |
| Development - Data Platform | This subscription supports the enterprise data platform | |
| Test | This subscription contains the Azure components for all IT Assets in a shared subscription | https://portal.azure.com/#@communitiesqld.onmicrosoft.com/resource/subscriptions/affee8ee-25b9-44c0-a026-aa0f8899a7c5/overview |
| Production | This subscription contains the Azure components of all staging and production IT Assets in a shared subscription. | |

Each Development subscription:
1. Has spend controls applied
2. Is managed by project team members who create and modify Azure components for the purposes of development and unit testing
3. Has it's desired Azure component configuration applied to an ARM template within Git which then is used in Azure DevOps build & release pipelines
4. Has a resource group per IT Asset (ie unify-dev-rg) that is controlled and should only be managed through Azure DevOps build and release pipelines.
5. Has policies applied that require tags for cost centre, ensure on Australian based regions are used and only whitelist Azure services are deployed

The Test and Production subscriptions are to only have services provisioned through the Azure DevOps build and release pipelines. Selected project teams members will have read-only access to enable troubleshooting and support. The policies from the Development subscriptions will also be applied to these subscriptions and there will be **no** spend limits applied.

> Developers are to use their individual MSDN subscriptions for research and development purposes. Once they have sufficient knowledge and business justification they will apply for a new Azure service to be added to the whitelist through the Architecture Review Board. Once approved the new Azure service will be added to the relevant Azure policies.

## 3 Resource Groups
Each subscription will contain multiple resource groups that will follow the following naming conventions.

__application-environment-service__

where:
- __application__ is one of unify, eip (enterprise integration platform) or edp (enterprise data platform)
- __environment__ is one of dev, solm, soltest, uat, staging or production
- __service__ indicates the Azure service based upon the naming standards in the table below.

Each of the Azure services listed in the following table are on the whitelist.
| Name | Azure Service |
|:-----|:--------------|
| rg | Resource group |
| sa | Storage account |
| ai | Application insights |
| fa | Function application |
| sql | SQL Azure |
| dl | Data Lake |
| apm | API Management |

Within the program the following IT Assets are being established and are considered as separate applications with isolation boundaries that are only crossed in well defined ways. The IT Assets are:
1. Unify - which consists of Dynamics 365 Customer Engagement and Azure resources that expose integration points to other applications.
2. Enterprise Integration Platform - which consists of the Azure components to support integration between Unify and the other internal and external applications.
3. Enterprise Data Platform - which consists of the Azure components to support the data needs of the program.

### 3.1 Unify Resource Groups

The Unify resources groups are unify-dev-rg, unify-solm-rg, unify-soltest-rg, unify-uat-rg, unify-staging-rg and unify-prod-rg

The Azure service that are provisioned each resource group are:
1. Storage account
2. Application Service Plan
3. Function App
4. Application Insights


### 3.2 Enterprise Integration Platform Resource Groups
The Enterprise Integration Platform resources groups are eip-dev-rg, eip-solm-rg, eip-soltest-rg, eip-uat-rg, eip-staging-rg and eip-prod-rg

The Azure service that are provisioned each resource group are:
1. Storage account
2. Application Service Plan
3. Function App
4. Application Insights
5. Logic Apps
6. Service Bus

### 3.3 Enterprise Data Platform Resource Groups
The Enterprise Data Platform resources groups are edp-dev-rg, edp-solm-rg, edp-soltest-rg, edp-uat-rg, edp-staging-rg and edp-prod-rg

The Azure service that are provisioned each resource group are:
1. Storage account
2. Application Insights
3. Data Lake
4. SQL Azure
5. Data Factory
6. SQL Data Warehouse
7. CosmosDB (TBC)