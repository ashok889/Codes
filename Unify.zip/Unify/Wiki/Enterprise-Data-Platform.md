The Enterprise Data Platform initially provides the data consolidation, analytical reporting and AI / Machine Learning for the Unify program. In time the platform will be extended to offer similar capabilities to other parts of the department. 

The Enterprise Data Platform is built on Microsoft Azure services and is developed and released as a loosely coupled component of the overall Unify architecture based upon its own release schedules and priorities. The architecture of the Enterprise Data Platform is based upon the  "Advanced analytics on big data" architecture.

[[_TOC_]]

The following are the key recommended practices related to the Enterprise Data Platform.
| Practice | Description |
|:---------|:-------------|
| Loosely couple the data platform | Organise the team and the implementation of the enterprise data platform as a loosely coupled IT asset within Unify. Allow production deployments to be scheduled independently of Unify and other applications with well defined and testable integration points. |
| Reduce on-premise traffic | Reduce the number of real-time requests for information to the on-premise data sources and infrastructure. Achieve this by implementing cache capabilities and read-only stores within the Enterprise Data Platform based upon Azure. |
| Store and secure data in its raw format | Store and secure data in the Enterprise Data Platform in its raw format and then provide more structured access once business needs and value are clearly established. |
| Automate build and release tasks | Automate build and release tasks to ensure maximum efficiency, predictability and responsiveness to business requirements for change. |

## Enterprise Data Platform Architecture

The following diagram shows the capabilities of the Enterprise Data Platform.

![Enterprise-Data-Platform-Capability-View.png](./Enterprise-Data-Platform/images/Enterprise-Data-Platform-Capability-View.png)

### ICMS ODS
The existing ICMS application that is hosted on-premise and utilises SQL Server has several Online Data Stores (ODS) that are utilised for reporting and non-transactional purposes. Another ICMS ODS is part of the Enterprise Data Platform where it is used to combine data with Unify and provide the capabilities for analytical reporting, low-latency read-only APIs, data migration, person search and person history.

### Unify ODS
The Unify ODS is a SQL Azure replica of the Dynamics 365 Customer Engagement database that is populated in near real-time using the Data Export Service. 

### Unify Data Lake
The Unify Data Lake, which is part of the larger data lake, stores the relevant Unify data that is required for analytical reporting and dashboarding within PowerBI. The Unify Data Lake is refreshed up to 4 times per day.

###  Unify Data Warehouse
The Unify Data Warehouse draws data from the multiple components of the Enterprise Data Platform and organises the information for consumption in PowerBI Dashboards. 

### PowerBI Dashboards
PowerBI Dashboards are the primary way in which summarised information is presented to staff members for analysis and management of the business processes within the department. 

The PowerBI Dashboards source information primarily from the Enterprise Data Platform and where possible from the Unify Data Warehouse to ensure optimal end-user performance.

### Reference Data Cache
The Reference Data Cache stores reference data that is sourced from other applications, primarily Unify, and then makes it available to consumers for use in the implementation of their business rules. Examples include the departmental definition of disabilities and how these are mapped from external definitions. The Enterprise Integration Platform is one consumer that uses this information to translate disabilities, described in inbound messages from external organisations, to the values that are used internally. The data migration processes also use this cache to map values from existing applications to Unify.

### Records Management Cache
The Records Management Cache is a read-only store of recently accessed documents from the on-premise records management application. As Unify initially requests a document, it will be sourced from the on-premise records management application and cached for future read requests. 

Business documents received from external organisations, including semi-structured messages (ie JSON) such as a student protection report from Department of Education,  will be stored in the on-premise records management application and cached for viewing within Unify.

### Integration Message Store
All messages processed by the Enterprise Integration Platform are stored in the Integration Message Store which is part of the data lake. 

### Audit Store
All audit messages, that are initially captured into the Office 365 audit store, are stored within this service in the Enterprise Data Platform for long term storage and retrieval. A regular process, multiple times per day, extracts information from Office 365 and places it into this store.

### Point In Time Store
The Point In Time Store allows for data to captured at certain critical points within a business process. Each of the critical points in the business process are defined by specific criteria such as a change in status or the creation of a subsequent data element. At these critical points in the business process the data is automatically serialised into JSON documents and stored in the Point In Time Store within the Enterprise Data Platform. Documents, within the Point In Time Store, can be queried by reporting tools or displayed within the Unify application through a real-time integration.

> 

### Person Search
The Person Search allows for a departmental staff member to search for a person across all of the data that has been consolidated within the Enterprise Data Platform. 

The Person Search is implemented as two components, being:
- An Azure Search Index that stores the consolidated data and provides an endpoint for the querying of the index
- One, or more, user interface capabilities that are used by staff members to query the index and display the results. The user interfaces are designed to be embedded within Unify and other applications that require the capability.

### Person History
Person History allows a consolidated summary of the person's history to be provided that includes information from across multiple data sources within the department. 

Person History is implemented as two components, being:
- An API that accepts a unique identifier for the person and responds with the relevant historical information for that person from across all of the data stored in the Enterprise Data Platform.
- One, or more, user interface capabilities that are used by staff members to view the person's historical information from across multiple data sources and in the context of the current business process. The user interface components are designed to be embedded within the Unify and other applications that require the capability. 


## Software List

The following products and services are used within the Enterprise Data Platform. 

| Technology | Description |
|:------------|:-----------|
| Azure Data Lake v2 | Data lake be used to store structured, semi-structured and unstructured data from Unify, ICMS and other sources.|
| SQL Azure | SQL Azure used to support the ICMS ODS and Unify ODS. |
| Azure Storage | Azure storage used for management purposes. |
| Azure Data Factory | Azure Data Factory used to schedule and execute the movement of bulk data into and within the Enterprise Data Platform. |
| Azure Databricks | Databricks to be used for complex data manipulation and AI / Machine Learning purposes. |
| Azure Search | Azure Search to be used to support the Person Search capability. |
| Azure Data Warehouse | Azure Data Warehouse to be used to structure information into dimensional models for consumption by PowerBI Dashboards. |
| Cosmos DB | TBC |
| PowerBI | PowerBI to be used to produce dashboards for analytical purposes and trend reporting. |
| Azure Functions | Azure Functions to provide structured services, based upon data within the platform, to consumer such as Unify and ICMS. |











