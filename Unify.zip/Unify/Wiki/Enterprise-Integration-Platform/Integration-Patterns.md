<h1>Integration Design Patterns</h1>

Though the usage of specific design pattern will be decided during detailed design, looking at current landscape and based on understanding of scope, one or more of below design patterns will be used.

[[_TOC_]]

## Asynchronous Update
> In this pattern, the sender will send a request and will get an immediate acknowledgement about the request whether it was successful or denied. The receiver will need to acknowledge whether the message has been received successfully as well as if it passes any basic validations. However, any prolonged logic or process will be parked for a later execution. At this stage, the sender is able to progress its internal application logic without the need to wait for the receiver to fully process the message and the required integration logic. This pattern is useful when the receiver needs to process a long running logic and the sender does not have to wait to receive the outcome.

Click [here](./Integration-Patterns/Asynchronous-Update.md) for more info.

## Synchronous Update
>This is similar to the asynchronous update pattern above except the sender will need to await a fully completed acknowledgement from the receiver that the message is fully processed and all logic is completed instead of only accepting the message. It means the sender will have to await the receiver to fully complete its processing logic and receive a completed response prior to executing further application or business logic. This pattern is important when the sender is dependent on the logic executed by the receiver to fully complete and commit the transaction.

Click [here](./Integration-Patterns/Synchronous-Update.md) for more info.

## Synchronous Read
>There are instances when a system does not provide access to interfaces or the database directly; or the application interface is so rich that it does not make sense to try to reproduce this with a new user interface.  In such instances, it is possible to embed the user interface for a Web Application by adding the URL to a Web Resource Control to load the external records within the its frame. This is typically used for read-only access to records in other systems. This pattern can substitute the need to migrate legacy records for instance and rather just expose such records within a frame inside the new system.

Click [here](./Integration-Patterns/Synchronous-Read.md) for more info.

## Message Queueing
>Messages in input are queued in order to guarantee delivery. There is no strict requirement for the receiving endpoint to be available, as it would be in a direct point-to-point connection. If the target system is not available, the message is not lost. A mechanism for retrial of submission is in place for a determined period of time, passed which the message is eventually removed from the queue if not consumed by any system.

Click [here](./Integration-Patterns/Message-Queueing.md) for more info.

## Publish and Subscribe
>It has one input channel that splits into multiple output channels, one for each subscriber. When an event is published into the channel, the Publish-Subscribe Channel delivers a copy of the message to each of the output channels. Each output channel has only one subscriber, which is only allowed to consume a message once. In this way, each subscriber only gets the message once and consumed copies disappear from their channels.

Click [here](./Integration-Patterns/Publish-Subscribe.md) for more info.

## Batch Data Synchronisation
>In the case of an integration where the data needs to be synchronised between Dynamics 365 and a remote system in a periodic manner, a periodic scheduled batch can be created to process the details via a data entity and an exchange protocol. In this pattern, one system will batch a group or records based on business logic (i.e. approved records since last successful sync timestamp) and send it another system for data synchronisation and further processing logic. File exchange either in CSV, JSON or XML format is a typical implementation of such pattern although other approached can be considered dependant on the technology used and available APIs.

Click [here](./Integration-Patterns/Batch-Data-Synchronisation.md) for more info.

## Bi-directional Synchronisation
>Bi-directional sync is the act of joining two datasets in two different systems to behave as one while respecting their need to exist as different datasets. The main driver for this type of integration need comes from having different tools or different systems for accomplishing different functions on the same data set.

Click [here](./Integration-Patterns/Bi-directional-Synchronisation.md) for more info.

## Data Exchange
>When data needs to be transported via an ETL layer (Extract, Transform, Load), the data exchange pattern is typically used to ensure data can be extracted from one system, data is then undergoes certain activities including cleansing, deduplicating, validation and finally transformed into a structure that is acceptable by the recipient system. 

Click [here](./Integration-Patterns/Data-Exchange.md) for more info.

## Process Integration Pattern
>Business processes extend beyond Dynamics 365. Digitalization requires ability to bridge legacy and cutting-edge systems in a rapid, intuitive and flexible manner.
	
Click [here](./Integration-Patterns/Process-Integration-Pattern.md) for more info.

# Pattern Decision Tree
The below table details the driving factors in selecting the integration approach or determine the appropriate pattern per each of some common scenarios

| Scenario  |  Applicable Integration Pattern(s) | Remarks |
|:--|:--|:--|
| When guaranteed delivery is required | Asynchronous Update,<br/>Message Queueing | |
| If transaction characteristic is a key  |  Synchronous Update | The sender can't commit until the receiver fully completed its actions |
| Data from Operations needs to be surfaced on CE without it being synchronised and vice versa  | Synchronous Read | This is an integration at a presentation layer and this pattern is best fit as data is not required to be synched and rather displayed as read-only in CE |
| Updating large volume of records regularly  | Batch Data Synchronisation<br/>Data Exchange | This is true if the integration can tolerate some time gaps or if data doesn't need to be viewed on the target system immediately |
| Both systems needs to hold same base record and keep it up to date (i.e. a person basic information) | Bi-directional Synchronisation | Also Data Exchange and Synchronisation Update can be applied although for the Synchronous Update any failure will rollback entire transaction and might incur additional performance hit but data will be guaranteed to be in-sync |
| When certain business actions needs to be processed in an orchestrated matter involving multiple systems | Process Integration Pattern  |   |
| .. |   |   |
| .. |   |   |
| .. |   |   |
| .. |   |   |


		
		
		
		
