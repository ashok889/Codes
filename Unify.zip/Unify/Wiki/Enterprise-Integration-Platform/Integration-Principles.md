<h1>Integration Principles</h1>

The following are some integration design principles that shall be adhered to while designing each inbound and outbound integration endpoint.

[[_TOC_]]

## Maximise the use of Integration Platform
Maximise the use of Integration Platform by making integration platform responsible for:
- Orchestrating the integration calls as part of business processes
- Act as abstraction layer for different systems to communicate 
- Transformation of data
- Broadcasting messages to different other systems
- Consolidation of messages and send one message to D365
- Integration Platform as a trigger for pushing/pulling the data from D365 and other systems
- Error handling and Retries.

## Design loosely coupled systems
Loosely coupled systems are less constrained to same platform, language, operating system.

## Elastic Integration
The integration platform should be able to scale up and scale down resources on demand.

## Limit synchronous integrations
Unless required by business process and is critical to have, synchronous integration should be limited. With synchronous call, the client connection is opened till response is received and could make implementation at server end complex and potential impact on user experience.

## Standardize Connectivity
Use the managed connectors or create a standardized custom connector using the pre-published API’s.

## Secure Data
Secure data at:
- Rest
- In process 
- In transit.

## For batch load/pull scenarios ensure system performance is not impacted during peak hours
Schedule batch pull/push in off-peak hours to ensure optimal performance.

## Reuse before customise
For Interim Interfaces leverage your existing integration mechanisms. Reuse any existing integration procedure and tool and extend it to support other instances.

## Use Web API/Rest endpoints for integrating with D365
Web APIs are standard and proven way to connect to Dynamics 365. It provides a modern, RESTful web service you can use to interact with data in Microsoft Dynamics 365 using a wide variety of platforms, programming languages and devices.

## Limit the use of SOAP Endpoints for integrating with D365
SOAP Endpoints are deprecating (in the process of being deprecated), and it is not advisable to use with Dynamics 365. However, this endpoint is still the primary one used for plugins and workflow activities. Use the new modern Web API when applicable.

## D365 to expose single endpoint per entity
Aim for your D365 instance to expose a single endpoint per entity which can be used to query/update the data for that entity.

## Use OOB connectors
Leverage the out of the box connectors when applicable (for Outlook, Power BI, SharePoint, Office 365...etc).

## Use Azure Active directory for Authentication
The On-Premise AD can be synced with Azure AD, which provides a SSO experience and also opportunity to use windows credentials for authentication and authorisation in Dynamics 365.

## Use Server to Server Authentication between integration endpoints
Aim to use the Server to Server Authentication and application ID if possible when integrating apps or systems instead of a dedicated service account credentials. D365 supports such authentication via a registered application in Azure AD.

## Authorisation of D365 Integration calls to follow security framework of D365
All integration CRUD operations on D365 must follow the security framework of D365.

## Minimise the use of Stubs during development and Testing
Stub based development could lead to quality issues and should be avoided. It is OK to use stub based development for small tasks or for unit testing but aim to interface with the actual endpoints or mirrored versions for end to end integration testings.

## Dedicated integration environment
For D365 instances where integration connectivity is required, avoid sharing same integration environment across multiple D365 instances.

## Freeze development of legacy systems
Any changes to legacy systems must be frozen to avoid re-work on integration.