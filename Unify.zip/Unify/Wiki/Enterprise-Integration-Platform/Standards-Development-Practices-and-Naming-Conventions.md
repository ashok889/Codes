<h1>Standards, Development Practices and Naming Conventions</h1>

This section documents the standards and best practices for the integration platform as well as some recommended naming standards and conventions.

[[_TOC_]]

## Naming Conventions

It is very important to agree on certain naming standards and conventions to be used across the entire organisation and for all its IT components and resources whether hosted on-premise or in the cloud (i.e. in Azure).

Well-designed naming standards allow easier identification of resources within the portal, on the bill and within scripts and other code. The adoption of a naming standard is recommended prior to the creation of any resources in Azure. The outcome is a more efficient identification and management of the environment at all levels.

Depending on the type of resource, there are constraints that apply to the naming of a resource. Some resource names are unique across entire Azure cloud. For example, a storage Account name must be unique across Azure and not just the DCSYW subscription, storage accounts also can’t contain upper case letters. Some resource names are constrained by length for example a Search Service is constrained between 2 to 15 characters.

The key to success with naming conventions is establishing and following them across your applications and organizations.
Below are the naming conventions agreed with DCSYW which will be followed for Integration Platform development.

### Virtual Machine and Hosted Services
The following naming convention will be used:
- '**Hosting Service**' denotes the hosting service for the component whether on-premise or cloud. 
  - 'A' is used for Azure services
  - 'AW' is used for Amazon Web Services 
  - 'I' is used for IBM services
  - 'L' is used for local (on-premise)
- ‘**Location**’ denotes the Region in which the service will be provisioned:
  - ‘AE’ denotes the Microsoft Azure Australia East (Sydney) region
  - ‘AS’ denotes the Microsoft Azure Australia Southeast (Melbourne) region
- ‘**Department**’ denotes the department for which the service will be provisioned:
  - ‘CW’ denotes Child Welfare
- ‘**Environment Type**’ denotes the lifecycle solution in which the service will be provisioned:
  - ‘P’ denotes the Production environment
  - ‘T’ denotes the Test environment
  - ‘D’ denotes the Development environment
- ‘**Platform**’ denotes the operating system type:
  - ‘W’ denotes Windows
  - ‘L’ denotes Linux
- ‘**Application**’ denotes the service/initiative the will be provisioned
- ‘**Increment**’ denotes the iteration number of the service; use 2 digits

**E.g.** For a Windows Virtual Machine hosted to support integration in a production server in Azure: **AAECWPWINT01**

| A	| AE | CW | P | W | INT | 01 |
|:--|:--|:--|:--|:--|:--|:--|
| Hosting Service | Location | Department | Environment Type | Platform | Application | Increment |
|

### Azure Applications
The following naming convention will be used for most Azure Cloud Applications:
- **Company**: csyw
- **Asset**:
  - unify = for Unify Application
  - eip = for Enterprise Integration Platform
  - edp = for Enterprise Data Platform
- **Object Code**:
  - la = Logic Apps
  - sb = Service Bus
  - fa = Function Apps 
  - am = API Management
  - rg = Resource Group
  - sa = Storage Account
  - ai - Application Insights
- **Context/Purpose/Function**: <mainAction(s)>
- **Environment**: p=Production; t=Test; d=development

**Examples**

- **Logic Apps example**: Logic app for DCSYW triggers OnPersonCreate in CE and will UpdateAddress in CE as well - used in production environment.
    - _csyw-unify-la-updateaddress-P_

- **Azure Functions example**: Azure Function for DCSYW triggers On KeyVault and will get credentials for a Logic App - used in production environment.
  - _Function App: csyw-unify-fa-p_
  - _Function name: retrievecredentials_

- **Service Bus example**: Service Bus for DCSYW for Department of Education queue with main queue to be used for CE - used in test environment.
    - _csyw-eip-sb-doemain-t_

- **API Management example**: API Management for DCSYW externally facing to expose a function to process SPR report through a logic app implementation of the endpoint - used in production.
    - API Mgt component: _csyw-eip-am-external-p_
    - Logic App for the endpoint: _csyw-unify-la-processspr-p_

### General Assembly Naming Convention
When .NET assemblies are required to support Azure Functions or Logic Apps, the following naming convention should be followed:

| Module |	Assembly Naming Convention | Asset |
|:-------|:----------------------------|:------|
| Azure Functions | CSYW.Unity.FA | Unify Application |
| Azure Functions UTest | CSYW.Unity.FA.Test | Unify Application |
| Azure Logic Apps	| CSYW.Unity.LA | Unify Application |
| Azure Logic Apps UTest |	CSYW.Unity.LA.Test | Unify Application |
| Azure Functions | CSYW.EIP.FA | Enterprise Integration Platform |
| Azure Functions UTest | CSYW.EIP.FA.Test | Enterprise Integration Platform |
| Azure Logic Apps	| CSYW.EIP.LA | Enterprise Integration Platform |
| Azure Logic Apps UTest |	CSYW.EIP.LA.Test | Enterprise Integration Platform |
| Azure Functions | CSYW.EDP.FA | Enterprise Data Platform |
| Azure Functions UTest | CSYW.EDP.FA.Test | Enterprise Data Platform |
| Azure Logic Apps	| CSYW.EDP.LA | Enterprise Data Platform |
| Azure Logic Apps UTest |	CSYW.EDP.LA.Test | Enterprise Data Platform |


## Standards and Best Practices

### Logic Apps
**Patterns and Practices for Writing Code**

Logic apps can be created in 3 ways: Azure Portal, Visual Studio or by hand. 

Generally a logic app structure is created with a visual designer in either the portal or Visual Studio, the template is then edited to parameterise out the necessary inputs. There is no wrong way to develop a logic app if the correct fields are parameterise out and the relevant parameters are added to all the environment parameter files in source control.

Follow below link for more details:
https://docs.microsoft.com/en-us/azure/logic-apps/logic-apps-deploy-from-vs

**Exception handling**

Scopes to Capture failures. The scope itself has its own status, which it receives after all the actions within a scope have completed. The scope status is determined with the same criteria as a run and, if the final action in an execution branch is Failed or Aborted, the status is failed.

where we can use runAfter, if the scope has been marked as Failed. In this scenario, runAfter can help us create a single action to catch failures if any actions within the scope fail.

We can also get the context of failure to understand exactly which actions failed using @result() workflow function. @result() takes a single parameter, scope name, and returns an array of all the action results from within that scope.

    "Exception_array": { 
        "inputs": { 
            "from": "@result('My_Scope')", 
            "where": "@equals(item()['status'], 'Failed')" 
        }, 
        "runAfter": { 
            "My_Scope": [ 
                "Failed" 
            ] 
        }, 
        "type": "Query" 
    } 

The Exception_array is a Filter array action to filter @result('My_Scope') to get the result of all actions within My_Scope.
The condition of the Filter array is any @result() item with the status equal to Failed. This will filter the array of all action results from My_Scope to only an array of failed action results.
These action objects include the same attributes as the @result() object, including action start time, action end time, action status, action inputs, action correlation IDs, and action outputs. We can combine the @result() function with a runAfter to send context of any actions that failed within a scope, as shown in the earlier example.
Once you have the Filter array of exceptions, you can perform an action for each failed action. For example, send an HTTP POST request with the response body of any actions that failed within the scope My_Scope.

    "Foreach_exception": { 
    { 
    "actions": { 
            "Log_Exception": { 
                "inputs": { 
                    "body": "@item()['outputs']['body']", 
                    "method": "POST", 
                    "headers": { 
                        "x-failed-action-name": "@item()['name']", 
                        "x-failed-tracking-id": "@item()['clientTrackingId']" 
                    }, 
                    "uri": "http://requestb.in/" 
                }, 
                "runAfter": {}, 
                "type": "Http" 
            } 
        }, 
        "foreach": "@body('Exception_array')", 
        "runAfter": { 
            "Exception_array": [ 
                "Succeeded" 
            ] 
        }, 
        "type": "Foreach" 
    } 
 
You can send an HTTP POST on the foreach item response body, or @item()['outputs']['body']. The @result() item shape is the same as the @actions() shape, and it can be parsed the same way.

Also, include two custom headers with the failed action name @item()['name'] and the failed run client tracking ID @item()['clientTrackingId']. You can also include other useful properties from the @result() such as startTime, endTime, and status.

We also have option to just terminate the workflow using the Terminate action, if the status of the scope is failed.

Follow this link for more details : https://docs.microsoft.com/en-in/azure/logic-apps/logic-apps-exception-handling


**Retry Policy**

These allow you to customize the retry behaviour for 4xx or 5xx errors. If a request in a Logic App workflow is timed out or failed (Error code 4xx or 5XX), Retry Policy can be defined for an action to retry.

    "retryPolicy" : { 
        "type": "<type-of-retry-policy>", 
        "interval": <retry-interval>, 
        "count": <number-of-retry-attempts> 
        }  
The retry interval is specified in the ISO 8601 format, which is representation of dates and times is an international standard covering the exchange of date and time-related data. By default, all actions retry four additional times over 20-second intervals. To disable the retry policy, set its type to None.

So, for example, if the first request received a 500 Internal Server Error response, the workflow engine pauses for 20 seconds and attempts the request again. If after all retries the response is still an exception or a failure, the workflow will continue and mark the action status as Failed.

**Singleton** 

Logic App runs are always executed in parallel (i.e. if you are using a batch trigger, and it fetches k records, then all k runs will be executed in parallel). 

If this is not the desired behaviour, then you can set the 'singleton' operation option on your trigger which can help to get around race conditions. For example, some logic apps take a long time to run, risk racing on shared resources like blob storage.

There will be multiple instances where you want to process the incoming request in sequential basis. In Logic Apps sequential workflow can be easily done by using operationOptions to singleInstance on the trigger definition.

    "triggers": {
        "mytrigger": {
            "type": "http",
            "inputs": { ... },
            "recurrence": { ... },
            "operationOptions": "singleInstance"
        }
    }
Singletons should only be used where it is impossible to provide a logic app with a dedicated resource. If any instance takes longer to run than the configured interval, the trigger will be skipped with a “WorkflowRunInProgress” code.

**Debatching**

Let's say you have a trigger in your Logic App that receives an array items. Now you want to debatch array items and start a new workflow per item. You can accomplish that using SplitOn. This is very useful when you want to poll an endpoint that can have multiple new items between polling intervals.

**Compute operations**

- Deploy function apps to handle the compute operations. This includes constructing the communication with CE. 
- Use C# code to handle compute operations
  - Transformation code
  - Translation code
- Use Logic Apps for flow and where there is benefit in using the out-of-the-box connectors
- Use Logic Apps for orchestration and implementing business rules and logic and use Azure Function for any computation that cannot be achieved via Logic Apps interface.

**Securing Logic Apps**

Tokens, keys, secrets and other sensitive information is not to be visible in the run history of a logic app. To accomplish this we have two approaches:

- Web App Proxy
The Web App Proxy is used to proxy requests that require the sensitive information be placed in the body, URI, or custom header of a request to another system. The Web App Proxy will make the request on behalf of the logic app and then return the response from the server, sanitizing any sensitive information. This removes all the sensitive information from the run history. 

- ARM Deployment with KeyVault Substitution
We can reference secrets from KeyVault during a deployment and they will automatically substituted into our ARM template. These parameters will be sanitized from the portal, however, if they are used in non-standard place such as custom headers, the request body or the URI, they will be visible in the run history. This method is useful for deploying API connections such as sFTP with a known password. The password will be sanitized and remain secure.
We can accomplish this using this guide: https://docs.microsoft.com/en-us/azure/azure-resource-manager/resource-manager-keyvault-parameter
Please note that you will need to know details about the KeyVault and secret you are referencing.


### API Management

**Creating APIM APIs**

APIM APIs should follow the following conventions:
- RESTful practices
- Use the correct method to describe what is happening
  - GET = getting a resource
  - POST = creating a resource
  - PUT = updating a resource 
- Do not include verbs in the name of the api
  - “address” instead of “getaddress”
- Backwards compatibility
- JSON is the preferred data-interchange format.
- Test your APIs using both the APIM Developer Portal and your application. 
- Do not hard code the APIM base URL into your code, make it a parameter/variable/config setting. It will change!
- Use the “No Subscription” product when creating a brand new API.
  - This removes the static key validation that APIM uses. We don’t need it because all our APIs use AAD to authenticate the user. 

**API Management for Securing Integration Platform**

One use of API Management (APIM) is to secure the internet exposed functionality of the integration platform. API Management uses Azure Active Directory (AAD) as an OAuth server. This allows client applications which are already authenticated to have a seamless experience with the integration layer using the built in single sign-on functionality.

**Structure**

APIM will be structured in such a way that one instance of API management will host multiple environments, provided all of them are connected to the same AAD tenant. To handle different versions of the same applications in each environment, a new, environment specific API will be exposed.

An example is found below, where we use the same APIM instance to expose APIs for both the Offshore Dev and Offshore Test environments:
The base URL for both environments will be the same, but the first section of the path will be different. As an example:

The base URL for the Offshore Dev environment is: https://am-fcs-aue-api-dev.azure-api.net/dev-la

The base URL for the Offshore Test environment is: https://am-fcs-aue-api-dev.azure-api.net/la-test

The first section of the path refers to the environment we are accessing. The production environment should have its own instance of APIM. Do not test across this API management. 

**Securing Logic Apps**

Logic Apps that require the request originate from outside of the Azure Environment need to be exposed using APIM to secure them from unauthorized access.

This needs to be done through the Portal so that we do not have to hardcode any logic app URLs, instead APIM will use a resource reference and handle resolving the logic app behind the scenes. 
Currently we are exploring ways to automate the flow of APIs from one instance of APIM to another but at present, this is a manual process, hence the release manager will need to be informed of the changes required to each environment. 

The logic app should also be IP restricted to only allow access from the APIM instance and the other intra-Azure services (such as other logic apps).

**Securing APIs**

We are using a standard Azure Web App with WebAPI on top (more in the WebAPI section). This API must be secured through APIM and be IP restricted in the same way as the logic apps. 

**Error Handling**

Azure API Management allows publishers to respond to error conditions that may occur during the processing of requests to the proxy by providing a ProxyError object. The ProxyError object is accessed through the context.LastError property and can be used by policies in the on-error policy section.

The on-error section is not present in policies by default. To add the on-error section to a policy, browse to the desired policy in the policy editor and add it.

If there is no on-error section, callers will receive 400 or 500 HTTP response messages if an error condition occurs.

We can accomplish this using this guide: https://docs.microsoft.com/en-us/azure/api-management/api-management-error-handling-policies



### Service Bus

Azure Service Bus is the enterprise message system. This system would be used where we would need to process messages in order, or where we have multiple consumers of a single message. 

**Topics vs Queues**

Topics are the preferred service bus function. They allow a message to easily to be consumed by multiple consumers and poisoned messages are automatically handled and scale incredibly well. Topics are subscribed to by consumers and then filtered, this way we can use 1 topic to handle multiple message types and have the subscribers filter on exactly which messages they can process. 

Queues are appropriate in situations where there is one consumer of the messages and the messages need to be processed in a certain order. In all other cases, we should be using Topics. 

**Reuse connections**

Service Bus client objects, such as QueueClient or MessageSender, are created through a MessagingFactory object, which also provides internal management of connections. You should not close messaging factories or queue, topic, and subscription clients after you send a message, and then re-create them when you send the next message. Closing a messaging factory deletes the connection to the Service Bus service, and a new connection is established when recreating the factory. Establishing a connection is an expensive operation that you can avoid by re-using the same factory and client objects for multiple operations. You can safely use the QueueClient object for sending messages from concurrent asynchronous operations and multiple threads.


### Azure Functions 

**Avoid long running functions**

Large, long-running functions can cause unexpected timeout issues. A function can become large due to many Node.js dependencies. Importing dependencies can also cause increased load times that result in unexpected timeouts. Dependencies are loaded both explicitly and implicitly. A single module loaded by your code may load its own additional modules. 

Whenever possible, refactor large functions into smaller function sets that work together and return responses fast. For example, a webhook or HTTP trigger function might require an acknowledgment response within a certain time limit; it is common for webhooks to require an immediate response. You can pass the HTTP trigger payload into a queue to be processed by a queue trigger function. This approach allows you to defer the actual work and return an immediate response.

**Cross function communication**

When integrating multiple functions, it is generally a best practice to use storage queues for cross function communication. The main reason is storage queues are cheaper and much easier to provision. + 
Individual messages in a storage queue are limited in size to 64 KB. If you need to pass larger messages between functions, an Azure Service Bus queue could be used to support message sizes up to 256 KB.
Service Bus topics are useful if you require message filtering before processing.

Event hubs are useful to support high volume communications.

**Write functions to be stateless**

Functions should be stateless and idempotent if possible. Associate any required state information with your data. For example, an order being processed would likely have an associated state member. A function could process an order based on that state while the function itself remains stateless. 

Idempotent functions are especially recommended with timer triggers. For example, if you have something that absolutely must run once a day, write it so it can run any time during the day with the same results. The function can exit when there is no work for a particular day. Also if a previous run failed to complete, the next run should pick up where it left off.

**Write defensive functions**

Assume your function could encounter an exception at any time. Design your functions with the ability to continue from a previous fail point during the next execution. Consider a scenario that requires the following actions:
- Depending on how complex your system is, you may have involved downstream services behaving badly, networking outages, or quota limits reached, etc. All of these can affect your function at any time. You need to design your functions to be prepared for it. 
- How does your code react if a failure occurs after inserting 5,000 of those items into a queue for processing? Track items in a set that you’ve completed. Otherwise, you might insert them again next time. This can have a serious impact on your work flow. 
- If a queue item was already processed, allow your function to be a no-op.

Take advantage of defensive measures already provided for components you use in the Azure Functions platform. For example, see Handling poison queue messages in the documentation for Azure Storage Queue triggers and bindings. 

**Don't mix test and production code in the same function app**

Functions within a function app share resources. For example, memory is shared. If you're using a function app in production, don't add test-related functions and resources to it. It can cause unexpected overhead during production code execution.

Be careful what you load in your production function apps. Memory is averaged across each function in the app.

If you have a shared assembly referenced in multiple .Net functions, put it in a common shared folder. Reference the assembly with a statement similar to the following example: 

    Copy 
    #r "..\Shared\MyAssembly.dll". 
Otherwise, it is easy to accidentally deploy multiple test versions of the same binary that behave differently between functions. 

Don't use verbose logging in production code. It has a negative performance impact.

**Use async code but avoid blocking calls**

Asynchronous programming is a recommended best practice. However, always avoid referencing the Result property or calling Wait method on a Task instance. This approach can lead to thread exhaustion.

**Error Handling**

Durable Function orchestrations are implemented in code and can use the error-handling capabilities of the programming language.  
- Errors in activity functions. 
Any exception that is thrown in an activity function is marshalled back to the orchestrator function and thrown as a TaskFailedException. You can write error handling and compensation code that suits your needs in the orchestrator function. 
- Automatic retry on failure. 
When you call activity functions or sub-orchestration functions you can specify an automatic retry policy. 
- Function timeouts.
You might want to abandon a function call within an orchestrator function if it is taking too long to complete. The proper way to do this today is by creating a durable timer using context.CreateTimer in conjunction with Task.WhenAny 
- Unhandled exceptions.
If an orchestrator function fails with an unhandled exception, the details of the exception are logged and the instance completes with a Failed status. 

We can accomplish this using this guide: https://docs.microsoft.com/en-us/azure/azure-functions/durable-functions-error-handling 


### Azure KeyVault

Azure KeyVault is used to store sensitive information such as usernames, passwords, keys and tokens that the platform requires. 
We should have one Key Vault per environment, but we can share key vaults across environments provided that all the environments use the same value for each key. The production environment should have its own key vault.

**Secrets**

Secrets should be added through the portal.
The secret names should be descriptive and as short as possible. These names will be used in multiple projects, so a good name is essential from the start as it could be costly to change the secret name later. 

**Access Control**

Key vault is currently used in 3 ways:
1. To add secrets through portal
1. To substitute sensitive values using ARM Deployments
1. To substitute sensitive values using the Web App. 

Each of these scenarios require that correct permissions be granted to principals. There needs to be the correct permissions given to the Web App principal used in #3, correct permissions to the principal who is deploying the solution (could be an application or a user) for #2 and correct permissions for the person adding secrets through portal. 





