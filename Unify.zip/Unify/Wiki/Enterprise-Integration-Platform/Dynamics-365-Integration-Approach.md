<h1>Dynamics 365 Integration Approach</h1>
As part of DCSYW transformation programme, Dynamics 365 needs to integrate with the existing landscape to complete critical business processes. This section will describe the various methods and endpoints when integrating with Dynamics 365 specifically as part of the overall Enterprise Integration Platform recommendations.

[[_TOC_]]

## Inbound and Outbound Integration Methods with Dynamics 365
When pulling or pushing data into Dynamics 365, consider the following two methods and what to use within each method:
- _**Dynamics 365 Inbound Integration**_: In this scenario, external applications and middleware should consume the web services exposed by Dynamics 365. Dynamics 365 exposes different types of endpoints for other clients to interact with its underlying data and metadata. We recommend the use of a **[Business API](#Business-API-layer-for-Dynamics-365)** layer that sits on top of Dynamics 365 and act as a single point of entry to the application.

    This layer is typlically implemented in **Azure Logic Apps** and **Azure Functions** and integrate with Dynamics 365 via the available out of the box connectors or directly via the Web API endpoint connector.

- _**Dynamics 365 Outbound Integration**_: In this scenario, Dynamics 365 would trigger integration by consuming the web services exposed by the middleware. In this type of integration, the integration platform’s capabilities would determine Dynamics 365 can consume their services. Usually we recommend other internal business applications (i.e. ICMS) to expose a set of Business APIs and those can be invoked by Dynamics 365 as required. For external integration, we recommend the use of a middleware or an integration messaging for reliable communications if required.

    This layer is typically implemented by a set of **plugins** or **workflows** exposing the transaction context message externally to **Azure Service Bus** or other systems. Also it can be implemented via **Azure Logic Apps** and **Azure Function** that is able to get invoked from within Dynamics 365 events or respond to Dynamics 365 actions and then push required data to the external applications.

## Business API layer for Dynamics 365
### Overview
Business API layer is a set of functions and logics that will orchestrate and execute certain commands against Dynamics 365 as part of the integration logic. This layer should be used for Inbound integration with Dynamics 365 and act as the single entry point to the platform.

### Responsibilities
This layer will be responsible for the following:
  - Validate incoming requests and ensure it is compatible with Dynamics 365 entity schema 
  - Transform incoming requests if not compatible with Dynamics 365 schema although we recommend the use of a transformation layer outside of the Business API for better reusability, management and support of the entire integration platform when involving other transformation logics for other applications
  - Execute the business logic and construct API requests that is able to communicate to Dynamics 365 APIs directly and produce a response if required. For instance, as part of the integration request, we need to create a new person record, a report and link the two. In the Business API we'll construct and execute a single batch request that includes those actions
  - Act as a single point of entry to Dynamics 365 and controls business logic from an integration perspective centrally.

### Benefits
  One of the key benefits of the Business API layer is the ability to hide the underlying complexity and design of Dynamics 365 from the various integration endpoints. For instance, other applications should not know how reports are stored and how a person structure looks like. However, they'll be able to send a request with data and the Business API layer should be able to route the information down to Dynamics 365 in the right manner.

  It means that the Business API layer should be built by the Application team and rather than the integration team. This will help in isolating business processes centrally and get them implemented as part of the development project of the Dynamics 365 itself.

### Technologies
The typical technologies used to implement this layer are:
- Azure Logic Apps
- Azure Functions

Typically the **Azure Logic** Apps will act as the central controller and orchestrator of the business logic. If the Azure Logic Apps fails to commit the data to Dynamics 365 due to a platform limitation or is unable to run some validation commands, then we recommend to implement such actions in **Azure Functions** as code blocks (which typically is more flexible but harder to maintain). Keep Azure Functions small and modular. They are best used when receiving an input, processing a logic and producing an output back to its caller. Refrain from using long running processes or logic that orchestrate various steps and integrate with multiple systems. Azure Logic Apps is better used for such scenarios 

## Dynamics 365 Integration Options
Dynamics 365 for CE exposes the following endpoints for external applications (i.e. Business API) to consume its services:
- Web API (OData v4)
- Organization Service

![dynamics-365-endpoints.png](./images/dynamics-365-endpoints.png)

There was a third endpoint known as the RESTFul Organization Data Service (OData v2) but got deprecated in 2016 in favour of using the Web API endpoint.

    As a recommended practice, always aim to use Web API as the first choice and preference over other endpoints if applicable

**Note**: there is a deployment service and discovery service but those are outside the scope of this topic.

Overview of each of these choices along with their pros, cons, and best fit scenarios is explained in the below subsections.

### Web API (OData v4)
**Overview**

- Web API is new endpoint exposed in Dynamics 365
- It implements OData v4 protocol. It is built on open standards. Hence HTTP requests can be created and sent using any standard library on any platform
- Web API will gradually replace Organization service and Organization Data service to become single web service for Dynamics 365 for Customer Engagement. Web API is the recommended choice for any new development for Dynamics 365.
 
**Pros**
- Since Web API is built on open standards and can be consumed via HTTP request, it is platform independent. Any middleware capable of creating HTTP Request can consume this service
- There is no need to use Dynamics 365 provided libraries to consume this service
- Web API Request and Response have JSON format, so it’s very easy to work with Web API from JavaScript
- Since data is shared in JSON format, it would be lighter than XML which is provided by SOAP protocol. It results in much smaller payload than SOAP protocol
- Web API is the introduced to aid better user experience in cloud and mobile application
- Compared to the Organization service, the Web API provides better compatibility across a wide variety of programming languages, platforms, and devices.

**Cons**
- Some custom actions not available in Web API. Custom actions are relevant only within Dynamics 365 Customer Engagement. This limitation would not have any impact for the integration platform to consume it
- Some of the organization service messages are not available under Web API.

**Best Fit Scenario**
- All integration use cases which are supported by Web API should be achieved with Web API
- Using Web API is Microsoft’s recommended option for Inbound Integration to Dynamics 365 for CE.

### Organization Service
**Overview**
- kept the US spelling of Organisation (with z) since this is the official name of the endpoint and known worldwide by this name
- Implements IOrganizationService interface
- Organization Service is implemented by SOAP protocol. Service request and response are provided in SOAP format
- Microsoft Dynamics CRM uses Windows Communication Foundation (WCF) to SOAP endpoint
- It is the primary web service for accessing data and metadata from Microsoft Dynamics 365 instance
- It is built on WCF and optimised for use with the .Net.

**Pros**
- The Organization service is optimised for use with .NET
- The Microsoft Dynamics 365 SDK provides a set of assemblies and tools to generate strongly typed classes and proxies that streamline the development process a using Microsoft Visual Studio
- Complete set of requests to perform any transaction within Dynamics 365 Customer Engagement is supported only by Organization Service. 

**Cons**
- Since it is optimised for .Net, other clients might not consume this service as easily as .Net client
- It uses SOAP protocol. Hence the size of request and response payload would be higher than JSON
- Microsoft is slowly moving toward Web API and thus the future of the Organization Service remains uncertain and best if not used in development for future compatibility and roadmap considerations of the platform.

**Best Fit Scenario**
- Business logic that runs in plug-ins or workflow assemblies on the server expect to use the Organization service. Input and output parameters use specific classes defined with the assemblies that support the Organization service. In fact, **when writing plug-ins and workflows, this endpoint is the recommend and only one should be used. Never try to initialise a Web API service in plug-ins or workflows due to performance and security constraints**
- .Net Clients which would like to interact with Dynamics 365 Customer Engagement can utilise organization service.

## Dynamics 365 and Integration Layer Considerations
The top key recommended integration characteristics to consider first should be Asynchronous and Reliable. Asynchronous integration will allow for better performance and isolation of business logic (decoupling) but it fails to provide prompt responses back to end users. Usually this limitation can be overcome or addressed by adjusting the integration business logic layer or provide an acceptable UI experience until the data is available. Reliable integration is important for guaranteed message delivery and ensure the integrated data is not lost. 

The following advantages offered by **integration layer** would be leveraged in asynchronous and reliable integrations:

- **Consolidation of Endpoints**: Integration platform (via the Business API layer) would consolidate all the requests associated with a specific functionality and use only one endpoint exposed from Dynamics 365. This would significantly reduce the endpoints exposed by Dynamics 365. For example, for all requirements related to creating SPR reports should go through only one Business API endpoint exposed over Dynamics 365. Thus  the integration platform will be performing the necessary heavy lifting to update various systems as needed
- **Better transformation**: Complex transformation is handled at the integration layer which is best designed for that. This reduces the design and development effort on Dynamics 365 and the other internal applications
- **Consistent Exception Handling**: Exceptions and logging in all the orchestrations are handled in a consistent fashion. They are logged at a central repository and can be enriched by the capabilities offered by the platform. Notification in case of critical errors are offered OOB by the integration platform (i.e. via using the Alerting function of Azure Monitor)
- **Retry Mechanism**: Ability to retry can be offered by the integration platform as part of the orchestration. No effort is required to be built in the source or the target system. 

Considering the advantages offered by the integration platform, Microsoft recommends all integrations be managed only via the integration platform and by an dedicated integration team. 
