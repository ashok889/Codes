<h1>Data Exchange</h1>

There will be instances when a data integration approach needs to be considered where:
- Data needs to be extracted for read-only purposes
- Data needs to be extracted for ETL
- Data files must be consumed by an application

There are many technological choices to meet these needs, with just a few being described below. These are not intended to be an exhaustive list of technology options.
Note that any of the ETL tools described below will use a Dynamics 365 adaptor that communicates with the Dynamics 365 web services only i.e. they do not communicate with the underlying Dynamics 365 database.

[[_TOC_]]

## Illustration
A middleware will extract data from System A (1) and will undergo some transformation logic internally before loading data (2) into System B. System B might send an acknowledgement or a response back to the middleware if successfully processed the data. This is useful for tracking as well as error handling and recovery from failures.
 
![data-exchange.png](../images/data-exchange.png)

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Data Factory v2
- SQL Server Integration Services (SSIS)
- Data Export Services + Azure Data Factory

### Azure Data Factory
Integrate data silos with Azure Data Factory, a service built for all data integration needs and skill levels. Easily construct ETL and ELT processes code-free within the intuitive visual environment, or write your own code. Visually integrate data sources using more than 80 natively built and maintenance-free connectors at no added cost.

**Pre-requisites**
- Valid Azure subscription

**Benefits**
- Configuration-first approach to ETL
- Easy to configure and read to use with large number of connectors including D365 (introduced in version2)
- Can process large volumes of data efficiently

**Limitations**
- Runs in the cloud and might face firewall restrictions when integrating to On-premise sources/targets

### SSIS
The product provides a configuration-first approach to integration within a Visual Studio style environment, and is therefore considered more complicated to use than other tools such as Scribe. SSIS will allow Dynamics 365 integration with applications directly with database, using web services or by import and exports of files.  The product supports extract, transformation, and load (ETL) to provide an integration hub which runs both manual and scheduled integration jobs. 

![ssis.png](../images/ssis.png)

**Pre-requisites**
- Server instance of SQL Server Enterprise Edition
- SSIS Adaptor for Dynamics 365 
- SSIS Development skills

**Benefits**
- Configuration-first approach to ETL
- Can run manually or scheduled
- Can process large volumes of data efficiently

**Limitations**
- Installation of SQL Server Enterprise required, which is expensive
- Need to purchase separate adaptor for Dynamics 365 e.g. KingswaySoft
- More complex than Scribe to configure	 

### Data Export Service
Dynamics 365 online is a shared SaaS and therefore has restrictions set on resources to ensure a fair use of the platform. i.e. do not allow a process to choke the platform; an example of this is with reporting. Reports that are not process-intensive will run well directly against the platform (using FetchXml via the web services), but for process-intensive reports it is better to extract a copy of the database and run the reports against that.
The Data Export Service provides a configuration-first approach to this and allows a copy of the database to be extracted to an Azure SQL Database, which will be periodically updated as changes take place in the master database.

**Pre-requisites**	
- Azure subscription

**Benefits**
- Configuration-first approach to creating a read-only copy of the Customer Engagement database
- Allows longer running jobs such as reports to run without impacting the Dynamics 365 online service

**Limitations**
- It is read-only
- Only available for Online platform

## Recommendations and Implementation Practices
The following are some recommendations that will help you decide a technology from above when implementing this pattern:
- It is a good idea to enable Export Data Services for the Dynamics 365 instance and enable track changes on the required entities. The service is free and will automatically such changes into an Azure SQL instance. However, note that you'll still be charged for the storage consumption by the Azure SQL instance.
- When deciding which ETL tool to use, consider Azure Data Factory v2 first. This is a cloud based ETL layer and with version 2, they added support for a Dynamics connector. It can implement complex integration mapping logics and have an easy to use designer. Use SSIS as a secondary preference. With SSIS, you'll need a third party connector to communicate with Dynamics 365 for complex integrations. Kingswaysoft is one of the commonly used connector and is highly recommended by the community but you need to purchase a license in order to use in the production integration platform.

To implement this pattern, rather than having the Data Factory directly exposing data from Dynamics 365, aim to use the Data Export Services SQL instance. This way there is no processing load on the Dynamics 365 instance. **It is a common practice to use Data Export Services with Data Factory for most integration platforms**.

Note: Never treat the Azure SQL database for the Data Export Services as a Data warehouse. It only stores the last updated version of the record and only expose the entities that are enabled for tracking. You can still build reports from the Data Export Services database or use it with a Data Factory for integration but for complex BI and Analytics reporting, a proper Data warehouse is still needed.



## General Application Scenarios
This type of integration is best used when a data transformation needs to be done in a middleware prior to committing the data to the target. Usually the data will go through an ETL layer (Extract, Transform and Load) in which the source data will be extracted (regularly or based on some event) and then is transformed (i.e. deduplicated, translated, apply any business logic conditions) then is loaded into the target systems.

Usually the middleware will connect to both source and target systems via out of the box connectors which makes the extraction and loading job straightforward. It is possible to even build custom connectors for some middleware but always use off the shelf product if available due to its proved history, had been tested and supported by the vendor.