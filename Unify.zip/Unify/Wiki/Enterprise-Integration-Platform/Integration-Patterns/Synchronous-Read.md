<h1>Synchronous Read</h1>

Integration with the client-side has already been mentioned when describing Form Events that implement the Event-Driven Consumer pattern, but there are instances when making use of the standard Customer Engagement forms will not be appropriate. 
It is more suitable to:
- Re-use an existing external application interface (iFrame)
- Develop a custom form (Web Resource Control)

[[_TOC_]]

## Illustration
System A needs to display data reside in System B. System A will have a control (i.e. a Frame) that is able to integrate and fetch data (1) from system B (2) via some API layer. System B will return the data (3) and the integration control will be able to render it properly within its frame (4) inside System A.

![presentation-integration.png](../images/presentation-integration.png)

## Technologies Used
The most common tools or technologies used in this pattern are:
- Embedded Canvas PowerApps
- Virtual Entities
- Embedding web application via a URL
- Embedded developed custom form (web resource)

### Embedded Canvas PowerApps
Using PowerApps to embed an interface or data from another system within Dynamics 365 is the most preferable approach by Microsoft moving forward for the Synchronisation Read pattern. PowerApps provide an easy interface with drag-and-drop controls, Excel like logic/formulas and connectors to over 200 external systems including Dynamics 365. It supports mobile, tables and web experiences. For more information, visit this link:
https://docs.microsoft.com/en-us/powerapps/maker/model-driven-apps/embed-canvas-app-in-form

![powerapps.png](../images/powerapps.png =700x400)

**Quick Reference**
- Online only
- Easy to use drag and drop designer

**Pre-Requisites**
- Valid O365 subscription

**Benefits**
- No/low development skills is required
- Flexible UI design
- Over 200 connectors

**Limitations**
- The API between embedded PowerApps and D365 is improving
- D365 Connector has some limits and still improving

### Virtual Entities
Virtual Entities has been introduced in order for Dynamics 365 to expose information from an external data source within a model-driven app or record of the Customer Engagement. For more information, check this article:
https://docs.microsoft.com/en-us/dynamics365/customer-engagement/customize/create-edit-virtual-entities

Virtual Entities currently support exposing data from an external system that supports **OData v4 WebAPI** endpoint. It is possible to create custom connector via a plugin but this requires lots of development.

**Quick Reference**
- Online and on-premise
- via OData v4 endpoint

**Pre-Requisites**
- API for the target application

**Benefits**
- No development skills is required
- Data is displayed within Dynamics 365 following same UI styling. Users wouldn't even know that data reside externally

**Limitations**
- Only read operation is supported
- Normally you can only see data, there are limited support for searching or interacting with the data from within Dynamics 365 unless purposely built

### Embedding web application via a URL
There are instances when a system does not provide access to interfaces or the database directly; or the application interface is so rich that it does not make sense to try to reproduce this with a new user interface.  In such instances, it is possible to embed the user interface for a Web Application by adding the URL to a Web Resource Control. (see https://msdn.microsoft.com/en-us/library/gg509061.aspx)

**Quick Reference**
- Online and on-premise
- Re-use of existing Web application UI
- The UI style may be very clearly different to the user

**Pre-requisites**
- A Web Application URL

**Benefits**
- Configure-first and simple
- No/low development required

**Limitations**
- No control over the look-and-feel
- No data or message exchange with D365

 
### Embedded Developed Custom Form (Web-resource)
By developing a HTML5 web form (i.e. a D365 Web-resource) or Silverlight control, a presentation-level integration can be implemented with an external application. NOTE: Silverlight should not be used for new development.

**Quick Reference**
- Online and on-premise
- Full control over the user experience
- Development skills required

**Pre-requisites**
- Development skills
- API for the target application

**Benefits**
- Full control over the user interface presented
- Ability to make the integration look seamless

**Limitations**
- Specialist development skills required
- Dynamics content is hard to build		


## Recommendations and Implementation Practices
Here are some recommendations and considerations to help you decide which technology to pick:
- We recommend Embedded Canvas PowerApps to be used when displaying information coming from external sources (i.e. Data Platform) and can group or aggregate data and render them as per business need. Microsoft is pushing toward using the Canvas PowerApps as a way moving forward compared to the old traditional way of custom built forms. You can even use PowerApps for collecting data from various entities within Dynamism 365 database itself and present them to the end user to provide a better user experience or a single and true 365 view. PowerApps are:
  - Easy to configure with drag and drop wizard
  - quite powerful and support over 200 connectors. Some can retrieve records while other to action commands
  - Microsoft is investing into the future of embedding PowerApps with Dynamics 365 and adding more API and SDK supports in the roadmap
- Since PowerApps are easier to create, consider them first. However, sometimes we need virtual entities if not just we want to present external data but also get the data involved in some business logic and participate in the platform events. Virtual entities are useful in displaying datasets and information residing outside Dynamics 365 and yet the list or form will look identical to any other real entity in the platform. You can think of the virtual entity like any other custom entity in the system except that the data is not stored into the Dynamics 365 database. It is currently limited to OData v4 endpoint and requires some configuration to the endpoint and registration to get it working. There are limitations when it comes to filtering of data, paging or implementing custom security. Basically the control is limited to what you can do with the data. Evaluate it carefully and will be good to build a quick prototype or a POC prior to commit the design toward this path
- If the web application to integrate with can be URL accessible and also support showing within iFrame, then probably embedding the web application via a URL is a good and easy approach to expose the data. However, you do not have much control over the iFrame form.
- We discourage custom developing web resources to embed data from external sources into Dynamics. Aim to use Canvas PowerApps instead.


## General Application Scenarios
Typical use of such pattern is to replace the migration of historical or archived data from a legacy system via the custom frame or the virtual entity list that will expose such data in read-time within Dynamics 365 without the need for data to be actually hosted in Dynamics 365. 

This type of pattern is helpful in call centre environment in which the agent on the phone might require data from various systems to be viewed at once and within limited screen real-estate in order to provide better customer service over the phone. So rather than the agent would open a legacy app to access historical cases, he/she can view them right from within the person's record who's calling.

