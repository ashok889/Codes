<h1>Message Queueing</h1>

Messages in input are queued in order to guarantee delivery. There is no strict requirement for the receiving endpoint to be available, as it would be in a direct point-to-point connection. If the target system is not available, the message is not lost. A mechanism for retrial of submission is in place for a determined period of time, passed which the message is eventually removed from the queue if not consumed by any system.

[[_TOC_]]

## Illustration
Sender will send a message (1) and the integration logic will attempt to store the message details in a Queueing system (2) then it will send an acknowledgement back to the sender (3). In Parallel a lister will be awaiting on the other side of the queue (4) to read new messages and send them through the integration pipeline for processing by the receiver (5) which will need to signal back a successful completion of the message (6) in order to remove it from the queue. 

![message-queue.png](../images/message-queue.png)

Note: there are multiple ways to listen or read messages from queues. Below is some common scenarios:
	• A reader application can peek through a new message and issue a lock so no one else can access the message while the reader is still reading it. Then the reader should issue a completed command back to the queue in order to remove the message from the queue
	• A reader application can peek and complete a new message at once. In this scenario, the message is automatically removed from the queue
	• A reader application can peek through a new message but will not issue any locks. It means other listeners will be able to read the same message. At some point, the message needs to be removed from the queue by one of the listeners or by another external logic

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Service Bus

### Azure Service Bus
Azure Service Bus messaging is an implementation of modern message queuing concepts implemented in the Microsoft Cloud as platform as a service. Service Bus messaging has two key areas as follows.

**Queues**

A queue implements a one way communication where the sender places a message on the queue and a receiver will collect the message soon or sometime in the future.  The queue is a durable entity meaning that a message placed on a queue is saved and can remain on the queue for a long period of time if the receiver is not ready to collect it yet.  A simple diagram showing a queue concept is below:
![queue-type.png](../images/queue-type.png)

**Topics**

A topic is similar to a queue except that a message sent to a topic can have a copy of that message forwarded to multiple subscriptions.  A subscription is similar to a queue except that is includes some rules which determine which messages from a topic will go to each queue.  An example of the use of a topic could be to use a fan out pattern where all messages sent to a topic will have a copy sent to each subscription so many applications can get their own copy of all messages.  Another example would be the implementation of a publish and subscribe pattern where the message sent to a topic is only forwarded to a subset of queues based on the rules it matches.  An example would be if a message had a property called “Message Type” and a subscription could say only send messages where the message type is “CustomerUpdate” to the subscription used by the CRM application.

The below diagram is a simple representation of the topic pattern.
![topics-type.png](../images/topics-type.png)


## Recommendations and Implementation Practices
- use **Queues** type when you want to track a simple queue to store messages and have a single listener. Use **Topic** if you want to implement a publish-subscribe approach of communication or for broadcasting messages to more than one listener
- Use Azure Service Bus in conjunction with Asynchronous Update pattern to achieve a better reliable, performant with guaranteed message delivery integration design
- In Azure Service Bus, you can **peek and lock** a message OR **peek and complete** immediately. We recommend that you peek and lock the message and once the processing logic is done with the message then you issue a separate complete command. Also you can control the lock interval from the queue settings in the Azure portal
- Always keeps in mind that messages are processed based on first in, first serve. Aim to design the integration with Azure Service Bus by decoupling the messages and each message should fulfill a complete purpose on its own without the need for other messages in the queue to address a business logic.


To implement this pattern, follow these steps:
1. Create an Azure Service Bus service in Azure
1. Add a queue to the above service bus instance. This queue will be used to store the incoming messages. You can create more than one queue if desired
1. [Dead-letter](https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-dead-letter-queues) queue is available as OOB feature in Azure Service Bus. For complex design, you can create or control dead-letter queues to manage how messages forward there through the integration logic

You'll now need to push messages to this queue as well as implement a listener that is able to read from the queue.

Dynamics 365 integrates with Azure Service Bus via creating an Azure-aware Plug-in which is capable of passing the execution context to Azure Service Bus either synchronously or asynchronously. This capability facilitate outbound integration from Dynamics 365 to external applications via Azure Service Bus for secure and reliable integration. More information about this approach can be found [here](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/azure-extensions).

We recommend using Azure Logic Apps or Azure Functions as listener as both provide trigger integration with Azure Service Bus and can support activities such as peek or complete.


## General Application Scenarios
Typical application of this pattern can be found for guaranteed delivery based integration or when message delivery reliability is a key to a successful integration design. This integration pattern is typically considered Asynchronous in which the sender will send a message to be stored without a commitment from the receiver to process the message in an immediate time. Also if the receiver is not available or blocked due to some technical error, the message is still stored safely until when the receiver is ready to receive it.
