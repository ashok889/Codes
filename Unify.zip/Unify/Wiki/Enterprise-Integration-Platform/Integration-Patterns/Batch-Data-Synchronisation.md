<h1>Batch Data Synchronisation</h1>

In the case of an integration where the data needs to be synchronised between Dynamics 365 and a remote system in a periodic manner, a periodic scheduled batch can be created to process the details via a data entity and an exchange protocol. In this pattern, one system will batch a group or records based on business logic (i.e. approved records since last successful sync timestamp) and send it another system for data synchronisation and further processing logic. File exchange either in CSV, JSON or XML format is a typical implementation of such pattern although other approached can be considered dependant on the technology used and available APIs.

[[_TOC_]]

## Illustration
The sender prepares batch or records (1) periodically (i.e. daily) usually in a form of file or stored in a database table. Then the batch is sent (2) to a receiver to start processing the required logic (3, 4, 5). Optionally and for better integration design, the receiver can update back the sender (6) about the faith of the batched records and usually issue a flag or an indicator that the records have been processed successfully.

![batch-data-sync.png](../images/batch-data-sync.png)

Based on the business need, this integration pattern can be designed as an asynchronous interface. The considerations include business need, volume and mode of communication.

## Technologies Used
The most common tools or technologies used in this pattern are:
- Logic Apps/Azure Functions
- Azure Service Bus
- OneDrive for Business to store the files

## Recommendations and Implementation Practices
- Use this pattern when you need to send large dataset daily or more regularly. This could be the end of the day transactions or newly submitted cases
- Some external applications (i.e. mostly banks and financial institutions) demand data to be stored in a file and formatted based on an agreed format usually published by them and available to developers. They'll run checks on the file format to ensure data is structured properly
- Ensure files are stored on a secure shared network drive or in OneDrive for Business and only the authorised application's service accounts have the read/write rights to those folders
- Once a file is processed, do not delete and rather move it to an archived completed folder
- Create a dead-letter folder for errors or corrupted files
-  Always ensure to run a validation check prior to processing the file. Never assume the file is already correct
- It is a recommended practice to notify the sender (if possible) about the faith of the records processed by a particular batch. Usually, a token or ID is sent back to the sender along the batch identification number in order for the sender to update its internal database. This is also needed for reconciliation and troubleshooting issues
- Aim to offload any validation, transformation or cleansing outside of Dynamics 365 and should be addressed in the integration layer
- If possible, ensure to process the batch (generating or importing) overnight or outside of business hours.

To implement this pattern, you can use any technology or the application itself to group records into files or batch them as per agreed communication protocols. Such agreement should be established and signed-off at the beginning of the integration project development. Any changes to the file schema needs to be communicated.

Azure Logic Apps can be used in this pattern. You can configure a timer based trigger and when it runs, it should fetch the required records based on business rules and then generate a file (i.e. TXT, CSV, XLS, XML, JSON..etc. to name few of the file formats commonly used). Logic Apps can also push the file to OneDrive for Business or to an external network drive accessible by the Logic Apps.

Azure Logic Apps supports a trigger from OneDrive when a file is added or updated. It can access the file, parse it and move it or rename it as desired.



## General Application Scenarios
This is typically used when large volume of records needs to be processed and synchronised periodically. Usually this pattern is used in transactional communication between financial systems in which one system might submit financial statements in a file for other system to process overnight.