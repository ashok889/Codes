<h1>Process Integration Pattern</h1>

This pattern usually is executed by an integration middleware that orchestrate set of steps, actions and conditions to perform various business process rules or logic. The steps can integrate with various systems via out of the box connectors or other means (i.e. APIs).

[[_TOC_]]

## Illustration
Use a central processing unit, a Process Manager, to maintain the state of the sequence and determine the next processing step based on intermediate results.

A process manager/controller will execute steps in a pre-configured order with certain conditions and branching logic and might interface with external systems (1-4) to pull or push data as needed per the business logic.

![process-integration.png](../images/process-integration.png)

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Logic Apps
- MS Flow

## Recommendations and Implementation Practices
We recommend using Azure Logic Apps for orchestrating the integration steps and connecting to various systems. Azure Logic Apps is a powerful workflow engine that has several connectors allowing the administrator to interact with various systems. For Dynamics 365, it supports triggers like when a record is creates, updated or deleted in Dynamics 365, it can invoke the Logic Apps logic to begin processing the logic and will have access to the record context from within the flow.

These are some high level considerations:
- Use this pattern when doing transformation jobs or translating Reference Data by checking against a pre-defined list that could be stored externally, in the Data Platform or in a Common Data Model layer
- Use this pattern when processing long running jobs or if you want to retrieve records and process one at a time through some orchestrated logic
- Always aim to use the out of the box connectors because they have been tested and are supported by Microsoft or 3rd party providers
- Usually such pattern is considered in situation that requires sending emails as confirmation or a notification about validating some business rules.

**Note**: Although we recommend to use connectors if applicable, there are situations in which using direct web calls are more preferable. For instance, we can use the out of the box Dynamics 365 connector to create a student record is one step, then create a report in another, create a school and we have to link these. If we want to add siblings or parents then we'll have to do them individually because the connector supports creating records in an individual transaction. This might be Ok for some cases but you want to ensure transactional commit is met and if any error then the platform should rollback (i.e. do not create the report record if there is an error while creating the student record). In this case, we can have a single step to issue a batched Web API call to Dynamics 365. In this approach, the Logic Apps will only push one request (a batch) to Dynamics and can preserve the transactional integrity and atomicity of the transaction.


## General Application Scenarios
This pattern is usually used to orchestrate certain repeatable actions that might be trigger based and will need to communicate to multiple systems. The chosen middleware must be able to support branching, sequencing and parallel runs as well as being able to apply conditions, loop through records and call custom actions. Also it is crucial for such system to have various connectors that can send/receive commands to various systems.

MS Flow and Logic Apps are typically used in such pattern. It is often you'd mix this pattern with others for a more complete integration end-to-end logic. For instance, one of the steps might push a message to a message queue while another is about synchronising the data with a target system based on a pre-defined data map.

Below is an example of MS Flow logic that is triggered every time a tweet is posted in Twitter and will process the actions as per business needs.

![msflowsample.png](../images/msflowsample.png)

It is important to be able to design such workflow with scalability in mind and being able to run them in parallel. This might not always be possible but it is recommended if no dependencies are established between the source records. For instance, you can have Logic App that process new transactions every minutes. If the transaction volume is high, the logic in the Logic App might take more time to complete before the minute is over which will result in another instance of the Logic App to execute and might re-process some of the remaining records and result in duplicates in the target system. It is better to implement some paging or a mechanism to prevent same data from being processed twice. If the Flow or Logic App is triggered based on event, then usually this problem will be avoided. 