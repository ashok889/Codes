<h1>Asynchronous Update</h1>

Asynchronous Update pattern is about achieving an orchestration between 2 systems without the need for the sender to await the receiver to fully complete its processing logic. In this pattern, the sender will send a request and will get an immediate acknowledgement about the request whether it was successful or denied. The receiver will need to acknowledge whether the message has been received successfully as well as if it passes any basic validations. However, any prolonged logic or process will be parked for a later execution. At this stage, the sender is able to progress its internal application logic without the need to wait for the receiver to fully process the message and the required integration logic. This pattern is useful when the receiver needs to process a long running logic and the sender does not have to wait to receive the outcome.

[[_TOC_]]

## Illustration
Sender will send a message (1) and the integration logic will acknowledge its recipient (2) then the integration pipeline will start processing the message (3) separately through delivering it to the receiver (4) and completing its intended action (5) 

![async-send-and-receive.png](../images/async-send-and-receive.png)

Note that after step (2) in the diagram, the sender will be able to complete any required internal logic irrespective of the outcomes of the subsequent integration steps.

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Functions
- Azure Logic Apps
- Azure API Management

It is recommended to use **Azure Logic** Apps over Azure Function when possible to implement business logic that needs orchestration. Azure Logic Apps provides: 
- An easy to use with drag-and-drop wizard designer and support connectors for hundred of sources
- It is quite a powerful technology and yet still configurable and can implement conditional branching, looping and retry mechanisms. 

However, if the Azure Logic Apps fails to deliver a particular functionality due to a limitation in the connector or logic is too complex, then **Azure Functions** should be used which can be invoked from within the Azure Logic Apps direction. In Azure Function, it is recommended to implement in C# Code and usually it is more flexible and normally can fulfil such limitations within Azure Logic Apps but it is harder to maintain and requires development skills. Keep Azure Functions small and modular. They are best used when receiving an input, processing a logic and producing an output back to its caller. Refrain from using long running processes or logic that orchestrate various steps and integrate with multiple systems. Azure Logic Apps is better used for such scenarios. Both technologies, if used together and properly, can achieve most complex business integration logics. 

## Recommendations and Implementation Practices
This type of integration patterns is **highly recommended** to consider in most integration designs because it facilitates the following criteria:
- Decoupling of applications. External applications will not need to know about the design components within internal systems
- Performance due to the sender will not need to await the receiver to process the logic
- Usually this pattern is used in conjunction with Message Queueing by implementing an Azure Service Bus or some queueing mechanism to store the message and defer the processing to a different integration layer. Such design is used when guaranteed message delivery is a key
- Reliability and high availability if used with Message Queueing as mentioned in the previous point. If the receiver is not available to process the message, then the sender is not affected.

To implement this pattern, the DCSYW can expose an API that is capable of receiving incoming requests via HTTPS and usually supply message details in a JSON object format as part of the POST data message body. This API endpoint can be implemented through Azure API Management and can call either Azure Logic App or via Azure Functions for the actual logic implementation of the endpoint. Both those technologies is capable of exposing an HTTPS trigger in which the API Management will invoke. This is the step by step recommended implementation practices:
1. Create an API endpoint through Azure API Management
1. Select Azure Logic Apps as the endpoint for the above step
1. Implement the validation business logic in Azure Logic Apps. If there's a limitation in the logic, implement and call an Azure Function to fulfil the logic by passing the data as input and await the function to return the result.
1. If reliable integration is required, then Azure Logic Apps can store the message to Azure Service Bus. Alternatively Azure Logic Apps can asynchronously invoke the receiver or another business processor layer. This call has to be asynchronous or in a parallel branch.
1. Finally, Azure Logic App will return a response back to the sender with the outcome of the request (either passed or failed) as a form of acknowledgment.

**Note**: The Azure Logic App needs to respond back to the sender without the need to await the async call in step (4) above to fully process its logic. If Azure Service Bus is used, then as soon as the message is stored in the queue, the request should be considered as completed.


## General Application Scenarios
This pattern is typically used in integration logic in which the receiver of the message requires to run prolonged operations without the need for the sender to await the completion of these operations. Additionally, this pattern is applicable if the sender is able to fire and forget. In another word, the sender is able to send a message but the message outcome isn't important or what will happen to the message is up to the receiver as long as the integration logic can acknowledge its recipient. 

Alternatively, if the processing logic can be deferred to a background process or when real-time integration is not required, then this pattern should be followed. This pattern is not suitable for transactional requests or if the entire logic should be completed otherwise a rollback should be issued. 

Typically, this type of pattern is suitable for integrating external systems in which dependencies between such systems should be kept to minimum or eliminated altogether.

When this pattern is combined with Message Queuing pattern to store the message prior to sending it to the Receiver, the  guaranteed delivery quality will be met.
