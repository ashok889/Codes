<h1>Synchronous Update</h1>

Synchronous Update pattern is about achieving an orchestration between 2 systems in which the sender will need to await for the receiver to fully complete its processing logic. Unlike the Asynchronous Update pattern, the sender will need to await a fully completed acknowledgment from the receiver that the message is fully processed and all logic is completed instead of only accepting the message. It means the sender will have to await the receiver to fully complete its processing logic and receive a completed response prior to executing further application or business logic. This pattern is important when the sender is dependent on the logic executed by the receiver to fully complete and commit the transaction.

[[_TOC_]]

## Illustration
Sender will send a message (1) and the integration pipeline will start processing the intended logic (2) by the receiver (3) and await for the logic to complete (4) before it signals the acknowledgment and message processing completion back to the sender (5)

![synch-send-and-receive.png](../images/synch-send-and-receive.png)

During the above logic and after step (1), the sender will be awaiting the entire process to be completed. This is useful if the sender is awaiting some values to be sent back by the receiver prior to completing any required internal logic.

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Functions
- Azure Logic Apps
- Azure API Management

It is recommended to use **Azure Logic** Apps over Azure Function when possible to implement business logic that needs orchestration. Azure Logic Apps provides: 
- An easy to use with drag-and-drop wizard designer and support connectors for hundred of sources
- It is quite a powerful technology and yet still configurable and can implement conditional branching, looping and retry mechanisms. 

However, if the Azure Logic Apps fails to deliver a particular functionality due to a limitation in the connector or logic is too complex, then **Azure Functions** should be used which can be invoked from within the Azure Logic Apps direction. In Azure Function, it is recommended to implement in C# Code and usually it is more flexible and normally can fulfill such limitations within Azure Logic Apps but it is harder to maintain and requires development skills. Keep Azure Functions small and modular. They are best used when receiving an input, processing a logic and producing an output back to its caller. Refrain from using long running processes or logic that orchestrate various steps and integrate with multiple systems. Azure Logic Apps is better used for such scenarios. Both technologies, if used together and properly, can achieve most complex business integration logics. 
	
## Recommendations and Implementation Practices
This pattern is still recommended but aim to consider the Asynchronous Update pattern first. This pattern is able to provide prompt and guaranteed response back to the sender but will have the following considerations/limitations:
- Performance considerations because the sender will need to await the receiver to fully process its logic. Performance will be impacted if the receiver is currently under a heavy processing load by another process
- Reliability is an issue if the receiver is offline or unavailable to process the request (i.e. under heavy processing load)

However, this pattern is still useful if the sender relies on the message outcome. For instance, The sender wants to check if a student record exist in the system and if so then get the unique identifier before processing this information further. In this example, the sender will need to fully await the receiver to query its internal database and provide a response whether the student record exist or not along the unique identifier.

Another typical and recommended usage of this pattern is when transaction property is a key. For example, when the Business API (sender) logic needs to commit student and report details into Dynamics 365 (receiver), it will synchronously communicate to Dynamics 365 and will need to await the transaction to fully complete otherwise it will need to issue a rollback procedure and undo the request or retry.

To implement this pattern, the DCSYW can expose an API that is capable of receiving incoming requests via HTTPS and usually supply message details in a JSON object format as part of the POST data message body. This API endpoint can be implemented through Azure API Management and can call either Azure Logic App or via Azure Functions for the actual logic implementation of the endpoint. Both those technologies is capable of exposing an HTTPS trigger in which the API Management will invoke. This is the step by step recommended implementation practices:
1. Create an API endpoint through Azure API Management
1. Select Azure Logic Apps as the endpoint for the above step
1. Implement the validation business logic in Azure Logic Apps or in Azure Function.
1. Immediately after start processing the intended business logic. For instance, if it needs to retrieve data from Dynamics 365, then it should immediately start calling Dynamics 365 endpoint (or via the Business API layer as per recommendation).
1. Finally, Azure Logic App will receive an outcome from the previous step and will return a response back to the sender with the outcome of the request (either passed or failed) as a form of acknowledgment.

**Note**: this pattern differs from Asynchronous Update in step (4) in which the Azure Logic App will need to respond back to the sender only after when it completed processing (i.e. talked to Dynamics 365 platform). Typically Azure Service Bus is not required or not used in the implementation of this pattern because the response cannot tolerate to await a queueing mechanism.


    
## General Application Scenarios
This pattern is best suited if the Receiver doesn't need to process prolonged operations and can quickly finish any required task and send a response back immediately (preferably under a second). Also if the Sender is dependent on some output values or some calculation results as a result of the receiver processing logic, then this pattern is recommended to follow. 

Alternatively, if real-time or near real-time integration is required or is a key criteria of the integration design, then this pattern should be followed. Most importantly, the entire transaction orchestration can be treated as one transaction and thus if there is any failure in the logic, the entire process can be rolled back. 
