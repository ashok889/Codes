<h1>Publish and Subscribe</h1>

It has one input channel that splits into multiple output channels, one for each subscriber. When an event is published into the channel, the Publish-Subscribe Channel delivers a copy of the message to each of the output channels. Each output channel has only one subscriber, which is only allowed to consume a message once. In this way, each subscriber only gets the message once and consumed copies disappear from their channels.

[[_TOC_]]

## Illustration
A publisher will publish a message or an event (1) from one side while a number of subscribers will be able to receive the message or event (2) and act on it. Each subscriber will get the same copy of the published message

![publish-subscribe.png](../images/publish-subscribe.png)

The Publisher creates a message in a published format and pushes it to a message queue, which will have one or more Subscribers.  The Subscriber will read the message queue to retrieve the published message from the queue. The pattern provides a way of decoupling the Publisher and Subscriber and provides greater scalability than the Event-Driven Consumer pattern. 

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Event Hub
- Azure Service Bus (topic feature)
- Publisher: Dynamics 365 Plug-in or Custom Workflow Activity via webhook
- Subscribers:
  - Azure Logic App/MS Flow
  - Azure Functions

### Azure Event Hub
Azure Event Hubs is a relatively new feature within the Azure Service Bus and is intended to help with the challenge of handling an event based messaging at huge scale.  The idea is that if you have apps or devices publishing telemetry events then Event Hubs can be the place you would send them to and behind the scenes the Event Hub will create a stream of all of these events which can be read at some point in different ways.

Event Hubs provides simple interfaces such as AMQP and HTTP to make it easy for apps to send messages to an Event Hub.  Internally Event Hubs implements a partitioning pattern to allow it to scale to deal with huge bursts of messages and to retain messages for a longer period of time.

In Event Hubs you can define consumer groups which allow you to read the stream of events.  If you only need one receiver to read the stream then you can use the default consumer group, but if you need multiple receivers to read the stream concurrently but at their own rate then each receiver would use its own consumer group.  A receiver will also manage an index (or off set) which is its own pointer to where in the stream of messages it is reading.  A receiver can start at the beginning of the stream and read to the end and then wait for new events or alternatively it can start reading part way through the stream.

The below diagram shows what Event Hubs might look like:
![azure-event-hub.png](../images/azure-event-hub.png)

## Recommendations and Implementation Practices
We recommend using Azure Service Bus as the central queueing system for the integration platform. You can still implement the Publisher and Subscribe pattern with Azure Service Bus by using the topic approach. Alternatively you can use Azure Event Hub but best to stay with one technology for easier maintenance and operational support.

Additionally, you can implement this pattern in Dynamics 365 context via the use of the new **webhook **registration capability introduced in Dynamics 365 v9.0. You can send data about events that occur on the server to a web application using webhooks. Webhooks is a lightweight HTTP pattern for connecting Web APIs and services with a publish and subscribe model. Webhook senders notify receivers about events by making requests to receiver endpoints with some information about the events. Click [here](https://docs.microsoft.com/en-us/dynamics365/customer-engagement/developer/use-webhooks) to learn more about how to use and configure a webhook endpoint which can be invoked from within Dynamics 365 events.

To implement this pattern, follow these steps:
1. Create Azure Service Bus or use an existing instance
2. Navigate to Topics and Create a topic
3. Inside each topic, you can create one or more subscription. Create at least one.

Follow this [article](https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-quickstart-topics-subscriptions-portal) to see screenshots for the above process. You can see sample of how to send a message to a topic as well as receive the message from the topic's subscription [here](https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-dotnet-how-to-use-topics-subscriptions).

## General Application Scenarios
This pattern is used when one system needs to issue an event and notify a number of subscribed services or system to process or act upon receiving the event. This pattern ensures a great decoupling between systems (publishers and subscribers) and can help to scale integration messages by increasing the list of subscribed systems without the need to alter the publisher.

The publish - Subscribe patterns is also known as Broadcast pattern. For a Dynamics 365 context, it is the act of moving data from Dynamics 365 to multiple destinations in real time or near real time scenarios. 

![publish-subscribe-broadcast.png](../images/publish-subscribe-broadcast.png =600x350)

This pattern is incremental in nature in which if Dynamics 365 raises an event (i.e. via a plugin or workflow), it will only push the new changes to an enterprise service bus for subscribers to consume. If any subsequent change to a dataset occur, only the changes will be pushed. In another word, it does not execute the logic of the message processors for all items which are in the dataset, rather it does it only for those items that have recently added/changed since last broadcast run. 
