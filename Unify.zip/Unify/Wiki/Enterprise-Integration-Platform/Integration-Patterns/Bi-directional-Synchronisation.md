<h1>Bi-directional Synchronisation</h1>

Bi-directional sync is the act of joining two datasets in two different systems to behave as one while respecting their need to exist as different datasets. The main driver for this type of integration need comes from having different tools or different systems for accomplishing different functions on the same data set. For example, you may have a system for taking and managing orders and a different system for customer support. For one reason or another, you find that these two systems are best and is important to use them rather than a suite which supports both functions and has a shared database. Using bi-directional sync to share the dataset will enable you to use both systems while maintaining a consistent real time view of the data in both systems.

> Use this pattern with caution. Better to avoid it entirely for complex synchronisations. Aim to use Data Exchange instead.

[[_TOC_]]

## Illustration
A change occurs in System A (1) which gets synchronised to system B (2). Same thing might happen in System B in reverse. The data can either synchronised directly or is pushed to a common data model.

![bi-directional-sync.png](../images/bi-directional-sync.png)

**Example**
For example a salesperson should know the status of a delivery, but they don’t need to know which warehouse the delivery is at. Similarly the delivery person needs to know the name of the customer that the delivery is for without needing to know how much the customer paid for it. Bi-directional synchronisation allows both of those people to have a real-time view of the same customer within the perspective that they care about.

## Technologies Used
The most common tools or technologies used in this pattern are:
- Azure Logic Apps
- Azure Functions
- Common Data Services (Common Data Model)  

## Recommendations and Implementation Practices
This pattern has lots of challenges and some of them are business challenges rather than technical. **It is best to avoid this pattern**. Before you implement it, consider the following situations:
- Not all systems or enterprise businesses would want data to magically update without a layer of notification or approval. Implementing such layer would complicate the design of this pattern
- Which system is the master of truth for the data? which system can update what data and what to sync? Creating a mapping schema and a pre-defined agreement is necessary but this is difficult for complex synchronisation scenarios
- How to resolve conflicts? what will happen if both systems update the same source of data?
- Complexity is increased with more endpoints participating in synchronising data

Still, you can implement this pattern by using following steps:
1. Create an Azure Logic App that is listening to an event or is timer based and will fetch changes from a source system. This logic app will only function as a trigger
2. Create another Azure Logic App to function as a middleware for any transformation logic required. This can be done in the previous logic app but if a transformation layer exists in the integration platform, then it is best to utilise it
3. Create A receiver Logic App that will push the data to the target system
4. You can add an Azure Service Bus for asynchronous and reliable synchronisation but again will increase complexity
5. Use Azure Data Factory as an ETL layer if the integration synchronisation is complex.

**Note**: the above implementation demonstrate how to sync in one-way. It needs to be repeated and mirrored to support a bi-directional synchronisation.

For more systems, create a Common Data Model instance to store the data centrally. Apply any business rule or approval at this layer if necessary.

Also synchronous integration will cause performance issues. Aim to use Asynchronous implementation by using Message Queueing or Publish and Subscribe patterns


## General Application Scenarios
The need, or demand, for a bi-directional sync integration is synonymous with wanting object representations of reality to be reliable and consistent. For example, if you want one view of your customer, you can solve that manually by giving everyone access to all the systems that have a representation of the notion of a customer. With that solution you can achieve one view of the customer at the expense of productivity, training, security, and cost. A better solution to the same problem is to list out which fields need to be visible for that customer object in which systems, and which systems are the owners of those. Most enterprise systems have a way to extend objects such that you can modify the customer object data structure to include those fields. Then, you can create integration applications either as point to point applications (using a common integration platform) if its a simple solution, or a more advanced routing system like a publish/subscribe or queue routing model if there are multiple systems at play. With this approach you can achieve a state where each user who deals with customers in various systems can have their own view of the customer with only the information that is relevant to them.

However, sometimes the complexity and maintenance overhead due to the synchronisations conflicts and business governance might make it harder to implement such pattern.

Use this pattern when data related to the same party needs to reside in multiple systems but still needs to be kept up to date. The DCSYW might store the person/child data in multiple systems (i.e. ICMS, Dynamics 365, SQL database...etc.) so this pattern will ensure that any update in one system can be reflected to the others promptly. 

It is recommended to use the Message Queueing pattern along this pattern to stage the updates into a queue for reliable data sync in case the target system is offline.

The Common Data Service (CDS) can be used for more complex scenarios to store the base core record (master of data) while all other systems can push its updates to CDS and then CDS will forward the requests to the remaining target systems.

Some governance might be required and a data map needs to be established to agree on which fields needs to be updated in the target systems when an update occur in the source system. A notification or approval mechanism might also be used if needed by the business (i.e. if the person's address has changed, you might not want to automatically update the target system with the new address and rather get it approved by the case officer).