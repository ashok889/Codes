# Common Integration Design Issues with Dynamics 365

The following is a list of the common integration design issues and their considerations:

### Treating Dynamics 365 as an infinitely scalable black box
  - Often a misconception but can be an excuse for inadequate consideration to integration data flows/process
  - Using tools that provide D365 connectors without understanding the underlying implementation of the tool
  - Designing the integration based on least coding rather than least processing
  - Not paying consideration to the underlying SQL query complexity and duration of transaction scope

### Using Dynamics 365 to conduct heavy processing
  - Regularly see preference to offload transformation processing into D365 instead of within the ETL/Middleware tool…
  - Sometimes see Custom Actions used to orchestrate integration business processing
  - Sometimes see plug-ins used to “reject” unchanged record updates
  - Frequently see complex and heavy queries used to retrieve data as part of the integration process

### Storing unnecessary data in Dynamics 365
  - Often perceived to be required for read-only access or reporting-only purposes
  - Sometimes used to “simplify” integration mapping to a back office system
  - Leveraging D365 as the User Experience to “front” a back office system directly
  - Sometimes used to “stage” data in D365 before transforming and loading into real D365 entities

### Using Dynamics 365 as if it is a Data Warehouse
  - Typically the reason behind storing unnecessary data within D365 but has additional implications
  - Reporting results in expensive queries against D365 that can impact both users and integration scenarios
	
