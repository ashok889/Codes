<h1>Integration Delivery Strategy</h1>

As more and more systems are making it easy to connect often integrations are developed in silos and then get difficult to manage. The organisation's current IT landscape is the result of many years of growth, acquisitions and now requires consolidation to reduce complexity and build agility. Adopting a strategy towards delivering the integration in a planned and controlled manner is important to restrict the complexity of Integration platform.

In this topic we'll discuss the following strategies:

[[_TOC_]]

## Systematic Integration
The goals of systematic integration are to gain economies of scale, and maintain control over IT architecture complexity. Economies of scale are achieved by having a single dedicated team that treats integration as a product. It will build up a deep understanding of DCSYW systems over time, removing weeks of tacit knowledge loss with a project approach. The team is highly skilled in integration technology, and has well established processes optimised for efficiency, for example analysis techniques, automated build, test and deployment pipelines. 

The team is organised around an enterprise integration backlog. The backlog is prioritised by collaboration between business stakeholders and enterprise architecture. The team can predict when things will be done by using scrum techniques such as story points and velocity. DCSYW can use this predictive data to scale the integration team accordingly. 
A permanent cross-functional team operating as a shared-services function supporting multiple organisational units and sustaining integration solutions in a coordinated manner. **We recommend DCSYW to adapt to Systematic integration approach and run a centralised integration team to deliver the integration**.

![systematic-integration.png](./images/systematic-integration.png)

## Adaptive Integration
The goals of adaptive integration are to optimise for time to deployment and enable innovation without disrupting the systematic approach. DCSYW needs to be responsive to changes in the market and be able to get new processes integrated quickly. Most of these initiatives are funded by projects outside of the central IT budget and do not want to held back by the backlog of the systematic integration team. There is therefore a need to allow other vendors and teams to be able to integrate on their own. 

![adaptive-integration.png](./images/adaptive-integration.png)

A good example of adaptive integration is stringing together some existing APIs to a new third party API in order to perform some straight through automation. API Management technology is a key enabler for adaptive integration.

There are of course challenges with this approach, as these lighter weight integration solutions tend not to offer the same capabilities as the systematic team. This can cause some of these solutions to miss some non-functional requirements such as resilience, error handling and disaster recovery. It may also start to create a proliferation of point-to-point solutions that inhibit DCSYW ability to adapt due to the increase in complexity. There is also the challenge of reuse. If each project develops integration artefacts in isolation, they will rarely reuse each other’s technology or services. All of these challenges can of course lead to increased IT debt that will just keep accumulating if not addressed.

The adaptive integration is supported and facilitated, not controlled by the Systematic central team. This team drives economy of scale across many projects by being aware of what is going on, and providing a service to the projects. The team provides are repository of self-service tooling, reusable integration assets, templates and suggested standards. The team will encourage the architecture principles of micro services for each adaptive integration. Some of the adaptive integrations may also be transitioned into the systematic integrations over time to control the technical debt.

## Error Handling Strategy  
Designing with failures in mind is essential to the proper functioning of the platform. While there are several aspects to failure tolerance such as – lowering time to recovery, avoid single points of failure, failure mode analyses, and fault injection, this strategy document focuses on how we handle exceptions which is one component of proper design for fault tolerance.

Exceptions are used as a technique of last resort because of a failure that cannot be handled and not for control flow.
 
### Exception handling considerations
Exception shielding. Ensure that sensitive information does not ‘leak’ out of the platform. There could be certain technical details which get attached to error, should be logged and not necessarily shown to users.

### Exception logging
important information about exceptions should be logged. The information logged should be sufficient enough to understand the error and trace the source of error and troubleshoot the issue. 
 
### The reason why we need to log
- One way to gain insight about what is happening inside the integration platform
- Pro-active mechanism to diagnose problems
- Allow troubleshooting in production.
 
### What to log
- “Enough” to know what the problem is
- Hard to know ahead of time
- Common useful items:
  - What operation we are doing 
  - Date/time/duration information
  - Success/Error status
  - Details about error
  - Thread id - Ability to track down to a single request for overlapping requests.

### Retention of logs
Keeping logs for a long time helps with troubleshooting issues but mainly can be used for analysis and building some application insights. However take into considerations the following implications:
- Storage costs
- Performance - logging should be a simple and quick process
- Polluting good information

We recommend that logs to be archived and can be stored in Azure Blob for instance for a later access. The retension schedule should be discussed and agreed internally by the business and IT team to consider when to archive and when to destruct the archived logs.

 
## Retry Strategy
### Determine an appropriate retry count and interval
It is vital to optimise the retry count and the interval to the type of use case. If you do not retry enough times, the integration platform will be unable to complete the operation and is likely to experience a failure. If you retry too many times, or with too short an interval between tries, the integration platform can potentially hold resources such as threads, connections, and memory for long periods, which will adversely affect the health of the application.

The appropriate values for the time interval and the number of retry attempts depend on the type of operation being attempted. For example, if the operation is part of a user interaction, the interval should be short and only a few retries attempted to avoid making users wait for a response (which holds open connections and can reduce availability for other users). If the operation is part of a long running or critical workflow, where cancelling and restarting the process is expensive or time-consuming, it is appropriate to wait longer between attempts and retry more times.

### Determine if the operation is suitable for retrying
We should only retry operations where the faults are transient (typically indicated by the nature of the error), and if there is at least some likelihood that the operation will succeed when reattempted.

Consider implementing error codes and messages that will help clients determine whether they should retry failed operations.

### Avoid anti-patterns
Should avoid implementations that include duplicated layers of retry code. Avoid designs that include cascading retry mechanisms, or that implement retry at every stage of an operation that involves a hierarchy of requests, unless you have specific requirements that demand this.

Never implement an endless retry mechanism.

Never perform an immediate retry more than once.

## High Availability 
### Availability
System availability is the measure of the percentage of a time window the system will be able to operate. The more moving parts within the system, the more care you must take to ensure the application can resiliently meet the availability requirements of its end users. You must plan for all services to potentially go down at different times, thus planned downtime should be added for all services involved to get overall downtime.

### Scalability
A scalable system scales horizontally or vertically to manage increases in load while maintaining consistent performance. In basic terms, horizontal scaling adds more machines of the same size (processor, memory, and bandwidth), while vertical scaling increases the size of the existing machines.

### Fault Tolerance
A fault tolerant application detects and manoeuvre’s around failed elements, to continue and return the correct results within a specific timeframe. Fault tolerant applications can use one or more design strategies, such as redundancy, replication, or degraded functionality.

| Components/Services |	SLA | Notes |
|--|--|--|
| Logic App  | 99.9% Uptime  | [SLA for Logic Apps](https://azure.microsoft.com/en-in/support/legal/sla/logic-apps/v1_0/)  |
| API Manager | 99.9% Uptime*  | [SLA for API Management](https://azure.microsoft.com/en-in/support/legal/sla/api-management/v1_0/)  |
| Azure Functions | 99.95% Uptime  | [SLA for Azure Functions](https://azure.microsoft.com/en-in/support/legal/sla/functions/v1_0/)  |
|Key Vault  | Assuming 99.9%  |  [SLA for Key Vault](https://azure.microsoft.com/en-us/support/legal/sla/key-vault/v1_0/) | 		
**Standard Tier deployments. No SLA is provided for the Developer tier of the API Management Service. DCSYW is responsible for Architecting and implementing High Availability of Integration platform*

## Disaster Recovery 
A cloud deployment might cease to function due to a systemic outage of the dependent services or the underlying infrastructure. Under such conditions, a business continuity plan triggers the disaster recovery process. This process typically involves both operations personnel and automated procedures in order to reactivate the application in an available region. This requires the transfer of application users, data, and services to the new region. It also involves the use of backup media or ongoing replication. Disaster recovery to another region is a complex task that typically involves some downtime and potential loss of data.

### Architecting DR Strategies 
Architecting a solution with DR is just a small portion of overall strategy for business continuity, following aspects should be considered for HA and DR: 
- Implement disaster recovery plans and processes  
- Consider failures that span the module level all the way to a complete cloud outage  
- Establish backup strategies for all reference and transactional data  
- Choose a multi-site disaster recovery architecture  
- Document the processes so they are easily repeatable  
- Train the staff to implement the process  
- Use regular disaster simulations for both training and validation of the process  

To architect a solution with DR design, at minimum following information is required: 
**Recovery time objective (RTO)** : The RTO is the maximum amount of time allocated for restoring application functionality. This is based on business requirements, and it is related to the importance of the application. Critical business applications require a low RTO. 

**Recovery point objective (RPO)** : The RPO is the acceptable time window of lost data due to the recovery process. For example, if the RPO is one hour, you must completely back up or replicate the data at least every hour. Once you bring up the application in an alternate region, the backup data may be missing up to an hour of data. Like RTO, critical applications target a much smaller RPO.

Usually cost of implementing DR is inversely proportional to values of RTO and RPO. Essentially, lower the RTO and RPO higher the cost to implement and maintain the DR site. 

Usually it is the DCSYW responsibility for architecting and implementing Disaster Recovery Plan for an Integration platform.

## Audit Management
The following are the high level considerations for the audit management capability of the integration platform:
- All transactions need to be audited and logged
- The **Payload message** should be logged in the **Data Platform** and securely stored along with a key identifier for traceability
- Azure Monitor can be used to provide a view of all running integration components and access to run logs for individual applications. Ensure to apply the logging standards mentioned under the [Monitoring and Alerting](./Monitoring-and-Alerting.md) section.


