<h1>Monitoring and Alerting</h1>

Getting a 360-degree view of integration applications, infrastructure, and network with advanced analytics, dashboards, and visualisation maps are key metrics when monitoring an enterprise integration platform which provide proactive issue resolutions. Issue alerting or notifications should be incorporated into the integration platform for prompt responses to issues when they occur.
 
[[_TOC_]]

## Integration Monitoring Technologies
There are lots of components playing integral parts in any integration platform at an enterprise scale. A good monitoring tool is recommended to be used across the program to oversee the entire platform and respond to issues promptly. For Azure and cloud monitoring, two leading tools should be considered: Azure Monitor and Azure Application Insights.

### Azure Monitor
Azure Monitor provides advanced analytics and machine learning to monitor application performance; proactively identify issues and automatically respond to alerts; analyse, correlate, and monitor data from various sources using a powerful query language and built-in machine learning constructs. With Azure Monitor you can use anomaly detection and predictive analytics for various applications to easily turn data into actionable insights. For more information visit: https://azure.microsoft.com/en-us/services/monitor/

### Azure Application Insights
Application Insights is an extensible Application Performance Management (APM) service for web developers on multiple platforms. Use it to monitor your live web application. It will automatically detect performance anomalies. It includes powerful analytics tools to help you diagnose issues and to understand what users actually do with your app. It's designed to help you continuously improve performance and usability. For more information visit: https://docs.microsoft.com/en-us/azure/azure-monitor/app/app-insights-overview


## What to Monitor?
 
**API Management:**
Use Azure Monitor to enable logging for API Management. It will push the data to OMS Log Analytics. 
Azure Monitor -> Diagnostics Settings -> APIM Resource -> Add diagnostic settings.

![api-management-monitor.png](./images/api-mgnt-monitor.png)

**Key Vault:**
Use Azure Monitor to enable logging for Key Vault. It will push the data to OMS Log Analytics. 
 Azure Monitor -> Diagnostics Settings -> Key Vault Resource -> Add diagnostic settings.

Additionally, if needed Enable the Azure Key Vault solution from Azure Marketplace. This will add Azure Key Vault solution in Log Analytics to review Azure Key Vault AuditEvent logs.

**Service Bus:**
Use Azure Monitor to enable logging for Service Bus. It will push the data to OMS Log Analytics. 
Azure Monitor -> Diagnostics Settings -> Service Bus Resource -> Add diagnostics settings.


**Azure Functions:**
Install and enable Application Insight configuration for Azure Function. Then install Application Insights connector for OMS.
https://docs.microsoft.com/en-us/azure/azure-functions/functions-monitoring
Else we can use OMS Data collector API and write a function to ingest data to OMS directly.
 

**Azure Web Apps:**
Install and enable Application Insight configuration for Azure Web Apps. Then install Application Insights connector for OMS.
Alternatively, use OMS Data collector API and write a code to ingest data to OMS directly.

**Azure Logic Apps**
Use Azure Monitor to enable logging for Logic Apps. It will push the data to OMS Log Analytics. 
Azure Monitor -> Diagnostics Settings -> Logic Apps Resource -> Add diagnostics settings.

**Virtual Machines (VMs)**
Monitor the health of all of the virtual machines in Azure Monitor. Viewing the overall health state of the Azure VM and underlying operating system can be observed from two perspectives with Azure Monitor for VMs health; either directly from the virtual machine; or across all VMs in a resource group from Azure Monitor. Check this link for more info: https://docs.microsoft.com/en-us/azure/azure-monitor/insights/vminsights-health

## Alerting
Alerts in Azure Monitor can identify important information in your Log Analytics repository. They are created by alert rules that automatically run log searches at regular intervals, and if results of the log search match particular criteria, then an alert record is created and it can be configured to perform an automated response.

Check the following link for more info: https://docs.microsoft.com/en-au/azure/azure-monitor/learn/tutorial-response.


## Considerations
Here are several points to consider when designing and implementing health monitoring:
- Consider the type of information to collect in the service in response to monitoring requests, and how to return this information. You may need to create a custom monitoring system to validate additional information beyond the HTTP status code
- Consider how much information to collect and which information will require extra processing, which in turn may overload the service and impact users. The time it takes also may exceed the timeout of the monitoring system, and so the application is considered to be unavailable. Most applications include instrumentation, such as error handlers and performance counters that log performance and detailed error information, which may be sufficient instead of returning additional information from a health-monitoring check
- Consider securing the monitoring endpoints to protect them from public access, which might expose the application to malicious attacks and can potentially expose sensitive information; such public access also can lead to denial of service (DoS) attacks. Security can be coded into the application configuration so that it can be updated without restarting the application
- Do not expose sensitive data (i.e. usernames or passwords) in the monitored logs
- Use a hidden endpoint; for example, expose the endpoint on a different IP address from the default application or use a non-standard HTTP port
- Consider whether the monitoring agent is performing correctly. One approach is to expose an endpoint that simply returns a value from the application configuration, or a random value that can be used to test the agent
- Consider using a specific path for the health-verification check; for example, HealthMonitoring {GUID} will make it relatively easy to add new services and test the health monitoring for it.