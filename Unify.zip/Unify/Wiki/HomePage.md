<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
        <img src="https://docs.microsoft.com/en-us/media/common/i_get-started.svg" style="width: 90%" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FProgram%20Architecture&pageId=40&wikiVersion=GBmaster">Program Architecture</a>
                </font></b>
            </li>
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
        <img src="https://docs.microsoft.com/en-us/office/media/icons/blocks-blue.svg" style="width: 90%" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FMethodology%20And%20Approach&pageId=35&wikiVersion=GBmaster">Methodology & Approach</a>
                </font></b>
            </li>
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
        <img src="https://docs.microsoft.com/en-us/dynamics365/images/layout_outline_36px_blue.svg" style="width: 90%" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FData%20Management&pageId=8&wikiVersion=GBmaster">Data Management</a>
                </font></b>
            </li>
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
        <img src="https://docs.microsoft.com/en-us/dynamics365/images/layout_outline_36px_blue.svg" style="width: 90%" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FUnify%20Business%20Application%20Platform&pageId=48&wikiVersion=GBmaster">Unify Business Application Platform</a>
                </font></b>
            </li>
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
        <img src="https://docs.microsoft.com/en-us/azure/devops/_img/index/devopsicontestplans96.svg?view=vsts" style="width: 80%" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FEnterprise%20Data%20Platform&pageId=13&wikiVersion=GBmaster">Enterprise Data Platform</a>
                </font></b>
            </li>      
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
         <img src="https://docs.microsoft.com/en-au/dynamics365/images/dynamics-project-services.svg" style="width:" />    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FEnterprise%20Integration%20Platform&pageId=17&wikiVersion=GBmaster">Enterprise Integration Platform</a>
                </font></b>
            </li> 
       </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
         <img src="https://www.devesprit.com/Content/img/Speed.png" style="width:" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FTechnical%20Architecture&pageId=47&wikiVersion=GBmaster">Technical Architecture</a>
                </font></b>
            </li> 
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
         <img src="https://www.devesprit.com/Content/img/Speed.png" style="width:" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FBuild%20and%20Release%20Management&pageId=3&wikiVersion=GBmaster">Build & Release Management</a>
                </font></b>
            </li> 
        </ul>
    </div>
</div>
<div class="box" style="width: 450px; float: left; margin: 10px; background-color: #ededed; padding: 30px; height: 230px;">
    <div style="width: 30%;float: left">
        <img src="https://docs.microsoft.com/en-us/dynamics365/images/dynamics-field-service.svg" style="width: 90%" />
    </div>
    <div style="width: 60%;padding-left: 15px;float: right;/* height: 500px; */">
        <ul style="list-style: none;margin: 0;padding: 0">
            <li style="padding-bottom: 10px">
                <b><font size="4">
                <a href="https://dev.azure.com/csyw/Unify/_wiki/wikis/Wiki?pagePath=%2FUnify%20Design&pageId=56&wikiVersion=GBmaster">Unify Design</a>
                </font></b>
            </li> 
        </ul>
    </div>
</div>
<div ="float: left; clear:both">&nbsp;&nbsp; </div>
<div style="float: left; clear:both"></div>




