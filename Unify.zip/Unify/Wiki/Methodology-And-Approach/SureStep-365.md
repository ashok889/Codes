# SureStep 365 Methodology

## 1 Introduction
This section describes the way in which the Unify program approaches the implementation of Dynamics 365 Customer Engagement for the needs of Child Safety and Youth Justice. The approach has been heavily based upon the Microsoft SureStep 365 methodology and adapted to the needs of the department.

[[_TOC_]]


The Build Phase applies an iterative approach where sets of user stories are completed in within iterations / sprints. This approach, combined with build automation and automated testing, is aimed at allowing for more flexibility and responsiveness to business change within the release cycles.


![Dynamics-SureStep-365.png](../methodology-and-approach/images/dynamics-surestep-365.png)



## 2 Discovery Phase
In the discovery phase the high-level objectives, business processes, scope and some business requirements are captured through various workshops and associated activities. The deliverables from the discovery phase should be detailed enough the enable an initial release plan and schedule to be constructed and will provide input to the solution modelling phase where additional details will be identified.

| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Review existing business and application documentation</li><li>Conduct workshops and interview business stakeholders</li><li>Produce and review deliverables</ul> |
| Deliverables | <ul><li>Lean Canvass</li><li>Product on a Page</li><li>Level 2 Business Processes</li><li>Features and associated business requirements for gaps</li></ul> |
| Exit Criteria | <ul><li>Approved deliverables</li></ul> |


## 3 Solution Modelling Phase
The main objective in the solution modelling phase is create and demonstrate a baseline configuration of the Unify application to business representatives. Through the solution modelling process the business representatives will be able to visualise how the final solution will operate and also assist in identifying any additional requirements.

Dependant on the outcome of the solution modelling workshops the scope and / or schedule of the release may need to be assessed.

| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Identify and agree in-scope features</li><li>Conduct feature modelling workshops</li><li>Review business processes</li><li>Produce user stories (all user stories to be planned to be complete within a single iteration / sprint</li><li>Estimate and agree User Stories that are in-scope</li><li>Create the baseline configuration</li><li>Conduct solution modelling workshops and demonstrate the baseline configuration</li><li>Validate feature and user stories</li><li>Create the draft solution design</li><li>Create the draft functional design</li><li>Update the release schedule</li><li>Perform a business impact assessment as part of the change management activities</li></ul> |
| Deliverables | <ul><li>Draft solution design</li><li>Draft functional design</li><li>Baseline configuration</li><li>Updated user stories</li></ul> |
| Exit Criteria | <ul><li>The draft solution design has been validated</li><li>The draft functional design has been validated</li><li>The baseline configuration has been validated that it meets the high-level needs of the level2 business processes</li><li>The updated and prioritised user stories meet the needs of the release</li><li>Business impact assessment</li><li>All business entities have been identified and configured with critical attributes</li></ul> |

> All business entities and the critical attributes are to be identified and configured as part of the solution modelling phase. Build phase will add the remaining attributes and chage the layouts of views and forms to meet the business needs.

## 4 Build Phase
The build phase is split into a number of iterations / sprints of which each will complete a set of user stories. To be complete a user story must be finished design, configuration / development, test case creation and test case execution.

Each iteration / sprint is to be of four weeks duration of which the last week is to be allocated to build-iteration testing which includes feature test execution and bug fixes.

> The duration of an iteration / sprint could be reduced to two weeks once the project team is familiar with the process and has demonstrated a successful rhythm of delivery

| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Estimate and plan the iteration / sprint including the creation of tasks</li><li>Design and configure / develop each user story</li><li>Create and execute test cases for each user story</li><li>Triage and fix bugs<li>Conduct a business showcase at the end of each iteration / sprint</li><li>Analyse, design and create data migration processes</li><li>Create data migration test scripts and reconciliation process</li><li>Create process test scripts</li><li>Produce the required technical documentation</li><li>Update the solution design</li><li>Update the functional design</li></ul> |
| Deliverables | <ul><li>Completed user stories</li>End to end process test scripts<li>Final solution design</li><li>Final functional design</li><li></li></ul> |
| Exit Criteria | <ul><li>Required user stories are completed</li><li>Updated solution design approved</li><li>Updated functional design approved</li><li>Zero severity 1 and 2 bugs for feature tests</li><li>Data migration process and scripts completed</li></ul> |

## 5 Solution Testing Phase
In the solution testing phase all the user stories for the release have been completed and feature tests have been executed. The solution testing is focused on executing the different types of tests, fixing any remaining bugs and stabilising the release for deployment into production.

> The solution testing phase is normally scheduled to be executed over a 2-4 period depending on the test strategy, size of the changes and maturity of the project team with the process and application.

| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Prepare testing environments</li><li>Migrate test data</li><li>Train the user of the application</li><li>Execute test scripts for feature, end-to-end, performance, UAT and data migration</li><li>Triage and fix all severity 1 and 2 bugs</li><li>Produce an approved deployment / cutover plan</li><li>Conduct a go/no-go meeting for production deployment</li><li>Produce an approved operations guide</li></ul> |
| Deliverables | <ul><li>User acceptance test signoff</li><li>User training is completed</li><li>Test summary report</li><li>Release notes</li><li>Approved cutover plan</li><li>Data migration trials have been completed and approved</li></ul> |
| Exit Criteria | <ul><li>Approved deliverables</li></ul> |

## 6 Deployment Phase
| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Conduct a go / no-go meeting for production deployment</li><li>Migrate configuration and customisations to production</li><li>Execute and reconcile the data migration</li><li>Execute business verification tests(BVT) as per the cutover plan</ul> |
| Deliverables | <ul><li>Updated cutover plan with outcomes and cutover issues identified</li><li>Release migrated to production with the associated data</li></ul> |
| Exit Criteria | <ul><li>Updated cutover plan with outcomes for migration of configuration, customisation and data including reconciliation</li><li>BVT test results</li></ul> |

## 7 Production Support Phase
In the production support phase the project team provide the initial production support coverage and transition knowledge to the support team for ongoing support.

| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Support the change management teams to provide end user assistance</li><li>Provide high levels of support to production incidents</li><li>Provide knowledge transfer to support teams on functional and technical aspects of the deployment</ul> |
| Deliverables | <ul><li>Not Applicable</li></ul> |
| Exit Criteria | <ul><li>Knowledge transfer to support team complete</li></ul> |

## 8 Operation Phase
In the operation phase the project team respond to escalations from the support team.
| Category   | Description |
|:-----------|:------------|
| Activities | <ul><li>Respond to escalations from the support team |
| Deliverables | <ul><li>Not Applicable</li></ul> |
| Exit Criteria | <ul><li>Not Applicable</li></ul> |