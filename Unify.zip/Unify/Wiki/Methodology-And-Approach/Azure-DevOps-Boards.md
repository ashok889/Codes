# Azure Boards

## 1 Introduction
Azure DevOps Boards provides the capabilities to manage and track the activities and deliverables specified by the SureStep 365 process. The Unify program is utilising the Agile template that is delivered by Microsoft in the DevOps product with the addition of a work item type to capture business requirements.

The work items included in this template are show in the diagram below. 
![unify-agile-template](./images/unify-agile-template.png)

[[_TOC_]]

## 2 Area's and Iterations
Area's are used in Azure DevOps to group work items, usually by some form of set of functionality or modules. Within the Unify program Area's will be used to group items by work product.

Iterations are used in Azure DevOps to plan time periods in which work is planned and executed. In the Unify program iterations will be used to specify the time periods that relate to the phases of SureStep 365 and the iterations / sprints within the build phase.


## 3 Feature & Requirements
Features are used to identify and group capabilities or feature that the application needs to implement and support. During the discovery phase these are identified, usually within the level 2 business processes, and provide a way to describe the scope of the application for a release at a high-level.

The following diagram shows the information which is captured on a Feature, including:
1. The Area in which the feature is grouped
2. The Iteration in which the feature is planned to be first implemented
3. Related work items which will include User Stories

> All requirements that are not parented to a User Story are considered to have not been implemented

![Feature-Work-Item.png](./images/feature-work-item.png)

## 4 User Stories 
User Stories are created from the discovery activities and deliverables and together are known as the backlog. The User Stories are reviewed, estimated, prioritised and allocated to a specific release for implementation.

The following diagram shows the information which is captured on a User Story, including:
1. The Area in which the User Story is implementing capability
2. The Iteration in which the User Story is planned to be completed
3. The Acceptance Criteria, which describes the functionality that the solution must support to be considered complete. The acceptance criteria needs to reflect the functionality to be produced, must give enough information to be clear for a developer and must be testable
4. The related work items will show the
    - Feature for which the User Story will implement capability
    - Tasks required to complete the User Story
    - Test Case that will test the acceptance criteria in the User Story
    - Any requirements that are satisfied by the User Story

> A User Story must be able to be completed within a single iteration or sprint. If it can not be completed in that time period it should be split into multiple User Stories 

> All User Stories must be parented to a Feature

![user-story-work-item.png](./images/user-story-work-item.png)

## 5 Tasks
Tasks are created to plan and manage activities that need to be performed by project team members in order to complete a User Story. Each Task is to be assigned and completed by a single project team member. Each Task has a type that indicates the work to be performed, types include:
1. Design - where design and configuration is performed
2. Development - where development of a customisation or integration is required
3. Test - where test planning, test case creation or test case execution is required

![task-work-item.png](./images/task-work-item.png)


## 6 Test Cases & Bugs
![test-case-work-item.png](./images/test-case-work-item.png)