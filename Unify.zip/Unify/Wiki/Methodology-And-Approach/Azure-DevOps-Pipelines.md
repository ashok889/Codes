# Azure DevOps Pipelines

## 1 Introduction
This section describes the objectives of the Azure DevOps pipelines for build and release processes and how they relate the methodology that the program is following. The detailed information is described in the [Build and Release Management](../Build-And-Release-Management.md) section.

The automation of the build & release processes is central to the objective of providing flexibility and responsiveness to business change.

## 2 Build Pipelines
There is an Azure DevOps Build Pipeline that is scheduled to execute each night for the Unify application that builds and packages the configuration and customisations from source control and executes an automated test suite. This includes the following tasks:
1. Build Dynamics 365 plugins from source control (Git)
2. Extract Dynamics 365 configuration from source control
3. Package the output from steps 1 and 2 into a Managed Solution that will be used to deploy to all environments within the release pipeline
4. Deploy the Managed Solution to the Development environment
5. Deploy the Azure configuration, from source control, to the Development environment
6. Execute the designated automated test suite

Further information on the build pipeline can be found on the [Build Pipelines](../Build-and-Release-Management/Build-Pipelines.md) page.

## 3 Release Pipelines
There are multiple Azure DevOps Release Pipelines defined to support the needs of the Unify application.

These include:
1. A Development pipeline that manages the migration of the Build artefacts (from the Build Pipeline) through the environments that support the solution modelling and build phases.
2. A Production pipeline that manages the migration of the Build artefacts through the environments that support the solution testing and deployment phases.

Further information on the release pipelines can be found on the [Release Pipelines](../Build-and-Release-Management/Release-Pipelines.md) page.