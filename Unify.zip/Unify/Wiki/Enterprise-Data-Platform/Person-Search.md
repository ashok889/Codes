<h1>Person Search</h1>
The following describes the Person Search capability that is implemented within the Enterprise Data Platform and is available to be embedded within applications.

[[_TOC_]]


## Objective
The objective of the Person Search capability is to enable departmental staff members to search and find a record of a Person from all of the available data that the department has collected across applications. Once found, the staff member will be able to view certain information to establish identity and key characteristics. The staff member will also have the ability to include this person into a new Unify transaction easily. 

## Design
Person Search has the following design elements:
1. Data on Person records from across the department is consolidated within the Enterprise Data Platform including Unify, ICMS and other external data sources.
2. An Azure Search index combines the Person data and provides flexible search capabilities.
3. The Person search user interface, similar to what is shown, allows a staff member multiple options to search for an individual.
4. The Person search user interface displays relevant information and indicators that will enable the staff member to identify the individual.
5. The Person search user interface includes options, buttons and links, to create/allocate the Person record to a specific transaction (ie Intake) within Unify. 

![Person-Search.png](./images/Person-Search.png)