<h1>Person History</h1>
The following describes the Person History that is implemented within the Enterprise Data Platform and is available to be embedded within applications.

[[_TOC_]]

## Objective
The objective of the Person History capability is to enable departmental staff members to view a Person history that includes all of the available data that the department has collected across applications. 

## Design
Person History has the following design elements:
1. Data on Person records from across the department is consolidated within the Enterprise Data Platform including Unify, ICMS and other external data sources.
2. An API combines the Person history information from across the Enterprise Data Platform and can also include AI / Machine Learning insights
3. One, or more, user interface components that display read-only information that can be embedded within Unify and other applications.

> The Person History capability has the potential to reduce the amount of data migration required by displaying information from external sources and therefore avoiding the need to store the information within the Unify database.