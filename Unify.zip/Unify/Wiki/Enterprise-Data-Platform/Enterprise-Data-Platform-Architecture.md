<h1>Enterprise Data Platform Architecture</h1>
The following describes the architecture of the Enterprise Data Platform.

[[_TOC_]]

## Architecture
The objective of the Person History capability is to enable departmental staff members to view a Person history that includes all of the available data that the department has collected across applications. 

The following diagram show the architecture of the Enterprise data Platform.

![Enterprise-Data-Platform-Architecture.png](./images/edp-architecture.png)