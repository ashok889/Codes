<h1>SPR Inbound Integration Design</h1>

This section will details the integration design when receiving the Student Protection Report (SPR) also known as **Mandatory Report** as a message from an external system and transforming/processing the message into Dynamics 365.

[[_TOC_]]


## High Level Design
The following illustration details the integration design components for the SPR inbound message integration into Dynamics 365.

Note that the primary source of data in this illustration is the Department of Education. However, the illustration shows how other sources can be  plugged into the design in the future as required.

![SPR-Integration-Design.png](./images/SPR-Integration-Design.png)

**Explanation**:

1. The Department of Education will send a JSON message to an API exposed by the DCSYW through API Management
1. The logic is then processed and validated. If any issue then the request will be rejected and a faulty response is sent back with an appropriate error message
1. Otherwise, the message will be accepted and stored in a Queue in Azure Service Bus. Each source will have a main queue and a deadletter queue specifically for that source for easier management and maintenance of message processing logic
1. A RequestID or an acknowledgement is sent back to the Department of Education to confirm the message has been received, accepted and stored successfully. At this stage, the message is only stored into a service bus queue and not in Dynamics 365
1. A listener on the specific service queue will peek through the queue and lock the message then start to process it by taking it through a transformation layer in order to convert the source schema into a target schema that ultimately the Business API layer of Dynamics 365 can accept. Any reference data or codes translations will occur in this layer as well 
1. Then the updated new schema is sent to the Business API layer via API Management layer (an internal interface) to be validated and processed.
1. A transactional batch will be created (a) and sent in a single request to Dynamics 365 via Dynamics 365 WebAPI endpoint (b)
1. If the message is successful and Dynamics 365 was able to process and create all required records and send a successful response back, then the Business API layer will issue a complete command back to the same service bus queue in order to remove the message from the queue. 

If any error occur during the transformation logic or within the Business API (including errors sent by Dynamics 365), then the message will be forwarded to a deadletter queue specific for each source.

### Recommended Technologies
The following list of technologies are recommended to be used in this integration design:
- API Management
- Azure Logic Apps
- Azure Functions
- Azure Service Bus
- Azure Monitor

## Technical Design
following is a display of the components implemented in Azure to fulfil the above design:
![SPR-Integration-Design.png](./images/SPR-Integration-TechDesign.png)
This is the details for each of the above components:

| Component | Type | Details |
|:----------|:-----|:--------|
| csyw-eip-apim-external | API Management  | An external API Management Endpoint  |
| csyw-eip-la-doeprocessspr | Logic App  | For the implementation of the csyw-eip-apim-external API  |
| csyw-eip-apim-internal | API Management | An internal API Management endpoint for the Business API layer of Dynamics 365 |
| ProcessMandatoryReport | Azure Function | For the implementation of the csyw-eip-apim-internal API  |
| csyw-unify-fa | Function App | An Azure Function App container for the Azure Functions related to the Unify application |
| csyw-eip-sb-doe  | Service Bus  | The Azure Service Bus for the Main Department of Education queue  |
| csyw-eip-apim-la-doereadfromsb | Logic App | A listener to the Main Department of Education queue that forward messages to the Business API Layer |

**Note**: Azure Monitor will be used across the platform to provide monitoring and alerting for any issues throughout the integration pipeline.

### csyw-eip-la-doeprocessspr logic
The following is the suggested implementation of the DOE Process SPR Logic App:
![csyw-eip-la-doeprocessspr.png](./images/csyw-eip-la-doeprocessspr.png)

### csyw-eip-apim-la-doereadfromsb logic
The following is the suggested implementation of the DOE Read From Service Bus Logic App:
![csyw-eip-apim-la-doereadfromsb.png](./images/csyw-eip-apim-la-doereadfromsb.png)


## Choice of Integration Patterns
The design of Inbound messaging needs to comply with guaranteed message quality as well as being able to send an acknowledgement back to the sender about the successful recipient of the message. The message structure is bit complex in nature and is based on a complex [JSON schema](./SPR-Inbound-Integration-Design/JSON-Schema.md), thus will require some time to be processed successfully into multiple structured records in Dynamics 365. Accordingly, the best implementation patterns for such design would be:
- **Asynchronous Update**: the sender (DoE) doesn't need to know where or how the message will be stored or processed. This pattern is also recommended in order to provide high decoupling of systems and being able to scale by plugging more sources while keep the background processing in a different layer. For more information, click [here](../../Enterprise-Integration-Platform/Integration-Patterns/Asynchronous-Update.md)
- **Message Queueing**: This pattern is needed for the guaranteed integration quality. For more information, click [here](../../Enterprise-Integration-Platform/Integration-Patterns/Message-Queueing.md)
- **Process Integration**: This pattern is used throughout the logic apps that is responsible for exposing the API Management function as well as the logic within the Transformation of the Business API layers. For more information, click [here](../../Enterprise-Integration-Platform/Integration-Patterns/Process-Integration-Pattern.md)
- **Synchronous Update**: This pattern is reflected in the Business API layer and when this layer is submitting a request to Dynamics 365's API. The Business API layer will await a response from Dynamics 365 before it progress and complete the message in Azure Service Bus, otherwise it'll forward the message to dead-letter in case of any issue. For more information, click [here](../../Enterprise-Integration-Platform/Integration-Patterns/Synchronous-Update.md)

The following diagram illustrates where each pattern is used in the design:
![SPR-Integration-Patterns.png](./images/SPR-Integration-Patterns.png)

## Affected User Stories

The following is a list of the user stories related to the integration design of the Inbound Mandatory Report (SPR) requirement.

::: query-table 8390237a-72bd-4a83-ad74-5f682722b12f
:::
 

## Current Exemplar Scope
The following is the agreed scope for the implementation of the inbound SPR integration design under the Exemplar's program scope of work
- Only one source of input will be implemented. This source is from Department of Education (DoE)
- Only the main Report information, student details and school details will be processed and imported into Dynamics 365
- We'll not support the Disability, Language, Legal Order and Year Level when creating the Student report
- We'll not suppor the agency contact list for the Report record.
- Validation is based on validating the JSON object against a schema for the following rules:
  - Field types
  - Mandatory fields
  - Field lengths
- Only one queue will be created to store the DoE messages. The default Dead-Letter queue of Azure Service Bus will be used for error messages
- No duplicate detections, any matching logic and prior message identification shall be implemented. If the same message JSON file is submitted again, duplicate records (student/report) shall be created in Dynamics 365
- The Transformation layer will not be implemented. It is assumed that the DoE JSON format is the same as the acceptable format to be processed by the Business API layer
- No reference data translation through Reference Data Management shall be implemented. This requires a Data Platform and a configured mapping of values
- Only one API Management endpoint shall be implemented which is acting as the external interface that will accept the DoE message and its JSON object
    - Special security consideration of the endpoint shall not be implemented, instead will use the default auth and session based authentication. You need to be logged in to the Azure Portal in order to invoke the API Management endpoint
    - No DNS or url masking will be implemented
    - No product configuration and API documentation shall be configured
- Azure Monitor will be enabled per each of the endpoints used in the logic but no analytics reporting or alerting functionality will be configured under the exemplar scope


## Business Rules

- ConcernID is unique per each report. If a new version of the report is updated in DoE, a new message will be sent with same ConcernID. Use the ConcernID to identify if a report already exist in the system prior to creating a new one
- Identify existing students by comparing against **eqId** field
- Match to existing schools by comparing against **School Name** field

## Data Map
This is the map between the JSON structure sent by DoE and the Dynamics 365 entities/fields:

[SPR-Mapping-with-D365.xlsx](./SPR-Inbound-Integration-Design/SPR-Mapping-with-D365.xlsx)


## Message Contract

### Request Header

- POST /request HTTPS/1.1
- Accept: application/jsonrequest
- Content-Encoding: identity
- Content-Length: 72
- Content-Type: application/json
- data: [JSON Schema](./SPR-Inbound-Integration-Design/JSON-Schema.md)

### Response Header

    <xs:complexType name="CreateReportResponseBodyType">
        <xs:sequence>
            <xs:element minOccurs="1" maxOccurs="1" form="unqualified" name="errorMessage" nillable="true" type="xs:string"/>
            <xs:element minOccurs="1" maxOccurs="1" form="unqualified" name="id" nillable="true" type="xs:string"/>
            <xs:element minOccurs="0" maxOccurs="1" form="unqualified" name="isSuccess" nillable="true" type="xs:boolean"/>
            <xs:element minOccurs="1" maxOccurs="1" form="unqualified" name="referenceCode" nillable="true" type="xs:string"/>
        </xs:sequence>
    </xs:complexType>

**Specifications:**
- __*id*__: SP4 reportDetails.Id (unique report message ID from DoE). This will be in the form of a GUID.
- __*isSuccess*__: Boolean value (true if successful | false if not)
- __*referenceCode*__: Unique identifier for the report generated by CSYW upon receipt of a report from DoE. Note: This ID will be displayed on screen in DoE OneSchool (i.e. must be human readable). Only assigned if the request isSucess = true. Use this convention: 
    - **'CSYW' + 7 digits starting from 1000000** 
- __*errorMessage*__: Provides DoE with a reason for message failure. Must only be populated if IsSuccess = false. The error message must be in an array of JSON error objects. See below an example.

        {
          "errors": [
            {
              "message": "Required properties are missing from object: concernId.",
              "lineNumber": 0,
              "linePosition": 0,
              "path": "report",
              "value": [],
              "schemaId": "http://example.com/root.json#/properties/report",
              "errorType": "required",
              "childErrors": []
            },
            {
              "message": "Invalid type. Expected Integer but got String.",
              "lineNumber": 0,
              "linePosition": 0,
              "path": "report.concernId",
              "value": "40667",
              "schemaId": "http://example.com/root.json#/properties/report/properties/concernId",
              "errorType": "type",
              "childErrors": []
            }
          ]
        }

