Refer to the functional design document.
