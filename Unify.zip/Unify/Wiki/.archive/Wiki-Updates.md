# Wiki update process



Updates to the Wiki are made utilising Markdown on a local computer and then applying those changes to the Git repository on Azure DevOps.

> Changes can also be made directly into the branch on the Azure DevOps server.



The steps in the process are:
1. Ensure a Task is created in Aure DevOps and assigned to manage the Wiki updates
2. Create a branch, from master, to capture the changes
3. Fetch the branch locally and checkout
4. Make the required changes in Markdown
5. Commit and push the changes back to Azure DevOps
6. Raise a pull request for the changes to be reviewed and merged into the master branch

## Steps

### 1. Ensure a Task is created in Aure DevOps and assigned to manage the Wiki updates

Each set of changes to the Wiki will need to be associated with a Task in Azure DevOps. In this case below the task is specifically for documentation but iw could be as part of a another Task type (Discipline).

A branch, which will be used to track the changes, can be created directly from the Task.

![Wiki-Task.png](./images/Wiki-Updates-Task.png)


### 2. Create a branch, from master, to capture the changes

Each set of changes to the Wiki will need to be associated with a Task in Azure DevOps. In this case below the task is specifically for documentation but iw could be as part of a another Task type (Discipline).

A branch, which will be used to track the changes, can be created directly from the Task.

![Create-Branch](./images/Wiki-Updates-Create-Branch.png)


### 3. Fetch the branch locally and checkout

![Fetch-Remote-Branch](./images/VScode-Checkout-Remote-Branch.png)

![Select-Remote-Branch](./images/VScode-Select-Branch.png)



### 4. Make the required changes in Markdown

![Update-Markdown](./images/VScode-Make-Changes-In-Branch.png)



### 5. Commit and push the changes back to Azure DevOps

![Commit-Locally](./images/VScode-Commit-All-Changes.png)

![Push-To-DevOps](./images/VScode-Push-To.png)


### 6. Raise a pull request for the changes to be reviewed and merged into the master branch

![DevOps-Create-Pull-Request](./images/DevOps-Create-Pull-Request.png)

![DevOps-Create-Pull-Request](./images/DevOps-Create-Pull-Request2.png)
