#  Methodology Overview

## 1 Introduction
The Unify application is being progressively implemented over a number of years to support the Child Safety and Youth Justice organisations. The methodology aims to assist in providing quality outcomes while also providing flexibility and responsiveness in the way and timing of changes to the application that support the business processes.

The SureStep 365 methodology has been applied to numerous Dynamics 365 implementation worldwide and across many industries and business problems. The solution modelling phase is executed once per release and aims to provide business representatives an early visualisation of the way in which the final applications will support their needs. The solution modelling workshops also provide the ability to drive a configure-first approach and an opportunity to identify additional requirements that have been previously missed.

The activities and deliverables of the discovery phase have been adjusted to align to the process by which the department is collecting high-level needs and requirements for each work product. This will allow SureStep 365 to align well with a human centred design approach where people are at the heart of the design process.

The build phase is structured into multiple iterations / sprints in more of an Agile approach. This approach, in the build phase, give the business and the project team flexibility to monitor and obtain feedback on progress and change direction if required. 

Throughout the process automation will be applied to make tasks repeatable, consistent and efficient. Tasks to be automated include build automation, release automation and automated testing. Management of the process including requirements, users stories, tasks, testing, builds and releases will be facilitated by Microsoft Azure DevOps.

[[_TOC_]]

The following are the key recommended practices related to Methodology and Approach.
| Practice | Description |
|:---------|:------------|
| Centralised Design Authority | Implement a centralised design authority for all data model and architectural changes |
| Configure-First | Drive a configure-first approach by demonstrating the application, configured to the high-level needs of the business, during the solution modelling phase. |
| Customisation Approval Process | Implement a well defined and understood approval process, including a register, for all customisations. Only use customisation where there is a significant business benefit or compliance requirement that can't be fulfilled through configuration. |
| Sizing User Stories | Plan for all User Stories to be completed within an iteration / sprint |
| Build & Release Automation | Automate all possible build and release steps to ensure consistency, predictability and efficiency |
| Automated Testing | Implement automated testing from the first day of the program to increase quality and reduce release cycle times. | 

## 2 SureStep 365

The SureStep 365 process, aligned to the Unify program is documented at [SureStep 365](./methodology-and-approach/surestep-365.md)

The high-level phases and activity sets of SureStep 365 are shown in the following diagram and described below.

![Dynamics-SureStep-365.png](./methodology-and-approach/images/Dynamics-SureStep-365.png)

The approach includes the following phases:
1. [Discovery Phase]() - where high-level business objectives, business processes and business requirements are captured and prioritised by each of the program products. The discovery phase can include a human centred design approach to capturing business input where stakeholders (children, staff, parents and carers, service providers) are at the centre of the design process.
2. [Solution Modelling Phase]() - where the high-level flow of the business processes implemented within Unify can be demonstrated to business representatives to gain early confirmation and feedback.
3. [Build]() - where an iterative based approach is employed to raise quality, flexibility and operate in an Agile manner
4. [Solution Testing Phase]() - where the formal testing of features (processes), end-to-end processes, performance is executed. The last step is to perform the User Acceptance Test (UAT) which is a formal milestone for production deployment.
5. [Deployment Phase]() - where the activities to deploy into production are planned and executed.
6. [Production Support Phase]() - where initial support is provided by the project team to ensure a successful release and knowledge transfer to the ongoing operations / support team take place.
7. [Operation Phase]() - where the operations / support team are responsible for first line support and the project act as an escalation point.

## 3 Azure DevOps Organisation and Projects
A new Azure DevOps organisation has been created, initially for the program but with the intention for it to be used eventually across the department, and can be found at https://dev.azure.com/csyw

The [Application Architecture](./program-architecture/application-architecture.md) defines that there are to be three distinct IT assets to be deployed in a loosely coupled architecture. Each of these IT assets can have there own release schedule, resources, Azure assets and stakeholders. Each of these assets will have there own Azure DevOps project with associated Git (source control), boards and pipelines.

## 4 Azure DevOps Boards
Azure DevOps Boards provides the capabilities to manage and track the activities and deliverables specified by the SureStep 365 process. The Unify program is utilising the Agile template that is delivered by Microsoft in the DevOps product with the addition of a work item type to capture business requirements.

The work items included in this template are show in the diagram below. Further information on the use of each of the work items, on the Unify program, is available on the the [Azure DevOps Board](./methodology-and-approach/Azure-DevOps-Boards.md) page.

![unify-agile-template](./methodology-and-approach/images/unify-agile-template.png)

## 5 Azure DevOps Pipelines
Azure DevOps Pipelines provides the capabilities to automate the build and release processes throughout the various environments. The Unify program will include build and release pipelines for Dynamics 365 Customer Engagement solutions and the associated Azure components that are required to expose business API endpoints. The pipelines will also include tasks to execute the automated test processes.

Further information on the use of these capabilities, for the Unify program, is available on the the [Azure DevOps Pipeline](./methodology-and-approach/azure-deveops-pipelines.md) page.

## 6 Testing Strategy
Testing is critical to ensuring a quality business outcome and also enabling a flexible and responsive release cycle. The following type of testing are part of the SureStep 365 approach.
| Test Type | Description |
|:----------|:------------|
| Unit Testing | Any customisation of Dynamics 365, integration or other code components are to have automated units tests |
| Feature Testing | Features are to have test cases written, executed and corrected within Azure DevOps. Each User Story, which is linked to a Feature, will have test cases that validate all of the acceptance criteria. Where possible these tests will be automated and included as part of the build and release management processes. |
| End-to-end Testing | End-to-end testing validates the complete process works from start to finish. This testing ensures that each of the features support the business processes in there entirety.  |
| Performance Testing | Performance testing focuses on those aspects of the application that are considered high-risk or high-impact and are sensitive to end user performance metrics. |
| UAT | User acceptance testing allows the business users an opportunity to ensure that the application is fit for purpose. |


