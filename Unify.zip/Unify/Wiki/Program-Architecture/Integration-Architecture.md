# Integration Architecture 

## 1 Introduction
The integration architecture describes the way in which the internal and external business platforms will share information. 

[[_TOC_]]

Further information on the implementation of the integration architecture can be found at [Enterprise Integration Platform](../Enterprise-Integration-Platform.md) section.

### 2 Integration Architecture

![Integration Architecture.png](./images/integration-architecture.png)

The implementation details of the Enterprise Integration Platform is described in detail in the [Enterprise Integration Platform](../Enterprise-Integration-Platform.md) section.

### 2 Integration Platform Responsibilities
The integration platform is responsible for:
1. Orchestrating communication between each of the application endpoints / services
2. Transformation between the message formats that are understood by each application
3. Mapping of field values between an external representation and the internal representation using the Reference Data services. Examples include mapping a value of "Queenslander" to the internal representation of "QLD"
4. Logging all integration message
5. Monitoring and alerting all integration capabilities
6. Managing guaranteed delivery where required
7. Authenticating with each application 

### 3 Integration Patterns

The Enterprise Integration Platform will play a significant role in implementing the following integration patterns.

| Integration Pattern | Description | More Info |
|:--------------------|:------------|:----------| 
| Asynchronous Update | This pattern is used when a update is committed in one application and the message is sent to another application for the updated to be applied. In this pattern the first application enforces all required business rules to validate the update and the message must be guaranteed delivery to the second application.| [link](../Enterprise-Integration-Platform/Integration-Patterns/Asynchronous-Update.md) |
| Publish and Subscribe | This pattern is used when an update is committed in one application and then place the update on a queue / hub where other applications that subscribe will receive and process the update. Guaranteed delivery is not enforced in this pattern| [link](../Enterprise-Integration-Platform/Integration-Patterns/Publish-Subscribe.md) |
| Synchronise Update | This pattern is used when and update must only be committed in the current application is a corresponding update is successful in a second application. If the update in the second application fails then the update in the first application also fails and notifies the user of the failure. This pattern is to be used where critical business rules are currently only implemented in the second application. This is likely to be the case where updates are being applied to a Person record in Unify but must first ensure that the update is applied in ICMS successfully. | [link](../Enterprise-Integration-Platform/Integration-Patterns/Synchronous-Update.md) |
| Synchronise Read | This pattern is used where information needs to available within an application, for display on the user interface or within some business logic, but is only available in another application or platform. | [link](../Enterprise-Integration-Platform/Integration-Patterns/Synchronous-Read.md) |