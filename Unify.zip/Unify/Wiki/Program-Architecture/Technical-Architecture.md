# Technical Architecture
----

# 1 Introduction
The technical architecture describes the design of the Azure components that will be deployed throughout the program and how they will interact with on-premise and external stakeholders.

It is organised into:

The following diagram depicts the architectural patterns that is being implemented to support the program. Further documentation on this pattern can be found at [Hub and Spoke Topology](https://docs.microsoft.com/en-us/azure/architecture/reference-architectures/hybrid-networking/shared-services)

<br/>

![Hub and Spoke Architecture](./images/hub-and-spoke-architecture.png)

# 2 Hub Virtual Network
The design for the Hub is being progressed with the assistance of a Microsoft PFE and is considered an enterprise asset that will be used initially by the Unify program. It is envisaged that in the long term all departmental Azure assets will be migrated to utilise the Hub.

The objectives and responsibilities of the Hub include:
1. Facilitate secure and robust network communication to on-premise assets and to the internet for access by external stakeholders
2. Centralised place for operations to exercise control and provide enterprise wide monitoring and alerting
3. Provide shared assets to the business capabilities and applications deployed in the spokes. This includes services such as API management and credential stores.
