# Data Architecture

# 1 Introduction
---
The data architecture / management items describes the approach and design of data elements within the program. 

[[_TOC_]]



## 2 Data Model
---
Microsoft has defined a Common Data Model (CDM) that has been implemented within the Dynamics 365 suite of products. This program will take this data model and extend it to support the business processes of Child Safety and Youth Justice. 

The Common Data Model is depicted below and more information can be found at the following links:
- [Common Data Model](https://docs.microsoft.com/en-us/common-data-model/)
- [Common Data Model on GitHub](https://github.com/Microsoft/CDM)
<br/>

![Common Data Model.png](../Data-Management/images/common-data-model.png)

## 3 Data Platform 
---

The following diagram depicts the Enterprise Data Platform components.

![Enterprise Data Platform](../Enterprise-Data-Platform/images/enterprise-data-platform.png)

The Enterprise Data Platform components are further described in the tables below.

**Visualisation**
| Component | Description |
|:----------|:------------|
| PowerBI | Microsoft PowerBI will be used to produce reports and dashboards for analytical reporting purposes. The PowerBI dashboards will be able to be embeddedb with the Unify (Dynamics 365) user interface and will be able to source data from a variety of data source including SQL Data Warehouse, Analysis Services, Data Lake and CosmosDB.

**Prepare and Enhance**
| Component | Description |
|:----------|:------------|
| Artificial Intelligence | The Artificial Intelligence and Machine Learning capabilities of Azure platform will be used to ingest data from the storage technologies and produce insights that can be consumed within Unify. Further information is available at [Azure Machine Learning](https://azure.microsoft.com/en-us/services/machine-learning-service/)
| Azure Search | Azure Search will be used to support advanced searching capabilities such as Person Search. Further information is available at [Azure Search](https://docs.microsoft.com/en-us/azure/search/)
| Cognitive Services | Cognitive Services provide pre-packaged AI capabilities in the area's of decision, speech, language, vision and search. The will be used based upon business requirements in each of the work packages. Further information is available at [Cognitive Services](https://azure.microsoft.com/en-us/services/cognitive-services/) |
| Data Warehouse | Azure SQL Data Warehouse provides the ability to organise, prepare and access information in an efficient way for analytical reporting. Azure SQL Data Warehouse will be used as the primary technology to consolidate data for analytical reporting that is viewed using PowerBI. Further information is available at [SQL Data Warehouse](https://docs.microsoft.com/en-us/azure/sql-data-warehouse/)|  
| Cosmos DB | Azure CosmosDB is a distributed database that allows flexible and fast retrieval of information. CosmosDB will be considered as part of the solution for storing audit data and as the store for low latency read-only APIs such as Person History. Further information is available at {Azure Cosmos DB](https://docs.microsoft.com/en-us/azure/cosmos-db/) 

> CosmosDB could be also be included in the Data Platform Storage layer.

**Data Processing**
| Component | Description |
|:----------|:------------|
| Data Factory | Azure Data Factory provides the ability move bulk datasets, perform basic transformations and schedule execution. |
| Databricks   | Databricks provides additional capabilities to perform complex transfromations, real-time stream processing and also AI / Machine Learning tasks. | 

Further information is available at [Azure Data Factory](https://docs.microsoft.com/en-us/azure/data-factory/)

**Data Platform Storage**
| Component | Description |
|:----------|:------------|
| ICMS ODS | A SQL Azure instance will provide a near real-time ODS of the current ICMS application database. This ICMS ODS will be used for any read-only APIs that are required within Unify and also as a source for analytical reporting. Locating an ICMS ODS in Azure is intended to provide reduced latency for read-only API calls. |
| Unify ODS | A SQL Azure instance will provide a near real-time ODS of the Unify application. The Dynamics 365 Data Export service will be used to synchronise the required entities. The Unify ODS will be used to source information for analytical reporting, Artificial Intelligence, person search and person history capabilities.
| Data Lake | An Azure Data Lake instance will be utilised to collate information for processing by the tools in the Prepare and Enhance layer. Data will be landed in the Data Lake, predominantly in it's raw form and secured. Further information is available at [Azure Data Lake Gen2](https://docs.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-introduction)|
| Azure Storage | Azure Storage will be available for storage if the Data Lake is not suitable or supported by the relevant data and source technologies. Further information is available at [Azure Table Storage](https://docs.microsoft.com/en-us/azure/storage/tables/table-storage-overview)|

> The needs for the storage and retrieval of audit log data needs to be assessed to determine the most appropriate storage capability. Current options under consideration include Data Lake and Azure Table Storage.


> Need to confirm the current version of SQL Server that is utilised by ICMS and the ability to create an ODS in Azure. There are a number ICMS ODS currently created on-premise and it is the preference to use a similar method for the Azure version. If the current method is not possible then other technologies and methods will need to be assessed.
<br/>

The Enterprise Data Platform will leverage the "Advanced analytics on big data" design, as documented at [Advanced analytics on big data](https://azure.microsoft.com/en-us/solutions/architecture/advanced-analytics-on-big-data/) and depicted below.
![Modern Analytics Platform.png](../Data-Management/images/modern-analytics-platform.png)

## 4 Data Ownership and Co-existence
---
During the course of the implementation program it will be necessary for ICMS and Unify to co-exist, share data and share responsibility for implementing business processes.

Each data entity, or part of a data entity, will need to be designated as having a single owning application. The owning application will be responsible for implementing all business rules regarding how the data is updated. Other applications that wish to update this data must integrate real-time (Asynchronous Update pattern) and only commit the update if it is successful in the owning application.

## 5 Reference Data
---
Reference data needs to be maintained within each application and also at an enterprise level.

Each application, including Unify, will maintain it's own set of static reference data for elements such as Australian States (QLD), disabilities, concerns, gender and title.

Some of the static reference data, including some of the examples above, will be stored at an enterprise level and then refreshed in the necessary applications through integration. The enterprise level will also store a mapping of values from one application, or external party, to another application. The Enterprise Integration Platform will use this mapping information to translate message to the appropriate value for integration purposes. Each application will only receive and successfully accept static reference data, as part of an integration point, in it's own recognised values.

It is common to have static reference data stored separately form all the applications within an organisation. As Unify is going to be the primary application in the target state it is proposed that it is used to store  and manage static reference data. Using Unify to manage static reference data will allow greater upfront validation and reduce the overhead of a separate application.