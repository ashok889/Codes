# Application Architecture

## 1 Introduction
----
The application architecture describes the application components that will comprise the overall solution for Child Safety and Youth Justice that will be delivered over the coming years. It is organised into:
1. [On-Premise Applications](#2On-Premise-Applications)
2. [Azure Cloud Based Applications](#3Azure-Cloud-Based-Applications)
3. [Externally Facing Internet Applications](#4Externally-Facing-Internet-Applications) 

The following diagram depicts the significant application components for the program.

![Unify-Application-Architecture.png](./images/unify-application-architecture.png)


## 2 On-Premise Applications
----
### 2.1 ICMS
The existing ICMS platform will be retired at the conclusion of the program. However, during the program the current ICMS application will need to co-exist with Dynamics 365 Customer Engagement and share responsibility for both business process execution and also data.

> An existing, or new ICMS ODS, will be deployed in the Enterprise Data Platform to support read-only integration from Unify. The objective of this cloud based ICMS ODS is to reduce latency and increase reliability of any real-time integration between Unify and ICMS for read-only operations.

### 2.2 Existing Business Applications
Existing business applications, deployed on-premise, will remain and be integrated via via a shared service) will remain and be integration via the enterprise integration platform. New business applications, related to Child Safety and Youth Justice, will be targeted to be implemented within the Azure cloud. Existing applications will be considered for migration to the Azure cloud as significant enhancements are proposed.

### 2.3 Records Management
The existing records management platforms will remain and be integrated via the enterprise integration platform.

### 2.4 Data Warehouse
The existing existing data warehouse will remain but all new analytical reporting capabilities required by the program will be provided by the Enterprise Data Platform (Azure) where possible.

### 2.5 Financials
The existing financials platforms (provided via a shared service) will remain and be integrated via the enterprise integration platform.

## 3 Azure Cloud Based Applications
----
### 3.1 Dynamics 365 Customer Engagement
Microsoft Dynamics 365 Customer Engagement will be the major application platform that will support the business processes of Child Safety and Youth Justice. The application will be used by staff members and external stakeholders through the use of portal and mobile capabilities.

### 3.2 Data Platform
Microsoft Azure services will form the basis of the Enterprise Data Platform.

### 3.3 Business Productivity
The Microsoft Office 365 business productivity suite will be implemented for all departmental staff members and contractors that support and execute the business processes for Child Safety and Youth Justice.

The Office 365 products to be implemented include:
1. Outlook and Exchange for departmental email and calendar functions
2. Teams for messaging and team based collaboration
3. Sharepoint for document storage

### 3.4 Enterprise Integration Platform
The Enterprise Integration Platform will be based upon Microsoft Azure services and will be responsible for all message based integration between:
1. Applications that will be deployed as part of this program and on-premise applications. On-premise applications will make functionality available through existing technologies.
2. Message based integration to external stakeholders

## 4 Externally Facing Internet Applications
----
### 4.1 External Portals
The program is likely to implement externally facing portals for some or all of the following stakeholders:
1. Children and families
2. Community service providers
3. Government agencies, legal and law enforcement organisations who are involved in the Child Safety and Youth Justice business processes

Each of the portals to be deployed are assumed to be implement using one the following methods:
1. Deployment of Microsoft Dynamics 365 Portals which is tightly coupled with Dynamics 365 Customer Engagement
2. Custom developed portals that leverage data and business rules from Unify and Enterprise Data Platform. Custom developed portals will access the required data and business rules through the integration platform.