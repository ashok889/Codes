﻿#
# Unpack CSYW Common Solutions
#
# This powershell script will export a D365 solution as Unmanaged and extract it while placing it in the appropriate Azure DevOps repository folder for the Unify application
#

# Unpack following two lines if required or module is not installed
# Set-ExecutionPolicy Unrestricted
# Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201

#Update unqiue name of solution in below line to point to a different solution if needed
$solutionName ="SocialWelfareCore"
$packageFolder = "..\Dynamics365\Solutions\ExtractedSolutions\"
$serverUrl = "https://unify-dev01.crm6.dynamics.com/"
Set-StrictMode -Version latest

function InstallModule {
	Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
	$moduleName = "Microsoft.Xrm.Data.Powershell"
	$moduleVersion = "2.8.5"
	if (!(Get-Module -ListAvailable -Name $moduleName )) {
		Write-host "Module Not found, installing now..."
		$moduleVersion
		Install-Module -Name $moduleName -MinimumVersion $moduleVersion -Force
	}
	else
	{
		Write-host "Module $moduleName Found."
	}
}

function GetCrmConn{
	write-host "Establishing D365 connection..."
	$crm = Connect-CrmOnline -ServerUrl $serverUrl -Credential (Get-Credential) -ForceOAuth
	return $crm
}

InstallModule
Import-Module Microsoft.Xrm.Data.Powershell
Update-Module Microsoft.Xrm.Data.PowerShell -Force

$Crm1 = GetCrmConn
Set-CrmConnectionTimeout -conn $Crm1 -TimeoutInSeconds 90
write-host "connection established."
Write-Host "Exporting $solutionName Solution..."
Export-CrmSolution -conn $Crm1 -SolutionName "$solutionName" -SolutionFilePath $packageFolder -SolutionZipFileName "$solutionName.zip"
Write-host "Solution exported successfully"

Write-host "Unpacking the solution into repo directory"
 ..\SDKTools\D365v9.0\Tools\CoreTools\SolutionPackager.exe /action:Extract /packagetype:Unmanaged /folder:..\Dynamics365\Solutions\$solutionName /zipfile:$packageFolder$solutionName.zip
 Write-host "Unpacking is done. Don't forget to check-in the changes to Git."



