﻿using DES.Crm.Core.NotesAttachmentManagement.Configuration;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.NotesAttachmentManagement
{
    public partial class Plugin
    {
        private const string PreUpdateKey = "PreUpdate";

        public void Update(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService _tracr = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            if (context.MessageName.ToLower() != "update")
                //Invalid event attached
                return;

            if (context.InputParameters.Contains(CrmConstants.TargetParameterKey) && context.InputParameters[CrmConstants.TargetParameterKey] is Entity)
            {
                try
                {
                    Entity entity = (Entity)context.InputParameters[CrmConstants.TargetParameterKey];
                    if (entity.LogicalName != CrmConstants.AnnotationEntityName && entity.LogicalName != CrmConstants.AttachmentEntityName)
                        return;

                    if (!context.PreEntityImages.ContainsKey(PreUpdateKey) || context.PreEntityImages[PreUpdateKey] == null)
                    {
                        throw new InvalidPluginExecutionException(OperationStatus.Failed, string.Format("PreEntityImage could not be found when updating {0}", context.PrimaryEntityName));
                    }
                    Entity preUpdateEntity = context.PreEntityImages[PreUpdateKey];

                    if (!entity.Attributes.Keys.Contains(GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]))
                    {
                        //No change to binary data
                        return;
                    }

                    IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                    IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                    Configuration.IConfigurationProvider configurationProvider = Configuration.Factory.GetConfigurationProvider(service, entity.LogicalName, unsecurePluginStepConfiguration, securePluginStepConfiguration);
                    if (configurationProvider.StorageProviderType == Providers.StorageProviderType.CrmDefault)
                    {
                        //In this case, not doing anything with the binary data.
                        return;
                    }

                    Providers.IBinaryStorageProvider storageProvider = Providers.Factory.GetStorageProvider(configurationProvider);

                    //If the document body is empty, delete the external binary (filename is in the preupdate image)
                    if (string.IsNullOrWhiteSpace((string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]]))
                    {
                        _tracr.Trace("100"); 
                        storageProvider.Delete(preUpdateEntity.Id, (string)preUpdateEntity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]]);
                        _tracr.Trace("101");
                        QueryExpression q1x = new QueryExpression("rbs_blobattachment");

                        q1x.Criteria.AddCondition("rbs_storageurl", ConditionOperator.Like, "%" + preUpdateEntity.Id.ToString() + "%");

                        q1x.Criteria.AddCondition("rbs_storageurl", ConditionOperator.Like, "%" + (string)preUpdateEntity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]] + "%");
                        q1x.ColumnSet.AddColumn("activityid");
                        EntityCollection e1c = service.RetrieveMultiple(q1x);
                        _tracr.Trace("103");
                        _tracr.Trace(e1c.Entities.Count.ToString());
                        _tracr.Trace("54");
                        if (e1c.Entities.Count > 0)
                        {
                            foreach (Entity e in e1c.Entities)
                            {
                                service.Delete("rbs_blobattachment", new Guid(e.Attributes["activityid"].ToString()));
                            }

                        }
                        return;
                    }

                    byte[] data = Convert.FromBase64String((string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]]);
                    string fileName = (string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]];
                    if (storageProvider.Create(entity.Id, fileName, data))
                    {
                        entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]] = GenericConstants.EmptyBodyContent;
                        AzureBlobStorageConfiguration azurestorage = new AzureBlobStorageConfiguration(configurationProvider, entity.LogicalName);
                        string labelFromDatabase = " Azure storage URL :<a href=\"{0}\" target=\"_blank\"> link </a>";
                        string url = "https://" + azurestorage.StorageAccount + ".blob.core.windows.net/notes/" + string.Format("{0}_{1}", entity.Id.ToString(), fileName);
                        
                        _tracr.Trace(((EntityReference)preUpdateEntity.Attributes["objectid"]).LogicalName);
                        //create nnew entity record
                        Entity attachemntBlobs = new Entity("rbs_blobattachment");
                        attachemntBlobs.Attributes["subject"] = fileName;
                        attachemntBlobs.Attributes["rbs_storageurl"] = "https://" + azurestorage.StorageAccount + ".blob.core.windows.net/notes/" + string.Format("{0}_{1}", entity.Id.ToString(), fileName);
                        attachemntBlobs.Attributes["regardingobjectid"] = new EntityReference(((EntityReference)preUpdateEntity.Attributes["objectid"]).LogicalName, ((EntityReference)preUpdateEntity.Attributes["objectid"]).Id);
                        service.Create(attachemntBlobs);
                    
                        //If the plugin is running in async mode and is for attachment, we have to make a call to save the attachment.
                        if (context.Stage == CrmConstants.PostOperationStateNumber && entity.LogicalName == CrmConstants.AttachmentEntityName)
                        {
                            service.Update(entity);
                        }
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException(OperationStatus.Suspended, string.Format("The storage provider '{0}' failed to when calling 'Create' method.", configurationProvider.StorageProviderType));
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException(OperationStatus.Suspended, ex.ToString());
                }
            }
        }
    }
}