﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.NotesAttachmentManagement
{
    public partial class Plugin
    {
        private const string PreDeleteImageKey = "PreDelete";

        public void Delete(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                ITracingService _tracr = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                _tracr.Trace("0");
                if (context.MessageName.ToLower() != "delete")
                {
                    //Invalid event attached
                    _tracr.Trace(context.MessageName.ToLower());
                    return;
                }

                if (!context.PreEntityImages.ContainsKey(PreDeleteImageKey) || context.PreEntityImages[PreDeleteImageKey] == null)
                {
                    throw new InvalidPluginExecutionException(OperationStatus.Failed, string.Format("PreEntityImage could not be found when deleting {0}", context.PrimaryEntityName));
                }
                Entity entity = context.PreEntityImages[PreDeleteImageKey];
                if (entity.LogicalName != CrmConstants.AnnotationEntityName && entity.LogicalName != CrmConstants.AttachmentEntityName)
                {
                    _tracr.Trace("1");
                    //only valid for attachments and annotations
                    return;
                }

                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                Configuration.IConfigurationProvider configurationProvider = Configuration.Factory.GetConfigurationProvider(service, entity.LogicalName, unsecurePluginStepConfiguration, securePluginStepConfiguration);
                if (configurationProvider.StorageProviderType == Providers.StorageProviderType.CrmDefault)
                {
                    _tracr.Trace("2");//In this case, not doing anything for the external file.
                    return;
                }

                Providers.IBinaryStorageProvider storageProvider = Providers.Factory.GetStorageProvider(configurationProvider);

                if (entity.Attributes.ContainsKey(GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]))
                {
                    _tracr.Trace("3");
                    try
                    {
                        bool deleted = storageProvider.Delete(entity.Id, (string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]]);
                        _tracr.Trace(deleted.ToString());
                        #region get the record from BlobStorageEntity

                        //QueryExpression qx = new QueryExpression("rbs_blobattachment");
                        //qx.Criteria.AddCondition("rbs_storageurl", ConditionOperator.Contains, new object[] { entity.Id, (string)entity.Attributes[GenericConstants.FileNameAttributeKey] });
                        //EntityCollection ec = (EntityCollection)service.RetrieveMultiple(qx);
                        //_tracr.Trace(ec.Entities.Count.ToString());


                        if (deleted)
                        {
                            _tracr.Trace(entity.Id.ToString());
                            _tracr.Trace((string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]]);
                            QueryExpression q1x = new QueryExpression("rbs_blobattachment");

                            q1x.Criteria.AddCondition("rbs_storageurl", ConditionOperator.Like, "%" + entity.Id.ToString() + "%");
                           
                            q1x.Criteria.AddCondition("rbs_storageurl", ConditionOperator.Like, "%" + (string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]] + "%");
                            q1x.ColumnSet.AddColumn("activityid");
                            EntityCollection e1c = service.RetrieveMultiple(q1x);

                            _tracr.Trace(e1c.Entities.Count.ToString());
                            _tracr.Trace("54");
                            if (e1c.Entities.Count > 0)
                            {
                                foreach (Entity e in e1c.Entities)
                                {
                                    service.Delete("rbs_blobattachment", new Guid(e.Attributes["activityid"].ToString()));
                                }

                            }

                        }
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(OperationStatus.Suspended, ex.ToString());
            }
        }
    }
}
