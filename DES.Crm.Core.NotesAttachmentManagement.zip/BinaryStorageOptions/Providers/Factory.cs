﻿using DES.Crm.Core.NotesAttachmentManagement.Configuration;

namespace DES.Crm.Core.NotesAttachmentManagement.Providers
{
	public static class Factory
	{
		public static IBinaryStorageProvider GetStorageProvider(IConfigurationProvider configurationProvider)
		{
			IStorageProvider storageProvider = null;
			switch (configurationProvider.StorageProviderType)
			{
				case StorageProviderType.AzureBlob:
					storageProvider = new AzureBlobStorageProvider((AzureBlobStorageConfiguration)configurationProvider.Configuration);
					break;
				case StorageProviderType.AzureFile:
					
					break;
			}
			return new BinaryStorageProvider(configurationProvider, storageProvider);
		}

		public static ICompressionProvider GetCompressionProvider(CompressionProviderType providerType, IConfigurationProvider configurationProvider)
		{
			ICompressionProvider provider = new PassThroughCompressionProvider();
			switch (providerType)
			{
				case CompressionProviderType.Zip:
					
					break;
			}
			return provider;
		}

		public static IEncryptionProvider GetEncryptionProvider(EncryptionProviderType providerType, IConfigurationProvider configurationProvider)
		{
			IEncryptionProvider provider = new PassThroughEncryptionProvider();
			switch (providerType)
			{
				case EncryptionProviderType.AES256:
				//	provider = new AES256EncryptionProvider(configurationProvider);
					break;
			}
			return provider;
		}
	}
}
