﻿using System;
using System.Collections.Generic;

namespace DES.Crm.Core.NotesAttachmentManagement.Providers
{
	public interface IBinaryStorageProvider
	{
		List<string> GetFileNames();
		bool Create(Guid id, string filename, byte[] data);
		bool Delete(Guid id, string filename);
		byte[] Read(Guid id, string filename);
		int GetFileSize(Guid id, string filename);
	}
}
