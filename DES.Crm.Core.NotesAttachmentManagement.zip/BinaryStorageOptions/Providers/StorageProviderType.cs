﻿namespace DES.Crm.Core.NotesAttachmentManagement.Providers
{
	public enum StorageProviderType
	{
		CrmDefault = 0,
		AzureBlob = 1,
		AzureFile = 2,
	}
}
