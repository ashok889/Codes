﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.NotesAttachmentManagement.Providers
{
	public enum CompressionProviderType
	{
		PassThrough = 0,
		Zip = 1,
	}
}
