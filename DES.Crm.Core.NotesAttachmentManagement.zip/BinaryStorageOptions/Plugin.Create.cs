﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.NotesAttachmentManagement.Configuration;
namespace DES.Crm.Core.NotesAttachmentManagement
{
    public partial class Plugin
    {
        public object MessageName { get; private set; }

        public void Create(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            if (context.MessageName != "Create")
                //Invalid event attached
                return;

            if (context.InputParameters.Contains(CrmConstants.TargetParameterKey) && context.InputParameters[CrmConstants.TargetParameterKey] is Entity)
            {
                try
                {
                    Entity entity = (Entity)context.InputParameters[CrmConstants.TargetParameterKey];
                    if (entity.LogicalName != CrmConstants.AnnotationEntityName && entity.LogicalName != CrmConstants.AttachmentEntityName)
                        return;

                    if (!entity.Attributes.Keys.Contains(GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]) || string.IsNullOrWhiteSpace((string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]]))
                    {
                        //No binary data
                        return;
                    }

                    IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                    IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                    Configuration.IConfigurationProvider configurationProvider = Configuration.Factory.GetConfigurationProvider(service, entity.LogicalName, unsecurePluginStepConfiguration, securePluginStepConfiguration);
                    if (configurationProvider.StorageProviderType == Providers.StorageProviderType.CrmDefault)
                    {
                        //In this case, not doing anything with the binary data.
                        return;
                    }

                    //This check is actually a bit useless for sandboxed pluxings.  CRM is bugged and won't allow anything bigger than 5mb, the plugin sandbox will just crash.
                    if (entity.Attributes.Keys.Contains(CrmConstants.FileSizeKey) && (int)entity.Attributes[CrmConstants.FileSizeKey] > configurationProvider.MaxFileSize)
                        throw new InvalidPluginExecutionException(OperationStatus.Failed, string.Format("FileSize Limit of {0} bytes was exceeded.", configurationProvider.MaxFileSize));
                    
                    Providers.IBinaryStorageProvider storageProvider = Providers.Factory.GetStorageProvider(configurationProvider);

                    byte[] data = Convert.FromBase64String((string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]]);
                    string fileName = (string)entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.FileNameAttributeKey]];
                    if (storageProvider.Create(entity.Id, fileName, data))
                    {
                       
                        entity.Attributes[GenericConstants.Constants[entity.LogicalName][GenericConstants.DocumentBodyAttributeKey]] = GenericConstants.EmptyBodyContent;

                        //If the plugin is running in async mode and is for attachment, we have to make a call to save the attachment.
                        
                        AzureBlobStorageConfiguration azurestorage = new AzureBlobStorageConfiguration(configurationProvider, entity.LogicalName);
                        trace.Trace(azurestorage.StorageAccount);
                      //  string labelFromDatabase = " Azure storage URL :<a href=\"{0}\" target=\"_blank\"> link </a>";
                      //  string url = "https://" + azurestorage.StorageAccount + ".blob.core.windows.net/notes/" + string.Format("{0}_{1}", entity.Id.ToString(), fileName);

                        //    entity.Attributes["notetext"] = entity.Attributes["notetext"] + String.Format(labelFromDatabase, url);
                        //entity.Attributes["documentbody"] = null;
                        //entity.Attributes["filename"] = null;
                        //entity.Attributes["filesize"] = null;
                        //entity.Attributes["isdocument"] = false;
                        trace.Trace(azurestorage.StorageAccount);
                     //   service.Update(entity);
                        trace.Trace(((EntityReference)entity.Attributes["objectid"]).LogicalName);
                        //create nnew entity record
                        Entity attachemntBlobs = new Entity("rbs_blobattachment");
                        attachemntBlobs.Attributes["subject"] = fileName;
                        attachemntBlobs.Attributes["rbs_storageurl"] = "https://" + azurestorage.StorageAccount + ".blob.core.windows.net/notes/" + string.Format("{0}_{1}", entity.Id.ToString(), fileName);
                        attachemntBlobs.Attributes["regardingobjectid"] = new EntityReference(((EntityReference)entity.Attributes["objectid"]).LogicalName, ((EntityReference)entity.Attributes["objectid"]).Id);
                        service.Create(attachemntBlobs);
                        if (context.Stage == CrmConstants.PostOperationStateNumber && entity.LogicalName == CrmConstants.AttachmentEntityName)
                        {
                            service.Update(entity);
                        }
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException(OperationStatus.Suspended, string.Format("The storage provider '{0}' failed to when calling 'Create' method.", configurationProvider.StorageProviderType));
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException(OperationStatus.Suspended, ex.ToString());
                }
            }
        }
    }
}