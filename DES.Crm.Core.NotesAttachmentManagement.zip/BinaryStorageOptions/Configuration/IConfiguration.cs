﻿namespace DES.Crm.Core.NotesAttachmentManagement.Configuration
{
	public interface IConfiguration
	{
	}
}
