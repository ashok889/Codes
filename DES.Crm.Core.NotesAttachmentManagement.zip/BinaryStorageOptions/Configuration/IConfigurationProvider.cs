﻿using DES.Crm.Core.NotesAttachmentManagement.Providers;

namespace DES.Crm.Core.NotesAttachmentManagement.Configuration
{
	public interface IConfigurationProvider
	{
		IConfiguration Configuration { get; }
		StorageProviderType StorageProviderType { get; }
		CompressionProviderType CompressionProviderType { get; }
		EncryptionProviderType EncryptionProviderType { get; }
		string GetSettingValue(string key);
		int MaxFileSize { get; }
	}
}
