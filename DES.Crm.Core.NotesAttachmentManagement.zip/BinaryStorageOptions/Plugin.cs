﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.NotesAttachmentManagement
{
	public partial class Plugin : IPlugin
	{
		private readonly string unsecurePluginStepConfiguration;
		private readonly string securePluginStepConfiguration;

		public Plugin(string unsecurePluginStepConfiguration, string securePluginStepConfiguration)
		{
			this.unsecurePluginStepConfiguration = unsecurePluginStepConfiguration;
			this.securePluginStepConfiguration = securePluginStepConfiguration;
		}

		public void Execute(IServiceProvider serviceProvider)
		{
			IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

			switch (context.MessageName)
			{
                case "Create":
					Create(serviceProvider);
					break;
                case "Delete":
                    Delete(serviceProvider);

                    break;
                case "Update":
                    Update(serviceProvider);

                    break;


            }
		}
	}
}
