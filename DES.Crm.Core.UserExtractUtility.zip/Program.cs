﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.Common.Security;


namespace UserExtractUtility
{
    class Program

    {
        public static CrmServiceClient _client = null;
        public static IOrganizationService _orgService;
        public static void Main(string[] args)

        {
            // Create Connection with CRM and initialize the object of CrmServiceClient
            CrmServiceClient crmSvc = null;

            if (crmSvc != null){}
            else
            {
                
                crmSvc = new CrmServiceClient(crmUserId: ConfigurationManager.AppSettings["crmUserId"], crmPassword: CrmServiceClient.MakeSecureString(ConfigurationManager.AppSettings["crmPassword"]), crmRegion: ConfigurationManager.AppSettings["crmRegion"], orgName: ConfigurationManager.AppSettings["crmOrgName"], isOffice365: true);
               // crmSvc = new CrmServiceClient(crmUserId: "nidhikapathak.pande@rbs.co.uk", crmPassword: CrmServiceClient.MakeSecureString("nigari2014@"), crmRegion: "EMEA", orgName: "bwcddprd", isOffice365: true);

              

                if (crmSvc.IsReady)
                {
                    _orgService = (IOrganizationService)crmSvc.OrganizationWebProxyClient != null ? (IOrganizationService)crmSvc.OrganizationWebProxyClient : (IOrganizationService)crmSvc.OrganizationServiceProxy;



                    List<Containers> lstContainers = new List<Containers>();
                    String SystemUsers = String.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                                        <entity name='systemuser' >
                                                            <attribute name='systemuserid' />
                                                            <attribute name='businessunitid' />
                                                            <attribute name='fullname' />
                                                            <attribute name='internalemailaddress' />
                                                            <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' visible='false' link-type='outer' alias='a' >
                                                                <attribute name='roleid' />
                                                                <link-entity name='role' from='roleid' to='roleid' visible='false' link-type='outer' alias='role' >
                                                                    <attribute name='name' />
                                                                </link-entity>
                                                            </link-entity>
                                                            <link-entity name='teammembership' from='systemuserid' to='systemuserid' visible='false' link-type='outer' alias='c' >
                                                                <attribute name='teamid' />
                                                                <link-entity name='team' from='teamid' to='teamid' visible='false' link-type='outer' alias='team' >
                                                                    <attribute name='name' />
                                                                </link-entity>
                                                            </link-entity>
                                                            <filter type='and'>      
                                                            <condition attribute='isdisabled' value='0' operator='eq'/>
                                                            </filter>
                                                        </entity>
                                                    </fetch>");

                    EntityCollection colSystemUsers = _orgService.RetrieveMultiple(new FetchExpression(SystemUsers));
                    if (colSystemUsers != null && colSystemUsers.Entities.Count > 0)
                    {
                        foreach (Entity entity in colSystemUsers.Entities)
                        {
                            Containers containers = new Containers();
                            containers.SystemUserId = entity.GetAttributeValue<Guid>("systemuserid");
                            containers.BusinessUnit = entity.GetAttributeValue<EntityReference>("businessunitid").Name;
                            containers.SystemUserName = entity.GetAttributeValue<String>("fullname");
                            containers.PrimaryEmail = entity.GetAttributeValue<String>("internalemailaddress");
                            containers.SystemUsersRoles = entity.GetAttributeValue<AliasedValue>("role.name") != null ? Convert.ToString(entity.GetAttributeValue<AliasedValue>("role.name").Value) : String.Empty;
                            containers.Teams = entity.GetAttributeValue<AliasedValue>("team.name") != null ? Convert.ToString(entity.GetAttributeValue<AliasedValue>("team.name").Value) : String.Empty;
                            lstContainers.Add(containers);
                        }
                        if (lstContainers != null && lstContainers.Count > 0)
                        {
                            List<Containers> lstFinalContainers = new List<Containers>();
                            #region "Get User Related Data from LIST"
                            var users = lstContainers.GroupBy(x => x.SystemUserId);
                            foreach (var item in users)
                            {
                                var listitem = lstContainers.Where(x => x.SystemUserId.Equals(new Guid(item.Key.ToString()))).ToList();
                               
                                var roleCount = listitem.ToList().Select(s => s.SystemUsersRoles).Distinct().Count();
                                var teamsCount = listitem.ToList().Select(s => s.Teams).Distinct().Count();
                                var roles = listitem.ToList().Select(s => s.SystemUsersRoles).Distinct();
                                var teams = listitem.ToList().Select(s => s.Teams).Distinct();
                                var length = teamsCount > roleCount ? teamsCount : roleCount;
                                for (int i = 0; i < length; i++)
                                {
                                    Containers objContainer = new Containers();
                                    objContainer.SystemUserId = listitem[0].SystemUserId;
                                    objContainer.BusinessUnit = listitem[0].BusinessUnit;
                                    objContainer.SystemUserName = listitem[0].SystemUserName;
                                    objContainer.PrimaryEmail = listitem[0].PrimaryEmail;
                                                                       
                                    objContainer.SystemUsersRoles = roles.ToList().Count > i ? roles.ToList()[i] : "" ;
                                    objContainer.Teams = teams.ToList().Count > i ? teams.ToList()[i] : "" ;

                                    lstFinalContainers.Add(objContainer);

                                }                                                                   
                                
                            }
                            #endregion
                            if (lstFinalContainers != null && lstFinalContainers.Count > 0)
                            {
                                DataTable dt = ConvertToDataTable<Containers>(lstFinalContainers);
                                CreateCSVFile(dt, ConfigurationManager.AppSettings["CSVExportPath"]);
                              //  CreateCSVFile(dt, "C:\\Mohit\\test.csv");

                            }
                        }
                    }
                }
            }
        }
        public static DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public static void CreateCSVFile(DataTable dt, string strFilePath)
        {
            #region Export Grid to CSV
            // Create the CSV file to which grid data will be exported.
            StreamWriter sw = new StreamWriter(strFilePath, false);
            // First we will write the headers.
            //DataTable dt = m_dsProducts.Tables[0];
            int iColCount = dt.Columns.Count;
            for (int i = 0; i < iColCount; i++)
            {
                sw.Write(dt.Columns[i]);
                if (i < iColCount - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            // Now write all the rows.
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < iColCount; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        sw.Write(dr[i].ToString());
                    }
                    if (i < iColCount - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
            #endregion
        }
        class Containers
        {
            public Guid SystemUserId { get; set; }
            public String SystemUserName { get; set; }
            public String PrimaryEmail { get; set; }
            public String SystemUsersRoles { get; set; }
            public String BusinessUnit { get; set; }
            public String Teams { get; set; }
        }

    }
}




