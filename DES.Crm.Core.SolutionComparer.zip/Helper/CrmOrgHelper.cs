﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Reflection;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Crm.Sdk.Messages;
using System.Net;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.IO.Packaging;

namespace Microsoft.Crm.Sdk.Samples
{
    /// <summary>
    /// Demonstrate how to do basic authentication using IServiceManagement and SecurityTokenResponse.
    /// </summary>
    class CrmOrgHelper
    {
        AuthenticationProviderType endpointType = AuthenticationProviderType.OnlineFederation;
        ClientCredentials clientCredentials = new ClientCredentials();
        //Folder name for exported Solution files.
        public String exportFolder = "ExportedSolutionXml";

        internal DiscoveryServiceProxy getDiscoveryServiceProxy(DiscoveryServiceProxy discoveryProxy,string _discoveryServiceAddress, string userName, string Password)
        {
            //Refresh Discovery Service, if endpoint mismatches
            if (discoveryProxy != null && discoveryProxy.ServiceConfiguration.CurrentServiceEndpoint.ListenUri.OriginalString != _discoveryServiceAddress)
                discoveryProxy = null;

            if (discoveryProxy == null)
            {
                //serviceManagement.AuthenticationType;
                clientCredentials.UserName.UserName = userName;
                clientCredentials.UserName.Password = Password;

                Uri serviceUri = new Uri(_discoveryServiceAddress);
                IServiceConfiguration<IDiscoveryService> servConf = ServiceConfigurationFactory.CreateConfiguration<IDiscoveryService>(serviceUri); ;
                DiscoveryServiceProxy _discoveryProxy = new DiscoveryServiceProxy(servConf, clientCredentials);// new Uri(_discoveryServiceAddress), null, clientCredentials, null);
                _discoveryProxy.Authenticate();

                // Get the discovery service proxy.
                using (discoveryProxy = _discoveryProxy)
                {
                    // Obtain organization information from the Discovery service. 
                    if (discoveryProxy != null)
                    {
                        // Obtain information about the organizations that the system user belongs to.
                        return discoveryProxy;
                    }
                }
            }
            return discoveryProxy;
        }

        internal OrganizationServiceProxy getOrgServiceProxy(string organizationUri)
        {
            if (!String.IsNullOrWhiteSpace(organizationUri))
            {
                IServiceManagement<IOrganizationService> orgServiceManagement =
                    ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                    new Uri(organizationUri));

                //Get the organization service proxy.
                using (OrganizationServiceProxy organizationProxy = new OrganizationServiceProxy(orgServiceManagement, clientCredentials))
                {
                    // This statement is required to enable early-bound type support.
                    //organizationProxy.EnableProxyTypes();
                    organizationProxy.Authenticate();
                    return organizationProxy;
                }
            }
            return null;
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        public OrganizationDetailCollection DiscoverOrganizations(
            IDiscoveryService service)
        {
                if (service == null) throw new ArgumentNullException("service");
                RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
                RetrieveOrganizationsResponse orgResponse =
                    (RetrieveOrganizationsResponse)service.Execute(orgRequest);

                return orgResponse.Details;
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name="orgUniqueName">The unique name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        public OrganizationDetail FindOrganization(string orgUniqueName,
            OrganizationDetail[] orgDetails)
        {
            if (String.IsNullOrWhiteSpace(orgUniqueName))
                throw new ArgumentNullException("orgUniqueName");
            if (orgDetails == null)
                throw new ArgumentNullException("orgDetails");
            OrganizationDetail orgDetail = null;

            foreach (OrganizationDetail detail in orgDetails)
            {
                if (String.Compare(detail.UniqueName, orgUniqueName,
                    StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    orgDetail = detail;
                    break;
                }
            }
            return orgDetail;
        }

        public EntityCollection getAllSolutions(OrganizationServiceProxy orgService)
        {
            //Connect to the Organization service.
            //The using statement assures that the service proxy will be properly disposed.
            if (orgService != null)
            {
                //Check whether it already exists
                QueryExpression query = new QueryExpression()
                {
                    EntityName = "solution",
                    ColumnSet = new ColumnSet(true)
                };

                return orgService.RetrieveMultiple(query);
            }
            else
                return null;
        }

        /// <summary>
        /// A helper method that decompresses the the Ribbon data returned
        /// </summary>
        /// <param name="data">The compressed ribbon data</param>
        /// <returns></returns>
        public byte[] unzipRibbon(byte[] data)
        {
            System.IO.Packaging.ZipPackage package = null;
            MemoryStream memStream = null;

            memStream = new MemoryStream();
            memStream.Write(data, 0, data.Length);
            package = (ZipPackage)ZipPackage.Open(memStream, FileMode.Open);

            ZipPackagePart part = (ZipPackagePart)package.GetPart(new Uri("/Solution.xml", UriKind.Relative));
            using (Stream strm = part.GetStream())
            {
                long len = strm.Length;
                byte[] buff = new byte[len];
                strm.Read(buff, 0, (int)len);
                return buff;
            }
        }

        public void compareSolutions(OrganizationServiceProxy orgService)
        {
            ////Create export folder for ribbon xml files if not already exist.
            //if (!Directory.Exists(exportFolder))
            //    Directory.CreateDirectory(exportFolder);

            ////Retrieve the Appliation Ribbon
            //ExportSolutionRequest appReq = new ExportSolutionRequest();
            //ExportSolutionResponse appResp = (ExportSolutionResponse)orgService.Execute(appReq);

            //System.String solutionPath = Path.GetFullPath(exportFolder + "\\Solution.xml");
            //File.WriteAllBytes(solutionPath, unzipRibbon(appResp.ExportSolutionFile));
            ////Write the path where the file has been saved.
            //Console.WriteLine(solutionPath);
            ////Retrieve system Entity Ribbons
            //RetrieveEntityRibbonRequest entRibReq = new RetrieveEntityRibbonRequest() { RibbonLocationFilter = RibbonLocationFilters.All };
            //System.String[] entitiesWithRibbons = { "account", "activitymimeattachment" };

            //foreach (System.String entityName in entitiesWithRibbons)
            //{
            //    entRibReq.EntityName = entityName;
            //    RetrieveEntityRibbonResponse entRibResp = (RetrieveEntityRibbonResponse)orgService.Execute(entRibReq);

            //    System.String entityRibbonPath = Path.GetFullPath(exportFolder + "\\" + entityName + "Ribbon.xml");
            //    File.WriteAllBytes(entityRibbonPath, unzipRibbon(entRibResp.CompressedEntityXml));
            //    //Write the path where the file has been saved.
            //    Console.WriteLine(entityRibbonPath);
            //}

            ////Check for custom entities
            //RetrieveAllEntitiesRequest raer = new RetrieveAllEntitiesRequest() { EntityFilters = EntityFilters.Entity };

            //RetrieveAllEntitiesResponse resp = (RetrieveAllEntitiesResponse)orgService.Execute(raer);

            //foreach (EntityMetadata em in resp.EntityMetadata)
            //{
            //    if (em.IsCustomEntity == true && em.IsIntersect == false)
            //    {
            //        entRibReq.EntityName = em.LogicalName;
            //        RetrieveEntityRibbonResponse entRibResp = (RetrieveEntityRibbonResponse)orgService.Execute(entRibReq);

            //        System.String entityRibbonPath = Path.GetFullPath(exportFolder + "\\" + em.LogicalName + "Ribbon.xml");
            //        File.WriteAllBytes(entityRibbonPath, unzipRibbon(entRibResp.CompressedEntityXml));
            //        //Write the path where the file has been saved.
            //        Console.WriteLine(entityRibbonPath);
            //    }
            //}
        }
    }
}