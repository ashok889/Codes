﻿using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Crm.Sdk.Samples;
using System.IO;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Net;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk;
using System.Runtime.InteropServices;
using System.Threading;
using DES.Crm.Core.SolutionComparer.DifferenceEngine;
using System.Collections;
using System.IO.Compression;
using System.ServiceModel;

namespace DES.Crm.Core.SolutionComparer
{
    public partial class Login : Form
    {
        #region Initialize
        #region Class Level Members
        private CrmOrgHelper auth = new CrmOrgHelper();
        private DiscoveryServiceProxy discService = null;
        private DiscoveryServiceProxy discService2 = null;
        private OrganizationServiceProxy orgService = null;
        private OrganizationServiceProxy orgService2 = null;
        private OrganizationDetailCollection orgColls;
        private OrganizationDetailCollection orgColls2;
        private List<CustPackagePart> pckPartColl = new List<CustPackagePart>();
        private List<CustPackagePart> pckPartColl2 = new List<CustPackagePart>();

        private BackgroundWorker bW_LoadOrgs1 = new BackgroundWorker();
        private BackgroundWorker bW_LoadSolutions1 = new BackgroundWorker();
        private BackgroundWorker bW_DownloadSolution1 = new BackgroundWorker();
        private BackgroundWorker bW_LoadOrgs2 = new BackgroundWorker();
        private BackgroundWorker bW_LoadSolutions2 = new BackgroundWorker();
        private BackgroundWorker bW_DownloadSolution2 = new BackgroundWorker();
        private BackgroundWorker bW_CompareFiles = new BackgroundWorker();
        private object _ecSolutions;
        private object _ecSolutions2;
        private string orgURI;
        private string orgURI2;
        private string orgName1;
        private string orgName2;

        public string SolName2 { get; private set; }
        public string SolName { get; private set; }

        #endregion
        public Login()
        {
            InitializeComponent();
            InitializeData();
        }
        private void InitializeData()
        {
            PositionControls();
            LoadDefaultData();
            AttachDefaultEvents();
        }
        private void AttachDefaultEvents()
        {
            bW_LoadOrgs1.DoWork += BackgroundWorker1_LoadOrgs;
            bW_LoadOrgs1.ProgressChanged += BackgroundWorker1_ProgressChanged;
            bW_LoadOrgs1.RunWorkerCompleted += BackgroundWorker1_LoadOrgsCompleted;

            bW_LoadSolutions1.DoWork += BW_LoadSolutions_DoWork;
            bW_LoadSolutions1.ProgressChanged += BackgroundWorker1_ProgressChanged;
            bW_LoadSolutions1.RunWorkerCompleted += BW_LoadSolutions_RunWorkerCompleted;

            bW_DownloadSolution1.DoWork += BW_DownloadSolution_DoWork;
            bW_DownloadSolution1.ProgressChanged += BackgroundWorker1_ProgressChanged;
            bW_DownloadSolution1.RunWorkerCompleted += BW_DownloadSolution_RunWorkerCompleted;

            bW_LoadOrgs2.DoWork += BW_LoadOrgs2_DoWork;
            bW_LoadOrgs2.ProgressChanged += BW_LoadOrgs2_ProgressChanged;
            bW_LoadOrgs2.RunWorkerCompleted += BW_LoadOrgs2_RunWorkerCompleted;

            bW_LoadSolutions2.DoWork += BW_LoadSolutions2_DoWork;
            bW_LoadSolutions2.ProgressChanged += BW_LoadOrgs2_ProgressChanged;
            bW_LoadSolutions2.RunWorkerCompleted += BW_LoadSolutions2_RunWorkerCompleted;

            bW_DownloadSolution2.DoWork += BW_DownloadSolution2_DoWork;
            bW_DownloadSolution2.ProgressChanged += BW_LoadOrgs2_ProgressChanged;
            bW_DownloadSolution2.RunWorkerCompleted += BW_DownloadSolution2_RunWorkerCompleted;

            bW_CompareFiles.DoWork += BW_CompareFiles_DoWork;
            bW_CompareFiles.ProgressChanged += BW_CompareFiles_ProgressChanged;
            bW_CompareFiles.RunWorkerCompleted += BW_CompareFiles_RunWorkerCompleted;
        }
        private void LoadDefaultData()
        {
            //Check For Same Cred
            if (chkSameCredentials.Checked)
            {
                txtUserName2.Enabled = false;
                txtPassword2.Enabled = false;
            }

            // no smaller than design time size
            MinimumSize = new Size(this.Width, this.Height);
            // no larger than screen size
            //this.MaximumSize = new System.Drawing.Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, (int)System.Windows.SystemParameters.PrimaryScreenHeight);
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;

            lblStatus.Text = string.Empty;
            lblSelectedFile1.Text = string.Empty;
            lblSelectedFile2.Text = string.Empty;
            lblBrowseFile1.Text = string.Empty;
            lblBrowseFile2.Text = string.Empty;

            // cmbRegions
            List<Regions> personList = new List<Regions>();
            personList.Add(new Regions { Name = "EMEA", Value = "crm4.dynamics.com" });
            personList.Add(new Regions { Name = "North America", Value = "crm.dynamics.com" });
            personList.Add(new Regions { Name = "South America", Value = "crm2.dynamics.com" });
            personList.Add(new Regions { Name = "Canada", Value = "crm3.dynamics.com" });
            personList.Add(new Regions { Name = "APAC", Value = "crm5.dynamics.com" });
            personList.Add(new Regions { Name = "Australia", Value = "crm6.dynamics.com" });
            personList.Add(new Regions { Name = "Japan", Value = "crm7.dynamics.com" });
            personList.Add(new Regions { Name = "India", Value = "crm8.dynamics.com" });
            personList.Add(new Regions { Name = "United Kingdom", Value = "crm11.dynamics.com" });

            cmbRegions.DataSource = personList;
            cmbRegions.DisplayMember = "Name";
            cmbRegions.ValueMember = "Value";

            cmbRegions2.DataSource = personList;
            cmbRegions2.DisplayMember = "Name";
            cmbRegions2.ValueMember = "Value";
        }
        private void Login_Resize(object sender, EventArgs e)
        {
            PositionControls();
        }
        private void PositionControls()
        {
            grpCompareBox.Width = Convert.ToInt32(this.Width * 0.49);
            grpCompareBox2.Width = Convert.ToInt32(this.Width * 0.49);

            grpSolution2.Location = new Point(Convert.ToInt32(this.Width * 0.495), 47);

            grpSolution1.Width = Convert.ToInt32(this.Width * 0.48);
            grpSolution2.Width = Convert.ToInt32(this.Width * 0.48);

            grpSolution1.Height = Convert.ToInt32(this.Height * 0.76);
            grpSolution2.Height = Convert.ToInt32(this.Height * 0.76);

            pnlSolution.Width = Convert.ToInt32(this.Width);

            btnCompare.Location = new Point(Convert.ToInt32(pnlSolution.Width - 150), Convert.ToInt32(pnlSolution.Height - 30));

            lblFile1.Location = new Point(10, 0);
            lblSelectedFile1.Location = new Point(50, 0);
            lblFile2.Location = new Point(Convert.ToInt32(pnlSolution.Width * 0.5), 0);
            lblSelectedFile2.Location = new Point(Convert.ToInt32(pnlSolution.Width * 0.5) + 50, 0);
        }
        #endregion

        #region Common
        public class Regions
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }
        private List<CustPackagePart> ExportCRMSolution(CheckBox chkLastSol, string SolutionName, string OutputDir, OrganizationServiceProxy orgService, bool isFileExternal)
        {
            List<CustPackagePart> localPckPartColl = new List<CustPackagePart>();
            if (!isFileExternal)
            {
                if (!chkLastSol.Checked || !File.Exists(OutputDir))
                {
                    var exportSolutionRequest = new ExportSolutionRequest();
                    exportSolutionRequest.Managed = false;
                    exportSolutionRequest.SolutionName = SolutionName;
                    var exportSolutionResponse = (ExportSolutionResponse)orgService.Execute(exportSolutionRequest);

                    byte[] exportXml = exportSolutionResponse.ExportSolutionFile;

                    File.WriteAllBytes(OutputDir, exportXml);
                }
            }
            //using (Package package = Package.Open(OutputDir, FileMode.Open, FileAccess.Read))
            //{
            //    localPckPartColl = (from val in package.GetParts()
            //                        select new CustPackagePart
            //                        {
            //                            URI = val.Uri.OriginalString,
            //                            Stream = getStreamToText(val.GetStream()),
            //                            Lines = getStreamToText(val.GetStream()).Split('\n').Length
            //                        }).ToList();


            //}

            //using (var zipStream = new FileStream(OutputDir, FileMode.Open))
            //using (var archive = new ZipArchive(zipStream, ZipArchiveMode.Read))
            //{
            //    foreach (var entry in archive.Entries)
            //    {
            //        using (var stream = entry.Open())
            //        using (var reader = new StreamReader(stream))
            //        {
            //            //Console.WriteLine(reader.ReadToEnd());
            //        }
            //    }
            //}

            using (ZipArchive archive = ZipFile.OpenRead(OutputDir))
            {
                localPckPartColl = (from val in archive.Entries
                                    select new CustPackagePart
                                    {
                                        URI = val.FullName,
                                        Stream = new StreamReader(val.Open()).ReadToEnd(),
                                        Lines = new StreamReader(val.Open()).ReadToEnd().Split('\n').Length
                                    }).ToList();
                //foreach (ZipArchiveEntry entry in archive.Entries)
                //{
                //    entry.
                //}
            }

            return localPckPartColl;
        }
        private void loadPackageToList(ListView lstBox, ListView lstBox2, List<CustPackagePart> pckPartColl, List<CustPackagePart> comparePckPartColl)
        {
            //try
            //{
            if (pckPartColl == null || comparePckPartColl == null)
                return;

            lstBox.Items.Clear(); lstBox2.Items.Clear();
            var lstPckPartColl = (from val in pckPartColl
                                  select new lstPckPartCollClass
                                  {
                                      URI = val.URI,
                                      Stream = val.Stream,
                                      Lines = val.Lines
                                  }).OrderBy(x => x.URI).ToList();

            var lstPckPartColl2 = (from val in comparePckPartColl
                                   select new lstPckPartCollClass
                                   {
                                       URI = val.URI,
                                       Stream = val.Stream,
                                       Lines = val.Lines
                                   }).OrderBy(x => x.URI).ToList();

            int maxIndex = 0; int maxTextLength = 50;
            if (lstPckPartColl.Count > lstPckPartColl2.Count) maxIndex = lstPckPartColl.Count;
            else maxIndex = lstPckPartColl2.Count;

            for (int i = 0; i < maxIndex; i++)
            {
                ListViewItem itmLV = new ListViewItem(new string[] { (lstPckPartColl.Count > i ? lstPckPartColl[i].URI : "") + " [Lines:" + (lstPckPartColl.Count > i ? lstPckPartColl[i].Lines.ToString() : "") + "]" });
                ListViewItem itmLV2 = new ListViewItem(new string[] { (lstPckPartColl2.Count > i ? lstPckPartColl2[i].URI : "") + " [Lines:" + (lstPckPartColl2.Count > i ? lstPckPartColl2[i].Lines.ToString() : "") + "]" });
                // If Both Matches, Compare the Files & check for differences
                if (lstPckPartColl.Count > i && lstPckPartColl2.Count > i && lstPckPartColl[i].URI == lstPckPartColl2[i].URI)
                {
                    string txtStream = lstPckPartColl[i].Stream;
                    string txtStream2 = lstPckPartColl2[i].Stream;

                    if (txtStream != txtStream2)
                    {
                        itmLV.Text = lstPckPartColl[i].URI + " [DIFF FOUND]";
                        itmLV.Text += " [Lines:" + lstPckPartColl[i].Lines + "]";
                        itmLV.BackColor = Color.Yellow;

                        itmLV2.Text = lstPckPartColl2[i].URI + " [DIFF FOUND]";
                        itmLV2.Text += " [Lines:" + lstPckPartColl2[i].Lines + "]";
                        itmLV2.BackColor = Color.Yellow;
                    }
                }
                else //Missing, So adjust the index
                {
                    //check if left itm is not in right collection
                    if (lstPckPartColl.Count > i && lstPckPartColl2.Where(c => c != null && c.URI == lstPckPartColl[i].URI).Count() == 0)
                    {
                        itmLV.Text = lstPckPartColl[i].URI + " [MISSING]";
                        itmLV.Text += " [Lines:" + lstPckPartColl[i].Lines + "]";
                        itmLV.BackColor = Color.LightPink;

                        itmLV2.Text = " ";
                        itmLV2.BackColor = Color.Gray;

                        lstPckPartColl2.Insert(i, null);
                        if (lstPckPartColl.Count > lstPckPartColl2.Count) maxIndex = lstPckPartColl.Count;
                        else maxIndex = lstPckPartColl2.Count;
                    }
                    else //if left itm exists in right collection, but at other index
                    {
                        itmLV2.Text = lstPckPartColl2[i].URI + " [MISSING]";
                        itmLV2.Text += " [Lines:" + lstPckPartColl2[i].Lines + "]";
                        itmLV2.BackColor = Color.LightPink;

                        itmLV.Text = " ";
                        itmLV.BackColor = Color.Gray;

                        lstPckPartColl.Insert(i, null);
                        if (lstPckPartColl.Count > lstPckPartColl2.Count) maxIndex = lstPckPartColl.Count;
                        else maxIndex = lstPckPartColl2.Count;
                    }
                }

                itmLV.Text = (lstBox.Items.Count + 1) + ". " + itmLV.Text;
                lstBox.Items.Add(itmLV);

                itmLV2.Text = (lstBox2.Items.Count + 1) + ". " + itmLV2.Text;
                lstBox2.Items.Add(itmLV2);
                if (maxTextLength < itmLV2.Text.Length)
                    maxTextLength = itmLV2.Text.Length;
            }


            //int index = 0;
            //foreach (string pckPartUri in lstPckPartColl)
            //{
            //    ListViewItem itmLV = new ListViewItem(new string[] { pckPartUri });
            //    //Check if Missing
            //    if (comparePckPartColl.Where(c => c.Uri.OriginalString == pckPart.Uri.OriginalString).Count() == 0)
            //    {
            //        itmLV.Text = pckPart.Uri.OriginalString + " [MISSING]";
            //        itmLV.BackColor = Color.LightPink;
            //    }
            //    else // If Not Missing Then Compare
            //    {
            //        Stream Stream2 = comparePckPartColl.Where(c => c.Uri.OriginalString == pckPart.Uri.OriginalString).First<PackagePart>().GetStream();

            //        string txtStream = getStreamToText(pckPart.GetStream());
            //        string txtStream2 = getStreamToText(Stream2);

            //        if (txtStream != txtStream2)
            //        {
            //            itmLV.Text = pckPart.Uri.OriginalString + " [DIFF FOUND]";
            //            itmLV.BackColor = Color.Yellow;
            //        }
            //    }
            //    //Insert Empty if not found to sync the index
            //    if (comparePckPartColl.Count() > (index + 1))
            //    {
            //        if (pckPartColl.Where(c => c.Uri.OriginalString == comparePckPartColl.ElementAt(index).Uri.OriginalString).Count() == 0)
            //        {
            //            ListViewItem itmLV2 = new ListViewItem();
            //            itmLV2.Text = (lstBox.Items.Count + 1) + ". ";
            //            itmLV2.BackColor = Color.Gray;
            //            lstBox.Items.Add(itmLV2);
            //        }
            //    }
            //    itmLV.Text = (lstBox.Items.Count + 1) + ". " + itmLV.Text;
            //    lstBox.Items.Add(itmLV);
            //    if (length < itmLV.Text.Length)
            //        length = itmLV.Text.Length;

            //    index++;
            //}

            lstBox.Columns[0].Width = maxTextLength * 6;
            lstBox2.Columns[0].Width = maxTextLength * 6;
            //}
            //catch(Exception Ex)
            //{
            //    MessageBox.Show(Ex.Message);
            //    btnDownloadSolution.Enabled = true;
            //}
        }
        private string getStreamToText(Stream stream)
        {
            using (Stream partStream = stream)
            {
                byte[] byteArray = new byte[partStream.Length];
                partStream.Read(byteArray, 0, (int)partStream.Length);
                partStream.Close();

                return Encoding.UTF8.GetString(byteArray);
            }
        }
        #endregion

        #region Validations
        private void ValidateAll(Control.ControlCollection Ctrls)
        {
            foreach (Control ctrl in Ctrls)
            {
                if (ctrl.HasChildren)
                {
                    ValidateAll(ctrl.Controls);
                }
                else
                {
                    if (ctrl.GetType().Name == "TextBox")
                        TextBox_Validating(ctrl, null);
                    //if (ctrl.GetType().Name == "ComboBox")
                    //    ComboBox_Validating(ctrl, null);
                }
            }
        }
        void TextBox_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            TextBox Box = sender as TextBox;

            bool valid = Box.TabIndex == 1 || Box.Text.Length > 0;

            if (!valid)
                errorProvider1.SetError(Box, "Error " + Box.Text);

            if (e != null)
                e.Cancel = !valid;
        }
        private void TextBox_Validated(object sender, System.EventArgs e)
        {
            TextBox Box = sender as TextBox;
            errorProvider1.SetError(Box, "");
        }
        void ComboBox_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            ComboBox Box = sender as ComboBox;

            bool valid = Box.TabIndex == 1 || Box.Text.Length > 0;

            if (!valid)
                errorProvider1.SetError(Box, "Error " + Box.Text);

            if (e != null)
                e.Cancel = !valid;
        }
        private void ComboBox_Validated(object sender, System.EventArgs e)
        {
            ComboBox Box = sender as ComboBox;
            errorProvider1.SetError(Box, "");
        }

        #endregion

        #region Events

        #region chkSameCredentials
        private void chkSameCredentials_CheckedChanged(object sender, EventArgs e)
        {
            //Check For Same Cred
            if (chkSameCredentials.Checked)
            {
                txtUserName2.Enabled = false;
                txtPassword2.Enabled = false;
                txtUserName2.Text = txtUserName.Text;
                txtPassword2.Text = txtPassword.Text;
            }
            else
            {
                txtUserName2.Enabled = true;
                txtPassword2.Enabled = true;
                txtUserName2.Text = string.Empty;
                txtPassword2.Text = string.Empty;
            }
        }

        private void txtUserName_KeyUp(object sender, KeyEventArgs e)
        {
            if (chkSameCredentials.Checked)
            {
                txtUserName2.Text = txtUserName.Text;
            }
        }

        private void txtPassword_KeyUp(object sender, KeyEventArgs e)
        {
            if (chkSameCredentials.Checked)
            {
                txtPassword2.Text = txtPassword.Text;
            }
        }
        #endregion

        #region cmbOrg, cmbRegions,cmbSolutions,lstSolutions - IndexChange
        private void cmbOrgs_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbOrgs.SelectedValue != null)
            //    cmbOrgs2.SelectedValue = cmbOrgs.SelectedValue;
            btnGetSolutions.Enabled = true;
        }
        private void cmbOrgs2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbOrgs2.SelectedValue != null)
            //    cmbOrgs.SelectedValue = cmbOrgs2.SelectedValue;
            btnGetSolutions.Enabled = true;
        }
        private void cmbRegions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRegions.SelectedValue.GetType().Name == "Regions")
                txtDiscURI.Text = "https://disco." + ((Regions)cmbRegions.SelectedValue).Value + "/XRMServices/2011/Discovery.svc";
            else
                txtDiscURI.Text = "https://disco." + cmbRegions.SelectedValue + "/XRMServices/2011/Discovery.svc";

            btnSubmit.Enabled = true;
        }
        private void cmbRegions2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRegions2.SelectedValue.GetType().Name == "Regions")
                txtDiscURI2.Text = "https://disco." + ((Regions)cmbRegions2.SelectedValue).Value + "/XRMServices/2011/Discovery.svc";
            else
                txtDiscURI2.Text = "https://disco." + cmbRegions2.SelectedValue + "/XRMServices/2011/Discovery.svc";

            btnSubmit.Enabled = true;
        }
        private void cmbSolutions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSolutions.SelectedValue != null)
                cmbSolutions2.SelectedValue = cmbSolutions.SelectedValue;

            //On Solution Change, Clear the Collection
            pckPartColl = null;
        }
        private void cmbSolutions2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSolutions2.SelectedValue != null)
                cmbSolutions.SelectedValue = cmbSolutions2.SelectedValue;
            //On Solution Change, Clear the Collection
            pckPartColl2 = null;
        }
        private void lstSolutions_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListViewEx LVEx = (ListViewEx)sender;
            lblSelectedFile1.Text = LVEx.FocusedItem.Text;
            grpCompareBox.Text = LVEx.FocusedItem.Text;

            if (lstSolutions.SelectedIndices.Count > 0 && (lstSolutions2.SelectedIndices.Count == 0 || lstSolutions.SelectedIndices[0] != lstSolutions2.SelectedIndices[0]))
            {
                lstSolutions2.SelectedIndices.Clear();
                lstSolutions2.Items[lstSolutions.SelectedIndices[0]].Focused = true;
                lstSolutions2.Select();
                lstSolutions2.EnsureVisible(lstSolutions.SelectedIndices[0]);
                lstSolutions2.Items[lstSolutions.SelectedIndices[0]].Selected = true;
            }
        }
        private void lstSolutions2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListViewEx LVEx = (ListViewEx)sender;
            lblSelectedFile2.Text = LVEx.FocusedItem.Text;
            grpCompareBox2.Text = LVEx.FocusedItem.Text;

            if (lstSolutions2.SelectedIndices.Count > 0 && (lstSolutions.SelectedIndices.Count == 0 || lstSolutions.SelectedIndices[0] != lstSolutions2.SelectedIndices[0]))
            {
                lstSolutions.SelectedIndices.Clear();
                lstSolutions.Items[lstSolutions2.SelectedIndices[0]].Focused = true;
                lstSolutions.Select();
                lstSolutions.EnsureVisible(lstSolutions2.SelectedIndices[0]);
                lstSolutions.Items[lstSolutions2.SelectedIndices[0]].Selected = true;
            }
        }
        #endregion

        #region btnSubmit - LoadOrgs
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                btnSubmit.Enabled = false;
                cmbOrgs.DataSource = null;
                cmbOrgs.Items.Clear();
                cmbOrgs2.DataSource = null;
                cmbOrgs2.Items.Clear();

                // Validate All Controls
                ValidateAll(Controls);
                auth = new CrmOrgHelper();

                bW_LoadOrgs1.WorkerReportsProgress = true;
                bW_LoadOrgs1.RunWorkerAsync();

                bW_LoadOrgs2.WorkerReportsProgress = true;
                bW_LoadOrgs2.RunWorkerAsync();

                lblStatus.Text = "Loading Orgs...";
            }
            #region Exception
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                string Error = string.Empty;
                btnSubmit.Enabled = true;
                Error += "The application terminated with an error.";
                Error += String.Format("Timestamp: {0}", ex.Detail.Timestamp);
                Error += String.Format("Code: {0}", ex.Detail.ErrorCode);
                Error += String.Format("Message: {0}", ex.Detail.Message);
                Error += String.Format("Plugin Trace: {0}", ex.Detail.TraceText);
                Error += String.Format("Inner Fault: {0}",
                    null == ex.Detail.InnerFault ? "No Inner Fault" : "Has Inner Fault");

                MessageBox.Show(Error);
            }
            catch (System.TimeoutException ex)
            {
                string Error = string.Empty;
                btnSubmit.Enabled = true;
                Error += String.Format("The application terminated with an error.");
                Error += String.Format("Message: {0}", ex.Message);
                Error += String.Format("Stack Trace: {0}", ex.StackTrace);
                Error += String.Format("Inner Fault: {0}",
                    null == ex.InnerException.Message ? "No Inner Fault" : ex.InnerException.Message);
                MessageBox.Show(Error);
            }
            catch (System.Exception ex)
            {
                string Error = string.Empty;
                btnSubmit.Enabled = true;
                Error += String.Format("The application terminated with an error.");
                Console.WriteLine(ex.Message);

                // Display the details of the inner exception.
                if (ex.InnerException != null)
                {
                    Console.WriteLine(ex.InnerException.Message);

                    FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> fe = ex.InnerException
                        as FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault>;
                    if (fe != null)
                    {
                        Error += String.Format("Timestamp: {0}", fe.Detail.Timestamp);
                        Error += String.Format("Code: {0}", fe.Detail.ErrorCode);
                        Error += String.Format("Message: {0}", fe.Detail.Message);
                        Error += String.Format("Plugin Trace: {0}", fe.Detail.TraceText);
                        Error += String.Format("Inner Fault: {0}",
                            null == fe.Detail.InnerFault ? "No Inner Fault" : "Has Inner Fault");
                    }
                }
                MessageBox.Show(Error);
            }

            // Additional exceptions to catch: SecurityTokenValidationException, ExpiredSecurityTokenException,
            // SecurityAccessDeniedException, MessageSecurityException, and SecurityNegotiationException.

            #endregion
        }
        private void BackgroundWorker1_LoadOrgs(object sender, DoWorkEventArgs e)
        {
            try
            {
                //Get Disc Service
                discService = auth.getDiscoveryServiceProxy(discService, txtDiscURI.Text, txtUserName.Text, txtPassword.Text);
                //Load Orgs
                orgColls = auth.DiscoverOrganizations(discService);
            }
            catch (Exception Ex)
            {
                orgColls = null;
                MessageBox.Show(Ex.Message);
            }
        }
        private void BackgroundWorker1_LoadOrgsCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            cmbOrgs.DataSource = orgColls;
            cmbOrgs.DisplayMember = "FriendlyName";
            cmbOrgs.ValueMember = "UniqueName";
        }
        private void BackgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lblStatus.Text = e.ProgressPercentage.ToString();
        }
        private void BW_LoadOrgs2_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                discService2 = auth.getDiscoveryServiceProxy(discService2, txtDiscURI2.Text, txtUserName.Text, txtPassword.Text);
                //Load Orgs
                orgColls2 = auth.DiscoverOrganizations(discService2);
                e.Result = true;
            }
            catch (Exception Ex)
            {
                orgColls2 = null;
                MessageBox.Show(Ex.Message);
                e.Result = false;
            }
        }
        private void BW_LoadOrgs2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!(bool)e.Result) lblStatus.Text = "Error!";

                Task.Factory.StartNew(() =>
                {
                    while (bW_LoadOrgs1.IsBusy)
                    { }
                }).ContinueWith((t) =>
                {
                    cmbOrgs2.DataSource = orgColls2;
                    cmbOrgs2.DisplayMember = "FriendlyName";
                    cmbOrgs2.ValueMember = "UniqueName";

                    btnSubmit.Enabled = true;
                    lblStatus.Text = "Completed!";
                }, CancellationToken.None, TaskContinuationOptions.None, TaskScheduler.FromCurrentSynchronizationContext());
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                btnSubmit.Enabled = true;
                lblStatus.Text = "Error!";
            }
        }
        private void BW_LoadOrgs2_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lblStatus.Text = e.ProgressPercentage.ToString();
        }
        #endregion

        #region btnGetSolutions - LoadSolutions
        private void btnGetSolutions_Click(object sender, EventArgs e)
        {
            try
            {
                btnGetSolutions.Enabled = false;

                orgName1 = ((OrganizationDetail)cmbOrgs.SelectedItem).FriendlyName;
                orgName2 = ((OrganizationDetail)cmbOrgs2.SelectedItem).FriendlyName;

                grpSolution1.Text = orgName1;
                grpSolution2.Text = orgName2;

                //Get Org Service
                orgURI = ((OrganizationDetail)cmbOrgs.SelectedItem).Endpoints[EndpointType.OrganizationService];
                orgURI2 = ((OrganizationDetail)cmbOrgs2.SelectedItem).Endpoints[EndpointType.OrganizationService];

                bW_LoadSolutions1.WorkerReportsProgress = true;
                bW_LoadSolutions1.RunWorkerAsync();
                bW_LoadSolutions2.WorkerReportsProgress = true;
                bW_LoadSolutions2.RunWorkerAsync();
                lblStatus.Text = "Loading Solutions...";
            }

            // Catch any service fault exceptions that Microsoft Dynamics CRM throws.
            catch (Exception Ex)
            {
                // You can handle an exception here or pass it back to the calling method.
                MessageBox.Show(Ex.Message);
                btnGetSolutions.Enabled = true;
                lblStatus.Text = "Error!";
            }
        }
        private void BW_LoadSolutions_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                orgService = auth.getOrgServiceProxy(orgURI);
                EntityCollection ecSolutions = auth.getAllSolutions(orgService);
                _ecSolutions = (from val in ecSolutions.Entities
                                select new
                                {
                                    Name = val.Attributes["uniquename"] + ((bool)val.Attributes["ismanaged"] ? "[Managed]" : "")
                                }).ToList();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                //lblStatus.Text = "Error!";
            }
        }
        private void BW_LoadSolutions_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            cmbSolutions.DataSource = _ecSolutions;
            cmbSolutions.DisplayMember = "Name";
            cmbSolutions.ValueMember = "Name";
        }
        private void BW_LoadSolutions2_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                orgService2 = auth.getOrgServiceProxy(orgURI2);
                EntityCollection ecSolutions2 = auth.getAllSolutions(orgService2);
                _ecSolutions2 = (from val in ecSolutions2.Entities
                                 select new
                                 {
                                     Name = val.Attributes["uniquename"] + ((bool)val.Attributes["ismanaged"] ? "[Managed]" : "")
                                 }).ToList();
                e.Result = true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                e.Result = false;
            }
        }
        private void BW_LoadSolutions2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!(bool)e.Result) lblStatus.Text = "Error!";

                Task.Factory.StartNew(() =>
                {
                    while (bW_LoadSolutions1.IsBusy)
                    { }
                }).ContinueWith((t) =>
                {
                    cmbSolutions2.DataSource = _ecSolutions2;
                    cmbSolutions2.DisplayMember = "Name";
                    cmbSolutions2.ValueMember = "Name";

                    btnGetSolutions.Enabled = true;
                    tabMain.SelectedTab = tabPage2;

                    lblStatus.Text = "Completed!";
                }, CancellationToken.None, TaskContinuationOptions.None, TaskScheduler.FromCurrentSynchronizationContext());

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                btnGetSolutions.Enabled = true;
                lblStatus.Text = "Error!";
            }
        }
        #endregion

        #region btnDownloadSolutions - DownloadSolution File
        private void btnDownloadSolution_Click(object sender, EventArgs e)
        {
            try
            {
                btnDownloadSolution.Enabled = false;

                if (cmbSolutions.SelectedValue == null)
                {
                    MessageBox.Show("Solution Name Is Required!");
                    btnDownloadSolution.Enabled = true;
                    lblStatus.Text = "Solution Name Is Required!";
                    return;
                }
                SolName = cmbSolutions.SelectedValue.ToString().Replace(" ", "").Replace("[Managed]", "");
                SolName2 = cmbSolutions2.SelectedValue.ToString().Replace(" ", "").Replace("[Managed]", "");


                bW_DownloadSolution1.WorkerSupportsCancellation = true;
                if (bW_DownloadSolution1.IsBusy)
                    bW_DownloadSolution1.CancelAsync();

                bW_DownloadSolution1.WorkerReportsProgress = true;
                bW_DownloadSolution1.RunWorkerAsync(new object[] { false });

                bW_DownloadSolution2.WorkerSupportsCancellation = true;
                if (bW_DownloadSolution2.IsBusy)
                    bW_DownloadSolution2.CancelAsync();

                bW_DownloadSolution2.WorkerReportsProgress = true;
                bW_DownloadSolution2.RunWorkerAsync(new object[] { false });
                lblStatus.Text = "Downloading Solution Components...";
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                btnDownloadSolution.Enabled = true;
                lblStatus.Text = "Error!";
            }
        }
        private void BW_DownloadSolution_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string fileLocation = string.Empty;
                if (chkSolutionPackageAvailable.Checked) fileLocation = lblBrowseFile1.Text;
                else fileLocation = "../1" + orgName1 + SolName + ".zip";
                pckPartColl = ExportCRMSolution(chkLastSolution, SolName, fileLocation, orgService, (bool)((object[])e.Argument)[0]);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void BW_DownloadSolution_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                //Load the Solution to List
                //loadPackageToList(lstSolutions, lstSolutions2, pckPartColl, pckPartColl2);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                btnDownloadSolution.Enabled = true;
                lblStatus.Text = "Error!";
            }
        }
        private void BW_DownloadSolution2_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string fileLocation = string.Empty;
                if (chkSolutionPackageAvailable.Checked) fileLocation = lblBrowseFile2.Text;
                else fileLocation = "../2" + orgName2 + SolName2 + ".zip";
                pckPartColl2 = ExportCRMSolution(chkLastSolution2, SolName2, fileLocation, orgService2, (bool)((object[])e.Argument)[0]);
                e.Result = true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                e.Result = false;

            }
        }
        private void BW_DownloadSolution2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!(bool)e.Result) lblStatus.Text = "Error!";

                Task.Factory.StartNew(() =>
                {
                    while (bW_DownloadSolution1.IsBusy)
                    { }
                }).ContinueWith((t) =>
                {
                    lblStatus.Text = "Loading Package To List..";
                    //Load the Solution to List
                    loadPackageToList(lstSolutions, lstSolutions2, pckPartColl, pckPartColl2);
                    btnDownloadSolution.Enabled = true;
                    lblStatus.Text = "Completed!";
                }, CancellationToken.None, TaskContinuationOptions.None, TaskScheduler.FromCurrentSynchronizationContext());

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                btnDownloadSolution.Enabled = true;
                lblStatus.Text = "Error!";
            }
        }

        #endregion

        #region btnCompare - CompareFiles
        private void btnCompare_Click(object sender, EventArgs e)
        {
            try
            {
                if (pckPartColl == null)
                {
                    MessageBox.Show("pckPartColl Is Empty!!");
                    return;
                }
                if (pckPartColl2 == null)
                {
                    MessageBox.Show("pckPartColl2 Is Empty!!");
                    return;
                }

                //Select Compare Tab 
                tabMain.SelectedTab = tabPage3;

                lstFile2.Items.Clear();
                lstFile.Items.Clear();

                if (lstSolutions.SelectedItems.Count > 0 && lstSolutions2.SelectedItems.Count > 0)
                {
                    string txtSolutions = lstSolutions.SelectedItems[0].Text;
                    string txtSolutions2 = lstSolutions2.SelectedItems[0].Text;

                    while (txtSolutions.First<char>() != ' ')
                        txtSolutions = txtSolutions.Remove(0, 1);
                    while (txtSolutions2.First<char>() != ' ')
                        txtSolutions2 = txtSolutions2.Remove(0, 1);

                    //Remove the left space
                    txtSolutions = txtSolutions.Remove(0, 1);
                    txtSolutions2 = txtSolutions2.Remove(0, 1);

                    //Load Both the Streams
                    string Stream1 = pckPartColl
                    .Where(c => c.URI == txtSolutions.Substring(0, txtSolutions.IndexOf("[") - 1))
                    .First().Stream;

                    string Stream2 = pckPartColl2
                        .Where(c => c.URI == txtSolutions2.Substring(0, txtSolutions.IndexOf("[") - 1))
                        .First().Stream;

                    bW_CompareFiles.WorkerReportsProgress = true;
                    bW_CompareFiles.RunWorkerAsync(new List<string> { Stream1, Stream2 });
                    //this.Cursor = Cursors.WaitCursor;
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void BW_CompareFiles_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = TextDiff(((List<string>)e.Argument)[0], ((List<string>)e.Argument)[1]);
        }
        private void BW_CompareFiles_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lblStatus.Text = ((object[])e.UserState)[0].ToString() + " : " + e.ProgressPercentage;
            //lblStatus.Text = "Processing...";
        }

        private void BW_CompareFiles_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            var obj = (List<object>)e.Result;
            Results((DiffList_TextFile)obj[0], (DiffList_TextFile)obj[1], (ArrayList)obj[2], (double)obj[3]);
            //this.Cursor = Cursors.Default;
            lblStatus.Text = "Completed!";
        }
        private List<object> TextDiff(string sFile, string dFile)
        {
            DiffList_TextFile sLF = null;
            DiffList_TextFile dLF = null;
            try
            {
                sLF = new DiffList_TextFile(sFile);
                dLF = new DiffList_TextFile(dFile);
            }
            catch (Exception ex)
            {
                //this.Cursor = Cursors.Default;
                MessageBox.Show(ex.Message, "File Error");
                return null;
            }

            try
            {
                double time = 0;
                DiffEngine de = new DiffEngine();
                time = de.ProcessDiff(sLF, dLF, DiffEngineLevel.FastImperfect, bW_CompareFiles);

                ArrayList rep = de.DiffReport(bW_CompareFiles);

                return (new List<object> { sLF, dLF, rep, time });
            }
            catch (Exception ex)
            {
                //this.Cursor = Cursors.Default;
                string tmp = string.Format("{0}{1}{1}***STACK***{1}{2}",
                    ex.Message,
                    Environment.NewLine,
                    ex.StackTrace);
                MessageBox.Show(tmp, "Compare Error");
                return null;
            }

        }

        public void Results(DiffList_TextFile source, DiffList_TextFile destination, ArrayList DiffLines, double seconds)
        {
            //InitializeComponent();
            this.Text = string.Format("Results: {0} secs.", seconds.ToString("#0.00"));
            int colLength = 50;
            ListViewItem lviS;
            ListViewItem lviD;
            int cnt = 1;
            int i;
            foreach (DiffResultSpan drs in DiffLines)
            {
                string line = string.Empty;
                switch (drs.Status)
                {
                    case DiffResultSpanStatus.DeleteSource:
                        for (i = 0; i < drs.Length; i++)
                        {
                            line = ((TextLine)source.GetByIndex(drs.SourceIndex + i)).Line;
                            if (colLength < line.Length)
                                colLength = line.Length;
                            lviS = new ListViewItem(cnt.ToString("00000"));
                            lviD = new ListViewItem(cnt.ToString("00000"));
                            lviS.BackColor = Color.Red;
                            lviS.SubItems.Add(((TextLine)source.GetByIndex(drs.SourceIndex + i)).Line);
                            lviD.BackColor = Color.LightGray;
                            lviD.SubItems.Add("");

                            lstFile.Items.Add(lviS);
                            lstFile2.Items.Add(lviD);
                            cnt++;
                        }

                        break;
                    case DiffResultSpanStatus.NoChange:
                        for (i = 0; i < drs.Length; i++)
                        {
                            line = ((TextLine)source.GetByIndex(drs.SourceIndex + i)).Line;
                            if (colLength < line.Length)
                                colLength = line.Length;
                            lviS = new ListViewItem(cnt.ToString("00000"));
                            lviD = new ListViewItem(cnt.ToString("00000"));
                            lviS.BackColor = Color.White;
                            lviS.SubItems.Add(((TextLine)source.GetByIndex(drs.SourceIndex + i)).Line);
                            lviD.BackColor = Color.White;
                            lviD.SubItems.Add(((TextLine)destination.GetByIndex(drs.DestIndex + i)).Line);

                            lstFile.Items.Add(lviS);
                            lstFile2.Items.Add(lviD);
                            cnt++;
                        }

                        break;
                    case DiffResultSpanStatus.AddDestination:
                        for (i = 0; i < drs.Length; i++)
                        {
                            line = ((TextLine)destination.GetByIndex(drs.DestIndex + i)).Line;
                            if (colLength < line.Length)
                                colLength = line.Length;
                            lviS = new ListViewItem(cnt.ToString("00000"));
                            lviD = new ListViewItem(cnt.ToString("00000"));
                            lviS.BackColor = Color.LightGray;
                            lviS.SubItems.Add("");
                            lviD.BackColor = Color.LightGreen;
                            lviD.SubItems.Add(((TextLine)destination.GetByIndex(drs.DestIndex + i)).Line);

                            lstFile.Items.Add(lviS);
                            lstFile2.Items.Add(lviD);
                            cnt++;
                        }

                        break;
                    case DiffResultSpanStatus.Replace:
                        for (i = 0; i < drs.Length; i++)
                        {
                            line = ((TextLine)source.GetByIndex(drs.SourceIndex + i)).Line;
                            if (colLength < line.Length)
                                colLength = line.Length;
                            lviS = new ListViewItem(cnt.ToString("00000"));
                            lviD = new ListViewItem(cnt.ToString("00000"));
                            lviS.BackColor = Color.Red;
                            lviS.SubItems.Add(((TextLine)source.GetByIndex(drs.SourceIndex + i)).Line);
                            lviD.BackColor = Color.LightGreen;
                            lviD.SubItems.Add(((TextLine)destination.GetByIndex(drs.DestIndex + i)).Line);

                            lstFile.Items.Add(lviS);
                            lstFile2.Items.Add(lviD);
                            cnt++;
                        }

                        break;
                }

            }

            lstFile2.Columns[1].Width = colLength * 6;
            lstFile.Columns[1].Width = colLength * 6;
        }

        /// <summary>
        /// Returns the number of steps required to transform the source string
        /// into the target string.
        /// </summary>
        int ComputeLevenshteinDistance(string source, string target)
        {
            if ((source == null) || (target == null)) return 0;
            if ((source.Length == 0) || (target.Length == 0)) return 0;
            if (source == target) return source.Length;

            int sourceWordCount = source.Length;
            int targetWordCount = target.Length;

            // Step 1
            if (sourceWordCount == 0)
                return targetWordCount;

            if (targetWordCount == 0)
                return sourceWordCount;

            int[,] distance = new int[sourceWordCount + 1, targetWordCount + 1];

            // Step 2
            for (int i = 0; i <= sourceWordCount; distance[i, 0] = i++) ;
            for (int j = 0; j <= targetWordCount; distance[0, j] = j++) ;

            for (int i = 1; i <= sourceWordCount; i++)
            {
                for (int j = 1; j <= targetWordCount; j++)
                {
                    // Step 3
                    int cost = (target[j - 1] == source[i - 1]) ? 0 : 1;

                    // Step 4
                    distance[i, j] = Math.Min(Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1), distance[i - 1, j - 1] + cost);
                }
            }

            return distance[sourceWordCount, targetWordCount];
        }
        /// <summary>
        /// Calculate percentage similarity of two strings
        /// <param name="source">Source String to Compare with</param>
        /// <param name="target">Targeted String to Compare</param>
        /// <returns>Return Similarity between two strings from 0 to 1.0</returns>
        /// </summary>
        double CalculateTextSimilarity(string source, string target)
        {
            if ((source == null) || (target == null)) return 0.0;
            //if ((source.Length == 0) || (target.Length == 0)) return 0.0;
            if (source == target) return 1.0;

            int stepsToSame = ComputeLevenshteinDistance(source, target);
            return (1.0 - ((double)stepsToSame / (double)Math.Max(source.Length, target.Length)));
        }
        #endregion

        #region ListBox Scroll Events
        void LstSolutions_Scroll(object sender, MyScrollEventArgs e)
        {
            try
            {
                int curItem = lstSolutions.TopItem.Index;
                lstSolutions2.TopItem = lstSolutions2.Items[curItem];
            }
            catch { }
        }
        private void lstFile_Scroll(object sender, MyScrollEventArgs e)
        {
            try
            {
                int curItem = lstFile.TopItem.Index;
                lstFile2.TopItem = lstFile2.Items[curItem];
            }
            catch { }
        }
        private void lstSolutions2_Scroll(object sender, MyScrollEventArgs e)
        {
            try
            {
                int curItem = lstSolutions2.TopItem.Index;
                lstSolutions.TopItem = lstSolutions.Items[curItem];
            }
            catch { }
        }
        private void lstFile2_Scroll(object sender, MyScrollEventArgs e)
        {
            try
            {
                int curItem = lstFile2.TopItem.Index;
                lstFile.TopItem = lstFile.Items[curItem];
            }
            catch { }
        }
        #endregion

        #endregion

        private void btnBrowseSolution1_Click(object sender, EventArgs e)
        {
            lblBrowseFile1.Text = string.Empty;
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                lblBrowseFile1.Text = openFileDialog1.FileName;
                try
                {
                    //string text = File.ReadAllText(file);
                    //size = text.Length;
                }
                catch (IOException)
                {
                }
            }
        }

        private void btnBrowseSolution2_Click(object sender, EventArgs e)
        {
            lblBrowseFile2.Text = string.Empty;
            DialogResult result = openFileDialog2.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                lblBrowseFile2.Text = openFileDialog2.FileName;
            }
        }

        private void btnBrowseConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblBrowseFile1.Text == string.Empty || lblBrowseFile2.Text == string.Empty)
                {
                    MessageBox.Show("Invalid FileName!!");
                    return;
                }
                tabMain.SelectedTab = tabPage2;
                bW_DownloadSolution1.WorkerSupportsCancellation = true;
                if (bW_DownloadSolution1.IsBusy)
                    bW_DownloadSolution1.CancelAsync();

                bW_DownloadSolution1.WorkerReportsProgress = true;
                bW_DownloadSolution1.RunWorkerAsync(new object[] { true });

                bW_DownloadSolution2.WorkerSupportsCancellation = true;
                if (bW_DownloadSolution2.IsBusy)
                    bW_DownloadSolution2.CancelAsync();

                bW_DownloadSolution2.WorkerReportsProgress = true;
                bW_DownloadSolution2.RunWorkerAsync(new object[] { true });
                lblStatus.Text = "Downloading Solution Components...";
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                lblStatus.Text = "Error!";
            }
        }

        private void chkSolutionPackageAvailable_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSolutionPackageAvailable.Checked)
            {
                tab1grpBrowseSol1.Enabled = true;
                tab1grpBrowseSol2.Enabled = true;

                tab1grpInstance1.Enabled = false;
                tab1grpInstance2.Enabled = false;
                tab1grpOrg1.Enabled = false;
                tab1grpOrg2.Enabled = false;

                btnSubmit.Enabled = false;
                btnGetSolutions.Enabled = false;
                btnBrowseConfirm.Enabled = true;
            }
            else
            {
                tab1grpBrowseSol1.Enabled = false;
                tab1grpBrowseSol2.Enabled = false;

                tab1grpInstance1.Enabled = true;
                tab1grpInstance2.Enabled = true;
                tab1grpOrg1.Enabled = true;
                tab1grpOrg2.Enabled = true;

                btnSubmit.Enabled = true;
                btnGetSolutions.Enabled = true;
                btnBrowseConfirm.Enabled = false;
            }
        }
    }

    internal class lstPckPartCollClass
    {
        public long Lines { get; set; }
        public string Stream { get; set; }
        public string URI { get; set; }
    }

    internal class CustPackagePart
    {
        public long Lines { get; internal set; }
        public string Stream { get; set; }
        public string URI { get; set; }
    }
    public class ListViewEx : ListView
    {
        public delegate void ScrollHandler(object sender, MyScrollEventArgs e);
        public event ScrollHandler Scroll;

        public void OnScroll(MyScrollEventArgs e)
        {
            if (Scroll != null)
            {
                Scroll(this, e);
            }
        }

        private const int WM_HSCROLL = 0x114;
        private const int WM_VSCROLL = 0x115;
        private const int MOUSEWHEEL = 0x020A;
        private const int KEYDOWN = 0x0100;

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 132 || m.Msg == MOUSEWHEEL || m.Msg == WM_VSCROLL || (m.Msg == KEYDOWN && (m.WParam == (IntPtr)40 || m.WParam == (IntPtr)35)))
            {
                MyScrollEventArgs e = new MyScrollEventArgs();
                e.WParam = m.WParam;
                e.Orientation = ScrollOrientation.VerticalScroll;
                OnScroll(e);
            }
            if (m.Msg == WM_HSCROLL)
            {
                MyScrollEventArgs e = new MyScrollEventArgs();
                e.WParam = m.WParam;
                e.Orientation = ScrollOrientation.HorizontalScroll;
                OnScroll(e);
            }
            base.WndProc(ref m);
        }
    }
    public class MyScrollEventArgs : EventArgs
    {
        private ScrollOrientation orientation;
        private IntPtr wParam;
        public IntPtr WParam
        {
            get { return wParam; }
            set { wParam = value; }
        }
        public ScrollOrientation Orientation
        {
            get { return orientation; }
            set { orientation = value; }
        }
    }
}
