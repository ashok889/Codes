﻿namespace DES.Crm.Core.SolutionComparer
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chkSolutionPackageAvailable = new System.Windows.Forms.CheckBox();
            this.tab1grpBrowseSol2 = new System.Windows.Forms.GroupBox();
            this.btnBrowseConfirm = new System.Windows.Forms.Button();
            this.lblBrowseFile2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.btnSolution2 = new System.Windows.Forms.Button();
            this.tab1grpBrowseSol1 = new System.Windows.Forms.GroupBox();
            this.lblBrowseFile1 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.btnSolution1 = new System.Windows.Forms.Button();
            this.tab1grpOrg2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbOrgs2 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tab1grpOrg1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbOrgs = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnGetSolutions = new System.Windows.Forms.Button();
            this.tab1grpInstance2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPassword2 = new System.Windows.Forms.TextBox();
            this.txtUserName2 = new System.Windows.Forms.TextBox();
            this.txtDiscURI2 = new System.Windows.Forms.TextBox();
            this.cmbRegions2 = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.tab1grpInstance1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtDiscURI = new System.Windows.Forms.TextBox();
            this.cmbRegions = new System.Windows.Forms.ComboBox();
            this.chkSameCredentials = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chkLastSolution2 = new System.Windows.Forms.CheckBox();
            this.chkLastSolution = new System.Windows.Forms.CheckBox();
            this.pnlSolution = new System.Windows.Forms.Panel();
            this.btnCompare = new System.Windows.Forms.Button();
            this.lblSelectedFile2 = new System.Windows.Forms.Label();
            this.lblSelectedFile1 = new System.Windows.Forms.Label();
            this.lblFile2 = new System.Windows.Forms.Label();
            this.lblFile1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbSolutions2 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbSolutions = new System.Windows.Forms.ComboBox();
            this.grpSolution2 = new System.Windows.Forms.GroupBox();
            this.grpSolution1 = new System.Windows.Forms.GroupBox();
            this.btnDownloadSolution = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.grpCompareBox = new System.Windows.Forms.GroupBox();
            this.grpCompareBox2 = new System.Windows.Forms.GroupBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.lstSolutions2 = new DES.Crm.Core.SolutionComparer.ListViewEx();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstSolutions = new DES.Crm.Core.SolutionComparer.ListViewEx();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstFile = new DES.Crm.Core.SolutionComparer.ListViewEx();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstFile2 = new DES.Crm.Core.SolutionComparer.ListViewEx();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tab1grpBrowseSol2.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tab1grpBrowseSol1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tab1grpOrg2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tab1grpOrg1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tab1grpInstance2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tab1grpInstance1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlSolution.SuspendLayout();
            this.grpSolution2.SuspendLayout();
            this.grpSolution1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.grpCompareBox.SuspendLayout();
            this.grpCompareBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Controls.Add(this.tabPage3);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(949, 669);
            this.tabMain.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnBrowseConfirm);
            this.tabPage1.Controls.Add(this.chkSolutionPackageAvailable);
            this.tabPage1.Controls.Add(this.tab1grpBrowseSol2);
            this.tabPage1.Controls.Add(this.tab1grpBrowseSol1);
            this.tabPage1.Controls.Add(this.tab1grpOrg2);
            this.tabPage1.Controls.Add(this.tab1grpOrg1);
            this.tabPage1.Controls.Add(this.btnGetSolutions);
            this.tabPage1.Controls.Add(this.tab1grpInstance2);
            this.tabPage1.Controls.Add(this.btnSubmit);
            this.tabPage1.Controls.Add(this.tab1grpInstance1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(941, 643);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Login";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chkSolutionPackageAvailable
            // 
            this.chkSolutionPackageAvailable.AutoSize = true;
            this.chkSolutionPackageAvailable.Location = new System.Drawing.Point(35, 20);
            this.chkSolutionPackageAvailable.Name = "chkSolutionPackageAvailable";
            this.chkSolutionPackageAvailable.Size = new System.Drawing.Size(257, 17);
            this.chkSolutionPackageAvailable.TabIndex = 20;
            this.chkSolutionPackageAvailable.Text = "Solution Package (OnPremise/Online) Available?";
            this.chkSolutionPackageAvailable.UseVisualStyleBackColor = true;
            this.chkSolutionPackageAvailable.CheckedChanged += new System.EventHandler(this.chkSolutionPackageAvailable_CheckedChanged);
            // 
            // tab1grpBrowseSol2
            // 
            this.tab1grpBrowseSol2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tab1grpBrowseSol2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tab1grpBrowseSol2.Controls.Add(this.lblBrowseFile2);
            this.tab1grpBrowseSol2.Controls.Add(this.label20);
            this.tab1grpBrowseSol2.Controls.Add(this.tableLayoutPanel5);
            this.tab1grpBrowseSol2.Enabled = false;
            this.tab1grpBrowseSol2.Location = new System.Drawing.Point(421, 283);
            this.tab1grpBrowseSol2.Name = "tab1grpBrowseSol2";
            this.tab1grpBrowseSol2.Size = new System.Drawing.Size(383, 110);
            this.tab1grpBrowseSol2.TabIndex = 19;
            this.tab1grpBrowseSol2.TabStop = false;
            this.tab1grpBrowseSol2.Text = "Browse Solution 2";
            // 
            // btnBrowseConfirm
            // 
            this.btnBrowseConfirm.Location = new System.Drawing.Point(714, 399);
            this.btnBrowseConfirm.Name = "btnBrowseConfirm";
            this.btnBrowseConfirm.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseConfirm.TabIndex = 10;
            this.btnBrowseConfirm.Text = "Confirm";
            this.btnBrowseConfirm.UseVisualStyleBackColor = true;
            this.btnBrowseConfirm.Click += new System.EventHandler(this.btnBrowseConfirm_Click);
            // 
            // lblBrowseFile2
            // 
            this.lblBrowseFile2.AutoSize = true;
            this.lblBrowseFile2.Location = new System.Drawing.Point(106, 53);
            this.lblBrowseFile2.MaximumSize = new System.Drawing.Size(250, 0);
            this.lblBrowseFile2.Name = "lblBrowseFile2";
            this.lblBrowseFile2.Size = new System.Drawing.Size(74, 13);
            this.lblBrowseFile2.TabIndex = 9;
            this.lblBrowseFile2.Text = "lblBrowseFile2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 52);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "File 2 :";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.AutoSize = true;
            this.tableLayoutPanel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.Controls.Add(this.label15, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.btnSolution2, 1, 6);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel5.RowCount = 10;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.Size = new System.Drawing.Size(377, 29);
            this.tableLayoutPanel5.TabIndex = 5;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Solution Zip File 2";
            // 
            // btnSolution2
            // 
            this.btnSolution2.Location = new System.Drawing.Point(100, 3);
            this.btnSolution2.Name = "btnSolution2";
            this.btnSolution2.Size = new System.Drawing.Size(75, 23);
            this.btnSolution2.TabIndex = 13;
            this.btnSolution2.Text = "Browse";
            this.btnSolution2.UseVisualStyleBackColor = true;
            this.btnSolution2.Click += new System.EventHandler(this.btnBrowseSolution2_Click);
            // 
            // tab1grpBrowseSol1
            // 
            this.tab1grpBrowseSol1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tab1grpBrowseSol1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tab1grpBrowseSol1.Controls.Add(this.lblBrowseFile1);
            this.tab1grpBrowseSol1.Controls.Add(this.label17);
            this.tab1grpBrowseSol1.Controls.Add(this.tableLayoutPanel6);
            this.tab1grpBrowseSol1.Enabled = false;
            this.tab1grpBrowseSol1.Location = new System.Drawing.Point(28, 283);
            this.tab1grpBrowseSol1.Name = "tab1grpBrowseSol1";
            this.tab1grpBrowseSol1.Size = new System.Drawing.Size(369, 110);
            this.tab1grpBrowseSol1.TabIndex = 18;
            this.tab1grpBrowseSol1.TabStop = false;
            this.tab1grpBrowseSol1.Text = "Browse Solution 1";
            // 
            // lblBrowseFile1
            // 
            this.lblBrowseFile1.AutoSize = true;
            this.lblBrowseFile1.Location = new System.Drawing.Point(103, 52);
            this.lblBrowseFile1.MaximumSize = new System.Drawing.Size(250, 0);
            this.lblBrowseFile1.Name = "lblBrowseFile1";
            this.lblBrowseFile1.Size = new System.Drawing.Size(74, 13);
            this.lblBrowseFile1.TabIndex = 7;
            this.lblBrowseFile1.Text = "lblBrowseFile1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(7, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 13);
            this.label17.TabIndex = 6;
            this.label17.Text = "File1 : ";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.AutoSize = true;
            this.tableLayoutPanel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this.label16, 0, 6);
            this.tableLayoutPanel6.Controls.Add(this.btnSolution1, 1, 6);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel6.RowCount = 9;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.Size = new System.Drawing.Size(363, 29);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 8);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "Solution Zip File 1";
            // 
            // btnSolution1
            // 
            this.btnSolution1.Location = new System.Drawing.Point(100, 3);
            this.btnSolution1.Name = "btnSolution1";
            this.btnSolution1.Size = new System.Drawing.Size(75, 23);
            this.btnSolution1.TabIndex = 13;
            this.btnSolution1.Text = "Browse";
            this.btnSolution1.UseVisualStyleBackColor = true;
            this.btnSolution1.Click += new System.EventHandler(this.btnBrowseSolution1_Click);
            // 
            // tab1grpOrg2
            // 
            this.tab1grpOrg2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tab1grpOrg2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tab1grpOrg2.Controls.Add(this.tableLayoutPanel4);
            this.tab1grpOrg2.Location = new System.Drawing.Point(424, 210);
            this.tab1grpOrg2.Name = "tab1grpOrg2";
            this.tab1grpOrg2.Size = new System.Drawing.Size(380, 61);
            this.tab1grpOrg2.TabIndex = 17;
            this.tab1grpOrg2.TabStop = false;
            this.tab1grpOrg2.Text = "Organization 2";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AutoSize = true;
            this.tableLayoutPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.cmbOrgs2, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 6);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel4.RowCount = 10;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(374, 27);
            this.tableLayoutPanel4.TabIndex = 5;
            // 
            // cmbOrgs2
            // 
            this.cmbOrgs2.FormattingEnabled = true;
            this.cmbOrgs2.Location = new System.Drawing.Point(80, 3);
            this.cmbOrgs2.Name = "cmbOrgs2";
            this.cmbOrgs2.Size = new System.Drawing.Size(202, 21);
            this.cmbOrgs2.TabIndex = 11;
            this.cmbOrgs2.SelectedIndexChanged += new System.EventHandler(this.cmbOrgs2_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Organizations";
            // 
            // tab1grpOrg1
            // 
            this.tab1grpOrg1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tab1grpOrg1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tab1grpOrg1.Controls.Add(this.tableLayoutPanel3);
            this.tab1grpOrg1.Location = new System.Drawing.Point(31, 210);
            this.tab1grpOrg1.Name = "tab1grpOrg1";
            this.tab1grpOrg1.Size = new System.Drawing.Size(369, 61);
            this.tab1grpOrg1.TabIndex = 16;
            this.tab1grpOrg1.TabStop = false;
            this.tab1grpOrg1.Text = "Organization 1";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.cmbOrgs, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 6);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(363, 27);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // cmbOrgs
            // 
            this.cmbOrgs.FormattingEnabled = true;
            this.cmbOrgs.Location = new System.Drawing.Point(80, 3);
            this.cmbOrgs.Name = "cmbOrgs";
            this.cmbOrgs.Size = new System.Drawing.Size(202, 21);
            this.cmbOrgs.TabIndex = 10;
            this.cmbOrgs.SelectedIndexChanged += new System.EventHandler(this.cmbOrgs_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Organizations";
            // 
            // btnGetSolutions
            // 
            this.btnGetSolutions.Location = new System.Drawing.Point(688, 16);
            this.btnGetSolutions.Name = "btnGetSolutions";
            this.btnGetSolutions.Size = new System.Drawing.Size(112, 23);
            this.btnGetSolutions.TabIndex = 15;
            this.btnGetSolutions.Text = "GET SOLUTIONS";
            this.btnGetSolutions.UseVisualStyleBackColor = true;
            this.btnGetSolutions.Click += new System.EventHandler(this.btnGetSolutions_Click);
            // 
            // tab1grpInstance2
            // 
            this.tab1grpInstance2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tab1grpInstance2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tab1grpInstance2.Controls.Add(this.tableLayoutPanel2);
            this.tab1grpInstance2.Location = new System.Drawing.Point(424, 43);
            this.tab1grpInstance2.Name = "tab1grpInstance2";
            this.tab1grpInstance2.Size = new System.Drawing.Size(380, 156);
            this.tab1grpInstance2.TabIndex = 13;
            this.tab1grpInstance2.TabStop = false;
            this.tab1grpInstance2.Text = "D365 Instance 2";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtPassword2, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtUserName2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtDiscURI2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmbRegions2, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(374, 105);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Password";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "UserName";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Disco URI";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Region";
            // 
            // txtPassword2
            // 
            this.txtPassword2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtPassword2.Location = new System.Drawing.Point(66, 82);
            this.txtPassword2.Name = "txtPassword2";
            this.txtPassword2.Size = new System.Drawing.Size(202, 20);
            this.txtPassword2.TabIndex = 5;
            this.txtPassword2.UseSystemPasswordChar = true;
            // 
            // txtUserName2
            // 
            this.txtUserName2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtUserName2.Location = new System.Drawing.Point(66, 56);
            this.txtUserName2.Name = "txtUserName2";
            this.txtUserName2.Size = new System.Drawing.Size(202, 20);
            this.txtUserName2.TabIndex = 2;
            // 
            // txtDiscURI2
            // 
            this.txtDiscURI2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDiscURI2.Location = new System.Drawing.Point(66, 30);
            this.txtDiscURI2.Name = "txtDiscURI2";
            this.txtDiscURI2.Size = new System.Drawing.Size(202, 20);
            this.txtDiscURI2.TabIndex = 15;
            // 
            // cmbRegions2
            // 
            this.cmbRegions2.FormattingEnabled = true;
            this.cmbRegions2.Location = new System.Drawing.Point(66, 3);
            this.cmbRegions2.Name = "cmbRegions2";
            this.cmbRegions2.Size = new System.Drawing.Size(202, 21);
            this.cmbRegions2.TabIndex = 11;
            this.cmbRegions2.SelectedIndexChanged += new System.EventHandler(this.cmbRegions2_SelectedIndexChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(607, 16);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 11;
            this.btnSubmit.Text = "SUBMIT";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // tab1grpInstance1
            // 
            this.tab1grpInstance1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tab1grpInstance1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tab1grpInstance1.Controls.Add(this.tableLayoutPanel1);
            this.tab1grpInstance1.Location = new System.Drawing.Point(28, 43);
            this.tab1grpInstance1.Name = "tab1grpInstance1";
            this.tab1grpInstance1.Size = new System.Drawing.Size(369, 156);
            this.tab1grpInstance1.TabIndex = 12;
            this.tab1grpInstance1.TabStop = false;
            this.tab1grpInstance1.Text = "D365 Instance 1";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtPassword, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtUserName, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtDiscURI, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbRegions, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.chkSameCredentials, 1, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(363, 128);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "UserName";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Disco URI";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Region";
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtPassword.Location = new System.Drawing.Point(66, 82);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(202, 20);
            this.txtPassword.TabIndex = 5;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyUp);
            // 
            // txtUserName
            // 
            this.txtUserName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtUserName.Location = new System.Drawing.Point(66, 56);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(202, 20);
            this.txtUserName.TabIndex = 2;
            this.txtUserName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtUserName_KeyUp);
            // 
            // txtDiscURI
            // 
            this.txtDiscURI.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDiscURI.Location = new System.Drawing.Point(66, 30);
            this.txtDiscURI.Name = "txtDiscURI";
            this.txtDiscURI.Size = new System.Drawing.Size(202, 20);
            this.txtDiscURI.TabIndex = 14;
            // 
            // cmbRegions
            // 
            this.cmbRegions.FormattingEnabled = true;
            this.cmbRegions.Location = new System.Drawing.Point(66, 3);
            this.cmbRegions.Name = "cmbRegions";
            this.cmbRegions.Size = new System.Drawing.Size(202, 21);
            this.cmbRegions.TabIndex = 10;
            this.cmbRegions.SelectedIndexChanged += new System.EventHandler(this.cmbRegions_SelectedIndexChanged);
            // 
            // chkSameCredentials
            // 
            this.chkSameCredentials.AutoSize = true;
            this.chkSameCredentials.Checked = true;
            this.chkSameCredentials.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSameCredentials.Location = new System.Drawing.Point(66, 108);
            this.chkSameCredentials.Name = "chkSameCredentials";
            this.chkSameCredentials.Size = new System.Drawing.Size(216, 17);
            this.chkSameCredentials.TabIndex = 14;
            this.chkSameCredentials.Text = "Use Same Credential On Both Instances";
            this.chkSameCredentials.UseVisualStyleBackColor = true;
            this.chkSameCredentials.CheckedChanged += new System.EventHandler(this.chkSameCredentials_CheckedChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chkLastSolution2);
            this.tabPage2.Controls.Add(this.chkLastSolution);
            this.tabPage2.Controls.Add(this.pnlSolution);
            this.tabPage2.Controls.Add(this.cmbSolutions2);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.cmbSolutions);
            this.tabPage2.Controls.Add(this.grpSolution2);
            this.tabPage2.Controls.Add(this.grpSolution1);
            this.tabPage2.Controls.Add(this.btnDownloadSolution);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(941, 643);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Solution";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chkLastSolution2
            // 
            this.chkLastSolution2.AutoSize = true;
            this.chkLastSolution2.Checked = true;
            this.chkLastSolution2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLastSolution2.Location = new System.Drawing.Point(525, 31);
            this.chkLastSolution2.Name = "chkLastSolution2";
            this.chkLastSolution2.Size = new System.Drawing.Size(172, 17);
            this.chkLastSolution2.TabIndex = 19;
            this.chkLastSolution2.Text = "Use Last Downloaded Solution";
            this.chkLastSolution2.UseVisualStyleBackColor = true;
            // 
            // chkLastSolution
            // 
            this.chkLastSolution.AutoSize = true;
            this.chkLastSolution.Checked = true;
            this.chkLastSolution.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkLastSolution.Location = new System.Drawing.Point(80, 31);
            this.chkLastSolution.Name = "chkLastSolution";
            this.chkLastSolution.Size = new System.Drawing.Size(172, 17);
            this.chkLastSolution.TabIndex = 18;
            this.chkLastSolution.Text = "Use Last Downloaded Solution";
            this.chkLastSolution.UseVisualStyleBackColor = true;
            // 
            // pnlSolution
            // 
            this.pnlSolution.Controls.Add(this.btnCompare);
            this.pnlSolution.Controls.Add(this.lblSelectedFile2);
            this.pnlSolution.Controls.Add(this.lblSelectedFile1);
            this.pnlSolution.Controls.Add(this.lblFile2);
            this.pnlSolution.Controls.Add(this.lblFile1);
            this.pnlSolution.Controls.Add(this.label11);
            this.pnlSolution.Controls.Add(this.label12);
            this.pnlSolution.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSolution.Location = new System.Drawing.Point(3, 584);
            this.pnlSolution.Name = "pnlSolution";
            this.pnlSolution.Size = new System.Drawing.Size(935, 56);
            this.pnlSolution.TabIndex = 17;
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(798, 28);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(132, 23);
            this.btnCompare.TabIndex = 6;
            this.btnCompare.Text = "Compare";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.btnCompare_Click);
            // 
            // lblSelectedFile2
            // 
            this.lblSelectedFile2.AutoSize = true;
            this.lblSelectedFile2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedFile2.Location = new System.Drawing.Point(518, 4);
            this.lblSelectedFile2.MaximumSize = new System.Drawing.Size(350, 0);
            this.lblSelectedFile2.Name = "lblSelectedFile2";
            this.lblSelectedFile2.Size = new System.Drawing.Size(97, 13);
            this.lblSelectedFile2.TabIndex = 20;
            this.lblSelectedFile2.Text = "lblSelectedFile2";
            // 
            // lblSelectedFile1
            // 
            this.lblSelectedFile1.AutoSize = true;
            this.lblSelectedFile1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedFile1.Location = new System.Drawing.Point(67, 4);
            this.lblSelectedFile1.MaximumSize = new System.Drawing.Size(350, 0);
            this.lblSelectedFile1.Name = "lblSelectedFile1";
            this.lblSelectedFile1.Size = new System.Drawing.Size(97, 13);
            this.lblSelectedFile1.TabIndex = 18;
            this.lblSelectedFile1.Text = "lblSelectedFile1";
            // 
            // lblFile2
            // 
            this.lblFile2.AutoSize = true;
            this.lblFile2.Location = new System.Drawing.Point(468, 4);
            this.lblFile2.Name = "lblFile2";
            this.lblFile2.Size = new System.Drawing.Size(44, 13);
            this.lblFile2.TabIndex = 19;
            this.lblFile2.Text = "FILE 2 :";
            // 
            // lblFile1
            // 
            this.lblFile1.AutoSize = true;
            this.lblFile1.Location = new System.Drawing.Point(13, 4);
            this.lblFile1.Name = "lblFile1";
            this.lblFile1.Size = new System.Drawing.Size(44, 13);
            this.lblFile1.TabIndex = 17;
            this.lblFile1.Text = "FILE 1 :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label11.Location = new System.Drawing.Point(10, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 15;
            this.label11.Text = "MISSING";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label12.Location = new System.Drawing.Point(68, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 13);
            this.label12.TabIndex = 16;
            this.label12.Text = "DIFFERENCE FOUND";
            // 
            // cmbSolutions2
            // 
            this.cmbSolutions2.FormattingEnabled = true;
            this.cmbSolutions2.Location = new System.Drawing.Point(525, 6);
            this.cmbSolutions2.Name = "cmbSolutions2";
            this.cmbSolutions2.Size = new System.Drawing.Size(202, 21);
            this.cmbSolutions2.TabIndex = 14;
            this.cmbSolutions2.SelectedIndexChanged += new System.EventHandler(this.cmbSolutions2_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(468, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 13);
            this.label14.TabIndex = 13;
            this.label14.Text = "Solution : ";
            // 
            // cmbSolutions
            // 
            this.cmbSolutions.FormattingEnabled = true;
            this.cmbSolutions.Location = new System.Drawing.Point(80, 4);
            this.cmbSolutions.Name = "cmbSolutions";
            this.cmbSolutions.Size = new System.Drawing.Size(202, 21);
            this.cmbSolutions.TabIndex = 12;
            this.cmbSolutions.SelectedIndexChanged += new System.EventHandler(this.cmbSolutions_SelectedIndexChanged);
            // 
            // grpSolution2
            // 
            this.grpSolution2.Controls.Add(this.lstSolutions2);
            this.grpSolution2.Location = new System.Drawing.Point(468, 47);
            this.grpSolution2.Name = "grpSolution2";
            this.grpSolution2.Size = new System.Drawing.Size(441, 531);
            this.grpSolution2.TabIndex = 6;
            this.grpSolution2.TabStop = false;
            this.grpSolution2.Text = "grpSolution2";
            // 
            // grpSolution1
            // 
            this.grpSolution1.Controls.Add(this.lstSolutions);
            this.grpSolution1.Location = new System.Drawing.Point(13, 46);
            this.grpSolution1.Name = "grpSolution1";
            this.grpSolution1.Size = new System.Drawing.Size(441, 531);
            this.grpSolution1.TabIndex = 5;
            this.grpSolution1.TabStop = false;
            this.grpSolution1.Text = "grpSolution1";
            // 
            // btnDownloadSolution
            // 
            this.btnDownloadSolution.Location = new System.Drawing.Point(771, 17);
            this.btnDownloadSolution.Name = "btnDownloadSolution";
            this.btnDownloadSolution.Size = new System.Drawing.Size(132, 23);
            this.btnDownloadSolution.TabIndex = 2;
            this.btnDownloadSolution.Text = "Download Solution";
            this.btnDownloadSolution.UseVisualStyleBackColor = true;
            this.btnDownloadSolution.Click += new System.EventHandler(this.btnDownloadSolution_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(20, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Solution : ";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.grpCompareBox);
            this.tabPage3.Controls.Add(this.grpCompareBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(941, 643);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Compare";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // grpCompareBox
            // 
            this.grpCompareBox.Controls.Add(this.lstFile);
            this.grpCompareBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.grpCompareBox.Location = new System.Drawing.Point(0, 0);
            this.grpCompareBox.Name = "grpCompareBox";
            this.grpCompareBox.Size = new System.Drawing.Size(460, 643);
            this.grpCompareBox.TabIndex = 8;
            this.grpCompareBox.TabStop = false;
            this.grpCompareBox.Text = "groupBox3";
            // 
            // grpCompareBox2
            // 
            this.grpCompareBox2.Controls.Add(this.lstFile2);
            this.grpCompareBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.grpCompareBox2.Location = new System.Drawing.Point(481, 0);
            this.grpCompareBox2.Name = "grpCompareBox2";
            this.grpCompareBox2.Size = new System.Drawing.Size(460, 643);
            this.grpCompareBox2.TabIndex = 7;
            this.grpCompareBox2.TabStop = false;
            this.grpCompareBox2.Text = "groupBox4";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.Yellow;
            this.lblStatus.Location = new System.Drawing.Point(761, 4);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(47, 13);
            this.lblStatus.TabIndex = 16;
            this.lblStatus.Text = "lblStatus";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "\"Zip Files|*.zip;";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            this.openFileDialog2.Filter = "\"Zip Files|*.zip;";
            // 
            // lstSolutions2
            // 
            this.lstSolutions2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2});
            this.lstSolutions2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstSolutions2.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstSolutions2.HideSelection = false;
            this.lstSolutions2.Location = new System.Drawing.Point(3, 16);
            this.lstSolutions2.Name = "lstSolutions2";
            this.lstSolutions2.Size = new System.Drawing.Size(435, 512);
            this.lstSolutions2.TabIndex = 1;
            this.lstSolutions2.UseCompatibleStateImageBehavior = false;
            this.lstSolutions2.View = System.Windows.Forms.View.Details;
            this.lstSolutions2.Scroll += new DES.Crm.Core.SolutionComparer.ListViewEx.ScrollHandler(this.lstSolutions2_Scroll);
            this.lstSolutions2.SelectedIndexChanged += new System.EventHandler(this.lstSolutions2_SelectedIndexChanged);
            // 
            // lstSolutions
            // 
            this.lstSolutions.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lstSolutions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstSolutions.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstSolutions.HideSelection = false;
            this.lstSolutions.Location = new System.Drawing.Point(3, 16);
            this.lstSolutions.Name = "lstSolutions";
            this.lstSolutions.Size = new System.Drawing.Size(435, 512);
            this.lstSolutions.TabIndex = 0;
            this.lstSolutions.UseCompatibleStateImageBehavior = false;
            this.lstSolutions.View = System.Windows.Forms.View.Details;
            this.lstSolutions.Scroll += new DES.Crm.Core.SolutionComparer.ListViewEx.ScrollHandler(this.LstSolutions_Scroll);
            this.lstSolutions.SelectedIndexChanged += new System.EventHandler(this.lstSolutions_SelectedIndexChanged);
            // 
            // lstFile
            // 
            this.lstFile.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5});
            this.lstFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstFile.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstFile.HideSelection = false;
            this.lstFile.Location = new System.Drawing.Point(3, 16);
            this.lstFile.Name = "lstFile";
            this.lstFile.Size = new System.Drawing.Size(454, 624);
            this.lstFile.TabIndex = 1;
            this.lstFile.UseCompatibleStateImageBehavior = false;
            this.lstFile.View = System.Windows.Forms.View.Details;
            this.lstFile.Scroll += new DES.Crm.Core.SolutionComparer.ListViewEx.ScrollHandler(this.lstFile_Scroll);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Line";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Text";
            // 
            // lstFile2
            // 
            this.lstFile2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader6});
            this.lstFile2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstFile2.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstFile2.HideSelection = false;
            this.lstFile2.Location = new System.Drawing.Point(3, 16);
            this.lstFile2.Name = "lstFile2";
            this.lstFile2.Size = new System.Drawing.Size(454, 624);
            this.lstFile2.TabIndex = 2;
            this.lstFile2.UseCompatibleStateImageBehavior = false;
            this.lstFile2.View = System.Windows.Forms.View.Details;
            this.lstFile2.Scroll += new DES.Crm.Core.SolutionComparer.ListViewEx.ScrollHandler(this.lstFile2_Scroll);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Line";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Text";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 669);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.tabMain);
            this.Name = "Login";
            this.Text = "Compare CRM Instances";
            this.Resize += new System.EventHandler(this.Login_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tab1grpBrowseSol2.ResumeLayout(false);
            this.tab1grpBrowseSol2.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tab1grpBrowseSol1.ResumeLayout(false);
            this.tab1grpBrowseSol1.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tab1grpOrg2.ResumeLayout(false);
            this.tab1grpOrg2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tab1grpOrg1.ResumeLayout(false);
            this.tab1grpOrg1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tab1grpInstance2.ResumeLayout(false);
            this.tab1grpInstance2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tab1grpInstance1.ResumeLayout(false);
            this.tab1grpInstance1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnlSolution.ResumeLayout(false);
            this.pnlSolution.PerformLayout();
            this.grpSolution2.ResumeLayout(false);
            this.grpSolution1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.grpCompareBox.ResumeLayout(false);
            this.grpCompareBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnGetSolutions;
        private System.Windows.Forms.GroupBox tab1grpInstance2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ComboBox cmbOrgs2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPassword2;
        private System.Windows.Forms.TextBox txtUserName2;
        private System.Windows.Forms.TextBox txtDiscURI2;
        private System.Windows.Forms.ComboBox cmbRegions2;
        private System.Windows.Forms.CheckBox chkSameCredentials;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox tab1grpInstance1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtDiscURI;
        private System.Windows.Forms.ComboBox cmbRegions;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnDownloadSolution;
        private System.Windows.Forms.GroupBox grpSolution1;
        private System.Windows.Forms.Button btnCompare;
        private System.Windows.Forms.GroupBox grpSolution2;
        private System.Windows.Forms.ComboBox cmbSolutions;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbSolutions2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox grpCompareBox;
        private System.Windows.Forms.GroupBox grpCompareBox2;
        private System.Windows.Forms.Panel pnlSolution;
        private ListViewEx lstSolutions2;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label lblSelectedFile2;
        private System.Windows.Forms.Label lblFile2;
        private System.Windows.Forms.Label lblSelectedFile1;
        private System.Windows.Forms.Label lblFile1;
        private ListViewEx lstSolutions;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private ListViewEx lstFile;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private ListViewEx lstFile2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.CheckBox chkLastSolution;
        private System.Windows.Forms.CheckBox chkLastSolution2;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbOrgs;
        private System.Windows.Forms.GroupBox tab1grpOrg1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.GroupBox tab1grpOrg2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.GroupBox tab1grpBrowseSol2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox tab1grpBrowseSol1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox chkSolutionPackageAvailable;
        private System.Windows.Forms.Button btnSolution2;
        private System.Windows.Forms.Button btnSolution1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Label lblBrowseFile2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblBrowseFile1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnBrowseConfirm;
    }
}

