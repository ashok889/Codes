﻿angular.module('app').factory('jitModule', function ($window) {
    return $window.$jit;
}
);