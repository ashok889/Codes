﻿angular.module('app').factory('CrmSoapService', function($window) {
        return $window.Sdk;
    }
);