﻿angular.module('app').factory('connectionsService', ['CrmSoapService', '$q', function (CrmSoapService, $q) {

    var svc = {}

    svc.contactsFetchXml = function (name) {
        var fetxhXml = [
           "<fetch top=\"10\" no-lock=\"true\" >",
           "<entity name=\"contact\" >",
           "<attribute name=\"contactid\" />",
           "<attribute name=\"fullname\" />",
           "<attribute name=\"jobtitle\" />",
           "<filter>",
           "<condition attribute=\"fullname\" operator=\"like\" value=\"%",
           name,
           "%\" />",
           "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\"/>",
           "</filter>",
           "<order attribute=\"fullname\" />",
           "</entity>",
           "</fetch>"
        ].join("");
        return fetxhXml;
    }

    svc.connectionsFetchXml = function (entityId) {
        var fetxhXml = [
           "<fetch distinct=\"true\" no-lock=\"true\" >",
           "<entity name=\"connection\" >",
           "<attribute name=\"connectionid\" />",
           "<attribute name=\"record2id\" />",
           "<attribute name=\"name\" />",
           "<filter type=\"and\" >",
           "<condition attribute=\"record1id\" operator=\"eq\" value=\"",
           entityId,
           "\" />",
           "<condition attribute=\"ismaster\" operator=\"eq\" value=\"true\" />",
           "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\"/>",
           "</filter>",
           "<order attribute=\"name\" />",
           "<link-entity name=\"contact\" from=\"contactid\" to=\"record2id\" link-type=\"inner\" >",
           "<attribute name=\"jobtitle\" />",
           "<filter type=\"and\" >",
           "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />",
           "</filter>",
           "</link-entity>",
           "</entity>",
           "</fetch>"
        ].join("");
        return fetxhXml;
    }

    svc.connectionToConnectionFetchXml = function (contacts) {
        var values = [];
        contacts.forEach(function (e, i) {
            //var contactIdPos = e["id"].indexOf("contactId:");
            //values.push("<value>" + e["id"].substr(contactIdPos + 10, 36) + "</value>");
            values.push("<value>" + e["id"] + "</value>");
        });

        var fetxhXml = [
           "<fetch no-lock=\"true\" >",
           "<entity name=\"connection\" >",
           "<attribute name=\"connectionid\" />",
           "<attribute name=\"record1id\" />",
           "<attribute name=\"record2id\" />",
           "<filter>",
           "<condition attribute=\"record1id\" operator=\"in\" >",
           values.join(""),
           "</condition>",
            "<condition attribute=\"record2id\" operator=\"in\" >",
           values.join(""),
           "</condition>",
           "<condition attribute=\"ismaster\" operator=\"eq\" value=\"true\" />",
           "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\"/>",
           "</filter>",
           "<link-entity name=\"connectionrole\" from=\"connectionroleid\" to=\"record2roleid\" alias=\"role1\" >",
           "<attribute name=\"name\" />",
           "</link-entity>",
           "</entity>",
           "</fetch>"
        ].join("");
        return fetxhXml;
    }

    svc.getConnectionToConnection = function (contacts) {

        var query = CrmSoapService.Query.FetchExpression(svc.connectionToConnectionFetchXml(contacts));

        var deffered = $q.defer();

        CrmSoapService.Async.retrieveMultiple(query,
            function (response) {
                var data = {};
                var contacts = [];
                var connections = [];
                var contactvalues = [];
                response.getEntities().forEach(function (e, i) {
                    var connection = {};

                    e.getAttributes().forEach(function (a, i) {
                        if (a.getName() == "record2id" || a.getName() == "record1id" || a.getName() == "role1.name" || a.getName() == "connectionid") {
                            switch (a.getType()) {
                                case "entityReference":
                                    connection[a.getName().replace("record1id", "from").replace("record2id", "to")] = a.getValue().getId();
                                    break;
                                case "string":
                                case "guid":
                                    connection[a.getName().replace("role1.name", "label").replace("connectionid", "id")] = a.getValue();
                                    break;
                                default:
                                    break;
                            }
                        }

                    });

                    //if (e.view().attributes["contact1.jobtitle"] != undefined) {
                    //    contact["label"] += '\n' + e.getAttributes("contact1.jobtitle").getValue();
                    //}

                    connections.push(connection);
                });


                deffered.resolve(connections);
            },
            function (exception) {
                deffered.reject(exception);
            });
        return deffered.promise;
    }

    svc.getConnections = function (entityId) {

        var query = CrmSoapService.Query.FetchExpression(svc.connectionsFetchXml(entityId));

        var deffered = $q.defer();

        CrmSoapService.Async.retrieveMultiple(query,
            function (response) {

                var contacts = [];
                var baseConnectionIds = {}
                var data = {};
                response.getEntities().forEach(function (e, i) {
                    var contact = {};
                    var baseConnectionId = {};
                    e.getAttributes().forEach(function (a, i) {
                        if (a.getName() == "record2id" || a.getName() == "name" || a.getName() == "connectionid") {
                            switch (a.getType()) {
                                case "entityReference":
                                    baseConnectionId["contactId"] = a.getValue().getId();
                                    contact[a.getName().replace("record2id", "id")] = a.getValue().getId();
                                    break;
                                default:
                                    if (a.getName() == "name") {
                                        contact[a.getName().replace("name", "label")] = a.getValue();
                                    }
                                    if (a.getName() == "connectionid") {
                                        baseConnectionId["connectionId"] = a.getValue();
                                    }
                                    break;
                            }
                        }

                    });

                    baseConnectionIds[baseConnectionId.contactId] = baseConnectionId.connectionId;
                    if (e.view().attributes["contact1.jobtitle"] != undefined) {
                        contact["label"] += '\n' + e.getAttributes("contact1.jobtitle").getValue();
                    }

                    contact["group"] = 'contact';

                    contacts.push(contact);

                });

                data["contacts"] = contacts;
                data["connectionIds"] = baseConnectionIds;
                deffered.resolve(data);
            },
            function (exception) {
                deffered.reject(exception);
            });
        return deffered.promise;
    }

    // Add connection (i.e. contact to contact or contact to opportunity)
    svc.addConnection = function (from, fromType, to, toType) {

        var deffered = $q.defer();
        var connection = new CrmSoapService.Entity("connection");
        connection.addAttribute(new CrmSoapService.Lookup('record1id', new CrmSoapService.EntityReference(fromType, from)));
        connection.addAttribute(new CrmSoapService.Lookup('record1roleid', new CrmSoapService.EntityReference('connectionrole', '1E3DAA3B-3849-E611-8F24-005056AE789B')));
        connection.addAttribute(new CrmSoapService.Lookup('record2roleid', new CrmSoapService.EntityReference('connectionrole', '1E3DAA3B-3849-E611-8F24-005056AE789B')));
        connection.addAttribute(new CrmSoapService.Lookup('record2id', new CrmSoapService.EntityReference(toType, to)));


        CrmSoapService.Async.create(connection,
            function (response) {
                deffered.resolve(response);
            },
            function (exception) {
                deffered.reject(exception);
            });
        return deffered.promise;
    }

    svc.deleteConnection = function (connectionId) {
        var deffered = $q.defer();

        CrmSoapService.Async.del('connection', connectionId,
           function (response) {
               deffered.resolve(response);
           },
           function (exception) {
               deffered.reject(exception);
           });
        return deffered.promise;

    }

    svc.getContacts = function (name) {
        var query = CrmSoapService.Query.FetchExpression(svc.contactsFetchXml(name));
        var deffered = $q.defer();

        CrmSoapService.Async.retrieveMultiple(query,
          function (response) {
              var contacts = [];
              response.getEntities().forEach(function (e, i) {
                  var contact = {};
                  e.getAttributes().forEach(function (a, i) {
                      if (a.getName() == "contactid" || a.getName() == "fullname" || a.getName() == "jobtitle") {
                          contact[a.getName()] = a.getValue();
                      }
                  });
                  contacts.push(contact);
              });

              deffered.resolve(contacts);
          },
          function (exception) {
              deffered.reject(exception);
          });
        return deffered.promise;
    }

    svc.getConnectionLayout = function(opportunityId) {
        var deffered = $q.defer();

        var columnSet = new Sdk.ColumnSet("rbsm_connectionnetworkdata");
        CrmSoapService.Async.retrieve("opportunity", opportunityId,columnSet,
            function (response) {
                deffered.resolve(response);
            },
            function (exception) {
                deffered.reject(exception);
            });
        return deffered.promise;
    }

    svc.saveConnectionLayout = function(opportunityId, layout) {
        var deffered = $q.defer();
        var opportunity = new CrmSoapService.Entity("opportunity");
        opportunity.setId(opportunityId);
  
        opportunity.addAttribute(new CrmSoapService.String('rbsm_connectionnetworkdata', layout));
        
        CrmSoapService.Async.update(opportunity,
            function (response) {
                deffered.resolve(response);
            },
            function (exception) {
                deffered.reject(exception);
            });
        return deffered.promise;
    }

    return svc;
}]);