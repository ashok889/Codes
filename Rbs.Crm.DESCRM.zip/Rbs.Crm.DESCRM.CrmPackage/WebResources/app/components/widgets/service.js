﻿angular.module('app').factory('WidgetService', ['CrmSoapService', '$q', function (CrmSoapService, $q) {

    var svc = {}
    svc.fetch = function (fetchXml) {
        var query = CrmSoapService.Query.FetchExpression(fetchXml);

        var deffered = $q.defer();

        CrmSoapService.Async.retrieveMultiple(query,
            function (response) {
                var recs = [];
                response.getEntities().forEach(function (e, i) {
                    var rec = {};

                    e.getAttributes().forEach(function (a, i) {
                        rec[a.getName()] = a.getValue();
                    });

                    recs.push(rec);
                });

                deffered.resolve(recs);
            },
            function (exception) {
                deffered.reject(exception);
            });
        return deffered.promise;
    }

    return svc;

}]);