﻿angular.module('app').controller('connectionsController', [
   '$scope', 'connectionsService', 'visModule', function ($scope, connectionsService, visModule) {

       var networkData = {};
       var seed = 2;
       network = null;
       baseConnectionIds = {};
       $scope.contactsFound = [];
       $scope.contactName = '';


       function destroy() {
           if (network !== null) {
               network.destroy();
               network = null;
           }
       }


       $scope.openRecord = function (type, id) {
           if (id != null) {
               var url = Xrm.Page.context.getClientUrl() +
                   "/main.aspx?etn=" + type + "&pagetype=entityrecord&id=" + id;
               Xrm.Utility.openEntityForm(type, id, null);
           }
       }


       $scope.findContacts = function () {
           connectionsService.getContacts($scope.contactName).then(function (response) {
               if (response != null) {
                   $scope.contactsFound = response;
               }
           },
       function (exception) {
       });
       }

       $scope.addContact = function (contact) {
           // add connection to opportunity
           var opportunityId = window.parent.Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
           if (networkData.nodes != undefined && networkData.nodes.get(contact.contactid) === null || networkData.nodes == undefined) {
               connectionsService.addConnection(opportunityId, 'opportunity', contact.contactid, 'contact').then(function (response) {
                   if (response != null) {
                       var jobTitle = (contact.jobtitle == undefined) ? '' : contact.jobtitle;
                       networkData.nodes.add({ id: contact.contactid, label: contact.fullname + '\n' + jobTitle, group: 'contact', x: -100, y: -40 });
                       baseConnectionIds[contact.contactid] = response;
                       $scope.clearPopUp();
                       $scope.saveNetworkLayout();
                       $scope.createNetwork();
                   }
               }, function (exception) {

               });
           } else {
               alert("Contact " + contact.fullname + " already added!");
               $scope.clearPopUp();
           }
       }

       draw = function () {
           destroy();
           // create a network
           var container = document.getElementById('mynetwork');
           var options = {
               autoResize: true,
               physics: {
                   enabled: true
               },
               groups: {
                   opportunity: {
                       color: { background: '#397139', border: '#397139' },
                   },
                   contact: {
                       color: { background: '#00518C', border: '#00518C' },
                       shape: 'box',
                   },
                   account: {
                       color: { background: '#7B4100', border: '#7B4100' },
                       shape: 'box',
                   }
               },
               edges: {
                   arrows: {
                       to: { enabled: true, scaleFactor: 0.5 }
                   },
                   smooth: true,
                   font: {
                       size: 0,
                       face: 'arial',
                   }
               },
               nodes: {
                   labelHighlightBold: false,
                   physics: false,
                   borderWidth: 1,
                   font: { face: 'Arial', color: 'White', size: 12 },
                   color: {
                       background: 'lightskyblue',
                       border: 'lightskyblue',
                       highlight: {
                           border: '#525552',
                           background: '#525552'
                       }
                   },
                   shape: 'box',
                   shapeProperties: {
                       borderRadius: 10
                   },
                   shadow: {
                       enabled: true,
                       color: '#ccc',
                       size: 8,
                       x: 3,
                       y: 3
                   }
               },
               layout: {
                   randomSeed: seed, // just to make sure the layout is the same when the locale is changed
                   //hierarchical: {
                   //    enabled: true,
                   //    direction: "DU",
                   ////    sortMethod: "directed",
                   ////    nodeSpacing: 200,
                   //    levelSeparation: 90
                   //}
               },
               locale: document.getElementById('locale').value,
               manipulation: {
                   enabled: true,
                   initiallyActive: true,
                   deleteNode: function (data, callback) {
                       connectionsService.deleteConnection(baseConnectionIds[data.nodes[0]]);
                       callback(data);
                       $scope.saveNetworkLayout();
                   },
                   addNode: function (data, callback) {
                       // filling in the popup DOM elements
                       data.group = 'contact';
                       document.getElementById('operation').innerHTML = " ";
                       document.getElementById('node-id').value = data.id;
                       document.getElementById('node-label').value = data.label;
                       document.getElementById('saveButton').onclick = saveData.bind(this, data, callback);
                       document.getElementById('cancelButton').onclick = cancelEdit.bind(callback);
                       document.getElementById('network-popUp').style.display = 'block';
                       document.getElementById('name').focus();
                   },
                   editEdge: false,
                   deleteEdge: function (data, callback) {
                       var thisEdge = network.body.data.edges.get(data.edges[0]);

                       connectionsService.deleteConnection(thisEdge.id).then(function (response) {
                           $scope.saveNetworkLayout();
                       }, function (exception) {

                       });

                       callback(data);
                   },
                   addEdge: function (data, callback) {
                       data["label"] = 'Related';

                       if (data.from == data.to) {
                           var r = confirm("Do you want to connect the node to itself?");
                           if (r == true) {
                               callback(data);
                           }
                       }
                       else {
                           //create contact to contact connection
                           connectionsService.addConnection(data.from, 'contact', data.to, 'contact').then(function (response) {
                               data["id"] = response;
                               callback(data);
                               networkData.redraw();
                               $scope.saveNetworkLayout();
                           }, function (exception) {

                           });
                       }
                   }
               }
           };
           network = new visModule.Network(container, networkData, options);
           network.on("dragEnd", function (params) {
               params.event = "[original event]";
               if (params.nodes.length > 0) {
                   $scope.saveNetworkLayout();
               }
           });
           network.on("doubleClick", function (params) {
               params.event = "[original event]";
               if (params.nodes.length > 0) {
                   $scope.openRecord('contact', params.nodes[0]);
               }
               else if (params.edges.length > 0) {
                   $scope.openRecord('connection', params.edges[0]);
               }
           });
       }

       $scope.checkKey = function (event) {
           if (event.which === 27) {
               $scope.clearPopUp();
               networkData.addNodeMode = false;
               networkData.redraw();
               event.preventDefault();
           }
       }

       $scope.clearPopUp = function () {
           document.getElementById('saveButton').onclick = null;
           document.getElementById('cancelButton').onclick = null;
           document.getElementById('name').value = '';
           $scope.contactsFound = [];
           document.getElementById('network-popUp').style.display = 'none';
       }

       $scope.saveNetworkLayout = function () {
           network.storePositions();
           var opportunityId = window.parent.Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
           var positions = [];
           networkData.nodes.forEach(function (e, i) {
               var contactPos = {};
               contactPos["id"] = e.id;
               contactPos["x"] = e.x;
               contactPos["y"] = e.y;
               positions.push(contactPos);
           });

           var layout = JSON.stringify(positions);
           connectionsService.saveConnectionLayout(opportunityId, layout);
       }



       function cancelEdit(callback) {
           $scope.contactsFound = [];
           $scope.clearPopUp();
           callback(null);

       }

       function saveData(data, callback) {
           data.id = document.getElementById('node-id').value;
           data.label = document.getElementById('node-label').value;
           $scope.clearPopUp();

           // add connection to opportunity
           var opportunityId = window.parent.Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
           connectionsService.addConnection(opportunityId, 'opportunity', data.id, 'contact');
           callback(data);
       }
       function appendConnectionPositions(positions, contacts) {
           contacts.forEach(function (e, i) {

               positions.forEach(function (a, i) {
                   if (e.id == a.id) {
                       try {
                           contacts[i]["x"] = a["x"];
                           contacts[i]["y"] = a["y"];
                       } catch (ex)
                       { }
                   }
               });

           });
           return contacts;
       }

       $scope.createNetwork = function () {
           var opportunityId = window.parent.Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');
           connectionsService.getConnections(opportunityId).then(function (data) {
               if (data != null && data.contacts !== null && data.contacts.length > 0) {
                   baseConnectionIds = data.connectionIds;

                   connectionsService.getConnectionToConnection(data.contacts).then(function (connections) {
                       if (connections != null) {
                           connectionsService.getConnectionLayout(opportunityId).then(function (layout) {

                               if (layout instanceof Sdk.Entity && layout.view().attributes["rbsm_connectionnetworkdata"] != undefined) {
                                   data.contacts = appendConnectionPositions(JSON.parse(layout.getValue("rbsm_connectionnetworkdata")), data.contacts);
                               }
                               networkData = {
                                   nodes: new visModule.DataSet(data.contacts),
                                   edges: new visModule.DataSet(connections)
                               };
                               draw();
                           },
                            function (exception) {
                            });
                       } else {
                           draw();
                       }
                   },
                    function (exception) {
                    });

               } else {
                   networkData = {
                       nodes: new visModule.DataSet([]),
                       edges: new visModule.DataSet([])
                   };
                   draw();
               }
           }, function (exception) {

           });
           draw();
       }

       $scope.createNetwork();
   }
]);