﻿angular.module('app').controller('widgetController', [
    '$scope', 'WidgetService', function ($scope, WidgetService) {

        $scope.warningIcon = "fa fa-calendar-check-o";

        $scope.openRecord = function (type, id) {
            var url = Xrm.Page.context.getClientUrl() +
                "/main.aspx?etn=" + type + "&pagetype=entityrecord&id=" + id;
            Xrm.Utility.openEntityForm(type, id, null);
        }

        var opportunityId = window.parent.Xrm.Page.data.entity.getId();
        var statecode = window.parent.Xrm.Page.getAttribute('statecode').getValue();
        var formType = window.parent.Xrm.Page.ui.getFormType();
        if (statecode == 0 && formType > 1) {

            var fetchXml_NextApp = ["<fetch count=\"1\" no-lock=\"true\" >",
                "<entity name=\"activitypointer\" >",
                "<attribute name=\"scheduledstart\" />",
                "<attribute name=\"subject\" />",
                "<filter>",
                "<condition attribute=\"activitytypecode\" operator=\"eq\" value=\"4201\" />",
                "<condition attribute=\"scheduledstart\" operator=\"next-x-days\" value=\"999999\" />",
                 "<condition attribute=\"regardingobjectid\" operator=\"eq\" value=\"",
                opportunityId,
                "\" />",
                "</filter>",
                "<order attribute=\"scheduledstart\" />",
                "</entity>",
                "</fetch>"
            ].join("");

            WidgetService.fetch(fetchXml_NextApp).then(function (data) {
                if (data.length == 1) {
                    $scope.nextContact = data[0].scheduledstart;
                    $scope.nextContactState = 'crmData';
                } else {
                    $scope.nextContact = 'Not Scheduled';
                    $scope.nextContactState = 'crmData red';
                }
            }, function (exception) {

            });


            var fetchXml_LastContact_Appointment = ["<fetch count=\"1\" no-lock=\"true\" >",
               "<entity name=\"activitypointer\" >",
               "<attribute name=\"scheduledend\" />",
               "<filter>",
               "<condition attribute=\"activitytypecode\" operator=\"eq\" value=\"4201\" />",
               "<condition attribute=\"scheduledend\" operator=\"last-x-days\" value=\"9999\" />",
               "<condition attribute=\"regardingobjectid\" operator=\"eq\" value=\"",
               opportunityId,
               "\" />",
               "</filter>",
               "<order attribute=\"scheduledend\" descending=\"true\" />",
               "</entity>",
               "</fetch>"
            ].join("");

            var fetchXml_LastContact_Other = ["<fetch count=\"1\" no-lock=\"true\" >",
               "<entity name=\"activitypointer\" >",
               "<attribute name=\"actualend\" />",
               "<filter>",
               "<condition attribute=\"activitytypecode\" operator=\"in\" >",
               "<value>4202</value>",
               "<value>4210</value>",
               "<value>4204</value>",
               "<value>4207</value>",
               "</condition>",
               "<condition attribute=\"actualend\" operator=\"last-x-days\" value=\"9999\" />",
               "<condition attribute=\"regardingobjectid\" operator=\"eq\" value=\"",
               opportunityId,
               "\" />",
               "</filter>",
               "<order attribute=\"actualend\" descending=\"true\" />",
               "</entity>",
               "</fetch>"
            ].join("");


            WidgetService.fetch(fetchXml_LastContact_Other).then(function (data1) {
                if (data1.length == 1) {
                    $scope.lastContact = data1[0].actualend;
                    $scope.days = getDays($scope.lastContact);
                    $scope.warningIcon = getWarningIcon($scope.days);

                    WidgetService.fetch(fetchXml_LastContact_Appointment).then(function (data2) {
                        if (data2.length == 1) {
                            if (data2[0].scheduledend > data1[0].actualend) {
                                $scope.lastContact = data2[0].scheduledend;
                                $scope.days = getDays($scope.lastContact);
                                $scope.warningIcon = getWarningIcon($scope.days);
                            }
                        } else {

                        }
                    }, function (exception) {

                    });
                } else {
                    WidgetService.fetch(fetchXml_LastContact_Appointment).then(function (data3) {
                        if (data3.length == 1) {
                            $scope.lastContact = data3[0].scheduledend;
                            $scope.days = getDays($scope.lastContact);
                            $scope.warningIcon = getWarningIcon($scope.days);
                        } else {
                            $scope.days = '--';
                            $scope.warningIcon = "fa fa-calendar-check-o";
                        }
                    }, function (exception) {

                    });
                }
            }, function (exception) {

            });
        }

        function getDays(contactDate) {

            var dc = '';
            if (contactDate !== undefined) {
                var myDate = new Date(contactDate);
                var today = new Date();
                var myDate_ms = myDate.getTime();
                var today_ms = today.getTime();
                var diff = today_ms - myDate_ms;
                dc = Math.round(diff / (1000 * 60 * 60 * 24));
            }

            return dc;
        }

        function getWarningIcon(days) {
            var iconClass = '';
            switch (true) {
                case (days > 5 && days <= 10):
                    iconClass = "fa fa-calendar-times-o ora";
                    break;
                case (days > 10):
                    iconClass = "fa fa-calendar-times-o red";
                    break;
                default:
                    iconClass = "fa fa-calendar-check-o green";
                    break;
            }
            return iconClass;
        }
    }
]);
