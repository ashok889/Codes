﻿angular.module('app').factory('visModule', function ($window) {
    return $window.vis;
}
);