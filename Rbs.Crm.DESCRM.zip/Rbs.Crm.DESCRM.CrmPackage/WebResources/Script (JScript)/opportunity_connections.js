﻿if (typeof (Rbs) == "undefined") {
    Rbs = {};
}

if (typeof (Rbs.Crm) == "undefined") {
    Rbs.Crm = {};
}

if (typeof (Rbs.Crm.DESCRM) == "undefined") {
    Rbs.Crm.DESCRM = {};
}

Rbs.Crm.DESCRM.Opportunity_Connections = {
    onLoad: function () {
        document.getElementById("header_process_d").style.display = "none";
        // crm2015/16 suported version
        // Xrm.Page.ui.process.setVisible(false);
    }
}