﻿if (typeof (Rbs) == "undefined") {
    Rbs = {};
}

if (typeof (Rbs.Crm) == "undefined") {
    Rbs.Crm = {};
}

if (typeof (Rbs.Crm.DESCRM) == "undefined") {
    Rbs.Crm.DESCRM = {};
}

Rbs.Crm.DESCRM.Opportunity = {
    onSave: function () {
        var contactWebResource = Xrm.Page.ui.controls.get('WebResource_index');
        contactWebResource.setSrc(contactWebResource.getSrc());
    }
}