﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Rbs.Crm.DESCRM.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
