//jquery.sdk.rest.js

if (typeof (SDKAPI) == "undefined")
{ SDKAPI = { __namespace: true }; }
SDKAPI.REST = {
    _context: function () {
        ///<summary>
        /// Private function to the context object.
        ///</summary>
        ///<returns>Context</returns>
        if (typeof GetGlobalContext != "undefined")
        { return GetGlobalContext(); }
        else {
            if (typeof Xrm != "undefined") {
                return Xrm.Page.context;
            }
            else { throw new Error("Context is not available."); }
        }
    },
    _getServerUrl: function () {
        ///<summary>
        /// Private function to return the server URL from the context
        ///</summary>
        ///<returns>String</returns>
        var serverUrl = this._context().getClientUrl()
        if (serverUrl.match(/\/$/)) {
            serverUrl = serverUrl.substring(0, serverUrl.length - 1);
        }
        return serverUrl;
    },
    _ODataPath: function () {
        ///<summary>
        /// Private function to return the path to the REST endpoint.
        ///</summary>
        ///<returns>String</returns>
        return this._getServerUrl() + "/api/data/v8.0/";
    },
    _errorHandler: function (req) {
        ///<summary>
        /// Private function return an Error object to the errorCallback
        ///</summary>
        ///<param name="req" type="XMLHttpRequest">
        /// The XMLHttpRequest response that returned an error.
        ///</param>
        ///<returns>Error</returns>
        return new Error("Error : " +
              req.status + ": " +
              req.statusText + ": " +
              JSON.parse(req.responseText).error.message.value);
    },
    _dateReviver: function (key, value) {
        ///<summary>
        /// Private function to convert matching string values to Date objects.
        ///</summary>
        ///<param name="key" type="String">
        /// The key used to identify the object property
        ///</param>
        ///<param name="value" type="String">
        /// The string value representing a date
        ///</param>
        var a;
        if (typeof value === 'string') {
            a = /Date\(([-+]?\d+)\)/.exec(value);
            if (a) {
                return new Date(parseInt(value.replace("/Date(", "").replace(")/", ""), 10));
            }
        }
        return value;
    },
    _parameterCheck: function (parameter, message) {
        ///<summary>
        /// Private function used to check whether required parameters are null or undefined
        ///</summary>
        ///<param name="parameter" type="Object">
        /// The parameter to check;
        ///</param>
        ///<param name="message" type="String">
        /// The error message text to include when the error is thrown.
        ///</param>
        if ((typeof parameter === "undefined") || parameter === null) {
            throw new Error(message);
        }
    },
    _stringParameterCheck: function (parameter, message) {
        ///<summary>
        /// Private function used to check whether required parameters are null or undefined
        ///</summary>
        ///<param name="parameter" type="String">
        /// The string parameter to check;
        ///</param>
        ///<param name="message" type="String">
        /// The error message text to include when the error is thrown.
        ///</param>
        if (typeof parameter != "string") {
            throw new Error(message);
        }
    },
    _callbackParameterCheck: function (callbackParameter, message) {
        ///<summary>
        /// Private function used to check whether required callback parameters are functions
        ///</summary>
        ///<param name="callbackParameter" type="Function">
        /// The callback parameter to check;
        ///</param>
        ///<param name="message" type="String">
        /// The error message text to include when the error is thrown.
        ///</param>
        if (typeof callbackParameter != "function") {
            throw new Error(message);
        }
    },
    createRecord: function (object, type, successCallback, errorCallback) {
        ///<summary>
        /// Sends an asynchronous request to create a new record.
        ///</summary>
        ///<param name="object" type="Object">
        /// A JavaScript object with properties corresponding to the Schema name of
        /// entity attributes that are valid for create operations.
        ///</param>
        this._parameterCheck(object, "SDKAPI.REST.createRecord requires the object parameter.");
        ///<param name="type" type="String">
        /// The Schema Name of the Entity type record to create.
        /// For an Account record, use "Account"
        ///</param>
        this._stringParameterCheck(type, "SDKAPI.REST.createRecord requires the type parameter is a string.");
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// This function can accept the returned record as a parameter.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.createRecord requires the successCallback is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.createRecord requires the errorCallback is a function.");
          if ($.browser.msie) {
            var systemQueryOptions = "Type=" + type + "&PostData=" + JSON.stringify(object) + "&ServiceUrl=" + this._getServerUrl();

            //$http.post(this._ServicePath() + 'createRecord', systemQueryOptions)
            xdr = new XDomainRequest();

            function timeo() {
                //alertbox();
                return_errorcallback('Oops! Time out');
            }
            function loadd() {
                var results= JSON.parse(xdr.responseText)
                var entityid = '';
                if (Object.isNotNull(results)) {
                    if (results.status == 200) {
                        if (Object.isNotNull(results.data)) {
                            if (results.data.Success == true) {
                                //var entityid = String.empty;
                                if (Object.isNotNull(results.data.Data)) {
                                    //var entityid = results.data.Data('OData-EntityId');
                                    entityid = results.data.Data;

                                }
                                successCallback(String.recordIdFromResponse(entityid));
                                //successCallback(null);
                            } else {
                                successCallback(null);
                            }
                        } else {
                            errorCallback(SDKAPI.REST._errorHandler(results));

                           // errorCallback(SDKService.Service._errorHandler(results));
                        }
                    } else {
                        errorCallback(SDKAPI.Service._errorHandler(results));
                    }
                } else {
                    errorCallback(SDKAPI.Service._errorHandler(results));
                }



            }
            function stopdata() {
                //alertbox('Stopped!');
                return_errorcallback('Stopped!');
                xdr.abort();
            }

            xdr.open('post', sharepoint_wcfurl + "/createRecord");
            xdr.onerror = err;
            xdr.ontimeout = timeo;
            xdr.onload = loadd;
            xdr.onprogress = function () { };
            xdr.timeout = 200000000;

            setTimeout(function () {
                xdr.send(systemQueryOptions);
            }, 500);

           

        }
        else{
        var req = new XMLHttpRequest();
        req.open("POST", encodeURI(this._ODataPath() + type), true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                req.onreadystatechange = null;
                if (this.status == 204 || this.status == 1223) {
                   // successCallback(JSON.parse(this.responseText, SDKAPI.REST._dateReviver).d);
                    var uri = this.getResponseHeader("OData-EntityId");
            var regExp = /\(([^)]+)\)/;
            var matches = regExp.exec(uri);
            var newEntityId = matches[1];
                     
                    successCallback(newEntityId);
                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send(JSON.stringify(object));
        }
    },
    retrieveRecord: function (id, type, select, expand, successCallback, errorCallback) {
        ///<summary>
        /// Sends an asynchronous request to retrieve a record.
        ///</summary>
        ///<param name="id" type="String">
        /// A String representing the GUID value for the record to retrieve.
        ///</param>
        this._stringParameterCheck(id, "SDKAPI.REST.retrieveRecord requires the id parameter is a string.");
        ///<param name="type" type="String">
        /// The Schema Name of the Entity type record to retrieve.
        /// For an Account record, use "Account"
        ///</param>
        this._stringParameterCheck(type, "SDKAPI.REST.retrieveRecord requires the type parameter is a string.");
        ///<param name="select" type="String">
        /// A String representing the $select OData System Query Option to control which
        /// attributes will be returned. This is a comma separated list of Attribute names that are valid for retrieve.
        /// If null all properties for the record will be returned
        ///</param>
        if (select != null)
            this._stringParameterCheck(select, "SDKAPI.REST.retrieveRecord requires the select parameter is a string.");
        ///<param name="expand" type="String">
        /// A String representing the $expand OData System Query Option value to control which
        /// related records are also returned. This is a comma separated list of of up to 6 entity relationship names
        /// If null no expanded related records will be returned.
        ///</param>
        if (expand != null)
            this._stringParameterCheck(expand, "SDKAPI.REST.retrieveRecord requires the expand parameter is a string.");
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// This function must accept the returned record as a parameter.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.retrieveRecord requires the successCallback parameter is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.retrieveRecord requires the errorCallback parameter is a function.");

        var systemQueryOptions = "";

        if (select != null || expand != null) {
            systemQueryOptions = "?";
            if (select != null) {
                var selectString = "$select=" + select;
                if (expand != null) {
                  //  selectString = selectString + "," + expand;
                    selectString = selectString + "&$expand=" + expand;
                  
                }
                systemQueryOptions = systemQueryOptions + selectString;
            }else if (expand != null) {
                systemQueryOptions = systemQueryOptions + "$expand=" + expand;
            }
        }
        


        var req = new XMLHttpRequest();
        req.open("GET", this._ODataPath() + type + "(" + id + ")" + systemQueryOptions, true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("Prefer", "odata.include-annotations=*");
        req.setRequestHeader("OData-Version", "4.0");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {            
           
                if (this.status == 200) {
                    //successCallback(JSON.parse(this.responseText, SDKAPI.REST._dateReviver).d);
                    var data= this.response!=undefined?this.response:this.responseText;
                    var resultData = JSON.parse(JSON.stringify(data), SDKAPI.REST._dateReviver)
                    successCallback(resultData);

                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();
    },
    updateRecord: function (id, object, type, successCallback, errorCallback) {
        ///<summary>
        /// Sends an asynchronous request to update a record.
        ///</summary>
        ///<param name="id" type="String">
        /// A String representing the GUID value for the record to retrieve.
        ///</param>
        this._stringParameterCheck(id, "SDKAPI.REST.updateRecord requires the id parameter.");
        ///<param name="object" type="Object">
        /// A JavaScript object with properties corresponding to the Schema Names for
        /// entity attributes that are valid for update operations.
        ///</param>
        this._parameterCheck(object, "SDKAPI.REST.updateRecord requires the object parameter.");
        ///<param name="type" type="String">
        /// The Schema Name of the Entity type record to retrieve.
        /// For an Account record, use "Account"
        ///</param>
        this._stringParameterCheck(type, "SDKAPI.REST.updateRecord requires the type parameter.");
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// Nothing will be returned to this function.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.updateRecord requires the successCallback is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.updateRecord requires the errorCallback is a function.");
        var req = new XMLHttpRequest();

        req.open("PATCH", this._ODataPath() + type + "(" + id + ")", true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
       // req.setRequestHeader("X-HTTP-Method", "MERGE");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                if (this.status == 204 || this.status == 1223) {
                    successCallback();
                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send(JSON.stringify(object));
    },
    deleteRecord: function (id, type, successCallback, errorCallback) {
        ///<summary>
        /// Sends an asynchronous request to delete a record.
        ///</summary>
        ///<param name="id" type="String">
        /// A String representing the GUID value for the record to delete.
        ///</param>
        this._stringParameterCheck(id, "SDKAPI.REST.deleteRecord requires the id parameter.");
        ///<param name="type" type="String">
        /// The Schema Name of the Entity type record to delete.
        /// For an Account record, use "Account"
        ///</param>
        this._stringParameterCheck(type, "SDKAPI.REST.deleteRecord requires the type parameter.");
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// Nothing will be returned to this function.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.deleteRecord requires the successCallback is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.deleteRecord requires the errorCallback is a function.");
        var req = new XMLHttpRequest();
        req.open("DELETE", this._ODataPath() + type + "(" + id + ")", true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
         req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
       // req.setRequestHeader("X-HTTP-Method", "DELETE");
        req.onreadystatechange = function () {

            if (this.readyState == 4 /* complete */) {
             req.onreadystatechange = null;
                if (this.status == 204 || this.status == 1223) {
                    successCallback();
                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();

    },
    retrieveMultipleRecords: function (type, options, successCallback, errorCallback, OnComplete) {
        ///<summary>
        /// Sends an asynchronous request to retrieve records.
        ///</summary>
        ///<param name="type" type="String">
        /// The Schema Name of the Entity type record to retrieve.
        /// For an Account record, use "Account"
        ///</param>
        this._stringParameterCheck(type, "SDK.REST.retrieveMultipleRecords requires the type parameter is a string.");
        ///<param name="options" type="String">
        /// A String representing the OData System Query Options to control the data returned
        ///</param>
        if (options != null)
            this._stringParameterCheck(options, "SDK.REST.retrieveMultipleRecords requires the options parameter is a string.");
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called for each page of records returned.
        /// Each page is 50 records. If you expect that more than one page of records will be returned,
        /// this function should loop through the results and push the records into an array outside of the function.
        /// Use the OnComplete event handler to know when all the records have been processed.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDK.REST.retrieveMultipleRecords requires the successCallback parameter is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDK.REST.retrieveMultipleRecords requires the errorCallback parameter is a function.");
        ///<param name="OnComplete" type="Function">
        /// The function that will be called when all the requested records have been returned.
        /// No parameters are passed to this function.
        /// </param>
        this._callbackParameterCheck(OnComplete, "SDK.REST.retrieveMultipleRecords requires the OnComplete parameter is a function.");

        var optionsString;
        if (options != null) {
            if (options.charAt(0) != "?") {
                optionsString = "?" + options;
            }
            else { optionsString = options; }
        }
        var req = new XMLHttpRequest();
        req.open("GET", this._ODataPath() + type + "" + optionsString, true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=*");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.onreadystatechange = function () {
       
            if (this.readyState == 4 /* complete */) {
                if (this.status == 200) {
                var data= this.response!=undefined?this.response:this.responseText;
                var results = JSON.parse(JSON.stringify(JSON.parse(JSON.stringify(data))))
                    //var returned = JSON.parse(this.responseText, SDKAPI.REST._dateReviver).d;
                       var returned = JSON.parse(results, SDKAPI.REST._dateReviver);
                    successCallback(returned);
                    var nextLink = returned["@odata.nextLink"];
                    // if (returned.__next != null) {
                    if (nextLink) {

                        var queryOptions = returned.__next.substring((SDKAPI.REST._ODataPath() + type ).length);
                        SDKAPI.REST.retrieveMultipleRecords(type, queryOptions, successCallback, errorCallback, OnComplete);
                    }
                    else { OnComplete(); }
                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();


    },
        retrieveGlobalOptionSetMetaDataId: function (type, successCallback, errorCallback) {
        ///<summary>
        /// Sends an asynchronous request to retrieve meta data id of option set.
        ///</summary>
           ///<param name="type" type="String">
        /// The Schema Name of the option setrecord to retrieve.        
        ///</param>
        this._stringParameterCheck(type, "SDKAPI.REST.retrieveGlobalOptionSetMetaDataId requires the type parameter is a string.");
     
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// This function must accept the returned record as a parameter.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.retrieveGlobalOptionSetMetaDataId requires the successCallback parameter is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.retrieveGlobalOptionSetMetaDataId requires the errorCallback parameter is a function.");

   

       


        var req = new XMLHttpRequest();
        req.open("GET", this._ODataPath() +"GlobalOptionSetDefinitions?$select=Name", false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                if (this.status == 200 || service.status == 201) {


                    var RetrieveService = eval('(' + this.responseText + ')');

                    if (RetrieveService.value.length > 0) {

                        for (var i = 0; i < RetrieveService.value.length; i++) {

                            if (RetrieveService.value[i].Name == type) {

                                globalOptionSetMetaDataId = RetrieveService.value[i].MetadataId;
                                successCallback(globalOptionSetMetaDataId);
                                break;

                            }

                        }

                    }

                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();
    },

    retrieveGlobalOptionSetOptionsMetaData: function (id, successCallback, errorCallback) {
        ///<summary>
        /// Sends an asynchronous request to retrieve  retrieve meta data of optionSet.
        ///</summary>
        ///<param name="id" type="String">
        /// A String representing the GUID value for the record to retrieve.
        ///</param>
        this._stringParameterCheck(id, "SDKAPI.REST.retrieveGlobalOptionSetOptionsMetaData requires the id parameter is a string.");

        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// This function must accept the returned record as a parameter.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.retrieveGlobalOptionSetOptionsMetaData requires the successCallback parameter is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.retrieveGlobalOptionSetOptionsMetaData requires the errorCallback parameter is a function.");






        var req = new XMLHttpRequest();
        req.open("GET", this._ODataPath() + "GlobalOptionSetDefinitions(" + id + ")", false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                if (this.status == 200 || service.status == 201) {


                    var RetrieveService = eval('(' + this.responseText + ')');

                    if (RetrieveService.Options.length > 0) {

                        successCallback(RetrieveService);
                        //var options = "";

                        //for (var i = 0; i < RetrieveService.Options.length; i++) {

                        //    var optionLabel = RetrieveService.Options[i].Label.UserLocalizedLabel.Label;

                        //    var optionValue = RetrieveService.Options[i].Value;

                        //    options += "<option value='" + optionValue + "'>" + optionLabel + "</option>";

                        //}

                        //$("#dropdownReason").html(options);

                    }

                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();
    },
    associateRecords: function (parentId, parentType, relationshipName, childId, childType, successCallback, errorCallback) {
        this._stringParameterCheck(parentId, "SDKAPI.REST.associateRecords requires the parentId parameter is a string.");
        ///<param name="parentId" type="String">
        /// The Id of the record to be the parent record in the relationship
        /// </param>
        ///<param name="parentType" type="String">
        /// The Schema Name of the Entity type for the parent record.
        /// For an Account record, use "Account"
        /// </param>
        ///<param name="relationshipName" type="String">
        /// The Schema Name of the Entity Relationship to use to associate the records.
        /// To associate account records as a Parent account, use "Referencedaccount_parent_account"
        /// </param>
        ///<param name="childId" type="String">
        /// The Id of the record to be the child record in the relationship
        /// </param>
        ///<param name="childType" type="String">
        /// The Schema Name of the Entity type for the child record.
        /// For an Account record, use "Account"
        /// </param>
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// Nothing will be returned to this function.
        /// </param>
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._stringParameterCheck(parentType, "SDKAPI.REST.associateRecords requires the parentType parameter is a string.");
        this._stringParameterCheck(relationshipName, "SDKAPI.REST.associateRecords requires the relationshipName parameter is a string.");
        this._stringParameterCheck(childId, "SDKAPI.REST.associateRecords requires the childId parameter is a string.");
        this._stringParameterCheck(childType, "SDKAPI.REST.associateRecords requires the childType parameter is a string.");
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.associateRecords requires the successCallback parameter is a function.");
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.associateRecords requires the errorCallback parameter is a function.");

       var childEntityReference = {}
        childEntityReference = this._ODataPath() + "/" + childType + "(" + childId + ")";
       
        var req = new XMLHttpRequest();
        req.open("POST", encodeURI(this._ODataPath() + parentType + "(" + parentId + ")/" + relationshipName+"/$ref"), true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        //req.setRequestHeader("odata.id", childEntityReference)
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                req.onreadystatechange = null;
                if (this.status == 204 || this.status == 1223) {
                    successCallback();
                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
              req.send(JSON.stringify({"@odata.id":  childEntityReference }));
    },
    disassociateRecords: function (parentId, parentType, relationshipName, childId, successCallback, errorCallback) {
        this._stringParameterCheck(parentId, "SDKAPI.REST.disassociateRecords requires the parentId parameter is a string.");
        ///<param name="parentId" type="String">
        /// The Id of the record to be the parent record in the relationship
        /// </param>
        ///<param name="parentType" type="String">
        /// The Schema Name of the Entity type for the parent record.
        /// For an Account record, use "Account"
        /// </param>
        ///<param name="relationshipName" type="String">
        /// The Schema Name of the Entity Relationship to use to disassociate the records.
        /// To disassociate account records as a Parent account, use "Referencedaccount_parent_account"
        /// </param>
        ///<param name="childId" type="String">
        /// The Id of the record to be disassociated as the child record in the relationship
        /// </param>
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// Nothing will be returned to this function.
        /// </param>
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._stringParameterCheck(parentType, "SDKAPI.REST.disassociateRecords requires the parentType parameter is a string.");
        this._stringParameterCheck(relationshipName, "SDKAPI.REST.disassociateRecords requires the relationshipName parameter is a string.");
        this._stringParameterCheck(childId, "SDKAPI.REST.disassociateRecords requires the childId parameter is a string.");
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.disassociateRecords requires the successCallback parameter is a function.");
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.disassociateRecords requires the errorCallback parameter is a function.");

        var req = new XMLHttpRequest();
        req.open("POST", encodeURI(this._ODataPath() + parentType + "(" + parentId + ")/" + relationshipName + "(" + childId + ")/$ref"), true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("X-HTTP-Method", "DELETE");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                req.onreadystatechange = null;
                if (this.status == 204 || this.status == 1223) {
                    successCallback();
                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();
    },
      fetchMore: function(originalFetchXML,type,successCallback, errorCallback){
        ///<summary>
        /// Sends an asynchronous request to retrieve records using fetchXML.
        ///</summary>
        ///<param name="originalFetchXML" type="String">
        /// A String representing the FetchXml expression
        ///</param>
        this._stringParameterCheck(originalFetchXML, "SDKAPI.REST.fetchMore requires the originalFetchXML parameter is a string.");
        ///<param name="type" type="String">
        /// The Schema Name of the Entity type record to retrieve.
        /// For an Account record, use "Account"
        ///</param>
        this._stringParameterCheck(type, "SDKAPI.REST.fetchMore requires the type parameter is a string.");
     
        ///<param name="successCallback" type="Function">
        /// The function that will be passed through and be called by a successful response. 
        /// This function must accept the returned record as a parameter.
        /// </param>
        this._callbackParameterCheck(successCallback, "SDKAPI.REST.fetchMore requires the successCallback parameter is a function.");
        ///<param name="errorCallback" type="Function">
        /// The function that will be passed through and be called by a failed response. 
        /// This function must accept an Error object as a parameter.
        /// </param>
        this._callbackParameterCheck(errorCallback, "SDKAPI.REST.fetchMore requires the errorCallback parameter is a function.");

        var systemQueryOptions = "";

      


        var req = new XMLHttpRequest();
        req.open("GET", this._ODataPath() + type + "?fetchXml=" + originalFetchXML, true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Prefer", "odata.include-annotations=*");
        req.onreadystatechange = function () {
            if (this.readyState == 4 /* complete */) {
                if (this.status == 200) {
               
                    //var data = this.response != undefined ? this.response : this.responseText;
                    ////successCallback(JSON.parse(this.responseText, SDKAPI.REST._dateReviver).d);
                    //var resultData = JSON.parse(JSON.stringify(data), SDKAPI.REST._dateReviver)
                    //successCallback(resultData);
                     var data = this.response != undefined ? this.response : this.responseText;
                    ////successCallback(JSON.parse(this.responseText, SDKAPI.REST._dateReviver).d);
                    var results = JSON.parse(JSON.stringify(JSON.parse(JSON.stringify(data))))
                    //var returned = JSON.parse(this.responseText, SDKAPI.REST._dateReviver).d;
                       var returned = JSON.parse(results, SDKAPI.REST._dateReviver);
                    successCallback(returned);

                }
                else {
                    errorCallback(SDKAPI.REST._errorHandler(this));
                }
            }
        };
        req.send();
    },
    __namespace: true
};