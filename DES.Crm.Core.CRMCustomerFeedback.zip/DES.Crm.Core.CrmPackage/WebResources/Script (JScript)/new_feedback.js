var FeedbackId = "";
//Getting Query String From URL
var Parameter = ParseQueryString(GetGlobalContext().getQueryStringParameters()["Data"]);
// Getter
var onSet = $("#rateYo").rateYo("option", "onSet"); //returns the function
// Setter
$("#rateYo").rateYo("option", "onSet", function () {
}); //returns a jQuery Element


$(function () {
    $("#rateYo").rateYo({
        onSet: function (rating, rateYoInstance) {
            //Set Rating value in a hidden variable.
            $("#hdnRating").val(rating);
        }
    });

    //Retriving Feedback records and get ID of exisiting record.
    RetriveFeedback();
    $("#btnSubmit").click(function () {
        /*if ($("#txtTitle").val().trim() == "") {
            Xrm.Utility.alertDialog("Please enter title.", function () { return false; });
        }
        else*/ if ($("#txtComment").val().trim() == "") {
            Xrm.Utility.alertDialog("Please enter comment.", function () { return false; });
        }
        else {
            //Create and Update Feedback records
            CreateFeedback();
        }

    });
    $("#btnCancel").click(function () {
        CloseWindow();
    });

});
function CreateFeedback() {

    var feedback = {};
    //feedback.title = $("#txtTitle").val();
	feedback.title = Parameter.casename;
    feedback.minrating = 0;
    feedback.comments = $("#txtComment").val();
    feedback["regardingobjectid_incident@odata.bind"] = "/incidents(" + Parameter.caseid.replace(/{|}/g, '') + ")";
    feedback.maxrating = 5;
	feedback.new_customrating = parseFloat($("#hdnRating").val()).toFixed(1); // Custom rating field accept float number
    //feedback.rating = Math.round($("#hdnRating").val());

    if (FeedbackId == null || FeedbackId == "") {
        //Create feedback
        SDKAPI.REST.createRecord(feedback, "feedback", function (result) {
            if (result != null) {
                Xrm.Utility.alertDialog("Record has been created successfully.", function () { CloseWindow(); });
            }

        },
        function (re) {
            Xrm.Utility.alertDialog("Server not respond. Please contact to administrator.",
                function () { CloseWindow(); });
        });
    }
    else {
        //update feedback
        SDKAPI.REST.updateRecord(
   FeedbackId.replace(/{|}/g, ''),
   feedback,
   "feedback",
   function () {
       Xrm.Utility.alertDialog("Record has been updated successfully.", function () { CloseWindow(); });
   },
   function () {
       Xrm.Utility.alertDialog("Server not respond. Please contact to administrator.",
       function () { CloseWindow(); });
   });
    }
}

function RetriveFeedback() {
    if (Parameter.caseid) {
        SDKAPI.REST.retrieveMultipleRecords("feedback",
                             "$filter=_regardingobjectid_value eq " + Parameter.caseid + "",
                             function (results) {
                                 results = results.value;
                                 $.each(results, function (i, item) {
                                     FeedbackId = item.feedbackid;
                                 });

                             }, function () { }, function () { });
    }
}
function ParseQueryString(query) {
    var result = {};

    if (typeof query == "undefined" || query == null) {
        return result;
    }

    var queryparts = query.split("&");
    for (var i = 0; i < queryparts.length; i++) {
        var params = queryparts[i].split("=");
        result[params[0]] = params.length > 1 ? params[1] : null;
    }
    return result;
}


function CloseWindow() {
this.parent.window.document.contentIFrame0.Xrm.Page.getControl("feedback").refresh();
    parent.$(".ui-dialog-content").dialog("close");

}

