﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.CRM.Core.GlobalNotifications.Workflows
{
    public sealed class UpsertNotificationRecepients : CodeActivity
    {
        [Input("Notification")]
        [ReferenceTarget("rbs_notification")]
        [RequiredArgument]
        public InArgument<EntityReference> notification { get; set; }
        [Input("Notification Recepient")]
        [ReferenceTarget("systemuser")]
        [RequiredArgument]
        public InArgument<EntityReference> User { get; set; }
        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            if (notification != null && notification.Get<EntityReference>(executionContext) != null && notification.Get<EntityReference>(executionContext).Id != Guid.Empty)
            {
                QueryExpression queryRecepient = new QueryExpression("rbs_notificationrecipient");
                queryRecepient.NoLock = true;
                queryRecepient.ColumnSet = new ColumnSet("rbs_user");
                queryRecepient.Criteria.AddCondition(new ConditionExpression("rbs_user", ConditionOperator.Equal, User.Get<EntityReference>(executionContext).Id));
                queryRecepient.Criteria.AddCondition(new ConditionExpression("rbs_notification", ConditionOperator.Equal, notification.Get<EntityReference>(executionContext).Id));
                queryRecepient.Criteria.AddCondition(new ConditionExpression("rbs_lastacknowledgedon", ConditionOperator.Null));
                try
                {
                    EntityCollection RecepientCollection = service.RetrieveMultiple(queryRecepient);
                    Entity entityRecepient = new Entity("rbs_notificationrecipient");
                    entityRecepient["rbs_lastacknowledgedon"] = DateTime.UtcNow;
                    if (RecepientCollection != null && RecepientCollection.Entities != null && RecepientCollection.Entities.Count > 0)
                    {
                        //update acknowledged date 
                        entityRecepient["rbs_notificationrecipientid"] = RecepientCollection.Entities.FirstOrDefault().Id;
                        service.Update(entityRecepient);
                    }
                    else
                    {
                        entityRecepient["rbs_user"] = User.Get<EntityReference>(executionContext);
                        entityRecepient["rbs_notification"] = notification.Get<EntityReference>(executionContext);
                        entityRecepient["rbs_recipienttype"] = new OptionSetValue(859770000);
                        service.Create(entityRecepient);
                    }
                }
                catch (Exception ex)
                {
                    tracingService.Trace(ex.Message);
                }
            }
            else
                tracingService.Trace("recepient id is null");
        }
    }
}
