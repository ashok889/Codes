﻿using DES.Crm.Core.Common.Security;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.RenameRootBU
{
    class Program
    {
        static void Main(string[] args)
        {
            Connection conn = new Connection();
            var crmSvc = conn.GetConnection_SOAP();

            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='businessunit'>                                
                                <attribute name='businessunitid' />
                                <filter type='and'>
                                    <condition attribute='parentbusinessunitid' operator='null' />
                                </filter>
                                </entity>
                            </fetch>";

            EntityCollection enBUs = crmSvc.RetrieveMultiple(new FetchExpression(sFetch));

            if(enBUs != null && enBUs.Entities != null && enBUs.Entities.Count > 0)
            {
                Entity enBUToUpdate = new Entity(enBUs.Entities[0].LogicalName);
                enBUToUpdate.Id = enBUs.Entities[0].Id;
                enBUToUpdate.Attributes["name"] = ConfigurationManager.AppSettings["RootBUName"];

                crmSvc.Update(enBUToUpdate);
            }
        }
    }

    class Connection
    {
        bool IsServiceConnectionActive = false;

        #region "Connection Creation"
        CrmServiceClient crmSvcClient = null;

        public CrmServiceClient GetConnection_SOAP()
        {
            if (crmSvcClient != null && IsServiceConnectionActive)
            {
                return crmSvcClient;
            }
            else
            {
                CreateConnection_SOAP();
                return crmSvcClient;
            }
        }
        private CrmServiceClient CreateConnection_SOAP()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            crmSvcClient = new CrmServiceClient(
                                    crmUserId: ConfigurationManager.AppSettings["Username"],                                    
                                    crmPassword: CrmServiceClient.MakeSecureString(DataProtect.DecryptString(ConfigurationManager.AppSettings["Password"])),
                                    crmRegion: ConfigurationManager.AppSettings["Region"],
                                    orgName: ConfigurationManager.AppSettings["OrgName"],
                                    isOffice365: true);
            crmSvcClient.OrganizationServiceProxy.ServiceChannel.ChannelClosed += ServiceChannel_ChannelClosed;
            crmSvcClient.OrganizationServiceProxy.ServiceChannel.ChannelFaulted += ServiceChannel_ChannelFaulted;
            IsServiceConnectionActive = true;
            var whoAmI = (WhoAmIResponse)crmSvcClient.Execute(new WhoAmIRequest());
            return crmSvcClient;
        }
        private void ServiceChannel_ChannelFaulted(object sender, Microsoft.Xrm.Sdk.Client.ChannelFaultedEventArgs e)
        {
            IsServiceConnectionActive = false;
        }
        private void ServiceChannel_ChannelClosed(object sender, Microsoft.Xrm.Sdk.Client.ChannelEventArgs e)
        {
            IsServiceConnectionActive = false;
        }
        #endregion
    }
}
