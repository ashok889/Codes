﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class RemoveMembersTeamRequestExecutor: IFakeMessageExecutor
    {

        public bool CanExecute(OrganizationRequest request)
        {
            return request is RemoveMembersTeamRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var removeMembersTeamRequest = (RemoveMembersTeamRequest)request;

            var teamId = removeMembersTeamRequest.TeamId;
            var memberIds = removeMembersTeamRequest.MemberIds;

            if (teamId == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Please provide team from which user is to be be removed.");
            }

            if (memberIds == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Please provide at least one member id to be removed from team.");
            }

            var service = ctx.GetOrganizationService();

            if (ctx.GetRelationship("teammembership_association") == null)
            {
                ctx.AddRelationship("teammembership_association", new XrmFakedRelationship
                {
                    IntersectEntity = "teammembership",
                    Entity1LogicalName = "systemuser",
                    Entity1Attribute = "systemuserid",
                    Entity2LogicalName = "team",
                    Entity2Attribute = "teamid"
                });
            }

            foreach (Guid memberId in memberIds)
            {
                service.Disassociate("systemuser", memberId, new Relationship("teammembership_association"), new EntityReferenceCollection { new EntityReference("team", teamId) });
            }

            return new RemoveMembersTeamResponse()
            {
                ResponseName = "RemoveMembersTeam"
            };
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(RemoveMembersTeamRequest);
        }
    }
}
