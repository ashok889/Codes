﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class RetrieveAllEntitiesRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is RetrieveAllEntitiesRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var retrieveAllEntitiesRequest = (RetrieveAllEntitiesRequest)request;

            if (retrieveAllEntitiesRequest.EntityFilters == Microsoft.Xrm.Sdk.Metadata.EntityFilters.Entity)
            {
                EntityMetadataCollection entityMetaDataCollection = new EntityMetadataCollection();

                foreach (Entity en in ctx.Data.Values.SelectMany(s => s.Values))
                {
                    if (en.Attributes.Contains("entityname"))
                    {
                        EntityMetadata enMetadata = new EntityMetadata();
                        enMetadata.DisplayName = new Label(en["entityname"].ToString(), 1033);
                        enMetadata.LogicalName = en.LogicalName;
                        entityMetaDataCollection.Add(enMetadata);
                    }
                }

                if(entityMetaDataCollection.Count == 0)
                {
                    throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Please specify 'entityname' for the relevant entity.");
                }

                return new RetrieveAllEntitiesResponse()
                {
                    ResponseName = "RetrieveAllEntitiesResponse",
                    Results = new ParameterCollection { { "EntityMetadata", entityMetaDataCollection .ToArray()} }
                };
            }
            else
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Only supports EntityFilters = Entity for 'RetrieveAllEntitiesRequest' ");
            }
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(RetrieveAllEntitiesRequest);
        }
    }
}
