﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    class GetTrackingTokenEmailRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is GetTrackingTokenEmailRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var trackingToken = "";
            var getTrackingTokenEmailRequest = (GetTrackingTokenEmailRequest)request;

            var subject = getTrackingTokenEmailRequest.Subject;
            var service = ctx.GetOrganizationService();

            if(!string.IsNullOrEmpty(subject))
            {
                trackingToken = ctx.CreateQuery<Entity>()
                                    .Where(w => w["subject"].ToString().Trim().Equals(subject.Trim()))
                                    .Select(s => s["trackingtoken"])
                                    .FirstOrDefault().ToString();
            }
            else
            {
                trackingToken = "CRM:010101";
            }            

            return new GetTrackingTokenEmailResponse()
            {
                ResponseName = "GetTrackingTokenEmail",
                Results = new ParameterCollection { { "TrackingToken", trackingToken } }
            };
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(GetTrackingTokenEmailRequest);
        }
    }
}
