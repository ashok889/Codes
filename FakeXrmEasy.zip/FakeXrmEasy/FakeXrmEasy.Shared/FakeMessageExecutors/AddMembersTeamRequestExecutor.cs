﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class AddMembersTeamRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is AddMembersTeamRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var addMembersTeamRequest = (AddMembersTeamRequest)request;

            var teamId = addMembersTeamRequest.TeamId;
            var memberIds = addMembersTeamRequest.MemberIds;

            if (teamId == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Please provide team to which user is to be be added.");
            }

            if (memberIds == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Please provide at least one member id to be added to team.");
            }

            var service = ctx.GetOrganizationService();

            if (ctx.GetRelationship("teammembership_association") == null)
            {
                ctx.AddRelationship("teammembership_association", new XrmFakedRelationship
                {
                    IntersectEntity = "teammembership",
                    Entity1LogicalName = "systemuser",
                    Entity1Attribute = "systemuserid",
                    Entity2LogicalName = "team",
                    Entity2Attribute = "teamid"
                });
            }

            foreach (Guid memberId in memberIds)
            {
                service.Associate("systemuser", memberId, new Relationship("teammembership_association"), new EntityReferenceCollection { new EntityReference("team", teamId) });
            }

            return new AddMembersTeamResponse()
            {
                ResponseName = "AddMembersTeam"                
            };
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(AddMembersTeamRequest);
        }

    }
}
