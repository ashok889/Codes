﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class RetrieveActivePathRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is RetrieveActivePathRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var retrieveActivePathRequest = (RetrieveActivePathRequest)request;

            if (retrieveActivePathRequest.ProcessInstanceId == null || retrieveActivePathRequest.ProcessInstanceId == Guid.Empty)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not retrieve active path without process instance id");
            }

            if (ctx.Data.Values.Any(w => w.Values.Where(e => e.Id.Equals(retrieveActivePathRequest.ProcessInstanceId) && ((OptionSetValue)e.Attributes["statecode"]).Value == 0).Count() > 0))
            {
                var processStages = new EntityCollection();

                foreach (var bpfEntityColl in ctx.Data.Values.Where(w => w.Values.Where(e => e.Id.Equals(retrieveActivePathRequest.ProcessInstanceId) && ((OptionSetValue)e.Attributes["statecode"]).Value == 0).Count() > 0))
                {
                    foreach (var bpfEntity in bpfEntityColl.Values)
                    {
                        if (ctx.Data.Values.Any(w => w.Values.Where(e => e.Id.Equals(((EntityReference)bpfEntity.Attributes["activestageid"]).Id) && ((OptionSetValue)e.Attributes["statecode"]).Value == 0).Count() > 0))
                        {
                            foreach (var processStage in ctx.Data.Values.Where(w => w.Values.Where(e => e.Id.Equals(((EntityReference)bpfEntity.Attributes["activestageid"]).Id) && ((OptionSetValue)e.Attributes["statecode"]).Value == 0).Count() > 0))
                            {
                                processStages.Entities.AddRange(processStage.Values);
                            }
                        }
                        else
                        {
                            throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not retrieve active process stage for the process instance id - " + retrieveActivePathRequest.ProcessInstanceId);
                        }
                    }
                }

                return new RetrieveActivePathResponse()
                {
                    ResponseName = "RetrieveActivePathResponse",
                    Results = new ParameterCollection { { "ProcessStages", processStages } }
                };
            }
            else
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not retrieve active process instance id - " + retrieveActivePathRequest.ProcessInstanceId);
            }
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(RetrieveActivePathRequest);
        }
    }
}
