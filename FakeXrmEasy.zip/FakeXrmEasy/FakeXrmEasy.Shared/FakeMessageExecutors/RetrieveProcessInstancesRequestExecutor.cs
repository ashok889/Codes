﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class RetrieveProcessInstancesRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is RetrieveProcessInstancesRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var retrieveProcessInstancesRequest = (RetrieveProcessInstancesRequest)request;

            if (string.IsNullOrEmpty(retrieveProcessInstancesRequest.EntityLogicalName))
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not retrieve process instance without entity logical name");
            }

            if (retrieveProcessInstancesRequest.EntityId == null || retrieveProcessInstancesRequest.EntityId == Guid.Empty)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not retrieve process instance without entity id");
            }

            var entityRef = new EntityReference(retrieveProcessInstancesRequest.EntityLogicalName, retrieveProcessInstancesRequest.EntityId);

            var bpfAttributeName = "bpf_" + entityRef.LogicalName + "id";

            if (ctx.Data.Values.Any(w => w.Values.Where(e => e.Attributes.Contains(bpfAttributeName) && ((OptionSetValue)e.Attributes["statecode"]).Value == 0).Count() > 0))
            {
                var processes = new EntityCollection();

                foreach (var bpfEntityColl in ctx.Data.Values.Where(w => w.Values.Where(e => e.Attributes.Contains(bpfAttributeName) && ((OptionSetValue)e.Attributes["statecode"]).Value == 0).Count() > 0))
                {
                    foreach (Entity en in bpfEntityColl.Values)
                    {
                        Entity enBPFInstance = new Entity("businessprocessflowinstance");
                        enBPFInstance.Id = en.Id;
                        enBPFInstance["name"] = en["name"];
                        enBPFInstance["processstageid"] = en["processstageid"];
                        enBPFInstance["processid"] = en["processid"];

                        processes.Entities.Add(en);
                    }
                }

                return new RetrieveProcessInstancesResponse()
                {
                    ResponseName = "RetrieveProcessInstancesResponse",                    
                    Results = new ParameterCollection { { "Processes", processes } }
                };
            }
            else
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not retrieve active process for the entity - " + entityRef.LogicalName);
            }
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(RetrieveProcessInstancesRequest);
        }
    }
}
