﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class InstantiateTemplateRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is InstantiateTemplateRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var instantiateTemplateRequest = (InstantiateTemplateRequest)request;
            var entityCol = new EntityCollection();

            var templateId = instantiateTemplateRequest.TemplateId;
            var objectId = instantiateTemplateRequest.ObjectId;
            var entityLogicalName = instantiateTemplateRequest.ObjectType;

            if (templateId == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not instantiate template without TemplateId");
            }

            if (objectId == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not instantiate template without ObjectId");
            }

            if (entityLogicalName == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not instantiate template without ObjectType");
            }

            var emailBody = ctx.CreateQuery("template")
                            .Where(w => w.Id == templateId)
                            .Select(s => s.Attributes["body"]).FirstOrDefault();

            var prepareEmail = new Entity
            {
                LogicalName = "email",
                Attributes = new AttributeCollection
                {
                    { "regardingobjectid", new EntityReference(entityLogicalName , objectId) },
                    { "description", emailBody }
                }
            };

            entityCol.Entities.Add(prepareEmail);

            return new InstantiateTemplateResponse()
            {
                ResponseName = "InstantiateTemplate",
                Results = new ParameterCollection { { "EntityCollection", entityCol } }
            };
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(InstantiateTemplateRequest);
        }
    }
}
