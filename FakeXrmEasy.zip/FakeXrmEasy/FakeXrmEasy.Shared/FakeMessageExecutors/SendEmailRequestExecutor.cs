﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace FakeXrmEasy.FakeMessageExecutors
{
    public class SendEmailRequestExecutor : IFakeMessageExecutor
    {
        public bool CanExecute(OrganizationRequest request)
        {
            return request is SendEmailRequest;
        }

        public OrganizationResponse Execute(OrganizationRequest request, XrmFakedContext ctx)
        {
            var sendEmailRequest = (SendEmailRequest)request;

            Guid emailId = sendEmailRequest.EmailId;
            bool issueSend = sendEmailRequest.IssueSend;
            string trackingToken = sendEmailRequest.TrackingToken;

            if (emailId == null)
            {
                throw new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Can not send email without specified emailid");
            }

            var service = ctx.GetOrganizationService();

            Entity enEmail = service.Retrieve("email", emailId, new ColumnSet(new string[] { "subject" } ));

            //update entity status.
            SetStateRequest setState = new SetStateRequest();
            setState.EntityMoniker = enEmail.ToEntityReference();
            setState.State = new OptionSetValue(1); //Completed

            if (issueSend)
            {
                setState.Status = new OptionSetValue(6); //Pending Send
            }
            else
            {
                setState.Status = new OptionSetValue(3); //Sent
            }

            service.Execute(setState);

            return new SendEmailResponse()
            {
                ResponseName = "SendEmail",
                Results = new ParameterCollection { { "Subject", enEmail.Attributes.Contains("subject") ? enEmail.Attributes["subject"].ToString() : string.Empty } }
            };
        }

        public Type GetResponsibleRequestType()
        {
            return typeof(SendEmailRequest);
        }
    }
}
