﻿namespace FakeXrmEasy
{
    public enum ProcessingStepStage
    {
        Prevalidation = 10,

        Preoperation = 20,

        Postoperation = 40
    }
}