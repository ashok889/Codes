﻿namespace FakeXrmEasy
{
    public enum ProcessingStepMode
    {
        Synchronous = 0,

        Asynchronous = 1
    }
}