﻿namespace FakeXrmEasy
{
    public enum ProcessingStepImageType
    {
        PreImage = 0,

        PostImage = 1,

        Both = 2
    }
}
