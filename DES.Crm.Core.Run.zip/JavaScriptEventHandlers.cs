﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Run
{
    public class JavaScriptEventHandlers
    {
        public bool IsEventEnabled { get; set; }
        public string FormName { get; set; }
        public string EventName { get; set; }
        public string LibraryName { get; set; }
        public string FunctionName { get; set; }
        public string AttributeName { get; set; }
    }
}
