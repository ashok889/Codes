﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Run
{
    public interface IRetrieveSendEmailArgs<T>
    {
        SendEmailArgs GetArgs(T obj);
    }
}
