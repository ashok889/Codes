﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Run
{
   public  class TeamExtension
    {
    }
    public class BURoleMapping
    {
        public Guid BUId { get; set; }
        public Guid RoleId { get; set; }
        public String RoleName { get; set; }
    }
    public class RolesAssign
    {
        public string RoleName { get; set; }
        public Guid RoleId { get; set; }
        public Guid EntityId { get; set; }
        public Guid EntityBuId { get; set; }
        public string Name { get; set; }
        public string Flag { get; set; }
    }
    public class UserPositionMapping
    {
        public string PositionName { get; set; }
        public string UserName { get; set; }
        public EntityReference Postion { get; set; }
        public EntityReference User { get; set; }
        public Boolean IsMainPosition { get; set; }
        public string Action { get; set; }
        public EntityReference CurrentMainPosition { get; set; }

    }

    public class RemovePositionMapping
    {

        public EntityReference Postion { get; set; }
        public EntityReference User { get; set; }
        public Guid UserPosition { get; set; }
        public string PositionName { get; set; }
        public string UserName { get; set; }
    }

    public class UserPositionLog
    {
        public string PositionName { get; set; }
        public string UserName { get; set; }
        public Boolean IsMainPosition { get; set; }
        public string Action { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }

    }
    class Position
    {
        public bool hasPositionId { get; set; }
        public bool hasUserPositionId { get; set; }

    }
}
