﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Run
{
    public class DefaultSendSmtpEmail : ISendEmail
    {
        ILog _Logger;

        string Host;
        public DefaultSendSmtpEmail(
            string host,
            ILog logger)
        {
            _Logger = logger;
            Host = host;
        }

        public SmtpStatusCode SendEmail(SendEmailArgs args)
        {
            var codeToReturn = SmtpStatusCode.Ok;
            try
            {
                using (var emailClient = new SmtpClient(Host))
                {
                    var mailMessage = CreateEmailMessage(args.From, args.To, args.CC, args.BCC, args.Subject, args.Body);
                    emailClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    if (args.EmailAttachments != null && args.EmailAttachments.Count > 0)
                    {
                        foreach (var item in args.EmailAttachments)
                        {
                            if (item.Bytes != null && item.Bytes.Count() > 0)
                            {
                                MemoryStream stream = new MemoryStream(item.Bytes);
                                Attachment mailattachment = new Attachment(stream, item.FileName, item.MimeType);
                                mailMessage.Attachments.Add(mailattachment);
                            }
                        }
                    }
                    emailClient.Send(mailMessage);
                }
            }
            catch (SmtpException exc)
            {
                _Logger.Error(exc);
                codeToReturn = exc.StatusCode;
            }
            catch (Exception exc)
            {
                _Logger.Error(exc);
                throw exc;
            }

            return codeToReturn;
        }

        private MailMessage CreateEmailMessage(
            string From, 
            string To, 
            string Cc, 
            string Bcc, 
            string Subject, 
            string Body)
        {
            var message = new MailMessage();
            int BracketPos = 0; string eMailAddress = "", DisplayName = "";
            BracketPos = From.IndexOf("[");
            if (BracketPos > 0)
            {
                eMailAddress = From.Substring(BracketPos + 1, From.Length - BracketPos - 2);
                DisplayName = From.Substring(0, BracketPos);
                message.From = new MailAddress(eMailAddress, DisplayName);
            }
            else
                message.From = new MailAddress(From, From);

            BracketPos = To.IndexOf("[");
            if (BracketPos > 0)
            {
                eMailAddress = To.Substring(BracketPos + 1, To.Length - BracketPos - 2);
                DisplayName = To.Substring(0, BracketPos);
                message.To.Add(new MailAddress(eMailAddress, DisplayName));
            }
            else
            {
                foreach (var address in To.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                {
                    message.To.Add(new MailAddress(address, address));
                }
            }

            if (!string.IsNullOrEmpty(Cc))
            {
                BracketPos = Cc.IndexOf("[");
                if (BracketPos > 0)
                {
                    eMailAddress = Cc.Substring(BracketPos + 1, Cc.Length - BracketPos - 2);
                    DisplayName = Cc.Substring(0, BracketPos);
                    message.CC.Add(new MailAddress(eMailAddress, DisplayName));
                }
                else
                {
                    foreach (var address in Cc.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        message.CC.Add(new MailAddress(address, address));
                    }
                }
            }

            if (!string.IsNullOrEmpty(Bcc))
            {
                BracketPos = Bcc.IndexOf("[");
                if (BracketPos > 0)
                {
                    eMailAddress = Bcc.Substring(BracketPos + 1, Bcc.Length - BracketPos - 2);
                    DisplayName = Bcc.Substring(0, BracketPos);
                    message.Bcc.Add(new MailAddress(eMailAddress, DisplayName));
                }
                else
                {
                    foreach (var address in Bcc.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        message.Bcc.Add(new MailAddress(address, address));
                    }
                }
            }

            message.Subject = Subject;
            message.Body = Body;
            message.IsBodyHtml = true;

            return message;
        }
    }
}
