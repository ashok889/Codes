﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

namespace DES.Crm.Core.Run.Test
{
    public static class ResourceHelper
    {
        public static string RetrieveTextFile(string resourceName)
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                var streamReader = new StreamReader(assembly.GetManifestResourceStream(string.Format("DES.Crm.Core.Run.Test.Documents.{0}", resourceName)));
                return streamReader.ReadToEnd();
            }
            catch
            {
                throw;                
            }
        }
    }
}
