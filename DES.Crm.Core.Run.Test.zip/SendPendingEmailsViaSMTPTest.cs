﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Shouldly;
using FakeXrmEasy;
using Moq;
using Microsoft.Xrm.Sdk;
using log4net.Core;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using System.Net.Mail;
using FakeXrmEasy.FakeMessageExecutors;
using Microsoft.Crm.Sdk.Messages;
using System.Reflection;
using System.Xml.Linq;

namespace DES.Crm.Core.Run.Test
{
    public class SendPendingEmailsViaSMTPTest
    {
        [Fact]
        public void GivenAnEmailActivityInPendingStateEnsureTheyAreSentAndEmailAndContactUpdated()
        {
            var context = new XrmFakedContext();
            var service = context.GetOrganizationService();
            var xDocument = XDocument.Parse(ResourceHelper.RetrieveTextFile("TestConfigXml.xml"));
            context.AddFakeMessageExecutor<SetStateRequest>(new SetStateRequestExecutor());
            var mockedEmailer = new Mock<ISendEmail>();
            var mockedLogger = new Mock<ILog>();
            var mockedEmailArgsRetriever = new Mock<IRetrieveSendEmailArgs<Entity>>();
            var emailActivityId = Guid.NewGuid();

            mockedEmailer.Setup(x => x.SendEmail(It.IsAny<SendEmailArgs>()))
                .Returns(System.Net.Mail.SmtpStatusCode.Ok);

            mockedEmailArgsRetriever.Setup(x => x.GetArgs(It.IsAny<Entity>()))
                .Returns(new SendEmailArgs() {
                    To = "ToEmail@email1.com",
                    From = "FromEmail@email1.com",
                    Body = "This is the test body to use regards",
                    Subject = "Test Subject"
                });

            var sendEmailObj = new SendPendingEmailsViaSMTP(service, mockedEmailer.Object, mockedLogger.Object, mockedEmailArgsRetriever.Object, xDocument);
            var contactTo = service.Create(ObjectFactory.CreateContact(null, "firstTo", "lastTo", "ToEmail@email1.com", null, null));
            var contactFrom = service.Create(ObjectFactory.CreateContact(null, "firstFrom", "lastFrom", "FromEmail@email1.com", null, null));
            var contactRegarding = service.Create(ObjectFactory.CreateContact(null, "firstRegarding", "lastRegarding", "RegardingEmail@email1.com", null, null));

            var emailToRetrieve = ObjectFactory.CreateEmailEntity(
                null,
                new EntityReference("contact", contactTo),
                new EntityReference("contact", contactFrom),
                new EntityReference("contact", contactRegarding),
                "Test Subject",
                "This is the test body to use regards",
                null,//new OptionSetValue(1),
                null,
                true); //new OptionSetValue(6));

            emailActivityId = service.Create(emailToRetrieve);
            var response = service.Execute(new SetStateRequest() { EntityMoniker = new EntityReference() { LogicalName = "email", Id = emailActivityId }, State = new OptionSetValue(1), Status = new OptionSetValue(6) });

            sendEmailObj.Run();

            // verify this emailer was called
            mockedEmailer.Verify();

            // verify that the logger error was not called
            mockedLogger.Verify(m => m.Error(It.IsAny<Exception>()), Times.Never());

            // check the results
            var retrievedActivity = context.CreateQuery("email").FirstOrDefault();
            retrievedActivity.GetAttributeValue<OptionSetValue>("statecode").Value.ShouldBe(1);
            retrievedActivity.GetAttributeValue<OptionSetValue>("statuscode").Value.ShouldBe(3);

            var contact = service.Retrieve("contact", contactTo, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));
        }

        [Theory]
        [InlineData(SmtpStatusCode.GeneralFailure)]
        [InlineData(SmtpStatusCode.BadCommandSequence)]
        [InlineData(SmtpStatusCode.CannotVerifyUserWillAttemptDelivery)]
        [InlineData(SmtpStatusCode.ClientNotPermitted)]
        public void GivenAnEmailActivitySetStatusFailedOnContactAndEmailActivityIfIssuesWithSmtp(SmtpStatusCode code)
        {
            var xDocument = XDocument.Parse(ResourceHelper.RetrieveTextFile("TestConfigNoUseSubCategory.xml"));
            var context = new XrmFakedContext();
            var service = context.GetOrganizationService();
            var mockedEmailer = new Mock<ISendEmail>();
            var mockedEmailArgsRetriever = new Mock<IRetrieveSendEmailArgs<Entity>>();
            var mockedLogger = new Mock<ILog>();
            var emailActivityId = Guid.NewGuid();

            // Add set state request
            context.AddFakeMessageExecutor<SetStateRequest>(new SetStateRequestExecutor());
            // setup mocked emailer
            mockedEmailer.Setup(x => x.SendEmail(It.IsAny<SendEmailArgs>())).Returns(code);

            // var contacts
            Guid contact1 = Guid.NewGuid();
            Guid contact2 = Guid.NewGuid();
            Guid contact3 = Guid.NewGuid();
            Guid contact4 = Guid.NewGuid();

            List<Guid> addGuids = new List<Guid>() { contact1, contact2, contact3, contact4 };

            Random rand = new Random();
            foreach (Guid guid in addGuids)
            {
                var createdContact = ObjectFactory.CreateContact(guid,
                    string.Format("firstName{0}", rand.Next()),
                    string.Format("lastName{0}", rand.Next()),
                    string.Format("test{0}@email.com", rand.Next()),
                    null, //new OptionSetValue(0),
                    null); //new OptionSetValue(1));

                service.Create(createdContact);
            }

            var sendEmailObj = new SendPendingEmailsViaSMTP(service, mockedEmailer.Object, mockedLogger.Object, mockedEmailArgsRetriever.Object, xDocument);

            var emailToRetrieve = ObjectFactory.CreateEmailEntity(
                null,
                new EntityReference("contact", contact1),
                new EntityReference("contact", contact2),
                new EntityReference("contact", contact3),
                "Test Subject",
                "This is the test body to use regards",
                null,//new OptionSetValue(1),
                null,
                false); //new OptionSetValue(6));

            emailActivityId = service.Create(emailToRetrieve);
            var response = service.Execute(new SetStateRequest() { EntityMoniker = new EntityReference() { LogicalName = "email", Id = emailActivityId }, State = new OptionSetValue(1), Status = new OptionSetValue(6) });

            sendEmailObj.Run();

            // verify this emailer was called
            mockedEmailer.Verify();

            // check the results
            var retrievedActivity = service.Retrieve("email", emailActivityId, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));
            retrievedActivity.GetAttributeValue<OptionSetValue>("statuscode").Value.ShouldBe(8);
            retrievedActivity.GetAttributeValue<OptionSetValue>("statecode").Value.ShouldBe(0);

            var contact = service.Retrieve("contact", contact1, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));
        }    
    }
}
