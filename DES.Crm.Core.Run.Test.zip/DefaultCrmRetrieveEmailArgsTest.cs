﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xunit;
using Microsoft.Xrm.Sdk;
using FakeXrmEasy;
using Moq;
using Microsoft.Crm.Sdk.Messages;
using Shouldly;
using System.Xml.Linq;

namespace DES.Crm.Core.Run.Test
{
    /// <summary>
    /// Summary description for DefaultCrmRetrieveEmailArgsTest
    /// </summary>    
    public class DefaultCrmRetrieveEmailArgsTest
    {

        [Fact]
        public void SuccessfullyRetrieveEmailArgsFromQueue()
        {
            var xDocument = XDocument.Parse(ResourceHelper.RetrieveTextFile("TestConfigXml.xml"));
            var context = new XrmFakedContext();
            var service = context.GetOrganizationService();
            var mockedLogger = new Mock<ILog>();
            var retrieveEmailArgs = new DefaultCrmRetrieveEmailArgs(service, mockedLogger.Object, xDocument);

            Entity queueFrom = new Entity("queue");
            queueFrom["emailaddress"] = "testQueue@email.com";
            queueFrom["name"] = "TestQueueName";
            queueFrom["queueviewtype"] = new OptionSetValue(0);
            queueFrom["incomingemailfilteringmethod"] = new OptionSetValue(0);

            var queueFromId = service.Create(queueFrom);

            var createdContact = ObjectFactory.CreateContact(null,
                "FirstName",
                "LastName",
                "testToEmail@email.com",
                null, //new OptionSetValue(0),
                null); //new OptionSetValue(1));

            Guid contact1 = service.Create(createdContact);

            var emailToRetrieve = ObjectFactory.CreateEmailEntity(
               null,
               new EntityReference("contact", contact1),
               new EntityReference("queue", queueFromId),
               new EntityReference("contact", contact1),
               "Test Subject",
               "This is the test body to use regards",
               null,//new OptionSetValue(1),
               null,
               true); //new OptionSetValue(6));

            var emailActivityId = service.Create(emailToRetrieve);

            var retrievedArgs = retrieveEmailArgs.GetArgs(emailToRetrieve);

            mockedLogger.Verify(m => m.Error(It.IsAny<Exception>()), Times.Never());

            retrievedArgs.ShouldNotBeNull();
            retrievedArgs.From.ShouldBe("testQueue@email.com");
            retrievedArgs.To.ShouldBe("testToEmail@email.com");
            retrievedArgs.Subject.ShouldBe("Test Subject");
            retrievedArgs.Body.ShouldBe("This is the test body to use regards");
        }
    }
}
