﻿using FakeXrmEasy;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Run.Test
{
    class ObjectFactory
    {
        public static Entity CreateEmailEntity(
            Guid? Id,
            EntityReference to,
            EntityReference from, 
            EntityReference regarding,
            string subject,
            string body,
            OptionSetValue status,
            OptionSetValue statusReason,
            bool useSubCategory)
        {
            Entity emailEntity = new Entity("email");

            Entity fromParty = new Entity("activityparty");
            Entity toParty = new Entity("activityparty");

            toParty["partyid"] = to;
            fromParty["partyid"] = from;

            emailEntity["from"] = new EntityCollection(new List<Entity>() { fromParty });
            emailEntity["to"] = new EntityCollection(new List<Entity>() { toParty });
            emailEntity["directioncode"] = true;
            emailEntity["subject"] = subject;
            emailEntity["regardingobjectid"] = regarding;
            emailEntity["activitytypecode"] = new OptionSetValue(4202);
            emailEntity["subcategory"] = "Acknowledgement Email";
            emailEntity["description"] = body;
            if(useSubCategory)
                emailEntity["subcategory"] = "SomeCategory";

            if (status != null) { emailEntity["statecode"] = status; }
            if (statusReason != null) { emailEntity["statusreason"] = statusReason; }

            if (Id.HasValue) {
                emailEntity.Id = Id.Value;
            }

            return emailEntity;
        }

        public static Entity CreateContact(
            Guid? Id,
            string firstName, 
            string lastName, 
            string email,
            OptionSetValue status,
            OptionSetValue statusReason)
        {
            Entity contactEntity = new Entity("contact");
            contactEntity["firstname"] = firstName;
            contactEntity["lastname"] = lastName;
            contactEntity["fullname"] = string.Format("{0} {1}", firstName, lastName);
            contactEntity["emailaddress1"] = email;
            contactEntity["rbs_confirmemail"] = email;
            if (status != null) { contactEntity["statecode"] = status; }
            if (statusReason != null) { contactEntity["statuscode"] = statusReason; }

            if (Id.HasValue)
            {
                contactEntity.Id = Id.Value;
            }

            return contactEntity;
        }

        public static void CreateContactsAndAddToContext(XrmFakedContext fakeContext, params Guid[] addContactIds)
        {
            List<Entity> contactsCreatedToBeInitialized = new List<Entity>();
            Random rand = new Random();
            foreach (Guid guid in addContactIds)
            {
                var createdContact = ObjectFactory.CreateContact(guid,
                    string.Format("firstName{0}", rand.Next()),
                    string.Format("lastName{0}", rand.Next()),
                    string.Format("test{0}@email.com", rand.Next()),
                    null, //new OptionSetValue(0),
                    null); //new OptionSetValue(1));
            }

            fakeContext.Initialize(contactsCreatedToBeInitialized);
        }
    }
}
