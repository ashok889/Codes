﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Utility.ExtractPrivilegeDetails
{
    class UserRole
    {

        public string UserId { get; set; }
        public string UserName { get; set; }
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public string QueueName { get; set; }
        public string Email { get; set; }
        public string BusinessUnitName { get; set; }
        public string TeamName { get; set; }
        public string PrivilegeName { get; set; }
        public string MailBoxName { get; set; }
    
    }
}
