﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

using System.Configuration;
using System.Data;
using System.Security.Cryptography;
using System.Reflection;
using System.Net;


namespace DES.Crm.Core.Utility.ExtractPrivilegeDetails
{
    class CommonMethods
    {
     
        public List<UserRole> GetUserRoleFromMCRM(IOrganizationService service)
        {

            List<UserRole> userRoleList = new List<UserRole>();


            var fetchXml = @"
<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'>
   <entity name='systemuser'>
    <attribute name='fullname' />
    <attribute name='domainname' />
    <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' link-type='inner' intersect='true'>
      <link-entity name='role' from='roleid' to='roleid' link-type='inner' alias='role'>
        <attribute name='name' />
      </link-entity>
    </link-entity>
    <link-entity name='queuemembership' from='systemuserid' to='systemuserid' intersect='true'>
      <link-entity name='queue' from='queueid' to='queueid' alias='queue'>
        <attribute name='name' />
      </link-entity>
    </link-entity>
    <link-entity name='teammembership' from='systemuserid' to='systemuserid' intersect='true'>
      <link-entity name='team' from='teamid' to='teamid' alias='team'>
        <attribute name='name' />
      </link-entity>
    </link-entity>
    <link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='businessunit'>
      <attribute name='name' />
    </link-entity>
    <link-entity name='mailbox' from='mailboxid' to='defaultmailbox' alias='mailbox'>
      <attribute name='name' />
    </link-entity>
  </entity>
</fetch>";

            try
            {
                FetchExpression fetch = new FetchExpression(fetchXml);

                var entityColl = service.RetrieveMultiple(fetch);

                if (entityColl.Entities.Count > 0)
                {
                    foreach (Entity entity in entityColl.Entities)
                    {

                        UserRole userRole = new UserRole();
                        userRole.UserId = entity.Attributes.Contains("systemuserid") ? entity["systemuserid"].ToString() : null;
                        userRole.UserName = entity.Attributes.Contains("domainname") ? entity["domainname"].ToString() : null;
                        userRole.BusinessUnitName = entity.Attributes.Contains("businessunit.name") ? ((AliasedValue)entity["businessunit.name"]).Value.ToString() : null;
                        userRole.RoleName = entity.Attributes.Contains("role.name") ? ((AliasedValue)entity["role.name"]).Value.ToString() : null;
                        userRole.QueueName = entity.Attributes.Contains("queue.name") ? ((AliasedValue)entity["queue.name"]).Value.ToString() : null;
                        userRole.TeamName = entity.Attributes.Contains("team.name") ? ((AliasedValue)entity["team.name"]).Value.ToString() : null;
                        userRole.MailBoxName = entity.Attributes.Contains("mailbox.name") ? ((AliasedValue)entity["mailbox.name"]).Value.ToString() : null;
                        userRoleList.Add(userRole);


                    }

                }
                return userRoleList;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in GetUserRoleFromMCRM block, Message: " + ex.Message);
                return userRoleList;
            }




        }
        public List<UserRole> GetSecurityRoleFromMCRMHavingPrivileges(IOrganizationService service, string privilege)
        {

            List<UserRole> securityRoleList = new List<UserRole>();


            var fetchXml = @"
<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'>
   <entity name='role' >
    <attribute name='name' />

 <order attribute='name' descending='false' />

    <link-entity name='roleprivileges' from='roleid' to='roleid' alias='roleprivilege' intersect='true' >
      <link-entity name='privilege' from='privilegeid' to='privilegeid' alias='privilege' >
        <attribute name='name' />
        <filter type='and' >
          <condition attribute='name' operator='eq' value='" + WebUtility.HtmlEncode(privilege) + @"' />
        </filter>
      </link-entity>
    </link-entity>
  </entity>
</fetch>";

            try
            {
                FetchExpression fetch = new FetchExpression(fetchXml);

                var entityColl = service.RetrieveMultiple(fetch);
                if (entityColl.Entities.Count > 0)
                {

                    {
                        foreach (Entity entity in entityColl.Entities)
                        {

                            UserRole securityRole = new UserRole();
                            securityRole.RoleName = entity.Attributes.Contains("name") ? entity["name"].ToString() : null;
                            securityRole.PrivilegeName = entity.Attributes.Contains("privilege.name") ? ((AliasedValue)entity["privilege.name"]).Value.ToString() : null;
                            securityRoleList.Add(securityRole);


                        }
                    }


                }
                return securityRoleList;
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception occured in GetSecurityRoleFromMCRMHavingPrivileges block, Message: " + ex.Message + "for privilege name" + privilege);
                return securityRoleList;
            }


        }
        public List<UserRole> GetAllUsersOfSecurityRoleHavingPrivileges(IOrganizationService service, string roleName)
        {
            List<UserRole> usersWithSecurityRoleList = new List<UserRole>();


            var fetchXml = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'>
<entity name='systemuser' >
    <attribute name='systemuserid' />
    <attribute name='fullname' />
     <attribute name='domainname' />
<filter type='and'>

<condition attribute = 'isdisabled' value = '0' operator= 'eq' />
     

     </filter >
     
         <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' intersect='true' >
      <link-entity name='role' from='roleid' to='roleid' alias='role' >
        <attribute name='name' />
        <filter>
          <condition attribute='name' operator='eq' value= '" + WebUtility.HtmlEncode(roleName) + @"' />
        </filter>
      </link-entity>
    </link-entity>
    <link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='businessunit' >
      <attribute name='name' />
 <order attribute='name' descending='false' />

    </link-entity>
  </entity>
</fetch>";
            try
            {
                FetchExpression fetch = new FetchExpression(fetchXml);

                var entityColl = service.RetrieveMultiple(fetch);
                if (entityColl.Entities.Count > 0)
                {
                    foreach (Entity entity in entityColl.Entities)
                    {

                        UserRole usersWithSecurityRole = new UserRole();

                        usersWithSecurityRole.UserName = entity.Attributes.Contains("fullname") ? entity["fullname"].ToString() : null;
                        usersWithSecurityRole.UserId = entity.Attributes.Contains("systemuserid") ? entity["systemuserid"].ToString() : null;
                        usersWithSecurityRole.Email = entity.Attributes.Contains("domainname") ? entity["domainname"].ToString() : null;
                        usersWithSecurityRole.RoleName = entity.Attributes.Contains("role.name") ? ((AliasedValue)entity["role.name"]).Value.ToString() : null;
                        usersWithSecurityRole.BusinessUnitName = entity.Attributes.Contains("businessunit.name") ? ((AliasedValue)entity["businessunit.name"]).Value.ToString() : null;

                        usersWithSecurityRoleList.Add(usersWithSecurityRole);


                    }
                }

                return usersWithSecurityRoleList;
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception occured in GetAllUsersOfSecurityRoleHavingxcelPrivileges block, Message: " + ex.Message + "for role name" + roleName);
                return usersWithSecurityRoleList;
            }
        }
        public List<UserRole> GetAllTeamsHavingPrivileges(IOrganizationService service, string roleName)
        {
            List<UserRole> teamsWithSecurityRoleList = new List<UserRole>();


            var fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
    <entity name='team' >
        <attribute name='name' />
        <filter type='and' >
            <condition attribute='teamtype' value='0' operator='eq' />
        </filter>
        <link-entity name='teamroles' from='teamid' to='teamid' intersect='true' >
            <link-entity name='role' from='roleid' to='roleid' alias='role' >
                <attribute name='name' />
                <filter type='and' >
                    <condition attribute='name' operator='eq' value='" + WebUtility.HtmlEncode(roleName) + @"' />
                </filter>
            </link-entity>
        </link-entity>
        <link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='businessunit' >
            <attribute name='name' />
        </link-entity>
    </entity>
</fetch>";
            try
            {
                FetchExpression fetch = new FetchExpression(fetchXml);

                var entityColl = service.RetrieveMultiple(fetch);
                if (entityColl.Entities.Count > 0)
                {
                    foreach (Entity entity in entityColl.Entities)
                    {

                        UserRole usersWithSecurityRole = new UserRole();

                        usersWithSecurityRole.TeamName = entity.Attributes.Contains("name") ? entity["name"].ToString() : null;

                        usersWithSecurityRole.RoleName = entity.Attributes.Contains("role.name") ? ((AliasedValue)entity["role.name"]).Value.ToString() : null;

                        usersWithSecurityRole.BusinessUnitName = entity.Attributes.Contains("businessunit.name") ? ((AliasedValue)entity["businessunit.name"]).Value.ToString() : null;

                        teamsWithSecurityRoleList.Add(usersWithSecurityRole);

                    }
                }
                return teamsWithSecurityRoleList;
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception occured in GetAllTeamsHavingPrivileges block, Message: " + ex.Message + "for role name" + roleName);
                return teamsWithSecurityRoleList;
            }
        }       
        public List<UserRole> GetAllUsersMappedToTeamsHavingPrivileges(IOrganizationService service, string teamName)
        {
            List<UserRole> teamsWithSecurityRoleList = new List<UserRole>();


            var fetchXml = @"
    <fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'>
    <entity name='systemuser' >
    <attribute name='fullname' />
<filter type='and'>

<condition attribute = 'isdisabled' value = '0' operator= 'eq' />
     

     </filter >
    <link-entity name='teammembership' from='systemuserid' to='systemuserid' intersect='true' >
      <filter type='and' />
      <link-entity name='team' from='teamid' to='teamid' alias='team' >
        <attribute name='name' />
        <filter type='and' >
          <condition attribute='name' operator='eq' value='" + WebUtility.HtmlEncode(teamName) + @"' />
        </filter>
      </link-entity>
    </link-entity>
    <link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='businessunit' >
      <attribute name='name' />
    </link-entity>
  </entity>
    </fetch>";
            FetchExpression fetch = new FetchExpression(fetchXml);

            try
            {
                var entityColl = service.RetrieveMultiple(fetch);
                if (entityColl.Entities.Count > 0)
                {
                    foreach (Entity entity in entityColl.Entities)
                    {
                        UserRole usersWithSecurityRole = new UserRole();

                        usersWithSecurityRole.TeamName = entity.Attributes.Contains("fullname") ? entity["fullname"].ToString() : null;

                        usersWithSecurityRole.RoleName = entity.Attributes.Contains("team.name") ? ((AliasedValue)entity["team.name"]).Value.ToString() : null;

                        usersWithSecurityRole.BusinessUnitName = entity.Attributes.Contains("businessunit.name") ? ((AliasedValue)entity["businessunit.name"]).Value.ToString() : null;

                        teamsWithSecurityRoleList.Add(usersWithSecurityRole);

                    }

                }
                return teamsWithSecurityRoleList;
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception occured  in GetAllUsersMappedToTeamsHavingPrivileges, message " + ex.Message + " for team name " + teamName);
                return teamsWithSecurityRoleList;
            }

        }
        public DataTable CreateUserRoleTable()
        {
            DataTable dtUserRole = new DataTable();

            dtUserRole.Columns.Add("UserId", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("NTUserName", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("BusinessUnitName", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("RoleName", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("QueueName", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("TeamName", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("MailBoxName", System.Type.GetType("System.String"));

            return dtUserRole;

        }
        public DataTable CreateSecurityRoleTable()
        {
            DataTable dtUserRole = new DataTable();

            dtUserRole.Columns.Add("SecurityRole", System.Type.GetType("System.String"));
            dtUserRole.Columns.Add("PrivilegeName", System.Type.GetType("System.String"));

            return dtUserRole;

        }
        public DataTable CreateUserWithSecurityRoleTable()
        {
            DataTable dtUserRole = new DataTable();

            dtUserRole.Columns.Add("UserName", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("Email", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("SecurityRole", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("BusinessUnitName", System.Type.GetType("System.String"));

            //dtUserRole.Columns.Add("PrivilegeName", System.Type.GetType("System.String"));

            return dtUserRole;

        }
        public DataTable CreateTeamWithSecurityRoleTable()
        {
            DataTable dtUserRole = new DataTable();

            dtUserRole.Columns.Add("TeamName", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("RoleName", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("BusinessUnitName", System.Type.GetType("System.String"));

            //dtUserRole.Columns.Add("PrivilegeName", System.Type.GetType("System.String"));

            return dtUserRole;

        }
        public DataTable CreateUsersWithTeamTable()
        {
            DataTable dtUserRole = new DataTable();

            dtUserRole.Columns.Add("UserName", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("Team", System.Type.GetType("System.String"));

            dtUserRole.Columns.Add("BusinessUnitName", System.Type.GetType("System.String"));

            //dtUserRole.Columns.Add("PrivilegeName", System.Type.GetType("System.String"));

            return dtUserRole;

        }
        public void GenerateXML(DataTable dt)
        {
            dt.TableName = "Roles";
            dt.WriteXml("Roles.xml");
        }
        public static string Encrypt(string toEncrypt, bool useHashing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

            System.Configuration.AppSettingsReader settingsReader =
                                                new AppSettingsReader();
            // Get the key from config file

            //string key = (string)settingsReader.GetValue("SecurityKey",
            //                                                 typeof(String));
            //System.Windows.Forms.MessageBox.Show(key);
            //If hashing use get hashcode regards to your key

            // keyArray = UTF8Encoding.UTF8.GetBytes(key);
            SHA512CryptoServiceProvider hash = new SHA512CryptoServiceProvider();
            keyArray = hash.ComputeHash(UTF8Encoding.UTF8.GetBytes("givekey"));
            byte[] trimmedBytes = new byte[24];
            Buffer.BlockCopy(keyArray, 0, trimmedBytes, 0, 24);
            keyArray = trimmedBytes;

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            //set the secret key for the tripleDES algorithm
            tdes.Key = keyArray;
            //mode of operation. there are other 4 modes.
            //We choose ECB(Electronic code Book)
            tdes.Mode = CipherMode.ECB;
            //padding mode(if any extra byte added)

            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            //transform the specified region of bytes array to resultArray
            byte[] resultArray =
              cTransform.TransformFinalBlock(toEncryptArray, 0,
              toEncryptArray.Length);
            //Release resources held by TripleDes Encryptor
            tdes.Clear();
            //Return the encrypted data into unreadable string format
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        public static string Decrypt(string cipherString, bool useHashing)
        {
            byte[] keyArray;
            //get the byte code of the string

            byte[] toEncryptArray = Convert.FromBase64String(cipherString);

            System.Configuration.AppSettingsReader settingsReader =
                                                new AppSettingsReader();
            //Get your key from config file to open the lock!
            //string key = (string)settingsReader.GetValue("SecurityKey",
            //                                             typeof(String));

            if (useHashing)
            {
                //if hashing was used get the hash code with regards to your key
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes("givekey"));
                //release any resource held by the MD5CryptoServiceProvider

                hashmd5.Clear();
            }
            else
            {
                //if hashing was not implemented get the byte code of the key
                SHA512CryptoServiceProvider hash = new SHA512CryptoServiceProvider();
                keyArray = hash.ComputeHash(UTF8Encoding.UTF8.GetBytes("givekey"));
                byte[] trimmedBytes = new byte[24];
                Buffer.BlockCopy(keyArray, 0, trimmedBytes, 0, 24);
                keyArray = trimmedBytes;
            }

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            //set the secret key for the tripleDES algorithm
            tdes.Key = keyArray;
            //mode of operation. there are other 4 modes. 
            //We choose ECB(Electronic code Book)

            tdes.Mode = CipherMode.ECB;
            //padding mode(if any extra byte added)
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(
                                 toEncryptArray, 0, toEncryptArray.Length);
            //Release resources held by TripleDes Encryptor                
            tdes.Clear();
            //return the Clear decrypted TEXT
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
        internal static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            try
            {

                foreach (DataRow row in dt.Rows)
                {
                    T item = GetItem<T>(row);
                    data.Add(item);

                }
                return data;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in ConvertDataTable block , message " + ex.Message + " for datatable name " + dt.TableName);

                return data;

            }

        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            try
            {

                foreach (DataColumn column in dr.Table.Columns)
                {
                    foreach (PropertyInfo pro in temp.GetProperties())
                    {
                        if (pro.Name == column.ColumnName)
                            pro.SetValue(obj, dr[column.ColumnName], null);
                        else
                            continue;
                    }
                }
                return obj;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in GetItem block , message " + ex.Message + " for data table name " + dr.Table.TableName);

                return obj;
            }

        }
        public void AddUsersToListWithSecurityRolesHavingPrivileges(List<UserRole> usersWithSecurityRoles, DataTable dtUsersBelongingToSecurityRoles)
        {
            foreach (UserRole ur in usersWithSecurityRoles)
            {
                dtUsersBelongingToSecurityRoles.Rows.Add(ur.UserName, ur.Email, ur.RoleName, ur.BusinessUnitName);
            }
        }
        public void AddTeamsToListWithSecurityRolesHavingPrivileges(List<UserRole> teamsWithSecurityRoles, DataTable dtUsersBelongingToSecurityRoles)
        {
            foreach (UserRole ur in teamsWithSecurityRoles)
            {
                dtUsersBelongingToSecurityRoles.Rows.Add(ur.TeamName, ur.RoleName, ur.BusinessUnitName);
            }
        }
        public void AddUsersToListWithTeamsHavingPrivileges(List<UserRole> usersWithSecurityRoles, DataTable dtUsersBelongingToSecurityRoles)
        {
            foreach (UserRole ur in usersWithSecurityRoles)
            {
                dtUsersBelongingToSecurityRoles.Rows.Add(ur.TeamName, ur.RoleName, ur.BusinessUnitName);
            }

        }
        internal bool CheckIfPrivilegeExists(IOrganizationService service, string strPrivilegeName)
        {

            QueryExpression qe = new QueryExpression();
            qe.EntityName = "privilege";
            qe.ColumnSet = new ColumnSet();
            qe.ColumnSet.Columns.Add("name");
            FilterExpression fe = new FilterExpression(LogicalOperator.And);
            ConditionExpression ce = new ConditionExpression("name", ConditionOperator.Equal, strPrivilegeName);
            
            fe.AddCondition(ce);
            qe.Criteria.AddFilter(fe);
          
            EntityCollection ec = service.RetrieveMultiple(qe);            
            return ec.Entities.Count>0? true: false;

        }
    }
}
