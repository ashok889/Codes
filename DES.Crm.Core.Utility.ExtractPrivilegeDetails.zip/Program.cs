﻿using System;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using System.Data;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;


namespace DES.Crm.Core.Utility.ExtractPrivilegeDetails
{
    class FetchUsersTeamsandRoles
    {
        public static string instanceName { get; set; }
        public static string privilegeName { get; set; }
        static void Main(string[] args)
        {
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;


                CommonMethods cms = new CommonMethods();
                string instanceName = "";
                CreateExcel excelObject = new CreateExcel();
                Console.WriteLine("Type URI of the instance you want to connect with. ex. https://####.crm#.dynamics.com ");
                string instanceUri = Console.ReadLine();



                Console.WriteLine("Type you user name");

                string userName = Console.ReadLine();




                Console.WriteLine("Type your password ");
                string passwordText = "";
                ConsoleKeyInfo key;

                do
                {
                    key = Console.ReadKey(true);

                    // Backspace Should Not Work
                    if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                    {
                        passwordText += key.KeyChar;
                        Console.Write("*");
                    }
                    else
                    {
                        if (key.Key == ConsoleKey.Backspace && passwordText.Length > 0)
                        {
                            passwordText = passwordText.Substring(0, (passwordText.Length - 1));
                            Console.Write("\b \b");
                        }
                    }
                }
                // Stops Receving Keys Once Enter is Pressed
                while (key.Key != ConsoleKey.Enter);


                var credentials = new ClientCredentials();

                credentials.UserName.UserName = userName;

                credentials.UserName.Password = passwordText;
                    

                Uri organizationUri = new Uri(instanceUri + "/XRMServices/2011/Organization.svc");

               
                using (OrganizationServiceProxy _serviceProxy = new OrganizationServiceProxy(organizationUri, null, credentials, null))
                {
                    if (_serviceProxy.Execute(new WhoAmIRequest()).Results["UserId"] != null)
                    {
                     
                        IOrganizationService service = (IOrganizationService)_serviceProxy;
                       

                      
                        instanceName = instanceUri.Substring(8).Split('.')[0].ToUpperInvariant();
                      
                        Console.WriteLine("\n Connection created successfully with " + instanceName);

                      
                                Console.WriteLine("\nEnter the privilegeName. ex. prvExportToExcel, prvReadReport");
                                privilegeName = Console.ReadLine();
                                bool privilegeExists = cms.CheckIfPrivilegeExists(service, privilegeName);
                                if (privilegeExists == true)
                                {
                                    bool successExporting = ExportToExcel(cms, _serviceProxy, privilegeName, privilegeName + instanceName + ".xlsx");

                                    if (successExporting == true)
                                        Console.WriteLine("Exported the details of Export to Excel Privileges in " + privilegeName + instanceName + ".xlsx");
                                    else
                                        Console.WriteLine("Could not export the details ");
                                    Console.WriteLine("\n---------------------------------*************---------------------------------");

                                    Console.WriteLine("Press any key to exit.");

                                    Console.ReadKey();
                                   
                                }
                                else
                                {
                                    Console.WriteLine("\nEnter a valid privilege name");

                                    Console.WriteLine("Press any key to exit.");

                                    Console.ReadKey();
                                  
                                }                                                                             
                           


                    }                                      
                     

            
                    else
                    {
                        Console.WriteLine("\n Connection could not be created successfully, check your Username/Password and try again." );
                        Console.WriteLine("\nEnter the privilegeName. ex. prvExportToExcel, prvReadReport");
                        privilegeName = Console.ReadLine();
                      
                    }
                }
                   


                
            }

            catch (Exception ex)
            {
                Console.WriteLine("Exception Occured, details: " +ex.Message);
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
            }
    
        }

        private static bool ExportToExcel(CommonMethods cms, IOrganizationService crmService,string privilegeName,string fileName)
        {
            Console.WriteLine("\n Retrieving details... ");

            List<UserRole> securityRolesHavingPrivilege = cms.GetSecurityRoleFromMCRMHavingPrivileges(crmService, privilegeName);

            Console.WriteLine("Obtained the list of security roles having "+privilegeName);
         
            List<UserRole> usersWithSecurityRolesHavingPrivilege;

            List<UserRole> teamsWithSecurityRolesHavingPrivilege;

            List<UserRole> usersWithTeamsHavingExportToExcel;

            DataSet ds = new DataSet();

            DataTable dtSecurityRole = cms.CreateSecurityRoleTable();
            dtSecurityRole.TableName = "SecurityRoles";

            DataTable dtUsersBelongingToSecurityRoles = cms.CreateUserWithSecurityRoleTable();
            dtUsersBelongingToSecurityRoles.TableName = "UsersBelongingToSecurityRoles";

            DataTable dtteamsBelongingToSecurityRoles = cms.CreateTeamWithSecurityRoleTable();
            dtteamsBelongingToSecurityRoles.TableName = "TeamBelongingToSecurityRoles";

            DataTable dtUsersBelongingToTeams = cms.CreateUsersWithTeamTable();
            dtUsersBelongingToTeams.TableName = "UsersBelongingToTeams";
                 
            
            foreach (UserRole ur in securityRolesHavingPrivilege)
            {
                dtSecurityRole.Rows.Add(ur.RoleName, ur.PrivilegeName);

                usersWithSecurityRolesHavingPrivilege = cms.GetAllUsersOfSecurityRoleHavingPrivileges(crmService, ur.RoleName);             
                cms.AddUsersToListWithSecurityRolesHavingPrivileges(usersWithSecurityRolesHavingPrivilege, dtUsersBelongingToSecurityRoles);

                teamsWithSecurityRolesHavingPrivilege = cms.GetAllTeamsHavingPrivileges(crmService, ur.RoleName);
                cms.AddTeamsToListWithSecurityRolesHavingPrivileges(teamsWithSecurityRolesHavingPrivilege, dtteamsBelongingToSecurityRoles);
            }

            ds.Tables.Add(dtSecurityRole);

            dtUsersBelongingToSecurityRoles.DefaultView.Sort = dtUsersBelongingToSecurityRoles.Columns.Contains("BusinessUnitName") ? "BusinessUnitName ASC" : "";
            dtUsersBelongingToSecurityRoles = dtUsersBelongingToSecurityRoles.DefaultView.ToTable();
            ds.Tables.Add(dtUsersBelongingToSecurityRoles);
            Console.WriteLine("Obtained the list of users with security roles having " + privilegeName);

            dtteamsBelongingToSecurityRoles.DefaultView.Sort = dtteamsBelongingToSecurityRoles.Columns.Contains("BusinessUnitName") ? "BusinessUnitName ASC" : "";
            dtteamsBelongingToSecurityRoles = dtteamsBelongingToSecurityRoles.DefaultView.ToTable();
            ds.Tables.Add(dtteamsBelongingToSecurityRoles);
            Console.WriteLine("Obtained the list of teams with security roles having " + privilegeName);

            List<UserRole> completeListOfAllTeamsHavingHavingExportToExcel = CommonMethods.ConvertDataTable<UserRole>(dtteamsBelongingToSecurityRoles);
            foreach (UserRole ur in completeListOfAllTeamsHavingHavingExportToExcel)
            {
                usersWithTeamsHavingExportToExcel = cms.GetAllUsersMappedToTeamsHavingPrivileges(crmService, ur.TeamName);
                cms.AddUsersToListWithTeamsHavingPrivileges(usersWithTeamsHavingExportToExcel, dtUsersBelongingToTeams);

            }
            dtUsersBelongingToTeams.DefaultView.Sort = dtUsersBelongingToTeams.Columns.Contains("BusinessUnitName") ? "BusinessUnitName ASC" : "";
            dtUsersBelongingToTeams = dtUsersBelongingToTeams.DefaultView.ToTable();
            ds.Tables.Add(dtUsersBelongingToTeams);

            Console.WriteLine("Obtained the list of users associated with teams having " + privilegeName);
           
            bool createdExcel = CreateExcel.CreateExcelDocument(ds, fileName);

            return createdExcel;
        }
    }
}
