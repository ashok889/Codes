﻿using System;
using System.Runtime.Serialization;

namespace PortalEncryptApi.Exceptions
{
    /// <inheritdoc />
    /// <summary>
    /// Portal Encrypt API Exception
    /// </summary>
    /// <seealso cref="T:System.Exception" />
    [Serializable]
    public class PortalEncryptApiException : Exception
    {
        /// <inheritdoc />
        /// <summary>
        /// Initializes a new instance of the <see cref="T:PortalEncryptApi.Exceptions.PortalEncryptApiException" /> class.
        /// </summary>
        public PortalEncryptApiException()
        {
        }

        /// <inheritdoc />
        /// <summary>
        /// Initializes a new instance of the <see cref="T:PortalEncryptApi.Exceptions.PortalEncryptApiException" /> class.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public PortalEncryptApiException(string message) : base(message)
        {
        }

        /// <inheritdoc />
        /// <summary>
        /// Initializes a new instance of the <see cref="T:PortalEncryptApi.Exceptions.PortalEncryptApiException" /> class.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">The exception that is the cause of the current exception, or a null reference (<see langword="Nothing" /> in Visual Basic) if no inner exception is specified.</param>
        public PortalEncryptApiException(string message, Exception innerException) :
            base(message, innerException)
        {
        }

        /// <inheritdoc />
        /// <summary>
        /// Initializes a new instance of the <see cref="T:PortalEncryptApi.Exceptions.PortalEncryptApiException" /> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo" /> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext" /> that contains contextual information about the source or destination.</param>
        protected PortalEncryptApiException(SerializationInfo info,
            StreamingContext context) : base(info, context)
        {
        }
    }
}
