﻿using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using Jose;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using PortalEncryptApi.Exceptions;

namespace PortalEncryptApi.Controllers
{
    /// <inheritdoc />
    /// <summary>
    /// Encrypt Controller
    /// </summary>
    /// <seealso cref="T:System.Web.Http.ApiController" />
    [EnableCors(origins: "https://descrmcoredev-test.microsoftcrmportals.com/", headers: "*", methods: "*")]
    public class EncryptController : ApiController
    {
        private const string Key = "-----BEGIN PRIVATE KEY-----\rMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAGeUHDZCQgZl7/AIwy/Vl2Zekj5XTFUOlQSYchqsd4xeDLwtlF062RkwC8nC/hgYZTP5GEJ0YW0mVQReE+SFhI3Zsv27lEtJB7WwLP8MOh8cYIBejJrXjsmBsXIlPkkWwjkvV674e/jVfjoudLV23G4gGwlWI4bMU847RqUCWKc4X1QXrYtp0zdb++1pRSLpFBtY77mcVcDv2vgiqV62kSwsO9b1qmz0S4XdjPxe/KPX7MesIXF0Iy17UPJmwTS9eMjrFLYLKVmp8iZwklAYS6pvs4M05uq5kfwWiUJug/AkDW18t7h5hC5/OzRkGrD4+e+n3Aix2oFDEsOAbxj6x/kCAwEAAQKCAQAs63jItzd3GuJR0RsFNbZxOPZnfuilwqsx0QM7OiymfWs8eO/s9saMO+AA4kXcIUhSn+a7e0l9UrBwMnSiGJ2B/zW3AJCxjbyAOSVqftz9/QqE4XxM8ssD7PENtcUrYWld74Axa6YoJj6V8OvAfwnd4KKZC/hgT2DRAbgDe98Ctcwz7g5Nb5aMptY1o9wWeBblUo7q1MjPnrBzo2WjRc6u4vd2ctRHRfcVy3QXIPqxdsTvCMPie4hK0SXIq8hDi4/6vCHYTvwpGwefcPnx1Gqu7z/POG0nkh5CNUfALDHl4o5ue8yMC529au3r6IWYY9+iQke/D0hROcN8lGTsJivhAoGBALEmRsymT20MBeoL31M8o64EUqkMD+zQZrhx0dxbmqQkj4JTxLmEpcE9ahmQtLdtlM6sUngOfIU0IfZvYwUx1n65ODwzE/z7WQiNq2lljixi4fDX+Carr9Wp0KzyAP1t/PKnO26w3TkpdS+Jtf8qGcEj05JlsmGduU68OTKvsYWNAoGBAJWunX/3C9f/urUfHF3tgt53WffMlvOSxrTw9g0+q0iNv8uRZtndyMgJs97n+LlPQLM68yundmmDc3gAr4cOPBkms6ayxIyU3tJogTKeWqsKJNbEvkmtPM62APTj9vkmcDQTNazCAItI+5qn8B23Y5cQOuDoc5RWgQ7254fsBgMdAoGADeYo6+mola+5zxE7ZnZ9iSvBqI3Pug7n4FTd2GI/kd1kfR9BciTcNHszFepqo3GvmT+gANdyIaljeMhohoHQiITTyrVfPhwici9bYZucOhNQEut/Btm1pBf8zXT3aur0S72fRiIOWWvNS/uMEgclmifLc9MS2eHcJjdSbY2nagkCgYEAlX6rwXXNN3MrV+B1pX4lOem8SpjknusWWPtc1AembLVePIPBVJGFCf1ez5+hs/rqpNeYrR35TxLBzbXpmZrm/TvBLBnZ4oqBLWbAuvybk75y4qnnX5CNbesrc2sHbPouEGSrNBsjDfnbiTB3ykYySlskYyLm5N2s0nRY9FEQBCUCgYBWfIOvF816b2Gm5ZH3/oovyd+u4epu14+4zHSHxW6FH7V6gHKpsBUoWB0wE0G8JT9viO/KYZWmz2ryr9IPxqrcOzwBNh7gdxb+6LPjMOWeMLRaFFYa6dDIIORRa81v0su8CvPu3643FuVu2QR4aW2/076/Nw11DFzzbGQrdgdysw==\r-----END PRIVATE KEY-----";
        /// <summary>
        /// Gets the RSA parameters.
        /// </summary>
        /// <value>
        /// The RSA parameters.
        /// </value>
        /// <exception cref="PortalEncryptApiException">Could not read RSA private key</exception>
        private static RSAParameters RsaParams
        {
            get
            {
                using (StringReader stringReader = new StringReader(Key))
                {
                    PemReader pemReader = new PemReader(stringReader);
                    RsaPrivateCrtKeyParameters privateRsaParams = pemReader.ReadObject() as RsaPrivateCrtKeyParameters;
                    return DotNetUtilities.ToRSAParameters(privateRsaParams);
                }
            }
        }

        /// <summary>
        /// Gets or sets the encode.
        /// </summary>
        /// <value>
        /// The encode.
        /// </value>
        private string Encode { get; set; }

        /// <summary>
        /// Encrypts the specified data.
        /// </summary>
        /// <param name="contactId">The contact identifier.</param>
        /// <param name="fullName">The full name.</param>
        /// <returns></returns>
        [AcceptVerbs("GET")]
        [HttpGet]
        public Task<IHttpActionResult> Encrypt(Guid contactId, string fullName)
        {
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                var payload = new
                {
                    sub = contactId.ToString().ToUpper(CultureInfo.CurrentCulture),
                    given_name = fullName,
                    iss = "source string",
                    iat = (int)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds,
                    exp = (int)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds + 7200
                };
                rsa.ImportParameters(RsaParams);
                Encode = JWT.Encode(payload, rsa, JwsAlgorithm.RS256);
                return Task.FromResult<IHttpActionResult>(Ok(Encode));
            }
        }
    }
}
