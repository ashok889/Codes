﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.CRM.Core.GlobalNotification.Plugins
{
    public class PreNotificationCreate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Obtain the tracing service from the service provider.
            ITracingService TracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));


            // Obtain the organization factory service from the service provider.
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            // Use the factory to generate the organization service.
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {

                Entity notification = (Entity)context.InputParameters["Target"];
                // Obtain the target entity from the input parameters.
                if (notification.LogicalName != "rbs_notification")
                    return;
                else
                {
                    Entity preImage=null;
                OptionSetValue displayType = new OptionSetValue(0);
                EntityReference notificationCategory = null;
                EntityReference notificationMessage = null;

                if (context.PreEntityImages.Contains("PreImage") && context.PreEntityImages["PreImage"] is Entity && context.MessageName.ToLower()=="update")
                    preImage = (Entity)context.PreEntityImages["PreImage"];

                        if (notification.Contains("rbs_notificationcategoryid"))
                            notificationCategory = notification.GetAttributeValue<EntityReference>("rbs_notificationcategoryid");
                        else if (context.MessageName.ToLower() == "update" && preImage.Contains("rbs_notificationcategoryid"))
                            //if notification category is not in context it means its not updated, so get the value from pre image to avoid a retrieve
                            notificationCategory = preImage.GetAttributeValue<EntityReference>("rbs_notificationcategoryid");
                        if (notification.Contains("rbs_notificationmessageid"))
                            notificationMessage = notification.GetAttributeValue<EntityReference>("rbs_notificationmessageid");
                        else if (context.MessageName.ToLower() == "update" && preImage.Contains("rbs_notificationmessageid"))
                            notificationMessage = preImage.GetAttributeValue<EntityReference>("rbs_notificationmessageid");
                        if (notification.Contains("rbs_notificationdisplaytype"))
                            displayType = notification.GetAttributeValue<OptionSetValue>("rbs_notificationdisplaytype");
                        else if(context.MessageName.ToLower() == "update" && preImage.Contains("rbs_notificationdisplaytype"))
                            displayType =preImage.GetAttributeValue<OptionSetValue>("rbs_notificationdisplaytype");


                    //check if it contains category, message and if its a bar notification

                    if (displayType.Value == 859770000 && notificationCategory != null && notificationCategory.Id != Guid.Empty && notificationMessage != null && notificationMessage.Id != Guid.Empty)
                    {
                        QueryExpression qeNotification = new QueryExpression("rbs_notification");
                        qeNotification.NoLock = true;
                        qeNotification.Criteria.AddCondition(new ConditionExpression("rbs_notificationmessageid", ConditionOperator.Equal, notificationMessage.Id));
                        qeNotification.Criteria.AddCondition(new ConditionExpression("rbs_notificationcategoryid", ConditionOperator.Equal, notificationCategory.Id));
                        qeNotification.ColumnSet = new ColumnSet("rbs_notificationmessageid");
                        EntityCollection _notificationCollection = service.RetrieveMultiple(qeNotification);
                        if (_notificationCollection != null && _notificationCollection.Entities != null && _notificationCollection.Entities.Count > 0)
                        {
                            throw new InvalidPluginExecutionException("A Notification already exists for the given combination of notification message and category");
                        }

                    }
                }
            }
        }
    }
}
