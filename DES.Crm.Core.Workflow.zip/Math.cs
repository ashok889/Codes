﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;

namespace Math
{

    public sealed class Pattern : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Value A")]
        [RequiredArgument()]
        public InArgument<string> ValueA { get; set; }

        [Input("Value B")]
        [RequiredArgument()]
        public InArgument<string> ValueB { get; set; }

        [Input("Help: Description.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            double dblValue = 0;
            double.TryParse(Value.Get(context), out dblValue);
            double dblA = 0;
            double.TryParse(ValueA.Get(context), out dblA);
            double dblB = 0;
            double.TryParse(ValueB.Get(context), out dblB);


            int intResult = 0;
            int intValue = 0;
            int.TryParse(Value.Get(context), out intValue);
            int intA = 0;
            int.TryParse(ValueA.Get(context), out intA);
            int intB = 0;
            int.TryParse(ValueB.Get(context), out intB);


            try
            {
                //Apply the required business logic
                Result.Set(context, System.Math.Abs(dblValue));

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }

}
