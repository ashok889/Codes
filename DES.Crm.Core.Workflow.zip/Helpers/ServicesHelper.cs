﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace Helpers
{

    public static class ServicesHelper
    {

        public static CodeActivityContext executionContext;
        public static ITracingService tracingService;
        public static IWorkflowContext context;
        public static IOrganizationServiceFactory serviceFactory;
        public static IOrganizationService service;

        public static void ServicesHelperExt(CodeActivityContext p_executionContext)
        {

            try
            {
                executionContext = p_executionContext;

                // Create the tracing service
                if (tracingService == null)
                {
                    tracingService = executionContext.GetExtension<ITracingService>();
                }

                if (tracingService == null)
                {
                    throw new InvalidPluginExecutionException("Failed to retrieve Tracing Service.");
                }

                tracingService.Trace("ActivityInstanceId: {0}, WorkflowInstanceId: {1}.",
                    executionContext.ActivityInstanceId,
                    executionContext.WorkflowInstanceId);

                // Create the context
                if (context == null)
                {
                    context = executionContext.GetExtension<IWorkflowContext>();
                }

                if (context == null)
                {
                    throw new InvalidPluginExecutionException("Failed to retrieve Workflow Context.");
                }

                tracingService.Trace("Correlation Id: {0}, Initiating User Id: {1}.",
                    context.CorrelationId,
                    context.InitiatingUserId);

                tracingService.Trace("Primary Entity Id: " + context.PrimaryEntityId +".");

                // Create the service
                if (serviceFactory == null)
                {
                    serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                }
                if (service == null)
                {
                    service = serviceFactory.CreateOrganizationService(context.UserId);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                throw new InvalidPluginExecutionException("Exception: " + e.ToString());
            }

        }

    }

}
