﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace Helpers
{

    internal class ExceptionManager
    {
        /// <summary>
        /// Basic exception handler
        /// </summary>
        /// <param name="e">FaultException</param>
        /// <param name="name">Name ot the Type generating the exception</param>
        /// <param name="tracingService">tracingService</param>
        public static void ManageBasicFaultException(string ExtraMessage, FaultException<OrganizationServiceFault> e, ITracingService tracingService)
        {

            string innerExceptionText = "";

            if ((e.InnerException != null))
            {
                innerExceptionText =  e.InnerException.ToString() + System.Environment.NewLine;
            }

            string message = ExtraMessage + System.Environment.NewLine +
                innerExceptionText + 
                e.Message;

            tracingService.Trace(message);
            throw new InvalidPluginExecutionException((OperationStatus.Failed), message);

        }

    }

}
