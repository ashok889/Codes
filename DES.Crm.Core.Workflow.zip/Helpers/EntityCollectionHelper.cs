﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;



namespace Helpers
{

    public class EntityCollectionHelper
    {

        public EntityCollection GetEntityCollection(
            string FetchQuery,
            InArgument Param0,
            InArgument Param1,
            InArgument Param2,
            InArgument Param3,
            InArgument Param4,
            InArgument Param5,
            InArgument Param6,
            InArgument Param7,
            InArgument Param8,
            InArgument Param9,
            out string FetchXML)
        {
            
            
            string fetchQuery = string.Empty;

            fetchQuery = string.Format(FetchQuery,
                        GetValue(Param0, ServicesHelper.executionContext),
                        GetValue(Param1, ServicesHelper.executionContext),
                        GetValue(Param2, ServicesHelper.executionContext),
                        GetValue(Param3, ServicesHelper.executionContext),
                        GetValue(Param4, ServicesHelper.executionContext),
                        GetValue(Param5, ServicesHelper.executionContext),
                        GetValue(Param6, ServicesHelper.executionContext),
                        GetValue(Param7, ServicesHelper.executionContext),
                        GetValue(Param8, ServicesHelper.executionContext),
                        GetValue(Param9, ServicesHelper.executionContext));

            try
            {
                FetchExpression fetch = new FetchExpression(fetchQuery);

                EntityCollection records = ServicesHelper.service.RetrieveMultiple(fetch);

                FetchXML = fetchQuery;

                return records;
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException(fetchQuery, e, ServicesHelper.tracingService);
                FetchXML = fetchQuery;
                return null;
            }

        }


        private string GetValue(InArgument parameter, System.Activities.CodeActivityContext executionContext)
        {

            if (parameter.Get(executionContext) != null)
            {
                return parameter.Get(executionContext).ToString();
            }
            else
            {
                return string.Empty;
            }

        }


    }

}
