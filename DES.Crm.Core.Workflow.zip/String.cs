﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;

//100% finished

//https://msdn.microsoft.com/en-us/library/system.string_methods.aspx
namespace String
{
    public sealed class Pattern : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Value.Get(context));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class CapitalizeName : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Update Attribute (optional)")]
        public InArgument<string> UpdateAttribute { get; set; }

        [Input("Help: Returns Value properly formatted as a Full Name. Optionally set Update Attribute = Result.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {



            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                string strResult = this.CapitalizeNameRet(Value.Get(context));

                if ((UpdateAttribute.Get(context)) != null)
                {
                    Entity currentEntity = new Entity(ServicesHelper.context.PrimaryEntityName);
                    currentEntity.Id = ServicesHelper.context.PrimaryEntityId;
                    currentEntity.Attributes[UpdateAttribute.Get(ServicesHelper.executionContext).ToString()] = strResult;

                    ServicesHelper.service.Update(currentEntity);
                }

                Result.Set(context, strResult);

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }


        private string CapitalizeNameRet(string name)
        {
            System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;

            name = name.ToLower();
            name = textInfo.ToTitleCase(name);

            name = name.Replace(" Y ", " y ");
            name = name.Replace(" DE ", " de ");
            name = name.Replace(" De ", " de ");
            name = name.Replace(" VAN ", " van ");
            name = name.Replace(" Van ", " van ");
            name = name.Replace(" Del ", " del ");
            name = name.Replace(" Of ", " of ");
            name = name.Replace(" Der ", " der ");
            name = name.Replace(" D\'", " d\'");

            string[] apostrophe = name.Split(new string[] { " d\'" }, StringSplitOptions.None);
            name = string.Empty;

            if (apostrophe.Length > 0)
            {
                int i = 0;

                while (i < apostrophe.Length)
                {
                    if (i == (apostrophe.Length - 1))
                    {
                        name += ToUpperFirstLetter(apostrophe[i]);
                    }
                    else
                    {
                        if (i > 0)
                        {
                            name += ToUpperFirstLetter(apostrophe[i]) + " d\'";
                        }
                        else
                        {
                            name += apostrophe[i] + " d\'";
                        }
                    }
                    i++;
                }
            }
            return name;
        }

        /// <summary>
        /// Set to upper the first character of a word
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private static string ToUpperFirstLetter(string name)
        {

            if (name.Length > 0)
            {
                char firstLetter = name[0];
                firstLetter = Char.ToUpper(firstLetter);
                name = firstLetter + name.Substring(1, name.Length - 1);
            }

            return name;
        }

    }


    public sealed class Compare : CodeActivity
    {

        #region Properties

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("str2")]
        [RequiredArgument()]
        public InArgument<string> str2 { get; set; }

        [Input("ignoreCase (default=true)")]
        [Default("True")]
        public InArgument<bool> ignoreCase { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/zkcaxw5y.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, string.Compare(str1.Get(context), str2.Get(context), ignoreCase.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Concat : CodeActivity
    {

        #region Properties

        [Input("str1 (default='')")]
        [Default("")]
        public InArgument<string> str1 { get; set; }

        [Input("str2 (default='')")]
        [Default("")]
        public InArgument<string> str2 { get; set; }

        [Input("str3 (default='')")]
        [Default("")]
        public InArgument<string> str3 { get; set; }

        [Default("")]
        [Input("str4 (default='')")]
        public InArgument<string> str4 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/0eafbze3.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, string.Concat(str1.Get(context), str2.Get(context), str3.Get(context), str4.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Contains : CodeActivity
    {

        #region Properties

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("str2")]
        [RequiredArgument()]
        public InArgument<string> str2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/dy85x1sa.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                string strStr2 = "";
                if (str2.Get(context) != null)
                {
                    strStr2 = str2.Get(context);
                }
                //Apply the required business logic
                Result.Set(context, str1.Get(context).Contains(strStr2));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Decrypt : CodeActivity
    {

        #region Properties 

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.security.cryptography.cryptostream.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DecryptRet(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        private static string DecryptRet(string Value)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212";
                byte[] cipherBytes = Convert.FromBase64String(Value);
                using (System.Security.Cryptography.Aes encryptor = System.Security.Cryptography.Aes.Create())
                {
                    System.Security.Cryptography.Rfc2898DeriveBytes pdb = new System.Security.Cryptography.Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                    {
                        using (System.Security.Cryptography.CryptoStream cs = new System.Security.Cryptography.CryptoStream(ms, encryptor.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        Value = System.Text.Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return Value;
            }
            catch
            {
                return string.Empty;
            }

        }

    }


    public sealed class Encrypt : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.security.cryptography.cryptostream.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, EncryptRet(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        private static string EncryptRet(string Value)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = System.Text.Encoding.Unicode.GetBytes(Value);
            using (System.Security.Cryptography.Aes encryptor = System.Security.Cryptography.Aes.Create())
            {
                System.Security.Cryptography.Rfc2898DeriveBytes pdb = new System.Security.Cryptography.Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    using (System.Security.Cryptography.CryptoStream cs = new System.Security.Cryptography.CryptoStream(ms, encryptor.CreateEncryptor(), System.Security.Cryptography.CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    Value = Convert.ToBase64String(ms.ToArray());
                }
            }
            return Value;
        }

    }


    public sealed class EndsWith : CodeActivity
    {

        #region Properties

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("str2)")]
        [RequiredArgument()]
        public InArgument<string> str2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/2333wewz.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                string strStr2 = "";
                if (str2.Get(context) != null)
                {
                    strStr2 = str2.Get(context);
                }
                Result.Set(context, str1.Get(context).EndsWith(strStr2));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Equals : CodeActivity
    {

        #region Properties

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("str2)")]
        [RequiredArgument()]
        public InArgument<string> str2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/1hkt4325.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, str1.Get(context).Equals(str2.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Format : CodeActivity
    {

        #region Properties

        [Input("format")]
        public InArgument<string> format { get; set; }

        [Input("arg0")]
        public InArgument<string> arg0 { get; set; }

        [Input("arg1")]
        public InArgument<string> arg1 { get; set; }

        [Input("arg2")]
        public InArgument<string> arg2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.string.format.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, string.Format(format.Get(context), arg0.Get(context), arg1.Get(context), arg2.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class GetDelimitedSubstring : CodeActivity
    {

        #region Properties 

        [Input("String: text to search in (i.e: the body of a email message)")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Tag: text to search for (i.e: NAME)")]
        [RequiredArgument()]
        public InArgument<string> tag { get; set; }

        [Input("Start Delimiter: text where the result start after the Tag (i.e: :)")]
        [RequiredArgument()]
        public InArgument<string> startDelimiter { get; set; }

        [Input("End Delimiter: text where the result ends (i.e: /#/)")]
        [RequiredArgument()]
        public InArgument<string> endDelimiter { get; set; }

        [Input("Help: Parse String searching for Tag and Returns the substring from Start Delimiter to End Delimiter.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, GetDelimitedSubstringRet(Value.Get(context), tag.Get(context), startDelimiter.Get(context), endDelimiter.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        private static string GetDelimitedSubstringRet(
            string FieldProperty,
            string Tag,
            string StartDelimiterProperty,
            string EndDelimiterProperty)
        {

            string result;

            string strFieldProperty = FieldProperty;
            string strTag = Tag;
            string strStartDelimiterProperty = StartDelimiterProperty;
            string strEndDelimiterProperty = EndDelimiterProperty;

            try
            {

                if (strFieldProperty.ToLower().IndexOf((strTag + strStartDelimiterProperty).ToLower()) >= 0)
                {
                    result = strFieldProperty.Substring(strFieldProperty.ToLower().IndexOf((strTag + strStartDelimiterProperty).ToLower()) + (strTag.Length + strStartDelimiterProperty.Length));

                    if (result.ToLower().IndexOf(strEndDelimiterProperty.ToLower()) >= 0)
                    {
                        result = result.Substring(0, result.ToLower().IndexOf(strEndDelimiterProperty.ToLower()));
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return "";
                }

                return result;
            }
            catch (Exception)
            {
                return "";
            }

        }

    }


    public sealed class GetGuid : CodeActivity
    {

        #region Properties

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.guid.newguid.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, new System.Guid().ToString());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class IndexOf : CodeActivity
    {

        #region Properties 

        [Input("value")]
        [RequiredArgument()]
        public InArgument<string> value { get; set; }

        [Input("startIndex")]
        [RequiredArgument()]
        public InArgument<int> startIndex { get; set; }

        [Input("count")]
        [RequiredArgument()]
        public InArgument<int> count { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/d93tkzah.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, value.Get(context).IndexOf(value.Get(context), startIndex.Get(context), count.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class IsGuid : CodeActivity
    {

        #region Properties

        [Input("possibleGuid")]
        [RequiredArgument()]
        public InArgument<string> possibleGuid { get; set; }

        [Input("Help: Returns true if possibleGuid is a real guid.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, IsGuidRet(possibleGuid.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        /// <summary>
        /// Returns true if pissibleGuid is a real guid
        /// </summary>
        /// <param name="possibleGuid"></param>
        /// <param name="guid"></param>
        /// <returns></returns>
        public static bool IsGuidRet(string possibleGuid)
        {
            System.Guid guid;
            return System.Guid.TryParse(possibleGuid, out guid);
        }

    }

    public sealed class IsNullOrEmpty : CodeActivity
    {

        #region Properties 

        [Input("value")]
        [RequiredArgument()]
        public InArgument<string> value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.string.isnullorempty.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, string.IsNullOrEmpty(value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class IsNullOrWhiteSpace : CodeActivity
    {

        #region Properties 

        [Input("value")]
        [RequiredArgument()]
        public InArgument<string> value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.string.isnullorwhitespace.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, string.IsNullOrWhiteSpace(value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class LastIndexOf : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("str2")]
        [RequiredArgument()]
        public InArgument<string> str2 { get; set; }

        [Input("startIndex (default = 0)")]
        public InArgument<int> startIndex { get; set; }

        [Input("count (default  = 0)")]
        public InArgument<int> count { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/d0z3tk9t.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                int intStartIndex = 0;
                if (startIndex.Expression != null)
                {
                    intStartIndex = startIndex.Get(context);
                }
                int intCount = 0;
                if (count.Expression != null)
                {
                    intCount = count.Get(context);
                }
                Result.Set(context, str1.Get(context).LastIndexOf(str2.Get(context), intStartIndex, intCount));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class PadLeft : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("totalWidth (default = 0)")]
        [Default("0")]
        public InArgument<int> totalWidth { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/92h5dc07.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                int intTotalWidth = 0;
                if (totalWidth.Expression != null)
                {
                    intTotalWidth = totalWidth.Get(context);
                }
                //Apply the required business logic
                Result.Set(context, str1.Get(context).PadLeft(intTotalWidth));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class PadRight : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("totalWidth (default = 0)")]
        [Default("0")]
        public InArgument<int> totalWidth { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/34d75d7s.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                int intTotalWidth = 0;
                if (totalWidth.Expression != null)
                {
                    intTotalWidth = totalWidth.Get(context);
                }
                Result.Set(context, str1.Get(context).PadRight(intTotalWidth));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Remove : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("startIndex (default = 0)")]
        [Default("0")]
        public InArgument<int> startIndex { get; set; }

        [Input("count (default = 0)")]
        [Default("0")]
        public InArgument<int> count { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/d8d7z2kk.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                int intStartIndex = 0;
                if (startIndex.Expression != null)
                {
                    intStartIndex = startIndex.Get(context);
                }
                int intCount = 0;
                if (count.Expression != null)
                {
                    intCount = count.Get(context);
                }
                int intStr1Length = str1.Get(context).Length;
                if ((intStartIndex + intCount) > intStr1Length)
                {
                    intCount = intStr1Length - intCount;
                }
                Result.Set(context, str1.Get(context).Remove(intStartIndex, intCount));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Replace : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("oldValue")]
        [RequiredArgument()]
        public InArgument<string> oldValue { get; set; }

        [Input("newValue")]
        [RequiredArgument()]
        public InArgument<string> newValue { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/fk49wtc1.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                string strOldValue = "A-VERY:UNLIKELY'VALUE;!1";
                if (oldValue.Get(context) != null)
                {
                    if (oldValue.Get(context) != "")
                    {
                        strOldValue = oldValue.Get(context);
                    }
                }
                Result.Set(context, (str1.Get(context).Replace(strOldValue, newValue.Get(context))));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class StartsWith : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("str2")]
        [RequiredArgument()]
        public InArgument<string> str2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/baketfxw.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                string strStr2 = "";
                if (str2.Get(context) != null)
                {
                    strStr2 = str2.Get(context);
                }
                Result.Set(context, str1.Get(context).StartsWith(strStr2));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Substring : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("startIndex (default = 0)")]
        [Default("0")]
        public InArgument<int> startIndex { get; set; }

        [Input("length (default = 0)")]
        [Default("0")]
        public InArgument<int> length { get; set; }


        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/aka44szs.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, str1.Get(context).Substring(startIndex.Get(context), length.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToLower : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/e78f86at.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, str1.Get(context).ToLower());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToUpper : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/ewdd6aed.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, str1.Get(context).ToUpper());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToUpperFirstLetter : CodeActivity
    {

        #region Properties 

        [Input("name")]
        [RequiredArgument()]
        public InArgument<string> name { get; set; }

        [Input("Help: Set to upper the first character of a word.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {



            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, ToUpperFirstLetterRet(name.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        /// <summary>
        /// Set to upper the first character of a word
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string ToUpperFirstLetterRet(string name)
        {
            if (name.Length > 0)
            {
                char firstLetter = name[0];
                firstLetter = Char.ToUpper(firstLetter);
                name = firstLetter + name.Substring(1, name.Length - 1);
            }
            return name;
        }

    }


    public sealed class Trim : CodeActivity
    {

        #region Properties 

        [Input("str1")]
        [RequiredArgument()]
        public InArgument<string> str1 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/t97s7bs3.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, str1.Get(context).Trim());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }

}
