﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

//https://msdn.microsoft.com/en-us/library/gg309405.aspx, http://msxrmtools.com/fetchxml/reference
namespace OnFetch
{

    public sealed class AddUserToRecordTeam : CodeActivity
    {

        #region Properties

        [Input("FetchQuery")]
        [RequiredArgument()]
        [Default("<fetch version='1.0' output-format='xml-platform' mapping='logical' no-lock='true' distinct='false'><entity name='{0}'><attribute name='{1}'/><filter type='and'><condition attribute='{2}' operator='{3}' value='{4}'/></filter></entity></fetch>")]
        public InArgument<string> FetchQuery { get; set; }

        [Input("Team")]
        [RequiredArgument()]
        [ReferenceTarget("team")]
        public InArgument<EntityReference> Team { get; set; }

        [Input("Param {0} [entity name='{0}']")]
        [Default("systemuser")]
        public InArgument<string> Param0 { get; set; }

        [Input("Param {1} [attribute name='{1}]")]
        [Default("systemuserid")]
        public InArgument<string> Param1 { get; set; }

        [Input("Param {2} [[condition attribute='{2}']")]
        [Default("emailaddress1")]
        public InArgument<string> Param2 { get; set; }

        [Input("Param {3} [condition operator='{3}']")]
        [Default("eq")]
        public InArgument<string> Param3 { get; set; }

        [Input("Param {4} [condition value='{4}]")]
        [Default("emailaddress@domain.com")]
        public InArgument<string> Param4 { get; set; }

        [Input("Param {5}")]
        [Default("")]
        public InArgument<string> Param5 { get; set; }

        [Input("Param {6}")]
        [Default("")]
        public InArgument<string> Param6 { get; set; }

        [Input("Param {7}")]
        [Default("")]
        public InArgument<string> Param7 { get; set; }

        [Input("Param {8}")]
        [Default("")]
        public InArgument<string> Param8 { get; set; }

        [Input("Param {9}")]
        [Default("")]
        public InArgument<string> Param9 { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Get a collection of entities based on the Fetch and on the ParamXs parameters
                string strFetchXML = System.String.Empty;
                EntityCollectionHelper p_EntityCollectionHelper = new EntityCollectionHelper();
                EntityCollection p_EntityCollection = p_EntityCollectionHelper.GetEntityCollection(
                    FetchQuery.Get(ServicesHelper.executionContext),
                    Param0, Param1, Param2, Param3, Param4, Param5, Param6, Param7, Param8, Param9, out strFetchXML);
                ServicesHelper.tracingService.Trace("Got a collection of entities based on the following Fetch: " + strFetchXML);

                //Apply the required business logic
                if (p_EntityCollection.Entities.Count > 0)
                {
                    //For each entity record
                    ServicesHelper.tracingService.Trace("For each entity in the collection (" + p_EntityCollection.Entities.Count + ")...");

                    foreach (Entity p_Entity in p_EntityCollection.Entities)
                    {
                        try
                        {
                            //Create the request
                            ServicesHelper.tracingService.Trace("Create the request for entity " + p_EntityCollection.Entities.Count + " LogicalName {0} and Id: {1}.", p_Entity.LogicalName, p_Entity.Id);
                            AssignRequest Request = new AssignRequest()
                            {
                                Assignee = new EntityReference
                                {
                                    LogicalName = "team",
                                    Id = new System.Guid(Team.Get(context).Id.ToString())
                                },

                                Target = new EntityReference(p_Entity.LogicalName, new System.Guid(p_Entity.Id.ToString()))
                            };
                            //Execute the request
                            ServicesHelper.tracingService.Trace("Execute the request for entity " + p_EntityCollection.Entities.Count + " LogicalName {0} and Id: {1}.", p_Entity.LogicalName, p_Entity.Id);
                            ServicesHelper.service.Execute(Request);
                        }
                        catch (FaultException<OrganizationServiceFault> e)
                        {
                            string strExtraMessage = "Fetch: " + strFetchXML;
                            ServicesHelper.tracingService.Trace("Error executing the request for entity LogicalName {0} and Id: {1}. Message: {2}. " + strExtraMessage, p_Entity.LogicalName, p_Entity.Id, e.Message);
                        }
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AggregateCount : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class AggregateAvg : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class AggregateSum : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class AggregateMin : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class AggregateMax : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class AggregateColumnCount : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class Delete : CodeActivity
    {

        #region Properties

        [Input("FetchQuery")]
        [RequiredArgument()]
        [Default("<fetch version='1.0' output-format='xml-platform' mapping='logical' no-lock='true' distinct='false'><entity name='{0}'><attribute name='{1}'/><filter type='and'><condition attribute='{2}' operator='{3}' value='{4}'/></filter></entity></fetch>")]
        public InArgument<string> FetchQuery { get; set; }

        [Input("Param {0} [entity name='{0}']")]
        [Default("account")]
        public InArgument<string> Param0 { get; set; }

        [Input("Param {1} [attribute name='{1}]")]
        [Default("accountid")]
        public InArgument<string> Param1 { get; set; }

        [Input("Param {2} [[condition attribute='{2}']")]
        [Default("name")]
        public InArgument<string> Param2 { get; set; }

        [Input("Param {3} [condition operator='{3}']")]
        [Default("eq")]
        public InArgument<string> Param3 { get; set; }

        [Input("Param {4} [condition value='{4}]")]
        [Default("ACME")]
        public InArgument<string> Param4 { get; set; }

        [Input("Param {5}")]
        [Default("")]
        public InArgument<string> Param5 { get; set; }

        [Input("Param {6}")]
        [Default("")]
        public InArgument<string> Param6 { get; set; }

        [Input("Param {7}")]
        [Default("")]
        public InArgument<string> Param7 { get; set; }

        [Input("Param {8}")]
        [Default("")]
        public InArgument<string> Param8 { get; set; }

        [Input("Param {9}")]
        [Default("")]
        public InArgument<string> Param9 { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                string fetchQuery = string.Empty;

                fetchQuery = string.Format(FetchQuery.Get(ServicesHelper.executionContext).ToString(),
                            GetValue(Param0, ServicesHelper.executionContext),
                            GetValue(Param1, ServicesHelper.executionContext),
                            GetValue(Param2, ServicesHelper.executionContext),
                            GetValue(Param3, ServicesHelper.executionContext),
                            GetValue(Param4, ServicesHelper.executionContext),
                            GetValue(Param5, ServicesHelper.executionContext),
                            GetValue(Param6, ServicesHelper.executionContext),
                            GetValue(Param7, ServicesHelper.executionContext),
                            GetValue(Param8, ServicesHelper.executionContext),
                            GetValue(Param9, ServicesHelper.executionContext));

                FetchExpression fetch = new FetchExpression(fetchQuery);

                EntityCollection records = ServicesHelper.service.RetrieveMultiple(fetch);

                if (records.Entities.Count > 0)
                {
                    foreach (Entity record in records.Entities)
                    {
                        ServicesHelper.service.Delete(record.LogicalName, record.Id);
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }


        private string GetValue(InArgument parameter, System.Activities.CodeActivityContext executionContext)
        {

            if (parameter.Get(executionContext) != null)
            {
                return parameter.Get(executionContext).ToString();
            }
            else
            {
                return string.Empty;
            }

        }

    }


    public sealed class GetFirstRecordBooleanAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordDateTimeAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordDecimalAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordDoubleAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordEntityReferenceAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordFloatAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordMoneyAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordOptionSetValueAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class GetFirstRecordStringAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class LaunchWorkflow : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class RemoveUserFromRecordTeamRequest : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class UpdateAttribute : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class SetLookup : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class SetOwnerUser : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class SetOwnerTeam : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class SetPartyList : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class SetRegardingLookup : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class SetState : CodeActivity
    {

        #region Properties

        [Input("New state code")]
        [RequiredArgument()]
        public InArgument<int> NewStateCode { get; set; }

        [Input("New status code")]
        [RequiredArgument()]
        public InArgument<int> NewStatusCode { get; set; }

        [Input("FetchQuery")]
        [RequiredArgument()]
        [Default("<fetch version='1.0' output-format='xml-platform' mapping='logical' no-lock='true' distinct='false'><entity name='{0}'><attribute name='{1}'/><filter type='and'><condition attribute='{2}' operator='{3}' value='{4}'/></filter></entity></fetch>")]
        public InArgument<string> FetchQuery { get; set; }

        [Input("Param {0} [entity name='{0}']")]
        [Default("account")]
        public InArgument<string> Param0 { get; set; }

        [Input("Param {1} [attribute name='{1}]")]
        [Default("accountid")]
        public InArgument<string> Param1 { get; set; }

        [Input("Param {2} [[condition attribute='{2}']")]
        [Default("name")]
        public InArgument<string> Param2 { get; set; }

        [Input("Param {3} [condition operator='{3}']")]
        [Default("eq")]
        public InArgument<string> Param3 { get; set; }

        [Input("Param {4} [condition value='{4}]")]
        [Default("ACME")]
        public InArgument<string> Param4 { get; set; }

        [Input("Param {5}")]
        [Default("")]
        public InArgument<string> Param5 { get; set; }

        [Input("Param {6}")]
        [Default("")]
        public InArgument<string> Param6 { get; set; }

        [Input("Param {7}")]
        [Default("")]
        public InArgument<string> Param7 { get; set; }

        [Input("Param {8}")]
        [Default("")]
        public InArgument<string> Param8 { get; set; }

        [Input("Param {9}")]
        [Default("")]
        public InArgument<string> Param9 { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            ServicesHelper.tracingService.Trace("Started execution");

            try
            {
                //Get a collection of entities based on the Fetch and on the ParamXs parameters
                string strFetchXML = System.String.Empty;
                EntityCollectionHelper p_EntityCollectionHelper = new EntityCollectionHelper();
                EntityCollection p_EntityCollection = p_EntityCollectionHelper.GetEntityCollection(
                    FetchQuery.Get(ServicesHelper.executionContext),
                    Param0, Param1, Param2, Param3, Param4, Param5, Param6, Param7, Param8, Param9, out strFetchXML);
                int intEntityCollectionCount = p_EntityCollection.Entities.Count;
                ServicesHelper.tracingService.Trace("Got a collection of " + intEntityCollectionCount + " entities based on the following Fetch: " + strFetchXML);

                //Apply the required business logic
                if (intEntityCollectionCount > 0)
                {
                    //For each entity record
                    foreach (Entity p_Entity in p_EntityCollection.Entities)
                    {
                        try
                        {
                            //Create the request
                            ServicesHelper.tracingService.Trace("Create the request for entity " + p_EntityCollection.Entities.Count + " LogicalName {0} and Id: {1}.", p_Entity.LogicalName, p_Entity.Id);
                            SetStateRequest Request = new SetStateRequest()
                            {
                                EntityMoniker = new EntityReference
                                {
                                    Id = p_Entity.Id,
                                    LogicalName = p_Entity.LogicalName,
                                },
                                State = new OptionSetValue(NewStateCode.Get(ServicesHelper.executionContext)),
                                Status = new OptionSetValue(NewStatusCode.Get(ServicesHelper.executionContext))
                            };
                            //Execute the request
                            ServicesHelper.tracingService.Trace("Execute the request for entity " + p_EntityCollection.Entities.Count + " LogicalName {0} and Id: {1}.", p_Entity.LogicalName, p_Entity.Id);
                            ServicesHelper.service.Execute(Request);
                        }
                        catch (FaultException<OrganizationServiceFault> e)
                        {
                            ServicesHelper.tracingService.Trace("Error executing the request for entity LogicalName {0} and Id: {1}. Message: {2}", p_Entity.LogicalName, p_Entity.Id, e.Message);
                        }
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }

}
