﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;

//50% finished

namespace DateTime
{

    public sealed class AddDays : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Days")]
        [RequiredArgument()]
        public InArgument<double> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.adddays.aspx?cs-save-lang=1&cs-lang=csharp#code-snippet-1")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddDays(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AddHours : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Hours")]
        [RequiredArgument()]
        public InArgument<double> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addhours.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddHours(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AddMilliseconds : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Milliseconds")]
        [RequiredArgument()]
        public InArgument<double> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addmilliseconds.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddMilliseconds(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AddMinutes : CodeActivity
    {


        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Minutes")]
        [RequiredArgument()]
        public InArgument<double> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addminutes.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion 


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddMinutes(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AddMonths : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Months")]
        [RequiredArgument()]
        public InArgument<int> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addmonths.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddMonths(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AddSeconds : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Seconds")]
        [RequiredArgument()]
        public InArgument<double> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addseconds.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddSeconds(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class AddTicks : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Ticks")]
        [RequiredArgument()]
        public InArgument<long> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addticks.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddTicks(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }

    public sealed class AddYears : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Years")]
        [RequiredArgument()]
        public InArgument<int> Value { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.addyears.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).AddYears(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Compare : CodeActivity
    {

        #region Properties

        [Input("DateTime T1")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTimeT1 { get; set; }

        [Input("DateTime T2")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTimeT2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.compare.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, System.DateTime.Compare(DateTimeT1.Get(context), DateTimeT2.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class DaysInMonth : CodeActivity
    {

        #region Properties

        [Input("Year")]
        [RequiredArgument()]
        public InArgument<int> Year { get; set; }

        [Input("Month")]
        [RequiredArgument()]
        public InArgument<int> Month { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.daysinmonth.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {


            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, System.DateTime.DaysInMonth(Year.Get(context), Month.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Equals : CodeActivity
    {

        #region Properties

        [Input("DateTime T1")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTimeT1 { get; set; }

        [Input("DateTime T2")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTimeT2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/wk5t802s.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, System.DateTime.Equals(DateTimeT1.Get(context), DateTimeT2.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class IsDaylightSavingTime : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.isdaylightsavingtime.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).IsDaylightSavingTime());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class IsLeapYear : CodeActivity
    {

        #region Properties

        [Input("Year")]
        [RequiredArgument()]
        public InArgument<int> Year { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.isleapyear.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, System.DateTime.IsLeapYear(Year.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }



    public sealed class ToLongDateString : CodeActivity
    {
        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }


        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.tolongdatestring.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).ToLongDateString());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToLongTimeString : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }


        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.tolongtimestring.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }
        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).ToLongTimeString());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToShortDateString : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.toshortdatestring.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).ToShortDateString());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToShortTimeString : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.toshorttimestring.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).ToShortTimeString());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToString : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Format")]
        [RequiredArgument()]
        public InArgument<string> Format { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/zdtaw1bw.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {


            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).ToString(Format.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class ToUniversalTime : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/system.datetime.touniversaltime.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {


            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, DateTime.Get(context).ToUniversalTime());
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }




    //Microsoft.VisualBasic methods
    public sealed class DateAdd : CodeActivity
    {

        #region Properties

        [Input("Interval [d¦y¦h¦n¦m¦q¦s¦w¦ww¦yyyy]")]
        [RequiredArgument()]
        [Default("d")]
        public InArgument<string> Interval { get; set; }

        [Input("Number")]
        [RequiredArgument()]
        [Default("0")]
        public InArgument<System.Double> Number { get; set; }

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateValue { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/c0ccadae.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.DateAdd(Interval.Get(context), Number.Get(context), DateValue.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class DateDiff : CodeActivity
    {
        #region Properties

        [Input("Interval [d¦y¦h¦n¦m¦q¦s¦w¦ww¦yyyy]")]
        [RequiredArgument()]
        public InArgument<string> Interval { get; set; }

        [Input("Date1 (From)")]
        [RequiredArgument()]
        public InArgument<System.DateTime> Date1 { get; set; }

        [Input("Date2 (To)")]
        [RequiredArgument()]
        public InArgument<System.DateTime> Date2 { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/ms127413.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<long> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.DateDiff(Interval.Get(context), Date1.Get(context), Date2.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Day : CodeActivity
    {
        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.day.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Day(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }


        }

    }


    public sealed class Hour : CodeActivity
    {
        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.hour.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }
        #endregion 


        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Hour(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Minute : CodeActivity
    {

        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.minute.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Minute(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Month : CodeActivity
    {

        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.month.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion 

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Month(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class MonthName : CodeActivity
    {

        #region Properties

        [Input("Month")]
        [RequiredArgument()]
        public InArgument<int> Month { get; set; }


        [Input("Abbreviate")]
        [Default("False")]
        public InArgument<bool> Abbreviate { get; set; }


        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.monthname.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion 

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.MonthName(Month.Get(context), Abbreviate.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Second : CodeActivity
    {

        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.second.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Second(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class WeekDay : CodeActivity
    {

        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.weekday.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Weekday(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class WeekdayName : CodeActivity
    {

        #region Properties

        [Input("Weekday")]
        [RequiredArgument()]
        public InArgument<int> Weekday { get; set; }


        [Input("Abbreviate")]
        [Default("False")]
        public InArgument<bool> Abbreviate { get; set; }


        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.weekdayname.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion 

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.WeekdayName(Weekday.Get(context), Abbreviate.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Year : CodeActivity
    {

        #region Properties

        [Input("DateValue")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Help")]
        [Default("https://msdn.microsoft.com/en-us/library/microsoft.visualbasic.dateandtime.year.aspx")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, Microsoft.VisualBasic.DateAndTime.Year(DateTime.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    //Other methods
    public sealed class AddBusinessDays : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTime { get; set; }

        [Input("Business Days")]
        [RequiredArgument()]
        public InArgument<Int32> Value { get; set; }

        [Input("Help: Add X (Business Days) to DateTime.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext executionContext)
        {


            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }
            try
            {
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                List<System.DateTime> holidaylist = new List<System.DateTime>();
                holidaylist = FetchHolidays(service, tracingService);
                Result.Set(executionContext, AddBusinessDay(DateTime.Get<System.DateTime>(executionContext), Value.Get<Int32>(executionContext), holidaylist));

            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }


        }
        private System.DateTime AddBusinessDay(System.DateTime date, int days, List<System.DateTime> holidaylist)
        {

            if (days == 0) return date;
            System.DateTime currentdate = date;
            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                date = date.AddDays(2);
                days -= 1;
            }
            else if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(1);
                days -= 1;
            }

            date = date.AddDays(days / 5 * 7);
            int extraDays = days % 5;



            //If the final day calculated is a Saturday or Sunday, 
            //it pushes the answer on to the following Monday or Tuesday respectively
            if ((int)date.DayOfWeek + extraDays > 5)
            {
                extraDays += 2;
            }

            date = date.AddDays(extraDays);

            if (holidaylist != null && holidaylist.Count > 0)
            {
                //get holidays and do the computation
                List<System.DateTime> _lstDaystoExclude = new List<System.DateTime>();
                List<System.DateTime> _lstholidaysintimeframe = new List<System.DateTime>();
                while (true)
                {
                    _lstholidaysintimeframe = holidaylist.Where(i => i >= currentdate.Date && i <= date
                    && i.DayOfWeek != DayOfWeek.Saturday && i.DayOfWeek != DayOfWeek.Sunday).ToList();
                    //exclude previously calculated holidays from the current list
                    _lstholidaysintimeframe = _lstholidaysintimeframe.Except(_lstDaystoExclude).ToList();
                    if (_lstholidaysintimeframe != null && _lstholidaysintimeframe.Count > 0)
                    {
                        //running the loop to check if there is a weekend that falls between
                        foreach (var holidayitem in _lstholidaysintimeframe)
                        {

                            date = date.AddDays(1);
                            // if last extra day that is returned is a weekend / public holiday

                            switch (date.DayOfWeek)
                            {
                                case DayOfWeek.Saturday:
                                    date = date.AddDays(2);
                                    break;
                                case DayOfWeek.Sunday:
                                    date = date.AddDays(1);
                                    break;
                                default:
                                    break;
                            }
                            _lstDaystoExclude.Add(holidayitem);
                        }
                    }
                    else
                        break;

                }
            }
            return date;
        }
        public List<System.DateTime> FetchHolidays(IOrganizationService service, ITracingService tracingService)
        {
            List<System.DateTime> _lstHolidays = new List<System.DateTime>();
            QueryExpression queryCalendar = new QueryExpression("calendar");
            queryCalendar.NoLock = true;
            queryCalendar.ColumnSet = new ColumnSet(true);//calendar rules attribute is not directly queryable hence fetching all attributes
            queryCalendar.Criteria.AddCondition(new ConditionExpression("type", ConditionOperator.Equal, 2));//type 2 is holiday
                                                                                                             // can fetch based on the name of the holiday schedule if reqd
            EntityCollection holidayCollection = service.RetrieveMultiple(queryCalendar);
            if (holidayCollection != null && holidayCollection.Entities != null && holidayCollection.Entities.Count > 0)
            {
                foreach (var item in holidayCollection.Entities)
                {
                    EntityCollection calendarrules = item.Contains("calendarrules") ? item.GetAttributeValue<EntityCollection>("calendarrules") : null;
                    if (calendarrules != null && calendarrules.Entities.Count > 0)
                    {
                        foreach (var holidayitem in calendarrules.Entities)
                        {
                            System.DateTime startDate = holidayitem.GetAttributeValue<System.DateTime>("starttime");
                            System.DateTime endDate = holidayitem.GetAttributeValue<System.DateTime>("effectiveintervalend");
                            var noofDays = endDate.Date.Subtract(startDate.Date).Days;
                            _lstHolidays.Add(startDate);//assuming start date will always be a non weekend day

                            /* logic if we are to consider consecutive days*/
                            noofDays -= 1;//decrement the added day from the total range

                            while (noofDays > 0)
                            {
                                startDate = startDate.AddDays(1);
                                switch (startDate.DayOfWeek)
                                {
                                    case DayOfWeek.Saturday:
                                        startDate = startDate.AddDays(2);
                                        noofDays -= 2;
                                        break;
                                    case DayOfWeek.Sunday:
                                        startDate = startDate.AddDays(1);
                                        noofDays -= 1;
                                        break;
                                    default:
                                        break;
                                }
                                _lstHolidays.Add(startDate);
                                noofDays -= 1;
                            }
                        }
                    }
                    else
                        tracingService.Trace("calendar rules is null");
                }
            }
            else
            {
                tracingService.Trace("No holidays present");
            }
            return _lstHolidays;
        }

    }


    public sealed class DiffWorkingDays : CodeActivity
    {

        #region Properties

        [Input("StartDate")]
        [RequiredArgument()]
        public InArgument<System.DateTime> StartDate { get; set; }

        [Input("EndDate")]
        [RequiredArgument()]
        public InArgument<System.DateTime> EndDate { get; set; }

        [Input("Help: Returns the number of working days between two dates.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }
        
        #endregion 


        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }


        public List<System.DateTime> GetHolidays()
        {
            var client = new System.Net.WebClient();
            var json = client.DownloadString("https://www.gov.uk/bank-holidays.json");
            //TODO: Use proper .NET 4.6 method
            //var js = new JavaScriptSerializer();
            //var holidays = js.Deserialize<Dictionary<string, Holidays>>(json);
            //return holidays["england-and-wales"].events.Select(d => d.date).ToList();
            return null;
        }

        public int GetWorkingDays(System.DateTime from, System.DateTime to)
        {
            var totalDays = 0;
            var holidays = GetHolidays();
            for (var date = from.AddDays(1); date <= to; date = date.AddDays(1))
            {
                if (date.DayOfWeek != DayOfWeek.Saturday
                    && date.DayOfWeek != DayOfWeek.Sunday
                    && !holidays.Contains(date))
                    totalDays++;
            }

            return totalDays;
        }
        public class Holidays
        {
            public string division { get; set; }
            public List<Event> events { get; set; }
        }

        public class Event
        {
            public System.DateTime date { get; set; }
            public string notes { get; set; }
            public string title { get; set; }
        }

    }

    
    public sealed class IsWorkingDay : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTim { get; set; }

        [Input("Help: Returns true if the passed date is a working day.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }


    public sealed class NextWorkingDay : CodeActivity
    {

        #region Properties

        [Input("DateTime")]
        [RequiredArgument()]
        public InArgument<System.DateTime> DateTim { get; set; }

        [Input("Help: Returns the next working day given a date to start from and a number of minutes to increment by.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion 


        protected override void Execute(CodeActivityContext context)
        {
            throw new NotImplementedException();
        }
    }

}
