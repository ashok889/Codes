﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;
using System.Net;
//100%

namespace Geolocation
{


    public class DistanceBetweenCoordinates : CodeActivity
    {

        #region Properties

        [Input("Latitude 1")]
        [RequiredArgument()]
        public InArgument<decimal> Latitude1 { get; set; }

        [Input("Longitude 1")]
        [RequiredArgument()]
        public InArgument<decimal> Longitude1 { get; set; }

        [Input("Latitude 2")]
        [RequiredArgument()]
        public InArgument<decimal> Latitude2 { get; set; }

        [Input("Longitude 2")]
        [RequiredArgument()]
        public InArgument<decimal> Longitude2 { get; set; }

        [Output("Result")]
        public OutArgument<decimal> Result { get; set; }

        #endregion

        protected override void Execute(System.Activities.CodeActivityContext context)
        {

            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                decimal lat1 = Latitude1.Get(context);
                decimal lon1 = Longitude1.Get(context);
                decimal lat2 = Latitude2.Get(context);
                decimal lon2 = Longitude2.Get(context);

                if ((lat1 == 0) || (lon1 == 0) || (lat2 == 0) || (lon2 == 0))
                {
                    Result.Set(context, -1);
                }
                else
                {
                    Result.Set(context, DistanceBetweenCoordinatesX(lat1, lon1, lat2, lon2));
                }

            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }



        /// <summary>
        /// </summary>
        /// <param name="lat1"></param>
        /// <param name="long1"></param>
        /// <param name="lat2"></param>
        /// <param name="long2"></param>
        /// <returns></returns>
        public static decimal DistanceBetweenCoordinatesX(decimal lat1, decimal lon1, decimal lat2, decimal lon2)
        {
            try
            {
                decimal r = 6378.137M;

                decimal pi = (decimal)(System.Math.PI);

                decimal dLat = (lat2 - lat1) * pi / 180;
                decimal dLong = (lon2 - lon1) * pi / 180;

                decimal a = (decimal)(System.Math.Sin((double)(dLat / 2)) * System.Math.Sin((double)(dLat / 2)) +
                                      System.Math.Cos((double)(lat1 * pi / 180)) * System.Math.Cos((double)(lat2 * pi / 180)) *
                                      System.Math.Sin((double)(dLong / 2)) * System.Math.Sin((double)(dLong / 2)));

                decimal c = (decimal)(2 * System.Math.Atan2(System.Math.Sqrt((double)a), System.Math.Sqrt((double)(1 - a))));

                return (r * c);
            }
            catch
            {
                return -1;
            }

        }


    }

    public class GetCoordinatesFromAddress : CodeActivity
    {

        #region Properties

        [Input("Force composite address?")]
        [RequiredArgument()]
        public InArgument<Boolean> UseCompositeAddress { get; set; }

        [Input("Line1")]
        public InArgument<string> Line1 { get; set; }

        [Input("Line2")]
        public InArgument<string> Line2 { get; set; }

        [Input("Line3")]
        public InArgument<string> Line3 { get; set; }

        [Input("Postal code")]
        public InArgument<string> PostalCode { get; set; }

        [Input("City")]
        public InArgument<string> City { get; set; }

        [Input("Province")]
        public InArgument<string> Province { get; set; }

        [Input("Country BSCH code")]
        public InArgument<string> Country { get; set; }

        [Input("Composite address")]
        public InArgument<string> CompositeAddress { get; set; }

        [Input("Bing maps api key")]
        [RequiredArgument()]
        public InArgument<string> BingMapsKey { get; set; }

        [Output("Latitude")]
        public OutArgument<decimal> Latitude { get; set; }

        [Output("Longitude")]
        public OutArgument<decimal> Longitude { get; set; }

        #endregion


        protected override void Execute(System.Activities.CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {

                string lat = System.String.Empty;
                string lon = System.String.Empty;

                string bingMapsKey = BingMapsKey.Get(context);

                System.Xml.XmlReader xmlReader = null;

                if ((bool)(UseCompositeAddress.Get(context)))
                {
                    string compositeAddress =
                            (!string.IsNullOrEmpty(CompositeAddress.Get(context))) ?
                            CompositeAddress.Get(context) :
                            string.Empty;

                    xmlReader = GetCoordinatesFromCompositeAddress(compositeAddress, bingMapsKey);
                }
                else
                {
                    xmlReader =
                        GetCoordinatesFromAddressFields(
                            Line1.Get(context),
                            Line2.Get(context),
                            Line3.Get(context),
                            PostalCode.Get(context),
                            City.Get(context),
                            Province.Get(context),
                            Country.Get(context),
                            bingMapsKey);
                }

                if (xmlReader != null)
                {
                    try
                    {
                        if (xmlReader.ReadToFollowing("Latitude"))
                        {
                            lat = xmlReader.ReadElementContentAsString();

                            Latitude.Set(context, decimal.Parse(lat));
                        }

                        if (xmlReader.ReadToFollowing("Longitude"))
                        {
                            lon = xmlReader.ReadElementContentAsString();

                            Longitude.Set(context, decimal.Parse(lon));
                        }
                    }
                    catch
                    {
                        Latitude.Set(context, 0);
                        Longitude.Set(context, 0);
                    }

                }
                else
                {
                    Latitude.Set(context, 0);
                    Longitude.Set(context, 0);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }


        public static System.Xml.XmlReader GetCoordinatesFromCompositeAddress(string address, string bingMapsKey)
        {
            address = (!string.IsNullOrEmpty(address)) ? address.Trim() : string.Empty;

            string locationsRequest = System.String.Format(@"http://dev.virtualearth.net/REST/v1/Locations/?q={0}&o=xml&key={1}", address, bingMapsKey);

            return GetResponse(locationsRequest);

        }

        public static System.Xml.XmlReader GetCoordinatesFromAddressFields(string line1,
                                                                string line2,
                                                                string line3,
                                                                string postalcode,
                                                                string city,
                                                                string province,
                                                                string country,
                                                                string bingMapsKey)
        {
            line1 = (!string.IsNullOrEmpty(line1)) ? line1.Trim() : string.Empty;
            line2 = (!string.IsNullOrEmpty(line2)) ? line2.Trim() : string.Empty;
            line3 = (!string.IsNullOrEmpty(line3)) ? line3.Trim() : string.Empty;
            postalcode = (!string.IsNullOrEmpty(postalcode)) ? postalcode.Trim() : string.Empty;
            city = (!string.IsNullOrEmpty(city)) ? city.Trim() : string.Empty;
            province = (!string.IsNullOrEmpty(province)) ? province.Trim() : string.Empty;
            country = (!string.IsNullOrEmpty(country)) ? country.Trim() : string.Empty;

            string address_line = (line1 + " " + line2 + " " + line3).Trim();

            string locationsRequest =
                System.String.Format(@"http://dev.virtualearth.net/REST/v1/Locations?CountryRegion={0}&adminDistrict={1}&locality={2}&postalCode={3}&addressLine={4}&o=xml&key={5}", country, province, city, postalcode, address_line, bingMapsKey);

            return GetResponse(locationsRequest);

        }


        public static System.Xml.XmlReader GetResponse(string requestUrl)
        {
            try
            {
                HttpWebRequest httpWebRequest = (HttpWebRequest)HttpWebRequest.Create(requestUrl);

                using (HttpWebResponse httpWebReponse = (HttpWebResponse)httpWebRequest.GetResponse())
                {
                    if (httpWebReponse.StatusCode == HttpStatusCode.OK)
                    {
                        return System.Xml.XmlReader.Create(httpWebReponse.GetResponseStream());
                    }
                    else
                    {
                        return null;
                    }

                }
            }
            catch
            {
                return null;
            }

        }

    }

}
