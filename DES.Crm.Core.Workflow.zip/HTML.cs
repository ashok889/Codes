﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;
using Microsoft.Xrm.Sdk.Query;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;

namespace HTML
{

    public sealed class CleanHtmlCode : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Retuns Value after cleaning HTML")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, CleanHtmlCodeRet(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        private static string CleanHtmlCodeRet(string Value)
        {

            System.Text.RegularExpressions.Regex Rgx = new System.Text.RegularExpressions.Regex(@"\n\s*\n");

            var strTidyHTML = Value;

            try
            {
                var strCleanHTML = System.Net.WebUtility.HtmlDecode(strTidyHTML);
                var strCleanedHTML = CleanHTML(strCleanHTML);

                if (strCleanedHTML != null)
                {
                    strCleanedHTML = Rgx.Replace(strCleanedHTML, "\n");
                }

                return strCleanedHTML;
            }
            catch (Exception)
            {
                return strTidyHTML;
            }

        }

        private static string CleanHTML(string Value)
        {

            string strHTML = Value;
            System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"<body[^>]*>(.*?)</body>", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Singleline);

            System.Text.RegularExpressions.Match m = rx.Match(Value);

            if (m.Success)
            {
                strHTML = m.Groups[1].Value;
            }

            strHTML = StripHTML(strHTML);

            return strHTML;

        }

        private static string StripHTML(string Value)
        {

            string HtmlTagPattern = "<.*?>";

            Value = Value.Replace("<br>", "\r\n");
            Value = Value.Replace("<br />", "\r\n");
            Value = Value.Replace("<br/>", "\r\n");

            string HtmlSinTags = System.Text.RegularExpressions.Regex.Replace(Value, HtmlTagPattern, string.Empty);

            return HtmlSinTags.Replace("&nbsp;", " ");

        }
    }


    /// <summary>
    /// Construye un hyperlink de la entidad primaria del proceso o de sus entidades relacionadas (N:1).
    /// </summary>
    public class CreateHyperLink : CodeActivity
    {

        #region Properties

        [RequiredArgument]
        [Input("URL of the CRM Organization (e.g. 'http://mycrm/myOrg'")]
        public InArgument<string> OrganizationUrl { get; set; }

        [RequiredArgument]
        [Input("HyperLink to primary entity (True) or related entity (False)")]
        public InArgument<bool> PrimaryEntity { get; set; }

        [Input("If creating hyperling to related entity, specify attribute name to get the related entity")]
        public InArgument<string> RelatedAttributeName { get; set; }

        [Input("HyperLink text. If not provided, entity primary field name will be used.")]
        public InArgument<string> HyperLinkText { get; set; }

        [Output("HtmlHyperLink")]
        public OutArgument<string> HtmlHyperLink { get; set; }

        [Output("DialogHyperLink")]
        public OutArgument<string> DialogHyperLink { get; set; }

        #endregion


        #region Private members

        private static string UrlFormat = @"{0}/main.aspx?etn={1}&pagetype=entityrecord&id=%7B{2}%7D";
        private static string HyperLinkFormat = @"<a href='{0}'>{1}</a>";
        private static string DialogLinkFormat = @"<hyperlink><name>{0}</name><value>{1}</value></hyperlink>";

        #endregion

        protected override void Execute(CodeActivityContext context)
        {


            //Create a new Services Helper class
            //ServicesHelper p_ServicesHelper = new ServicesHelper(executionContext);
            ServicesHelper.ServicesHelperExt(context);

            try
            {
            //Apply the required business logic
            if (PrimaryEntity.Get(ServicesHelper.executionContext))
            {
                GenerateHyperLink(new EntityReference(ServicesHelper.context.PrimaryEntityName, ServicesHelper.context.PrimaryEntityId), ServicesHelper.executionContext, ServicesHelper.service, ServicesHelper.tracingService);
            }
            else
            {
                string relatedAttribute = RelatedAttributeName.Get(ServicesHelper.executionContext);
                if (string.IsNullOrEmpty(relatedAttribute))
                {
                    string srtExtraMessage = "If creating hyperlink to related entity, related attribute name must be specified in the process step configuration.";
                    ExceptionManager.ManageBasicFaultException(srtExtraMessage, null, ServicesHelper.tracingService);
                }

                // Retrieve primary entity with the required attribute
                ServicesHelper.tracingService.Trace("Retrieving process primary entity");
                Entity primaryEntity = ServicesHelper.service.Retrieve(ServicesHelper.context.PrimaryEntityName, ServicesHelper.context.PrimaryEntityId, new ColumnSet(relatedAttribute));

                if (primaryEntity.Contains(relatedAttribute))
                {
                    EntityReference reference = primaryEntity[relatedAttribute] as EntityReference;
                    if (reference == null)
                    {
                        string srtExtraMessage = string.Format("The attribute {0} on entity {1} is expected to be of EntityReference type.", relatedAttribute, ServicesHelper.context.PrimaryEntityName);
                        ExceptionManager.ManageBasicFaultException(srtExtraMessage, null, ServicesHelper.tracingService);
                    }

                    ServicesHelper.tracingService.Trace("Creating hyperlink to entity related to primary entity by attribute " + relatedAttribute);
                    GenerateHyperLink(reference, ServicesHelper.executionContext, ServicesHelper.service, ServicesHelper.tracingService);
                    }

                }

            }
        catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        private void GenerateHyperLink(EntityReference entityReference, CodeActivityContext context, IOrganizationService service, ITracingService tracer)
        {
            string url = string.Format( 
                CultureInfo.InvariantCulture, 
                UrlFormat,
                OrganizationUrl.Get(context),
                entityReference.LogicalName,
                entityReference.Id);

            string hyperLinkText = HyperLinkText.Get(context);
            if (string.IsNullOrEmpty(hyperLinkText))
            {
                tracer.Trace("Retrieving primary field of entity to use as hyperlink text.");
                hyperLinkText = GetHyperLinkText(entityReference, service);
            }
            string htmlHyperLink = string.Format(
                CultureInfo.InvariantCulture, 
                HyperLinkFormat,
                url,
                hyperLinkText);
                HtmlHyperLink.Set(context, htmlHyperLink);

            string dialogHyperLink = string.Format(
                CultureInfo.InvariantCulture, 
                DialogLinkFormat,
                hyperLinkText,
                url);

            DialogHyperLink.Set(context, dialogHyperLink);
        }

        private string GetHyperLinkText(EntityReference entityReference, IOrganizationService service)
        {
            RetrieveEntityRequest req = new RetrieveEntityRequest
            {
                LogicalName = entityReference.LogicalName,
            };
            RetrieveEntityResponse resp = (RetrieveEntityResponse)service.Execute(req);

            Entity entity = service.Retrieve(entityReference.LogicalName, entityReference.Id, new ColumnSet(resp.EntityMetadata.PrimaryNameAttribute));
            string text = entity[resp.EntityMetadata.PrimaryNameAttribute] as string;
            if (string.IsNullOrEmpty(text))
            {
                // Default text if none specified and entity does not have primary field
                text = "HyperLink";
            }
            return text;
        }

    }


    /// <summary>
    /// Returns Value without NonAsciiChars.
    /// </summary>
    public sealed class ReplaceNonAsciiChars : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Returns Value without NonAsciiChars.")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {



            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                //Apply the required business logic
                Result.Set(context, ReplaceNonAsciiCharsRet(Value.Get(context)));
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

        private static string ReplaceNonAsciiCharsRet(string Value)
        {

            Value = System.Text.RegularExpressions.Regex.Replace(Value, @"[^\u0000-\u007F]+", string.Empty);

            //Value = Value.Replace("–", "");
            //Value = Value.Replace("—", "");
            //Value = Value.Replace("¡", "");
            //Value = Value.Replace("¿", "");
            //Value = Value.Replace("'", "");
            //Value = Value.Replace("‘", "");
            //Value = Value.Replace("’", "");
            //Value = Value.Replace("«", "");
            //Value = Value.Replace("»", "");
            //Value = Value.Replace("&", "");
            //Value = Value.Replace("¢", "");
            //Value = Value.Replace("©", "");
            //Value = Value.Replace("÷", "");
            //Value = Value.Replace(">", "");
            //Value = Value.Replace("<", "");
            //Value = Value.Replace("µ", "");
            //Value = Value.Replace("·", "");
            //Value = Value.Replace("¶", "");
            //Value = Value.Replace("±", "");
            //Value = Value.Replace("€", "");
            //Value = Value.Replace("£", "");
            //Value = Value.Replace("®", "");
            //Value = Value.Replace("§", "");
            //Value = Value.Replace("™", "");
            //Value = Value.Replace("¥", "");
            //Value = Value.Replace("á", "a");
            //Value = Value.Replace("Á", "A");
            //Value = Value.Replace("à", "a");
            //Value = Value.Replace("À", "A");
            //Value = Value.Replace("â", "a");
            //Value = Value.Replace("Â", "A");
            //Value = Value.Replace("å", "a");
            //Value = Value.Replace("Å", "A");
            //Value = Value.Replace("ã", "a");
            //Value = Value.Replace("Ã", "A");
            //Value = Value.Replace("ä", "a");
            //Value = Value.Replace("Ä", "A");
            //Value = Value.Replace("æ", "ae");
            //Value = Value.Replace("Æ", "AE");
            //Value = Value.Replace("ç", "c");
            //Value = Value.Replace("Ç", "C");
            //Value = Value.Replace("é", "e");
            //Value = Value.Replace("É", "I");
            //Value = Value.Replace("è", "e");
            //Value = Value.Replace("È", "I");
            //Value = Value.Replace("ê", "e");
            //Value = Value.Replace("Ê", "I");
            //Value = Value.Replace("ë", "e");
            //Value = Value.Replace("Ë", "I");
            //Value = Value.Replace("í", "i");
            //Value = Value.Replace("Í", "I");
            //Value = Value.Replace("ì", "i");
            //Value = Value.Replace("Ì", "I");
            //Value = Value.Replace("î", "i");
            //Value = Value.Replace("Î", "I");
            //Value = Value.Replace("ï", "i");
            //Value = Value.Replace("Ï", "I");
            //Value = Value.Replace("ñ", "n");
            //Value = Value.Replace("Ñ", "N");
            //Value = Value.Replace("ó", "o");
            //Value = Value.Replace("Ó", "O");
            //Value = Value.Replace("ò", "o");
            //Value = Value.Replace("Ò", "O");
            //Value = Value.Replace("ô", "o");
            //Value = Value.Replace("Ô", "O");
            //Value = Value.Replace("ø", "o");
            //Value = Value.Replace("Ø", "O");
            //Value = Value.Replace("õ", "o");
            //Value = Value.Replace("Õ", "O");
            //Value = Value.Replace("ö", "o");
            //Value = Value.Replace("Ö", "O");
            //Value = Value.Replace("ß", "");
            //Value = Value.Replace("ú", "u");
            //Value = Value.Replace("Ú", "U");
            //Value = Value.Replace("ù", "u");
            //Value = Value.Replace("Ù", "U");
            //Value = Value.Replace("û", "u");
            //Value = Value.Replace("Û", "U");
            //Value = Value.Replace("ü", "u");
            //Value = Value.Replace("Ü", "U");
            //Value = Value.Replace("ÿ", "y");
            //Value = Value.Replace("´", "");
            //Value = Value.Replace("`", "");

            //Value = Value.Replace(".", "");
            //Value = Value.Replace(".", "");
            //Value = Value.Replace("\"", "");
            //Value = Value.Replace("#", "");
            //Value = Value.Replace("%", "");
            //Value = Value.Replace("&", "");
            //Value = Value.Replace("*", "");
            //Value = Value.Replace(":", "");
            //Value = Value.Replace(">", "");
            //Value = Value.Replace("<", "");
            //Value = Value.Replace("?", "");
            //Value = Value.Replace("/", "");
            //Value = Value.Replace("\\", "");
            //Value = Value.Replace("{", "");
            //Value = Value.Replace("|", "");
            //Value = Value.Replace("}", "");

            //Value = Value.Replace("@", "");
            //Value = Value.Replace("·", "");
            //Value = Value.Replace("$", "");
            //Value = Value.Replace("€", "");
            //Value = Value.Replace("¡", "");
            //Value = Value.Replace("¿", "");
            //Value = Value.Replace("+", "");
            //Value = Value.Replace("`", "");
            //Value = Value.Replace("^", "");
            //Value = Value.Replace(",", "");
            //Value = Value.Replace(";", "");

            return Value;

        }

    }



}
