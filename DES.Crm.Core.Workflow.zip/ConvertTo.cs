﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;

//100% finished

namespace ConvertTo
{

    public sealed class Bool : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Converts Value to Boolean")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {

                bool resultTryParse;

                if (bool.TryParse(Value.Get(context), out resultTryParse))
                {
                    Result.Set(context, resultTryParse);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class DateTime : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Converts Value to Boolean")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<System.DateTime> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {

                System.DateTime resultTryParse;
                 
                if (System.DateTime.TryParse(Value.Get(context), out resultTryParse))
                {
                    Result.Set(context, resultTryParse);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Decimal : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Converts Value to Decimal")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<decimal> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {

                System.Decimal resultTryParse;

                if (System.Decimal.TryParse(Value.Get(context), out resultTryParse))
                {
                    Result.Set(context, resultTryParse);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Double : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Converts Value to Double")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<double> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                System.Double resultTryParse;

                if (System.Double.TryParse(Value.Get(context), out resultTryParse))
                {
                    Result.Set(context, resultTryParse);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Int : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Converts Value to Int")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<int> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {

                int resultTryParse;
                 

                if (int.TryParse(Value.Get(context), out resultTryParse))
                {
                    Result.Set(context, resultTryParse);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Float : CodeActivity
    {

        #region Properties

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Help: Converts Value to Float")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<float> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            try
            {

                float resultTryParse;

                if (float.TryParse(Value.Get(context), out resultTryParse))
                {
                    Result.Set(context, resultTryParse);
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }

}
