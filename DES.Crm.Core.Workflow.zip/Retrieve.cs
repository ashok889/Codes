﻿using Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retrieve
{
    public sealed class RetrieveQueue : CodeActivity
    {
        [Input("FetchQuery")]
        [RequiredArgument()]
        [Default("<fetch version='1.0' output-format='xml-platform' mapping='logical' no-lock='true' distinct='false'><entity name = '{0}' ><attribute name = '{1}' /><filter type = 'and' ><condition attribute = '{2}' operator= '{3}' value = '{4}' /></filter></entity></fetch>")]
        public InArgument<string> FetchQuery { get; set; }

     

        [Input("Param {0} [entity name='{0}']")]
        [Default("queue")]
        public InArgument<string> Param0 { get; set; }

        [Input("Param {1} [attribute name='{1}]")]
        [Default("queueid")]
        public InArgument<string> Param1 { get; set; }

        [Input("Param {2} [[condition attribute='{2}']")]
        [Default("name")]
        public InArgument<string> Param2 { get; set; }

        [Input("Param {3} [condition operator='{3}']")]
        [Default("eq")]
        public InArgument<string> Param3 { get; set; }

        [Input("Param {4} [condition value='{4}]")]
        [Default("queue name")]
        public InArgument<string> Param4 { get; set; }

        [Input("Param {5}")]
        [Default("")]
        public InArgument<string> Param5 { get; set; }

        [Input("Param {6}")]
        [Default("")]
        public InArgument<string> Param6 { get; set; }

        [Input("Param {7}")]
        [Default("")]
        public InArgument<string> Param7 { get; set; }

        [Input("Param {8}")]
        [Default("")]
        public InArgument<string> Param8 { get; set; }

        [Input("Param {9}")]
        [Default("")]
        public InArgument<string> Param9 { get; set; }
        [Output("Queue")]
        [ReferenceTarget("queue")]
        public OutArgument<EntityReference> Queue { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            ServicesHelper.ServicesHelperExt(context);

            try
            {
                if (context == null)
                {
                    throw new ArgumentNullException("context");
                }

                string strFetchXML = System.String.Empty;
                EntityCollectionHelper p_EntityCollectionHelper = new EntityCollectionHelper();
                EntityCollection p_EntityCollection = p_EntityCollectionHelper.GetEntityCollection(
                    FetchQuery.Get(ServicesHelper.executionContext),
                    Param0, Param1, Param2, Param3, Param4, Param5, Param6, Param7, Param8, Param9, out strFetchXML);
                ServicesHelper.tracingService.Trace("Got a collection of entities based on the following Fetch: " + strFetchXML);

               if(p_EntityCollection!=null && p_EntityCollection.Entities!=null && p_EntityCollection.Entities.Count>0)
                {
                    Queue.Set(context, p_EntityCollection.Entities[0].ToEntityReference());
                }
            }
            catch (Exception e)
            {
                throw new InvalidPluginExecutionException("Error: " + e.Message);
            }
        }
    }
}
