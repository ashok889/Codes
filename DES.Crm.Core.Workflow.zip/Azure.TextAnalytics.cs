﻿using System;
using System.Activities;
using System.ServiceModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Net;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System.Runtime.Serialization;
using Helpers;

//http://dynamicscrmcoe.com/microsoft-cognitive-services-text-analytics-recognition/
//https://azure.microsoft.com/en-us/services/cognitive-services/text-analytics/
//https://westus.dev.cognitive.microsoft.com/docs/services/TextAnalytics.V2.0/operations/56f30ceeeda5650db055a3c7

namespace Azure.TextAnalytics
{

    public sealed class DetectLanguage : CodeActivity
    {

        #region Properties

        [Input("Text")]
        [RequiredArgument()]
        public InArgument<string> Text { get; set; }

        [Input("Number Of Languages To Detect")]
        [RequiredArgument()]
        [Default("1")]
        public InArgument<int> numberOfLanguagesToDetect { get; set; }

        [Input("Subscription Key")]
        [RequiredArgument()]
        public InArgument<string> OcpApimSubscriptionKey { get; set; }

        [Input("Language. Default=en [en, fr, es, pt]")]
        [RequiredArgument()]
        [Default("en")]
        public InArgument<string> Language { get; set; }

        [Input("Help: returns the detected language and a numeric score between 0 and 1.")]
        [Default("https://westus.dev.cognitive.microsoft.com/docs/services/TextAnalytics.V2.0/operations/56f30ceeeda5650db055a3c7")]
        public InArgument<string> Help { get; set; }

        [Output("Result: Name")]
        public OutArgument<string> ResultName { get; set; }

        [Output("Result: ISO 6391 Name")]
        public OutArgument<string> ResultISO6391Name { get; set; }

        [Output("Result: ISO 6391 Name")]
        public OutArgument<double> ResultScore { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {

            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            string strResult = System.String.Empty;

            try
            {
                //Apply the required business logic
                ResultName.Set(context, strResult);
                ResultISO6391Name.Set(context, strResult);
                ResultScore.Set(context, strResult);
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class DetectTopics : CodeActivity
    {

        #region Properties

        [Input("Text")]
        [RequiredArgument()]
        public InArgument<string> Text { get; set; }

        [Input("Min. Documents Per Word")]
        public InArgument<int> minDocumentsPerWord { get; set; }

        [Input("Max. Documents Per Word")]
        public InArgument<int> maxDocumentsPerWord { get; set; }

        [Input("Subscription Key")]
        [RequiredArgument()]
        public InArgument<string> OcpApimSubscriptionKey { get; set; }

        [Input("Help: Returns the top detected topics for a list of submitted text documents.")]
        [Default("https://westus.dev.cognitive.microsoft.com/docs/services/TextAnalytics.V2.0/operations/56f30ceeeda5650db055a3ca")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {



            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            string strResult = System.String.Empty;

            try
            {
                //Apply the required business logic
                Result.Set(context, strResult);
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class KeyPhrases : CodeActivity
    {

        #region Properties

        [Input("Text")]
        [RequiredArgument()]
        public InArgument<string> Text { get; set; }

        [Input("Subscription Key")]
        [RequiredArgument()]
        public InArgument<string> OcpApimSubscriptionKey { get; set; }

        [Input("Language. Default=en [en, fr, es, pt]")]
        [RequiredArgument()]
        [Default("en")]
        public InArgument<string> Language { get; set; }


        [Input("Help: Returns a list of strings denoting the key talking points in the input text.")]
        [Default("https://westus.dev.cognitive.microsoft.com/docs/services/TextAnalytics.V2.0/operations/56f30ceeeda5650db055a3c6")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext context)
        {

            
            //Create a new Services Helper class
            ServicesHelper.ServicesHelperExt(context);

            string strResult = System.String.Empty;

            try
            {
                //Apply the required business logic
                Result.Set(context, strResult);
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }

    }


    public sealed class Sentiment : CodeActivity
    {

        #region Properties

        /// <summary>
        /// text to analyze
        /// </summary>
        [Input("Text")]
        [RequiredArgument()]
        public InArgument<string> Text { get; set; }

        /// <summary>
        /// azure text analytics access key 
        /// </summary>
        [Input("Subscription Key")]
        [RequiredArgument()]
        public InArgument<string> OcpApimSubscriptionKey { get; set; }

        [Input("Language. Default=en [en, fr, es, pt]")]
        [RequiredArgument()]
        [Default("en")]
        public InArgument<string> Language { get; set; }

        [Input("Help: Returns a numeric score between 0 (bad) and 1 (good).")]
        [Default("https://westus.dev.cognitive.microsoft.com/docs/services/TextAnalytics.V2.0/operations/56f30ceeeda5650db055a3c9")]
        public InArgument<string> Help { get; set; }

        /// <summary>
        /// sentiment score - numbers closer to 1 are more positive, numbers closer to 0 are more negative
        /// </summary>
        [Output("Result")]
        public OutArgument<decimal> Result { get; set; }

        #endregion


        //web service address
        private string _webAddress = "https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/sentiment";

        //name of your custom workflow activity for tracing/error logging
        private string _activityName = "AnalyzeSentiment";

        /// <summary>
        /// Executes the workflow activity.
        /// </summary>
        /// <param name="executionContext">The execution context.</param>
        protected override void Execute(CodeActivityContext context)
        {

            ServicesHelper.ServicesHelperExt(context);

            string strResult = System.String.Empty;

            try
            {
                string inputText = Text.Get(context);
                if (inputText != string.Empty)
                {
                    //strip any html characters from the text to analyze
                    inputText = StripHTML(inputText);
                    ServicesHelper.tracingService.Trace(string.Format("stripped text: {0}", inputText));

                    //escape any double quote characters (") so they don't cause problems when posting the json later
                    string escapedText = inputText.Replace("\"", "\\\"");
                    ServicesHelper.tracingService.Trace(string.Format("escaped text: {0}", escapedText));

                    //create the webrequest object
                    HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(_webAddress);

                    //set request content type so it is treated as a regular form post
                    req.ContentType = "application/json";

                    //set method to post
                    req.Method = "POST";

                    //buld the request
                    StringBuilder postData = new StringBuilder();

                    //note the Id value set to 1 - we can hardcode this because we're only sending a batch of one
                    var postStr = "{\"documents\":[{\"id\":\"1\",\"text\":\"" + escapedText + "\"}]}";
                    ServicesHelper.tracingService.Trace(string.Format("Post Data: {0}", postStr));
                    postData.Append(postStr);

                    req.Headers["Ocp-Apim-Subscription-Key"] = OcpApimSubscriptionKey.Get(context);
                    //set the authentication using the azure service access key
                    string authInfo = "AccountKey:" + OcpApimSubscriptionKey.Get(context);
                    authInfo = Convert.ToBase64String(Encoding.Default.GetBytes(authInfo));
                    req.Headers["Authorization"] = "Basic " + authInfo;

                    //create a stream
                    byte[] bytes = Encoding.ASCII.GetBytes(postData.ToString());
                    req.ContentLength = bytes.Length;
                    Stream os = req.GetRequestStream();
                    os.Write(bytes, 0, bytes.Length);
                    os.Close();

                    //post the request and get the response
                    WebResponse resp = req.GetResponse();

                    //deserialize the response to a SentimentBatchResult object
                    DocumentsResult sentimentResult = new DocumentsResult();
                    System.Runtime.Serialization.Json.DataContractJsonSerializer deserializer = new System.Runtime.Serialization.Json.DataContractJsonSerializer(sentimentResult.GetType());
                    sentimentResult = deserializer.ReadObject(resp.GetResponseStream()) as DocumentsResult;

                    //if no errors, return the sentiment
                    if (sentimentResult.Errors.Count == 0)
                    {
                        //set output values from the fields of the deserialzed myjsonresponse object
                        Result.Set(context, sentimentResult.Documents[0].Score);
                    }
                    else
                    {
                        //otherwise raise an exception with the returned error message
                        throw new InvalidPluginExecutionException(System.String.Format("Sentiment analyis error: {0)", sentimentResult.Errors[0].Message));
                    }
                }

                //Apply the required business logic
                Result.Set(context, strResult);
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exception
                ExceptionManager.ManageBasicFaultException("", e, ServicesHelper.tracingService);
            }

        }
        public string StripHTML(string input)
        {
            return System.Text.RegularExpressions.Regex.Replace(input, "<.*?>", System.String.Empty);
        }

    }


    
    /// <summary>
    /// class to represent sentiment result batch response
    /// </summary>
    [DataContract]
    public class DocumentsResult
    {
        [DataMember(Name = "documents")]
        public List<SentimentBatchResultItem> Documents { get; set; }

        [DataMember(Name = "errors")]
        public List<ErrorRecord> Errors { get; set; }
    }



    /// <summary>
    /// class to represent invidual error item
    /// </summary>
    [DataContract]
    public class ErrorRecord
    {
        [DataMember(Name = "id")]
        public string Id { get; set; }

        [DataMember(Name = "message")]
        public string Message { get; set; }
    }


    /// <summary>
    /// class to represent invidual sentiment result item
    /// </summary>
    [DataContract]
    public class SentimentBatchResultItem
    {
        [DataMember(Name = "score")]
        public Decimal Score { get; set; }

        [DataMember(Name = "id")]
        public string Id { get; set; }
    }

}
