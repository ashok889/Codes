﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Helpers;


namespace Configuration
{

    public sealed class Read : CodeActivity
    {

        #region Properties

        [Input("Key")]
        [RequiredArgument()]
        public InArgument<string> Key { get; set; }

        [Input("Configuration.xml location")]
        [RequiredArgument()]
        public InArgument<string> Configuration { get; set; }

        [Input("Help: Returns the Value for the specified Key stored in the Configuration.xml file.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Value")]
        public OutArgument<string> Value { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {
            //Returns the Value for the Key. 
            //Returns ‘Key ‘ + Key + ’ is not founded.’ if the Key is not founded.

        }

    }


    public sealed class Write : CodeActivity
    {

        #region Properties

        [Input("Key")]
        [RequiredArgument()]
        public InArgument<string> Key { get; set; }

        [Input("Value")]
        [RequiredArgument()]
        public InArgument<string> Value { get; set; }

        [Input("Configuration.xml location")]
        [RequiredArgument()]
        public InArgument<string> Configuration { get; set; }

        [Input("Help: Stores the Value for the specified Key in the Configuration.xml file.")]
        [Default("")]
        public InArgument<string> Help { get; set; }

        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion


        protected override void Execute(CodeActivityContext context)
        {
            //Returns true if the KVP has been stored. 
            //Returns false if any error occurs.

        }

    }

}


