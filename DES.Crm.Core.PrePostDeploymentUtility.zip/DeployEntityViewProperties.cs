﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    public class DeployEntityViewProperties
    {
        readonly CrmServiceClient _crmServiceClient;
        readonly XmlDocument _xmlConfigDocument;
        readonly Logger _logger;

        private static Dictionary<string, int> returnTypeCodeDictionary = new Dictionary<string, int>();

        public DeployEntityViewProperties(CrmServiceClient service, XmlDocument xmlConfigDocument, Logger logger)
        {
            _crmServiceClient = service;
            _xmlConfigDocument = xmlConfigDocument;
            _logger = logger;

            // Include Return type code for core entities
            returnTypeCodeDictionary.Add("account", 1);
            returnTypeCodeDictionary.Add("contact", 2);
            returnTypeCodeDictionary.Add("nwm_callreport", 10006);
        }

        public void SettingEntityViewProperties(string configMode)
        {
            var xpath = "Config/" + configMode + "/views/*";
            var validViews = new Dictionary<string, Dictionary<string, SavedQuery>>();

            if (_xmlConfigDocument.CreateNavigator().Select(xpath).Count > 0)
            {
                foreach (System.Xml.XPath.XPathNavigator child in _xmlConfigDocument.CreateNavigator().Select(xpath))
                {
                    var selectName = child.GetAttribute("name", "");
                    var isdefault = Convert.ToBoolean(child.GetAttribute("isdefault", ""));
                    var baseentityname = child.GetAttribute("baseentityname", "");

                    var query = new SavedQuery
                    {
                        isDefault = isdefault,
                        name = selectName
                    };

                    if (validViews.ContainsKey(baseentityname))
                    {
                        validViews[baseentityname].Add(query.name, query);
                    }
                    else
                    {
                        var entityViews = new Dictionary<string, SavedQuery>();
                        entityViews.Add(query.name, query);
                        validViews.Add(baseentityname, entityViews);
                    }

                }
            }

            foreach (var entityname in validViews.Keys)
            {
                int returnTypeCode = 0;

                if (!returnTypeCodeDictionary.ContainsKey(entityname))
                {
                    throw new Exception("Not able to find ");
                }
                else
                {
                    returnTypeCode = returnTypeCodeDictionary[entityname];
                }

                try
                {
                    QueryExpression entityPublicViews = new QueryExpression
                    {
                        ColumnSet = new ColumnSet("savedqueryid", "name", "querytype", "isdefault", "returnedtypecode", "isquickfindquery"),
                        EntityName = "savedquery",
                        Criteria = new FilterExpression
                        {
                            Conditions =
                        {
                            new ConditionExpression
                            {
                                AttributeName = "querytype",
                                Operator = ConditionOperator.Equal,
                                Values = {0} // Public query
                            },
                            new ConditionExpression
                            {
                                AttributeName = "returnedtypecode",
                                Operator = ConditionOperator.Equal,
                                Values = { returnTypeCode }
                            }
                        }
                        }
                    };

                    DataCollection<Entity> entityPublicViewsCollection = null;

                    RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = entityPublicViews };

                    RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);

                    entityPublicViewsCollection = retrieveSavedQueriesResponse.EntityCollection.Entities;

                    _logger.Info("Retrieve public views for entity {0}.", entityname);

                    foreach (var publicView in entityPublicViewsCollection)
                    {
                        if (validViews.ContainsKey(entityname) && validViews[entityname].ContainsKey(publicView["name"].ToString()))
                        {
                            // Keep defined views activated
                            SetStateRequest ssreq = new SetStateRequest
                            {
                                EntityMoniker = new EntityReference("savedquery", (Guid)publicView["savedqueryid"]),
                                State = new OptionSetValue(0), // 0 - active, 1 - inactive
                                Status = new OptionSetValue(1) // 1 - active, 2 - inactive
                            };

                            _crmServiceClient.Execute(ssreq);

                            _logger.Info("Make registered view {0} activated.", publicView["name"]);
                        }
                        else
                        {
                            // Deactivate undefined views
                            if (publicView["isdefault"].Equals(true))
                            {
                                publicView["isdefault"] = false;
                                _crmServiceClient.Update(publicView);

                                _logger.Info("Make unregistered view {0} not as default.", publicView["name"]);
                            }

                            SetStateRequest ssreq = new SetStateRequest
                            {
                                EntityMoniker = new EntityReference("savedquery", (Guid)publicView["savedqueryid"]),
                                State = new OptionSetValue(1), // 0 - active, 1 - inactive
                                Status = new OptionSetValue(2) // 1 - active, 2 - inactive
                            };

                            _crmServiceClient.Execute(ssreq);
                            _logger.Info("Make unregistered view {0} deactivated.", publicView["name"]);
                        }
                    }

                }
                catch (Exception ex)
                {
                    _logger.Error("Not able to get public views of {0}.", entityname);
                    throw new Exception("Not able to get public views: ", ex);
                }

            }
        } 
    }

    internal class SavedQuery
    {
        public string name { get; set; }
        public bool isDefault { get; set; }
        public Guid savedqueryid { get; set; }
        public string querytype { get; set; }
    }
}
