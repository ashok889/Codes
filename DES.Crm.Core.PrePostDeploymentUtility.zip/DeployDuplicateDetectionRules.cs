﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    class DeployDuplicateDetectionRules
    {

        readonly CrmServiceClient _crmServiceClient;
        readonly XmlDocument _xmlConfigDocument;
        readonly Logger _logger;

        #region "Fetchxml"

        const string FetchDuplicateRuleRecord =
            @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
              <entity name='duplicaterule' >
                <attribute name='duplicateruleid' />
                <attribute name='name' />
                <attribute name='ownerid' />
                <attribute name='statuscode' />
              </entity> 
            </fetch>";

        #endregion


        #region "CONSTRUCTOR" 

        public DeployDuplicateDetectionRules(CrmServiceClient service, XmlDocument xmlConfigDocument, Logger logger)
        {
            _crmServiceClient = service;
            _xmlConfigDocument = xmlConfigDocument;
            _logger = logger;
            
        }

        #endregion

        public void ProcessDuplicateDetectionRules(string configMode)
        {
            var xpath = "Config/" + configMode + "/duplicaterules/*";
            if (_xmlConfigDocument.CreateNavigator().Select(xpath).Count > 0)
            {

                var duplicateRuleRecords = GetExistingDuplicateRules();
                var existingRulesDictionary = new Dictionary<string, Entity>();
                foreach (var rule in duplicateRuleRecords)
                {
                    existingRulesDictionary.Add(rule["name"].ToString(), rule);
                }

                foreach (System.Xml.XPath.XPathNavigator child in _xmlConfigDocument.CreateNavigator().Select(xpath))
                {
                    var selectName = child.GetAttribute("name", "");
                    var delete = Convert.ToBoolean(child.GetAttribute("delete", ""));

                    _logger.Info(string.Format("Start to process duplicate Rule: {0}", child.GetAttribute("name", "")));

                    if (!string.IsNullOrWhiteSpace(selectName))
                    {
                        if (existingRulesDictionary.ContainsKey(selectName))
                        {
                            var rule = existingRulesDictionary[selectName];

                            if (delete)
                            {
                                _logger.Info(string.Format("Start to delete duplicate Rule: {0}", child.GetAttribute("name", "")));
                                DeleteDuplicateRule(rule);
                            }
                            else
                            {
                                _logger.Info(string.Format("Start to publish existing duplicate Rule: {0}", child.GetAttribute("name", "")));
                                Publish(rule);
                            }

                            existingRulesDictionary.Remove(selectName);
                        }
                        else
                        {
                            _logger.Info(string.Format("Start to create and publish new duplicate Rule: {0}", child.GetAttribute("name", "")));
                            if (!delete) CreateDuplicateRule(child);
                        }

                    }
                }

                UnpublishUnregisteredDuplicationDetectionRules(existingRulesDictionary);
            }
        }

        /// <summary>
        /// Unpublish existing but unregistered duplication detection rules
        /// </summary>
        /// <param name="existingRulesDictionary"></param>
        private void UnpublishUnregisteredDuplicationDetectionRules(Dictionary<string, Entity> existingRulesDictionary)
        {
            foreach (Entity rule in existingRulesDictionary.Values)
            {
                try
                {
                    OptionSetValue status = (OptionSetValue)rule["statuscode"];

                    if (status != null && status.Value.Equals((int)StatusCode.Published))
                    {
                        _crmServiceClient.Execute(new UnpublishDuplicateRuleRequest
                        {
                            DuplicateRuleId = rule.Id
                        });

                        _logger.Info(string.Format("Unpublish duplicate Rule ({0}) with the id({1})", rule["name"], rule["duplicateruleid"]));
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error(string.Format("Unable to unpublish duplicate Rule.", rule["name"], rule["duplicateruleid"]));
                    throw new Exception("Unable to unpublish duplicate Rule", ex);
                }
            }
        }


        /// <summary>
        /// Method to create new duplication detetcion rules
        /// </summary>
        /// <param name="child"></param>
        private void CreateDuplicateRule(XPathNavigator child)
        {

            try
            {
                var duplicateRule = new Entity("duplicaterule");
                duplicateRule["name"] = child.GetAttribute("name", "");
                duplicateRule["baseentityname"] = child.GetAttribute("baseentityname", "");
                duplicateRule["baseentitytypecode"] = child.GetAttribute("baseentitytypecode", "");
                duplicateRule["iscasesensitive"] = Convert.ToBoolean(child.GetAttribute("iscasesensitive", ""));
                duplicateRule["excludeinactiverecords"] = Convert.ToBoolean(child.GetAttribute("excludeinactiverecords", ""));
                duplicateRule["matchingentityname"] = child.GetAttribute("matchingentityname", "");
                duplicateRule["matchingentitytypecode"] = child.GetAttribute("matchingentitytypecode", "");

                _logger.Info(string.Format("Reading duplication detection rule details from configuration."));

                var duplicateRuleId = _crmServiceClient.Create(duplicateRule);
                XPathNodeIterator iteratorDuplicateRuleCondition = child.Select("duplicaterulecondition");
                while (iteratorDuplicateRuleCondition.MoveNext())
                {
                    XPathNavigator node = iteratorDuplicateRuleCondition.Current;
                    var duplicateRuleCondition = new Entity("duplicaterulecondition");
                    duplicateRuleCondition["baseattributename"] = node.GetAttribute("baseattributename", "");
                    duplicateRuleCondition["ignoreblankvalues"] = Convert.ToBoolean(node.GetAttribute("ignoreblankvalues", ""));
                    duplicateRuleCondition["matchingattributename"] = node.GetAttribute("matchingattributename", "");
                    duplicateRuleCondition["operatorcode"] = new OptionSetValue(Convert.ToInt16(node.GetAttribute("operatorcode", "")));
                    duplicateRuleCondition["regardingobjectid"] = new EntityReference("duplicaterule", duplicateRuleId);
                    var duplicateRuleConditionId = _crmServiceClient.Create(duplicateRuleCondition);
                }
                duplicateRule["duplicateruleid"] = duplicateRuleId;
                _crmServiceClient.Execute(new PublishDuplicateRuleRequest
                {
                    DuplicateRuleId = duplicateRuleId
                });
                _logger.Info(string.Format("Duplicate Rule ({0}) created and published with the id({1})", duplicateRule["name"], duplicateRuleId));
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("Duplicate Rule ({0}) cannot be created and published)", child.GetAttribute("name", "")));
                throw new Exception("Not able to create duplication detection rule: {0}", ex);
            }

        }

        /// <summary>
        /// Method to retrieve existing duplication detection rules
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private DataCollection<Entity> GetExistingDuplicateRules()
        {
            try
            {
                _logger.Info("Get Existing duplication detection rules.");
                var fetchXmlQueryforDuplicateRuleRecord = FetchDuplicateRuleRecord;
                var queryDuplicateRuleRecord = new FetchExpression(fetchXmlQueryforDuplicateRuleRecord);
                var requestDuplicateRuleRecord = new RetrieveMultipleRequest { Query = queryDuplicateRuleRecord };
                return ((RetrieveMultipleResponse)_crmServiceClient.Execute(requestDuplicateRuleRecord)).EntityCollection.Entities;
            }
            catch (Exception ex)
            {
                _logger.Error("Not able to retrieve Duplicate Rules Records.");
                throw new Exception("Not able to retrieve Duplicate Rules Records.", ex);
            }
        }

        /// <summary>
        /// Method to publish existing duplication detection rules
        /// </summary>
        /// <param name="duplicateRuleRecord"></param>
        private void Publish(Entity duplicateRuleRecord)
        {
     
            if (duplicateRuleRecord != null)
            {

                OptionSetValue status = (OptionSetValue)duplicateRuleRecord["statuscode"];

                if (status != null && status.Value.Equals((int)StatusCode.Unpublished))
                {
                    _crmServiceClient.Execute(new PublishDuplicateRuleRequest
                    {
                        DuplicateRuleId = duplicateRuleRecord.Id
                    });

                    _logger.Info(string.Format("Duplicate Rule ({0}) republished with the id({1})", duplicateRuleRecord["name"], duplicateRuleRecord["duplicateruleid"]));
                }
                else
                {
                    if (duplicateRuleRecord["name"] != null)
                    {
                        _logger.Info(string.Format("Duplicate Rule ({0}) is in published or Publishing Status.", duplicateRuleRecord["name"]));
                    }
                }

            }
        }

        private void DeleteDuplicateRule(Entity duplicateRuleRecord)
        {
            try
            {
                _crmServiceClient.Delete(duplicateRuleRecord.LogicalName, duplicateRuleRecord.Id);
                _logger.Info(string.Format("Duplicate Rule ({0}) Deleted.", duplicateRuleRecord["name"]));
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("Cannot delete duplicate Rule ({0}).", duplicateRuleRecord["name"]));
                throw new Exception("Not able to delete duplication detection rule.", ex);
            }
        }

        private enum StatusCode
        {

            [System.Runtime.Serialization.EnumMemberAttribute()]
            Published = 2,

            [System.Runtime.Serialization.EnumMemberAttribute()]
            Publishing = 1,

            [System.Runtime.Serialization.EnumMemberAttribute()]
            Unpublished = 0,
        }

    }
}
