﻿//-----------------------------------------------------------------------
// <copyright file="DeployTeamTemplates.cs" company="NatWest Markets">
//     Copyright (c) NatWest Markets 2017.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.CrmEarlyBoundClasses;
using System;
using DES.Crm.Core.PrePostDeploymentUtility.XML;


namespace DES.Crm.Core.PrePostDeploymentUtility
{ 
    /// <summary>
    /// Deploy team templates functionality.
    /// </summary>
    public class DeployTeamTemplates
    {
        #region Private Fields
        /// <summary>
        /// CRM Service Client private field.
        /// </summary>
        private readonly CrmServiceClient crmServiceClient;
        
        /// <summary>
        /// Configuration xml document private field.
        /// </summary>
        private readonly XmlDocument xmlConfigDocument;

        /// <summary>
        /// Logger private field.
        /// </summary>
        private readonly Logger logger;
        #endregion

     
        /// <summary>
        /// Initializes a new instance of the <see cref="DeployTeamTemplates" /> class.
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="xmlConfigDocument">Configuration xml document</param>
        /// <param name="logger">NLog logging.</param>
        public DeployTeamTemplates(CrmServiceClient service, XmlDocument xmlConfigDocument, Logger logger)
        {
            this.crmServiceClient = service;
            this.xmlConfigDocument = xmlConfigDocument;
            this.logger = logger;
        }

        /// <summary>
        /// Main method to action deployment.
        /// </summary>
        /// <param name="configMode">Pre or Post</param>
        public void Setting(string configMode)
        {
            var xpath = "Config/" + configMode + "/accessteamtemplates/*";
            var accessTeamTemplates = new Dictionary<string, Dictionary<string, SavedQuery>>();

            if (this.xmlConfigDocument.CreateNavigator().Select(xpath).Count > 0)
            {
                CrmServiceContext serviceContext = new CrmServiceContext(this.crmServiceClient.OrganizationServiceProxy);

                foreach (System.Xml.XPath.XPathNavigator child in this.xmlConfigDocument.CreateNavigator().Select(xpath))
                {
                    // Get objecttypecode in target environment using entity name
                    var entityName = child.GetAttribute("baseentityname", string.Empty);
                    int? objectTypeCode = this.GetObjectTypeCode(entityName);

                    var id = Guid.Empty;

                    var name = child.GetAttribute("name", string.Empty);
                    var description = child.GetAttribute("description", string.Empty);
                    var rightsMask = Convert.ToInt32(child.GetAttribute("rightsmask", string.Empty));

                    if (Guid.TryParse(child.GetAttribute("id", string.Empty), out id))
                    {
                        var templateToCreate = new TeamTemplate
                        {
                            DefaultAccessRightsMask = rightsMask,
                            Id = id,
                            TeamTemplateName = name,
                            Description = description,
                            ObjectTypeCode = objectTypeCode
                        };

                        
                        var request = new UpsertRequest()
                        {
                            Target = templateToCreate
                        };

                        var response = (UpsertResponse)crmServiceClient.Execute(request);

                        if (response.RecordCreated)
                        {
                            this.logger.Info("Team template {0} with id - {1} Created.", name, id);
                        }
                        else
                        {
                            this.logger.Info("Team template {0} with id - {1} Updated.", name, id);
                        }
                    }
                }
            }
        } 
     
        /// <summary>
        /// Returns the object type code number given the entity name.
        /// </summary>
        /// <param name="entityName">The logical entity name.</param>
        /// <returns>The integer object type code.</returns>
        private int? GetObjectTypeCode(string entityName)
        {
            var entityRequest = new RetrieveEntityRequest
            {
                LogicalName = entityName
            };
            var response = this.crmServiceClient.Execute(entityRequest) as RetrieveEntityResponse;
            var objectTypeCode = response.EntityMetadata.ObjectTypeCode;
            return objectTypeCode;
        }
 
    }
}

