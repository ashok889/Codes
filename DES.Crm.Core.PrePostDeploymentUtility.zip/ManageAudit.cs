﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.CrmEarlyBoundClasses;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using System; 
using System.Xml;
using System.Xml.XPath;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    class ManageAudit
    {
        readonly CrmServiceClient _crmServiceClient;
        readonly XmlDocument _xmlConfigDocument;
        readonly Logger _logger; 

        #region "CONSTRUCTOR" 

        public ManageAudit(CrmServiceClient service, XmlDocument xmlConfigDocument, Logger logger)
        {
            _crmServiceClient = service;
            _xmlConfigDocument = xmlConfigDocument;
            _logger = logger; 
        }

        #endregion
 
        public void ConfigureAudit(string configMode)
        {
            string auditPath = "Config/" + configMode + "/audit";
            if (_xmlConfigDocument.SelectSingleNode(auditPath) != null)
            { 

                bool orgAuditFlag = Convert.ToBoolean(_xmlConfigDocument.SelectSingleNode(auditPath).Attributes["enabled"].Value);
                 
                Guid orgId = ((WhoAmIResponse)_crmServiceClient.Execute(new WhoAmIRequest())).OrganizationId; 
                
                Organization org = _crmServiceClient.Retrieve(Organization.EntityLogicalName, orgId,
                    new ColumnSet(new string[] { "organizationid", "isauditenabled" })) as Organization; 
                
                if(orgAuditFlag != org.IsAuditEnabled.Value)
                {
                    _logger.Info(string.Format("Configuring Organisation level Auditing Flag..."));
                    org.IsAuditEnabled = orgAuditFlag;
                    _crmServiceClient.Update(org);
                    _logger.Info(string.Format("Configured Organisation level Auditing Flag to {0}", orgAuditFlag));
                }
                else
                {
                    _logger.Info(string.Format("No change made to Organisation level Auditing({0})", orgAuditFlag));
                }

                var auditPathSub = auditPath + "/*";
                if (_xmlConfigDocument.CreateNavigator().Select(auditPathSub).Count > 0)
                {
                    foreach (XPathNavigator child in _xmlConfigDocument.CreateNavigator().Select(auditPathSub))
                    {
                        var entityLogicalName = child.GetAttribute("entity", "");
                        var auditFlag = Convert.ToBoolean(child.GetAttribute("enabled", ""));

                        _logger.Info(string.Format("Configuring {0} Entity Auditing Flag to {1}", entityLogicalName, auditFlag));

                         bool oldValue = EnableEntityAuditing(entityLogicalName, auditFlag);

                        if(oldValue.Equals(auditFlag))
                        {
                            _logger.Info(string.Format("No change made to Entity ({0}) Auditing({1})", entityLogicalName,orgAuditFlag));
                        }
                        else
                        {
                            _logger.Info(string.Format("Configured {0} Entity Auditing Flag to {1}", entityLogicalName, auditFlag));
                        } 
                    }
                }
            } 
        } 

        private bool EnableEntityAuditing(string entityLogicalName, bool newAuditFlag)
        {
            // Retrieve the entity metadata.
            RetrieveEntityRequest entityRequest = new RetrieveEntityRequest
            {
                LogicalName = entityLogicalName,
                EntityFilters = EntityFilters.Attributes
            };

            RetrieveEntityResponse entityResponse =
                (RetrieveEntityResponse)_crmServiceClient.Execute(entityRequest);

            // Enable auditing on the entity. By default, this also enables auditing
            // on all the entity's attributes.
            EntityMetadata entityMetadata = entityResponse.EntityMetadata;

            bool oldValue = entityMetadata.IsAuditEnabled.Value;
            if(oldValue != newAuditFlag)
            {
                entityMetadata.IsAuditEnabled = new BooleanManagedProperty(newAuditFlag);

                UpdateEntityRequest updateEntityRequest = new UpdateEntityRequest { Entity = entityMetadata };

                UpdateEntityResponse updateEntityResponse =
                    (UpdateEntityResponse)_crmServiceClient.Execute(updateEntityRequest);
            }
            return oldValue; 
        }
    }
}
