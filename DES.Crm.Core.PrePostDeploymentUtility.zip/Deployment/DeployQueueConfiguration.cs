﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Xml;
using DES.Crm.Core.CrmEarlyBoundClasses;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployQueueConfiguration : DeployConfiguration
    {        
        readonly QueueCollection _queues;        

        public DeployQueueConfiguration(CrmServiceClient service, QueueCollection queues, Logger logger) : base (service, logger)
        {
            _queues = queues;
        }

        public override void DeployConfigurationData()
        {
            if (_queues.Queues == null || _queues.Queues.Length == 0)
            {
                _logger.Info("No queues to process");
            }

            foreach (var queue in _queues.Queues)
            {
                try
                {
                    var create = false;
                    Entity tempRecord = null;
                    CrmEarlyBoundClasses.Queue queueRecord = null;
                    // Check if queue already exists              
                    try
                    {
                        tempRecord = _crmServiceClient.Retrieve(CrmEarlyBoundClasses.Queue.EntityLogicalName, queue.Id, new ColumnSet("queueid", "name", "queueviewtype", "ownerid"));
                    }
                    catch (FaultException<OrganizationServiceFault> e)
                    {
                        if (!e.Message.StartsWith("queue with id", StringComparison.InvariantCultureIgnoreCase))
                        {
                            throw e;
                        }
                    }                    

                    // Check whether team currently has the assigned role                                     
                    if (tempRecord != null)
                    {
                        queueRecord = tempRecord.ToEntity<CrmEarlyBoundClasses.Queue>();
                        _logger.Info("Queue: \"{0}\" already exists. Updating queue.", queue.Name);
                        queueRecord.QueueViewTypeEnum = queue.QueueTypeEnum;
                        queueRecord.Name = queue.Name;                                                
                    }
                    else
                    {
                        // Creating the queue
                        _logger.Info("Creating queue: \"{0}\" of type: \"{1}\". Owner:\"{0}\"", queue.Name, queue.QueueType, queue.Owner);
                        queueRecord = new CrmEarlyBoundClasses.Queue()
                        {
                            Id = queue.Id,
                            Name = queue.Name,
                            QueueViewTypeEnum = queue.QueueTypeEnum
                        };
                        create = true;
                    }            

                    // Check if owner is the team or user
                    switch (queue.OwnerTypeEnum)
                    {
                        case Enums.OwnerType.SystemUser:
                            var userRecord = _crmServiceClient.Retrieve(SystemUser.EntityLogicalName, queue.Owner, new ColumnSet("systemuserid", "fullname"));
                            queueRecord.OwnerId = userRecord.ToEntityReference();
                            break;
                        case Enums.OwnerType.Team:
                            var teamRecord = _crmServiceClient.Retrieve(Team.EntityLogicalName, queue.Owner, new ColumnSet("teamid", "name"));
                            queueRecord.OwnerId = teamRecord.ToEntityReference();
                            break;
                    }
                    if (create)
                    {
                        _crmServiceClient.Create(queueRecord);
                    }
                    else
                    {
                        _crmServiceClient.Update(queueRecord);
                    }
                     
                }
                catch (Exception ex)
                {
                    _logger.Error("Error while creating or updating queue: {0}", queue.Name);
                    _logger.Error(ex.Message);
                    throw new Exception("Cannot process queue: ", ex);
                }
            }
        }
    }
}
