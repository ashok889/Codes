﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;
using DES.Crm.Core.CrmEarlyBoundClasses;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployDuplicateDetectionRuleConfiguration : DeployConfiguration
    {        
        readonly DuplicateRuleCollection _duplicateRules;        

        #region "Fetchxml"

        const string FetchDuplicateRuleRecord =
            @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
              <entity name='duplicaterule' >
                <attribute name='duplicateruleid' />
                <attribute name='name' />
                <attribute name='ownerid' />
                <attribute name='statuscode' />
              </entity> 
            </fetch>";

        #endregion


        #region "CONSTRUCTOR" 

        public DeployDuplicateDetectionRuleConfiguration(CrmServiceClient service, DuplicateRuleCollection duplicateRules, Logger logger) : base (service, logger)
        {
            _duplicateRules = duplicateRules;            
        }

        #endregion

        public override void DeployConfigurationData()
        {
            if (_duplicateRules.DuplicateRules == null || _duplicateRules.DuplicateRules.Length == 0)
            {
                _logger.Info("No Duplicate detection rules to process");
            }
 
            var duplicateRuleRecords = GetExistingDuplicateRules();
            var existingRulesDictionary = new Dictionary<string, CrmEarlyBoundClasses.DuplicateRule>();
            foreach (var rule in duplicateRuleRecords)
            {
                existingRulesDictionary.Add(rule.Name, rule);
            }

            foreach (var _rule in _duplicateRules.DuplicateRules)
            {
                _logger.Info("Start to process duplicate Rule: {0}", _rule.Name);

                if (!string.IsNullOrWhiteSpace(_rule.Name))
                {
                    if (existingRulesDictionary.ContainsKey(_rule.Name))
                    {
                        var rule = existingRulesDictionary[_rule.Name];

                        if (_rule.Delete)
                        {
                            _logger.Info("Start to delete duplicate Rule: {0}", _rule.Name);
                            DeleteDuplicateRule(rule);
                        }
                        else
                        {
                            _logger.Info("Start to publish existing duplicate Rule: {0}", _rule.Name);
                            Publish(rule);
                        }

                        existingRulesDictionary.Remove(_rule.Name);
                    }
                    else
                    {
                        _logger.Info("Start to create and publish new duplicate Rule: {0}", _rule.Name);
                        if (!_rule.Delete) CreateDuplicateRule(_rule);
                    }
                }
            }

            UnpublishUnregisteredDuplicationDetectionRules(existingRulesDictionary);            
        }

        /// <summary>
        /// Unpublish existing but unregistered duplication detection rules
        /// </summary>
        /// <param name="existingRulesDictionary"></param>
        private void UnpublishUnregisteredDuplicationDetectionRules(Dictionary<string, CrmEarlyBoundClasses. DuplicateRule> existingRulesDictionary)
        {
            foreach (var rule in existingRulesDictionary.Values)
            {
                try
                {
                    OptionSetValue status = rule.StatusCode;

                    if (status != null && status.Value.Equals((int)DuplicateRule_StatusCode.Published))
                    {
                        _crmServiceClient.Execute(new UnpublishDuplicateRuleRequest
                        {
                            DuplicateRuleId = rule.Id
                        });

                        _logger.Info("Unpublish duplicate Rule: \"{0}\" with id: \"{1}\"", rule.Name, rule.Id);
                    }
                }
                catch (Exception ex)
                {
                    _logger.Error("Unable to unpublish duplicate Rule: \"{0}\". Id: \"{1}\".", rule.Name, rule.Id);
                    throw new Exception(string.Format("Unable to unpublish duplicate Rule: \"{0}\"", rule.Name), ex);
                }
            }
        }


        /// <summary>
        /// Method to create new duplication detetcion rules
        /// </summary>
        /// <param name="child"></param>
        private void CreateDuplicateRule(XML.DuplicateRule child)
        {
            try
            {
                var duplicateRule = new CrmEarlyBoundClasses.DuplicateRule()
                {
                    Name = child.Name,
                    BaseEntityName = child.BaseEntityName,
                    IsCaseSensitive = child.IsCaseSensitive,
                    ExcludeInactiveRecords = child.ExcludeActiveRecords,
                    MatchingEntityName = child.MatchingEntityName,
                    StatusCodeEnum = DuplicateRule_StatusCode.Unpublished                 
                };                

                // Create the duplicate rule
                var duplicateRuleId = _crmServiceClient.Create(duplicateRule);
                _logger.Info("Duplicate Rule: \"{0}\" created", duplicateRule.Name);
                duplicateRule.Id = duplicateRuleId;

                if (child.DuplicateRuleConditions != null && child.DuplicateRuleConditions.Length > 0)
                {                    
                    foreach (var record in child.DuplicateRuleConditions)
                    {
                        var duplicateRuleCondition = new CrmEarlyBoundClasses.DuplicateRuleCondition()
                        {
                            BaseAttributeName = record.BaseAttributeName,
                            IgnoreBlankValues = record.IgnoreBlankValues,
                            MatchingAttributeName = record.MatchingAttributeName,
                            OperatorCode = new OptionSetValue(record.OperatorCode),
                            RegardingObjectId = duplicateRule.ToEntityReference()
                        };                        
                        var duplicateRuleConditionId = _crmServiceClient.Create(duplicateRuleCondition);
                        _logger.Info("Duplicate Rule Condition: \"{0}\" created for duplicate rule: \"{1}\"", duplicateRuleConditionId, duplicateRule.Name);
                    }
                }
                Publish(duplicateRule);
            }
            catch (Exception ex)
            {
                _logger.Error("Duplicate Rule: \"{0}\" cannot be created and published)", child.Name);
                throw new Exception(string.Format("Not able to create duplication detection rule: {0}", child.Name), ex);
            }

        }

        /// <summary>
        /// Method to retrieve existing duplication detection rules
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private IEnumerable<CrmEarlyBoundClasses.DuplicateRule> GetExistingDuplicateRules()
        {
            try
            {
                _logger.Info("Get Existing duplication detection rules.");
                var fetchXmlQueryforDuplicateRuleRecord = FetchDuplicateRuleRecord;
                var queryDuplicateRuleRecord = new FetchExpression(fetchXmlQueryforDuplicateRuleRecord);
                var requestDuplicateRuleRecord = new RetrieveMultipleRequest { Query = queryDuplicateRuleRecord };
                return ((RetrieveMultipleResponse)_crmServiceClient.Execute(requestDuplicateRuleRecord)).EntityCollection.Entities.Select(p => p.ToEntity<CrmEarlyBoundClasses.DuplicateRule>());
            }
            catch (Exception ex)
            {
                _logger.Error("Not able to retrieve Duplicate Rules Records.");
                throw new Exception("Not able to retrieve Duplicate Rules Records.", ex);
            }
        }

        /// <summary>
        /// Method to publish existing duplication detection rules
        /// </summary>
        /// <param name="duplicateRuleRecord"></param>
        private void Publish(CrmEarlyBoundClasses.DuplicateRule duplicateRuleRecord)
        {                
            OptionSetValue status = duplicateRuleRecord.StatusCode;

            if (status != null && status.Value.Equals((int)DuplicateRule_StatusCode.Unpublished))
            {
                _crmServiceClient.Execute(new PublishDuplicateRuleRequest
                {
                    DuplicateRuleId = duplicateRuleRecord.Id
                });

                _logger.Info("Duplicate Rule \"{0}\" published with the id \"{1}\"", duplicateRuleRecord.Name, duplicateRuleRecord.Id);
            }
            else
            {
                if (duplicateRuleRecord.Name != null)
                {
                    _logger.Info("Duplicate Rule \"{0}\" is in published or Publishing Status.", duplicateRuleRecord.Name);
                }
            }
        }

        private void DeleteDuplicateRule(Entity duplicateRuleRecord)
        {
            try
            {
                _crmServiceClient.Delete(duplicateRuleRecord.LogicalName, duplicateRuleRecord.Id);
                _logger.Info(string.Format("Duplicate Rule ({0}) Deleted.", duplicateRuleRecord["name"]));
            }
            catch (Exception ex)
            {
                _logger.Error(string.Format("Cannot delete duplicate Rule ({0}).", duplicateRuleRecord["name"]));
                throw new Exception("Not able to delete duplication detection rule.", ex);
            }
        }        
    }
}
