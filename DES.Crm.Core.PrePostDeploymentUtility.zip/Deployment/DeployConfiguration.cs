﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public abstract class DeployConfiguration
    {
        protected readonly CrmServiceClient _crmServiceClient;
        protected readonly Logger _logger;        

        public DeployConfiguration (CrmServiceClient client, Logger logger)
        {
            _crmServiceClient = client;
            _logger = logger;
        }

        public abstract void DeployConfigurationData();
    }
}
