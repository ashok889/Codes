﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Xml;
using DES.Crm.Core.CrmEarlyBoundClasses;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployWorkflowActionConfiguration : DeployConfiguration
    {
        readonly WorkflowActionCollection _workflowActions;

        public DeployWorkflowActionConfiguration(CrmServiceClient service, WorkflowActionCollection workflowsActions, Logger logger) : base(service, logger)
        {
            _workflowActions = workflowsActions;
        }

        public override void DeployConfigurationData()
        {
            if (_workflowActions.WorkflowActions == null || _workflowActions.WorkflowActions.Length == 0)
            {
                _logger.Info("No workflow actions to process");
            }

            foreach (var workflow in _workflowActions.WorkflowActions)
            {
                
                // Check if queue already exists              
                try
                {
                    var query = new QueryExpression()
                    {
                        EntityName = Workflow.EntityLogicalName,
                        ColumnSet = new ColumnSet("workflowid", "name")
                    };
                    query.Criteria.AddCondition("name", ConditionOperator.Equal, workflow.WorkflowName);
                    EntityCollection results = _crmServiceClient.RetrieveMultiple(query);

                    if (results == null || results.Entities.Count == 0)
                    {
                        _logger.Info("No workflow with name: \"{0}\" exists.", workflow.WorkflowName);
                    }

                    foreach (var result in results.Entities)
                    {
                        var workflowRecord = result.ToEntity<Workflow>();
                        var setStateRequest = new SetStateRequest();

                        _logger.Info("Performing action: \"{0}\" on workflow: \"{1}\"", workflow.ActionType, workflow.WorkflowName);
                        switch (workflow.ActionTypeEnum)
                        {
                            case Enums.ActionType.Activate:                                
                                _crmServiceClient.UpdateStateAndStatusForEntity(Workflow.EntityLogicalName, workflowRecord.Id, (int)WorkflowState.Activated, (int)Workflow_StatusCode.Activated);                                
                                break;
                            case Enums.ActionType.Deactivate:
                                _crmServiceClient.UpdateStateAndStatusForEntity(Workflow.EntityLogicalName, workflowRecord.Id, (int)WorkflowState.Draft, (int)Workflow_StatusCode.Draft);
                                break;                            
                        }                        
                    }
                }                                    
                catch (Exception ex)
                {
                    _logger.Error("Error while performing action: \"{0}\" on workflow: {1}", workflow.ActionType, workflow.WorkflowName);
                    _logger.Error(ex.Message);
                    throw new Exception("Cannot process workfow: ", ex);
                }
            }
        }
    }
}