﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.CrmEarlyBoundClasses;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using System;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployAuditConfiguration : DeployConfiguration
    {        
        readonly AuditCollection _auditItems;        

        #region "CONSTRUCTOR" 

        public DeployAuditConfiguration(CrmServiceClient service, AuditCollection audits, Logger logger) : base (service, logger)
        {            
            _auditItems = audits;            
        }

        #endregion
 
        public override void DeployConfigurationData()
        {           
                           
            Guid orgId = ((WhoAmIResponse)_crmServiceClient.Execute(new WhoAmIRequest())).OrganizationId; 
                
            Organization org = _crmServiceClient.Retrieve(Organization.EntityLogicalName, orgId, new ColumnSet(new string[] { "organizationid", "isauditenabled" })) as Organization; 
                
            if(_auditItems.Enabled != org.IsAuditEnabled.Value)
            {
                _logger.Info("Configuring Organisation level Auditing Flag...");
                org.IsAuditEnabled = _auditItems.Enabled; ;
                _crmServiceClient.Update(org);
                _logger.Info("Configured Organisation level Auditing Flag to {0}", _auditItems.Enabled);
            }
            else
            {
                _logger.Info("No change made to Organisation level Auditing ({0})", _auditItems.Enabled);
            }

            if (_auditItems.AuditItems == null || _auditItems.AuditItems.Length == 0)
            {
                _logger.Info("No entities require audit setting to be amended");
                return;
            }

            foreach (var audit in _auditItems.AuditItems)
            {
                _logger.Info("Configuring Entity: {0} Auditing Flag to {1}", audit.Entity, audit.Enabled);
                var oldValue = EnableEntityAuditing(audit.Entity, audit.Enabled);

                if(oldValue.Equals(audit.Enabled))
                {
                    _logger.Info("No change made to Entity ({0}) Auditing ({1})", audit.Entity, audit.Enabled);
                }
                else
                {
                    _logger.Info("Configured Entity: {0} Auditing Flag to {1}", audit.Entity, audit.Enabled);
                } 
            }                           
        } 

        private bool EnableEntityAuditing(string entityLogicalName, bool newAuditFlag)
        {
            // Retrieve the entity metadata.
            RetrieveEntityRequest entityRequest = new RetrieveEntityRequest
            {
                LogicalName = entityLogicalName,
                EntityFilters = EntityFilters.Attributes
            };

            RetrieveEntityResponse entityResponse = (RetrieveEntityResponse)_crmServiceClient.Execute(entityRequest);

            // Enable auditing on the entity. By default, this also enables auditing
            // on all the entity's attributes.
            EntityMetadata entityMetadata = entityResponse.EntityMetadata;

            bool oldValue = entityMetadata.IsAuditEnabled.Value;
            if(oldValue != newAuditFlag)
            {
                entityMetadata.IsAuditEnabled = new BooleanManagedProperty(newAuditFlag);

                UpdateEntityRequest updateEntityRequest = new UpdateEntityRequest { Entity = entityMetadata };

                UpdateEntityResponse updateEntityResponse =
                    (UpdateEntityResponse)_crmServiceClient.Execute(updateEntityRequest);
            }
            return oldValue; 
        }
    }
}
