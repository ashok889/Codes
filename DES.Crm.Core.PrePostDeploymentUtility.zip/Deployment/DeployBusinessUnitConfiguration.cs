﻿using System;
using System.Collections.Generic;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployBusinessUnitConfiguration : DeployConfiguration
    {
        readonly BusinessUnitCollection _businessUnits;

        public DeployBusinessUnitConfiguration(CrmServiceClient service, BusinessUnitCollection businessUnits, Logger logger) : base(service, logger)
        {
            _businessUnits = businessUnits;
        }

        public override void DeployConfigurationData()
        {
            if (_businessUnits.BusinessUnits == null || _businessUnits.BusinessUnits.Length == 0)
            {
                _logger.Info("No Business Units to process");
            }

            var businessUnits = GetExistingBusinessUnits();
            var admin = ((WhoAmIResponse)_crmServiceClient.Execute(new WhoAmIRequest())).UserId;

            foreach (var businessUnit in _businessUnits.BusinessUnits)
            {
                var name = businessUnit.Name;                
                var parentbu = businessUnit.ParentBusinessUnit;

                if (businessUnits.ContainsValue(name))
                {
                    _logger.Info("Business unit: \"{0}\" already exists in targeted instance.", name);
                }
                else
                {
                    var bu = new CrmEarlyBoundClasses.BusinessUnit()
                    {                        
                        Name = name                                                
                    };

                    CrmEarlyBoundClasses.BusinessUnit buRecord = null;
                    if (string.IsNullOrEmpty(parentbu))
                    {
                        buRecord = BusinessUnitRetriever.GetRootBusinessUnit(_crmServiceClient);                        
                    }
                    else
                    {
                        buRecord = BusinessUnitRetriever.GetBusinessUnitByName(_crmServiceClient, parentbu);                        
                    }

                    bu.ParentBusinessUnitId = new EntityReference("businessunit", buRecord.Id);
                    try
                    {
                        var buId = _crmServiceClient.Create(bu);
                        _logger.Info("Business unit: \"{0}\" with id \"{1}\" has been created", name, buId);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error("Not able to create business unit: \"{0}\"", name);
                        _logger.Error(ex);
                    }
                }

            }
        }

        private Dictionary<Guid, string> GetExistingBusinessUnits()
        {
            var buDictionary = new Dictionary<Guid, string>();

            QueryExpression businessUnitquery = new QueryExpression
            {
                ColumnSet = new ColumnSet("businessunitid", "name"),
                EntityName = "businessunit",
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression
                        {     
                            AttributeName = "parentbusinessunitid",
                            Operator = ConditionOperator.NotNull                               
                        }
                    }
                }
            };

            DataCollection<Entity> businessUnits;
            //Retrieve the value based on the condition given
            RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = businessUnitquery };
            RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
            businessUnits = retrieveSavedQueriesResponse.EntityCollection.Entities;

            foreach (var bu in businessUnits)
            {
                buDictionary.Add(bu.Id, bu["name"].ToString());
            }

            return buDictionary;
        }        
    }
}
