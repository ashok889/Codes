﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Linq;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using DES.Crm.Core.CrmEarlyBoundClasses;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployTeamSecurityRoleConfiguration : DeployConfiguration
    {        
        readonly TeamSecurityRoleCollection _teamRoles;       

        public DeployTeamSecurityRoleConfiguration(CrmServiceClient service, TeamSecurityRoleCollection teamRoles, Logger logger) : base(service, logger)
        {
            _teamRoles = teamRoles;            
        }     

        public override void DeployConfigurationData()
        {
            if (_teamRoles.TeamSecurityRoles == null || _teamRoles.TeamSecurityRoles.Length == 0)
            {
                _logger.Info("No team security role assignments to process");
            }            

            foreach (var teamRole in _teamRoles.TeamSecurityRoles)
            {
                CrmServiceContext context = null;
                Team teamRecord = null;
                Role roleRecord = null;
                try
                {
                    // Retrieve team record and associated entities
                    teamRecord = TeamRetriever.RetrieveTeamByName(_crmServiceClient, teamRole.TeamName);
                    context = new CrmServiceContext(_crmServiceClient);
                    context.Attach(teamRecord);
                    context.LoadProperty(teamRecord, new Relationship("teamroles_association"));
                    context.LoadProperty(teamRecord, new Relationship("business_unit_teams"));

                    // Retrieve the security role for that team's business unit
                    roleRecord = RetrieveRole(_crmServiceClient, teamRole.SecurityRoleName, teamRecord.BusinessUnitId.Id);

                    // Check whether team currently has the assigned role                     
                    if (teamRecord.teamroles_association != null && teamRecord.teamroles_association.Any(p => p.Name.Equals(roleRecord.Name, StringComparison.InvariantCultureIgnoreCase))){  
                        _logger.Info("Team: \"{0}\" already has the following role: \"{1}\"", teamRole.TeamName, teamRole.SecurityRoleName);
                        context.Detach(teamRecord);
                        continue;                        
                    }

                    // Associating team with role
                    _logger.Info("Assigning role: \"{0}\" to the following team: \"{1}\"", teamRole.SecurityRoleName, teamRole.TeamName);
                    _crmServiceClient.Associate(Team.EntityLogicalName, teamRecord.Id, new Relationship("teamroles_association"), new EntityReferenceCollection() { roleRecord.ToEntityReference() });
                    context.Detach(teamRecord);
                }
                catch (Exception ex)
                {
                    _logger.Error("Error while assigning requested security role: \"{0}\" to team: \"{1}\"", teamRole.SecurityRoleName, teamRole.TeamName);
                    _logger.Error(ex.Message);                    
                    throw new Exception("Cannot process team security setup: ", ex);                    
                }
                finally
                {
                    if (context != null)
                    {
                        context.Dispose();
                    }
                }
            }       
        }
                
        private Role RetrieveRole(CrmServiceClient client, string name, Guid businessUnitId)
        {
            try
            {
                var roleQuery = new QueryExpression
                {
                    EntityName = "role",
                    ColumnSet = new ColumnSet("roleid", "name")
                };
                roleQuery.Criteria.AddCondition("name", ConditionOperator.Equal, name);
                roleQuery.Criteria.AddCondition("businessunitid", ConditionOperator.Equal, businessUnitId);                
                var results = _crmServiceClient.RetrieveMultiple(roleQuery);
                return results[0].ToEntity<Role>();
            }
            catch (Exception)
            {
                throw new Exception(string.Format("Role: \"{0}\" does not exist in the target system.", name));
            }
        }               
    }
}
