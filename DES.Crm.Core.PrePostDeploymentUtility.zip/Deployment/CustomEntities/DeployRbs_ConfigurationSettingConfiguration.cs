﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Xml;
using DES.Crm.Core.CrmEarlyBoundClasses;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using DES.Crm.Core.PrePostDeploymentUtility.XML.CustomEntities;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment.CustomEntities
{
    public class DeployRbs_ConfigurationSettingConfiguration : DeployConfiguration
    {
        readonly rbs_ConfigurationSettingCollection _configurationSettings;

        public DeployRbs_ConfigurationSettingConfiguration(CrmServiceClient service, rbs_ConfigurationSettingCollection configSettings, Logger logger) : base(service, logger)
        {
            _configurationSettings = configSettings;
        }

        public override void DeployConfigurationData()
        {
            if (_configurationSettings.CustomEntityBaseCollection == null || _configurationSettings.CustomEntityBaseCollection.Length == 0)
            {
                _logger.Info("No Configuration Settings to process");
            }

            try
            {
                //Check whether to clear entity data prior to deployment
                if (_configurationSettings.CleanDeploy)
                {
                    var result = _configurationSettings.ClearEntityData(_crmServiceClient, _logger);
                    _logger.Info("Configuration settings deleted: {0}", result);
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Error while clearing existing configuration setting data");
                _logger.Error(ex.Message);
                throw new Exception("ERROR: Clearing existing configuration setting data: ", ex);
            }

            foreach (var tempSetting in _configurationSettings.CustomEntityBaseCollection)
            {
                var _configSetting = (rbs_ConfigurationSetting)tempSetting;   
                try
                {
                    var configSettingRecord = _configSetting.ConvertToEntity(_configurationSettings.EntityName);
                    _crmServiceClient.Create(configSettingRecord);
                    _logger.Info("Configuration Setting Id: \"{0}\" - Name: \"{1}\" created", _configSetting.Id, _configSetting.Name);
                }                       
                catch (Exception ex)
                {
                    _logger.Error("Error while creating configuration setting: {0}", _configSetting.Name);
                    _logger.Error(ex.Message);
                    throw new Exception("ERROR: Cannot create configuration setting: ", ex);
                }
            }
        }
    }
}
