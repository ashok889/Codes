﻿//-----------------------------------------------------------------------
// <copyright file="DeployTeamTemplates.cs" company="NatWest Markets">
//     Copyright (c) NatWest Markets 2017.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.CrmEarlyBoundClasses;
using System;
using DES.Crm.Core.PrePostDeploymentUtility.XML;


namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{ 
    /// <summary>
    /// Deploy team templates functionality.
    /// </summary>
    public class DeployAccessTeamTemplateConfiguration : DeployConfiguration
    {       
        readonly AccessTeamTemplateCollection _accessTeams;
       
        /// <summary>
        /// Initializes a new instance of the <see cref="DeployTeamTemplates" /> class.
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="xmlConfigDocument">Configuration xml document</param>
        /// <param name="logger">NLog logging.</param>
        public DeployAccessTeamTemplateConfiguration(CrmServiceClient service, AccessTeamTemplateCollection accessTeams, Logger logger) : base(service, logger)
        {
            _accessTeams = accessTeams;          
        }

        /// <summary>
        /// Main method to action deployment.
        /// </summary>
        /// <param name="configMode">Pre or Post</param>
        public override void DeployConfigurationData()
        {
            if (_accessTeams.AccessTeamTemplates == null || _accessTeams.AccessTeamTemplates.Length == 0)
            {
                _logger.Info("No Access Teams to process");
                return;
            }
                        
            CrmServiceContext serviceContext = new CrmServiceContext(_crmServiceClient.OrganizationServiceProxy);
            foreach (var accessTeam in _accessTeams.AccessTeamTemplates)
            {
                // Get objecttypecode in target environment using entity name
                var entityName = accessTeam.BaseEntityName;
                var objectTypeCode = GetObjectTypeCode(entityName);
                var name = accessTeam.Name;                          

                var templateToCreate = new TeamTemplate
                {
                    DefaultAccessRightsMask = accessTeam.RightsMask,
                    Id = accessTeam.Id,
                    TeamTemplateName = name,
                    Description = accessTeam.Description,
                    ObjectTypeCode = objectTypeCode
                };

                        
                var request = new UpsertRequest()
                {
                    Target = templateToCreate
                };

                var response = (UpsertResponse)_crmServiceClient.Execute(request);

                if (response.RecordCreated)
                {
                    _logger.Info("Team template {0} with id - {1} Created.", name, accessTeam.Id);
                }
                else
                {
                    _logger.Info("Team template {0} with id - {1} Updated.", name, accessTeam.Id);
                }                
            }
        }     
        /// <summary>
        /// Returns the object type code number given the entity name.
        /// </summary>
        /// <param name="entityName">The logical entity name.</param>
        /// <returns>The integer object type code.</returns>
        private int? GetObjectTypeCode(string entityName)
        {
            var entityRequest = new RetrieveEntityRequest
            {
                LogicalName = entityName
            };
            var response = _crmServiceClient.Execute(entityRequest) as RetrieveEntityResponse;
            var objectTypeCode = response.EntityMetadata.ObjectTypeCode;
            return objectTypeCode;
        }
 
    }
}

