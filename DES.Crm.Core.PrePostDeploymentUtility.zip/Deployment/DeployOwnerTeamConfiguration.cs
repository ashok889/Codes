﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DES.Crm.Core.PrePostDeploymentUtility.Common;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using DES.Crm.Core.CrmEarlyBoundClasses;

namespace DES.Crm.Core.PrePostDeploymentUtility.Deployment
{
    public class DeployOwnerTeamConfiguration : DeployConfiguration
    {        
        readonly OwnerTeamCollection _ownerTeams;

        public DeployOwnerTeamConfiguration(CrmServiceClient service, OwnerTeamCollection ownerTeams, Logger logger) : base (service, logger)
        {
            _ownerTeams = ownerTeams;
        }

        public override void DeployConfigurationData()
        {
            if (_ownerTeams.OwnerTeams == null || _ownerTeams.OwnerTeams.Length == 0)
            {
                _logger.Info("No Owner Teams to process");
            }          
        
            var existingTeams = GetExistingOwnerTeams();
            var admin = ((WhoAmIResponse)_crmServiceClient.Execute(new WhoAmIRequest())).UserId;

            foreach (var ownerTeam in _ownerTeams.OwnerTeams)
            {
                var name = ownerTeam.Name;
                var guid = ownerTeam.Guid;
                var parentbu = ownerTeam.ParentBusinessUnit;              

                if (existingTeams.ContainsKey(guid))
                {
                    _logger.Info("Owner Team: \"{0}\" with id: \"{1}\" already exists in targeted instance. ", name, guid);                    
                }
                else
                {
                    var team = new Team()
                    {                        
                        TeamId = guid,
                        Name = name,
                        TeamType = new OptionSetValue((int)Team_TeamType.Owner),
                        AdministratorId = new EntityReference("systemuser", admin)
                    };

                    CrmEarlyBoundClasses.BusinessUnit buRecord = null;
                    if (parentbu.Equals("root") || string.IsNullOrEmpty(parentbu))
                    {
                        buRecord = BusinessUnitRetriever.GetRootBusinessUnit(_crmServiceClient);                        
                    }
                    else
                    {
                        buRecord = BusinessUnitRetriever.GetBusinessUnitByName(_crmServiceClient, parentbu);                                         
                    }
                    team.BusinessUnitId = buRecord.ToEntityReference(); // new EntityReference("businessunit", new Guid(businessUnitId));

                    try
                    {
                        var teamid = _crmServiceClient.Create(team);
                        _logger.Info("Team: \"{0}\" with id \"{1}\" has been created", name, teamid);                        
                    }
                    catch (Exception ex)
                    {
                        _logger.Error("Not able to create team: \"{0}\"", name);                        
                        _logger.Error(ex);
                    }
                }
                    
            }            
        }

        private Dictionary<Guid, string> GetExistingOwnerTeams()
        {
            var teamDictionary = new Dictionary<Guid, string>();

            QueryExpression ownerteamquery = new QueryExpression
            {
                ColumnSet = new ColumnSet("teamid", "name"),
                EntityName = "team",
                Criteria = new FilterExpression
                {
                    Conditions =
                        {
                            new ConditionExpression
                            {
                                AttributeName = "teamtype",
                                Operator = ConditionOperator.Equal,
                                Values = { 0 } // 0 - owner, 1 - access
                            }
                        }
                }
            };

            DataCollection<Entity> teams;
            //Retrieve the value based on the condition given
            RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = ownerteamquery };
            RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
            teams = retrieveSavedQueriesResponse.EntityCollection.Entities;

            foreach (var team in teams)
            {
                teamDictionary.Add(team.Id, team["name"].ToString());
            }

            return teamDictionary;
        }

        //private string GetRootBusinessUnitId()
        //{
        //    try
        //    {
        //        QueryExpression businessUnitQuery = new QueryExpression
        //        {
        //            ColumnSet = new ColumnSet("businessunitid", "name"),
        //            EntityName = "businessunit",
        //            Criteria = new FilterExpression
        //            {
        //                Conditions =
        //                {
        //                    new ConditionExpression
        //                    {
        //                        AttributeName = "parentbusinessunitid",
        //                        Operator = ConditionOperator.Null,
        //                    }
        //                }
        //            }
        //        };

        //        DataCollection<Entity> dcBUDetails;
        //        //Retrieve the value based on the condition given
        //        RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = businessUnitQuery };
        //        RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
        //        dcBUDetails = retrieveSavedQueriesResponse.EntityCollection.Entities;                

        //        //Return the Guid of the BusinessUnit
        //        if (dcBUDetails.Count == 1 && dcBUDetails[0] != null && dcBUDetails[0].Id != null)
        //        {
        //            return dcBUDetails[0].Id.ToString();
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error("Error while retrieving Guid of Root Business Unit. Exception: " + ex.Message);
        //    }

        //    return null;
        //}

        //private string GetBusinessUnitId(string buName)
        //{
        //    try
        //    {
        //        //Checks whether the BUName is empty or null and then proceed into the query 
        //        if (buName != null && buName.Length > 0)
        //        {
        //            QueryExpression businessUnitQuery = new QueryExpression
        //            {
        //                ColumnSet = new ColumnSet("businessunitid", "name"),
        //                EntityName = "businessunit",
        //                Criteria = new FilterExpression
        //                {
        //                    Conditions =
        //                    {
        //                        new ConditionExpression
        //                        {
        //                            AttributeName = "name",
        //                            Operator = ConditionOperator.Equal,
        //                            Values = { buName }
        //                        }
        //                    }
        //                }
        //            };

        //            DataCollection<Entity> dcBUDetails;
        //            //Retrieve the value based on the condition given
        //            RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = businessUnitQuery };
        //            RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
        //            dcBUDetails = retrieveSavedQueriesResponse.EntityCollection.Entities;

        //            //Return the Guid of the BusinessUnit
        //            if (dcBUDetails.Count == 1)
        //            {
        //                if (dcBUDetails[0] != null)
        //                {
        //                    if (dcBUDetails[0].Id != null)
        //                    {
        //                        return dcBUDetails[0].Id.ToString();
        //                    }
        //                }
        //            }
       
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.Error("Error while retrieving Guid of Business Unit. Exception: " + ex.Message);
        //    }

        //    return null;
        //}
    }
}
