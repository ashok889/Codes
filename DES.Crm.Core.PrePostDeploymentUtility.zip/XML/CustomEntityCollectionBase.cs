﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using DES.Crm.Core.PrePostDeploymentUtility.XML.CustomEntities;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlInclude(typeof(rbs_ConfigurationSettingCollection))]
    public abstract class CustomEntityCollectionBase : CollectionBase
    {
        public CustomEntityCollectionBase() { }

        #region Variables
        [XmlElement("rbs_configurationsetting", typeof(rbs_ConfigurationSetting))]
        public CustomEntityBase[] CustomEntityBaseCollection
        {
            get;
            set;
        }

        [XmlAttribute("entityname")]
        public string EntityName
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool CleanDeploy
        {
            get;
            set;
        }

        [XmlAttribute("cleandeploy")]
        public string CleanDeployString
        {
            get
            {
                return XmlConvert.ToString(Action);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                CleanDeploy = parsedValue;
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Clears all entity data from the specific entity
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public int ClearEntityData(CrmServiceClient service, Logger logger)
        {
            var numberDeleted = 0;
            var primaryKeyId = EntityName + "id";
            if (!CleanDeploy)
            {
                return 0;
            }

            logger.Info("Clearing data from entity: " + EntityName);
            var query = new QueryExpression()
            {
                EntityName = this.EntityName,
                ColumnSet = new ColumnSet(primaryKeyId)
            };
            var results = service.RetrieveMultiple(query);

            foreach (var record in results.Entities)
            {
                numberDeleted++;
                service.Delete(this.EntityName, new Guid(record[primaryKeyId].ToString()));
            }
            return numberDeleted;
        }
        #endregion
    }
}