﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot(ElementName = "accessteamtemplate")]
    public class AccessTeamTemplate
    {
        public AccessTeamTemplate() { }

        public AccessTeamTemplate(string name, string Id, string description, int rightsmask, string baseEntityName)
        {
            Name = name;
            Description = description;
            RightsMask = rightsmask;
            BaseEntityName = baseEntityName;
        }


        #region Variables
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        [XmlAttribute("id")]
        public Guid Id
        {

            get;
            set;
        }

        [XmlAttribute("description")]
        public string Description
        {
            get;
            set;
        }

        [XmlAttribute("rightsmask")]
        public int RightsMask
        {
            get;
            set;
        }

        [XmlAttribute("baseentityname")]
        public string BaseEntityName
        {
            get;
            set;
        }
        #endregion
    }
}
