﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("duplicaterulecondition")]
    public class DuplicateRuleCondition
    {

        #region Constructor
        public DuplicateRuleCondition() { }

        public DuplicateRuleCondition(string baseattributename, Boolean ignoreblankvalues, string matchingattributename, int operatorcode)
        {
            BaseAttributeName = baseattributename;
            IgnoreBlankValues = ignoreblankvalues;
            MatchingAttributeName = matchingattributename;
            OperatorCode = operatorcode;
        }
        #endregion


        [XmlAttribute("baseattributename")]
        #region Variables
        public string BaseAttributeName
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool IgnoreBlankValues
        {
            get;
            set;
        }

        [XmlAttribute("ignoreblankvalues")]
        public string IgnoreBlankValuesString
        {
            get
            {
                return XmlConvert.ToString(IgnoreBlankValues);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                IgnoreBlankValues = parsedValue;
            }
        }

        [XmlAttribute("matchingattributename")]
        public string MatchingAttributeName
        {
            get;
            set;
        }

        [XmlAttribute("operatorcode")]
        public int OperatorCode
        {
            get;
            set;
        }
        #endregion
    }
}