﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using DES.Crm.Core.CrmEarlyBoundClasses;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]    
    [XmlRoot(ElementName = "queue")]
    public class Queue
    {
        /*public Queue() { }

        public Queue(string name, Guid id)
        {
            Name = name;
            Id = id;            
        }*/


        #region Variables
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        [XmlAttribute("id")]
        public Guid Id
        {
            get;
            set;
        }

        [XmlIgnore]
        public Queue_QueueViewType QueueTypeEnum
        {
            get
            {
               return (Queue_QueueViewType)Enum.Parse(typeof (Queue_QueueViewType), QueueType, true);
            }
            set
            {
                QueueType =  Enum.GetName(typeof(Queue_QueueViewType), value);
            }
        }

        [XmlAttribute("queuetype")]
        public string QueueType
        {
            get;
            set;
        }

        
        [XmlIgnore]
        public Enums.OwnerType OwnerTypeEnum
        {
            get
            {
                return (Enums.OwnerType)Enum.Parse(typeof(Enums.OwnerType), OwnerType, true);
            }
            set
            {
                OwnerType = Enum.GetName(typeof(Enums.OwnerType), value);
            }
        }

        [XmlAttribute("ownertype")]
        public string OwnerType
        {
            get;
            set;            
        }

        [XmlAttribute("owner")]
        public Guid Owner
        {
            get;
            set;
        }
        #endregion
    }
}
