﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{

    [Serializable]
    [XmlRoot(ElementName = "crmconnection")]    
    public sealed class CRMConnection
    {             
        public CRMConnection() {}

        public CRMConnection(int id, string name, string organization, string user, string pass, string region, string authType, bool requireNewInstance)
        {
            Name = name;
            OrganizationUrl = organization;
            CrmUserId = user;
            CrmUserPassword = pass;
            RequireNewInstance = requireNewInstance;
            AuthType = authType;
            BuildConnectingString();
        }

        public void BuildConnectingString()
        {
            ConnnectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}", RequireNewInstance, OrganizationUrl, CrmUserId, CrmUserPassword, AuthType);
        }


        [XmlAttribute("organizationurl")]
        public string OrganizationUrl
        {
            get;
            set;
        }

        [XmlAttribute("crmuserid")]
        public string CrmUserId
        {
            get;
            set;
        }

        [XmlAttribute("crmuserpassword")]
        public string CrmUserPassword
        {
            get;
            set;
        }

        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        [XmlAttribute("requirenewinstance")]
        public bool RequireNewInstance
        {
            get;
            set;
        }

        [XmlAttribute("authtype")]
        public string AuthType
        {
            get;
            set;
        }

        [XmlIgnore]
        public string ConnnectionString
        {
            get;
            set;
        }

        [XmlAttribute("id")]
        public string Id
        {
            get;
            set;
        }
    }
}