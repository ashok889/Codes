﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("businessunits")]
    public sealed class BusinessUnitCollection : CollectionBase
    {
        //[XmlArrayItem(ElementName = "ownerteam")]
        [XmlElement("businessunit")]
        public BusinessUnit[] BusinessUnits
        {
            get;
            set;
        }

        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployBusinessUnitConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }
    }
}
