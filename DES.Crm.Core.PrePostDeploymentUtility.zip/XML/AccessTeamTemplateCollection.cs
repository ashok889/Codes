﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;
using Microsoft.Xrm.Tooling.Connector;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("accessteamtemplates")]
    public sealed class AccessTeamTemplateCollection : CollectionBase
    {        
        //[XmlArray(ElementName = "accessteamtemplate")]
        //[XmlArrayItem(typeof(AccessTeamTemplate))]
        [XmlElement("accessteamtemplate")]
        public AccessTeamTemplate[] AccessTeamTemplates
        {
            get;
            set;
        } 
        
        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployAccessTeamTemplateConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }       
    }
}
