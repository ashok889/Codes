﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xrm.Tooling.Connector;
using NLog;


namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    public abstract class CollectionBase
    {
        //public virtual void DeployConfigurationData(CrmServiceClient client, Logger logger) { }
        public abstract void DeployConfigurationData(CrmServiceClient client, Logger logger);

        #region Variables
        [XmlIgnore]
        public bool Action
        {
            get;
            set;
        }

        [XmlAttribute("action")]        
        public string ActionString
        {
            get
            {
                return XmlConvert.ToString(Action);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                Action = parsedValue;
            }
        }
        #endregion
    }
}
