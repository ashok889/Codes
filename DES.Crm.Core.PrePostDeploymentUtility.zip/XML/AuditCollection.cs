﻿using System;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("audit")]
    public sealed class AuditCollection : CollectionBase
    {
        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployAuditConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }

        #region Variables
        [XmlElement("audititem")]
        public AuditItem[] AuditItems
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool Enabled
        {
            get;
            set;
        }

        [XmlAttribute("enabled")]
        public string EnabledString
        {
            get
            {
                return XmlConvert.ToString(Enabled);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                Enabled = parsedValue;
            }
        }
        #endregion
    }
}
