﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using DES.Crm.Core.PrePostDeploymentUtility.XML.CustomEntities;
using Microsoft.Xrm.Tooling.Connector;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("customentities")]
    public sealed class CustomEntitiesCollection : CollectionBase
    {        
        [XmlElement("rbs_configurationsettings", typeof(rbs_ConfigurationSettingCollection))]
        public CustomEntityCollectionBase[] CustomEntities
        {
            get;
            set;
        }

        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            throw new NotImplementedException();
        }
    }
}