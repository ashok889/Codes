﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot(ElementName = "teamsecurityrole")]
    public class TeamSecurityRole
    {
        /*public TeamSecurityRole() { }

        public TeamSecurityRole(string teamname, Guid teamid, string securityrolename)
        {
            TeamName = teamname;
            TeamId = teamid;
            SecurityRoleName = securityrolename;            
        }*/


        #region Variables
        [XmlAttribute("teamname")]
        public string TeamName
        {
            get;
            set;
        }

        [XmlAttribute("teamid")]
        public Guid TeamId
        {
            get;
            set;
        }

        [XmlAttribute("securityrolename")]
        public string SecurityRoleName
        {
            get;
            set;
        }

        [XmlAttribute("securityroleid")]
        public Guid SecurityRoleId
        {
            get;
            set;
        }
        #endregion
    }
}