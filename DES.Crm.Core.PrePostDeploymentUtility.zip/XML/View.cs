﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot(ElementName = "view")]
    public class View
    {
        #region Constructor
        public View() { }

        public View (string name, string baseentityname, bool isDefault)
        {
            Name = name;
            BaseEntityName = baseentityname;
            IsDefault = isDefault;
        }
        #endregion

        #region Variables
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        [XmlAttribute("baseentityname")]
        public string BaseEntityName
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool IsDefault
        {
            get;
            set;
        }

        [XmlAttribute("isdefault")]
        public string IsDefaultString
        {
            get
            {
                return XmlConvert.ToString(IsDefault);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                IsDefault = parsedValue;
            }
        }

        #endregion
    }
}
