﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("Config")]
    public sealed class XMLConfig
    {
        public XMLConfig() { }

        public XMLConfig(CRMConnection[] connections, Pre precontents, Post postcontents)
        {
            Connections = Connections;
            PreContents = precontents;
            PostContents = postcontents;
        }
        
        [XmlElement("crmconnections")]        
        public CRMConnectionCollection Connections
        {
            get;
            set;
        }

        [XmlElement("pre")]
        public Pre PreContents
        {
            get;
            set;
        }

        [XmlElement("post")]
        public Post PostContents
        {
            get;
            set;
        }
    }
}
