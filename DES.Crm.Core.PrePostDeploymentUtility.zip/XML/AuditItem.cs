﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{   
    [Serializable]
    [XmlRoot(ElementName = "audititem")]
    public class AuditItem
    {        
        public AuditItem() { }

        public AuditItem(string entity, Boolean enabled)
        {
            Entity = entity;
            Enabled = enabled;
        }


        #region Variables
        [XmlAttribute("entity")]
        public string Entity
        {
            get;
            set;        
        }

        [XmlIgnore]
        public bool Enabled
        {
            get;
            set;
        }

        [XmlAttribute("enabled")]
        public string EnabledString
        {
            get
            {
                return XmlConvert.ToString(Enabled);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                Enabled = parsedValue;
            }
        }
        #endregion
    }
}
