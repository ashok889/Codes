﻿using System;
using System.Xml.Serialization;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;
using Microsoft.Xrm.Tooling.Connector;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("post")]
    public sealed class Post : ElementContents
    {
        public Post() : base("post") { }

        public void DeployConfigurationSettings(CrmServiceClient client, Logger logger)
        {
            // Deploy audit settings
            if (Audits.Action)
            {
                LogStart(string.Format("\"{0}\" Audit configuration at Org level and Entity level", _prePost), logger);
                Audits.DeployConfigurationData(client, logger);
                LogCompletion("audit", logger);
            }

            // Deploy Teams security roles
            if (TeamSecurityRoles.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Default security role assignments to teams", _prePost), logger);                
                TeamSecurityRoles.DeployConfigurationData(client, logger);
                LogCompletion("Team security roles", logger);
            }

            // Deploy queues
            if (Queues.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Creation and update of queues", _prePost), logger);                  
                Queues.DeployConfigurationData(client, logger);
                LogCompletion("Queues", logger);
            }


            // Deploy duplicate rules
            if (DuplicateRules.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Creation of duplicate detection rules", _prePost), logger);
                DuplicateRules.DeployConfigurationData(client, logger);
                LogCompletion("Duplicage rules", logger);
            }

            // Deploy views
            if (Views.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Creation of entity views", _prePost), logger);
                Views.DeployConfigurationData(client, logger);
                LogCompletion("Views", logger);
            }

            // Workflow Actions
            if (WorkflowActions.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Workflow actions", _prePost), logger);
                WorkflowActions.DeployConfigurationData(client, logger);
                LogCompletion("Workflow Actions", logger);
            }

            if (CustomEntities.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Custom entities", _prePost), logger);               
                foreach (var customEntityCollection in CustomEntities.CustomEntities)
                {
                    LogStart(string.Format("\"{0}\" deployment: {1}", _prePost, customEntityCollection.EntityName), logger);
                    customEntityCollection.DeployConfigurationData(client, logger);
                }
                LogCompletion("Custom Entities Actions", logger);
            }
        }
    }
}
