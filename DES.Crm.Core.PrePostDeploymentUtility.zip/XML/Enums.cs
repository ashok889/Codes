﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    public class Enums
    {        
        public enum OwnerType
        {
            SystemUser = 8,
            Team = 9
        }
        
        public enum ActionType
        {
            Activate = 0,
            Deactivate = 1        
        }        
    }
}
