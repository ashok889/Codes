﻿using System;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("teamsecurityroles")]
    public sealed class TeamSecurityRoleCollection : CollectionBase
    {
        //[XmlArrayItem(ElementName = "teamsecurityrole")]
        [XmlElement("teamsecurityrole")]
        public TeamSecurityRole[] TeamSecurityRoles
        {
            get;
            set;
        }

        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployTeamSecurityRoleConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }
    }
}
