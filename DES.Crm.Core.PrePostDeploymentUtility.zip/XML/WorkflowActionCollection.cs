﻿using System;
using System.Xml.Serialization;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("workflowactions")]
    public class WorkflowActionCollection : CollectionBase
    {

        [XmlElement("workflowaction")]
        public WorkflowAction[] WorkflowActions
        {
            get;
            set;
        }


        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployWorkflowActionConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }
    }
}
