﻿using System;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("views")]
    public class ViewCollection : CollectionBase
    {
        [XmlElement("view")]
        public View[] Views
        {
            get;
            set;  
        }

        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployEntityViewConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }
    }
}
