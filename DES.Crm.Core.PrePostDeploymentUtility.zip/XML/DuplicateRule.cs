﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot(ElementName = "duplicaterule")]
    public class DuplicateRule
    {
        List<DuplicateRuleCondition> _dupes;


        #region Constructor
        public DuplicateRule() {
            _dupes = new List<DuplicateRuleCondition>();
        }

        public DuplicateRule(string name, 
            string baseentityname, 
            bool ignoreblankvalues, 
            int baseentitytypecode,
            bool iscasesensitive,
            bool excludeactiverecords, 
            string matchingentityname,
            int matchingentitytypecode,
            string description,
            bool delete) : base() 
        {
            Name = name;
            BaseEntityName = baseentityname;
            IgnoreBlankValues = ignoreblankvalues;
            BaseEntityTypeCode = baseentitytypecode;
            IsCaseSensitive = iscasesensitive;
            ExcludeActiveRecords = excludeactiverecords;
            MatchingEntityName = matchingentityname;
            MatchingEntityTypeCode = matchingentitytypecode;
            Description = description;
            Delete = delete;            
        }
        #endregion

        #region Variables
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        [XmlAttribute("baseentityname")]
        public string BaseEntityName
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool IgnoreBlankValues
        {
            get;
            set;
        }

        [XmlAttribute("ignoreblankvalues")]
        public string IgnoreBlankValuesString
        {
            get
            {
                return XmlConvert.ToString(IgnoreBlankValues);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                IgnoreBlankValues = parsedValue;
            }
        }

        [XmlAttribute("baseentitytypecode")]
        public int BaseEntityTypeCode
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool IsCaseSensitive
        {
            get;
            set;
        }

        [XmlAttribute("iscasesensitive")]
        public string IsCaseSensitiveString
        {
            get
            {
                return XmlConvert.ToString(IsCaseSensitive);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                IsCaseSensitive = parsedValue;
            }
        }

        [XmlIgnore]
        public bool ExcludeActiveRecords
        {
            get;
            set;
        }

        [XmlAttribute("excludeactiverecords")]
        public string ExcludeActiveRecordsString
        {
            get
            {
                return XmlConvert.ToString(ExcludeActiveRecords);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                ExcludeActiveRecords = parsedValue;
            }
        }

        [XmlAttribute("matchingentityname")]
        public string MatchingEntityName
        {
            get;
            set;
        }

        [XmlAttribute("matchingentitytypecode")]
        public int MatchingEntityTypeCode
        {
            get;
            set;
        }

        [XmlAttribute("description")]
        public string Description
        {
            get;
            set;
        }

        [XmlIgnore]
        public bool Delete
        {
            get;
            set;
        }

        [XmlAttribute("delete")]
        public string DeleteString
        {
            get
            {
                return XmlConvert.ToString(Delete);
            }

            set
            {
                bool parsedValue;
                if (!bool.TryParse(value, out parsedValue))
                {
                    parsedValue = XmlConvert.ToBoolean(value);
                }
                Delete = parsedValue;
            }
        }

        /*[XmlArray(ElementName = "duplicaterulecondition")]
        [XmlArrayItem(typeof(DuplicateRuleCondition))]
        public List<DuplicateRuleCondition> DuplicateRuleConditions
        {
            get
            {
                return _dupes;
            }
            private set
            {
                _dupes = new List<DuplicateRuleCondition>();
            }
        }*/

        [XmlElement("duplicaterulecondition")]
        public DuplicateRuleCondition[] DuplicateRuleConditions
        {
            get;
            set;
        }
        #endregion
    }
}


 
          
        