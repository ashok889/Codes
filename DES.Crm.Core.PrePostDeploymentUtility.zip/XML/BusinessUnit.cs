﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("businessunit")]
    public class BusinessUnit
    {
        public BusinessUnit() { }

        public BusinessUnit(string name, string parentbu)
        {
            Name = name;            
            ParentBusinessUnit = parentbu;
        }


        #region Variables
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        } 

        [XmlAttribute("parentbusinessunit")]
        public string ParentBusinessUnit
        {
            get;
            set;
        }
        #endregion
    }
}