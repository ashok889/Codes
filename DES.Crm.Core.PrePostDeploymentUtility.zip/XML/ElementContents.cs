﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlInclude(typeof(Pre))]
    [XmlInclude(typeof(Post))]
    public abstract class ElementContents
    {
        protected readonly string _prePost;        

        public ElementContents(string prePostAction)
        {
            _prePost = prePostAction;           
        }

        public void LogStart(string startType, Logger logger)
        {
            logger.Info("Performing {0}", startType);
            logger.Info("--------------------------------------------------------------------------");
        }

        public void LogCompletion(string completionType, Logger logger)
        {
            logger.Info("Completed {0} deployment actions", completionType);
            logger.Info("---------------------------------------------------------------------------");
            logger.Info("");
        }

        // In both
        [XmlElement("audit")]
        public AuditCollection Audits
        {
            get;
            set;
        }
        

        //pre
        [XmlElement("businessunits")]
        public BusinessUnitCollection BusinessUnits
        {
            get;
            set;
        }

        [XmlElement("ownerteams")]
        public OwnerTeamCollection OwnerTeams
        {
            get;
            set;
        }

        [XmlElement("accessteamtemplates")]
        public AccessTeamTemplateCollection AccesssTeams
        {
            get;
            set;
        }
        

        //post
        [XmlElement("teamsecurityroles")]
        public TeamSecurityRoleCollection TeamSecurityRoles
        {
            get;
            set;
        }

        [XmlElement("queues")]
        public QueueCollection Queues
        {
            get;
            set;
        }

        [XmlElement("duplicaterules")]
        public DuplicateRuleCollection DuplicateRules
        {
            get;
            set;
        }

        [XmlElement("views")]
        public ViewCollection Views
        {
            get;
            set;
        }

        [XmlElement("workflowactions")]
        public WorkflowActionCollection WorkflowActions
        {
            get;
            set;
        }

        [XmlElement("customentities")]
        public CustomEntitiesCollection CustomEntities
        {
            get;
            set;
        }
    }
}
