﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{ 
    [Serializable]
    [XmlRoot(ElementName = "ownerteam")]
    public class OwnerTeam
    {
        public OwnerTeam() { }

        public OwnerTeam(string name, Guid guid, string parentbu)
        {
            Name = name;
            Guid = guid;
            ParentBusinessUnit = parentbu;
        }


        #region Variables
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        [XmlAttribute("guid")]
        public Guid Guid
        {
            get;
            set;
        }

        [XmlAttribute("parentbusinessunit")]
        public string ParentBusinessUnit
        {
            get;
            set;
        }
        #endregion
    }
}