﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("workflowaction")]
    public class WorkflowAction
    {
        #region Variables
        [XmlAttribute("workflowname")]
        public string WorkflowName
        {
            get;
            set;
        }        

        [XmlAttribute("actiontype")]
        public string ActionType 
        {
            get;
            set;
        }

        [XmlIgnore]
        public Enums.ActionType ActionTypeEnum
        {
            get
            {
                return (Enums.ActionType)Enum.Parse(typeof(Enums.ActionType), ActionType, true);
            }
            set
            {
                ActionType = Enum.GetName(typeof(Enums.OwnerType), value);
            }
        }       
        #endregion
    }
}
