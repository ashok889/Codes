﻿using System;
using System.Xml.Serialization;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment;
using Microsoft.Xrm.Tooling.Connector;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]   
    [XmlRoot("pre")]
    public sealed class Pre : ElementContents    
    {
        public Pre() : base("pre") { }

        public void DeployConfigurationSettings(CrmServiceClient client, Logger logger)
        {
            // Deploy audit settings
            if (Audits.Action) {
                LogStart(string.Format("\"{0}\" Audit configuration at Org level and Entity level", _prePost), logger);
                Audits.DeployConfigurationData(client, logger);
                LogCompletion("Audit", logger);
            }

            // Deploy Business Units
            if (BusinessUnits.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Creation of Business Units", _prePost), logger);
                BusinessUnits.DeployConfigurationData(client, logger);
                LogCompletion("Business Units", logger);
            }


            // Deploy owner teams
            if (OwnerTeams.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Creation of Owner teams", _prePost), logger);
                OwnerTeams.DeployConfigurationData(client, logger);
                LogCompletion("Owner Teams", logger);
            }
            
                        
            // Deploy access teams
            if (AccesssTeams.Action)
            {
                LogStart(string.Format("\"{0}\" deployment: Creation of Access teams", _prePost), logger);
                AccesssTeams.DeployConfigurationData(client, logger);
                LogCompletion("Access Teams", logger);
            }            
        }       
    }
}
