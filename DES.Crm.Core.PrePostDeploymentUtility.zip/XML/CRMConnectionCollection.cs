﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML
{
    [Serializable]
    [XmlRoot("crmconnections")]
    public sealed class CRMConnectionCollection
    {
        //[XmlArray("crmconnection")]
        //[XmlArrayItem(typeof(CRMConnection))]
        [XmlElement("crmconnection")]
        public CRMConnection[] CRMConnections
        {
            get;
            set;
        }
    }
}