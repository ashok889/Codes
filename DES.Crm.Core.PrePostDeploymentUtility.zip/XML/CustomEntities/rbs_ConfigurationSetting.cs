﻿using System;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML.CustomEntities
{
    [Serializable]
    [XmlRoot("rbs_configurationsetting")]
    public class rbs_ConfigurationSetting : CustomEntityBase
    {
        #region Methods
        public override Entity ConvertToEntity(string entityName)
        {
            var newRecord = new Entity()
            {
                LogicalName = entityName,
                Id = Id,               
            };            
            newRecord.Attributes.Add("rbs_name", Name);
            newRecord.Attributes.Add("rbs_key", Key);
            newRecord.Attributes.Add("rbs_value", Value);
            newRecord.Attributes.Add("rbs_description", Description);
            return newRecord;
        }
        #endregion

        #region Variables
        [XmlAttribute("id")]
        public Guid Id
        {
            get;
            set;
        }
        
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }
        
        [XmlAttribute("key")]
        public string Key
        {
            get;
            set;
        }
        
        [XmlAttribute("value")]
        public string Value
        {
            get;
            set;
        }
        
        [XmlAttribute("description")]
        public string Description
        {
            get;
            set;
        }        
        #endregion
    }
}