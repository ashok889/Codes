﻿using System;
using System.Xml.Serialization;
using Microsoft.Xrm.Sdk;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML.CustomEntities
{
    [Serializable]
    [XmlInclude(typeof(rbs_ConfigurationSetting))]
    public abstract class CustomEntityBase
    {
        public abstract Entity ConvertToEntity(string entityName);        
    }
}
