﻿using System;
using System.Xml.Serialization;
using DES.Crm.Core.PrePostDeploymentUtility.Deployment.CustomEntities;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using Microsoft.Xrm.Tooling.Connector;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility.XML.CustomEntities
{
    [Serializable]
    [XmlRoot("rbs_configurationsettings")]
    public sealed class rbs_ConfigurationSettingCollection : CustomEntityCollectionBase
    {
        public rbs_ConfigurationSettingCollection() : base()
        {
            EntityName = "rbs_configurationsetting";
        }

        public override void DeployConfigurationData(CrmServiceClient client, Logger logger)
        {
            var deployment = new DeployRbs_ConfigurationSettingConfiguration(client, this, logger);
            deployment.DeployConfigurationData();
        }
    }
}
