﻿using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using DES.Crm.Core.CrmEarlyBoundClasses;

namespace DES.Crm.Core.PrePostDeploymentUtility.Common
{
    public class TeamRetriever
    {
        public static Team RetrieveTeamByName(CrmServiceClient client, string name)
        {
            try
            {
                var query = new QueryExpression()
                {
                    EntityName = Team.EntityLogicalName,
                    ColumnSet = new ColumnSet("name", "teamid", "businessunitid"),
                };
                query.Criteria.AddCondition("name", ConditionOperator.Equal, name);
                var results = client.RetrieveMultiple(query);

                return results[0].ToEntity<Team>();
            }
            catch (Exception e)
            {
                throw new Exception(string.Format("Team: \"{0}\" does not exist in the target system.", name));
            }
        }
    }
}
