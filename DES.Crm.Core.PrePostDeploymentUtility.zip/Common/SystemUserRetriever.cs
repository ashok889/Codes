﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using DES.Crm.Core.CrmEarlyBoundClasses;
using System;
using System.Linq;
using System.Collections.Generic;

namespace DES.Crm.Core.PrePostDeploymentUtility.Common
{
    public class SystemUserRetriever
    {
        public static List<SystemUser> RetrieveSystemUserByName(CrmServiceClient client, string fullname)
        {
            try
            {
                QueryExpression systemuserQuery = new QueryExpression
                {
                    ColumnSet = new ColumnSet("systemuserid", "fullname"),
                    EntityName = SystemUser.EntityLogicalName
                };
                systemuserQuery.Criteria.AddCondition("fullname", ConditionOperator.Equal, fullname);                            

                var result = client.RetrieveMultiple(systemuserQuery);
                return result.Entities.Select(p => p.ToEntity<SystemUser>()).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error while retrieving CRM user with fullname: \"{0}\" from target CRM instance. Exception: {1} ", fullname, ex.Message), ex);
            }
        }
    }
}
