﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using DES.Crm.Core.CrmEarlyBoundClasses;
using System;

namespace DES.Crm.Core.PrePostDeploymentUtility.Common
{
    public class BusinessUnitRetriever
    {
        public static BusinessUnit GetRootBusinessUnit(CrmServiceClient client)
        {
            try
            {
                QueryExpression businessUnitQuery = new QueryExpression
                {
                    ColumnSet = new ColumnSet("businessunitid", "name"),
                    EntityName = BusinessUnit.EntityLogicalName,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression
                            {
                                AttributeName = "parentbusinessunitid",
                                Operator = ConditionOperator.Null,
                            }
                        }
                    }
                };

                var result = client.RetrieveMultiple(businessUnitQuery);
                return result.Entities[0].ToEntity<BusinessUnit>();
            }
            catch (Exception ex)
            {
                throw new Exception("Error while retrieving the root business unit from the target CRM instance. Exception: " + ex.Message, ex);
            }            
        }

        public static BusinessUnit GetBusinessUnitByName(CrmServiceClient client, string buName)
        {
            if (string.IsNullOrEmpty(buName))
            {
                throw new Exception("No name for the busines unit has been supplied");
            }

            try
            {                
                var businessUnitQuery = new QueryExpression
                {
                    ColumnSet = new ColumnSet("businessunitid", "name"),
                    EntityName = BusinessUnit.EntityLogicalName,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression
                            {
                                AttributeName = "name",
                                Operator = ConditionOperator.Equal,
                                Values = { buName }
                            }
                        }
                    }
                };
                var result = client.RetrieveMultiple(businessUnitQuery);
                return result.Entities[0].ToEntity<BusinessUnit>();                
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Error while retrieving business Unit with name: \"{0}\" from the target CRM instance. Exception: {1}", buName, ex.Message), ex);                
            }           
        }
    }
}
