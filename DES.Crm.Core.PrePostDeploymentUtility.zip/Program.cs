﻿using NLog;
using System;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Crm.Sdk.Messages;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    class Program
    {
        static CrmServiceClient _crmServiceClient;
        //static XmlDocument _xmlConfigDocument;
        static string _configMode;
        static Logger Logger;
        static CommandLineBuilderOptions command;
        static void Main(string[] args)
        {
            try
            {
                Logger = LogManager.GetLogger("Default");
                _configMode = "pre";
                command = new CommandLineBuilderOptions(Logger);
                var result = command.Execute(args);

                if (result != 0)
                {
                    Logger.Info("Parameters Error. Exiting Application");
                    Environment.Exit(0);
                }
                CreateServiceObject();

                Logger.Info("Starting \"{0}\" CRM Deployment steps...", command.PrePostAction);
                Logger.Info("----------------------------------------------");
                Logger.Info("");
                switch (command.PrePostAction.ToLower())
                {
                    case "pre":                        
                        command.XMLConfiguration.PreContents.DeployConfigurationSettings(_crmServiceClient, Logger);
                        break;
                    case "post":
                        command.XMLConfiguration.PostContents.DeployConfigurationSettings(_crmServiceClient, Logger);
                        break;

                }
                Logger.Info("Deployment action: \"{0}\" complete. Exiting Application", command.PrePostAction);
                Environment.Exit(0);

                /*_configMode = "pre"; // utility running mode: pre or post; it is running pre deployment setup by default
                if (args.Length > 0) _configMode = args[0].ToLower();

                if (!_configMode.Equals("pre") && !_configMode.Equals("post"))
                {
                    throw new Exception("Invalid configuration mode.");
                }*/

                //_xmlConfigDocument = new XmlDocument();
                //_xmlConfigDocument.Load(command.ConfigFile);

                //// Initialize connection
                //CreateServiceObject();

                //if (_configMode.Equals("post"))
                //{
                //    Logger.Info(string.Format("Starting {0} CRM Deployment steps...", _configMode));

                //    // post scripts
                //    // Managing Auditing at Org level and Entity level.
                //    Logger.Info(string.Format("Starting {0} Managing Audit at Org level and Entity level...", _configMode));
                //    var manageAudit = new ManageAudit(_crmServiceClient, _xmlConfigDocument, Logger);
                //    manageAudit.ConfigureAudit(_configMode);

                //    // Setup owner teams' security role
                //    Logger.Info(string.Format("Starting {0} owner team security role setup steps...", _configMode));
                //    var ownerteamroleprocessor = new DeployOwnerTeamSecurityRole(_crmServiceClient, _xmlConfigDocument, Logger);
                //    ownerteamroleprocessor.SettingTeamSecurityRoles(_configMode);

                //    // Include: Duplicate detection rules, business unit setup, email profile setup, other configuration changes
                //    Logger.Info(string.Format("Starting {0} Duplicate rule creation steps...", _configMode));
                //    var duplicationDetectionRuleProcessor = new DeployDuplicateDetectionRules(_crmServiceClient, _xmlConfigDocument, Logger);
                //    duplicationDetectionRuleProcessor.ProcessDuplicateDetectionRules(_configMode);

                //    // Views status configuration
                //    Logger.Info(string.Format("Starting {0} setting entity views...", _configMode));
                //    var entityViewProcessor = new DeployEntityViewProperties(_crmServiceClient, _xmlConfigDocument, Logger);
                //    entityViewProcessor.SettingEntityViewProperties(_configMode);

                //}
                //else
                //{
                //    // pre scripts
                //    // Include: Organizational configurations
                //    Logger.Info(string.Format("Starting {0} CRM Deployment steps...", _configMode));
                //    // Managing Auditing at Org level and Entity level.
                //    Logger.Info(string.Format("Starting {0} Managing Audit at Org level and Entity level...", _configMode));
                //    var manageAudit = new ManageAudit(_crmServiceClient, _xmlConfigDocument, Logger);
                //    manageAudit.ConfigureAudit(_configMode);

                //    Logger.Info(string.Format("Starting {0} Access Team Template Setup steps...", _configMode));
                //    var accessTeamTemplateSetupProcessor = new DeployTeamTemplates(_crmServiceClient, _xmlConfigDocument, Logger);
                //    accessTeamTemplateSetupProcessor.Setting(_configMode);

                //    Logger.Info(string.Format("Starting {0} Owner Team Setup steps...", _configMode));
                //    var ownerTeamSetupProcessor = new DeployOwnerTeams(_crmServiceClient, _xmlConfigDocument, Logger);
                //    ownerTeamSetupProcessor.SettingOwnerTeams(_configMode);
                //}
            }
            catch (Exception ex)
            {
                Logger.Info(string.Format("CRM Pre Post Executable Utility failed with the following Exception, during {0} Execution", _configMode));
                Logger.Info("Exception message: " + ex.Message);
                Logger.Info("Exception innerexception: " + ex.InnerException);
                Logger.Info("Stack trace: " + ex.StackTrace);
                Console.WriteLine(ex.Message);
                Environment.ExitCode = -1;
            }
        }

        static void CreateServiceObject()
        {
            /*string orgName = "";
            string crmUserId = "";
            string crmUserPassword = "";

            if (_xmlConfigDocument.SelectSingleNode("Config/OrgName") != null)
            {
                orgName = _xmlConfigDocument.SelectSingleNode("Config/OrgName").InnerText;
            }

            if (_xmlConfigDocument.SelectSingleNode("Config/CrmUserId") != null)
            {
                crmUserId = _xmlConfigDocument.SelectSingleNode("Config/CrmUserId").InnerText;
            }

            if (_xmlConfigDocument.SelectSingleNode("Config/CrmUserPassword") != null)
            {
                crmUserPassword = _xmlConfigDocument.SelectSingleNode("Config/CrmUserPassword").InnerText;
            }*/

            //var conn = commandLine.XMLConfiguration.Connections.CRMConnections[commandLine.TargetEnvironmentId];
            var conn = command.TargetEnvironment;
            try
            {
                // Encyption and decryption method can be made more secured if required. 
                //Use the below two lines if you put in plain pwd in the config xml
                //var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(crmUserPassword);
                //crmUserPassword = System.Convert.ToBase64String(plainTextBytes);
                
                //byte[] data = Convert.FromBase64String(conn.CrmUserPassword);
                //string password = Encoding.UTF8.GetString(data);
                //_crmServiceClient = new CrmServiceClient(crmUserId: crmUserId, crmPassword: CrmServiceClient.MakeSecureString(password), crmRegion: "EMEA", orgName: orgName, isOffice365: true);

                Logger.Info("Creating connection to CRM organization: " + conn.Name);
                conn.BuildConnectingString();               
                _crmServiceClient = new CrmServiceClient(conn.ConnnectionString);

                var whoAmI = (WhoAmIResponse)_crmServiceClient.Execute(new WhoAmIRequest());               
            }
            catch (Exception ex)
            {
                //Logger.Error("Not able to connect to Dynamics 365 - {0} as user - {1}", conn.OrgName, conn.CrmUserId);
                Logger.Error("Not able to connect to Dynamics 365 - {0} as user - {1}", conn.Name, conn.CrmUserId);
                throw ex;
            }
        }

    }
}

