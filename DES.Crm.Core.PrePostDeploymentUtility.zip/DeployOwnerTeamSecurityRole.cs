﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Linq;
using System.Xml;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    public class DeployOwnerTeamSecurityRole
    {
        readonly CrmServiceClient _crmServiceClient;
        readonly XmlDocument _xmlConfigDocument;
        readonly Logger _logger;

        public DeployOwnerTeamSecurityRole(CrmServiceClient service, XmlDocument xmlConfigDocument, Logger logger)
        {
            _crmServiceClient = service;
            _xmlConfigDocument = xmlConfigDocument;
            _logger = logger;
        }

        public void SettingTeamSecurityRoles(string configMode)
        {

            var xpath = "Config/" + configMode + "/teamsecurityroles/*";

            if (_xmlConfigDocument.CreateNavigator().Select(xpath).Count > 0)
            {
                foreach (System.Xml.XPath.XPathNavigator child in _xmlConfigDocument.CreateNavigator().Select(xpath))
                {
                    var teamname = child.GetAttribute("teamname", "");
                    var teamid = child.GetAttribute("teamid", "");
                    var securityrolename = child.GetAttribute("securityrolename", "");
                    var securityroleid = child.GetAttribute("securityroleid", "");

                    QueryExpression query = new QueryExpression
                    {
                        EntityName = "role",
                        ColumnSet = new ColumnSet("roleid", "name"),
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression
                                {
                                    AttributeName = "roleid",
                                    Operator = ConditionOperator.Equal,
                                    Values = { securityroleid }
                                }
                            }
                        }
                    };
                    try
                    {
                        RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = query };

                        RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);

                        if (retrieveSavedQueriesResponse.EntityCollection.Entities.Count > 0)
                        {
                            var role = retrieveSavedQueriesResponse.EntityCollection.Entities.First();
                            if(role["name"].Equals(securityrolename))
                            {
                                _crmServiceClient.Associate("team", new Guid(teamid), new Relationship("teamroles_association"), new EntityReferenceCollection() { new EntityReference("role", new Guid(securityroleid)) });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.Error("Error While assigning requested security role {0} to team {1} ", securityrolename, teamname);
                        _logger.Error(ex.Message);
                        throw new Exception("Cannot process team security setup: ", ex);
                    }

                }
            }
        }
    }
}
