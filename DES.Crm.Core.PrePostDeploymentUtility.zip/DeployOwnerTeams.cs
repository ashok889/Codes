﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DES.Crm.Core.PrePostDeploymentUtility.XML;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    public class DeployOwnerTeams
    {
        readonly CrmServiceClient _crmServiceClient;
        readonly XmlDocument _xmlConfigDocument;         
        readonly Logger _logger;

        public DeployOwnerTeams(CrmServiceClient service, XmlDocument xmlConfigDocument, Logger logger)
        {
            _crmServiceClient = service;
            _xmlConfigDocument = xmlConfigDocument;
            _logger = logger;

        }

        public void SettingOwnerTeams(string configMode)
        {
            var xpath = "Config/" + configMode + "/ownerteams/*";
            var ownerteams = new Dictionary<string, Dictionary<string, SavedQuery>>();

            var existingTeams = GetExistingOwnerTeams();

            if (_xmlConfigDocument.CreateNavigator().Select(xpath).Count > 0)
            {
                foreach (System.Xml.XPath.XPathNavigator child in _xmlConfigDocument.CreateNavigator().Select(xpath))
                {
                    var name = child.GetAttribute("name", "");
                    var guid = child.GetAttribute("guid", "");
                    var parentbu = child.GetAttribute("parentbu", "");

                    if (existingTeams.ContainsKey(new Guid(guid)))
                    {
                        _logger.Info("Ignore team - {0} with id - {1}, because it has been created in targeted intance. ", name, guid);
                    }
                    else
                    {
                        Entity team = new Entity("team");
                        team["teamid"] = new Guid(guid);
                        team["name"] = name;

                        var admin = ((WhoAmIResponse)_crmServiceClient.Execute(new WhoAmIRequest())).UserId;


                        team["administratorid"] = new EntityReference("systemuser", admin);
                        team["teamtype"] = new OptionSetValue(Convert.ToInt32(0));  // 0 - owner, 1 - access

                        if (parentbu.Equals("root"))
                        {
                            var businessUnitId = GetRootBusinessUnitId();
                            team["businessunitid"] = new EntityReference("businessunit", new Guid(businessUnitId));
                        }
                        else
                        {
                            var businessUnitId = GetBusinessUnitId(parentbu);
                            team["businessunitid"] = new EntityReference("businessunit", new Guid(businessUnitId));
                        }


                        try
                        {
                            var teamid = _crmServiceClient.Create(team);
                            _logger.Info("Create team - {0} - with id {1}", name, teamid);
                        }
                        catch (Exception ex)
                        {
                            _logger.Error("Not able to create team - {0}", name);
                            _logger.Error(ex);
                        }
                    }
                    
                }
            }
        }

        private Dictionary<Guid, string> GetExistingOwnerTeams()
        {
            var teamDictionary = new Dictionary<Guid, string>();

            QueryExpression ownerteamquery = new QueryExpression
            {
                ColumnSet = new ColumnSet("teamid", "name"),
                EntityName = "team",
                Criteria = new FilterExpression
                {
                    Conditions =
                        {
                            new ConditionExpression
                            {
                                AttributeName = "teamtype",
                                Operator = ConditionOperator.Equal,
                                Values = { 0 } // 0 - owner, 1 - access
                            }
                        }
                }
            };

            DataCollection<Entity> teams;
            //Retrieve the value based on the condition given
            RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = ownerteamquery };
            RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
            teams = retrieveSavedQueriesResponse.EntityCollection.Entities;

            foreach (var team in teams)
            {
                teamDictionary.Add(team.Id, team["name"].ToString());
            }

            return teamDictionary;
        }

        private string GetRootBusinessUnitId()
        {
            try
            {
                QueryExpression businessUnitQuery = new QueryExpression
                {
                    ColumnSet = new ColumnSet("businessunitid", "name"),
                    EntityName = "businessunit",
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression
                            {
                                AttributeName = "parentbusinessunitid",
                                Operator = ConditionOperator.Null,
                            }
                        }
                    }
                };

                DataCollection<Entity> dcBUDetails;
                //Retrieve the value based on the condition given
                RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = businessUnitQuery };
                RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
                dcBUDetails = retrieveSavedQueriesResponse.EntityCollection.Entities;

                Console.WriteLine();

                //Return the Guid of the BusinessUnit
                if (dcBUDetails.Count == 1 && dcBUDetails[0] != null && dcBUDetails[0].Id != null)
                {
                    return dcBUDetails[0].Id.ToString();
                }

            }
            catch (Exception ex)
            {
                _logger.Error("Error While retrieving Guid of Root Business Unit " + ex.Message);
            }

            return null;
        }

        private string GetBusinessUnitId(string buName)
        {
            try
            {
                //Checks whether the BUName is empty or null and then proceed into the query 
                if (buName != null && buName.Length > 0)
                {
                    QueryExpression businessUnitQuery = new QueryExpression
                    {
                        ColumnSet = new ColumnSet("businessunitid", "name"),
                        EntityName = "businessunit",
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression
                                {
                                    AttributeName = "name",
                                    Operator = ConditionOperator.Equal,
                                    Values = { buName }
                                }
                            }
                        }
                    };

                    DataCollection<Entity> dcBUDetails;
                    //Retrieve the value based on the condition given
                    RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = businessUnitQuery };
                    RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_crmServiceClient.Execute(retrieveSavedQueriesRequest);
                    dcBUDetails = retrieveSavedQueriesResponse.EntityCollection.Entities;

                    //Return the Guid of the BusinessUnit
                    if (dcBUDetails.Count == 1)
                    {
                        if (dcBUDetails[0] != null)
                        {
                            if (dcBUDetails[0].Id != null)
                            {
                                return dcBUDetails[0].Id.ToString();
                            }
                        }
                    }
       
                }
            }
            catch (Exception ex)
            {
                _logger.Error("Error While retrieving Guid of Business Unit " + ex.Message);
            }

            return null;
        }
    }
}
