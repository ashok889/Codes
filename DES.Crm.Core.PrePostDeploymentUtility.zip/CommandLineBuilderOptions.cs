﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.Windows.Forms;
using DES.Crm.Core.PrePostDeploymentUtility.XML;
using Mono.Options;
using NLog;

namespace DES.Crm.Core.PrePostDeploymentUtility
{
    public class CommandLineBuilderOptions
    {        
        CRMConnection _targetEnvironment;        
        XMLConfig _xmlConfig;             
        OptionSet _options;
        Logger _logger;

        #region OptionSet Variables
        string _ConfigFilePath;
        bool _showHelp;       
        string _prePost;
        string _targetEnvironmentId;
        #endregion

        public CommandLineBuilderOptions(Logger logger)
        {
            _logger = logger;
            _ConfigFilePath = Environment.CurrentDirectory + "\\Config.xml";
            _prePost = "pre";
            _showHelp = false;
            _options = new OptionSet
            {
                { "c|cf|configurationfile:", "Location of the configuration file or leave empty for default path of: " + _ConfigFilePath,
                    c => {                        
                        if (!string.IsNullOrEmpty(c))
                        {
                            _ConfigFilePath = c;
                        }                        
                    }    
                },
                { "p|prepost:", "Pre or Post deployment action. Allowed options: 1. Pre 2. Post. Default if empty: pre",
                    p => {                        
                        if (!string.IsNullOrEmpty(p))
                        {
                            _prePost = p;
                        }                                               
                    }
                },
                { "t|target:", "Id of the target environment. Name should match ids in connection settings in config file. Default set to first connection option in file if only one connection in file",
                    t => {
                        _targetEnvironmentId = t;                       
                    }
                },
                { "h|help", "show help",
                    o =>_showHelp = o != null
                }
            };
        }

        #region Public method
        public int Execute(string[] args)
        {
            try {
                var _arguments = _options.Parse(args);
                if (_showHelp)
                {
                    ShowHelp();
                    return 10;
                }
                CheckConfigFileOption();
                CheckPrePostOption();
                CheckTargetEnvironmentOption();                   
                return 0;           
            }
            catch (OptionException e)
            {
                Console.WriteLine(e.Message);
                return -1;
            }            
        }
        #endregion

        #region Check Options
        void CheckConfigFileOption()
        {
            _logger.Info("Checking file path: " + _ConfigFilePath);
            var path = Path.GetFullPath(_ConfigFilePath);
            if (File.Exists(path))
            {
                DeserializeConfigFile();                
            }
            else
            {
                throw new OptionException("File does not exist at: " + _ConfigFilePath, "c");
            }
        }

        void CheckPrePostOption()
        {
            var options = new string[] { "pre", "post" };
            if (options.Contains(_prePost))
            {
                _logger.Info("Chosen PrePost: " + _prePost);               
            }
            else
            {
                throw new OptionException("Invalid prepost action specified. Please choose either \"Pre\" or \"Post\" without quotation marks", "p");
            }            
        }

        void CheckTargetEnvironmentOption()
        {
            //var connNames = new Dictionary<string, string>();
            var targets = XMLConfiguration.Connections.CRMConnections.OrderBy(p => p.Id).ToList();
            //connNames = targets.ToDictionary(g => g.Id, g => g.Name);

            // Check connections file contains CRM connections
            if (targets.Count == 0)
            {
                throw new OptionException("No connections have been specified in the configuration file", "t");
            }
            // Config file has only one connection
            else if (targets.Count == 1)
            {                
                if (!string.IsNullOrEmpty(_targetEnvironmentId) && !targets.Exists(p => p.Id == _targetEnvironmentId))
                {
                    throw new OptionException("Connection Id: " + _targetEnvironmentId + " does not exist in the configuration file", "t");
                }
               
                _targetEnvironment = targets[0];
                _logger.Info("Target: " + _targetEnvironment.Name);                
            }
            // Config file has more than one connection
            else 
            {
                if (string.IsNullOrEmpty(_targetEnvironmentId))
                {
                    throw new OptionException("Connection Id required as multiple connections specified in connections file", "t");
                }

                if (!targets.Exists(p => p.Id == _targetEnvironmentId))
                {
                    throw new OptionException("Connection Id: " + _targetEnvironmentId + " does not exist in the configuration file", "t");
                }
                
                _targetEnvironment = targets.Find(p => p.Id == _targetEnvironmentId);
                _logger.Info("Target: " + _targetEnvironment.Name);                
            }
        }
        #endregion

        #region Private methods
        void DeserializeConfigFile()
        {
            var serializer = new XmlSerializer(typeof(XMLConfig));
            using (XmlReader reader = XmlReader.Create(ConfigFile))
            {
                _xmlConfig = (XMLConfig)serializer.Deserialize(reader);
            }
        }

        void ShowHelp()
        {
            // show some app description message
            Console.WriteLine("Usage: " + Application.ProductName +  ".exe [OPTIONS]");
            Console.WriteLine("Deploys configuration settings to a specific CRM environment");            
            Console.WriteLine();

            // output the options
            Console.WriteLine("Options:");
            _options.WriteOptionDescriptions(Console.Out);
        }
        #endregion


        #region Variables
        public string ConfigFile
        {
            get
            {
                return _ConfigFilePath;
            }
        }

        public string PrePostAction
        {
            get
            {
                return _prePost;
            }
        }

        public CRMConnection TargetEnvironment
        {
            get
            {
                return _targetEnvironment;
            }
        }

        public XMLConfig XMLConfiguration
        {
            get
            {
                return _xmlConfig;
            }
        }
        #endregion

    }
}