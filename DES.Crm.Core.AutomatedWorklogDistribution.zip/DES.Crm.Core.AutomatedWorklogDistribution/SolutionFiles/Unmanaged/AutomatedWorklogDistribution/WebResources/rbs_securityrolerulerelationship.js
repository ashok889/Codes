function setRolesView() {
    Xrm.Page.getControl("rbs_securityrole").addPreSearch(function () {
        setCustomView("rbs_securityrole");
    });
}

function setCustomView(fieldName) {

                var viewId = '{61F8D435-8E25-4751-8330-5969506EF536}';
                var entityName = 'role';
                var viewDisplayName = "Roles Lookup View";
				
		var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'> <entity name='role'> <attribute name='name' /> <attribute name='businessunitid' /> <attribute name='roleid' /> <order attribute='name' descending='false' /> <link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='ab'> <filter type='and'> <condition attribute='name' operator='eq' value='CDD Remediation' /> </filter> </link-entity> </entity> </fetch>";
					
                var layoutXml = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'><row name='result' id='roleid'><cell name='name' width='300' /><cell name='businessunitid' width='300' /></row></grid>";

                Xrm.Page.getControl(fieldName).addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);               

            //Unsupported
            parent.document.getElementById(fieldName).attributes.disableviewpicker.value = "1";
}