﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Messages;

namespace DES.Crm.Core.AWD
{
    public class DistributeRecords
    {
        #region Public properties and variable declaration

        public AppMode APPMODE;
        public bool ISACTIVITYENTITY = false;
        public int successfulCounter = 0;
        public int failedCounter = 0;
        Entity enAudit = null;
        Dictionary<EntityReference, List<EntityReference>> assigneeRecordCollection = null;
        Dictionary<EntityReference, string> failedRecordCollection = null;
        string ruleTargetEntityName = string.Empty;
        bool isAuditRequired = false;

        public enum AppMode
        {
            WithGroupBy,
            WithoutGroupBy
        }

        public enum FetchXml
        {
            UsersInExclusionTeam,
            UsersOnDistributionRuleSubgrid,
            UsersInConfiguredTeams,
            UsersHavingConfiguredSecurityRoles,
            UsersHavingConfiguredPositions,
            TeamsOnDistributionRuleSubgrid,
            TeamsHavingConfiguredSecurityRoles,
            ActiveRecordsOfTargetEntity,
            ConfiguredSecurityRoles
        }

        // Ques: For threshold, retrieving records of entity configured in rbs_targetentityschemaname? and not from the entity configured in fetchxml field?
        // Ques: How to ensure active records of entities? few entities dont have statecode=0 as Active. Ex - Contracts | Article (no statecode=0)

        public struct CrmAttribute
        {
            public struct DistributionRule
            {
                public const string entityname = "rbs_distributionrule";
                public const string rbs_name = "rbs_name";
                public const string rbs_description = "rbs_description";
                public const string rbs_distributiontargettype = "rbs_distributiontargettype";
                public const string rbs_exclusionteam = "rbs_exclusionteam";
                public const string rbs_frequency = "rbs_frequency";
                public const string rbs_grouprecordsbyschemaname = "rbs_grouprecordsbyschemaname";
                public const string rbs_nexttriggerdate = "rbs_nexttriggerdate";
                public const string rbs_retrievalcriteriainxml = "rbs_retrievalcriteriainxml";
                public const string rbs_targetentityschemaname = "rbs_targetentityschemaname";
                public const string rbs_isauditrequired = "rbs_isauditrequired";
            }

            public struct DistributionAuditLog
            {
                public const string entityname = "rbs_distributionauditlog";
                public const string rbs_name = "rbs_name";
                public const string rbs_targetentityschemaname = "rbs_targetentityschemaname";
                public const string rbs_distributiontargettype = "rbs_distributiontargettype";
                public const string rbs_distributionrule = "rbs_distributionrule";
                public const string rbs_trigger = "rbs_trigger";
                public const string rbs_recordstobeassigned = "rbs_recordstobeassigned";
                public const string rbs_recordsassignmentsuccessful = "rbs_recordsassignmentsuccessful";
                public const string rbs_recordsassignmentfailed = "rbs_recordsassignmentfailed";
            }

            public struct DistributionTargetRecord
            {
                public const string entityname = "rbs_distributiontargetrecord";
                public const string rbs_distributionauditlog = "rbs_distributionauditlog";
                public const string rbs_distributiontargetteam = "rbs_distributiontargetteam";
                public const string rbs_distributiontargetuser = "rbs_distributiontargetuser";
                public const string rbs_failurereason = "rbs_failurereason";
                public const string rbs_isassigned = "rbs_isassigned";
            }

            public struct DistributionTargetTeam
            {
                public const string entityname = "rbs_distributiontargetteam";
                public const string rbs_distributionauditlog = "rbs_distributionauditlog";
                public const string rbs_recordsassigned = "rbs_recordsassigned";
                public const string rbs_team = "rbs_team";
            }

            public struct DistributionTargetUser
            {
                public const string entityname = "rbs_distributiontargetuser";
                public const string rbs_distributionauditlog = "rbs_distributionauditlog";
                public const string rbs_recordsassigned = "rbs_recordsassigned";
                public const string rbs_user = "rbs_user";
            }
        }

        #endregion

        public void Execute(IOrganizationService service, Guid distributionRuleId, bool triggerMode)
        {
            try
            {
                EntityReference distributionRule = new EntityReference(CrmAttribute.DistributionRule.entityname, distributionRuleId);

                enAudit = new Entity(CrmAttribute.DistributionAuditLog.entityname);
                enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_trigger] = triggerMode;
                enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_recordstobeassigned] = 0;
                enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_recordsassignmentsuccessful] = 0;
                enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_recordsassignmentfailed] = 0;

                assigneeRecordCollection = new Dictionary<EntityReference, List<EntityReference>>();
                failedRecordCollection = new Dictionary<EntityReference, string>();

                BusinessLogic(service, distributionRule);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally
            {
                try
                {
                    if (isAuditRequired)
                    {
                        #region Logging Audit

                        Guid guidDistributionAuditLog = service.Create(enAudit);

                        string ruleEntityAttributeName = Common.GetLookupAttributeNameByEntityName(service, CrmAttribute.DistributionTargetRecord.entityname, ruleTargetEntityName);

                        Program.Trace(string.Format("Count: " + assigneeRecordCollection.Count));

                        #region Populate Users/Teams Audit
                        foreach (KeyValuePair<EntityReference, List<EntityReference>> kvp in assigneeRecordCollection)
                        {
                            if (kvp.Key.LogicalName.Equals("systemuser"))
                            {
                                Entity enDistributionTargetUser = new Entity(CrmAttribute.DistributionTargetUser.entityname);
                                enDistributionTargetUser.Attributes[CrmAttribute.DistributionTargetUser.rbs_distributionauditlog] = new EntityReference(CrmAttribute.DistributionAuditLog.entityname, guidDistributionAuditLog);
                                enDistributionTargetUser.Attributes[CrmAttribute.DistributionTargetUser.rbs_recordsassigned] = kvp.Value.Count;
                                enDistributionTargetUser.Attributes[CrmAttribute.DistributionTargetUser.rbs_user] = kvp.Key;

                                Guid guidDistributionTargetUser = service.Create(enDistributionTargetUser);

                                foreach (EntityReference erRecord in kvp.Value)
                                {
                                    if (!string.IsNullOrEmpty(ruleEntityAttributeName))
                                    {
                                        Entity enDistributionTargetRecord = new Entity(CrmAttribute.DistributionTargetRecord.entityname);
                                        enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_distributionauditlog] = new EntityReference(CrmAttribute.DistributionAuditLog.entityname, guidDistributionAuditLog);
                                        enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_distributiontargetuser] = new EntityReference(CrmAttribute.DistributionTargetUser.entityname, guidDistributionTargetUser);
                                        enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_isassigned] = true;
                                        enDistributionTargetRecord.Attributes[ruleEntityAttributeName] = erRecord;

                                        service.Create(enDistributionTargetRecord);
                                    }
                                }
                            }
                            else if (kvp.Key.LogicalName.Equals("team"))
                            {
                                Entity enDistributionTargetTeam = new Entity(CrmAttribute.DistributionTargetTeam.entityname);
                                enDistributionTargetTeam.Attributes[CrmAttribute.DistributionTargetTeam.rbs_distributionauditlog] = new EntityReference(CrmAttribute.DistributionAuditLog.entityname, guidDistributionAuditLog);
                                enDistributionTargetTeam.Attributes[CrmAttribute.DistributionTargetTeam.rbs_recordsassigned] = kvp.Value.Count;
                                enDistributionTargetTeam.Attributes[CrmAttribute.DistributionTargetTeam.rbs_team] = kvp.Key;

                                Guid guidDistributionTargetTeam = service.Create(enDistributionTargetTeam);

                                foreach (EntityReference erRecord in kvp.Value)
                                {
                                    Entity enDistributionTargetRecord = new Entity(CrmAttribute.DistributionTargetRecord.entityname);
                                    enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_distributionauditlog] = new EntityReference(CrmAttribute.DistributionAuditLog.entityname, guidDistributionAuditLog);
                                    enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_distributiontargetteam] = new EntityReference(CrmAttribute.DistributionTargetTeam.entityname, guidDistributionTargetTeam);
                                    enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_isassigned] = true;
                                    enDistributionTargetRecord.Attributes[ruleEntityAttributeName] = erRecord;

                                    service.Create(enDistributionTargetRecord);
                                }
                            }
                        }
                        #endregion

                        #region Populate Failed Records
                        foreach (KeyValuePair<EntityReference, string> kvp in failedRecordCollection)
                        {
                            Entity enDistributionTargetRecord = new Entity(CrmAttribute.DistributionTargetRecord.entityname);
                            enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_distributionauditlog] = new EntityReference(CrmAttribute.DistributionAuditLog.entityname, guidDistributionAuditLog);
                            enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_isassigned] = false;
                            enDistributionTargetRecord.Attributes[ruleEntityAttributeName] = kvp.Key;
                            enDistributionTargetRecord.Attributes[CrmAttribute.DistributionTargetRecord.rbs_failurereason] = kvp.Value;

                            service.Create(enDistributionTargetRecord);
                        }
                        #endregion

                        #endregion
                    }

                    Program.Trace(string.Format("\nExecution completed. Exiting DistributeRecords.Execute()."));
                }
                finally
                {
                    Program.LogTrace();
                }
            }
        }

        /// <summary>
        /// Main business logic
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="context">Workflow context</param>
        /// <param name="executionContext">Code activity execution context</param>
        private void BusinessLogic(IOrganizationService service, EntityReference enRefDistributionRule)
        {
            //Program.Trace(string.Format("Primary Entity Name: " + context.PrimaryEntityName));
            //Program.Trace(string.Format("Primary Entity Id: " + context.PrimaryEntityId.ToString().ToUpper()));

            Entity enDistributionRule = service.Retrieve(enRefDistributionRule.LogicalName, enRefDistributionRule.Id, new ColumnSet(true)); // Columnset tbcx

            if (enDistributionRule != null)
            {
                Program.Trace(string.Format("\nExecuting Distribution Rule with Name: '{0}' | Id: {1}\n", (enDistributionRule.Contains("rbs_name")) ? enDistributionRule["rbs_name"] : "null", enDistributionRule.Id.ToString()));

                enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_distributiontargettype] = (OptionSetValue)enDistributionRule.Attributes[CrmAttribute.DistributionRule.rbs_distributiontargettype];
                enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_name] = "Distribution Audit Log - " + enDistributionRule.Attributes[CrmAttribute.DistributionRule.rbs_name];

                if (ValidateConfigurationData(enDistributionRule))
                {
                    Program.Trace(string.Format("Configuration data validated successfully."));

                    EntityCollection recordsCollection;
                    Dictionary<string, int> assigneeRecordsCount;
                    Dictionary<string, int> assigneeThresholdCount;
                    AttributeTypeCode? groupByAttributeType;

                    InitialiseCommonCollectionObjects(service, enDistributionRule, out recordsCollection, out assigneeRecordsCount, out assigneeThresholdCount, out groupByAttributeType);

                    if (recordsCollection != null)
                    {
                        enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_recordstobeassigned] = recordsCollection.Entities.Count;

                        SetAppMode(enDistributionRule);

                        switch (APPMODE)
                        {
                            case AppMode.WithGroupBy:
                                Run_WithGroupBy(service, enDistributionRule, recordsCollection, assigneeRecordsCount, assigneeThresholdCount, groupByAttributeType);
                                break;

                            case AppMode.WithoutGroupBy:
                                Run_WithoutGroupBy(service, enDistributionRule, recordsCollection, assigneeRecordsCount, assigneeThresholdCount);
                                break;
                        }

                        Program.Trace(string.Format("Records Assigned Successfully: " + successfulCounter));
                        Program.Trace(string.Format("Records Assignment Failed: " + failedCounter));

                        enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_recordsassignmentsuccessful] = successfulCounter;
                        enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_recordsassignmentfailed] = failedCounter;
                    }
                    else
                        Program.Trace(string.Format("No records retrieved for distribution. Exiting."));
                }
                else
                    Program.Trace(string.Format("Validation failed. Records will not be distributed."));
            }
            else
                Program.Trace(string.Format("Failed to retrieve Distribution Rule record."));
        }

        /// <summary>
        /// Validates if all the required fields contain data
        /// </summary>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <returns>True: if data is present in all the required fields | False: otherwise</returns>
        private bool ValidateConfigurationData(Entity enDistributionRule)
        {
            if (GetValue<string>(enDistributionRule, CrmAttribute.DistributionRule.rbs_retrievalcriteriainxml) == null)
                return false;
            else if (GetValue<string>(enDistributionRule, CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname) != null)
            {
                if (!enDistributionRule[CrmAttribute.DistributionRule.rbs_retrievalcriteriainxml].ToString().Replace(" ", "").Replace("\"", "'").Contains("<attributename='" + enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname].ToString().Trim() + "'"))
                {
                    throw new InvalidPluginExecutionException("Group by attribute - " + enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname] + " - is not present in FetchXml criteria.");
                }
            }

            if (GetValue<OptionSetValue>(enDistributionRule, CrmAttribute.DistributionRule.rbs_distributiontargettype) == null)
                return false;
            if (GetValue<string>(enDistributionRule, CrmAttribute.DistributionRule.rbs_targetentityschemaname) == null)
                return false;

            return true;
        }

        /// <summary>
        /// Initialises the objects which are required while executing the code activity in either of the APPMODE
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <param name="recordsCollection">Collection of records obtained by executing the configured fetch xml</param>
        /// <param name="assigneeRecordsCount">Collection of already existing Active records owned by the assignees</param>
        /// <param name="assigneeThresholdCount">Collection of assignees with their respective threshold counts as configured</param>
        /// <param name="groupByAttributeType">Attribute type code of the 'group by' attribute as configured</param>
        private void InitialiseCommonCollectionObjects(IOrganizationService service, Entity enDistributionRule, out EntityCollection recordsCollection, out Dictionary<string, int> assigneeRecordsCount, out Dictionary<string, int> assigneeThresholdCount, out AttributeTypeCode? groupByAttributeType)
        {
            Program.Trace(string.Format("Initiliasing common objects."));

            string retrievalCriteriaXml = (string)enDistributionRule[CrmAttribute.DistributionRule.rbs_retrievalcriteriainxml];
            string groupBy = GetValue<string>(enDistributionRule, CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname);
            ruleTargetEntityName = (string)enDistributionRule[CrmAttribute.DistributionRule.rbs_targetentityschemaname];
            isAuditRequired = enDistributionRule.Contains(CrmAttribute.DistributionRule.rbs_isauditrequired) ? (bool)enDistributionRule[CrmAttribute.DistributionRule.rbs_isauditrequired] : false;

            enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_distributionrule] = enDistributionRule.ToEntityReference();
            enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_targetentityschemaname] = ruleTargetEntityName;

            assigneeRecordsCount = null;
            assigneeThresholdCount = null;

            groupByAttributeType = GetAttributeDataTypeAndEntityType(service, ruleTargetEntityName, groupBy);

            Program.Trace(string.Format("Retrieving the records by executing the configured fetch xml."));
            recordsCollection = RetrieveRecordsByFetch(service, retrievalCriteriaXml);

            if (recordsCollection != null)
            {
                assigneeRecordsCount = PrepareAssigneeRecordsCountCollection(service, enDistributionRule);
                assigneeThresholdCount = PrepareAssigneeThresholdCountCollection(service, enDistributionRule);
            }
            else
                Program.Trace(string.Format("Configured fetch xml yielded no records to be distributed."));
        }

        /// <summary>
        /// Distributes the records when 'Group Records By' field doesn't contain data
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <param name="recordsCollection">Collection of records obtained by executing the configured fetch xml</param>
        /// <param name="assigneeRecordsCount">Collection of already existing Active records owned by the assignees</param>
        /// <param name="assigneeThresholdCount">Collection of assignees with their respective threshold counts as configured</param>
        private void Run_WithoutGroupBy(IOrganizationService service, Entity enDistributionRule, EntityCollection recordsCollection, Dictionary<string, int> assigneeRecordsCount, Dictionary<string, int> assigneeThresholdCount)
        {
            EntityReference tempAssignee;
            string key;
            string entityLogicalName = ((OptionSetValue)enDistributionRule[CrmAttribute.DistributionRule.rbs_distributiontargettype]).Value.Equals(859770000) ? "systemuser" : "team";

            if (assigneeThresholdCount.Count > 0)
            {
                // Remove the records from assigneeRecordsCount based on the key (assigneeId), where the key is not present in assigneeThresholdCount.
                assigneeRecordsCount.ToList().Where(p => !assigneeThresholdCount.Select(x => x.Key).Contains(p.Key)).ToList().ForEach(p => assigneeRecordsCount.Remove(p.Key));

                // Add the assignees to assigneeRecordsCount (from assigneeThresholdCount) who own no active records in CRM (these were not retrieved while preparing the assigneeRecordsCount collection).
                foreach (var itemAssignee in assigneeThresholdCount)
                {
                    if (!assigneeRecordsCount.Keys.Contains(itemAssignee.Key))
                        assigneeRecordsCount.Add(itemAssignee.Key, 0);
                }

                // Sort based on count of active records each assignee owns.
                assigneeRecordsCount = assigneeRecordsCount.OrderBy(o => o.Value).ToDictionary(k => k.Key, v => v.Value);

                Program.Trace(string.Format("Count of dictionaries - 'assigneeRecordsCount': {0} | 'assigneeThresholdCount': {1}", assigneeRecordsCount.Count.ToString(), assigneeThresholdCount.Count.ToString()));
                Program.Trace(string.Format("Sorted the list by count of records owned by assignees."));
                Program.Trace(string.Format("Starting distribution."));

                foreach (var recordToBeAssigned in recordsCollection.Entities)
                {
                    // If there is no user having bandwidth to take more records, break the loop.
                    // Remaining records will be left unassigned.
                    if (assigneeRecordsCount.Count == 0)
                        break;

                    List<string> keysToBeRemoved = new List<string>();

                    foreach (var assignee in assigneeRecordsCount.OrderBy(o => o.Value).ToDictionary(k => k.Key, v => v.Value))
                    {
                        key = assignee.Key.ToUpper();
                        tempAssignee = new EntityReference(entityLogicalName, new Guid(key));

                        // Check if one more record will be assigned to the assignee, assignee would not cross the threshold limit.
                        if (1 + assigneeRecordsCount[key] <= assigneeThresholdCount[key])
                        {
                            // Check if the recordToBeAssigned is not already owned by the target assignee.
                            if (!(recordToBeAssigned.Attributes.Contains("ownerid") && ((EntityReference)recordToBeAssigned["ownerid"]).Id.Equals(tempAssignee.Id)))
                            {
                                BulkAssign(service, key, tempAssignee, ref assigneeRecordsCount, null, recordToBeAssigned);
                                break;
                            }
                            else
                                Program.Trace(string.Format("Record is already assigned to the targeted assignee."));
                        }
                        else
                        {
                            // Since the assignee has reached the threshold, it should be removed from the collection assigneeRecordsCount.
                            // This would avoid running the inner foreach loop again for this assignee.
                            Program.Trace(string.Format("Assignee with id: {0} reached threshold.", key));
                            keysToBeRemoved.Add(key);
                        }
                    }

                    // Remove the assignee(s) from the collection who have reached threshold.
                    if (keysToBeRemoved != null && keysToBeRemoved.Count() > 0)
                        foreach (var tempKey in keysToBeRemoved)
                            if (assigneeRecordsCount.Keys.Contains(tempKey))
                                assigneeRecordsCount.Remove(tempKey);
                }
                Program.Trace(string.Format("Distribution finished."));
            }
        }

        /// <summary>
        /// Distributes the records when 'Group Records By' field contains data
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <param name="recordsCollection">Collection of records obtained by executing the configured fetch xml</param>
        /// <param name="assigneeRecordsCount">Collection of already existing Active records owned by the assignees</param>
        /// <param name="assigneeThresholdCount">Collection of assignees with their respective threshold counts as configured</param>
        /// <param name="groupByAttributeType">Attribute type code of the 'group by' attribute as configured</param>
        private void Run_WithGroupBy(IOrganizationService service, Entity enDistributionRule, EntityCollection recordsCollection, Dictionary<string, int> assigneeRecordsCount, Dictionary<string, int> assigneeThresholdCount, AttributeTypeCode? groupByAttributeType)
        {
            if (recordsCollection != null)
            {
                if (groupByAttributeType != null)
                {
                    #region Prepare collection for record to be distributed group by [Rule.GroupBy]

                    Dictionary<string, List<Entity>> recordsGroup = GroupRecordsToBeDistributed(service, recordsCollection, enDistributionRule, groupByAttributeType);

                    #endregion

                    #region Prepare collection for existing record set of assignees

                    EntityCollection existingRecords = null;

                    Dictionary<string, List<Entity>> existingRecordsGroup = GroupAssigneeRecordsCollection(service, enDistributionRule, groupByAttributeType, out existingRecords);

                    #endregion

                    if (recordsGroup.Count > 0)
                    {
                        if (assigneeThresholdCount.Count > 0)
                        {
                            DistributeRecordsByGroups(service, enDistributionRule, assigneeThresholdCount, assigneeRecordsCount, recordsGroup, existingRecordsGroup);

                            Program.Trace(string.Format("Distribution finished."));
                        }
                        else
                            Program.Trace(string.Format("No assignee(s) retrieved. No record distribution will take place"));
                    }
                    else
                        Program.Trace(string.Format("No items found in recordsGroup dictionary."));
                }
                else
                    Program.Trace(string.Format("Attribute data type could not be identified. No record distribution will take place."));
            }
            else
                Program.Trace(string.Format("No records retrieved with the configured fetch. No record distribution will take place."));
        }

        /// <summary>
        /// Checks and assigns all te records of a group to an assignee based on the following criteria:
        /// If there exists any assignee who owns at least one Active record where 'group by' attribute contains the same data as that in the record to be distributed
        /// Then, all the records of that group will be assigned to the same assignee based on assignee threshold
        /// Otherwise, the records of that group will be assigned to the assignee owning least number of active records of the target entity
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <param name="assigneeThresholdCount">Collection of assignees with their respective threshold counts as configured</param>
        /// <param name="assigneeRecordsCount">Collection of already existing Active records owned by the assignees</param>
        /// <param name="toBeDistributedRecordsGroup">Collection of entity records to be distributed grouped by 'Group Records By'</param>
        /// <param name="existingRecordsGroup">Collection of already existing entity records grouped by 'Group Records By'</param>
        private void DistributeRecordsByGroups(IOrganizationService service, Entity enDistributionRule, Dictionary<string, int> assigneeThresholdCount, Dictionary<string, int> assigneeRecordsCount, Dictionary<string, List<Entity>> toBeDistributedRecordsGroup, Dictionary<string, List<Entity>> existingRecordsGroup)
        {
            string assigneeEntityLogicalName = ((OptionSetValue)enDistributionRule[CrmAttribute.DistributionRule.rbs_distributiontargettype]).Value.Equals(859770000) ? "systemuser" : "team";
            EntityReference tempAssignee = null;
            string key = string.Empty;
            bool isAssigneeFound = false;

            assigneeRecordsCount.ToList().Where(p => !assigneeThresholdCount.Select(x => x.Key).Contains(p.Key)).ToList().ForEach(p => assigneeRecordsCount.Remove(p.Key));

            // Add the assignees to assigneeRecordsCount (from assigneeThresholdCount) who own no active records in CRM (these were not retrieved while preparing the assigneeRecordsCount collection).
            foreach (var itemAssignee in assigneeThresholdCount)
            {
                if (!assigneeRecordsCount.Keys.Contains(itemAssignee.Key))
                    assigneeRecordsCount.Add(itemAssignee.Key, 0);
            }

            toBeDistributedRecordsGroup = toBeDistributedRecordsGroup.OrderByDescending(o => existingRecordsGroup.Where(w1 => w1.Key.Equals(o.Key)).Select(s => s.Value).Any(a => a.Any(s => assigneeThresholdCount.Keys.Contains(((EntityReference)s["ownerid"]).Id.ToString().ToUpper())))).ToDictionary(d => d.Key, d => d.Value);

            foreach (var recordsToBeDistributed in toBeDistributedRecordsGroup)
            {
                // Ques: What if there exists two users who are currently working for the same customer?

                var list = existingRecordsGroup.Where(w => w.Key.Equals(recordsToBeDistributed.Key)).Select(s => s.Value).ToList();

                if (list != null && list.Count() > 0)
                {
                    isAssigneeFound = list.Any(a => a.Any(s => assigneeThresholdCount.Keys.Contains(((EntityReference)s["ownerid"]).Id.ToString().ToUpper())));
                }

                if (isAssigneeFound)
                {
                    Entity enRecordTemp = list.FirstOrDefault(a => a.Any(s => assigneeThresholdCount.Keys.Contains(((EntityReference)s["ownerid"]).Id.ToString().ToUpper()))).FirstOrDefault(s => assigneeThresholdCount.Keys.Contains(((EntityReference)s["ownerid"]).Id.ToString().ToUpper()));
                    tempAssignee = (EntityReference)enRecordTemp["ownerid"];

                    if (assigneeRecordsCount.ContainsKey(tempAssignee.Id.ToString().ToUpper()))
                    {
                        Program.Trace(string.Format("\nBatch Size: {0}; Assignee found: {1}; Assignee found having at least 1 active record for the group by record.", recordsToBeDistributed.Value.Count, tempAssignee.Id));

                        ValidateThresholdandAssignBatch(service, recordsToBeDistributed, assigneeThresholdCount, ref assigneeRecordsCount, tempAssignee);
                    }
                    else
                    {
                        Program.Trace(string.Format("\nBatch Size: {0}; Assignee will be calculated as per least WIP alogrithm.", recordsToBeDistributed.Value.Count));

                        AssignBasedonLeastWIPAlgorithm(service, assigneeEntityLogicalName, recordsToBeDistributed, assigneeThresholdCount, ref assigneeRecordsCount);
                    }
                }
                else
                {
                    Program.Trace(string.Format("\nBatch Size: {0}; Assignee will be calculated as per least WIP alogrithm.", recordsToBeDistributed.Value.Count));

                    AssignBasedonLeastWIPAlgorithm(service, assigneeEntityLogicalName, recordsToBeDistributed, assigneeThresholdCount, ref assigneeRecordsCount);
                }
            }
        }

        private void AssignBasedonLeastWIPAlgorithm(IOrganizationService service, string assigneeEntityLogicalName, KeyValuePair<string, List<Entity>> recordsToBeDistributed, Dictionary<string, int> assigneeThresholdCount, ref Dictionary<string, int> assigneeRecordsCount)
        {
            bool isValidAssigneeFound = false;
            EntityReference tempAssignee = null;
            string key = string.Empty;

            foreach (var item in assigneeRecordsCount.OrderBy(o => o.Value).ToDictionary(k => k.Key, v => v.Value))
            {
                key = item.Key.ToUpper();

                tempAssignee = new EntityReference(assigneeEntityLogicalName, new Guid(key));

                isValidAssigneeFound = ValidateThresholdandAssignBatch(service, recordsToBeDistributed, assigneeThresholdCount, ref assigneeRecordsCount, tempAssignee);

                if (isValidAssigneeFound)
                    break;

                Program.Trace("Searching for next valid user.");
            }
        }

        private bool ValidateThresholdandAssignBatch(IOrganizationService service, KeyValuePair<string, List<Entity>> recordsToBeDistributed, Dictionary<string, int> assigneeThresholdCount, ref Dictionary<string, int> assigneeRecordsCount, EntityReference tempAssignee)
        {
            bool isAssigneeFound = false;
            string key = tempAssignee.Id.ToString().ToUpper();

            if (recordsToBeDistributed.Value.Count + assigneeRecordsCount[key] <= assigneeThresholdCount.FirstOrDefault(f => f.Key.Equals(key)).Value)
            {
                isAssigneeFound = true;

                BulkAssignRecordBatch(service, key, tempAssignee, recordsToBeDistributed.Value, ref assigneeRecordsCount);
            }
            else
                Program.Trace(string.Format("Batch Size: {0}; User ID: {1}; Existing Records Owned Count: {2}; Records to be assigned will be exceeding the threshold limit of the assignee. This batch of records will not be assigned.", recordsToBeDistributed.Value.Count, key, assigneeRecordsCount[key]));

            return isAssigneeFound;
        }

        private void BulkAssignRecordBatch(IOrganizationService service, string userGuid, EntityReference tempAssignee, List<Entity> recordsToBeDistributed, ref Dictionary<string, int> assigneeRecordsCount)
        {
            // Check if the recordToBeAssigned is not already owned by the target assignee.
            // Remove the record from the collection if already assigned to the target assignee.
            recordsToBeDistributed.Where(w => w.Attributes.Contains("ownerid") && ((EntityReference)w.Attributes["ownerid"]).Id.ToString().ToUpper().Equals(userGuid)).ToList().ForEach(f => recordsToBeDistributed.Remove(recordsToBeDistributed.FirstOrDefault(x => ((EntityReference)x.Attributes["ownerid"]).Id.ToString().ToUpper().Equals(userGuid))));

            BulkAssign(service, userGuid, tempAssignee, ref assigneeRecordsCount, recordsToBeDistributed);
            //assigneeRecordsCount = assigneeRecordsCount.OrderBy(o => o.Value).ToDictionary(k => k.Key, v => v.Value);
        }

        /// <summary>
        /// Prepares the Target and Assignee and initiates assignment of either a single record or all the records of a collection
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="targetAssignee">Record(s) will be assigned to this user/team</param>
        /// <param name="recordsToBeAssigned">Collection of records to be assigned</param>
        /// <param name="recordToBeAssigned">Single record to be assigned</param>
        private void BulkAssign(IOrganizationService service, string userGuid, EntityReference targetAssignee, ref Dictionary<string, int> assigneeRecordsCount, List<Entity> recordsToBeAssigned = null, Entity recordToBeAssigned = null)
        {
            try
            {
                if (recordsToBeAssigned != null)
                    foreach (var record in recordsToBeAssigned)
                    {
                        try
                        {
                            AssignRecord(service, targetAssignee, record.ToEntityReference());

                            assigneeRecordsCount[userGuid] = assigneeRecordsCount[userGuid] + 1;

                            Program.Trace(string.Format("{0} id: {1} assigned", ruleTargetEntityName, record.Id));

                            AddToAssigneeRecordsDictionary(targetAssignee, record.ToEntityReference());
                            successfulCounter++;
                        }
                        catch (Exception ex)
                        {
                            Program.Trace(string.Format("Assignment Failed for record - " + record.Id + " to " + targetAssignee.LogicalName + " - " + targetAssignee.Id + " for the reason: " + ex.Message));
                            AddToFailedRecordsDictionary(record.ToEntityReference(), ex.Message);
                            failedCounter++;
                            continue;
                        }
                    }

                else if (recordToBeAssigned != null)
                {
                    AssignRecord(service, targetAssignee, recordToBeAssigned.ToEntityReference());

                    assigneeRecordsCount[userGuid] = assigneeRecordsCount[userGuid] + 1;

                    Program.Trace(string.Format("{0} id: {1} assigned", ruleTargetEntityName, recordToBeAssigned.Id));

                    AddToAssigneeRecordsDictionary(targetAssignee, recordToBeAssigned.ToEntityReference());
                    successfulCounter++;
                }
            }
            catch (Exception ex)
            {
                Program.Trace(string.Format("Assignment Failed for record - " + recordToBeAssigned.Id + " to " + targetAssignee.LogicalName + " - " + targetAssignee.Id + " for the reason: " + ex.Message));
                AddToFailedRecordsDictionary(recordToBeAssigned.ToEntityReference(), ex.Message);
                failedCounter++;
            }
        }

        private void AddToAssigneeRecordsDictionary(EntityReference targetAssignee, EntityReference record)
        {
            List<EntityReference> lstRecords = null;

            if (assigneeRecordCollection.Count > 0 && assigneeRecordCollection.Keys.Any(a => a.Id.Equals(targetAssignee.Id)) && assigneeRecordCollection.TryGetValue(assigneeRecordCollection.Keys.Where(a => a.Id.Equals(targetAssignee.Id)).FirstOrDefault(), out lstRecords))
            {
                lstRecords.Add(record);
                assigneeRecordCollection.Remove(targetAssignee);
            }
            else
            {
                lstRecords = new List<EntityReference>();
                lstRecords.Add(record);
            }

            assigneeRecordCollection.Add(targetAssignee, lstRecords);
        }

        private void AddToFailedRecordsDictionary(EntityReference record, string failureReason)
        {
            failedRecordCollection.Add(record, failureReason);
        }

        /// <summary>
        /// Creates and executes AssignRequest
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="assignee">Record will be assigned to this user/team</param>
        /// <param name="target">Record to be assigned</param>
        private void AssignRecord(IOrganizationService service, EntityReference assignee, EntityReference target)
        {
            AssignRequest assign = new AssignRequest
            {
                Assignee = assignee,
                Target = target
            };

            service.Execute(assign);
        }

        /// <summary>
        /// Prepares the collection of count of active records of the target entity owned by each assignee
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <returns>Collection of count of active records of the target entity owned by each assignee</returns>
        private Dictionary<string, int> PrepareAssigneeRecordsCountCollection(IOrganizationService service, Entity enDistributionRule)
        {
            /* This function can be trashed and use the collection generated from GroupAssigneeRecordsCollection can be used instead */
            Dictionary<string, int> assigneeRecordsCount = new Dictionary<string, int>();
            EntityCollection tempActiveRecordsCollection = null;
            string entityPrimaryAttribute = ISACTIVITYENTITY ? "activityid" : enDistributionRule[CrmAttribute.DistributionRule.rbs_targetentityschemaname] + "id";

            tempActiveRecordsCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.ActiveRecordsOfTargetEntity), new string[] { (string)enDistributionRule[CrmAttribute.DistributionRule.rbs_targetentityschemaname], entityPrimaryAttribute, "" });

            assigneeRecordsCount = tempActiveRecordsCollection.Entities.GroupBy(r => ((EntityReference)r["ownerid"]).Id.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).Count());

            return assigneeRecordsCount;
        }

        /// <summary>
        /// Prepares the collection of threshold count of each assignee
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <returns>Collection of threshold count of each assignee</returns>
        private Dictionary<string, int> PrepareAssigneeThresholdCountCollection(IOrganizationService service, Entity enDistributionRule)
        {
            Dictionary<string, int> assigneeThresholdCount = new Dictionary<string, int>();
            EntityCollection tempRetrievedAssigneeCollection = null;
            EntityCollection configuredSecurityRolesCollection = null;
            string rolesCondition = string.Empty;

            enAudit.Attributes[CrmAttribute.DistributionAuditLog.rbs_distributiontargettype] = ((OptionSetValue)enDistributionRule[CrmAttribute.DistributionRule.rbs_distributiontargettype]);

            switch (((OptionSetValue)enDistributionRule[CrmAttribute.DistributionRule.rbs_distributiontargettype]).Value)
            {
                case 859770000: // User

                    // Ques: Can we retrieve this is using lesser fetch?
                    tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.UsersOnDistributionRuleSubgrid), new string[] { enDistributionRule.Id.ToString() });
                    assigneeThresholdCount = AddRemoveRangeInDictionaryForThresholdCount(assigneeThresholdCount, tempRetrievedAssigneeCollection, "add");

                    tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.UsersInConfiguredTeams), new string[] { enDistributionRule.Id.ToString() });
                    assigneeThresholdCount = AddRemoveRangeInDictionaryForThresholdCount(assigneeThresholdCount, tempRetrievedAssigneeCollection, "add");

                    configuredSecurityRolesCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.ConfiguredSecurityRoles), new string[] { enDistributionRule.Id.ToString() });

                    if (configuredSecurityRolesCollection != null)
                    {
                        rolesCondition = "<filter type='and'><filter type='or'>";

                        foreach (Entity enRole in configuredSecurityRolesCollection.Entities)
                        {
                            rolesCondition += "<condition attribute='name' operator='eq' value='" + enRole.Attributes["name"].ToString() + "' />";
                        }

                        rolesCondition += "</filter></filter>";

                        tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.UsersHavingConfiguredSecurityRoles), new string[] { rolesCondition });
                        assigneeThresholdCount = AddRemoveRangeInDictionaryForThresholdCount(assigneeThresholdCount, tempRetrievedAssigneeCollection, "add", true, configuredSecurityRolesCollection);
                    }

                    tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.UsersHavingConfiguredPositions), new string[] { enDistributionRule.Id.ToString() });
                    assigneeThresholdCount = AddRemoveRangeInDictionaryForThresholdCount(assigneeThresholdCount, tempRetrievedAssigneeCollection, "add");

                    if (GetValue<EntityReference>(enDistributionRule, CrmAttribute.DistributionRule.rbs_exclusionteam) != null)
                    {
                        tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.UsersInExclusionTeam), new string[] { ((EntityReference)enDistributionRule[CrmAttribute.DistributionRule.rbs_exclusionteam]).Id.ToString() });
                        assigneeThresholdCount = AddRemoveRangeInDictionaryForThresholdCount(assigneeThresholdCount, tempRetrievedAssigneeCollection, "remove");
                    }

                    break;

                case 859770001: // Team

                    tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.TeamsOnDistributionRuleSubgrid), new string[] { enDistributionRule.Id.ToString() });
                    assigneeThresholdCount = AddRemoveRangeInDictionaryForThresholdCount(assigneeThresholdCount, tempRetrievedAssigneeCollection, "add");

                    /*
                      Scope can be extended in fututre.
                     */
                    //tempRetrievedAssigneeCollection = RetrieveRecordsByFetch(service,  GetFetchXml( FetchXml.TeamsHavingConfiguredSecurityRoles), new string[] { enDistributionRule.Id.ToString() });
                    //assigneeThresholdCount = AddRemoveRangeInDictionary(assigneeThresholdCount, tempRetrievedAssigneeCollection, "add");

                    break;
            }

            return assigneeThresholdCount;
        }

        /// <summary>
        /// Adds or removes each element to the dictionary corresponding to the collection passed to this function
        /// </summary>
        /// <param name="Trace">Tracing service</param>
        /// <param name="dictionary">Dictionary to be updated</param>
        /// <param name="entityCollection">Collection to be added/removed</param>
        /// <param name="action">To decide whether to add or remove the collection</param>
        /// <returns>Updated dictionary after adding/removing collection</returns>
        private Dictionary<string, int> AddRemoveRangeInDictionaryForThresholdCount(Dictionary<string, int> dictionary, EntityCollection entityCollection, string action, bool forSecurityRole = false, EntityCollection roleThresholdCollection = null)
        {
            if (entityCollection != null)
            {
                switch (action)
                {
                    case "add":

                        foreach (var item in entityCollection.Entities)
                        {
                            string key = item.Id.ToString().ToUpper();
                            int value = 0;
                            if (forSecurityRole && roleThresholdCollection != null)
                                value = (int)((AliasedValue)roleThresholdCollection.Entities.Where(w => w.Attributes["name"].ToString().Equals(((AliasedValue)item.Attributes["an.name"]).Value.ToString())).FirstOrDefault().Attributes["linkentity.rbs_distributionthresholdcount"]).Value;
                            else
                                value = (int)((AliasedValue)item.Attributes["linkentity.rbs_distributionthresholdcount"]).Value;
                            if (!dictionary.Keys.Contains(key))
                                dictionary.Add(key, value);
                            else
                            if (value < dictionary[key])
                            {
                                Program.Trace(string.Format("Assignee with the Id: {0} was overlapping in more than one configured set.", key));
                                dictionary[key] = value;
                            }
                        }
                        break;

                    case "remove":

                        foreach (var item in entityCollection.Entities)
                        {
                            string key = item.Id.ToString().ToUpper();
                            if (dictionary.Keys.Contains(key))
                                dictionary.Remove(key);
                        }
                        break;
                }
            }
            return dictionary;
        }

        /// <summary>
        /// Generic method to retrieve records by using fetch xml
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="fetchXml">Fetch xml which needs to be executed</param>
        /// <param name="fetchXmlParams">Parameters which needs to be replaced in the fetch xml</param>
        /// <returns>Collection of the retrieved entity records</returns>
        private EntityCollection RetrieveRecordsByFetch(IOrganizationService service, string fetchXml, string[] fetchXmlParams = null)
        {
            if (fetchXmlParams != null)
            {
                int counter = 0;
                foreach (var fetchXmlParam in fetchXmlParams)
                {
                    fetchXml = fetchXml.Replace("{" + counter + "}", fetchXmlParam);
                    counter++;
                }
            }

            var moreRecords = false;
            int page = 1;
            var cookie = string.Empty;
            EntityCollection entities = new EntityCollection();
            
            do
            {
                var xml = "<fetch " + cookie + fetchXml.Substring(fetchXml.IndexOf("<fetch") + 6);
                var collection = service.RetrieveMultiple(new FetchExpression(xml));

                if (collection.Entities.Count >= 0) entities.Entities.AddRange(collection.Entities);

                moreRecords = collection.MoreRecords;
                if (moreRecords)
                {
                    page++;
                    cookie = string.Format("paging-cookie='{0}' page='{1}'", System.Security.SecurityElement.Escape(collection.PagingCookie), page);
                }
            } while (moreRecords);

            if (entities.Entities.Count > 0)
            {
                Program.Trace(string.Format("Count of records retrieved: {0}", entities.Entities.Count));
                return entities;
            }
            else
            {
                Program.Trace(string.Format("Count of records retrieved: null"));
                return null;
            }
        }

        /// <summary>
        /// Prepares the collection of records to be distributed grouped by the attribute configured in 'Group Records By'
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="recordsCollection">Collection of records to be grouped</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <param name="attributeType">Attribute type of the attribute configured in 'Group Records By'</param>
        /// <returns>Collection of records to be distributed grouped by attribute configured in 'Group Records By'</returns>
        private Dictionary<string, List<Entity>> GroupRecordsToBeDistributed(IOrganizationService service, EntityCollection recordsCollection, Entity enDistributionRule, AttributeTypeCode? attributeType)
        {
            Dictionary<string, List<Entity>> recordsGroup = new Dictionary<string, List<Entity>>();
            List<Entity> listOfRecordsToBeDistributed = new List<Entity>();

            foreach (Entity record in recordsCollection.Entities.Where(w => !w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])))
            {
                failedCounter++;
                failedRecordCollection.Add(record.ToEntityReference(), "Data for '" + (string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname] + "' is not found for the record id: " + record.Id);
            }

            switch (attributeType)
            {
                case AttributeTypeCode.Customer:
                case AttributeTypeCode.Lookup:
                    try
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((EntityReference)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Id.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((EntityReference)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).Id.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;

                case AttributeTypeCode.String:
                    try
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => (string)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => (string)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;

                case AttributeTypeCode.Picklist:
                    try
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((OptionSetValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((OptionSetValue)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).Value.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;

                case AttributeTypeCode.DateTime: //tbcx - group by DateTime or Date?
                    try
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((DateTime)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Date.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        recordsGroup = recordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((DateTime)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).Date.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;
            }

            return recordsGroup;
        }

        /// <summary>
        /// Prepares the collection of active records of the target entity owned by each assignee
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        /// <param name="attributeType">Attribute type of the attribute configured in 'Group Records By'</param>
        /// <returns>Collection of active records of the target entity owned by each assignee</returns>
        private Dictionary<string, List<Entity>> GroupAssigneeRecordsCollection(IOrganizationService service, Entity enDistributionRule, AttributeTypeCode? attributeType, out EntityCollection existingRecords)
        {
            Dictionary<string, List<Entity>> existingRecordsGroup = new Dictionary<string, List<Entity>>();
            List<Entity> listOfRecordsAlreadyOwnedByAssignee = new List<Entity>();

            EntityCollection tempActiveRecordsCollection = null;
            string entityPrimaryAttribute = ISACTIVITYENTITY ? "activityid" : enDistributionRule[CrmAttribute.DistributionRule.rbs_targetentityschemaname] + "id";

            tempActiveRecordsCollection = RetrieveRecordsByFetch(service, GetFetchXml(FetchXml.ActiveRecordsOfTargetEntity), new string[] { (string)enDistributionRule[CrmAttribute.DistributionRule.rbs_targetentityschemaname], entityPrimaryAttribute, string.Format("<attribute name='{0}' />", (string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]) });

            existingRecords = tempActiveRecordsCollection;

            switch (attributeType)
            {
                case AttributeTypeCode.Customer:
                case AttributeTypeCode.Lookup:
                    try
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((EntityReference)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Id.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((EntityReference)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).Id.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;

                case AttributeTypeCode.String:
                    try
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => (string)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => (string)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;

                case AttributeTypeCode.Picklist:
                    try
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((OptionSetValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((OptionSetValue)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).Value.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;

                case AttributeTypeCode.DateTime: //tbcx - group by DateTime or Date?
                    try
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((DateTime)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Date.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    catch
                    {
                        existingRecordsGroup = tempActiveRecordsCollection.Entities.Where(w => w.Attributes.Contains((string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname])).GroupBy(r => ((DateTime)((AliasedValue)r.Attributes[(string)enDistributionRule[CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname]]).Value).Date.ToString().ToUpper()).ToDictionary(t => t.Key, t => t.Select(r => r).ToList());
                    }
                    break;
            }

            return existingRecordsGroup;
        }

        /// <summary>
        /// Queries metadata to find out:
        /// 1. type of the entity: sets ISACTIVITYENTITY to true if target entity is an activity entity
        /// 2. attribute type code of the attribute passed in the parameter attributeName
        /// </summary>
        /// <param name="service">CRM service</param>
        /// <param name="Trace">Tracing service</param>
        /// <param name="entityName">Name of the target entity</param>
        /// <param name="attributeName">Name of the attribute whose attribute type code needs to be identified</param>
        /// <returns>Returns attribute type code of the attribute</returns>
        private AttributeTypeCode? GetAttributeDataTypeAndEntityType(IOrganizationService service, string entityName, string attributeName = null)
        {
            // Create the request.
            RetrieveEntityRequest entityRequest = new RetrieveEntityRequest();

            // Retrieve only the currently published changes, ignoring the changes that have not been published.
            entityRequest.RetrieveAsIfPublished = false;
            entityRequest.LogicalName = entityName;
            entityRequest.EntityFilters = EntityFilters.Attributes;

            // Execute the request.
            RetrieveEntityResponse entityResponse = (RetrieveEntityResponse)service.Execute(entityRequest);

            // Access the retrieved entity metadata.
            var retrievedEntityMetadata = entityResponse.EntityMetadata;

            ISACTIVITYENTITY = (bool)retrievedEntityMetadata.IsActivity;
            Program.Trace(string.Format("Is activity entity?: " + ISACTIVITYENTITY.ToString()));

            if (attributeName != null)
            {
                foreach (AttributeMetadata attribute in retrievedEntityMetadata.Attributes)
                {
                    if (attribute.LogicalName.Equals(attributeName))
                    {
                        Program.Trace(string.Format("Group By attribute type: {0}", attribute.AttributeType.ToString()));
                        return attribute.AttributeType;
                    }
                }
                Program.Trace(string.Format("Group By attribute type: null"));
            }
            return null;
        }

        /// <summary>
        /// Sets the mode (APPMODE: global variable) in which the distribution of records will take place based on the 'Group Records By' field
        /// </summary>
        /// <param name="Trace">Tracing service</param>
        /// <param name="enDistributionRule">Distribution Rule entity object</param>
        private void SetAppMode(Entity enDistributionRule)
        {
            string groupBy = GetValue<string>(enDistributionRule, CrmAttribute.DistributionRule.rbs_grouprecordsbyschemaname);

            if (groupBy == string.Empty || groupBy == null)
                APPMODE = AppMode.WithoutGroupBy;
            else
                APPMODE = AppMode.WithGroupBy;
            Program.Trace(string.Format("APPMODE: {0}", APPMODE));
        }

        /// <summary>
        /// Contains all the fetch xml utilised in this program
        /// </summary>
        /// <param name="Trace">Tracing service</param>
        /// <param name="fetchXmlType">Enum of type FetchXml to define which fetch xml needs to be returned</param>
        /// <returns>Returns the fetch xml based on the fetchXmlType</returns>
        private string GetFetchXml(FetchXml fetchXmlType)
        {
            Program.Trace(string.Format("Records will be retrieved for '{0}' fetch.", fetchXmlType.ToString()));
            string fetchXml = string.Empty;

            switch (fetchXmlType)
            {
                case FetchXml.ConfiguredSecurityRoles:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='role'>
                                    <attribute name='roleid' />
                                    <attribute name='name' />                                   
                                    <link-entity name='rbs_securityrolerulerelationship' from='rbs_securityrole' to='roleid' alias='linkentity'>                                        
                                       <attribute name='rbs_distributionthresholdcount' />
                                        <filter type='and'>
                                            <condition attribute='rbs_distributionrule' operator='eq' uitype='rbs_distributionrule' value='{0}' />
                                        </filter>
                                    </link-entity>                                      
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.UsersOnDistributionRuleSubgrid:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='systemuser'>
                                    <attribute name='fullname' />
                                    <attribute name='businessunitid' />
                                    <attribute name='positionid' />
                                    <attribute name='systemuserid' />
                                    <order attribute='fullname' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='isdisabled' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='rbs_userrulerelationship' from='rbs_user' to='systemuserid' alias='linkentity'>
                                      <attribute name='rbs_distributionthresholdcount' />
                                      <filter type='and'>
                                        <condition attribute='rbs_distributionrule' operator='eq' uitype='rbs_distributionrule' value='{0}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.UsersHavingConfiguredPositions:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='systemuser'>
                                    <attribute name='fullname' />
                                    <attribute name='businessunitid' />
                                    <attribute name='positionid' />
                                    <attribute name='systemuserid' />
                                    <order attribute='fullname' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='isdisabled' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='position' from='positionid' to='positionid' alias='ap'>
                                      <link-entity name='rbs_positionrulerelationship' from='rbs_position' to='positionid' alias='linkentity'>
                                      <attribute name='rbs_distributionthresholdcount' />
                                        <filter type='and'>
                                          <condition attribute='rbs_distributionrule' operator='eq' uitype='rbs_distributionrule' value='{0}' />
                                        </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.UsersInConfiguredTeams:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='systemuser'>
                                    <attribute name='fullname' />
                                    <attribute name='businessunitid' />
                                    <attribute name='positionid' />
                                    <attribute name='systemuserid' />
                                    <order attribute='fullname' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='isdisabled' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='teammembership' from='systemuserid' to='systemuserid' visible='false' intersect='true'>
                                      <link-entity name='team' from='teamid' to='teamid' alias='aj'>
                                        <link-entity name='rbs_teamrulerelationship' from='rbs_team' to='teamid' alias='linkentity'>
                                          <attribute name='rbs_distributionthresholdcount' />
                                          <filter type='and'>
                                            <condition attribute='rbs_distributionrule' operator='eq' uitype='rbs_distributionrule' value='{0}' />
                                          </filter>
                                        </link-entity>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.UsersHavingConfiguredSecurityRoles:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='systemuser'>
                                    <attribute name='fullname' />
                                    <attribute name='businessunitid' />
                                    <attribute name='positionid' />
                                    <attribute name='systemuserid' />
                                    <order attribute='fullname' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='isdisabled' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' visible='false' intersect='true'>
                                      <link-entity name='role' from='roleid' to='roleid' alias='an'>
                                        <attribute name='name' />
                                        {0}                                        
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.TeamsOnDistributionRuleSubgrid:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='team'>
                                    <attribute name='name' />
                                    <attribute name='businessunitid' />
                                    <attribute name='teamid' />
                                    <attribute name='teamtype' />
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='teamtype' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='rbs_teamrulerelationship' from='rbs_team' to='teamid' alias='linkentity'>
                                      <attribute name='rbs_distributionthresholdcount' />
                                      <filter type='and'>
                                        <condition attribute='rbs_distributionrule' operator='eq' uitype='rbs_distributionrule' value='{0}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.TeamsHavingConfiguredSecurityRoles:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='team'>
                                    <attribute name='name' />
                                    <attribute name='businessunitid' />
                                    <attribute name='teamid' />
                                    <attribute name='teamtype' />
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='teamtype' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='teamroles' from='teamid' to='teamid' visible='false' intersect='true'>
                                      <link-entity name='role' from='roleid' to='roleid' alias='av'>
                                        <link-entity name='rbs_securityrolerulerelationship' from='rbs_securityrole' to='roleid' alias='linkentity'>
                                          <attribute name='rbs_distributionthresholdcount' />
                                          <filter type='and'>
                                            <condition attribute='rbs_distributionrule' operator='eq' uitype='rbs_distributionrule' value='{0}' />
                                          </filter>
                                        </link-entity>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.UsersInExclusionTeam:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='systemuser'>
                                    <attribute name='fullname' />
                                    <attribute name='businessunitid' />
                                    <attribute name='positionid' />
                                    <attribute name='systemuserid' />
                                    <order attribute='fullname' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='isdisabled' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='teammembership' from='systemuserid' to='systemuserid' visible='false' intersect='true'>
                                      <link-entity name='team' from='teamid' to='teamid' alias='linkentity'>
                                        <filter type='and'>
                                          <condition attribute='teamid' operator='eq' uitype='team' value='{0}' />
                                        </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";
                    break;

                case FetchXml.ActiveRecordsOfTargetEntity:
                    fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='{0}'>
                                    <attribute name='{1}' />
                                    {2}
                                    <attribute name='ownerid' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                  </entity>
                                </fetch>";
                    break;
            }
            return fetchXml;
        }

        /// <summary>
        /// Generic function to retrieve the value of an attribute from the entity object
        /// </summary>
        /// <typeparam name="T">Generic data type</typeparam>
        /// <param name="Trace">Tracing service</param>
        /// <param name="en">Entity object in which the attribute needs to be checked</param>
        /// <param name="attribute">Attribute whose value needs to be retrieved from the entity object</param>
        /// <returns>Returns the value of the attribute if it is not null. Returns null otherwise</returns>
        private T GetValue<T>(Entity en, string attribute)
        {
            if (en != null)
            {
                if (en.Attributes.Contains(attribute) && en.Attributes[attribute] != null)
                {
                    return (T)Convert.ChangeType(en.GetAttributeValue<T>(attribute), typeof(T));
                }
                else
                {
                    return (T)Convert.ChangeType(null, typeof(T));
                }
            }
            else
            {
                return (T)Convert.ChangeType(null, typeof(T));
            }
        }
    }
}