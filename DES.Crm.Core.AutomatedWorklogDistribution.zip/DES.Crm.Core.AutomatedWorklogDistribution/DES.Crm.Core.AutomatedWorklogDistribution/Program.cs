﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.AWD
{
    class Program
    {
        private static string _logs = string.Empty;

        static void Main(string[] args)
        {
            try
            {
                IOrganizationService service;
                CrmServiceClient svcClient;                

                if (args == null && args.Count() != 2)
                    throw new Exception("DistributionRuleId or TriggerMode parameters is/are missing.");

                CreateCrmConnection(out service, out svcClient);

                DistributeRecords dr = new DistributeRecords();
                dr.Execute(service, new Guid(args[0]), Convert.ToBoolean(args[1]));
            }
            catch (Exception ex)
            {
                Trace(string.Format("Exception occured: " + ex.Message));
                throw new Exception("Exception occured: " + ex.Message);
            }
        }

        static private void CreateCrmConnection(out IOrganizationService service, out CrmServiceClient svcClient)
        {
            string orgUrl;
            ClientCredentials clientCredentials;

            ReadConfigurationData(out orgUrl, out clientCredentials);

            // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            Trace(string.Format("Trying to establish connection with CRM..."));

            OrganizationServiceProxy proxy = new OrganizationServiceProxy(new Uri(orgUrl), null, clientCredentials, null);
            svcClient = new CrmServiceClient(proxy);
            service = (IOrganizationService)proxy;

            if (service != null)
            {
                var whoAmI = (WhoAmIResponse)service.Execute(new WhoAmIRequest());
                Trace(string.Format("Connection established successfully."));
                System.Threading.Thread.Sleep(1500);
            }
            else
            {
                Trace(string.Format(System.Environment.NewLine + "Failed to establish connection!" + System.Environment.NewLine));
                throw new Exception();
            }
        }

        private static void ReadConfigurationData(out string orgUrl, out ClientCredentials clientCredentials)
        {
            string org = ConfigurationManager.AppSettings["Org"];
            orgUrl = "https://{0}.api.crm4.dynamics.com/XRMServices/2011/Organization.svc";
            orgUrl = string.Format(orgUrl, org);

            clientCredentials = new ClientCredentials();

            if (ConfigurationManager.AppSettings["UserName"].Equals(""))
            {
                Trace(string.Format("Enter your username: "));
                clientCredentials.UserName.UserName = Console.ReadLine();
            }
            else
            {
                Trace(string.Format("Username: {0}", ConfigurationManager.AppSettings["UserName"]));
                clientCredentials.UserName.UserName = ConfigurationManager.AppSettings["UserName"];
            }

            if (ConfigurationManager.AppSettings["Password"].Equals(""))
            {
                Console.Write("Enter your password: ");
                clientCredentials.UserName.Password = DataProtect.ReadPassword();
            }
            else
                clientCredentials.UserName.Password = DataProtect.DecryptString(ConfigurationManager.AppSettings["Password"].ToString());

        }

        public static void Trace(string data)
        {
            Console.WriteLine(string.Format(data));

            _logs += string.Format(data) + "\r\n";
        }

        public static void LogTrace()
        {
            StreamWriter log;
            string filePath = ConfigurationManager.AppSettings["LogPath"].ToString();

            if (!File.Exists(filePath))
            {
                log = new StreamWriter(filePath);
            }
            else
            {
                log = File.AppendText(filePath);
            }

            // Write to the file:
            log.WriteLine(DateTime.Now);
            log.WriteLine(_logs);
            log.WriteLine();

            string filepathwithoutextension = filePath.Substring(0, filePath.LastIndexOf(".") - 1);
            string extension = filePath.Substring(filePath.LastIndexOf("."));

            // Close the stream:
            log.Close();

            if (!File.Exists(filepathwithoutextension + "_" + DateTime.Now.ToString("yyyyMMdd") + extension))
                File.Copy(filePath, filepathwithoutextension + "_" + DateTime.Now.ToString("yyyyMMdd") + extension);
            else
                File.AppendAllLines(filepathwithoutextension + "_" + DateTime.Now.ToString("yyyyMMdd") + extension, File.ReadAllLines(filePath));

            File.Delete(filePath);
        }
    }
}
