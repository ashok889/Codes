﻿using System;
using System.Activities;
using System.ServiceModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;

namespace DES.Crm.Core.AWD.Workflows
{
    public class UpdateNextTriggerDate : CodeActivity
    {
        #region Public properties and variable declaration

        public struct CrmAttribute
        {
            public struct DistributionRule
            {
                public const string rbs_nexttriggerdate = "rbs_nexttriggerdate";
            }
        }

        #endregion

        [Input("Next Trigger Date")]
        [RequiredArgument]
        public InArgument<DateTime> NextTriggerDate { get; set; }

        [Input("Frequency")]
        [RequiredArgument]
        public InArgument<int> Frequency { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            if (tracingService == null)
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");

            if (context == null)
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");

            tracingService.Trace("Entered UpdateNextTriggerDate.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}", executionContext.ActivityInstanceId, executionContext.WorkflowInstanceId);
            tracingService.Trace("UpdateNextTriggerDate.Execute(), Correlation Id: {0}, Initiating User: {1}", context.CorrelationId, context.InitiatingUserId);

            try
            {
                BusinessLogic(service, tracingService, context, executionContext);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally
            {
                tracingService.Trace("Execution completed. Exiting UpdateNextTriggerDate.Execute().");
            }
        }

        private void BusinessLogic(IOrganizationService service, ITracingService tracingService, IWorkflowContext context, CodeActivityContext executionContext)
        {
            tracingService.Trace("Primary Entity Name: " + context.PrimaryEntityName);
            tracingService.Trace("Primary Entity Id: " + context.PrimaryEntityId.ToString().ToUpper());

            DateTime nextTriggerDate = NextTriggerDate.Get<DateTime>(executionContext);
            int frequency = Frequency.Get<int>(executionContext);

            tracingService.Trace("Input Next Trigger Date: " + nextTriggerDate.ToString());
            tracingService.Trace("Input Frequency (in minutes): " + frequency.ToString());

            DateTime updatedDate = nextTriggerDate.AddMinutes(frequency);

            Entity enToBeUpdated = new Entity(context.PrimaryEntityName, context.PrimaryEntityId);
            enToBeUpdated[CrmAttribute.DistributionRule.rbs_nexttriggerdate] = updatedDate;
            service.Update(enToBeUpdated);

            tracingService.Trace("Updated Next Trigger Date: " + updatedDate);
        }
    }
}
