﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.AWD.Workflows
{
    public class Common
    {
        public static string GetLookupAttributeNameByEntityName(IOrganizationService service, ITracingService tracingService, string entityName, string ruleEntityName)
        {
            // Create the request.
            RetrieveEntityRequest entityRequest = new RetrieveEntityRequest();

            // Retrieve only the currently published changes, ignoring the changes that have not been published.
            entityRequest.RetrieveAsIfPublished = false;
            entityRequest.LogicalName = entityName;
            entityRequest.EntityFilters = EntityFilters.Attributes;

            // Execute the request.
            RetrieveEntityResponse entityResponse = (RetrieveEntityResponse)service.Execute(entityRequest);

            // Access the retrieved entity metadata.
            var retrievedEntityMetadata = entityResponse.EntityMetadata;

            foreach (AttributeMetadata attribute in retrievedEntityMetadata.Attributes)
            {
                if ((attribute.AttributeType.Equals(AttributeTypeCode.Customer) || attribute.AttributeType.Equals(AttributeTypeCode.Lookup)) && ((LookupAttributeMetadata)attribute).Targets.Contains(ruleEntityName))
                {
                    tracingService.Trace("Lookup attribute name is: {0} for entity: {1}", attribute.LogicalName, ruleEntityName);
                    return attribute.LogicalName;
                }
            }
            tracingService.Trace("Could not find Lookup attribute name for entity: " + ruleEntityName);

            return string.Empty;
        }
    }
}
