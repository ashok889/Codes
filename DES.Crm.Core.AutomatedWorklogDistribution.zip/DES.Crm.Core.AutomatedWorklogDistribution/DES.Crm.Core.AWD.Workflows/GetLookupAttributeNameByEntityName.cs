﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.AWD.Workflows
{
    public class GetLookupAttributeNameByEntityName : CodeActivity
    {
        [Input("Lookup Entity Schema Name")]        
        [RequiredArgument]
        public InArgument<string> LookupEntitySchemaName { get; set; }

        [Input("To Search in Entity Schema Name")]        
        [RequiredArgument]
        public InArgument<string> ToSearchInEntitySchemaName { get; set; }

        [Output("Lookup Attribute Schema Name")]        
        public OutArgument<string> LookupAttributeSchemaName { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            if (tracingService == null)
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");

            if (context == null)
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");

            tracingService.Trace("Entered GetLookupAttributeNameByEntityName.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}", executionContext.ActivityInstanceId, executionContext.WorkflowInstanceId);
            tracingService.Trace("GetLookupAttributeNameByEntityName.Execute(), Correlation Id: {0}, Initiating User: {1}", context.CorrelationId, context.InitiatingUserId);

            try
            {
                string attributeName = Common.GetLookupAttributeNameByEntityName(service, tracingService, ToSearchInEntitySchemaName.Get<string>(executionContext), LookupEntitySchemaName.Get<string>(executionContext));

                LookupAttributeSchemaName.Set(executionContext, attributeName);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally
            {
                tracingService.Trace("Execution completed. Exiting GetLookupAttributeNameByEntityName.Execute().");
            }
        }
    }
}
