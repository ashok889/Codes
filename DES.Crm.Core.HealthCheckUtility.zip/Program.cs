﻿using DES.Crm.Core.Common.Security;
using System;
using System.Linq;
using System.Net;
using System.Xml.Linq;

namespace DES.Crm.Core.HealthCheckUtility
{
    class Program
    {
        static void Main(string[] args)
        {
            string connParameter = string.Empty;

            try
            {
                if (args.Length > 0)
                {
                    connParameter = args[0];
                }
                else
                {
                    throw new Exception("Please provide the connection parameter as argument.");
                }

                XDocument xDoc = XDocument.Load("Config.xml");

                var conn = xDoc.Element("Config")
                                    .Element("crmconnections")
                                    .Elements("crmconnection")
                                       .Where(x => x.Attribute("id").Value.ToLower() == connParameter.ToLower())
                                    .FirstOrDefault();

                var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
                  conn.Attribute("requirenewinstance").Value,
                  conn.Attribute("organizationurl").Value,
                  conn.Attribute("crmuserid").Value,
                  DataProtect.DecryptString(conn.Attribute("crmuserpassword").Value),
                  conn.Attribute("authtype").Value);

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

                if (!service.IsReady)
                {
                    throw new Exception("Could not connect to CRM. " + conn + " " + service.LastCrmException);
                }
                else
                {
                    HealthCheck objHealthCheck = new HealthCheck(conn.Attribute("organizationurl").Value);

                    objHealthCheck.CheckAuditingStatus(service, xDoc);
					objHealthCheck.CheckPluginStatus(service, xDoc);
                    objHealthCheck.CheckWorkflowStatus(service, xDoc);
                    objHealthCheck.ValidateHealthCheckCounts(service, xDoc);
                    
                    objHealthCheck.LogHealthCheckSummary(xDoc);

                    if (objHealthCheck.ErrorList.Length > 0)
                        throw new Exception(objHealthCheck.ErrorList.ToString());
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
