﻿using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Xrm.Sdk;
using System.IO;
using System.Text;
using DES.Crm.Core.Common.Security;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Xml;

namespace DES.Crm.Core.HealthCheckUtility
{
    class HealthCheck
    {
        private StringBuilder errorList = new StringBuilder();
        private StringBuilder healthCheckSummary = new StringBuilder();

        internal StringBuilder ErrorList
        { get { return errorList; } }
        internal StringBuilder HealthCheckSummary
        { get { return healthCheckSummary; } }

        public HealthCheck(string connInstance)
        {
            healthCheckSummary.AppendLine("Starting Health Check process for " + connInstance);
        }

        internal void CheckAuditingStatus(CrmServiceClient crmSvc, XDocument xDoc)
        {
            var auditElements = xDoc.Element("Config")
                                    .Element("HealthCheckSection")
                                    .Elements("audit")
                                    .Elements();

            var crmSolutionName = xDoc.Element("Config")
                                    .Element("CrmSolutionName").Value.Split(';');

            string solutionNameFilter = @"<filter type='or'>";

            foreach (var solutionName in crmSolutionName)
                solutionNameFilter += "<condition attribute='uniquename' operator='eq' value='" + solutionName + @"' />";

            solutionNameFilter += @"</filter>";

            var configAuditEnabledCount = auditElements.Where(w => Convert.ToBoolean(w.Attribute("value").Value)).Count();
            var configAuditDisabledCount = auditElements.Where(w => !Convert.ToBoolean(w.Attribute("value").Value)).Count();

            Dictionary<string, bool> auditEntities = new Dictionary<string, bool>();

            string sFetchEntities = @"<fetch>
                                    <entity name='solutioncomponent' >
                                        <attribute name='objectid' />
                                        <filter>
                                            <condition attribute='componenttype' operator='eq' value='1' />
                                        </filter>
                                        <link-entity name='solution' from='solutionid' to='solutionid' >
                                            {0}
                                        </link-entity>
                                    </entity>
                                </fetch>";

            EntityCollection retrievedauditEntities = crmSvc.RetrieveMultiple(new FetchExpression(string.Format(sFetchEntities, solutionNameFilter)));

            foreach (Entity auditEntity in retrievedauditEntities.Entities)
            {
                string sFetch = @"<fetch>
                                    <entity name='entity' >
                                        <attribute name='name' />
                                        <filter>
                                            <condition attribute='entityid' operator='eq' value='{0}' />
                                        </filter>                                        
                                    </entity>
                                </fetch>";

                ExecuteFetchRequest req1 = new ExecuteFetchRequest
                {
                    FetchXml = string.Format(sFetch, ((Guid)auditEntity["objectid"]).ToString())
                };

                ExecuteFetchResponse res1 = (ExecuteFetchResponse)crmSvc.Execute(req1);

                if (!string.IsNullOrEmpty(res1.FetchXmlResult))
                {
                    XmlDocument xmlDoc1 = new XmlDocument();
                    xmlDoc1.LoadXml(res1.FetchXmlResult);

                    string entityName = xmlDoc1.GetElementsByTagName("name")[0].InnerText.ToLower();

                    RetrieveEntityRequest req = new RetrieveEntityRequest()
                    {
                        EntityFilters = EntityFilters.All,
                        LogicalName = entityName,
                        RetrieveAsIfPublished = true
                    };

                    RetrieveEntityResponse res = (RetrieveEntityResponse)crmSvc.Execute(req);

                    if (!auditEntities.ContainsKey(entityName))
                        auditEntities.Add(entityName, res.EntityMetadata.IsAuditEnabled.Value);
                }
            }

            var crmAuditEnabledCount = auditEntities.Where(w => w.Value).Count();
            var crmAuditDisabledCount = auditEntities.Where(w => !w.Value).Count();

            foreach (XElement item in auditElements)
            {
                if (item.Attribute("name").Value == "organization")
                {
                    CheckAuditingStatus_Organization(crmSvc, item);
                }
                else
                {
                    if (auditEntities.ContainsKey(item.Attribute("name").Value))
                    {
                        CheckAuditingStatus_Entity(crmSvc, item, auditEntities);
                    }
                }
            }

            HealthCheckSummary.AppendLine("AuditCheckInfo: Config Audit Enabled Count: " + configAuditEnabledCount + "; Crm Audit Enabled Count: " + crmAuditEnabledCount);
            HealthCheckSummary.AppendLine("AuditCheckInfo: Config Audit Disabled Count: " + configAuditDisabledCount + "; Crm Audit Disabled Count: " + crmAuditDisabledCount);

            if (!configAuditEnabledCount.Equals(crmAuditEnabledCount) || !configAuditDisabledCount.Equals(crmAuditDisabledCount))
            {
                ErrorList.AppendLine("AuditCheckFailed: Count mismatch.");
                HealthCheckSummary.AppendLine("AuditCheckFailed: Count mismatch.");
            }
        }

        private void CheckAuditingStatus_Organization(CrmServiceClient crmSvc, XElement auditElement)
        {
            QueryExpression query = new QueryExpression("organization");
            query.ColumnSet = new ColumnSet(new string[] { "isauditenabled" });
            query.Distinct = true;
            var orgs = crmSvc.RetrieveMultiple(query);

            if (orgs.Entities.Count > 0)
            {
                if (orgs.Entities[0].Attributes["isauditenabled"].ToString().ToLower() != auditElement.Attribute("value").Value.ToString().ToLower())
                {
                    ErrorList.AppendLine("AuditCheckFailed: Organization level auditing is not properly set.");
                    HealthCheckSummary.AppendLine("AuditCheckFailed: Organization level auditing is not properly set.");
                }
            }

            return;
        }

        private void CheckAuditingStatus_Entity(CrmServiceClient crmSvc, XElement auditElement, Dictionary<string, bool> auditEntities)
        {
            if (auditEntities[auditElement.Attribute("name").Value.ToString().ToLower()].ToString().ToLower() != auditElement.Attribute("value").Value.ToString().ToLower())
            {
                ErrorList.AppendLine("AuditCheckFailed:Entity level auditing is not properly set for:" + auditElement.Attribute("name").Value);
                HealthCheckSummary.AppendLine("AuditCheckFailed:Entity level auditing is not properly set for:" + auditElement.Attribute("name").Value);
            }
            return;
        }

        internal void CheckPluginStatus(CrmServiceClient crmSvc, XDocument xDoc)
        {
            var pluginStepElements = xDoc.Element("Config")
                                    .Element("HealthCheckSection")
                                    .Elements("pluginsteps")
                                    .Elements();

            var exceptionElements = xDoc.Element("Config")
                                    .Element("HealthCheckSection")
                                    .Elements("exceptionList")
                                    .Elements();

            var crmSolutionName = xDoc.Element("Config")
                                    .Element("CrmSolutionName").Value.Split(';');

            string solutionNameFilter = @"<filter type='or'>";

            foreach (var solutionName in crmSolutionName)
                solutionNameFilter += "<condition attribute='uniquename' operator='eq' value='" + solutionName + @"' />";

            solutionNameFilter += @"</filter>";

            var runFrequency = xDoc.Element("Config")
                                    .Element("Frequency").Value;

            var nameSpace = xDoc.Element("Config")
                                .Element("HealthCheckSection")
                                .Element("pluginsteps").Attribute("namespace").Value;

            var configPluginStepsActivatedCount = pluginStepElements.Where(w => w.Attribute("state").Value.ToLower().Equals("activated")).Count();
            var configPluginStepsDeactivatedCount = pluginStepElements.Where(w => w.Attribute("state").Value.ToLower().Equals("draft")).Count();

            List<Entity> pluginSteps = new List<Entity>();

            string sFetchPluginSteps = @"<fetch>
                                          <entity name='sdkmessageprocessingstep' >
                                            <attribute name='name' />
                                            <attribute name='statuscode' />
                                            <attribute name='statecode' />
                                            <attribute name='sdkmessageprocessingstepid' />
                                            <link-entity name='plugintype' from='plugintypeid' to='plugintypeid' >
                                              <attribute name='name' />
                                              <filter>
                                                <condition attribute='name' operator='like' value='%" + nameSpace + @"%' />
                                              </filter>
                                            </link-entity>
                                          </entity>
                                        </fetch>";

            EntityCollection retrievedPluginSteps = crmSvc.RetrieveMultiple(new FetchExpression(sFetchPluginSteps));

            foreach (Entity pluginStep in retrievedPluginSteps.Entities)
            {
                string sFetch = @"<fetch>
                                    <entity name='solutioncomponent' >
                                        <filter>
                                            <condition attribute='componenttype' operator='eq' value='92' />
                                            <condition attribute='objectid' operator='eq' value='{0}' />
                                        </filter>
                                        <link-entity name='solution' from='solutionid' to='solutionid' >
                                            {1}
                                        </link-entity>
                                    </entity>
                                </fetch>";

                EntityCollection enCollSolution = crmSvc.RetrieveMultiple(new FetchExpression(string.Format(sFetch, pluginStep.Id.ToString(), solutionNameFilter)));

                if (enCollSolution != null && enCollSolution.Entities != null && enCollSolution.Entities.Count > 0)
                {
                    pluginSteps.Add(pluginStep);
                }
            }

            var crmPluginStepActivatedCount = pluginSteps.Where(w => (((OptionSetValue)w["statecode"]).Value.Equals(0))).Count();
            var crmPluginStepDeactivatedCount = pluginSteps.Where(w => (((OptionSetValue)w["statecode"]).Value.Equals(1))).Count();

            foreach (XElement item in pluginStepElements)
            {
                if (pluginSteps.Any(w => w.Id.Equals(new Guid(item.Attribute("id").Value))))
                {
                    Entity retrievedPluginStep = pluginSteps.FirstOrDefault(w => w.Id.Equals(new Guid(item.Attribute("id").Value)));

                    var crmPluginStepStatus = ((OptionSetValue)retrievedPluginStep["statecode"]).Value == 0 ? "Activated" : "Draft";

                    if (crmPluginStepStatus.ToLower() != item.Attribute("state").Value.ToLower())
                    {
                        ErrorList.AppendLine("PluginStepStatusCheckFailed: Plugin Step state is not properly set for Plugin Step(sdkmessageprocessingstepid):" + ((AliasedValue)retrievedPluginStep.Attributes["plugintype1.name"]).Value + "(" + item.Attribute("id").Value + ")");
                        HealthCheckSummary.AppendLine("PluginStepStatusCheckFailed: Plugin Step state is not properly set for Plugin Step(sdkmessageprocessingstepid):" + ((AliasedValue)retrievedPluginStep.Attributes["plugintype1.name"]).Value + "(" + item.Attribute("id").Value + ")");
                    }

                    CheckIfPluginJobFailed(crmSvc, item, exceptionElements, runFrequency);
                }
            }

            HealthCheckSummary.AppendLine("PluginStepStatusCheckInfo: Config Plugin Step Activated Count: " + configPluginStepsActivatedCount + "; Crm Plugin Step Activated Count: " + crmPluginStepActivatedCount);
            HealthCheckSummary.AppendLine("PluginStepStatusCheckInfo: Config Plugin Step Deactivated Count: " + configPluginStepsDeactivatedCount + "; Crm Plugin Step Deactivated Count: " + crmPluginStepDeactivatedCount);

            if (!configPluginStepsActivatedCount.Equals(crmPluginStepActivatedCount) || !configPluginStepsDeactivatedCount.Equals(crmPluginStepDeactivatedCount))
            {
                ErrorList.AppendLine("PluginStepStatusCheckFailed: Count mismatch.");
                HealthCheckSummary.AppendLine("PluginStepStatusCheckFailed: Count mismatch.");
            }

            return;
        }

        internal void CheckIfPluginJobFailed(CrmServiceClient crmSvc, XElement item, IEnumerable<XElement> exceptionElements, string runFrequency)
        {
            if (item.Attribute("jobstatuscheckrequired").Value.ToLower().Equals("true"))
            {
                var pluginStepQuery = new QueryExpression("plugintracelog");
                pluginStepQuery.ColumnSet = new ColumnSet("createdon", "exceptiondetails");

                pluginStepQuery.Criteria = new FilterExpression();
                pluginStepQuery.Criteria.AddCondition(new ConditionExpression("pluginstepid", ConditionOperator.Equal, new Guid(item.Attribute("id").Value)));
                pluginStepQuery.Criteria.AddCondition(new ConditionExpression("operationtype", ConditionOperator.Equal, 1));
                pluginStepQuery.Criteria.AddCondition(new ConditionExpression("exceptiondetails", ConditionOperator.NotEqual, string.Empty));
                pluginStepQuery.Criteria.AddCondition(new ConditionExpression("createdon", ConditionOperator.OnOrAfter, DateTime.UtcNow.Date));

                EntityCollection pluginJobs = crmSvc.RetrieveMultiple(pluginStepQuery);

                if (pluginJobs != null && pluginJobs.Entities != null && pluginJobs.Entities.Count > 0)
                {
                    bool actualError = false;

                    foreach (Entity enAsyncJob in pluginJobs.Entities.Where(w => w.Attributes.Contains("exceptiondetails") && ((DateTime)w.Attributes["createdon"]) >= ((string.IsNullOrEmpty(runFrequency) || runFrequency.ToLower().Equals("hourly")) ? DateTime.UtcNow.Add(new TimeSpan(-1, 0, 0)) : DateTime.UtcNow.Date)))
                    {
                        if (exceptionElements.Count() > 0)
                        {
                            foreach (XElement exceptionElement in exceptionElements)
                            {
                                actualError = false;

                                if (!enAsyncJob.Attributes["exceptiondetails"].ToString().Contains(exceptionElement.Attribute("name").Value))
                                {
                                    actualError = true;
                                }
                                else
                                    break;
                            }
                        }
                        else
                            actualError = true;

                        if (actualError)
                            break;
                    }

                    if (actualError)
                    {
                        ErrorList.AppendLine("PluginJobStatusCheckFailed: One of a Plugin job has been failed today for Plugin Step(sdkmessageprocessingstepid):" + item.Attribute("name").Value + "(" + item.Attribute("id").Value + ")");
                        HealthCheckSummary.AppendLine("PluginJobStatusCheckFailed: One of a Plugin job has been failed today for Plugin Step(sdkmessageprocessingstepid):" + item.Attribute("name").Value + "(" + item.Attribute("id").Value + ")");
                    }
                }
            }

            return;
        }

        internal void CheckWorkflowStatus(CrmServiceClient crmSvc, XDocument xDoc)
        {
            var workflowElements = xDoc.Element("Config")
                                    .Element("HealthCheckSection")
                                    .Elements("workflows")
                                    .Elements();

            var exceptionElements = xDoc.Element("Config")
                                    .Element("HealthCheckSection")
                                    .Elements("exceptionList")
                                    .Elements();

            var crmSolutionName = xDoc.Element("Config")
                                    .Element("CrmSolutionName").Value.Split(';');

            string solutionNameFilter = @"<filter type='or'>";

            foreach (var solutionName in crmSolutionName)
                solutionNameFilter += "<condition attribute='uniquename' operator='eq' value='" + solutionName + @"' />";

            solutionNameFilter += @"</filter>";

            var runFrequency = xDoc.Element("Config")
                                    .Element("Frequency").Value;

            var configProcessActivatedCount = workflowElements.Where(w => w.Attribute("state").Value.ToLower().Equals("activated")).Count();
            var configProcessDeactivatedCount = workflowElements.Where(w => w.Attribute("state").Value.ToLower().Equals("draft")).Count();

            List<Entity> workflows = new List<Entity>();

            string sFetchWorkflows = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                        <entity name='workflow'>
                                        <attribute name='workflowid' />
                                        <attribute name='name' />
                                        <attribute name='category' />
                                        <attribute name='statecode' />
                                        <order attribute='name' descending='false' />
                                        <filter type='and'>
                                            <condition attribute='type' operator='eq' value='1' />
                                            <condition attribute='category' operator='in'>
                                            <value>3</value>
                                            <value>4</value>
                                            <value>0</value>
                                            <value>1</value>
                                            <value>2</value>
                                            </condition>
                                            <condition attribute='ismanaged' operator='eq' value='0' />
                                        </filter>
                                        </entity>
                                    </fetch>";

            EntityCollection retrievedWorkflows = crmSvc.RetrieveMultiple(new FetchExpression(sFetchWorkflows));

            foreach (Entity workflow in retrievedWorkflows.Entities)
            {
                string sFetch = @"<fetch>
                                    <entity name='solutioncomponent' >
                                        <filter>
                                            <condition attribute='componenttype' operator='eq' value='29' />
                                            <condition attribute='objectid' operator='eq' value='{0}' />
                                        </filter>
                                        <link-entity name='solution' from='solutionid' to='solutionid' >
                                            {1}
                                        </link-entity>
                                    </entity>
                                </fetch>";

                EntityCollection enCollSolution = crmSvc.RetrieveMultiple(new FetchExpression(string.Format(sFetch, workflow.Id.ToString(), solutionNameFilter)));

                if (enCollSolution != null && enCollSolution.Entities != null && enCollSolution.Entities.Count > 0)
                {
                    workflows.Add(workflow);
                }
            }

            var crmProcessActivatedCount = workflows.Where(w => (((OptionSetValue)w["statecode"]).Value.Equals(1))).Count();
            var crmProcessDeactivatedCount = workflows.Where(w => (((OptionSetValue)w["statecode"]).Value.Equals(0))).Count();

            foreach (XElement item in workflowElements)
            {
                if (workflows.Any(w => w.Id.Equals(new Guid(item.Attribute("id").Value))))
                {
                    Entity retrievedWorkflow = workflows.FirstOrDefault(w => w.Id.Equals(new Guid(item.Attribute("id").Value)));

                    var crmWorkflowStatus = ((OptionSetValue)retrievedWorkflow["statecode"]).Value == 1 ? "Activated" : "Draft";

                    if (crmWorkflowStatus.ToLower() != item.Attribute("state").Value.ToLower())
                    {
                        ErrorList.AppendLine("WorkflowStatusCheckFailed: Workflow state is not properly set for Workflow(workflowid):" + retrievedWorkflow["name"] + "(" + item.Attribute("id").Value + ")");
                        HealthCheckSummary.AppendLine("WorkflowStatusCheckFailed: Workflow state is not properly set for Workflow(workflowid):" + retrievedWorkflow["name"] + "(" + item.Attribute("id").Value + ")");
                    }

                    CheckIfWorkflowJobFailed(crmSvc, item, exceptionElements, runFrequency);
                }
            }

            HealthCheckSummary.AppendLine("WorkflowStatusCheckInfo: Config Process Activated Count: " + configProcessActivatedCount + "; Crm Process Activated Count: " + crmProcessActivatedCount);
            HealthCheckSummary.AppendLine("WorkflowStatusCheckInfo: Config Process Deactivated Count: " + configProcessDeactivatedCount + "; Crm Process Deactivated Count: " + crmProcessDeactivatedCount);

            if (!configProcessActivatedCount.Equals(crmProcessActivatedCount) || !configProcessDeactivatedCount.Equals(crmProcessDeactivatedCount))
            {
                ErrorList.AppendLine("WorkflowStatusCheckFailed: Count mismatch.");
                HealthCheckSummary.AppendLine("WorkflowStatusCheckFailed: Count mismatch.");
            }

            return;
        }

        internal void CheckIfWorkflowJobFailed(CrmServiceClient crmSvc, XElement item, IEnumerable<XElement> exceptionElements, string runFrequency)
        {
            if (item.Attribute("jobstatuscheckrequired").Value.ToLower().Equals("true"))
            {
                var workflowQuery = new QueryExpression("processsession");
                workflowQuery.ColumnSet = new ColumnSet("createdon", "comments");

                LinkEntity linkedEntity = new LinkEntity();
                linkedEntity.LinkFromAttributeName = "processid";
                linkedEntity.LinkFromEntityName = "processsession";
                linkedEntity.LinkToAttributeName = "workflowid";
                linkedEntity.LinkToEntityName = "workflow";

                linkedEntity.LinkCriteria = new FilterExpression();
                linkedEntity.LinkCriteria.AddCondition(new ConditionExpression("name", ConditionOperator.Equal, item.Attribute("name").Value));

                workflowQuery.Criteria = new FilterExpression();
                workflowQuery.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.Equal, "6")); //6 = Failed
                workflowQuery.Criteria.AddCondition(new ConditionExpression("createdon", ConditionOperator.OnOrAfter, DateTime.UtcNow.Date));
                workflowQuery.LinkEntities.Add(linkedEntity);

                EntityCollection workflowJobs = crmSvc.RetrieveMultiple(workflowQuery);

                if (workflowJobs != null && workflowJobs.Entities != null && workflowJobs.Entities.Count > 0)
                {
                    bool actualError = false;

                    foreach (Entity enAsyncJob in workflowJobs.Entities.Where(w => w.Attributes.Contains("comments") && ((DateTime)w.Attributes["createdon"]) >= ((string.IsNullOrEmpty(runFrequency) || runFrequency.ToLower().Equals("hourly")) ? DateTime.UtcNow.Add(new TimeSpan(-1, 0, 0)) : DateTime.UtcNow.Date)))
                    {
                        if (exceptionElements.Count() > 0)
                        {
                            foreach (XElement exceptionElement in exceptionElements)
                            {
                                actualError = false;

                                if (!enAsyncJob.Attributes["comments"].ToString().Contains(exceptionElement.Attribute("name").Value))
                                {
                                    actualError = true;
                                }
                                else
                                    break;
                            }
                        }
                        else
                            actualError = true;

                        if (actualError)
                            break;
                    }

                    if (actualError)
                    {
                        ErrorList.AppendLine("WorkflowJobStatusCheckFailed: One of a Workflow job has been failed today for Workflow(workflowid):" + item.Attribute("name").Value + "(" + item.Attribute("id").Value + ")");
                        HealthCheckSummary.AppendLine("WorkflowJobStatusCheckFailed: One of a Workflow job has been failed today for Workflow(workflowid):" + item.Attribute("name").Value + "(" + item.Attribute("id").Value + ")");
                    }
                }
            }

            return;
        }



        internal void ValidateHealthCheckCounts(CrmServiceClient crmSvc, XDocument xDoc)
        {
            var fetchQueryElements = xDoc.Element("Config")
                                      .Element("HealthCheckCount")
                                      .Elements("FetchQuery");

            foreach (XElement fetchQuery in fetchQueryElements)
            {
                string name = fetchQuery.Element("Name").Value;
                string fetch = fetchQuery.Element("Fetch").Value;
                int threshold = Convert.ToInt32(fetchQuery.Element("ErrorThreshold").Value);
                var records = crmSvc.RetrieveMultiple(new FetchExpression(fetch));
                int recordsCount = (int)((AliasedValue)records.Entities[0]["Records"]).Value;

                if (recordsCount > threshold)
                {
                    ErrorList.AppendLine(string.Format("Check{0}CountFailed: Expected count is {1} but existing count is: {2}", name, threshold, recordsCount));
                    HealthCheckSummary.AppendLine(string.Format("Check{0}CountFailed: Expected count is {1} but existing count is: {2}", name, threshold, recordsCount));
                }
                else
                {
                    HealthCheckSummary.AppendLine(string.Format("Check{0}CountPassed: Expected threshold count is {1} and existing count is: {2}", name, threshold, recordsCount));
                }
            }
        }

        internal void LogHealthCheckSummary(XDocument xDoc)
        {
            var logPath = xDoc.Element("Config")
                                      .Element("LogPath")
                                      .Value;

            // Create a writer and open the file:
            StreamWriter log;
            string filePath = logPath;

            if (!File.Exists(filePath))
            {
                log = new StreamWriter(filePath);
            }
            else
            {
                log = File.AppendText(filePath);
            }

            // Write to the file:
            log.WriteLine(DateTime.Now);
            log.WriteLine(HealthCheckSummary);
            log.WriteLine();

            string filepathwithoutextension = filePath.Substring(0, filePath.LastIndexOf(".") - 1);
            string extension = filePath.Substring(filePath.LastIndexOf("."));

            // Close the stream:
            log.Close();

            if (!File.Exists(filepathwithoutextension + "_" + DateTime.Now.ToString("yyyyMMdd") + extension))
                File.Copy(filePath, filepathwithoutextension + "_" + DateTime.Now.ToString("yyyyMMdd") + extension);
            else
                File.AppendAllLines(filepathwithoutextension + "_" + DateTime.Now.ToString("yyyyMMdd") + extension, File.ReadAllLines(filePath));

            File.Delete(filePath);
        }
    }
}
