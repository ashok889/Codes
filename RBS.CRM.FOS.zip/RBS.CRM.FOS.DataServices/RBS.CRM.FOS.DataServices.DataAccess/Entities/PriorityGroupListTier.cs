﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRM.DataServices.DataAccess.Entities
{
    public class PriorityGroupListTier
    {
        public int StagingId { get; set; }
        public string Name { get; set; }
        public string PriorityType { get; set; }
        public int ParentStagingId { get; set; }
        public string ParentMSCRMId { get; set; }
        public string MSCRMId { get; set; }
    }
}
