﻿using System;
using System.Collections.Generic;


namespace CRM.DataServices.DataAccess.Entities
{
    /// <summary>
    /// Client information
    /// </summary>
    public class Client
    {
        public string Name { get; set; }
        public int StagingClientId { get; set; }
        public int? ParentClientId { get; set; }
        public string MSCRMId { get; set; }
        public string ParentMSCRMId { get; set; }
        public string UltimateParentMSCRMId { get; set; }
        public int SDMId { get; set; }
        public int RootClientId { get; set; }
        public int UpdateUserId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string CISCode { get; set; }
        public int CreatorId { get; set; }
        public bool IsActive { get; set; }
        public int ClientPriorityTierID { get; set; }
        public int LevelId { get; set; }
        public int? Telephone { get; set; }
        public string Classification { get; set; }
        public string Domicile { get; set; }
        public string Geography { get; set; }
        public string Sector { get; set; }
        public string Source { get; set; }
        public int SourceId { get; set; }
        public string SubSector { get; set; }
    }
}
