﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRM.DataServices.DataAccess.Entities
{
    public class SDMClientUserRole
    {
        public string ClientMSCRMId { get; set; }
        public int LevelId { get; set; }
        public int StagingId { get; set; }
        public string RoleId { get; set; }
        public string MSCRMID { get; set; }
        public string UserName { get; set; }
        public bool IsDeleted { get; set; }
        public string EmployeeMSCRMID { get; set; }
    }
}
