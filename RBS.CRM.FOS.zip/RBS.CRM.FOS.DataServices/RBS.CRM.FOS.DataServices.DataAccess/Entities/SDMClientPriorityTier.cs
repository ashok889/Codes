﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRM.DataServices.DataAccess.Entities
{
    public class SDMClientPriorityTier
    {
        public string ClientMSCRMID { get; set; }
        public string PriorityMSCRMID { get; set; }
        public int StagingId { get; set; }
        public bool IsDeleted { get; set; }
        public string MSCRMID { get; set; }
    }
}
