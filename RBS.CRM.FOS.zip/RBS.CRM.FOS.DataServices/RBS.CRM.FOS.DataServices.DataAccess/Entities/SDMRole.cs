﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRM.DataServices.DataAccess.Entities
{
    public class SDMRole
    {
        public int SDMRoleId { get; set; }
        public string RoleDescription { get; set; }
        public int StagingId { get; set; }
        public DateTime UpdateDate { get; set; }
        public string MSCRMID { get; set; }
    }
}
