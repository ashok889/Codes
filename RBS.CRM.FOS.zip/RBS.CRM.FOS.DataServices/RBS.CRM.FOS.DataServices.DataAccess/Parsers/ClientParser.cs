﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CRM.DataServices.DataAccess.Entities;

namespace RBS.CRM.FOS.DataServices.DataAccess.Parsers
{
    /// <summary>
    /// For parsing client related data
    /// </summary>
    public class ClientParser : IDataParser<Client>
    {
        private int MSCRMIdOrdinal;
        private int parentMSCRMIdOrdinal;
        private int ultimateParentMSCRMIdOrdinal;
        private int stagingClientIdOrdinal;
        private int clientSdmIdOrdinal;
        private int nameOrdinal;
        private int CISCodeOrdinal;
        private int IsActiveOrdinal;
        private int LevelIdOrdinal;
        private int ClientPriorityTierIDOrdinal;
        private int ClassificationOrdinal;
        private int DomicileOrdinal;
        private int GeographyOrdinal;
        private int SectorOrdinal;
        private int SourceOrdinal;
        private int SourceIdOrdinal;
        private int SubSectorOrdinal;

        //private int Address1_StagingAddressIdOrdinal;
        //private int Address1_AddressLine1Ordinal;
        //private int Address1_AddressLine2Ordinal;
        //private int Address1_AddressLine3Ordinal;
        //private int Address1_CityOrdinal;
        //private int Address1_StateOrdinal;
        //private int Address1_PostCodeOrdinal;
        //private int Address1_CountryOrdinal;
        //private int Address1_AddressTypeIdOrdinal;

        //private int Address2_StagingAddressIdOrdinal;
        //private int Address2_AddressLine1Ordinal;
        //private int Address2_AddressLine2Ordinal;
        //private int Address2_AddressLine3Ordinal;
        //private int Address2_CityOrdinal;
        //private int Address2_StateOrdinal;
        //private int Address2_PostCodeOrdinal;
        //private int Address2_CountryOrdinal;
        //private int Address2_AddressTypeIdOrdinal;
        //private int fundBranchManagerMSCRMIdOrdinal;
        //private int FundBranchManagerNameOrdinal;
        //private int fundBranchTypeOrdinal;
        //private int clientLEIOrdinal;

        /// <summary>
        /// For initializing column name
        /// </summary>
        /// <param name="reader"></param>
        public void InitializeOrdinals(IDataReader reader)
        {
            stagingClientIdOrdinal = reader.GetOrdinal("StagingClientId");
            MSCRMIdOrdinal = reader.GetOrdinal("MSCRMId");
            parentMSCRMIdOrdinal = reader.GetOrdinal("ParentMSCRMId");
            ultimateParentMSCRMIdOrdinal = reader.GetOrdinal("UltimateParentMSCRMId"); // adding ultimate parent field
            LevelIdOrdinal = reader.GetOrdinal("LevelId");
            clientSdmIdOrdinal = reader.GetOrdinal("SdmId");
            nameOrdinal = reader.GetOrdinal("Name");
            CISCodeOrdinal = reader.GetOrdinal("CISCode");
            IsActiveOrdinal = reader.GetOrdinal("IsActive");
            ClientPriorityTierIDOrdinal = reader.GetOrdinal("ClientPriorityTierID");
            ClassificationOrdinal = reader.GetOrdinal("Classification");
            DomicileOrdinal = reader.GetOrdinal("Domicile");
            GeographyOrdinal = reader.GetOrdinal("Geography");
            SectorOrdinal = reader.GetOrdinal("Sector");
            SourceOrdinal = reader.GetOrdinal("Source");
            SourceIdOrdinal = reader.GetOrdinal("SourceId");
            SubSectorOrdinal = reader.GetOrdinal("SubSector");
        }

        /// <summary>
        /// For processing each rows
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public List<Client> ProcessRows(IDataReader reader)
        {
            if (reader == null)
            {
                throw new Exception();
            }

            var clients = new List<Client>();

            while (reader.Read())
            {
                var client = new Client();
                client.StagingClientId = stagingClientIdOrdinal >= 0 ? reader.GetInt32(stagingClientIdOrdinal) : -1;
                client.MSCRMId = MSCRMIdOrdinal > 0 ? GetNullableString(reader, MSCRMIdOrdinal) : string.Empty;
                client.ParentMSCRMId = parentMSCRMIdOrdinal > 0 ? GetNullableString(reader, parentMSCRMIdOrdinal) : string.Empty;
                client.UltimateParentMSCRMId = ultimateParentMSCRMIdOrdinal > 0 ? GetNullableString(reader, ultimateParentMSCRMIdOrdinal) : string.Empty;
                client.Name = nameOrdinal >= 0 ? GetNullableString(reader, nameOrdinal) : string.Empty;
                client.CISCode = CISCodeOrdinal >= 0 ? GetNullableString(reader, CISCodeOrdinal) : string.Empty;
                client.IsActive = IsActiveOrdinal >= 0 ? reader.GetBoolean(IsActiveOrdinal) : false;
                client.ClientPriorityTierID = ClientPriorityTierIDOrdinal >= 0 ? GetNullableInt(reader, ClientPriorityTierIDOrdinal) : -1;
                client.LevelId = LevelIdOrdinal >= 0 ? GetNullableInt(reader, LevelIdOrdinal) : -1;
                client.Source = SourceOrdinal >= 0 ? GetNullableString(reader, SourceOrdinal) : string.Empty;
                client.SourceId = SourceIdOrdinal >= 0 ? GetNullableInt(reader, SourceIdOrdinal) : -1;
                client.SubSector = SubSectorOrdinal >= 0 ? GetNullableString(reader, SubSectorOrdinal) : string.Empty;
                client.Sector = SectorOrdinal >= 0 ? GetNullableString(reader, SectorOrdinal) : string.Empty;
                client.Geography = GeographyOrdinal >= 0 ? GetNullableString(reader, GeographyOrdinal) : string.Empty;
                client.Classification = ClassificationOrdinal >= 0 ? GetNullableString(reader, ClassificationOrdinal) : string.Empty;
                client.Domicile = DomicileOrdinal >= 0 ? GetNullableString(reader, DomicileOrdinal) : string.Empty;

                client.SDMId = clientSdmIdOrdinal >= 0 ? reader.GetInt32(clientSdmIdOrdinal) : -1;
                clients.Add(client);
            }

            return clients;
        }

        /// <summary>
        /// Get a nullable string from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A <see cref="string.Empty"/> object if the column being read is null otherwise the string value.</returns>
        protected static string GetNullableString(IDataReader record, int ordinal)
        {
            if (record.IsDBNull(ordinal))
            {
                return string.Empty;
            }

            return record.GetString(ordinal);
        }

        /// <summary>
        /// Get a nullable int from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from.</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A nullable int.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "Can be null")]
        protected static int GetNullableInt(IDataReader record, int ordinal)
        {
            int i = -1;

            if (!record.IsDBNull(ordinal))
            {
                i = record.GetInt32(ordinal);
            }

            return i;
        }



    }
}
