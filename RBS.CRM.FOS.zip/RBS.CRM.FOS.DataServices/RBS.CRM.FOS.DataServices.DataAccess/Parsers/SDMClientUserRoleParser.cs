﻿using System.Data;
using System;
using System.Collections.Generic;
using CRM.DataServices.DataAccess.Entities;

namespace RBS.CRM.FOS.DataServices.DataAccess.Parsers
{
    public class SDMClientUserRoleParser : IDataParser<SDMClientUserRole>
    {
        private int StagingIdOrdinal;
        private int ClientMSCRMIdOrdinal;
        private int LevelIdOrdinal;
        private int RoleIdOrdinal;
        private int MSCRMIDOrdinal;
        private int UserNameOrdinal;
        private int IsDeletedOrdinal;
        private int EmployeeMSCRMIDOrdinal;

        /// <summary>
        /// For initializing column name
        /// </summary>
        /// <param name="reader"></param>
        public void InitializeOrdinals(IDataReader reader)
        {
            StagingIdOrdinal = reader.GetOrdinal("StagingId");
            ClientMSCRMIdOrdinal = reader.GetOrdinal("ClientMSCRMId");
            LevelIdOrdinal = reader.GetOrdinal("LevelId");
            RoleIdOrdinal = reader.GetOrdinal("RoleId");
            MSCRMIDOrdinal = reader.GetOrdinal("MSCRMID");
            UserNameOrdinal = reader.GetOrdinal("UserName");
            IsDeletedOrdinal = reader.GetOrdinal("IsDeleted");
            EmployeeMSCRMIDOrdinal = reader.GetOrdinal("EmployeeMSCRMID");
        }

        /// <summary>
        /// For processing each rows
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public List<SDMClientUserRole> ProcessRows(IDataReader reader)
        {
            if (reader == null)
            {
                throw new Exception();
            }

            var SDMClientUserRoles = new List<SDMClientUserRole>();

            while (reader.Read())
            {
                var sdmClientUserRole = new SDMClientUserRole();
                sdmClientUserRole.StagingId = StagingIdOrdinal >= 0 ? GetNullableInt(reader, StagingIdOrdinal) : -1;
                sdmClientUserRole.ClientMSCRMId = ClientMSCRMIdOrdinal >= 0 ? GetNullableString(reader, ClientMSCRMIdOrdinal) : string.Empty;
                sdmClientUserRole.LevelId = LevelIdOrdinal >= 0 ? GetNullableInt(reader, LevelIdOrdinal) : -1;
                sdmClientUserRole.RoleId = RoleIdOrdinal >= 0 ? GetNullableString(reader, RoleIdOrdinal) : string.Empty;
                sdmClientUserRole.MSCRMID = MSCRMIDOrdinal > 0 ? GetNullableString(reader, MSCRMIDOrdinal) : string.Empty;
                sdmClientUserRole.UserName = UserNameOrdinal > 0 ? GetNullableString(reader, UserNameOrdinal) : string.Empty;
                sdmClientUserRole.IsDeleted = IsDeletedOrdinal > 0 ? GetNullableBoolean(reader, IsDeletedOrdinal) : false;
                sdmClientUserRole.EmployeeMSCRMID = EmployeeMSCRMIDOrdinal > 0 ? GetNullableString(reader, EmployeeMSCRMIDOrdinal) : string.Empty;
                SDMClientUserRoles.Add(sdmClientUserRole);
            }

            return SDMClientUserRoles;
        }

        /// <summary>
        /// Get a nullable string from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A <see cref="string.Empty"/> object if the column being read is null otherwise the string value.</returns>
        protected static string GetNullableString(IDataReader record, int ordinal)
        {
            if (record.IsDBNull(ordinal))
            {
                return string.Empty;
            }

            return record.GetString(ordinal);
        }

        /// <summary>
        /// Get a nullable int from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from.</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A nullable int.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "Can be null")]
        protected static int GetNullableInt(IDataReader record, int ordinal)
        {
            int i = -1;

            if (!record.IsDBNull(ordinal))
            {
                i = record.GetInt32(ordinal);
            }

            return i;
        }

        protected static bool GetNullableBoolean(IDataReader record, int ordinal)
        {
            if (record.IsDBNull(ordinal))
            {
                return false;
            }

            return record.GetBoolean(ordinal);
        }
    }
}
