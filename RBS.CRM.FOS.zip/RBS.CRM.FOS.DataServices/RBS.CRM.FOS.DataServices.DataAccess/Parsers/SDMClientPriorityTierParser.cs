﻿using System.Data;
using System;
using System.Collections.Generic;
using CRM.DataServices.DataAccess.Entities;

namespace RBS.CRM.FOS.DataServices.DataAccess.Parsers
{
    public class SDMClientPriorityTierParser : IDataParser<SDMClientPriorityTier>
    {
        private int ClientMSCRMIDOrdinal;
        private int PriorityMSCRMIDOrdinal;
        private int StagingIdOrdinal;
        private int IsDeletedOrdinal;
        private int MSCRMIDOrdinal;

        /// <summary>
        /// For initializing column name
        /// </summary>
        /// <param name="reader"></param>
        public void InitializeOrdinals(IDataReader reader)
        {
            ClientMSCRMIDOrdinal = reader.GetOrdinal("ClientMSCRMID");
            PriorityMSCRMIDOrdinal = reader.GetOrdinal("PriorityMSCRMId");
            StagingIdOrdinal = reader.GetOrdinal("StagingId");
            IsDeletedOrdinal = reader.GetOrdinal("IsDeleted");
            MSCRMIDOrdinal = reader.GetOrdinal("MSCRMID");
        }

        /// <summary>
        /// For processing each rows
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public List<SDMClientPriorityTier> ProcessRows(IDataReader reader)
        {
            if (reader == null)
            {
                throw new Exception();
            }

            var sdmClientPriorityTiers = new List<SDMClientPriorityTier>();

            while (reader.Read())
            {
                var sdmClientPriorityTier = new SDMClientPriorityTier();
                sdmClientPriorityTier.ClientMSCRMID = ClientMSCRMIDOrdinal >= 0 ? GetNullableString(reader, ClientMSCRMIDOrdinal) : string.Empty;
                sdmClientPriorityTier.PriorityMSCRMID = PriorityMSCRMIDOrdinal >= 0 ? GetNullableString(reader, PriorityMSCRMIDOrdinal) : string.Empty;
                sdmClientPriorityTier.StagingId = StagingIdOrdinal >= 0 ? GetNullableInt(reader, StagingIdOrdinal) : -1;
                sdmClientPriorityTier.IsDeleted = false;//IsDeletedOrdinal >= 0 && reader.GetBoolean(IsDeletedOrdinal);
                sdmClientPriorityTier.MSCRMID = MSCRMIDOrdinal > 0 ? GetNullableString(reader, MSCRMIDOrdinal) : string.Empty;
                sdmClientPriorityTiers.Add(sdmClientPriorityTier);
            }

            return sdmClientPriorityTiers;
        }

        /// <summary>
        /// Get a nullable string from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A <see cref="string.Empty"/> object if the column being read is null otherwise the string value.</returns>
        protected static string GetNullableString(IDataReader record, int ordinal)
        {
            if (record.IsDBNull(ordinal))
            {
                return string.Empty;
            }

            return record.GetString(ordinal);
        }

        /// <summary>
        /// Get a nullable int from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from.</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A nullable int.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "Can be null")]
        protected static int GetNullableInt(IDataReader record, int ordinal)
        {
            int i = -1;

            if (!record.IsDBNull(ordinal))
            {
                i = record.GetInt32(ordinal);
            }

            return i;
        }

        protected static bool GetNullableBoolean(IDataReader record, int ordinal)
        {
            if (record.IsDBNull(ordinal))
            {
                return false;
            }

            return record.GetBoolean(ordinal);
        }
    }
}
