﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CRM.DataServices.DataAccess.Entities;

namespace RBS.CRM.FOS.DataServices.DataAccess.Parsers
{
    /// <summary>
    /// For parsing Employee related data
    /// </summary>
    public class EmployeeParser : IDataParser<Employee>
    {
        private int StagingIdOrdinal;
        private int EmployeeIdOrdinal;
        private int TitleOrdinal;
        private int FirstNameOrdinal;
        private int LastNameOrdinal;
        private int MiddleNameOrdinal;
        private int EmailAddressOrdinal;
        private int CostCentreCodeOrdinal;
        private int JobTitleOrdinal;
        private int FullNumberOrdinal;
        private int RACFIdOrdinal;
        private int DescriptionOrdinal;
        private int MSCRMIdOrdinal;
        private int EmployeeStatusDescOrdinal;



        /// <summary>
        /// For initializing column name
        /// </summary>
        /// <param name="reader"></param>
        public void InitializeOrdinals(IDataReader reader)
        {
            StagingIdOrdinal = reader.GetOrdinal("RowId");
            EmployeeIdOrdinal = reader.GetOrdinal("EmployeeId");
            TitleOrdinal = reader.GetOrdinal("Title");
            FirstNameOrdinal = reader.GetOrdinal("FirstName");
            LastNameOrdinal = reader.GetOrdinal("LastName");
            MiddleNameOrdinal = reader.GetOrdinal("MiddleName");
            EmailAddressOrdinal = reader.GetOrdinal("EmailAddress");
            CostCentreCodeOrdinal = reader.GetOrdinal("CostCentreCode");
            JobTitleOrdinal = reader.GetOrdinal("JobTitle");
            FullNumberOrdinal = reader.GetOrdinal("FullNumber");
            RACFIdOrdinal = reader.GetOrdinal("RACFId");
            DescriptionOrdinal = reader.GetOrdinal("Description");
            MSCRMIdOrdinal = reader.GetOrdinal("MSCRMID");
            EmployeeStatusDescOrdinal = reader.GetOrdinal("EmployeeStatusDesc");
        }

        /// <summary>
        /// For processing each rows
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public List<Employee> ProcessRows(IDataReader reader)
        {
            if (reader == null)
                throw new Exception("No reader object received");

            List<Employee> Employees = new List<Employee>();
            while (reader.Read())
            {
                Employee emp = new Employee();
                emp.StagingId = StagingIdOrdinal >= 0 ? reader.GetInt32(StagingIdOrdinal) : -1;
                emp.EmployeeId = EmployeeIdOrdinal > 0 ? GetNullableInt(reader, EmployeeIdOrdinal) : -1;
                emp.Title = TitleOrdinal > 0 ? GetNullableString(reader, TitleOrdinal) : string.Empty;
                emp.FirstName = FirstNameOrdinal >= 0 ? GetNullableString(reader, FirstNameOrdinal) : string.Empty;
                emp.LastName = LastNameOrdinal >= 0 ? GetNullableString(reader, LastNameOrdinal) : string.Empty;
                emp.MiddleName = MiddleNameOrdinal >= 0 ? GetNullableString(reader, MiddleNameOrdinal) : string.Empty;
                emp.EmailAddress = EmailAddressOrdinal >= 0 ? GetNullableString(reader, EmailAddressOrdinal) : string.Empty;
                emp.CostCentreCode = CostCentreCodeOrdinal >= 0 ? GetNullableString(reader, CostCentreCodeOrdinal) : string.Empty;
                emp.JobTitle = JobTitleOrdinal >= 0 ? GetNullableString(reader, JobTitleOrdinal) : string.Empty;
                emp.FullNumber = FullNumberOrdinal >= 0 ? GetNullableString(reader, FullNumberOrdinal) : string.Empty;
                emp.RACFId = RACFIdOrdinal >= 0 ? GetNullableString(reader, RACFIdOrdinal) : string.Empty;
                emp.Description = DescriptionOrdinal >= 0 ? GetNullableString(reader, DescriptionOrdinal) : string.Empty;
                emp.MSCRMID = MSCRMIdOrdinal >= 0 ? GetNullableString(reader, MSCRMIdOrdinal) : string.Empty;
                emp.EmployeeStatusDesc = EmployeeStatusDescOrdinal >= 0 ? GetNullableString(reader, EmployeeStatusDescOrdinal) : string.Empty;
                Employees.Add(emp);
            }

            return Employees;
        }

        /// <summary>
        /// Get a nullable string from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A <see cref="string.Empty"/> object if the column being read is null otherwise the string value.</returns>
        protected static string GetNullableString(IDataReader record, int ordinal)
        {
            if (record.IsDBNull(ordinal))
            {
                return string.Empty;
            }

            return record.GetString(ordinal);
        }

        /// <summary>
        /// Get a nullable int from a DataReader.
        /// </summary>
        /// <param name="record">The data record to read from.</param>
        /// <param name="ordinal">The ordinal of the column to read.</param>
        /// <returns>A nullable int.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters", Justification = "Can be null")]
        protected static int GetNullableInt(IDataReader record, int ordinal)
        {
            int i = -1;

            if (!record.IsDBNull(ordinal))
            {
                i = record.GetInt32(ordinal);
            }

            return i;
        }



    }
}
