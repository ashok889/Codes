﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// Database common 
    /// </summary>
    public partial class DataAccessManager : IDataAccessManager
    {
        /// <summary>
        /// Function to log the heart beat of the service
        /// </summary>
        /// <param name="serviceName">name of the service</param>
        /// <param name="coreLastBeat"></param>
        /// <param name="serviceLastBeat"></param>
        public void SendHeartBeat(string serviceName, DateTime? lastHeartBeat)
        {
            try
            {
                SqlParameter[] param = new SqlParameter[3];
                param[0] = new SqlParameter("ServiceName", serviceName);
                param[1] = new SqlParameter("HostName", Environment.MachineName);
                param[2] = new SqlParameter("LastHeartBeat", lastHeartBeat);


                SqlManager sqlManager = new SqlManager();
                sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure,
                                            DataConstants.USPSERVICEHEARTBEATUPDATE, param);
            }
            catch (Exception exception)
            {
                throw new Exception(
                    string.Format(
                        "Could not send the heardbeat for service {0}", serviceName), exception);
            }
        }

        public static void SetResourceLock(string processName, bool releaseFlag)
        {
            try
            {
                var param = new SqlParameter[4];
                param[0] = new SqlParameter("ProcessName", processName);
                param[1] = new SqlParameter("LockStatus", releaseFlag);
                param[2] = new SqlParameter("LockHolder", "DataSyncService");
                param[3] = new SqlParameter("isLocked", false) { Direction = ParameterDirection.Output };

                var sqlManager = new SqlManager();
                sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure,
                                            DataConstants.SETRESOURCELOCK, param);

            }
            catch (Exception exception)
            {
                throw new Exception(
                    string.Format(
                        "Could not set the Resource Lock for service {0}", processName), exception);
            }
        }

    }
}
