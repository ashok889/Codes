﻿using System.Collections.Generic;
using System.Data;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.DataAccess;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    public interface ISDMClientUserRoleReader : IEntityDataReader<SDMClientUserRole>
    {
        List<SDMClientUserRole> GetSDMClientUserRoles(string connectionstring, int batchSize);
        bool SyncMSCRMIDForSDMClientUserRoles(string connectionstring, DataTable tblCRMResponse);
    }
}
