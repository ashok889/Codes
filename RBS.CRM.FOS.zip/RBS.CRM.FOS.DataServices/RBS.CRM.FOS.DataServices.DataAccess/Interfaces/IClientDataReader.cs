﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM.DataServices.DataAccess.Entities;
using System.Data;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// interface for client data reader
    /// </summary>
    public interface IClientDataReader : IEntityDataReader<Client>
    {
        List<Client> GetClients(string connectionstring, int batchSize);
        bool SyncMSCRMIDForClients(string connectionstring, DataTable tblCRMResponse);
    }
}
