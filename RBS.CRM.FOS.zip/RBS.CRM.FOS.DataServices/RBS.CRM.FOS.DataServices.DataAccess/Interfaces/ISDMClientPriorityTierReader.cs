﻿using System.Collections.Generic;
using System.Data;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.DataAccess;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    public interface ISDMClientPriorityTierReader : IEntityDataReader<SDMClientPriorityTier>
    {
        List<SDMClientPriorityTier> GetSDMClientPriorityTiers(string connectionstring, int batchSize);
        bool SyncMSCRMIDForSDMClientPriorityTiers(string connectionstring, DataTable tblCRMResponse);
    }
}
