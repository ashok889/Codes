﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    
    /// <summary>
    /// For parsing data
    /// </summary>
    public interface IDataParser<T>
    {
        void InitializeOrdinals(IDataReader reader);
        List<T> ProcessRows(IDataReader reader);
    }
}
