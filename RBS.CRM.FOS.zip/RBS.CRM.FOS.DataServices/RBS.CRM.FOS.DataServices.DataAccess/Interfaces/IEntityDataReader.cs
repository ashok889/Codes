﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// Interface for enitity data reader
    /// </summary>
    public interface IEntityDataReader<T>
    {
        ISqlManager SqlManager { get; set; }

        IDataParser<T> EntityDataParser { get; set; }
    }
}
