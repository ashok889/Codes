﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    public interface IDataAccessManager
    {
        void SendHeartBeat(string serviceName, DateTime? lastHeartBeat);
    }
}
