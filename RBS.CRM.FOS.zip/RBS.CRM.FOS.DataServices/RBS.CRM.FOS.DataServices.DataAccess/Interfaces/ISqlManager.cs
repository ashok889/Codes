﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// interface for sql manager
    /// </summary>
    public interface ISqlManager
    {
        SqlDataReader ExecuteReader(string connectionString, CommandType commandType, string commandText);

        SqlDataReader ExecuteReader(string connectionString, CommandType commandType, string commandText,
            params SqlParameter[] commandParameters);

        SqlDataReader ExecuteReader(SqlConnection connection, SqlTransaction transaction, CommandType commandType,
            string commandText, SqlParameter[] commandParameters);

        SqlDataReader ExecuteReader(string connectionString, string storedProcName, params object[] parameterValues);

        int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText);

        int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText,
           params SqlParameter[] commandParameters);

        int ExecuteNonQuery(SqlConnection connection, CommandType commandType, string commandText,
            params SqlParameter[] commandParameters);
    }
}
