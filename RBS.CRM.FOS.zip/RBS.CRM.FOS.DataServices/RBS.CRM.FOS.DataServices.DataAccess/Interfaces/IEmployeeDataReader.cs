﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM.DataServices.DataAccess.Entities;
using System.Data;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// interface for Employee data reader
    /// </summary>
    public interface IEmployeeDataReader : IEntityDataReader<Employee>
    {
        List<Employee> GetEmployees(string connectionstring, int batchSize);
        bool SyncMSCRMIDForEmployees(string connectionstring, DataTable tblCRMResponse);
    }
}
