﻿using System.Collections.Generic;
using System.Data;
using CRM.DataServices.DataAccess.Entities;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    public interface IPriorityGroupListTierDataReader : IEntityDataReader<PriorityGroupListTier>
    {
        List<PriorityGroupListTier> GetPriorityGroupListTier(string connectionstring, char priorityCriteria, int batchSize);
        bool SyncMSCRMIDForPriorityGroupListTier(string connectionstring, DataTable tblCRMResponse);
    }
}
