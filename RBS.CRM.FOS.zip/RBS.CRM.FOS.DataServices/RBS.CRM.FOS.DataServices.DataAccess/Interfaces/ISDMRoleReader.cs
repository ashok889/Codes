﻿using System.Collections.Generic;
using System.Data;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.DataAccess;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    public interface ISDMRoleReader : IEntityDataReader<SDMRole>
    {
        List<SDMRole> GetSDMRoles(string connectionstring, int batchSize);
        bool SyncMSCRMIDForSDMRoles(string connectionstring, DataTable tblCRMResponse);
    }
}
