﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.DataAccess.Parsers;
using System.Data;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// Reads Employee related data from staging db
    /// </summary>
    public class EmployeeDataReader : IEmployeeDataReader
    {

        /// <summary>
        /// For getting Employees details
        /// </summary>
        /// <param name="connectionstring"></param>
        /// <returns></returns>
        public List<Employee> GetEmployees(string connectionstring, int batchSize)
        {
            const string spname = "ETL.p_FOS_Employee_Get";

            object[] inputparams = new object[] { batchSize };

            if (SqlManager == null)
                SqlManager = new SqlManager();

            if (EntityDataParser == null)
            {
                EntityDataParser = new EmployeeParser();
            }

            var reader = SqlManager.ExecuteReader(connectionstring, spname, inputparams); //read data from staging db
            EntityDataParser.InitializeOrdinals(reader); //intialize parser
            var Employees = EntityDataParser.ProcessRows(reader); //parse data returned from s.p
            return Employees;
        }

        /// <summary>
        /// Sets MSCRMID for Employees create in Dynamics
        /// </summary>
        /// <param name="connectionstring"></param>
        /// <returns></returns>
        public bool SyncMSCRMIDForEmployees(string connectionstring, DataTable tblCRMResponse)
        {
            const string spname = "ETL.p_UpdateResponse";
            bool result;

            object[] inputparams = new object[] { tblCRMResponse, "FOS_Employee" };

            if (SqlManager == null)
                SqlManager = new SqlManager();

            if (EntityDataParser == null)
            {
                EntityDataParser = new EmployeeParser();
            }

            var reader = SqlManager.ExecuteReader(connectionstring, spname, inputparams); //read data from staging db
            result = reader.HasRows;
            return result;
        }

        public ISqlManager SqlManager
        {
            get;
            set;
        }

        public IDataParser<Employee> EntityDataParser
        {
            get;
            set;
        }

    }
}
