﻿using System.Collections.Generic;
using System.Data;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.DataAccess.Parsers;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    public class PriorityGroupListTierDataReader : IPriorityGroupListTierDataReader
    {
        /// <summary>
        /// For getting clients details
        /// </summary>
        /// <param name="connectionstring"></param>
        /// <returns></returns>
        public List<PriorityGroupListTier> GetPriorityGroupListTier(string connectionstring, char priorityCriteria, int batchSize)
        {
            const string spname = "ETL.p_FOS_PriorityGroupList_Get";

            //Todo: add proper input params..it could be batch size
            object[] inputparams = new object[] { true, false, priorityCriteria, batchSize };

            if (SqlManager == null)
                SqlManager = new SqlManager();

            if (EntityDataParser == null)
            {
                EntityDataParser = new PriorityGroupListTierParser();
            }

            var reader = SqlManager.ExecuteReader(connectionstring, spname, inputparams); //read data from staging db
            EntityDataParser.InitializeOrdinals(reader); //intialize parser
            var priorityGroupListTiers = EntityDataParser.ProcessRows(reader); //parse data returned from s.p
            return priorityGroupListTiers;
        }

        /// <summary>
        /// Sets MSCRMID for Clients create in Dynamics
        /// </summary>
        /// <param name="connectionstring"></param>
        /// <returns></returns>
        public bool SyncMSCRMIDForPriorityGroupListTier(string connectionstring, DataTable tblCRMResponse)
        {
            const string spname = "ETL.p_UpdateResponse";
            bool result = false;

            //Todo: add proper input params..it could be batch size
            object[] inputparams = new object[] { tblCRMResponse, "FOS_PriorityGroupListTier" };

            if (SqlManager == null)
                SqlManager = new SqlManager();

            var reader = SqlManager.ExecuteReader(connectionstring, spname, inputparams); //read data from staging db
            result = true;
            return result;
        }

        public ISqlManager SqlManager
        {
            get;
            set;
        }

        public IDataParser<PriorityGroupListTier> EntityDataParser
        {
            get;
            set;
        }
    }
}
