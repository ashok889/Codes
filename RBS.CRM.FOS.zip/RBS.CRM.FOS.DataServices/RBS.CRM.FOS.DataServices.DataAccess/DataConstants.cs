﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.DataAccess
{
    /// <summary>
    /// Database related constants
    /// </summary>
    public sealed class DataConstants
    {
        public const string STAGINGDBOWNER = "dbo";
        public const string CPLUSETLDBOWNER = "etl";

        private DataConstants() { }

        #region TableNames
        public const string TABLESDMSECTOR = "SDMSector";
        public const string TABLESDMTIER = "SDMPriorityTier";
        public const string TABLESDMLIST = "SDMPriorityList";
        public const string TABLESDMGROUP = "SDMPriorityGroup";
        public const string TABLESDMCLIENTTIER = "SDMClientPriorityTier";
        public const string TABLESDMCLIENT = "SDMClient";
        public const string TABLESDMCLIENTATTRIBUTE = "SDMClientAttribute";
        public const string TABLECONNECTCLIENTADDRESS = "ConnectClientAddress";
        public const string TABLERECORDTYPE = "RecordType";

        // ConnectPlus tables
        public const string CPLUSCLIENTADDRESS = "ClientAddressHolding";

        #endregion

        #region TableColumns
        public const string SERVICENAME = "ServiceName";
        public const string SYNCSTATUS = "SyncStatus";
        public const string ATTRIBUTEID = "AttributeId";
        public const string ATTRIBUTEDESCRIPTION = "AttributeDescription";
        public const string SDMCLIENTID = "SDMClientId";
        public const string RECORDID = "RecordId";
        public const string ENTITYTYPEID = "EntityTypeId";
        public const string ACTIONTYPEID = "ActionTypeID";
        public const string DATA = "Data";
        public const string ADDRESSID = "AddressID";
        public const string ADDRESSTYPE = "AddressType";
        public const string ADDRESSLINE1 = "AddressLine1";
        public const string ADDRESSLINE2 = "AddressLine2";
        public const string ADDRESSLINE3 = "AddressLine3";
        public const string ADDRESSLINE4 = "AddressLine4";
        public const string CITY = "City";
        public const string COUNTRY = "Country";
        public const string POSTCODE = "PostCode";
        public const string SDMCOUNTRYCODE = "SDMCountryCode";

        #region CRM Data Queue Resultset Column Names Start
        public const string QUEUEMESSAGETYPE = "EntityTypeName";
        public const string QUEUEVERSION = "RecordId";
        public const string QUEUEITEMID = "RecordId";
        public const string QUEUEOPERATION = "Action";

        /// <summary>
        /// Priority Group.
        /// </summary>
        public const string DATAQUEUEPRIORITYGROUPPRIORITYGROUPID = "PriorityGroupId";
        public const string DATAQUEUEPRIORITYGROUPPRIORITYGROUPDESCRIPTION = "PriorityGroupDescription";
        public const string DATAQUEUEPRIORITYGROUPSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUEPRIORITYGROUPCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUEPRIORITYGROUPISDELETED = "IsDeleted";

        /// <summary>
        /// Priority List .
        /// </summary>
        public const string DATAQUEUEPRIORITYLISTPRIORITYLISTID = "PriorityListId";
        public const string DATAQUEUEPRIORITYLISTPRIORITYLISTDESCRIPTION = "PriorityListDescription";
        public const string DATAQUEUEPRIORITYLISTPRIORITYGROUPID = "PriorityGroupId";
        public const string DATAQUEUEPRIORITYLISTSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUEPRIORITYLISTCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUEPRIORITYLISTISDELETED = "IsDeleted";

        /// <summary>
        /// Priority Tier.
        /// </summary>
        public const string DATAQUEUEPRIORITYTIERPRIORITYTIERID = "PriorityTierId";
        public const string DATAQUEUEPRIORITYTIERPRIORITYTIERDESCRIPTION = "PriorityTierDescription";
        public const string DATAQUEUEPRIORITYTIERSORTORDER = "SortOrder";
        public const string DATAQUEUEPRIORITYTIERPRIORITYLISTID = "PriorityListId";
        public const string DATAQUEUEPRIORITYTIERSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUEPRIORITYTIERCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUEPRIORITYTIERISDELETED = "IsDeleted";

        /// <summary>
        /// Classification of client sectors.
        /// </summary>
        public const string DATAQUEUECLASSIFICATIONCLASSIFICATIONID = "ClassificationID";
        public const string DATAQUEUECLASSIFICATIONCLASSIFICATIONDESCRIPTION = "ClassificationDescription";
        public const string DATAQUEUECLASSIFICATIONCLASSIFICATIONACTIVESTATUS = "ClassificationActiveStatus";
        public const string DATAQUEUECLASSIFICATIONSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUECLASSIFICATIONCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUECLASSIFICATIONISDELETED = "IsDeleted";

        /// <summary>
        /// Sectors info.
        /// </summary>
        public const string DATAQUEUESECTORSECTORID = "SectorID";
        public const string DATAQUEUESECTORSECTORDESCRIPTION = "SectorDescription";
        public const string DATAQUEUESECTORSECTORACTIVESTATUS = "SectorActiveStatus";
        public const string DATAQUEUESECTORCLASSIFICATIONID = "ClassificationId";
        public const string DATAQUEUESECTORSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUESECTORCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUESECTORISDELETED = "IsDeleted";

        // Sub - sector.
        public const string DATAQUEUESUBSECTORSUBSECTORID = "SubSectorID";
        public const string DATAQUEUESUBSECTORSUBSECTORDESCRIPTION = "SubSectorDescription";
        public const string DATAQUEUESUBSECTORSUBSECTORACTIVESTATUS = "SubSectorActiveStatus";
        public const string DATAQUEUESUBSECTORSECTORID = "SectorId";
        public const string DATAQUEUESUBSECTORSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUESUBSECTORCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUESUBSECTORISDELETED = "IsDeleted";

        /// <summary>
        /// Attribute info.
        /// </summary>
        public const string DATAQUEUEATTRIBUTEATTRIBUTEID = "AttributeId";
        public const string DATAQUEUEATTRIBUTEATTRIBUTEDESCRIPTION = "AttributeDescription";
        public const string DATAQUEUEATTRIBUTEUPDATEDATE = "UpdateDate";

        /// <summary>
        /// Client data.
        /// </summary>
        public const string DATAQUEUECLIENTSDMCLIENTID = "SDMClientId";
        public const string DATAQUEUECLIENTPARENTSDMCLIENTID = "ParentSDMClientId";
        public const string DATAQUEUECLIENTLEVELID = "LevelId";
        public const string DATAQUEUECLIENTCLIENTNAME = "ClientName";
        public const string DATAQUEUECLIENTSUBSECTORID = "SubSectorId";
        public const string DATAQUEUECLIENTCOUNTRYCODE = "CountryCode";
        public const string DATAQUEUECLIENTCISCODE = "CISCode";
        public const string DATAQUEUECLIENTULTIMATECISCODE = "UltimateCISCode";
        public const string DATAQUEUECLIENTPARENTCISCODE = "ParentCISCode";
        public const string DATAQUEUECLIENTRMATTRIBUTE1ID = "RMAttribute1Id";
        public const string DATAQUEUECLIENTISACTIVE = "IsActive";
        public const string DATAQUEUECLIENTISDELETED = "IsDeleted";
        public const string DATAQUEUECLIENTSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUECLIENTCRMUPDATEDATE = "CRMUpdateDate";

        /// <summary>
        /// Client Priority Tier.
        /// </summary>
        public const string DATAQUEUECLIENTPRIORITYTIERIDENTITYID = "IdentityId";
        public const string DATAQUEUECLIENTPRIORITYTIERSDMCLIENTID = "SDMClientId";
        public const string DATAQUEUECLIENTPRIORITYTIERCLIENTPRIORITYTIERID = "ClientPriorityTierId";
        public const string DATAQUEUECLIENTPRIORITYTIERSDMUPDATEDATE = "SDMUpdateDate";
        public const string DATAQUEUECLIENTPRIORITYTIERCRMUPDATEDATE = "CRMUpdateDate";
        public const string DATAQUEUECLIENTPRIORITYTIERISDELETED = "IsDeleted";

        /// <summary>
        /// Client Attribute.
        /// </summary>
        public const string DATAQUEUECLIENTATTRIBUTECLIENTATTRIBUTEID = "ClientAttributeID";
        public const string DATAQUEUECLIENTATTRIBUTEATTRIBUTEID = "AttributeId";
        public const string DATAQUEUECLIENTATTRIBUTESDMCLIENTID = "SDMClientId";
        public const string DATAQUEUECLIENTATTRIBUTEISDELETED = "IsDeleted";
        public const string DATAQUEUECLIENTATTRIBUTEUPDATEDATE = "UpdateDate";

        /// <summary>
        /// Merge Client.
        /// </summary>
        public const string DATAQUEUEMERGECLIENTRECORDID = "RecordId";
        public const string DATAQUEUEMERGECLIENTSDMCLIENTID = "SDMClientId";
        public const string DATAQUEUEMERGECLIENTMERGECLIENTID = "MergeClientId";
        public const string DATAQUEUEMERGECLIENTMERGEDATE = "MergeDate";
        public const string DATAQUEUEMERGECLIENTEVENTDATE = "EventDate";
        public const string DATAQUEUEMERGECLIENTCRMUPDATEDATE = "CRMUpdateDate";

        /// <summary>
        /// Client Address
        /// </summary>
        public const string DATAQUEUECLIENTADDRESSCLIENTADDRESSID = "ClientAddressID";
        public const string DATAQUEUECLIENTADDRESSSDMCLIENTID = "SDMClientId";
        public const string DATAQUEUECLIENTADDRESSADDRESSID = "AddressID";
        public const string DATAQUEUECLIENTADDRESSADDRESSTYPE = "AddressType";
        public const string DATAQUEUECLIENTADDRESSADDRESSLINE1 = "AddressLine1";
        public const string DATAQUEUECLIENTADDRESSADDRESSLINE2 = "AddressLine2";
        public const string DATAQUEUECLIENTADDRESSADDRESSLINE3 = "AddressLine3";
        public const string DATAQUEUECLIENTADDRESSADDRESSLINE4 = "AddressLine4";
        public const string DATAQUEUECLIENTADDRESSCITY = "City";
        public const string DATAQUEUECLIENTADDRESSCOUNTRY = "Country";
        public const string DATAQUEUECLIENTADDRESSPOSTCODE = "PostCode";
        public const string DATAQUEUECLIENTADDRESSSDMCOUNTRYCODE = "SDMCountryCode";
        public const string DATAQUEUECLIENTADDRESSISDELETED = "IsDeleted";
        public const string DATAQUEUECLIENTADDRESSUPDATEDATE = "UpdateDate";
        #endregion

        #endregion

        #region XML Elements
        public const string XMLRECORDS = "Records";
        public const string XMLRECORD = "Record";
        public const string XMLRECORDID = "RecordId";
        public const string XMLISPROCESSED = "IsProcessed";
        public const string XMLISERROR = "IsError";
        #endregion

        #region ServiceNames
        public const string SERVICECLIENTEOD = "ClientEOD";
        public const string SERVICESECTOREOD = "Sector";
        public const string SERVICECLIENTTIER = "ClientTier";
        public const string SERVICECLIENTINTRADAY = "ClientIntraDay";
        public const string SERVICECLIENTATTRIBUTE = "ClientAttribute";
        public const string SERVICECLIENTADDRESS = "ClientAddress";
        #endregion

        #region Stored Procedures
        public const string USPTRUNCATETABLE = "[dbo].[p_TruncateTable]";
        public const string USPGETSERVICESTATUS = "[dbo].[p_GetServiceHoldStatus]";
        public const string USPUPDATESERVICESTATUS = "[dbo].[p_UpdateServiceStatus]";
        public const string USPPROCESSCLIENTINTRADAY = "[dbo].[p_ProcessClientIntraDayMessage]";
        public const string SYNCCLIENTINTRADAYMESSAGE = "[dbo].[p_SyncClientIntraDayMessage]";
        public const string USPGETRECORDTYPEDOWNLOADREQUIREDSTATUS = "[dbo].[p_GetSalesForceRefreshRequiredStatus]";
        public const string USPINSERTMAINTENANCEREQUEST = "[dbo].[p_InsertMaintenanceRequest]";
        public const string USPSERVICEHEARTBEATUPDATE = "[ETL].[p_ServiceHeartBeatUpdate]";
        public const string USPGETRECORDSALESFORCESYNC = "[dbo].[p_GetRecordSalesforceSync]";
        public const string USPUPDATESALESFORCESYNCRECORD = "[dbo].[p_UpdateSalesForceSyncRecord]";
        public const string USPGETRECORDTYPEID = "[dbo].[p_GetRecordTypeId]";
        public const string USPUPSERTSALESFORCEACCOUNT = "[dbo].[p_UpsertSalesForceAccount]";
        public const string INSERTDUMMYTIERFORMERGERECORD = "[dbo].[p_InsertDummyTierForMergeRecord]";

        public const string USPUPSERTCLIENTATTRIBUTES = "[dbo].[p_UpsertAttribute]";
        public const string USPGETCLIENTATTRIBUTES = "[dbo].[p_GetAttribute]";
        public const string USPSYNCENTITY = "[dbo].[p_SyncEntity]";
        public const string USPINSERTCLIENTATTRIBUTES = "[dbo].[p_InsertClientAttribute]";

        public const string USPUPDATECRMDATAQUEUEITEMSTATUS = "[dbo].[p_UpdateCRMDataQueueItemStatus]";
        public const string USPGETNEXTCRMDATAQUEUEITEM = "[dbo].[p_GetNextCRMDataQueueItem]";

        public const string CPLUSSYNCCLIENTADDRESS = "[dbo].[p_SyncClientAddress]";
        public const string SETRESOURCELOCK = "ETL.[p_getResourceLock]";

        #endregion

        #region Flags
        public const string DOWNLOADING = "DownloadStarted";
        public const string DOWNLOADED = "DownloadCompleted";
        public const string DOWNLOADABORTED = "DownloadAborted";
        public const string DOWNLOADERROR = "DownloadError";
        #endregion
    }
}
