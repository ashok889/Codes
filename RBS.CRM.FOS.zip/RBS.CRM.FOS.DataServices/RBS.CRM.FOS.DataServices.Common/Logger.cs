﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NLog;
using RBS.CRM.FOS.DataServices.Common.Exceptions;

namespace RBS.CRM.FOS.DataServices.Common
{
    /// <summary>
    /// Custom logger
    /// </summary>
    public static class Logger
    {
        private static NLog.Logger logger = NLog.LogManager.GetLogger("CRM.DataService");

        /// <summary>
        /// For logging validation errors
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public static void LogError(string message, ValidationException exception)
        {
            if (exception != null)
            {
                GDC.Set("sourceId", exception.SourceId.ToString());
                GDC.Set("ruleId", exception.RuleId.ToString());
                GDC.Set("sourceTypeId", exception.SourceTypeId.ToString());
                GDC.Set("batchId", exception.BatchId.ToString());
                GDC.Set("customMessage", message);
            }

            logger.ErrorException(message + "Exception:" + exception, exception);

        }


        /// <summary>
        /// Logs the exception as an error with a detailed message containing inner exception details.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="exception">The exception.</param>
        public static void LogFatal(string message, SynchServiceException exception, string source = "")
        {
            if (exception != null)
            {
                GDC.Set("categoryId", exception.CategoryId.ToString());
                GDC.Set("entityType", exception.EntityType);
                GDC.Set("extendedData", exception.ExtendedData);
                GDC.Set("customMessage", message + "; ExceptionText:" + exception.Message);
                GDC.Set("exceptionSourceName", source);
                GDC.Set("hostName", Environment.MachineName);
            }
            logger.FatalException(message + "Exception:" + exception, exception);
        }

        /// <summary>
        /// Log the debug detail
        /// </summary>
        /// <param name="message"></param>
        /// <param name="entityType"></param>
        /// <param name="categoryId"></param>
        public static void LogDebug(string message, string entityType = "", int categoryId = 3)
        {
            GDC.Set("entityType", entityType);
            GDC.Set("categoryId", categoryId.ToString());
            GDC.Set("customMessage", message);
            logger.Debug(message + " [Time-" + DateTime.Now + "]");

        }

        /// <summary>
        /// Log the Trace detail
        /// </summary>
        /// <param name="message"></param>
        /// <param name="entityType"></param>
        /// <param name="categoryId"></param>
        public static void LogTrace(string message, string entityType = "", int categoryId = 3)
        {
            GDC.Set("entityType", entityType);
            GDC.Set("categoryId", categoryId.ToString());
            GDC.Set("customMessage", message);
            logger.Trace(message + " [Time-" + DateTime.Now + "]");
        }


        /// <summary>
        /// Log the Info detail
        /// </summary>
        /// <param name="message"></param>
        /// <param name="entityType"></param>
        /// <param name="categoryId"></param>
        public static void LogInfo(string message, string entityType = "", int categoryId = 3)
        {
            GDC.Set("entityType", entityType);
            GDC.Set("categoryId", categoryId.ToString());
            GDC.Set("customMessage", message);
            logger.Info(message + " [Time-" + DateTime.Now + "]");
        }

        /// <summary>
        /// Log the Warning detail
        /// </summary>
        /// <param name="message">Actual message to be logged.</param>
        public static void LogWarn(string message)
        {
            logger.Warn(message + " [Time-" + DateTime.Now + "]");
        }
    }
}
