﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Common.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Class for validation errors
    /// </summary>
    public class ValidationException : Exception
    {
        /// <summary>
        /// SourceId
        /// </summary>
        public int SourceId
        { get; set; }

        /// <summary>
        /// RuleId
        /// </summary>
        public int RuleId
        { get; set; }

        /// <summary>
        /// SourceTypeId
        /// </summary>
        public int SourceTypeId
        { get; set; }

        /// <summary>
        /// BatchId
        /// </summary>
        public int BatchId
        { get; set; }

        /// <summary>
        /// Error Message
        /// </summary>
        public string ErrorMessage
        { get; set; }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ValidationException()
        {

        }

        /// <summary>
        /// Exception Constructor
        /// </summary>
        /// <param name="message"></param>
        public ValidationException(string message)
        {
            this.ErrorMessage = message;
        }
    }
}
