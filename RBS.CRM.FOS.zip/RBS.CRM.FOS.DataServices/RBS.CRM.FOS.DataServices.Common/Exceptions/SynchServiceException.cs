﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Common.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Runtime.Serialization;

    /// <summary>
    /// SynchServiceException
    /// </summary>
    public class SynchServiceException : Exception
    {
        #region properties
        /// <summary>
        /// EntityType
        /// </summary>
        public string EntityType { get; set; }

        /// <summary>
        /// ExtendedData
        /// </summary>
        public string ExtendedData { get; set; }

        /// <summary>
        /// CategoryId
        /// </summary>
        public int CategoryId { get; set; }

        #endregion properties
        /// <summary>
        /// Initializes a new instance of the <see cref="SynchServiceException"/> class.
        /// </summary>
        public SynchServiceException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SynchServiceException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public SynchServiceException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SynchServiceException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="innerException">The inner exception.</param>
        public SynchServiceException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SynchServiceException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="payload">The payload.</param>
        /// <param name="innerException">The inner exception.</param>
        public SynchServiceException(string message, object payload, Exception innerException)
            : base(message, innerException)
        {
            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SynchServiceException"/> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.ArgumentNullException">
        /// The <paramref name="info"/> parameter is null.
        /// </exception>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">
        /// The class name is null or <see cref="P:System.Exception.HResult"/> is zero (0).
        /// </exception>
        protected SynchServiceException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }



    }
}
