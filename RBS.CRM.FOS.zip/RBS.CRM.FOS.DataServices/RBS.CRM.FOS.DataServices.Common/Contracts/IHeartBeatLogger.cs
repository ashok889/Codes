﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Common.Contracts
{
    /// <summary>
    /// Custom logger
    /// </summary>
    public interface IHeartBeatLogger
    {
        void LogHeartBeat(string serviceName, DateTime? lastHeartBeat);
    }
}
