﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RBS.CRM.FOS.DataServices.Core.Polling;
using RBS.CRM.FOS.DataServices.Common.Contracts;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Resources;
using RBS.CRM.FOS.DataServices.Core.Configuration;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using System.Configuration;
using System.Globalization;

namespace RBS.CRM.FOS.DataServices.Core.Messaging
{
    /// <summary>
    /// Service for publishing messages from a message source.
    /// </summary>
    public class MessagePollingService : IMessagePollingService
    {
        #region Fields

        /// <summary>
        /// The source from which to pull messages for publishing.
        /// </summary>
        private readonly IEnumerable<IMessageQueueReader> messageSources;

        /// <summary>
        /// The name of the service
        /// </summary>
        private readonly string name;

        /// <summary>
        /// The poller used to control the message processing frequency
        /// </summary>
        private Poller poller;

        /// <summary>
        /// THe number of messages to process in a batch.
        /// </summary>
        private int messageProcessingBatchSize = 2;

        /// <summary>
        /// Message dequeueing flag.
        /// </summary>
        private bool isDequeueing = false;

        /// <summary>
        /// Reads the service specific configuration
        /// </summary>
        private MessagePollingServiceElement serviceConfiguration = null;
        /// <summary>
        /// Specifies if the eod servcie should execute the core logic when it is started
        /// </summary>
        private bool eodRunAtServiceStart = false;

        /// <summary>
        /// Specifies the last day when
        /// </summary>
        private DateTime lastEodExecutedDay;
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="MessagePollingService"/> class.
        /// </summary>
        /// <param name="name">The name of the service, the name is used to load configuration information from the application configuration file.</param>
        /// <param name="messageQueueReaders">The message queue reader.</param>
        public MessagePollingService(string name, IEnumerable<IMessageQueueReader> messageQueueReaders, IHeartBeatLogger hbLogger)
        {
            this.messageSources = messageQueueReaders;
            this.name = name;
            this.HeartBeatLogger = hbLogger;
            this.Configure();
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is enabled.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is enabled; otherwise, <c>false</c>.
        /// </value>
        public IHeartBeatLogger HeartBeatLogger
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is enabled.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsEnabled
        {
            get { return this.poller.IsEnabled; }
            set { this.poller.IsEnabled = value; }
        }

        /// <summary>
        /// Gets the name of the service.
        /// </summary>
        /// <value>The name of the service.</value>
        public string Name
        {
            get
            {
                return this.name;
            }
        }

        /// <summary>
        /// Starts the service.
        /// </summary>
        public void Start()
        {
            Logger.LogTrace(string.Format("{0} message polling service started", name));
            this.IsEnabled = true;
        }

        /// <summary>
        /// Stops the service.
        /// </summary>
        public void Stop()
        {
            this.IsEnabled = false;
            Logger.LogTrace(string.Format("{0} message polling service stoped", name));
        }

        /// <summary>
        /// Stops and waits for activity to complete.
        /// </summary>
        public void StopWait()
        {
            this.poller.StopWait();
        }

        /// <summary>
        /// Logs the process message exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        private static void LogProcessNextMessageException(Exception exception)
        {
            var message = LoggerMessages.ProcessNextMessageError;

            var messageProcessingException = exception as MessageProcessingException;
            if (messageProcessingException != null && messageProcessingException.Payload != null)
            {
                message += string.Format("\r\nMessage={0}", messageProcessingException.Payload);
            }

            Logger.LogFatal(message, messageProcessingException);
        }

        /// <summary>
        /// Called when the poller polls.
        /// </summary>
        /// <returns>The <see cref="PollResult"/> of the poll operation.</returns>
        public PollResult OnPoll()
        {
            try
            {
                if (serviceConfiguration.Active)
                {
                    if (!serviceConfiguration.EodOnly)
                    {
                        return OnPollExecutedFunction();
                    }
                    else
                    {
                        if (eodRunAtServiceStart)
                        {
                            eodRunAtServiceStart = false;
                            return OnPollExecutedFunction();
                        }
                        else
                        {
                            if (IsValidDateTimeForEODExecution())
                            {
                                lastEodExecutedDay = DateTime.Now;
                                return OnPollExecutedFunction();
                            }
                        }
                    }
                }
                return PollResult.Active;
            }
            catch (Exception e)
            {
                Logger.LogFatal(LoggerMessages.ProcessNextMessageBatchError + " " + e.Message, e as SynchServiceException, this.Name);
                return PollResult.Error;
            }
        }
        private PollResult OnPollExecutedFunction()
        {
            // start
            Logger.LogDebug(LoggerMessages.ProcessNextMessageBatchStarted);
            HeartBeatLogger.LogHeartBeat(Name, DateTime.UtcNow);
            var messageCount = this.ProcessNextMessageBatch();

            // complete
            Logger.LogDebug(string.Format(LoggerMessages.ProcessNextMessageBatchCompleted, messageCount));
            return messageCount > 0 ? PollResult.Active : PollResult.Idle;
        }

        private bool IsValidDateTimeForEODExecution()
        {
            string[] eodExecutionDays = serviceConfiguration.EodRunOnDays.Split(",".ToCharArray());
            bool validDay = false;
            
            if (lastEodExecutedDay.Date < DateTime.Now.Date)
            {
                for (int i = 0; i < eodExecutionDays.Length; i++)
                {
                    if (eodExecutionDays[i].ToUpper(CultureInfo.InvariantCulture) == DateTime.Now.DayOfWeek.ToString().ToUpper(CultureInfo.InvariantCulture))
                    {
                        validDay = true;
                        break;
                    }
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// Processes the next batch of messages.
        /// </summary>
        /// <returns>The number of messages processed.</returns>
        private int ProcessNextMessageBatch()
        {
            var numberOfMessagesProcessed = 0;

            while ((numberOfMessagesProcessed < this.messageProcessingBatchSize) && this.ProcessNextMessage())
            {
                numberOfMessagesProcessed++;
            }

            return numberOfMessagesProcessed;
        }

        /// <summary>
        /// Processes the next message.
        /// </summary>
        /// <returns><c>true</c> if a message was available to be processed; otherwise <c>false</c>.</returns>
        private bool ProcessNextMessage()
        {
            Logger.LogDebug(LoggerMessages.ProcessNextMessageStarted);
            try
            {
                bool result;

                result = this.ProcessNextMessageCore();

                Logger.LogDebug(LoggerMessages.ProcessNextMessageComplete);
                return result;
            }
            catch (Exception e)
            {
                Logger.LogFatal(e.Message, new SynchServiceException(e.Message, e), this.name);
                LogProcessNextMessageException(e);
                throw;
            }
        }

        /// <summary>
        /// Core logic for processing a messages.
        /// </summary>
        /// <returns><c>true</c> if a message was available to be processed; otherwise <c>false</c>.</returns>
        private bool ProcessNextMessageCore()
        {
            var messageFound = false;
            foreach (var messageSource in this.messageSources)
            {
                var message = this.GetNextMessage(messageSource);

                if (message == null)
                {
                    continue;
                }

                try
                {
                    messageSource.PublishMessage(message);
                }
                catch (Exception e)
                {
                    Logger.LogFatal(e.Message, new SynchServiceException(e.Message, e), this.name);
                    throw new MessageProcessingException(ExceptionMessages.ErrorPublishingMessage + " " + e.Message, message, e);
                }

                messageFound = true;
            }

            return messageFound;
        }

        /// <summary>
        /// Dequeues the next message to be published.
        /// </summary>
        /// <param name="queueReader">The queue reader.</param>
        /// <returns>The message.</returns>
        private object GetNextMessage(IMessageQueueReader queueReader)
        {
            try
            {
                //if already de-queueing the message, simply ignore the next call..
                if (isDequeueing)
                {
                    return null;
                }

                //Set the isDeQueueing flag on
                isDequeueing = true;
                object result = queueReader.Dequeue(this.messageProcessingBatchSize);

                //Set the isDeQueueing flag off
                isDequeueing = false;
                return result;
            }
            catch (Exception e)
            {
                isDequeueing = false;
                string errorMessage = string.Format("{1} :=> {0} ", ExceptionMessages.ErrorDequeingMessage + " " + e.Message, name);
                throw new MessageProcessingException(errorMessage, e);
            }
        }

        /// <summary>
        /// Publishes the message.
        /// </summary>
        /// <param name="messageHandler">The message handler.</param>
        /// <param name="message">The message.</param>
        private void PublishMessage(IMessageHandler messageHandler, object message)
        {
            try
            {
                messageHandler.Handle(message);
            }
            catch (Exception e)
            {
                throw new MessageProcessingException(ExceptionMessages.ErrorPublishingMessage + " " + e.Message, message, e);
            }
        }

        /// <summary>
        /// Reads the configuration.
        /// </summary>
        private void Configure()
        {
            // get the service configuration
            serviceConfiguration = this.GetServiceConfiguration();
            eodRunAtServiceStart = serviceConfiguration.EodRunAtServiceStart;

            this.poller = this.CreatePoller(serviceConfiguration);

            if (serviceConfiguration != null)
            {
                this.messageProcessingBatchSize = serviceConfiguration.MessageBatchSize;
            }
            else
            {
                this.messageProcessingBatchSize = 1;
            }
        }

        /// <summary>
        /// Creates the <see cref="Poller"/> for the service.
        /// </summary>
        /// <param name="serviceConfiguration">The service configuration.</param>
        /// <returns>The <see cref="Poller"/> for the service.</returns>
        private Poller CreatePoller(MessagePollingServiceElement serviceConfiguration)
        {
            var pollerConfiguration = this.GetPollerConfiguration(serviceConfiguration);
            return new Poller(pollerConfiguration, this.OnPoll);
        }

        /// <summary>
        /// Gets the <see cref="PollerConfiguration"/> for the service.
        /// </summary>
        /// <param name="serviceElement">The service element.</param>
        /// <returns>The <see cref="PollerConfiguration"/> for the service.</returns>
        private PollerConfiguration GetPollerConfiguration(MessagePollingServiceElement serviceElement)
        {
            var pollerElement = serviceElement != null ? serviceElement.Poller : null;
            if (pollerElement == null)
            {
                return new PollerConfiguration();
            }

            return new PollerConfiguration
            {
                ActiveInterval = pollerElement.ActiveInterval,
                IdleInterval = pollerElement.IdleInterval,
                ErrorIntervalMaximum = pollerElement.ErrorIntervalMaximum,
                ErrorIntervalGrowthFactor = pollerElement.ErrorIntervalGrowthFactor
            };
        }

        /// <summary>
        /// Gets the <see cref="MessagePollingServiceElement"/> containing the configuration for the service.
        /// </summary>
        /// <returns>The <see cref="MessagePollingServiceElement"/> for the service.</returns>
        private MessagePollingServiceElement GetServiceConfiguration()
        {
            var section = (MessagePollingSection)ConfigurationManager.GetSection("messagePolling");
            if (section != null)
            {
                return section.Services[this.Name];
            }

            return null;
        }
    }
}
