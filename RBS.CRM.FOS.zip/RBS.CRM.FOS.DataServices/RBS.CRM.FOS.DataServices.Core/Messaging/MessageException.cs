﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Core.Messaging
{
    using System;
    using System.Runtime.Serialization;
    using RBS.CRM.FOS.DataServices.Common.Exceptions;

    /// <summary>
    /// Represents an exception related to a message.
    /// </summary>
    public class MessageProcessingException : SynchServiceException
    {
        #region Fields

        /// <summary>
        /// Backing field for the <see cref="Payload"/> property.
        /// </summary>
        private readonly object payload;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageProcessingException"/> class.
        /// </summary>
        public MessageProcessingException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageProcessingException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public MessageProcessingException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageProcessingException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="innerException">The inner exception.</param>
        public MessageProcessingException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageProcessingException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="payload">The payload.</param>
        /// <param name="innerException">The inner exception.</param>
        public MessageProcessingException(string message, object payload, Exception innerException)
            : base(message, innerException)
        {
            this.payload = payload;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageProcessingException"/> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.ArgumentNullException">
        /// The <paramref name="info"/> parameter is null.
        /// </exception>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">
        /// The class name is null or <see cref="P:System.Exception.HResult"/> is zero (0).
        /// </exception>
        protected MessageProcessingException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        /// <summary>
        /// Gets the message payload.
        /// </summary>
        /// <value>The message payload.</value>
        public object Payload
        {
            get { return this.payload; }
        }
    }
}
