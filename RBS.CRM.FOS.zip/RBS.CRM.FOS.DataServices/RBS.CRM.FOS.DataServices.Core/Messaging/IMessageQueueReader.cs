﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Core.Messaging
{
    /// <summary>
    /// Represents a source of messages
    /// </summary>
    public interface IMessageQueueReader
    {
        /// <summary>
        /// Dequeues a message from the queue.
        /// </summary>
        /// <returns>
        /// The dequeued message; or a null reference if no message was available.
        /// </returns>
        object Dequeue(int messageProcessingBatchSize);

        /// <summary>
        /// Registers the subscriber.
        /// </summary>
        /// <param name="handler">The handler.</param>
        void RegisterSubscriber(IMessageHandler handler);

        /// <summary>
        /// Publishes the message.
        /// </summary>
        /// <param name="message">The message.</param>
        void PublishMessage(object message);
    }
}
