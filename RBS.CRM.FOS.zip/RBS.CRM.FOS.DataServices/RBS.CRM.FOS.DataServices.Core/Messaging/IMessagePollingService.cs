﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Core.Messaging
{
    /// <summary>
    /// Interface for MessagePollingService
    /// </summary>
    public interface IMessagePollingService
    {
        void Start();
    }
}
