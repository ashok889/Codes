﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Core.Polling
{
    /// <summary>
    /// Represents the result of a poll.
    /// </summary>
    public enum PollResult
    {
        /// <summary>
        /// Indicates that the polling method has performed some work, i.e. the systm is active.
        /// </summary>
        Active,

        /// <summary>
        /// Indicates there was no work for the polling method to perform, i.e. the system is idle.
        /// </summary>
        Idle,

        /// <summary>
        /// Indicates that an error occured within the polling method.
        /// </summary>
        Error,
    }
}
