﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Core.Polling
{
    /// <summary>
    /// The delegate type called by the <see cref="Poller"/> class when polling.
    /// </summary>
    /// <returns>
    /// The result of the polling operation.
    /// </returns>
    public delegate PollResult PollMethod();
}
