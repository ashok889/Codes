﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Timers;
using Timer = System.Timers.Timer;

namespace RBS.CRM.FOS.DataServices.Core.Polling
{
    /// <summary>
    /// Polls a method.
    /// </summary>
    public class Poller : IDisposable
    {
        #region Fields

        /// <summary>
        /// The configuration.
        /// </summary>
        private readonly PollerConfiguration configuration;

        /// <summary>
        /// The poll method.
        /// </summary>
        private readonly PollMethod pollMethod;

        /// <summary>
        /// Object used to synchronize
        /// </summary>
        private readonly object synchronizationObject = new object();

        /// <summary>
        /// Indicates whether the poller is in call
        /// </summary>
        private readonly ManualResetEvent pollerInCall = new ManualResetEvent(true);

        /// <summary>
        /// Tracks whether the instance has been disposed.
        /// </summary>
        private bool isDisposed;

        /// <summary>
        /// The timer.
        /// </summary>
        private Timer timer;

        /// <summary>
        /// The is enabled.
        /// </summary>
        private volatile bool isEnabled;

        private readonly object lockobject = new object();

        #endregion

        #region public properties


        /// <summary>
        /// The timer.
        /// </summary>
        public Timer Timer
        {
            get { return this.timer; }

        }

        /// <summary>
        /// The poll method.
        /// </summary>
        public PollMethod PollMethod
        {
            get { return this.pollMethod; }
        }

        /// <summary>
        /// ThreadId that the poller is associated with.
        /// </summary>
        private int ThreadId { get; set; }

        /// <summary>
        /// The poller configuration.
        /// </summary>
        public PollerConfiguration Configuration
        {
            get { return this.configuration; }

        }

        #endregion


        /// <summary>
        /// Initializes a new instance of the <see cref="Poller"/> class.
        /// </summary>
        /// <param name="pollMethod">
        /// The poll method.
        /// </param>
        public Poller(PollMethod pollMethod)
            : this(new PollerConfiguration(), pollMethod)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Poller"/> class.
        /// </summary>
        /// <param name="configuration">
        /// The configuration.
        /// </param>
        /// <param name="pollMethod">
        /// The poll method.
        /// </param>
        public Poller(PollerConfiguration configuration, PollMethod pollMethod)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException("configuration");
            }

            if (pollMethod == null)
            {
                throw new ArgumentNullException("pollMethod");
            }

            this.configuration = configuration;
            this.pollMethod = pollMethod;
            this.ThreadId = Thread.CurrentThread.ManagedThreadId;
            this.CurrentPollingInterval = configuration.ActiveInterval.TotalMilliseconds;
        }

        /// <summary>
        /// Raised when <see cref="IsEnabled"/> is changed.
        /// </summary>
        public event EventHandler IsEnabledChanged;

        /// <summary>
        /// Gets or sets a value indicating whether the poller is enabled.
        /// </summary>
        /// <value><c>true</c> if this instance is enabled; otherwise, <c>false</c>. </value>
        public bool IsEnabled
        {
            get
            {
                return this.isEnabled;
            }

            set
            {
                this.ThrowIfDisposed();
                this.Synchronize(() => this.UpdateIsEnabled(value));
            }
        }

        /// <summary>
        /// Gets or sets the current polling interval.
        /// </summary>
        /// <value>The current interval.</value>
        /// <remarks>
        /// Important: The setter is protected as it should only by modified by the poller when 
        /// throttling.
        /// </remarks>
        public double CurrentPollingInterval
        {
            get;
            protected set;
        }

        #region IDisposable Members

        /// <summary>
        /// The dispose.
        /// </summary>
        public void Dispose()
        {
            if (!this.isDisposed)
            {
                // stop
                this.Stop();

                // set disposed
                this.isDisposed = true;
            }
        }

        #endregion

        /// <summary>
        /// Starts polling.
        /// </summary>
        public void Start()
        {
            this.IsEnabled = true;
        }

        /// <summary>
        /// Stops polling.
        /// </summary>
        public void Stop()
        {
            this.IsEnabled = false;
        }

        /// <summary>
        /// Stops and waits until the timer has finished.
        /// </summary>
        public void StopWait()
        {
            this.IsEnabled = false;

            this.pollerInCall.WaitOne();
        }

        /// <summary>
        /// Called when is enabled changed.
        /// </summary>
        protected virtual void OnIsEnabledChanged()
        {
            if (this.IsEnabledChanged != null)
            {
                this.IsEnabledChanged(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// Called when the poller polls.
        /// </summary>
        /// <param name="state">An object used to track state.</param>
        /// <remarks>
        /// The state object is used to ensure that the polling method does not manipulate 
        /// the internal state when the poller has been reset (Stopped/Started).
        /// </remarks>
        protected void Poll(object state)
        {
            // invoke poll method
            var pollResult = this.InvokePollMethod();

            // get updated interval
            var interval = this.GetUpdatedPollingIntervalFromResult(pollResult);

            // apply interval (if the poller is still enabled and the state is valid)
            this.Synchronize(
                () =>
                {
                    if (this.IsEnabled && this.IsPollingStateValid(state))
                    {
                        this.CurrentPollingInterval = interval;

                        // update timer seperately to ensure we are working with the correct instance
                        this.timer.Interval = interval;
                    }
                });
        }

        /// <summary>
        /// Throws an <see cref="ObjectDisposedException"/> if the poller has been disposed.
        /// </summary>
        /// <exception cref="ObjectDisposedException">Thrown if the poller has been disposed.</exception>
        protected void ThrowIfDisposed()
        {
            if (this.isDisposed)
            {
                throw new ObjectDisposedException(GetType().FullName);
            }
        }

        /// <summary>
        /// Updates the is enabled.
        /// create and start timer
        /// </summary>
        /// <param name="value">if set to <c>true</c> [value].</param>
        private void UpdateIsEnabled(bool value)
        {
            if (this.isEnabled != value)
            {
                this.isEnabled = value;

                // reset the polling interval
                this.CurrentPollingInterval = this.configuration.ActiveInterval.TotalMilliseconds;

                // dispose timer?..if timer is disabled then distroy timer
                if (!this.IsEnabled)
                {
                    this.DisposeTimer();
                }
                else
                {
                    // create timer?
                    if (this.IsEnabled)
                    {
                        this.CreateAndStartTimer();
                    }
                }

                // notify
                this.OnIsEnabledChanged();
            }
        }

        /// <summary>
        /// Creates the timer used to managing polling.
        /// </summary>
        private void CreateAndStartTimer()
        {
            if (this.timer != null)
            {
                throw new InvalidOperationException("Timer has already been created.");
            }

            this.timer = new Timer(this.CurrentPollingInterval) { AutoReset = false };

            this.timer.Elapsed += this.OnTimerElapsed;
            this.timer.Start();
        }

        /// <summary>
        /// Disposes of the current timer being used to manage polling.
        /// </summary>
        private void DisposeTimer()
        {
            if (this.timer != null)
            {
                this.timer.Elapsed -= this.OnTimerElapsed;
                this.timer.Dispose();
                this.timer = null;
            }
        }

        /// <summary>
        /// Handles the poll result.
        /// </summary>
        /// <param name="pollResult">The poll result.</param>
        /// <returns>The new polling interval to use.</returns>
        private double GetUpdatedPollingIntervalFromResult(PollResult pollResult)
        {
            switch (pollResult)
            {
                case PollResult.Active:
                    return this.configuration.ActiveInterval.TotalMilliseconds;
                case PollResult.Idle:
                    return this.configuration.IdleInterval.TotalMilliseconds;
                case PollResult.Error:
                    return this.GetIntervalAfterApplyingErrorGrowthFactor();
                default:
                    throw new ArgumentOutOfRangeException("pollResult", pollResult, "The PollMethod must return a valid PollResult value.");
            }
        }

        /// <summary>
        /// Applies the error growth factory.
        /// </summary>
        /// <returns>
        /// The new interval after applying the error growth factor.
        /// </returns>
        private double GetIntervalAfterApplyingErrorGrowthFactor()
        {
            if (this.CurrentPollingInterval >= this.configuration.ErrorIntervalMaximum.TotalMilliseconds)
            {
                return this.configuration.ErrorIntervalMaximum.TotalMilliseconds;
            }

            var result = this.CurrentPollingInterval + (this.CurrentPollingInterval * this.configuration.ErrorIntervalGrowthFactor);
            if (double.IsNaN(result) || double.IsPositiveInfinity(result) || result > this.configuration.ErrorIntervalMaximum.TotalMilliseconds)
            {
                return this.configuration.ErrorIntervalMaximum.TotalMilliseconds;
            }

            return result;
        }

        /// <summary>
        /// Determines whether the specified polling state is valid.
        /// </summary>
        /// <param name="state">The state.</param>
        /// <returns>
        /// <c>true</c> if the polling state is valid; otherwise, <c>false</c>.
        /// </returns>
        private bool IsPollingStateValid(object state)
        {
            return this.timer != null && this.timer == state;
        }

        /// <summary>
        /// Invokes the poll method.
        /// </summary>
        /// <returns>
        /// The result of the poll method invocation.
        /// </returns>
        private PollResult InvokePollMethod()
        {
            try
            {
                lock (lockobject)
                {
                    return this.pollMethod();
                }
            }
            catch (Exception)
            {
                return PollResult.Error;
            }
        }

        /// <summary>
        /// Called when <see cref="Timer">timer</see> has elapsed.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The <see cref="System.Timers.ElapsedEventArgs"/> instance containing the event data.
        /// </param>
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            // check IsEnabled (we do not synchronize access here as we do not want to lock during the poll operation as it may be long running)
            if (this.IsEnabled)
            {
                try
                {
                    this.pollerInCall.Reset();
                    // get the poll result
                    this.Poll(sender);
                }
                finally
                {
                    // start the timer
                    this.Synchronize(this.ResumePolling);
                    this.pollerInCall.Set();
                }
            }
        }

        /// <summary>
        /// Resumes polling if the poller is enabled.
        /// </summary>
        private void ResumePolling()
        {
            if (this.IsEnabled)
            {
                this.timer.Start();
            }
        }

        /// <summary>
        /// Synchronizes the specified action.
        /// </summary>
        /// <param name="action">The action.</param>
        private void Synchronize(Action action)
        {
            lock (this.synchronizationObject)
            {
                action();
            }
        }
    }
}
