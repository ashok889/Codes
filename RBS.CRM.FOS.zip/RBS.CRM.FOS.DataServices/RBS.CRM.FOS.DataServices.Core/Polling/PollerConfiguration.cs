﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RBS.CRM.FOS.DataServices.Core.Polling
{
    /// <summary>
    /// Represents configuration information for the poller class
    /// </summary>
    public class PollerConfiguration
    {
        #region Fields

        /// <summary>
        /// Backing field for <see cref="ErrorIntervalGrowthFactor"/>
        /// </summary>
        private double errorIntervalGrowthFactor;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="PollerConfiguration"/> class.
        /// </summary>
        public PollerConfiguration()
        {
            this.ActiveInterval = TimeSpan.FromMilliseconds(1000);
            this.IdleInterval = TimeSpan.FromMilliseconds(5000);
            this.ErrorIntervalMaximum = TimeSpan.FromMinutes(100);
            this.ErrorIntervalGrowthFactor = 0.0;
        }

        /// <summary>
        /// Gets or sets the active interval.
        /// </summary>
        /// <value>The active interval.</value>
        /// <remarks>The default value is 100 milliseconds.</remarks>
        public TimeSpan ActiveInterval { get; set; }

        /// <summary>
        /// Gets or sets the idle interval.
        /// </summary>
        /// <value>The idle interval.</value>
        /// <remarks>The default value is 500 milliseconds.</remarks>
        public TimeSpan IdleInterval { get; set; }

        /// <summary>
        /// Gets or sets the maximum wait interval that should be used when expanding due to errors.
        /// </summary>
        /// <value>The error interval maximum.</value>
        /// <remarks>The default value is 10 minutes.</remarks>
        public TimeSpan ErrorIntervalMaximum { get; set; }

        /// <summary>
        /// Gets or sets the growth as a percentage between 0.0 and 1.0 that should be applied to the current interval when an error occurs.
        /// </summary>
        /// <value>The error interval growth factor.</value>
        public double ErrorIntervalGrowthFactor
        {
            get
            {
                return this.errorIntervalGrowthFactor;
            }

            set
            {
                if (value < 0.0)
                {
                    throw new ArgumentOutOfRangeException("value", value, "Value must be greater than 0.0.");
                }

                this.errorIntervalGrowthFactor = value;
            }
        }
    }
}
