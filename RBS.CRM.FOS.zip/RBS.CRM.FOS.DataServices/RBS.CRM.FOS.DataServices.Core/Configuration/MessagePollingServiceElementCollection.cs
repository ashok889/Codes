﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace RBS.CRM.FOS.DataServices.Core.Configuration
{
    /// <summary>
    /// Configuration element collection for <see cref="MessagePollingServiceElement "/> types.
    /// </summary>
    public class MessagePollingServiceElementCollection : ConfigurationElementCollection
    {
        /// <summary>
        /// Gets the type of the <see cref="T:System.Configuration.ConfigurationElementCollection"/>.
        /// </summary>
        /// <value></value>
        /// <returns>
        /// The <see cref="T:System.Configuration.ConfigurationElementCollectionType"/> of this collection.
        /// </returns>
        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.AddRemoveClearMap;
            }
        }

        /// <summary>
        /// Gets or sets the name of the <see cref="T:System.Configuration.ConfigurationElement"/> to associate with the add operation in the <see cref="T:System.Configuration.ConfigurationElementCollection"/> when overridden in a derived class.
        /// </summary>
        /// <value></value>
        /// <returns>The name of the element.</returns>
        /// <exception cref="T:System.ArgumentException">
        /// The selected value starts with the reserved prefix "config" or "lock".
        /// </exception>
        public new string AddElementName
        {
            get
            {
                return base.AddElementName;
            }

            set
            {
                base.AddElementName = value;
            }
        }

        /// <summary>
        /// Gets or sets the name for the <see cref="T:System.Configuration.ConfigurationElement"/> to associate with the clear operation in the <see cref="T:System.Configuration.ConfigurationElementCollection"/> when overridden in a derived class.
        /// </summary>
        /// <value></value>
        /// <returns>
        /// The name of the element.
        /// </returns>
        /// <exception cref="T:System.ArgumentException">
        /// The selected value starts with the reserved prefix "config" or "lock".
        /// </exception>
        public new string ClearElementName
        {
            get
            {
                return base.ClearElementName;
            }

            set
            {
                base.ClearElementName = value;
            }
        }

        /// <summary>
        /// Gets the name of the <see cref="T:System.Configuration.ConfigurationElement"/> to associate with the remove operation in the <see cref="T:System.Configuration.ConfigurationElementCollection"/> when overridden in a derived class.
        /// </summary>
        /// <value></value>
        /// <returns>
        /// The name of the element.
        /// </returns>
        /// <exception cref="T:System.ArgumentException">
        /// The selected value starts with the reserved prefix "config" or "lock".
        /// </exception>
        public new string RemoveElementName
        {
            get
            {
                return base.RemoveElementName;
            }
        }

        /// <summary>
        /// Gets the number of elements in the collection.
        /// </summary>
        /// <value></value>
        /// <returns>
        /// The number of elements in the collection.
        /// </returns>
        public new int Count
        {
            get
            {
                return base.Count;
            }
        }

        /// <summary>
        /// Gets or sets the <see cref="ConnectPlus.Data.Synchronization.Configuration.MessagePollingServiceElement"/> at the specified index.
        /// </summary>
        /// <param name="index">The index of the element to get or set.</param>
        /// <value>The element at the specified <param name="index"/>.</value>
        public MessagePollingServiceElement this[int index]
        {
            get
            {
                return (MessagePollingServiceElement)BaseGet(index);
            }

            set
            {
                if (BaseGet(index) != null)
                {
                    BaseRemoveAt(index);
                }

                this.BaseAdd(index, value);
            }
        }

        /// <summary>
        /// Gets the <see cref="ConnectPlus.Data.Synchronization.Configuration.MessagePollingServiceElement"/> with the specified name.
        /// </summary>
        /// <param name="name">The name of the element to get.</param>
        /// <value>The element with the specified <param name="name"/>.</value>
        public new MessagePollingServiceElement this[string name]
        {
            get
            {
                return (MessagePollingServiceElement)BaseGet(name);
            }
        }

        /// <summary>
        /// Indexes the of the specified <paramref name="element"/>
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>The index of the specified element; or -1 if the element is not contained within the collection.</returns>
        public int IndexOf(MessagePollingServiceElement element)
        {
            return BaseIndexOf(element);
        }

        /// <summary>
        /// Adds the specified element.
        /// </summary>
        /// <param name="element">The element.</param>
        public void Add(MessagePollingServiceElement element)
        {
            this.BaseAdd(element);
        }

        /// <summary>
        /// Removes the specified element.
        /// </summary>
        /// <param name="element">The element.</param>
        public void Remove(MessagePollingServiceElement element)
        {
            if (this.BaseIndexOf(element) >= 0)
            {
                this.BaseRemove(element.Name);
            }
        }

        /// <summary>
        /// Removes the element at the specified <paramref name="index"/>.
        /// </summary>
        /// <param name="index">The index.</param>
        public void RemoveAt(int index)
        {
            this.BaseRemoveAt(index);
        }

        /// <summary>
        /// Removes the element with the specified name.
        /// </summary>
        /// <param name="name">The name of the element to remove.</param>
        public void Remove(string name)
        {
            BaseRemove(name);
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        public void Clear()
        {
            BaseClear();
        }

        /// <summary>
        /// Adds a configuration element to the <see cref="T:System.Configuration.ConfigurationElementCollection"/>.
        /// </summary>
        /// <param name="element">The <see cref="T:System.Configuration.ConfigurationElement"/> to add.</param>
        protected override void BaseAdd(ConfigurationElement element)
        {
            this.BaseAdd(element, false);
        }

        /// <summary>
        /// When overridden in a derived class, creates a new <see cref="T:System.Configuration.ConfigurationElement"/>.
        /// </summary>
        /// <returns>
        /// A new <see cref="T:System.Configuration.ConfigurationElement"/>.
        /// </returns>
        protected override ConfigurationElement CreateNewElement()
        {
            return new MessagePollingServiceElement();
        }

        /// <summary>
        /// Creates a new <see cref="T:System.Configuration.ConfigurationElement"/> when overridden in a derived class.
        /// </summary>
        /// <param name="elementName">The name of the <see cref="T:System.Configuration.ConfigurationElement"/> to create.</param>
        /// <returns>
        /// A new <see cref="T:System.Configuration.ConfigurationElement"/>.
        /// </returns>
        protected override ConfigurationElement CreateNewElement(string elementName)
        {
            return new MessagePollingServiceElement(elementName);
        }

        /// <summary>
        /// Gets the element key for a specified configuration element when overridden in a derived class.
        /// </summary>
        /// <param name="element">The <see cref="T:System.Configuration.ConfigurationElement"/> to return the key for.</param>
        /// <returns>An <see cref="T:System.Object"/> that acts as the key for the specified <see cref="T:System.Configuration.ConfigurationElement"/>./// </returns>
        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((MessagePollingServiceElement)element).Name;
        }
    }
}
