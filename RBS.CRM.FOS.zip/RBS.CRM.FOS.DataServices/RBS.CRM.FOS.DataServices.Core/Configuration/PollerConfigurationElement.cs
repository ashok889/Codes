﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Diagnostics;

namespace RBS.CRM.FOS.DataServices.Core.Configuration
{
    /// <summary>
    /// Configuration elemnt
    /// </summary>
    public class PollerConfigurationElement : ConfigurationElement
    {
        protected PollerConfigurationElement() { }

        /// <summary>
        /// ActiveInterval property name
        /// </summary>
        private const string PropertyNameActiveInterval = "activeInterval";

        /// <summary>
        /// IdleInterval property name
        /// </summary>
        private const string PropertyNameIdleInterval = "idleInterval";

        /// <summary>
        /// ErrorIntervalMaximum property name
        /// </summary>
        private const string PropertyNameErrorIntervalMaximum = "errorIntervalMaximum";

        /// <summary>
        /// ErrorIntervalGrowthFactor property name
        /// </summary>
        private const string PropertyNameErrorIntervalGrowthFactor = "errorIntervalGrowthFactor";

        /// <summary>
        /// Gets or sets the active interval.
        /// </summary>
        /// <value>The active interval.</value>
        [ConfigurationProperty(PropertyNameActiveInterval, DefaultValue = "00:00:00.5", IsRequired = false)]
        [PositiveTimeSpanValidator]
        public TimeSpan ActiveInterval
        {
            get
            {
                return (TimeSpan)this[PropertyNameActiveInterval];
            }

            set
            {
                this[PropertyNameActiveInterval] = value;
            }
        }

        /// <summary>
        /// Gets or sets the idle interval.
        /// </summary>
        /// <value>The idle interval.</value>
        [ConfigurationProperty(PropertyNameIdleInterval, DefaultValue = "00:00:05.0", IsRequired = false)]
        [PositiveTimeSpanValidator]
        public TimeSpan IdleInterval
        {
            get
            {
                return (TimeSpan)this[PropertyNameIdleInterval];
            }

            set
            {
                this[PropertyNameIdleInterval] = value;
            }
        }

        /// <summary>
        /// Gets or sets the error interval maximum.
        /// </summary>
        /// <value>The error interval maximum.</value>
        [ConfigurationProperty(PropertyNameErrorIntervalMaximum, DefaultValue = "00:05:00", IsRequired = false)]
        [PositiveTimeSpanValidator()]
        public TimeSpan ErrorIntervalMaximum
        {
            get
            {
                return (TimeSpan)this[PropertyNameErrorIntervalMaximum];
            }

            set
            {
                this[PropertyNameErrorIntervalMaximum] = value;
            }
        }

        /// <summary>
        /// Gets or sets the error interval maximum.
        /// </summary>
        /// <value>The error interval maximum.</value>
        [ConfigurationProperty(PropertyNameErrorIntervalGrowthFactor, DefaultValue = 0.25, IsRequired = false)]
        [CallbackValidator(CallbackMethodName = "ValidateErrorIntervalGrowthFactor", Type = typeof(Validator))]
        public double ErrorIntervalGrowthFactor
        {
            get
            {
                return (double)this[PropertyNameErrorIntervalGrowthFactor];
            }

            set
            {
                this[PropertyNameErrorIntervalGrowthFactor] = value;
            }
        }

        /// <summary>
        /// Class containing custom validation for the configuration element
        /// </summary>
        protected class Validator
        {
            /// <summary>
            /// constructor
            /// </summary>
            protected Validator()
            { }

            /// <summary>
            /// Validates the error interval growth factor.
            /// </summary>
            /// <param name="value">The value.</param>
            [DebuggerStepThrough]
            public static void ValidateErrorIntervalGrowthFactor(object value)
            {
                var typedValue = (double)value;
                if (double.IsNaN(typedValue) || typedValue < 0.0)
                {
                    // -- ArgumentOutOfRangeException
                }
            }
        }
    }
}
