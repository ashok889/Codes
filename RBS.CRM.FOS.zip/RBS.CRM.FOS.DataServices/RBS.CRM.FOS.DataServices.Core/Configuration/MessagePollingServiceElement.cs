﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace RBS.CRM.FOS.DataServices.Core.Configuration
{
    /// <summary>
    /// Configuration element for the <see cref="MessagePollingService"/>
    /// </summary>
    public class MessagePollingServiceElement : ConfigurationElement
    {
        #region Fields

        /// <summary>
        /// Poller property name
        /// </summary>
        private const string PropertyNamePoller = "poller";

        /// <summary>
        /// MessageBatchSize property name
        /// </summary>
        private const string PropertyNameMessageBatchSize = "messageBatchSize";

        /// <summary>
        /// Name property name
        /// </summary>
        private const string PropertyNameName = "name";


        /// <summary>
        /// Poller property name
        /// </summary>
        private const string PropertyNameEodOnly = "eodOnly";


        /// <summary>
        /// Name property name
        /// </summary>
        private const string PropertyNameEodRunOnDays = "eodRunOnDays";

        /// <summary>
        /// Name property name
        /// </summary>
        private const string PropertyNameEodRunAtHour = "eodRunAtHour";


        /// <summary>
        /// Name property name
        /// </summary>
        private const string PropertyNameEodRunAtServiceStart = "eodRunAtServiceStart";


        /// <summary>
        /// Name property name
        /// </summary>
        private const string PropertyNameActive = "active";


        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="MessagePollingServiceElement"/> class.
        /// </summary>
        public MessagePollingServiceElement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessagePollingServiceElement"/> class.
        /// </summary>
        /// <param name="name">The name of the element.</param>
        public MessagePollingServiceElement(string name)
        {
            this.Name = name;
        }

        /// <summary>
        /// Gets or sets the error interval maximum.
        /// </summary>
        /// <value>The error interval maximum.</value>
        [ConfigurationProperty(PropertyNameName, DefaultValue = "Default", IsRequired = true, IsKey = true)]
        [StringValidator(InvalidCharacters = " ~!@#$%^&*()[]{}/;'\"|\\", MinLength = 1, MaxLength = 60)]
        public string Name
        {
            get
            {
                return (string)this[PropertyNameName];
            }

            set
            {
                this[PropertyNameName] = value;
            }
        }

        /// <summary>
        /// Gets the poller configuration element
        /// </summary>
        /// <value>The poller.</value>
        [ConfigurationProperty(PropertyNamePoller)]
        public PollerConfigurationElement Poller
        {
            get
            {
                return (PollerConfigurationElement)this[PropertyNamePoller];
            }
        }

        /// <summary>
        /// Gets or sets the message batch size
        /// </summary>
        /// <value>The message batch size.</value>
        [ConfigurationProperty(PropertyNameMessageBatchSize, DefaultValue = 10, IsRequired = true)]
        [IntegerValidator(ExcludeRange = false, MinValue = 1, MaxValue = Int32.MaxValue)]
        public int MessageBatchSize
        {
            get
            {
                return (int)this[PropertyNameMessageBatchSize];
            }

            set
            {
                this[PropertyNameMessageBatchSize] = value;
            }
        }

        /// <summary>
        /// Gets or sets the maximum wait interval that should be used when expanding due to errors.
        /// </summary>
        /// <value>The error interval maximum.</value>
        /// <remarks>The default value is 10 minutes.</remarks>
        [ConfigurationProperty(PropertyNameEodOnly, DefaultValue = false, IsRequired = false)]
        public bool EodOnly
        {
            get
            {
                return (bool)this[PropertyNameEodOnly];
            }

            set { this[PropertyNameEodOnly] = value; }
        }

        /// <summary>
        /// Gets or sets the maximum wait interval that should be used when expanding due to errors.
        /// </summary>
        /// <value>The error interval maximum.</value>
        /// <remarks>The default value is 10 minutes.</remarks>
        [ConfigurationProperty(PropertyNameEodRunOnDays, DefaultValue = "Monday;Tuesday;Wednesday;Thursday;Friday;Saturday", IsRequired = false)]
        public string EodRunOnDays
        {
            get
            {
                return this[PropertyNameEodRunOnDays].ToString();
            }
            set { this[PropertyNameEodRunOnDays] = value; }
        }

        /// <summary>
        /// Gets or sets the maximum wait interval that should be used when expanding due to errors.
        /// </summary>
        /// <value>The error interval maximum.</value>
        /// <remarks>The default value is 10 minutes.</remarks>
        [ConfigurationProperty(PropertyNameEodRunAtHour, DefaultValue = 22, IsRequired = false)]
        [IntegerValidator(ExcludeRange = false, MinValue = 1, MaxValue = 24)]
        public int EodRunAtHour
        {
            get
            {
                return (int)this[PropertyNameEodRunAtHour];
            }
            set
            {
                this[PropertyNameEodRunAtHour] = value;
            }
        }

        /// <summary>
        /// Gets or sets the maximum wait interval that should be used when expanding due to errors.
        /// </summary>
        /// <value>The error interval maximum.</value>
        /// <remarks>The default value is 10 minutes.</remarks>
        /// [ConfigurationProperty("eodRunAtHour", DefaultValue = 22, IsRequired = fasle)]
        [ConfigurationProperty(PropertyNameEodRunAtServiceStart, DefaultValue = false, IsRequired = false)]
        public bool EodRunAtServiceStart
        {
            get
            {
                return (bool)this[PropertyNameEodRunAtServiceStart];
            }
            set
            {
                this[PropertyNameEodRunAtServiceStart] = value;
            }
        }

        /// <summary>
        /// Gets or sets the maximum wait interval that should be used when expanding due to errors.
        /// </summary>
        /// <value>The error interval maximum.</value>
        /// <remarks>The default value is 10 minutes.</remarks>
        [ConfigurationProperty(PropertyNameActive, DefaultValue = false, IsRequired = true)]
        public bool Active
        {
            get
            {
                return (bool)this[PropertyNameActive];
            }
            set
            {
                this[PropertyNameActive] = value;
            }
        }
    }
}
