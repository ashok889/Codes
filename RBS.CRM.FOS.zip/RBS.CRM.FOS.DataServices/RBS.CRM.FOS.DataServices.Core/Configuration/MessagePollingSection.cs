﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace RBS.CRM.FOS.DataServices.Core.Configuration
{
    /// <summary>
    /// Configuration section for message polling
    /// </summary>
    public class MessagePollingSection : ConfigurationSection
    {
        /// <summary>
        /// Property name for services property
        /// </summary>
        public const string PropertyNameServices = "services";

        /// <summary>
        /// The transaction enabled property name
        /// </summary>
        private const string TransactionsEnabled = "transactionsEnabled";

        /// <summary>
        /// Gets the services configured for polling.
        /// </summary>
        /// <value>The services.</value>
        [ConfigurationProperty(PropertyNameServices, IsDefaultCollection = false)]
        public MessagePollingServiceElementCollection Services
        {
            get
            {
                return (MessagePollingServiceElementCollection)base[PropertyNameServices];
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [use transactions].
        /// </summary>
        /// <value><c>true</c> if [use transactions]; otherwise, <c>false</c>.</value>
        [ConfigurationProperty(TransactionsEnabled, DefaultValue = true)]
        public bool UseTransactions
        {
            get
            {
                return (bool)this[TransactionsEnabled];
            }

            set
            {
                this[TransactionsEnabled] = value;
            }
        }
    }
}
