﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServiceBase.cs" company="RBS GBM">
//   Copyright © RBS GBM 2010
// </copyright>
// <summary>
//   ServiceBase enables windows services to be run within the IDE or command line.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using RBS.CRM.FOS.DataServices.Core.Messaging;
using RBS.CRM.FOS.DataServices.Common;

namespace RBS.CRM.FOS.DataServices.Core.Services
{
    /// <summary>
    /// ServiceBase enables windows services to be run within the IDE or command line.
    /// </summary>
    [System.Diagnostics.DebuggerNonUserCode]
    public class ServiceBase : System.ServiceProcess.ServiceBase
    {
        #region Fields

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBase"/> class.
        /// </summary>
        public ServiceBase()
        {
            MessagePollingService = null;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the message polling service.
        /// </summary>
        /// <value>
        /// The message polling service.
        /// </value>
        public MessagePollingService MessagePollingService { get; set; }

        #endregion

        #region Public operations

        /// <summary>
        /// Start the service.
        /// </summary>
        /// <param name="service">The service we want to run.</param>
        /// <param name="args">The arguments to start the service with.</param>
        /// <remarks>
        /// If executing within the IDE and the build configuration
        /// is set to 'Debug' then the service will run outside of
        /// the ServiceController.
        /// </remarks>
        public void Run(ServiceBase service, string[] args)
        {
            try
            {
                if (args.Length == 1 && args[0] == "/debug")
                {
                    service.OnStart(args);
                    Console.WriteLine("Press enter or carriage-return to stop.");
                    Console.Read();
                    service.OnStop();

                    return;
                }

                Run(service);
            }
            catch (Exception ex)
            {
                Logger.LogFatal("An error occurred when trying to start the service" , ex as SynchServiceException , this.MessagePollingService.Name);
            }
        }

        #endregion
    }
}
