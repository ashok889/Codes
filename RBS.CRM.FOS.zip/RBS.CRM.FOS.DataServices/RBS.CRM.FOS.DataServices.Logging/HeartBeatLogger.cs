﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Common.Contracts;

namespace RBS.CRM.FOS.DataServices.Logging
{
    /// <summary>
    /// Custom Logger
    /// </summary>
    public class HeartBeatLogger : IHeartBeatLogger
    {
        readonly IDataAccessManager dataAccessManager;

        public HeartBeatLogger(IDataAccessManager dacManager)
        {
            this.dataAccessManager = dacManager;
        }

        public void LogHeartBeat(string serviceName, DateTime? lastHeartBeat)
        {
            dataAccessManager.SendHeartBeat(serviceName, lastHeartBeat);
        }
    }
}
