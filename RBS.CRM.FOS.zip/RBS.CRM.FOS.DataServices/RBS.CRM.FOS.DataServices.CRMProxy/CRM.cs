﻿using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Text;
using System.Net;
using Microsoft.Xrm.Tooling.Connector;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using RBS.CRM.FOS.DataServices.Common.Security;
using Microsoft.Xrm.Sdk.Query;
using System.Security;

namespace RBS.CRM.FOS.DataServices.CRMProxy
{
    public class CRM
    {
        // -- load env related config
        readonly string ClientId = ConfigurationManager.AppSettings["REST_ClientId"];
        readonly string ServiceUrl = ConfigurationManager.AppSettings["REST_ServiceUrl"];
        readonly string ServiceApiUrl = ConfigurationManager.AppSettings["REST_ServiceApiUrl"];
        readonly Uri RedirectUrl = new Uri(ConfigurationManager.AppSettings["REST_RedirectUrl"]);
        readonly static string Username = ConfigurationManager.AppSettings["REST_Username"];
        readonly string UserEmailId = ConfigurationManager.AppSettings["SOAP_UserEmailId"];
        readonly string CRMRegion = ConfigurationManager.AppSettings["SOAP_CRMRegion"];
        readonly string CRMOrgName = ConfigurationManager.AppSettings["SOAP_CRMOrgName"]; //--nwmfossit
        readonly static SecureString UserPassword = CrmServiceClient.MakeSecureString(ConfigurationManager.AppSettings["REST_UserPassword"]);
        readonly SecureString UserNTPassword = CrmServiceClient.MakeSecureString(DataProtect.DecryptString(ConfigurationManager.AppSettings["SOAP_UserNTPassword"]));

        // **Will be used when we use ADAL for web api token caching** 3.13.8 private UserPasswordCredential _credentials = new UserPasswordCredential(Username, UserPassword);
        private AuthenticationResult _authResult;
        private AuthenticationContext _authContext;

        #region "Connection Creation"
        CrmServiceClient crmSvc = null;
        public void CreateConnection_REST()
        {
            if (_authResult != null) return;
            #region pwd
            var credentials = new UserCredential(Username, UserPassword);
            #endregion

            var ap = AuthenticationParameters.CreateFromResourceUrlAsync(new Uri(ConfigurationManager.AppSettings["REST_ServiceResourceUrl"])).Result;
            var authContext = new AuthenticationContext(ap.Authority, false);
            _authResult = authContext.AcquireToken(ServiceUrl, ClientId, credentials);
            #region // **Will be used when we use ADAL for web api token caching** 
            //var ap = AuthenticationParameters.CreateFromResourceUrlAsync(new Uri(ConfigurationManager.AppSettings["REST_ServiceResourceUrl"])).Result;
            //_authContext = new AuthenticationContext(ap.Authority, new FileCache());
            //CheckForCachedToken(ServiceUrl, ClientId, RedirectUrl);
            #endregion
        }

        #region // **Will be used when we use ADAL for web api token caching** 
        //private async void CheckForCachedToken(string serviceUrl, string clientId, Uri redirectUrl)
        //{
        //    // As the application starts, try to get an access token without prompting the user.  If one exists it will have been taken from teh token cache.
        //    try
        //    {
        //        _authResult = await _authContext.AcquireTokenAsync(serviceUrl, clientId, redirectUrl, new PlatformParameters(PromptBehavior.Never));
        //    }
        //    catch (AdalException ex)
        //    {
        //        // If a token is not available or has expired we can re-authenticate passing in credentials
        //        if (ex.ErrorCode == "user_interaction_required")
        //        {
        //            //send credentials
        //            _authResult = await _authContext.AcquireTokenAsync(ServiceUrl, ClientId, _credentials);
        //        }
        //        else
        //        {
        //            throw ex;
        //        }
        //    }
        //    // A valid token is in the cache
        //}
        #endregion

        public CrmServiceClient CreateConnection_SOAP()
        {
            if (crmSvc != null)
            {
                return crmSvc;
            }
            else
            {
                CrmServiceClient crmSvc = new CrmServiceClient(crmUserId: UserEmailId, crmPassword: UserNTPassword, crmRegion: CRMRegion, orgName: CRMOrgName, isOffice365: true);
                var whoAmI = (WhoAmIResponse)crmSvc.Execute(new WhoAmIRequest());
                return crmSvc;
            }
        }
        #endregion

        #region "SOAP BASED OPERATIONS"
        public EntityCollection CreateMultipleEntities_SOAP(EntityCollection lstEntity)
        {
            try
            {
                var crmSvc = CreateConnection_SOAP();
                foreach (var item in lstEntity.Entities)
                {
                    var itemId = crmSvc.Create(item);
                    item.Attributes.Add("id", itemId);
                }
                return lstEntity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public EntityCollection UpdateMultipleEntities_SOAP(EntityCollection lstEntity)
        {
            try
            {
                var crmSvc = CreateConnection_SOAP();
                foreach (var item in lstEntity.Entities)
                {
                    crmSvc.Update(item);
                }
                return lstEntity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public Guid GetUserIdByName(string UserName)
        {
            Guid UserID = new Guid();
            var crmSvc = CreateConnection_SOAP();

            QueryExpression query = new QueryExpression("systemuser");
            query.ColumnSet = new ColumnSet(new string[] { "systemuserid" });
            query.Distinct = true;
            query.Criteria = new FilterExpression();
            query.Criteria.AddCondition("fullname", ConditionOperator.Equal, UserName);
            var users = crmSvc.RetrieveMultiple(query);

            if (users.Entities.Count > 0)
                UserID = users.Entities[0].Id;

            return UserID;
        }
        #endregion

        #region "REST BASED OPERATIONS"
        #region "SDMClientPriorityTier"
        public List<JObject> SaveMultipleSdmClientPriorityTier_REST(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await CreateSdmClientPriorityTier_REST(entities)));
            return entities;
        }

        public List<JObject> UpdateMultipleSdmClientPriorityTier_REST(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await UpdateSdmClientPriorityTier_REST(entities)));
            return entities;
        }

        public async Task CreateSdmClientPriorityTier_REST(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                using (var httpClient = new HttpClient())
                {
                    httpClient.BaseAddress = new Uri(ServiceApiUrl);
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    #region Create account list
                    foreach (var rbsm_accountpriorityassociation in entities)
                    {
                        HttpRequestMessage createRequest = new HttpRequestMessage(HttpMethod.Post, "rbsm_accountpriorityassociation");
                        createRequest.Content = new StringContent(rbsm_accountpriorityassociation.ToString(), Encoding.UTF8, "application/json");

                        HttpResponseMessage createResponse = await httpClient.SendAsync(createRequest);
                        if (createResponse.StatusCode == HttpStatusCode.NoContent)
                        {
                            var rbsm_accountpriorityassociationUri = createResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                            rbsm_accountpriorityassociationUri = rbsm_accountpriorityassociationUri.Replace(ServiceApiUrl, "").Replace("rbsm_accountpriorityassociation(", "").Replace(")", "");
                            rbsm_accountpriorityassociation.Add("id", rbsm_accountpriorityassociationUri);
                        }
                        else
                        {
                            return;
                        }
                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task UpdateSdmClientPriorityTier_REST(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();

                #region Update account list
                foreach (var rbsm_accountpriorityassociation in entities)
                {
                    var httpClient = new HttpClient();
                    httpClient.BaseAddress = new Uri(ServiceApiUrl + "rbsm_accountpriority(" + rbsm_accountpriorityassociation["id"] + ")");
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    HttpRequestMessage updateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), ServiceApiUrl + "rbsm_accountpriorityassociation(" + rbsm_accountpriorityassociation["id"] + ")");
                    rbsm_accountpriorityassociation.Remove("id"); // -- this is mscrmid and is not stored in crm as 'id'. sop remving from request fields.
                    updateRequest.Content = new StringContent(rbsm_accountpriorityassociation.ToString(), Encoding.UTF8, "application/json");

                    HttpResponseMessage updateResponse = await httpClient.SendAsync(updateRequest);
                    if (updateResponse.StatusCode == HttpStatusCode.NoContent)
                    {
                        var rbsm_accountpriorityassociationUri = updateResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                        rbsm_accountpriorityassociationUri = rbsm_accountpriorityassociationUri.Replace(ServiceApiUrl, "").Replace("rbsm_accountpriority(", "").Replace(")", "");
                        rbsm_accountpriorityassociation.Add("id", rbsm_accountpriorityassociationUri);
                    }
                    else
                    {
                        return;
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion  

        #region "PriorityGroupListTier"
        public List<JObject> CreateMultipleAccountPriority_REST(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await CreateAccountPriority_REST(entities)));
            return entities;
        }

        public List<JObject> UpdateMultipleAccountPriority_REST(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await UpdateAccountPriority_REST(entities)));
            return entities;
        }

        public async Task CreateAccountPriority_REST(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                using (var httpClient = new HttpClient())
                {
                    httpClient.BaseAddress = new Uri(ServiceApiUrl);
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    #region Create account list
                    foreach (var rbsm_accountpriority in entities)
                    {
                        HttpRequestMessage createRequest = new HttpRequestMessage(HttpMethod.Post, "rbsm_accountpriorities");
                        createRequest.Content = new StringContent(rbsm_accountpriority.ToString(), Encoding.UTF8, "application/json");

                        HttpResponseMessage createResponse = await httpClient.SendAsync(createRequest);
                        if (createResponse.StatusCode == HttpStatusCode.NoContent)
                        {
                            var accountpriorityUri = createResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                            accountpriorityUri = accountpriorityUri.Replace(ServiceApiUrl, "").Replace("rbsm_accountpriorities(", "").Replace(")", "");
                            rbsm_accountpriority.Add("rbsm_accountpriorityid", accountpriorityUri);
                        }
                        else
                        {
                            return;
                        }
                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task UpdateAccountPriority_REST(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                #region Update account list
                foreach (var rbsm_accountpriority in entities)
                {
                    var httpClient = new HttpClient();
                    httpClient.BaseAddress = new Uri(ServiceApiUrl + "rbsm_accountpriorities(" + rbsm_accountpriority["rbsm_accountpriorityid"] + ")");
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    HttpRequestMessage updateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), ServiceApiUrl + "rbsm_accountpriorities(" + rbsm_accountpriority["rbsm_accountpriorityid"] + ")");
                    rbsm_accountpriority.Remove("rbsm_accountpriorityid"); // -- this is mscrmid and is not stored in crm as 'id'. sop remving from request fields.
                    updateRequest.Content = new StringContent(rbsm_accountpriority.ToString(), Encoding.UTF8, "application/json");

                    HttpResponseMessage updateResponse = await httpClient.SendAsync(updateRequest);
                    if (updateResponse.StatusCode == HttpStatusCode.NoContent)
                    {
                        var rbsm_accountpriorityUri = updateResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                        rbsm_accountpriorityUri = rbsm_accountpriorityUri.Replace(ServiceApiUrl, "").Replace("rbsm_accountpriorities(", "").Replace(")", "");
                        rbsm_accountpriority.Add("rbsm_accountpriorityid", rbsm_accountpriorityUri);
                    }
                    else
                    {
                        return;
                    }


                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        #region "SDMClientUserRole/Connection"
        public List<JObject> SaveMultipleSDMClientUserRole(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await CreateSDMClientUserRole(entities)));
            return entities;
        }

        public List<JObject> UpdateMultipleSDMClientUserRole(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await UpdateSDMClientUserRole(entities)));
            return entities;
        }

        public async Task CreateSDMClientUserRole(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                using (var httpClient = new HttpClient())
                {
                    httpClient.BaseAddress = new Uri(ServiceApiUrl);
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    #region Create account list
                    foreach (var connection in entities)
                    {

                        #region "GetUserId"
                        HttpRequestMessage fetchRequest = new HttpRequestMessage(HttpMethod.Get, ServiceApiUrl + "/systemusers?$filter=fullname eq '" + connection["record2id"].ToString() + "'");
                        HttpResponseMessage fetchResponse;
                        fetchResponse = await httpClient.SendAsync(fetchRequest);

                        if (fetchResponse.StatusCode == HttpStatusCode.OK) //200
                        {
                            var user = JsonConvert.DeserializeObject<JObject>(fetchResponse.Content.ReadAsStringAsync().Result);
                            if (((Newtonsoft.Json.Linq.JContainer)(user.SelectToken(@"value"))).HasValues)
                            {
                                connection.Remove("record2id");
                                connection.Add("record2id_systemuser@odata.bind", "/systemusers(" + user.SelectToken(@"value[0].systemuserid").Value<string>() + ")");
                                HttpRequestMessage createRequest = new HttpRequestMessage(HttpMethod.Post, "connections");
                                createRequest.Content = new StringContent(connection.ToString(), Encoding.UTF8, "application/json");

                                HttpResponseMessage createResponse = await httpClient.SendAsync(createRequest);
                                if (createResponse.StatusCode == HttpStatusCode.NoContent)
                                {
                                    var connectionUri = createResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                                    connectionUri = connectionUri.Replace(ServiceApiUrl, "").Replace("connections(", "").Replace(")", "");
                                    connection.Add("id", connectionUri);
                                }
                                else
                                {
                                    return;
                                }
                            }

                        }
                        #endregion

                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task UpdateSDMClientUserRole(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                #region Update account list
                foreach (var connection in entities)
                {
                    var httpClient = new HttpClient();
                    httpClient.BaseAddress = new Uri(ServiceApiUrl + "connections(" + connection["id"] + ")");
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);


                    HttpRequestMessage fetchRequest = new HttpRequestMessage(HttpMethod.Get, ServiceApiUrl + "/systemusers?$filter=fullname eq '" + connection["record2id"].ToString() + "'");
                    HttpResponseMessage fetchResponse;
                    fetchResponse = await httpClient.SendAsync(fetchRequest);

                    if (fetchResponse.StatusCode == HttpStatusCode.OK) //200
                    {
                        JObject user = JsonConvert.DeserializeObject<JObject>(fetchResponse.Content.ReadAsStringAsync().Result);
                        if (((Newtonsoft.Json.Linq.JContainer)(user.SelectToken(@"value"))).HasValues)
                        {
                            connection.Remove("record2id");
                            connection.Add("record2id_systemuser@odata.bind", "/systemusers(" + user.SelectToken(@"value[0].systemuserid").Value<string>() + ")");
                            HttpRequestMessage updateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), ServiceApiUrl + "connections(" + connection["id"] + ")");
                            connection.Remove("id"); // -- this is mscrmid and is not stored in crm as 'id'. sop remving from request fields.
                            updateRequest.Content = new StringContent(connection.ToString(), Encoding.UTF8, "application/json");

                            HttpResponseMessage updateResponse = await httpClient.SendAsync(updateRequest);
                            if (updateResponse.StatusCode == HttpStatusCode.NoContent)
                            {
                                var connectionUri = updateResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                                connectionUri = connectionUri.Replace(ServiceApiUrl, "").Replace("connections(", "").Replace(")", "");
                                connection.Add("id", connectionUri);
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        #region "SDMRole"
        public List<JObject> SaveMultipleSDMRole(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await CreateSDMRole(entities)));
            return entities;
        }

        public List<JObject> UpdateMultipleSDMRole(List<JObject> entities)
        {
            Task.WaitAll(Task.Run(async () => await UpdateSDMRole(entities)));
            return entities;
        }

        public async Task CreateSDMRole(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                using (var httpClient = new HttpClient())
                {
                    httpClient.BaseAddress = new Uri(ServiceApiUrl);
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    #region Create account list
                    string temp_rbsm_stagingid = "";
                    foreach (var connectionrole in entities)
                    {
                        HttpRequestMessage createRequest = new HttpRequestMessage(HttpMethod.Post, "connectionroles");
                        temp_rbsm_stagingid = connectionrole["rbsm_stagingid"].ToString();
                        connectionrole.Remove("rbsm_stagingid"); // -- this is mscrmid and is not stored in crm as 'id'. sop remving from request fields.
                        createRequest.Content = new StringContent(connectionrole.ToString(), Encoding.UTF8, "application/json");

                        HttpResponseMessage createResponse = await httpClient.SendAsync(createRequest);
                        if (createResponse.StatusCode == HttpStatusCode.NoContent)
                        {
                            var accountpriorityUri = createResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                            accountpriorityUri = accountpriorityUri.Replace(ServiceApiUrl, "").Replace("connectionroles(", "").Replace(")", "");
                            connectionrole.Add("id", accountpriorityUri);
                            connectionrole.Add("rbsm_stagingid", temp_rbsm_stagingid);
                        }
                        else
                        {
                            return;
                        }
                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task UpdateSDMRole(List<JObject> entities)
        {
            try
            {
                CreateConnection_REST();
                #region Update account list
                foreach (var connectionrole in entities)
                {
                    var httpClient = new HttpClient();
                    httpClient.BaseAddress = new Uri(ServiceApiUrl + "connectionroles(" + connectionrole["id"] + ")");
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    HttpRequestMessage updateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), ServiceApiUrl + "connectionroles(" + connectionrole["id"] + ")");
                    connectionrole.Remove("id"); // -- this is mscrmid and is not stored in crm as 'id'. sop remving from request fields.
                    updateRequest.Content = new StringContent(connectionrole.ToString(), Encoding.UTF8, "application/json");

                    HttpResponseMessage updateResponse = await httpClient.SendAsync(updateRequest);
                    if (updateResponse.StatusCode == HttpStatusCode.NoContent)
                    {
                        var connectionroleUri = updateResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                        connectionroleUri = connectionroleUri.Replace(ServiceApiUrl, "").Replace("connectionroles(", "").Replace(")", "");
                        connectionrole.Add("id", connectionroleUri);
                    }
                    else
                    {
                        return;
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        #region "ACCOUNTS"
        public async Task CreateAccounts(List<JObject> accounts)
        {
            try
            {
                CreateConnection_REST();
                using (var httpClient = new HttpClient())
                {
                    httpClient.BaseAddress = new Uri(ServiceApiUrl);
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    #region Create account list
                    foreach (var account in accounts)
                    {
                        HttpRequestMessage createRequest = new HttpRequestMessage(HttpMethod.Post, "accounts");
                        createRequest.Content = new StringContent(account.ToString(), Encoding.UTF8, "application/json");

                        HttpResponseMessage createResponse = await httpClient.SendAsync(createRequest);
                        if (createResponse.StatusCode == HttpStatusCode.NoContent)
                        {
                            var accountUri = createResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                            accountUri = accountUri.Replace(ServiceApiUrl, "").Replace("accounts(", "").Replace(")", "");
                            account.Add("id", accountUri);
                        }
                        else
                        {
                            return;
                        }
                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task UpdateAccounts(List<JObject> accounts)
        {
            try
            {
                CreateConnection_REST();
                #region Update account list
                string temp_stagingid = string.Empty;
                foreach (var account in accounts)
                {
                    var httpClient = new HttpClient();
                    httpClient.BaseAddress = new Uri(ServiceApiUrl + "accounts(" + account["id"] + ")");
                    httpClient.Timeout = new TimeSpan(0, 2, 0);
                    httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
                    httpClient.DefaultRequestHeaders.Add("OData-Version", "4.0");
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authResult.AccessToken);

                    HttpRequestMessage updateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), ServiceApiUrl + "accounts(" + account["id"] + ")");
                    account.Remove("id"); // -- this is mscrmid and is not stored in crm as 'id'. sop remving from request fields.
                    temp_stagingid = account["rbsm_stagingid"].ToString();
                    account.Remove("rbsm_stagingid");
                    updateRequest.Content = new StringContent(account.ToString(), Encoding.UTF8, "application/json");

                    HttpResponseMessage updateResponse = await httpClient.SendAsync(updateRequest);
                    if (updateResponse.StatusCode == HttpStatusCode.NoContent)
                    {
                        var accountUri = updateResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                        accountUri = accountUri.Replace(ServiceApiUrl, "").Replace("accounts(", "").Replace(")", "");
                        account.Add("id", accountUri);
                        account.Add("rbsm_stagingid", temp_stagingid);
                    }
                    else
                    {
                        return;
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Task<HttpResponseMessage> SendAsJsonAsync<T>(HttpClient client, HttpMethod method, string requestUri, T value)
        {
            var content = value.GetType().Name.Equals("JObject") ?
                value.ToString() : JsonConvert.SerializeObject(value, new JsonSerializerSettings() { DefaultValueHandling = DefaultValueHandling.Ignore });

            var request = new HttpRequestMessage(method, requestUri) { Content = new StringContent(content) };
            request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");

            return client.SendAsync(request);
        }

        public List<JObject> CreateMultipleAccounts_REST(List<JObject> accounts)
        {
            Task.WaitAll(Task.Run(async () => await CreateAccounts(accounts)));
            return accounts;
        }

        public List<JObject> UpdateMultipleAccounts_REST(List<JObject> accounts)
        {
            Task.WaitAll(Task.Run(async () => await UpdateAccounts(accounts)));
            return accounts;
        }
        #endregion
        #endregion

    }
}
