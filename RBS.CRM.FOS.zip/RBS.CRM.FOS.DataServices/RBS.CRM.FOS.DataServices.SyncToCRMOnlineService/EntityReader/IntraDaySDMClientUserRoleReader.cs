﻿using System;
using System.Collections.Generic;
using System.Configuration;
using CRM.DataServices.DataAccess;
using CRM.DataServices.DataAccess.Entities;
using System.Globalization;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.DataAccess.Parsers;
using RBS.CRM.FOS.DataServices.Common.Contracts;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Resources;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Core.Messaging;
using RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntityReader
{
    public class IntraDaySDMClientUserRoleReader : IMessageQueueReader
    {
        /// <summary>
        /// For reading client related data from staging db
        /// </summary>
        public ISDMClientUserRoleReader Reader
        {
            get;
            set;
        }

        /// <summary>
        /// service bname
        /// </summary>
        private string serviceName = string.Empty;

        /// <summary>
        /// Message dequeueing flag.
        /// </summary>
        private IHeartBeatLogger heartBeatLogger = null;

        public IntraDaySDMClientUserRoleReader(string serviceName, IHeartBeatLogger hbLogger)
        {

            this.serviceName = serviceName;
            this.heartBeatLogger = hbLogger;
        }

        /// <summary>
        /// Message dequeueing flag.
        /// </summary>
        public IHeartBeatLogger HeartBeatLogger
        {
            get { return heartBeatLogger; }
            set { heartBeatLogger = value; }
        }

        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public object Dequeue(int messageProcessingBatchSize)
        {
            HeartBeatLogger.LogHeartBeat(serviceName, DateTime.UtcNow);
            if (Reader == null)
                Reader = new SDMClientUserRoleDataReader();
            try
            {
                //read connection string from config
                string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

                Logger.LogInfo("Fetching batch of " + messageProcessingBatchSize.ToString() + " SDMClientUserRole from database.");
                var SDMClientUserRoles = Reader.GetSDMClientUserRoles(connectionstring, messageProcessingBatchSize);
                Logger.LogInfo("Fetched batch of " + SDMClientUserRoles.Count.ToString() + " SDMClientUserRole from database.");
                return SDMClientUserRoles;
            }
            catch (Exception ex)
            {
                Logger.LogFatal(string.Format(CultureInfo.CurrentCulture, LoggerMessages.ServiceFailedToStart, serviceName), ex as SynchServiceException, " processing Prioritytier association");
            }
            return null;
        }

        public void RegisterSubscriber(IMessageHandler handler)
        {
            throw new NotImplementedException();
        }

        public void RegisterSubscriber(Core.Messaging.IMessageHandler handler)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Publish message
        /// </summary>
        /// <param name="message"></param>
        public void PublishMessage(object message)
        {
            try
            {
                var SDMClientUserRoleList = message != null ? (List<SDMClientUserRole>)message : null;
                if (SDMClientUserRoleList.Count > 0)
                {
                    var objSDMClientUserRoleSync = new SDMClientUserRoleSync(Reader);
                    bool UseRESTConnection = ConfigurationManager.AppSettings["UseRESTConnection"].ToString() == "false" ? false : true;

                    if (UseRESTConnection)
                        objSDMClientUserRoleSync.PublishSDMClientUserRoleToMsd_REST(SDMClientUserRoleList);
                    else
                        objSDMClientUserRoleSync.PublishSDMClientUserRoleToMsd_SOAP(SDMClientUserRoleList);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
