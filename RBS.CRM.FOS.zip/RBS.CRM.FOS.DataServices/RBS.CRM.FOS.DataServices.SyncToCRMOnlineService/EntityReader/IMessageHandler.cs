﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RBS.CRM.FOS.DataServices.DataAccess;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntityReader
{
    /// <summary>
    /// Responsible for handling messages
    /// </summary>
    public interface IMessageHandler
    {
        /// <summary>
        /// Instance of DataAccess manager class.
        /// </summary>
        IDataAccessManager DataAccessManager { get; set; }

        /// <summary>
        /// Handle the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        void Handle(object message);
    }
}
