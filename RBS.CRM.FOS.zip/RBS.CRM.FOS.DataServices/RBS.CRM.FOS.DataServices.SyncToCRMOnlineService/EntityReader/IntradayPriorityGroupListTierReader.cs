﻿using System;
using System.Collections.Generic;
using System.Configuration;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Core.Messaging;
using CRM.DataServices.DataAccess;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using System.Globalization;
using RBS.CRM.FOS.DataServices.Common.Resources;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Common.Contracts;
using RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntityReader
{
    public class IntradayPriorityGroupListTierReader : IMessageQueueReader
    {
        /// <summary>
        /// For reading client related data from staging db
        /// </summary>
        public IPriorityGroupListTierDataReader Reader
        {
            get;
            set;
        }

        /// <summary>
        /// service bname
        /// </summary>
        private string serviceName = string.Empty;

        private char _priorityCriteria { get; set; }

        /// <summary>
        /// Message dequeueing flag.
        /// </summary>
        private IHeartBeatLogger heartBeatLogger = null;

        public IntradayPriorityGroupListTierReader(string serviceName, char priorityCriteria, IHeartBeatLogger hbLogger)
        {

            this.serviceName = serviceName;
            this.heartBeatLogger = hbLogger;
            _priorityCriteria = priorityCriteria;
        }

        /// <summary>
        /// Message dequeueing flag.
        /// </summary>
        public IHeartBeatLogger HeartBeatLogger
        {
            get { return heartBeatLogger; }
            set { heartBeatLogger = value; }
        }

        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public object Dequeue(int messageProcessingBatchSize)
        {
            HeartBeatLogger.LogHeartBeat(serviceName, DateTime.UtcNow);
            if (Reader == null)
                Reader = new PriorityGroupListTierDataReader();
            try
            {
                //read connection string from config
                string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

                Logger.LogInfo("Fetching batch of " + messageProcessingBatchSize.ToString() + " PriorityGroupListTier from database.");
                var priorityGroupListTiers = Reader.GetPriorityGroupListTier(connectionstring, _priorityCriteria, messageProcessingBatchSize);
                Logger.LogInfo("Fetched batch of " + priorityGroupListTiers.Count.ToString() + " priority Group List Tiers from database.");
                return priorityGroupListTiers;
            }
            catch (Exception ex)
            {
                Logger.LogFatal(string.Format(CultureInfo.CurrentCulture, LoggerMessages.ServiceFailedToStart, serviceName), ex as SynchServiceException, " processing PriorityGroupListTier");
            }
            return null;
        }

        public void RegisterSubscriber(IMessageHandler handler)
        {
            throw new NotImplementedException();
        }
        public void RegisterSubscriber(Core.Messaging.IMessageHandler handler)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Publish message
        /// </summary>
        /// <param name="message"></param>
        public void PublishMessage(object message)
        {
            try
            {
                var priorityGroupListTiers = message != null ? (List<PriorityGroupListTier>)message : null;
                if (priorityGroupListTiers.Count > 0)
                {
                    var objPriorityGroupListTierSync = new PriorityGroupListTierSync(Reader);
                    bool UseRESTConnection = ConfigurationManager.AppSettings["UseRESTConnection"].ToString() == "false" ? false : true;

                    if (UseRESTConnection)
                        objPriorityGroupListTierSync.PublishPriorityGroupListTierToMsd_REST(priorityGroupListTiers);
                    else
                        objPriorityGroupListTierSync.PublishPriorityGroupListTierToMsd_SOAP(priorityGroupListTiers);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
