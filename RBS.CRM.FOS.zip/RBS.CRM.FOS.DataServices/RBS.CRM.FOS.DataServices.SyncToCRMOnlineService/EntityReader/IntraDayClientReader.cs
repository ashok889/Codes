﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RBS.CRM.FOS.DataServices.Core.Messaging;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Common.Contracts;
using System.Configuration;
using RBS.CRM.FOS.DataServices.Common;
using System.Globalization;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using RBS.CRM.FOS.DataServices.Common.Resources;
using CRM.DataServices.DataAccess.Entities;
using RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntityReader
{
    /// <summary>
    /// Intraday client reader reads clients published intraday on staging db
    /// </summary>
    public class IntraDayClientReader : IMessageQueueReader
    {

        /// <summary>
        /// For reading client related data from staging db
        /// </summary>
        public IClientDataReader Reader
        {
            get;
            set;
        }

        /// <summary>
        /// service bname
        /// </summary>
        private readonly string serviceName = string.Empty;

        public IntraDayClientReader(string serviceName, IHeartBeatLogger hbLogger)
        {
            this.serviceName = serviceName;
            this.HeartBeatLogger = hbLogger;
        }

        /// <summary>
        /// Message dequeueing flag.
        /// </summary>
        public IHeartBeatLogger HeartBeatLogger
        {
            get;
            set;
        }

        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public object Dequeue(int messageProcessingBatchSize)
        {
            HeartBeatLogger.LogHeartBeat(serviceName, DateTime.UtcNow);
            if (Reader == null)
                Reader = new ClientDataReader();

            try
            {
                //read connection string from config
                string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;
 
                Logger.LogInfo("Fetching batch of " + messageProcessingBatchSize.ToString() + " Clients from database.");
                var clients = Reader.GetClients(connectionstring, messageProcessingBatchSize);
                Logger.LogInfo("Fetched batch of " + clients.Count.ToString() + " Clients from database.");
                return clients;
            }
            catch (Exception ex)
            {
                Logger.LogFatal(string.Format(CultureInfo.CurrentCulture, LoggerMessages.ServiceFailedToStart, serviceName), ex as SynchServiceException, " processing Client data");
            }
            return null;
        }

        public void RegisterSubscriber(IMessageHandler handler)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Publish message
        /// </summary>
        /// <param name="message"></param>
        public void PublishMessage(object message)
        {
            try
            {
                var clientList = message != null ? (List<Client>)message : null;
                if (clientList.Count > 0)
                {
                    AccountSync objAccountSync = new AccountSync(Reader);
                    bool UseRESTConnection = ConfigurationManager.AppSettings["UseRESTConnection"].ToString() == "false" ? false : true;

                    if (UseRESTConnection)
                        objAccountSync.PublishAccountstoMSD_REST(clientList);
                    else
                        objAccountSync.PublishAccountstoMSD_SOAP(clientList);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        
        public void RegisterSubscriber(Core.Messaging.IMessageHandler handler)
        {
            throw new NotImplementedException();
        }
    }
}
