﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using CRM.DataServices.DataAccess;
using CRM.DataServices.DataAccess.Entities;
using Microsoft.Xrm.Sdk;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using CRMVSBCU = RBS.CRM.FOS.DataServices.CRMProxy.CrmEarlyBoundClasses;
using RBS.CRM.FOS.DataServices.Common.Resources;
using Newtonsoft.Json.Linq;
using CRMVSBCU.CrmEarlyBoundClasses;
using Rbs.Crm.FOS.CrmEarlyBoundClasses;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync
{
    public class SDMClientUserRoleSync
    {
        private ISDMClientUserRoleReader _reader = null;
        private int _serviceHitCount = 0;

        public SDMClientUserRoleSync(ISDMClientUserRoleReader reader)
        {
            _reader = reader;
        }


        public void PublishSDMClientUserRoleToMsd_SOAP(object message)
        {
            try
            {
                _serviceHitCount += 1;

                #region "VARIBLES"
                var SDMClientUserRoles = message != null ? (List<SDMClientUserRole>)message : null;
                var objCrmProxy = new CRMProxy.CRM();

                EntityCollection objSaveSDMClientUserRole = new EntityCollection();
                EntityCollection objUpdateSDMClientUserRole = new EntityCollection();
                EntityCollection objreSaveSDMClientUserRole = new EntityCollection();

                var tblCrmResponse = new DataTable("CRMResponse");
                tblCrmResponse.Columns.Add("guid", typeof(Guid));
                tblCrmResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

                EntityCollection saveResult = new EntityCollection();
                EntityCollection updateResult = new EntityCollection();
                EntityCollection reSaveResult = new EntityCollection();
                #endregion

                #region "Populate MSD objects from datareader"
                nwm_employee_coveragerole temp = new nwm_employee_coveragerole();
                if (SDMClientUserRoles != null)
                    foreach (var SDMClientUserRole in SDMClientUserRoles)
                    {
                        temp = new nwm_employee_coveragerole();
                        temp.nwm_Account = new EntityReference(CRMProxy.CrmEarlyBoundClasses.Account.EntityLogicalName, new Guid(SDMClientUserRole.ClientMSCRMId));
                        temp.nwm_CovreageRole = new EntityReference(nwm_coveragerole.EntityLogicalName, new Guid(SDMClientUserRole.RoleId));
                        temp.nwm_Employee = new EntityReference(nwm_Employee.EntityLogicalName, new Guid(SDMClientUserRole.EmployeeMSCRMID));
                        temp.nwm_StagingId = SDMClientUserRole.StagingId;

                        Guid blankGUID = new Guid(); // -- this is just a placeholder for try GUID format parsing.
                        if (!string.IsNullOrEmpty(SDMClientUserRole.MSCRMID) && Guid.TryParse(SDMClientUserRole.MSCRMID, out blankGUID))
                        {
                            
                            temp.Id = new Guid(SDMClientUserRole.MSCRMID); //-- id is available only for records getting updated.

                            // -- state to be changed only in updates. All new created ones will be active by default.
                            //-- statecode: 0=Active, 1=Inactive
                            // -- statecode":1,"statuscode":2
                            temp.statecode = SDMClientUserRole.IsDeleted ? nwm_employee_coverageroleState.Inactive : nwm_employee_coverageroleState.Active;
                            temp.statuscode = SDMClientUserRole.IsDeleted ? new Microsoft.Xrm.Sdk.OptionSetValue(2) : new Microsoft.Xrm.Sdk.OptionSetValue(1);

                            // Sdm Client Priority Tier already exists on MS Dynamics as we have the GUID. So we need to send update command
                            objUpdateSDMClientUserRole.Entities.Add(temp);
                        }
                        else
                        {
                            // new Sdm Client Priority Tier for MS Dynamics as we dont  have the GUID. We need to send insert command
                            objSaveSDMClientUserRole.Entities.Add(temp);
                        }
                    }
                #endregion
             
                #region "Sync MSD generate Id back to staging database"
                if (objSaveSDMClientUserRole.Entities.Count > 0)
                {
                    saveResult = objCrmProxy.CreateMultipleEntities_SOAP(objSaveSDMClientUserRole);

                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Entities.Count - 1; saveResultCntr++)
                    {
                        if (1 == 0)
                        {

                        }
                        else
                        {
                            // -- save this MSCRM response in database
                            try
                            {
                                string val = saveResult[saveResultCntr]["id"].ToString();
                                tblCrmResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of PriorityGroupListTier object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing Priority Group List Tier, if required"
                if (objUpdateSDMClientUserRole.Entities.Count > 0)
                {
                    updateResult = objCrmProxy.UpdateMultipleEntities_SOAP(objUpdateSDMClientUserRole);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Entities.Count - 1; i++)
                    {
                        string val = updateResult[i].Id.ToString();
                        tblCrmResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSaveSDMClientUserRole.Entities.Count > 0)
                {
                    reSaveResult = objCrmProxy.CreateMultipleEntities_SOAP(objreSaveSDMClientUserRole);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Entities.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["id"].ToString();
                        tblCrmResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCrmResponse.Rows.Count > 0)
                {
                    bool syncResult = SyncMSCRMIDForSDMClientUserRole(tblCrmResponse);
                }
                #endregion

            }
            catch (Exception ex)
            {
                if (_serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishSDMClientUserRoleToMsd_SOAP(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishSDMClientUserRoleToMsd_SOAP(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }
        public void PublishSDMClientUserRoleToMsd_REST(object message)
        {
            try
            {
                _serviceHitCount += 1;

                #region "VARIBLES"
                var SDMClientUserRoles = message != null ? (List<SDMClientUserRole>)message : null;
                var objCrmProxy = new CRMProxy.CRM();
                DataCollection<Entity> entityList;
                List<JObject> objSaveSDMClientUserRole = new List<JObject>();
                List<JObject> objUpdateSDMClientUserRole = new List<JObject>();
                List<JObject> objreSaveSDMClientUserRole = new List<JObject>();

                #endregion

                #region "Populate MSD objects from datareader"
                var temp = new JObject();
                if (SDMClientUserRoles != null)
                    foreach (var SDMClientUserRole in SDMClientUserRoles)
                    {
                        temp = new JObject();
                        temp.Add("record2roleid@odata.bind", "/connectionroles(" + SDMClientUserRole.RoleId + ")");
                        temp.Add("record2id", SDMClientUserRole.UserName);
                        temp.Add("record1id_account@odata.bind", "/accounts(" + SDMClientUserRole.ClientMSCRMId + ")");
                        temp.Add("nwm_stagingid", SDMClientUserRole.StagingId);

                        if (!string.IsNullOrEmpty(SDMClientUserRole.MSCRMID))
                        {
                            temp.Add("id", SDMClientUserRole.MSCRMID); //-- id is available only for records getting updated.

                            // -- state to be changed only in updates. All new created ones will be active by default.
                            //-- statecode: 0=Active, 1=Inactive
                            // -- statecode":1,"statuscode":2
                            temp.Add("statecode", SDMClientUserRole.IsDeleted ? 1 : 0);
                            temp.Add("statuscode", SDMClientUserRole.IsDeleted ? 2 : 1);

                            // Sdm Client Priority Tier already exists on MS Dynamics as we have the GUID. So we need to send update command
                            objUpdateSDMClientUserRole.Add(temp);
                        }
                        else
                        {
                            // new Sdm Client Priority Tier for MS Dynamics as we dont  have the GUID. We need to send insert command
                            objSaveSDMClientUserRole.Add(temp);
                        }
                    }

                #endregion

                #region "Sync MSD generate Id back to staging database"

                var tblCrmResponse = new DataTable("CRMResponse");

                tblCrmResponse.Columns.Add("guid", typeof(Guid));
                tblCrmResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

                List<JObject> saveResult = new List<JObject>();
                List<JObject> updateResult = new List<JObject>();
                List<JObject> reSaveResult = new List<JObject>();

                if (objSaveSDMClientUserRole.Count > 0)
                {
                    saveResult = objCrmProxy.SaveMultipleSDMClientUserRole(objSaveSDMClientUserRole);

                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Count - 1; saveResultCntr++)
                    {
                        if (1 == 0)
                        {

                        }
                        else
                        {
                            // -- save this MSCRM response in database
                            try
                            {
                                string val = saveResult[saveResultCntr]["id"].ToString();
                                tblCrmResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of PriorityGroupListTier object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing Priority Group List Tier, if required"
                if (objUpdateSDMClientUserRole.Count > 0)
                {
                    updateResult = objCrmProxy.UpdateMultipleSDMClientUserRole(objUpdateSDMClientUserRole);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Count - 1; i++)
                    {
                        string val = updateResult[i]["id"].ToString();
                        tblCrmResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSaveSDMClientUserRole.Count > 0)
                {
                    reSaveResult = objCrmProxy.SaveMultipleSDMClientUserRole(objreSaveSDMClientUserRole);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["id"].ToString();
                        tblCrmResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCrmResponse.Rows.Count > 0)
                {
                    bool syncResult = SyncMSCRMIDForSDMClientUserRole(tblCrmResponse);
                }
                #endregion

            }
            catch (Exception ex)
            {
                if (_serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishSDMClientUserRoleToMsd_REST(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishSDMClientUserRoleToMsd_REST(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        /// <summary>
        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public bool SyncMSCRMIDForSDMClientUserRole(DataTable tblCRMResponse)
        {
            if (_reader == null)
                _reader = new SDMClientUserRoleDataReader();

            //read connection string from config
            string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

            var result = _reader.SyncMSCRMIDForSDMClientUserRoles(connectionstring, tblCRMResponse);
            return result;
        }
    }
}
