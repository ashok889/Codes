﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using CRM.DataServices.DataAccess.Entities;
using Microsoft.Xrm.Sdk;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using RBS.CRM.FOS.DataServices.Common.Resources;
using Newtonsoft.Json.Linq;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync
{
    public class SDMClientPriorityTierSync
    {
        private ISDMClientPriorityTierReader _reader = null;
        private int _serviceHitCount = 0;

        public SDMClientPriorityTierSync(ISDMClientPriorityTierReader reader)
        {
            _reader = reader;
        }

        public void PublishSDMClientPriorityTierToMsd_SOAP(object message)
        {
            try
            {
                _serviceHitCount += 1;

                #region "VARIBLES"
                var sdmClientPriorityTiers = message != null ? (List<SDMClientPriorityTier>)message : null;
                var objCrmProxy = new CRMProxy.CRM();
                EntityCollection objUpdateAccountWithSdmClientPriorityTier = new EntityCollection();
                EntityCollection updateResult = new EntityCollection();

                var tblCrmResponse = new DataTable("CRMResponse");
                tblCrmResponse.Columns.Add("guid", typeof(Guid));
                tblCrmResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));
                #endregion

                #region "Populate MSD objects from datareader"
                CRMProxy.CrmEarlyBoundClasses.Account temp = new CRMProxy.CrmEarlyBoundClasses.Account();
                if (sdmClientPriorityTiers != null)

                    foreach (var sdmClientPriorityTier in sdmClientPriorityTiers)
                    {
                        temp = new CRMProxy.CrmEarlyBoundClasses.Account();
                        temp.Id = new Guid(sdmClientPriorityTier.ClientMSCRMID);
                        //temp.nwm_stagingId = sdmClientPriorityTier.StagingId;
                        temp.nwm_CIBCoverageModelId = new EntityReference(CRMProxy.CrmEarlyBoundClasses.nwm_accountpriority.EntityLogicalName, new Guid(sdmClientPriorityTier.PriorityMSCRMID));
                        objUpdateAccountWithSdmClientPriorityTier.Entities.Add(temp);
                    }
                #endregion

                #region "Update existing Priority Group List Tier, if required"
                if (objUpdateAccountWithSdmClientPriorityTier.Entities.Count > 0)
                {
                    updateResult = objCrmProxy.UpdateMultipleEntities_SOAP(objUpdateAccountWithSdmClientPriorityTier);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Entities.Count - 1; i++)
                    {
                        string val = updateResult[i]["accountid"].ToString();
                        tblCrmResponse.Rows.Add(val, sdmClientPriorityTiers[i].StagingId);
                    }
                }
                #endregion

                #region "update staging db"
                if (tblCrmResponse.Rows.Count > 0)
                {
                    bool syncresult = SyncMSCRMIDForSDMClientPriorityTier(tblCrmResponse);
                }
                #endregion

            }
            catch (Exception ex)
            {
                if (_serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishSDMClientPriorityTierToMsd_SOAP(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishSDMClientPriorityTierToMsd_SOAP(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }
        public void PublishSDMClientPriorityTierToMsd_REST(object message)
        {
            try
            {
                _serviceHitCount += 1;

                #region "VARIBLES"
                var sdmClientPriorityTiers = message != null ? (List<SDMClientPriorityTier>)message : null;
                var objCrmProxy = new CRMProxy.CRM();
                List<JObject> objSaveSdmClientPriorityTier = new List<JObject>();
                List<JObject> objUpdateSdmClientPriorityTier = new List<JObject>();
                List<JObject> objreSaveSdmClientPriorityTier = new List<JObject>();

                var tblCrmResponse = new DataTable("CRMResponse");
                tblCrmResponse.Columns.Add("guid", typeof(Guid));
                tblCrmResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

                List<JObject> saveResult = new List<JObject>();
                List<JObject> updateResult = new List<JObject>();
                List<JObject> reSaveResult = new List<JObject>();
                #endregion

                #region "Populate MSD objects from datareader"
                var temp = new JObject();
                if (sdmClientPriorityTiers != null)

                    foreach (var sdmClientPriorityTier in sdmClientPriorityTiers)
                    {
                        temp = new JObject();
                        temp.Add("id", sdmClientPriorityTier.ClientMSCRMID);
                        //temp.Add("nwm_stagingid", sdmClientPriorityTier.StagingId);
                        temp.Add("nwm_CIBCoverageModelId@odata.bind", "/nwm_accountpriorities(" + sdmClientPriorityTier.PriorityMSCRMID + ")");
                        objUpdateSdmClientPriorityTier.Add(temp);
                    }

                #endregion

                #region "Update existing Priority Group List Tier, if required"
                if (objUpdateSdmClientPriorityTier.Count > 0)
                {
                    updateResult = objCrmProxy.UpdateMultipleAccounts_REST(objUpdateSdmClientPriorityTier);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Count - 1; i++)
                    {
                        string val = updateResult[i]["id"].ToString();
                        tblCrmResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "update staging db"
                if (tblCrmResponse.Rows.Count > 0)
                {
                    bool syncresult = SyncMSCRMIDForSDMClientPriorityTier(tblCrmResponse);
                }
                #endregion

            }
            catch (Exception ex)
            {
                if (_serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishSDMClientPriorityTierToMsd_REST(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishSDMClientPriorityTierToMsd(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        /// <summary>
        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public bool SyncMSCRMIDForSDMClientPriorityTier(DataTable tblCRMResponse)
        {
            if (_reader == null)
                _reader = new SDMClientPriorityTierDataReader();

            //read connection string from config
            string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

            var result = _reader.SyncMSCRMIDForSDMClientPriorityTiers(connectionstring, tblCRMResponse);
            return result;
        }
    }
}
