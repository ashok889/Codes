﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RBS.CRM.FOS.DataServices.DataAccess;
using CRM.DataServices.DataAccess.Entities;
using Microsoft.Xrm.Sdk;
using System.Data;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using System.Configuration;
using RBS.CRM.FOS.DataServices.Common.Resources;
using RBS.CRM.FOS.DataServices.CRMProxy.CrmEarlyBoundClasses;
using Newtonsoft.Json.Linq;
using Rbs.Crm.FOS.CrmEarlyBoundClasses;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync
{
    /// <summary>
    /// Employee sync class provides Methods to update both CRM and database accordingly.
    /// </summary>
    public class EmployeeSync
    {
        private IEmployeeDataReader Reader = null;
        private int serviceHitCount = 0;

        public EmployeeSync(IEmployeeDataReader reader)
        {
            Reader = reader;
        }

        public void PublishEmployeestoMSD_SOAP(object message)
        {
            try
            {
                // -- to reissue webrequest we need to count, only thrice we will issue requests
                serviceHitCount += 1;

                #region "VARIBLES"      
                var EmployeeList = message != null ? (List<Employee>)message : null;

                CRMProxy.CRM objCRM = new CRMProxy.CRM();
                EntityCollection objSaveEmployeesCollection = new EntityCollection() { EntityName = nwm_Employee.EntityLogicalName };
                EntityCollection objUpdateEmployeesCollection = new EntityCollection() { EntityName = nwm_Employee.EntityLogicalName };
                EntityCollection objreSaveEmployeesCollection = new EntityCollection() { EntityName = nwm_Employee.EntityLogicalName };
                #endregion

                #region "Populate MSD objects from datareader"
                nwm_Employee temp;
                foreach (Employee Employee in EmployeeList)
                {
                    temp = new nwm_Employee();
                    temp.nwm_name = Employee.FirstName;
                    temp.nwm_LastName = Employee.LastName;
                    temp.nwm_MiddleName = Employee.MiddleName;
                    temp.nwm_StagingId = Employee.StagingId;
                    temp.nwm_Title = Employee.Title;
                    temp.nwm_JobTitle = Employee.JobTitle;
                    temp.nwm_CostCenterCode = Employee.CostCentreCode;
                    temp.nwm_EmailAddress = Employee.EmailAddress;
                    temp.nwm_PhoneNumber = Employee.FullNumber;
                    temp.nwm_ECDId = Employee.EmployeeId;

                    if (!string.IsNullOrEmpty(Employee.MSCRMID))
                    {
                        temp.statecode = Employee.EmployeeStatusDesc == "Leaver" ? nwm_EmployeeState.Inactive : nwm_EmployeeState.Active;
                        temp.statuscode = Employee.EmployeeStatusDesc == "Leaver" ? new Microsoft.Xrm.Sdk.OptionSetValue(2) : new Microsoft.Xrm.Sdk.OptionSetValue(1);

                        // Employee already exists on MS Dynamics as we have the GUID. So we need to send update command
                        temp.nwm_EmployeeId = new Guid(Employee.MSCRMID);
                        objUpdateEmployeesCollection.Entities.Add(temp);
                    }
                    else
                    {
                        // new Employee for MS Dynamics as we dont  have the GUID. We need to send insert command
                        objSaveEmployeesCollection.Entities.Add(temp);
                    }
                }
                #endregion

                #region "Sync MSD generate Id back to staging database"
                DataTable tblCRMResponse = new DataTable("CRMResponse");

                // -- we create column names as per the type in DB 
                tblCRMResponse.Columns.Add("guid", typeof(Guid));
                tblCRMResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

                // -- invoke MSD service with populated objects
                EntityCollection saveResult = new EntityCollection();
                EntityCollection updateResult = new EntityCollection();
                EntityCollection reSaveResult = new EntityCollection();
                if (objSaveEmployeesCollection.Entities.Count > 0)
                {
                    saveResult = objCRM.CreateMultipleEntities_SOAP(objSaveEmployeesCollection);

                    // -- checking for duplicate founds in savelist
                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Entities.Count - 1; saveResultCntr++)
                    {
                        if (1 == 0)
                        {
                            //-- to implement: handling when duplicate detection rules send back failure.
                        }
                        else
                        {
                            try
                            {
                                string val = saveResult[saveResultCntr]["id"].ToString();
                                tblCRMResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of Employee object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing Employees, if required"
                if (objUpdateEmployeesCollection.Entities.Count > 0)
                {
                    updateResult = objCRM.UpdateMultipleEntities_SOAP(objUpdateEmployeesCollection);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Entities.Count - 1; i++)
                    {
                        string val = updateResult[i]["nwm_employeeid"].ToString();
                        tblCRMResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSaveEmployeesCollection.Entities.Count > 0)
                {
                    reSaveResult = objCRM.CreateMultipleEntities_SOAP(objreSaveEmployeesCollection);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Entities.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["id"].ToString();
                        tblCRMResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCRMResponse.Rows.Count > 0)
                {
                    SyncMSCRMIDForEmployees(tblCRMResponse);
                }
                #endregion
            }
            catch (Exception ex)
            {
                if (serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishEmployeestoMSD_SOAP(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishEmployeestoMSD_SOAP(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        public void PublishEmployeestoMSD_REST(object message)
        {
            //try
            //{
            //    // -- to reissue webrequest we need to count, only thrice we will issue requests
            //    serviceHitCount += 1;

            //    #region "VARIBLES"      
            //    var EmployeeList = message != null ? (List<Employee>)message : null;
            //    #endregion

            //    #region "Populate MSD objects from datareader - JSON"
            //    var Employee = new JObject();
            //    // -- instantiate MSD related objects
            //    CRMProxy.CRM objCRM = new CRMProxy.CRM();
            //    List<JObject> objSaveEmployeesCollection = new List<JObject>();
            //    List<JObject> objUpdateEmployeesCollection = new List<JObject>();
            //    List<JObject> objreSaveEmployeesCollection = new List<JObject>();
            //    // -- invoke MSD service with populated objects
            //    List<JObject> saveResult = new List<JObject>();
            //    List<JObject> updateResult = new List<JObject>();
            //    List<JObject> reSaveResult = new List<JObject>();

            //    foreach (Employee Employee in EmployeeList)
            //    {
            //        Employee = new JObject();
            //        Employee.Add("name", Employee.Name);
            //        Employee.Add("nwm_sector", Employee.Sector);
            //        Employee.Add("nwm_subsector", Employee.SubSector);
            //        Employee.Add("nwm_classification", Employee.Classification);
            //        Employee.Add("nwm_domicile", Employee.Domicile);
            //        Employee.Add("nwm_geography", Employee.Geography);
            //        Employee.Add("nwm_sdmid", Employee.SDMId);
            //        Employee.Add("nwm_stagingid", Employee.StagingEmployeeId);

            //        // -- set parent if available
            //        if (Employee.ParentMSCRMId != null && Employee.ParentMSCRMId != Employee.MSCRMId)
            //        {
            //            Employee.Add("parentEmployeeid@odata.bind", "/Employees(" + Employee.ParentMSCRMId + ")");
            //        }

            //        switch (Employee.LevelId)
            //        {
            //            case 1:
            //                Employee.Add("nwm_level", 277810000); // -- L1
            //                break;
            //            case 2:
            //                Employee.Add("nwm_level", 277810001); // -- L2
            //                break;
            //            case 3:
            //                Employee.Add("nwm_level", 277810002); // -- L3
            //                break;
            //            case 4:
            //                Employee.Add("nwm_level", 277810003); // -- L4
            //                break;
            //            default:
            //                break;
            //        }

            //        Employee.Add("nwm_ciscode", Employee.CISCode);
            //        Employee.Add("nwm_matchname", Employee.Name + "*Level" + Employee.LevelId);


            //        if (Employee.MSCRMId != null && Employee.MSCRMId != string.Empty)
            //        {
            //            // Employee already exists on MS Dynamics as we have the GUID. So we need to send update command
            //            Employee.Add("id", new Guid(Employee.MSCRMId));
            //            objUpdateEmployeesCollection.Add(Employee);
            //        }
            //        else
            //        {
            //            // new Employee for MS Dynamics as we dont  have the GUID. We need to send insert command
            //            objSaveEmployeesCollection.Add(Employee);
            //        }
            //    }
            //    #endregion

            //    #region "Sync MSD generate Id back to staging database"
            //    DataTable tblCRMResponse = new DataTable("CRMResponse");

            //    // -- we create column names as per the type in DB 
            //    tblCRMResponse.Columns.Add("guid", typeof(Guid));
            //    tblCRMResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

            //    if (objSaveEmployeesCollection.Count > 0)
            //    {
            //        saveResult = objCRM.CreateMultipleEmployees_REST(objSaveEmployeesCollection);

            //        // -- checking for duplicate founds in savelist
            //        for (int saveResultCntr = 0; saveResultCntr <= saveResult.Count - 1; saveResultCntr++)
            //        {
            //            if (1 == 0)
            //            {
            //                //-- to implement: handling when duplicate detection rules send back failure.
            //            }
            //            else
            //            {
            //                try
            //                {
            //                    string val = saveResult[saveResultCntr]["id"].ToString();
            //                    tblCRMResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
            //                }
            //                catch (Exception ex)
            //                {
            //                    Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of Employee object.",
            //                        new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
            //                }
            //            }
            //        }
            //    }
            //    #endregion

            //    #region "Update existing Employees, if required"
            //    if (objUpdateEmployeesCollection.Count > 0)
            //    {
            //        updateResult = objCRM.UpdateMultipleEmployees_REST(objUpdateEmployeesCollection);

            //        // -- set successful updates for marking to synched
            //        for (int i = 0; i <= updateResult.Count - 1; i++)
            //        {
            //            string val = updateResult[i]["id"].ToString();
            //            tblCRMResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
            //        }
            //    }
            //    #endregion

            //    #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
            //    if (objreSaveEmployeesCollection.Count > 0)
            //    {
            //        reSaveResult = objCRM.CreateMultipleEmployees_REST(objreSaveEmployeesCollection);

            //        // -- set successful updates for marking to synched
            //        for (int i = 0; i <= reSaveResult.Count - 1; i++)
            //        {
            //            string val = reSaveResult[i]["id"].ToString();
            //            tblCRMResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
            //        }
            //    }
            //    #endregion

            //    #region "Update Staging DB"
            //    if (tblCRMResponse.Rows.Count > 0)
            //    {
            //        SyncMSCRMIDForEmployees(tblCRMResponse);
            //    }
            //    #endregion
            //}
            //catch (Exception ex)
            //{
            //    if (serviceHitCount <= 3)
            //    {
            //        // -- this can be a first hit null error. Try reposting it.
            //        PublishEmployeestoMSD_REST(message);
            //    }
            //    else
            //    {
            //        Logger.LogFatal("Error inside method PublishEmployeestoMSD_REST(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
            //    }
            //}
        }

        /// <summary>
        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public bool SyncMSCRMIDForEmployees(DataTable tblCRMResponse)
        {
            if (Reader == null)
                Reader = new EmployeeDataReader();

            //read connection string from config
            string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

            var result = Reader.SyncMSCRMIDForEmployees(connectionstring, tblCRMResponse);
            return result;
        }
    }
}
