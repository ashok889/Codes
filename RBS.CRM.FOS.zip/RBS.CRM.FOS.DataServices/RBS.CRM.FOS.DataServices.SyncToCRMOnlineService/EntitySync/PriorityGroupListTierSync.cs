﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using CRM.DataServices.DataAccess;
using CRM.DataServices.DataAccess.Entities;
using Microsoft.Xrm.Sdk;
using RBS.CRM.FOS.DataServices.DataAccess;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using RBS.CRM.FOS.DataServices.Common.Resources;
using Newtonsoft.Json.Linq;
using Rbs.Crm.FOS.CrmEarlyBoundClasses;
using RBS.CRM.FOS.DataServices.CRMProxy.CrmEarlyBoundClasses;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync
{
    public class PriorityGroupListTierSync
    {
        private IPriorityGroupListTierDataReader _reader = null;
        private int _serviceHitCount = 0;

        public PriorityGroupListTierSync(IPriorityGroupListTierDataReader reader)
        {
            _reader = reader;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void PublishPriorityGroupListTierToMsd_SOAP(object message)
        {
            try
            {
                _serviceHitCount += 1;

                #region "VARIBLES"
                var priorityGroupListTiers = message != null ? (List<PriorityGroupListTier>)message : null;
                var objCrmProxy = new CRMProxy.CRM();

                EntityCollection objSavePriorityGroupListTier = new EntityCollection();
                EntityCollection objUpdatePriorityGroupListTier = new EntityCollection();
                EntityCollection objreSavePriorityGroupListTier = new EntityCollection();

                var tblCrmResponse = new DataTable("CRMResponse");
                tblCrmResponse.Columns.Add("guid", typeof(Guid));
                tblCrmResponse.Columns.Add("EntityPrimaryKey", typeof(Int32)); ;

                EntityCollection saveResult = new EntityCollection();
                EntityCollection updateResult = new EntityCollection();
                EntityCollection reSaveResult = new EntityCollection();
                #endregion

                #region "Populate MSD objects from datareader"
                nwm_accountpriority temp = new nwm_accountpriority();

                if (priorityGroupListTiers != null)
                    foreach (var priorityGroupListTier in priorityGroupListTiers)
                    {
                        temp = new nwm_accountpriority();
                        temp.nwm_name = priorityGroupListTier.Name;
                        temp.nwm_AccountPriorityType = priorityGroupListTier.PriorityType;
                        temp.nwm_StagingId = priorityGroupListTier.StagingId;
                        if (!string.IsNullOrEmpty(priorityGroupListTier.ParentMSCRMId))
                        {
                            temp.nwm_ParentAccountPriority = new EntityReference(CRMProxy.CrmEarlyBoundClasses.nwm_accountpriority.EntityLogicalName, new Guid(priorityGroupListTier.ParentMSCRMId));
                        }

                        if (!string.IsNullOrEmpty(priorityGroupListTier.MSCRMId))
                        {
                            // Priority Group List Tier already exists on MS Dynamics as we have the GUID. So we need to send update command
                            temp.nwm_accountpriorityId = new Guid(priorityGroupListTier.MSCRMId);
                            objUpdatePriorityGroupListTier.Entities.Add(temp);
                        }
                        else
                        {
                            // new Priority Group List Tier for MS Dynamics as we dont  have the GUID. We need to send insert command
                            objSavePriorityGroupListTier.Entities.Add(temp);
                        }
                    }

                #endregion

                #region "Sync MSD generate Id back to staging database"
                if (objSavePriorityGroupListTier.Entities.Count > 0)
                {
                    saveResult = objCrmProxy.CreateMultipleEntities_SOAP(objSavePriorityGroupListTier);

                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Entities.Count - 1; saveResultCntr++)
                    {
                        if (1 == 0)
                        {

                        }
                        else
                        {
                            // -- save this MSCRM response in database
                            try
                            {
                                string val = saveResult[saveResultCntr]["id"].ToString();
                                tblCrmResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of PriorityGroupListTier object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing Priority Group List Tier, if required"
                if (objUpdatePriorityGroupListTier.Entities.Count > 0)
                {
                    updateResult = objCrmProxy.UpdateMultipleEntities_SOAP(objUpdatePriorityGroupListTier);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Entities.Count - 1; i++)
                    {
                        string val = updateResult[i]["nwm_accountpriorityid"].ToString();
                        tblCrmResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSavePriorityGroupListTier.Entities.Count > 0)
                {
                    reSaveResult = objCrmProxy.CreateMultipleEntities_SOAP(objreSavePriorityGroupListTier);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Entities.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["id"].ToString();
                        tblCrmResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCrmResponse.Rows.Count > 0)
                {
                    bool syncResult = SyncMSCRMIDForPriorityGroupListTier(tblCrmResponse);
                }
                #endregion

            }
            catch (Exception ex)
            {
                if (_serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishPriorityGroupListTierToMsd_SOAP(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PriorityGroupListTier(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        public void PublishPriorityGroupListTierToMsd_REST(object message)
        {
            try
            {
                _serviceHitCount += 1;

                #region "VARIBLES"
                var priorityGroupListTiers = message != null ? (List<PriorityGroupListTier>)message : null;
                var objCrmProxy = new CRMProxy.CRM();

                List<JObject> objSavePriorityGroupListTier = new List<JObject>();
                List<JObject> objUpdatePriorityGroupListTier = new List<JObject>();
                List<JObject> objreSavePriorityGroupListTier = new List<JObject>();

                var tblCrmResponse = new DataTable("CRMResponse");
                tblCrmResponse.Columns.Add("guid", typeof(Guid));
                tblCrmResponse.Columns.Add("EntityPrimaryKey", typeof(Int32)); ;

                List<JObject> saveResult = new List<JObject>();
                List<JObject> updateResult = new List<JObject>();
                List<JObject> reSaveResult = new List<JObject>();
                #endregion

                #region "Populate MSD objects from datareader"
                var temp = new JObject();
                if (priorityGroupListTiers != null)
                    foreach (var priorityGroupListTier in priorityGroupListTiers)
                    {
                        temp = new JObject();
                        temp.Add("nwm_name", priorityGroupListTier.Name);
                        temp.Add("nwm_accountprioritytype", priorityGroupListTier.PriorityType);
                        temp.Add("nwm_stagingid", priorityGroupListTier.StagingId);
                        if (!string.IsNullOrEmpty(priorityGroupListTier.ParentMSCRMId))
                        {

                            temp.Add("nwm_ParentAccountPriority@odata.bind", "/nwm_accountpriorities(" + priorityGroupListTier.ParentMSCRMId + ")");
                        }

                        if (!string.IsNullOrEmpty(priorityGroupListTier.MSCRMId))
                        {
                            // Priority Group List Tier already exists on MS Dynamics as we have the GUID. So we need to send update command
                            temp.Add("nwm_accountpriorityid", priorityGroupListTier.MSCRMId);
                            objUpdatePriorityGroupListTier.Add(temp);
                        }
                        else
                        {
                            // new Priority Group List Tier for MS Dynamics as we dont  have the GUID. We need to send insert command
                            objSavePriorityGroupListTier.Add(temp);
                        }
                    }
                #endregion

                #region "Sync MSD generate Id back to staging database"
                if (objSavePriorityGroupListTier.Count > 0)
                {
                    saveResult = objCrmProxy.CreateMultipleAccountPriority_REST(objSavePriorityGroupListTier);

                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Count - 1; saveResultCntr++)
                    {
                        if (1 == 0)
                        {

                        }
                        else
                        {
                            // -- save this MSCRM response in database
                            try
                            {
                                string val = saveResult[saveResultCntr]["nwm_accountpriorityid"].ToString();
                                tblCrmResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of PriorityGroupListTier object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing Priority Group List Tier, if required"
                if (objUpdatePriorityGroupListTier.Count > 0)
                {
                    updateResult = objCrmProxy.UpdateMultipleAccountPriority_REST(objUpdatePriorityGroupListTier);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Count - 1; i++)
                    {
                        string val = updateResult[i]["nwm_accountpriorityid"].ToString();
                        tblCrmResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSavePriorityGroupListTier.Count > 0)
                {
                    reSaveResult = objCrmProxy.CreateMultipleAccountPriority_REST(objreSavePriorityGroupListTier);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["nwm_accountpriorityid"].ToString();
                        tblCrmResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCrmResponse.Rows.Count > 0)
                {
                    bool syncResult = SyncMSCRMIDForPriorityGroupListTier(tblCrmResponse);
                }
                #endregion

            }
            catch (Exception ex)
            {
                if (_serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishPriorityGroupListTierToMsd_REST(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PriorityGroupListTier(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        /// <summary>
        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public bool SyncMSCRMIDForPriorityGroupListTier(DataTable tblCRMResponse)
        {
            if (_reader == null)
                _reader = new PriorityGroupListTierDataReader();

            //read connection string from config
            string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

            var result = _reader.SyncMSCRMIDForPriorityGroupListTier(connectionstring, tblCRMResponse);
            return result;
        }
    }
}
