﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RBS.CRM.FOS.DataServices.DataAccess;
using CRM.DataServices.DataAccess.Entities;
using Microsoft.Xrm.Sdk;
using System.Data;
using RBS.CRM.FOS.DataServices.Common;
using RBS.CRM.FOS.DataServices.Common.Exceptions;
using System.Configuration;
using RBS.CRM.FOS.DataServices.Common.Resources;
using RBS.CRM.FOS.DataServices.CRMProxy.CrmEarlyBoundClasses;
using Newtonsoft.Json.Linq;

namespace RBS.CRM.FOS.DataServices.SyncToCRMOnlineService.EntitySync
{
    /// <summary>
    /// Account sync class provides Methods to update both CRM and database accordingly.
    /// </summary>
    public class AccountSync
    {
        private IClientDataReader Reader = null;
        private int serviceHitCount = 0;
        private string PTTBaseURL = ConfigurationManager.AppSettings["PTTBaseURL"];
        public AccountSync(IClientDataReader reader)
        {
            Reader = reader;
        }

        public void PublishAccountstoMSD_SOAP(object message)
        {
            try
            {
                // -- to reissue webrequest we need to count, only thrice we will issue requests
                serviceHitCount += 1;

                #region "VARIBLES"      
                var clientList = message != null ? (List<Client>)message : null;

                CRMProxy.CRM objCRM = new CRMProxy.CRM();
                EntityCollection objSaveAccountsCollection = new EntityCollection() { EntityName = Account.EntityLogicalName };
                EntityCollection objUpdateAccountsCollection = new EntityCollection() { EntityName = Account.EntityLogicalName };
                EntityCollection objreSaveAccountsCollection = new EntityCollection() { EntityName = Account.EntityLogicalName };

                #endregion

                #region "Populate MSD objects from datareader"
                Account temp;
                foreach (Client client in clientList)
                {
                    temp = new Account();
                    temp.Name = client.Name;
                    temp.nwm_StagingId = client.StagingClientId;
                    temp.nwm_ciscode = client.CISCode;
                    temp.nwm_Classification = client.Classification;
                    temp.nwm_Domicile = client.Domicile;
                    temp.nwm_Geography = client.Geography;
                    temp.nwm_Sector = client.Sector;
                    temp.nwm_SubSector = client.SubSector;
                    temp.nwm_SdmId = client.SDMId;
                    temp.nwm_MatchName = client.Name + "*Level" + client.LevelId;
                    
                    if (!string.IsNullOrEmpty(PTTBaseURL) && !string.IsNullOrEmpty(client.CISCode))
                    {   
                        temp.nwm_agilemarketurl = PTTBaseURL + client.CISCode;
                    }

                    switch (client.LevelId)
                    {
                        case 1:
                            temp.nwm_Level = new Microsoft.Xrm.Sdk.OptionSetValue(277810000); // -- L1
                            break;
                        case 2:
                            temp.nwm_Level = new Microsoft.Xrm.Sdk.OptionSetValue(277810001); // -- L2
                            break;
                        case 3:
                            temp.nwm_Level = new Microsoft.Xrm.Sdk.OptionSetValue(277810002); // -- L3
                            break;
                        case 4:
                            temp.nwm_Level = new Microsoft.Xrm.Sdk.OptionSetValue(277810003); // -- L4
                            break;
                        default:
                            break;
                    }

                    // -- set parent if available
                    if (!string.IsNullOrEmpty(client.ParentMSCRMId) && client.ParentMSCRMId != client.MSCRMId)
                    {
                        temp.ParentAccountId = new EntityReference(Account.EntityLogicalName,
                            new Guid(client.ParentMSCRMId));
                    }

                    // -- set ultimate L1 parent if available
                    if (!string.IsNullOrEmpty(client.UltimateParentMSCRMId) && client.UltimateParentMSCRMId != client.MSCRMId)
                    {
                        temp.nwm_UltimateL1Parent = new EntityReference(Account.EntityLogicalName,
                            new Guid(client.UltimateParentMSCRMId));
                    }

                    if (client.MSCRMId != null && client.MSCRMId != string.Empty)
                    {
                        // client already exists on MS Dynamics as we have the GUID. So we need to send update command
                        temp.AccountId = new Guid(client.MSCRMId);
                        objUpdateAccountsCollection.Entities.Add(temp);
                    }
                    else
                    {
                        // new client for MS Dynamics as we dont  have the GUID. We need to send insert command
                        objSaveAccountsCollection.Entities.Add(temp);
                    }
                }
                #endregion

                #region "Sync MSD generate Id back to staging database"
                DataTable tblCRMResponse = new DataTable("CRMResponse");

                // -- we create column names as per the type in DB 
                tblCRMResponse.Columns.Add("guid", typeof(Guid));
                tblCRMResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

                // -- invoke MSD service with populated objects
                EntityCollection saveResult = new EntityCollection();
                EntityCollection updateResult = new EntityCollection();
                EntityCollection reSaveResult = new EntityCollection();
                if (objSaveAccountsCollection.Entities.Count > 0)
                {
                    saveResult = objCRM.CreateMultipleEntities_SOAP(objSaveAccountsCollection);

                    // -- checking for duplicate founds in savelist
                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Entities.Count - 1; saveResultCntr++)
                    {
                        if (1 == 0)
                        {
                            //-- to implement: handling when duplicate detection rules send back failure.
                        }
                        else
                        {
                            try
                            {
                                string val = saveResult[saveResultCntr]["id"].ToString();
                                tblCRMResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of Account object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing accounts, if required"
                if (objUpdateAccountsCollection.Entities.Count > 0)
                {
                    updateResult = objCRM.UpdateMultipleEntities_SOAP(objUpdateAccountsCollection);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Entities.Count - 1; i++)
                    {
                        string val = updateResult[i]["accountid"].ToString();
                        tblCRMResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSaveAccountsCollection.Entities.Count > 0)
                {
                    reSaveResult = objCRM.CreateMultipleEntities_SOAP(objreSaveAccountsCollection);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Entities.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["id"].ToString();
                        tblCRMResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCRMResponse.Rows.Count > 0)
                {
                    SyncMSCRMIDForClients(tblCRMResponse);
                }
                #endregion
            }
            catch (Exception ex)
            {
                if (serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishAccountstoMSD_SOAP(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishAccountstoMSD_SOAP(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        public void PublishAccountstoMSD_REST(object message)
        {
            try
            {
                // -- to reissue webrequest we need to count, only thrice we will issue requests
                serviceHitCount += 1;

                #region "VARIBLES"      
                var clientList = message != null ? (List<Client>)message : null;
                #endregion

                #region "Populate MSD objects from datareader - JSON"
                var account = new JObject();
                // -- instantiate MSD related objects
                CRMProxy.CRM objCRM = new CRMProxy.CRM();
                List<JObject> objSaveAccountsCollection = new List<JObject>();
                List<JObject> objUpdateAccountsCollection = new List<JObject>();
                List<JObject> objreSaveAccountsCollection = new List<JObject>();
                // -- invoke MSD service with populated objects
                List<JObject> saveResult = new List<JObject>();
                List<JObject> updateResult = new List<JObject>();
                List<JObject> reSaveResult = new List<JObject>();

                foreach (Client client in clientList)
                {
                    account = new JObject();
                    account.Add("name", client.Name);
                    account.Add("nwm_sector", client.Sector);
                    account.Add("nwm_subsector", client.SubSector);
                    account.Add("nwm_classification", client.Classification);
                    account.Add("nwm_domicile", client.Domicile);
                    account.Add("nwm_geography", client.Geography);
                    account.Add("nwm_sdmid", client.SDMId);
                    account.Add("nwm_stagingid", client.StagingClientId);

                    // -- set parent if available
                    if (client.ParentMSCRMId != null && client.ParentMSCRMId != client.MSCRMId)
                    {
                        account.Add("parentaccountid@odata.bind", "/accounts(" + client.ParentMSCRMId + ")");
                    }

                    if (client.UltimateParentMSCRMId != null && client.UltimateParentMSCRMId != client.MSCRMId)
                    {
                        account.Add("nwm_ultimatel1parent@odata.bind", "/accounts(" + client.UltimateParentMSCRMId + ")");
                    }

                    switch (client.LevelId)
                    {
                        case 1:
                            account.Add("nwm_level", 277810000); // -- L1
                            break;
                        case 2:
                            account.Add("nwm_level", 277810001); // -- L2
                            break;
                        case 3:
                            account.Add("nwm_level", 277810002); // -- L3
                            break;
                        case 4:
                            account.Add("nwm_level", 277810003); // -- L4
                            break;
                        default:
                            break;
                    }

                    account.Add("nwm_ciscode", client.CISCode);
                    account.Add("nwm_matchname", client.Name + "*Level" + client.LevelId);


                    if (client.MSCRMId != null && client.MSCRMId != string.Empty)
                    {
                        // client already exists on MS Dynamics as we have the GUID. So we need to send update command
                        account.Add("id", new Guid(client.MSCRMId));
                        objUpdateAccountsCollection.Add(account);
                    }
                    else
                    {
                        // new client for MS Dynamics as we dont  have the GUID. We need to send insert command
                        objSaveAccountsCollection.Add(account);
                    }
                }
                #endregion

                #region "Sync MSD generate Id back to staging database"
                DataTable tblCRMResponse = new DataTable("CRMResponse");

                // -- we create column names as per the type in DB 
                tblCRMResponse.Columns.Add("guid", typeof(Guid));
                tblCRMResponse.Columns.Add("EntityPrimaryKey", typeof(Int32));

                if (objSaveAccountsCollection.Count > 0)
                {
                    saveResult = objCRM.CreateMultipleAccounts_REST(objSaveAccountsCollection);

                    // -- checking for duplicate founds in savelist
                    for (int saveResultCntr = 0; saveResultCntr <= saveResult.Count - 1; saveResultCntr++)
                    {

                        if (1 == 0)
                        {
                            //-- to implement: handling when duplicate detection rules send back failure.
                        }
                        else
                        {
                            try
                            {
                                string val = saveResult[saveResultCntr]["id"].ToString();
                                tblCRMResponse.Rows.Add(val, saveResult[saveResultCntr]["nwm_stagingid"].ToString());
                            }
                            catch (Exception ex)
                            {
                                Logger.LogFatal("Could not retrieve GUID from response. Possible Fault was returned instead of Account object.",
                                    new SynchServiceException(ex.Message, ex.InnerException), LoggerMessages.SyncToCRMOnlineService);
                            }
                        }
                    }
                }
                #endregion

                #region "Update existing accounts, if required"
                if (objUpdateAccountsCollection.Count > 0)
                {
                    updateResult = objCRM.UpdateMultipleAccounts_REST(objUpdateAccountsCollection);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= updateResult.Count - 1; i++)
                    {
                        string val = updateResult[i]["id"].ToString();
                        tblCRMResponse.Rows.Add(val, updateResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Second attempt for save, if required (in case updating any record(s) in batch has caused error in saving of other remaining save records)"
                if (objreSaveAccountsCollection.Count > 0)
                {
                    reSaveResult = objCRM.CreateMultipleAccounts_REST(objreSaveAccountsCollection);

                    // -- set successful updates for marking to synched
                    for (int i = 0; i <= reSaveResult.Count - 1; i++)
                    {
                        string val = reSaveResult[i]["id"].ToString();
                        tblCRMResponse.Rows.Add(val, reSaveResult[i]["nwm_stagingid"].ToString());
                    }
                }
                #endregion

                #region "Update Staging DB"
                if (tblCRMResponse.Rows.Count > 0)
                {
                    SyncMSCRMIDForClients(tblCRMResponse);
                }
                #endregion
            }
            catch (Exception ex)
            {
                if (serviceHitCount <= 3)
                {
                    // -- this can be a first hit null error. Try reposting it.
                    PublishAccountstoMSD_REST(message);
                }
                else
                {
                    Logger.LogFatal("Error inside method PublishAccountstoMSD_REST(): " + ex.Message, new SynchServiceException(ex.Message, ex), LoggerMessages.SyncToCRMOnlineService);
                }
            }
        }

        /// <summary>
        /// For dequing data from db
        /// </summary>
        /// <returns></returns>
        public bool SyncMSCRMIDForClients(DataTable tblCRMResponse)
        {
            if (Reader == null)
                Reader = new ClientDataReader();

            //read connection string from config
            string connectionstring = ConfigurationManager.ConnectionStrings["CRMStaging"] != null ? ConfigurationManager.ConnectionStrings["CRMStaging"].ToString() : null;

            var result = Reader.SyncMSCRMIDForClients(connectionstring, tblCRMResponse);
            return result;
        }
    }
}
