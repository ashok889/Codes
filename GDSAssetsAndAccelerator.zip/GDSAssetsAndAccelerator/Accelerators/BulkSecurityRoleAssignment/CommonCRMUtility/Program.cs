﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Diagnostics;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Crm.Sdk.Messages;
using System.Configuration;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Threading;
using CommonCrmUtility.Security;



namespace CommonCRMUtility
{
    class Program
    {
        private static DefaultLogger _defaultLogger = new DefaultLogger();
        private static System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
        private static bool error = false;
        static void Main(string[] args)
        {
           var v =  DataProtect.EncryptString("Ashok@123");
            _defaultLogger.Info("STARTS EXECUTION");
            string xmlDocpath = string.Empty;
            bool useNamedConnections = false;
            List<string> conns = new List<string>();
            string branch = string.Empty;
            if (args.Length > 0)
            {
                for (int counter = 0; counter < args.Length; counter++)
                {
                    if (args[counter].Contains("config-"))
                    {
                        xmlDocpath = args[counter].Split('-')[1].Trim();
                        useNamedConnections = true;
                    }
                    else if (args[counter].Contains("conn-"))
                        conns.Add(args[counter].Split('-')[1].Trim());
                    else if (args[counter].Contains("branch-"))
                        branch = args[counter].Split('-')[1].Trim();
                }
            }

            if (string.IsNullOrEmpty(xmlDocpath))
                // Reads Config.xml, connects to the specified crmconnection and executes all the Run nodes
                xmlDocpath = "Config.xml";
            XDocument xDoc = XDocument.Load(xmlDocpath);
            _defaultLogger.Info("Loaded config file: " + xmlDocpath);

            /***logic to manipulate the args[] to contain only the crmconnectionid and remove config file path from args if it exists***/
            if (conns.Count > 0)
                args = conns.ToArray();//in case of using cofig file from a different location and if we want to pass connections also as arguments make sure to use named connections in format conn-connectionId

            //no config and no connection sent as parameters indicates --> args.length==0
            //or no connection but parametrised config file which means args contains data
            else if (args.Length == 0 || useNamedConnections)
            {
                //if no connections passed fetch all crm connections from the config file
                var ConnNode = xDoc.Element("Config")
                              .Element("crmconnections")
                              .Elements()
                              .Where(x => x.Attribute("execute").Value.ToLower() == "true");
                if (ConnNode != null && ConnNode.Count() > 0)
                {
                    foreach (var connString in ConnNode)
                    {
                        conns.Add(connString.Attribute("id").Value);
                        _defaultLogger.Info("Loads connection: " + connString.Attribute("id").Value.ToString());
                    }
                }
                args = conns.ToArray();
            }
            //next case only unnmaed connections && no config--->so all values in args are already connectionids
            //No Implementation reqd  as args already contains only connectionid without prefix name conn-
            /** end logic to manipulate the args contents**/
            try
            {

                var runNodes = from nodeSet in xDoc.Element("Config").Element("Run").Elements()
                               where nodeSet.Element("execute").Value.ToLower() == "true"
                               select nodeSet;
                for (int argCount = 0; argCount < args.Length; argCount++)
                {

                    List<RolesAssign> _lstUsrRoles = new List<RolesAssign>();
                    List<RolesAssign> _lstTeamRoles = new List<RolesAssign>();


                    foreach (var node in runNodes)
                    {
                        try

                        {
                            _defaultLogger.Info("Starts execution of node: " + node.Name.LocalName.ToString());
                            switch (node.Name.LocalName)
                            {
                                
                                case "AssignSecurityRoleToUser":
                                    RolesAssign _usrRoleMap = new RolesAssign();
                                    _usrRoleMap.Flag = Convert.ToString(node.Descendants("Action").FirstOrDefault().Value);
                                    _usrRoleMap.Name = Convert.ToString(node.Descendants("UserName").FirstOrDefault().Value);
                                    _usrRoleMap.RoleName = Convert.ToString(node.Descendants("RoleName").FirstOrDefault().Value);
                                    _lstUsrRoles.Add(_usrRoleMap);
                                    break;
                                case "AssignSecurityRoleToTeam":
                                    RolesAssign _teamRoleMap = new RolesAssign();
                                    _teamRoleMap.Flag = Convert.ToString(node.Descendants("Action").FirstOrDefault().Value);
                                    _teamRoleMap.Name = Convert.ToString(node.Descendants("TeamName").FirstOrDefault().Value);
                                    _teamRoleMap.RoleName = Convert.ToString(node.Descendants("RoleName").FirstOrDefault().Value);
                                    _lstTeamRoles.Add(_teamRoleMap);
                                    break;                               
                                 
                                default:
                                    _defaultLogger.Info(string.Format("No implementation found for node {0}.", node.Name.LocalName));
                                    break;
                            }
                            _defaultLogger.Info("Ends execution of node: " + node.Name.LocalName.ToString());
                        }
                        catch (Exception ex)
                        {
                            _defaultLogger.Error(ex);
                            error = true;
                        }
                    }
                    if (_lstUsrRoles.Count > 0)
                    {
                        FetchAndAssignUserRoleMaping(_lstUsrRoles, args[argCount], xDoc);
                    }
                    if (_lstTeamRoles.Count > 0)
                        FetchAndAssignTeamRole(args[argCount], _lstTeamRoles, xDoc);
                     
                }

                if (error)
                    throw new Exception("Error: Check Error log lines");
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
                throw;
            }
            finally
            {
                //update the current date time as last runtime
                SaveXmlDocument(xDoc, xmlDocpath);
                _defaultLogger.Info("ENDS EXECUTION");
                _defaultLogger.Info("");
            }
        }

        private static void FetchAndAssignUserRoleMaping(List<RolesAssign> _lstRoles, string args, XDocument document)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4};RedirectUri={5};AppId={6};LoginPrompt={7}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value, "app://58145B91-0C36-4500-8554-080854F2AC97",
              "51f81489-12ee-4a9e-aaae-a2591f45987d", "Auto");

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
                error = true;
            }
            else
            {
                List<BURoleMapping> _lstBURole = new List<BURoleMapping>();
                var distinctuser = _lstRoles.Select(x => x.Name).Distinct();
                QueryExpression queryUser = new QueryExpression("systemuser");
                queryUser.NoLock = true;
                queryUser.ColumnSet = new ColumnSet("domainname", "businessunitid");
                queryUser.Criteria.AddCondition(new ConditionExpression("domainname", ConditionOperator.In, distinctuser.ToArray()));
                EntityCollection UserCollection = service.RetrieveMultiple(queryUser);
                if (UserCollection != null && UserCollection.Entities != null && UserCollection.Entities.Count > 0)
                {
                    foreach (var item in UserCollection.Entities)
                    {
                        string useremail = item.GetAttributeValue<string>("domainname");
                        var users = _lstRoles.Where(x => x.Name.ToLower() == useremail.ToLower());
                        foreach (var usrItem in users)
                        {
                            usrItem.EntityId = item.Id;
                            usrItem.EntityBuId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                        }
                    }
                    var distinctRoles = _lstRoles.Select(x => x.RoleName).Distinct();
                    _defaultLogger.Info("Fetching the security roles from CRM...");
                    QueryExpression queryRole = new QueryExpression("role");
                    queryRole.NoLock = true;
                    queryRole.ColumnSet = new ColumnSet("name", "businessunitid");
                    queryRole.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctRoles.ToArray()));
                    EntityCollection RolesCollection = service.RetrieveMultiple(queryRole);
                    if (RolesCollection != null && RolesCollection.Entities != null && RolesCollection.Entities.Count > 0)
                    {
                        foreach (var item in RolesCollection.Entities)
                        {
                            BURoleMapping BUroles = new BURoleMapping();
                            BUroles.RoleName = item.GetAttributeValue<string>("name");
                            BUroles.BUId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                            BUroles.RoleId = item.Id;
                            _lstBURole.Add(BUroles);

                        }
                        if (_lstBURole.Count > 0)
                        {
                            foreach (var rolItem in _lstRoles)
                            {
                                List<BURoleMapping> _buRole = _lstBURole.Where(i => i.BUId == rolItem.EntityBuId && i.RoleName.ToLower() == rolItem.RoleName.ToLower()).ToList();
                                if (_buRole != null && _buRole.Count > 0)
                                {
                                    rolItem.RoleId = _buRole.FirstOrDefault().RoleId;
                                    AssignRole(rolItem.Flag, rolItem.EntityId, rolItem.RoleId, "systemuser", "systemuserroles_association", service);
                                }
                            }
                        }
                    }
                    else
                        _defaultLogger.Info("Role is empty from CRM. Please check the role names and try again");
                }
            }
        }

        private static void FetchAndAssignTeamRole(string args, List<RolesAssign> _lstRoles, XDocument document)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4};RedirectUri={5};AppId={6};LoginPrompt={7}",
               getNode.Attribute("requirenewinstance").Value,
               getNode.Attribute("organizationurl").Value,
               getNode.Attribute("crmuserid").Value,
               DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
               getNode.Attribute("authtype").Value, "app://58145B91-0C36-4500-8554-080854F2AC97",
               "51f81489-12ee-4a9e-aaae-a2591f45987d", "Auto");

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
                error = true;
            }
            else
            {
                List<BURoleMapping> _lstBURole = new List<BURoleMapping>();
                var distinctuser = _lstRoles.Select(x => x.Name).Distinct();
                QueryExpression queryTeam = new QueryExpression("team");
                queryTeam.NoLock = true;
                queryTeam.ColumnSet = new ColumnSet("name", "businessunitid");
                queryTeam.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctuser.ToArray()));
                queryTeam.Criteria.AddCondition(new ConditionExpression("teamtype", ConditionOperator.Equal, 0));//owner teams only
                EntityCollection UserCollection = service.RetrieveMultiple(queryTeam);
                if (UserCollection != null && UserCollection.Entities != null && UserCollection.Entities.Count > 0)
                {
                    foreach (var item in UserCollection.Entities)
                    {
                        string useremail = item.GetAttributeValue<string>("name");
                        var users = _lstRoles.Where(x => x.Name.ToLower() == useremail.ToLower());
                        foreach (var usrItem in users)
                        {
                            usrItem.EntityId = item.Id;
                            usrItem.EntityBuId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                        }
                    }
                    var distinctRoles = _lstRoles.Select(x => x.RoleName).Distinct();
                    _defaultLogger.Info("Fetching the security roles from CRM...");
                    QueryExpression queryRole = new QueryExpression("role");
                    queryRole.NoLock = true;
                    queryRole.ColumnSet = new ColumnSet("name", "businessunitid");
                    queryRole.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctRoles.ToArray()));
                    EntityCollection RolesCollection = service.RetrieveMultiple(queryRole);
                    if (RolesCollection != null && RolesCollection.Entities != null && RolesCollection.Entities.Count > 0)
                    {
                        foreach (var item in RolesCollection.Entities)
                        {
                            BURoleMapping BUroles = new BURoleMapping();
                            BUroles.RoleName = item.GetAttributeValue<string>("name");
                            BUroles.BUId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                            BUroles.RoleId = item.Id;
                            _lstBURole.Add(BUroles);

                        }
                        if (_lstBURole.Count > 0)
                        {
                            foreach (var rolItem in _lstRoles)
                            {
                                _defaultLogger.Info("Assigning the role " + rolItem.RoleName + " to the team : " + rolItem.Name);
                                List<BURoleMapping> _buRole = _lstBURole.Where(i => i.BUId == rolItem.EntityBuId && i.RoleName.ToLower() == rolItem.RoleName.ToLower()).ToList();
                                if (_buRole != null && _buRole.Count > 0)
                                {
                                    rolItem.RoleId = _buRole.FirstOrDefault().RoleId;
                                    AssignRole(rolItem.Flag, rolItem.EntityId, rolItem.RoleId, "team", "teamroles_association", service);
                                }
                                else
                                {
                                    _defaultLogger.Info("Role Id returned null for role :" + rolItem.RoleName);
                                }
                            }
                        }
                    }
                    else
                        _defaultLogger.Info("Role is empty from CRM. Please check the role names and try again");
                }
            }
        }

        public static void SaveXmlDocument(XDocument document, string docPath)
        {
            if (document.Element("Config").Element("Variables") != null)
            {

                var getLastExecutionTimeNode = document.Element("Config")
                  .Element("Variables")
                  .Elements();

                if (getLastExecutionTimeNode.Any() && getLastExecutionTimeNode.Where(x => x.Name.LocalName.ToLower() == "lastexecutiondatetime").Count() != 0)
                {
                    var LastExecElemenct = getLastExecutionTimeNode.Where(x => x.Name.LocalName.ToLower() == "lastexecutiondatetime").FirstOrDefault();
                    LastExecElemenct.Value = DateTime.UtcNow.ToString("s");
                }
                else
                {
                    //create the child node
                    var variableElement = document.Element("Config").Element("Variables");
                    variableElement.Add(new XElement("LastExecutionDateTime", DateTime.UtcNow.ToString("s")));
                }
            }
            else
            //create the variable
            {
                XElement root = new XElement("Variables");
                root.Add(new XElement("LastExecutionDateTime", DateTime.UtcNow.ToString("s")));
                document.Element("Config").Add(root);
            }
            try
            {
                document.Save(docPath);
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
                error = true;
            }
        }

        public static void AssignRole(string flg, Guid referenceId, Guid RoleId, string EntityName, String RelationShipName, CrmServiceClient service)
        {
            try
            {
                if (flg.ToLower() == "add")
                {
                    
                    service.Associate(
                    EntityName,
                    referenceId,
                    new Relationship(RelationShipName),
                    new EntityReferenceCollection() { new EntityReference("role", RoleId) });
                }
                else if (flg.ToLower() == "remove")
                {
                    
                    service.Disassociate(
            EntityName,
            referenceId,
            new Relationship(RelationShipName),
            new EntityReferenceCollection() { new EntityReference("role", RoleId) });
                }
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
                error = true;
            }
        }
    }
}
