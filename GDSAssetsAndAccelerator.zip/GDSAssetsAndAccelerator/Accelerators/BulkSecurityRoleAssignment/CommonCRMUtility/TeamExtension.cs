﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonCRMUtility
{
   public  class TeamExtension
    {
    }
    public class BURoleMapping
    {
        public Guid BUId { get; set; }
        public Guid RoleId { get; set; }
        public String RoleName { get; set; }
    }
    public class RolesAssign
    {
        public string RoleName { get; set; }
        public Guid RoleId { get; set; }
        public Guid EntityId { get; set; }
        public Guid EntityBuId { get; set; }
        public string Name { get; set; }
        public string Flag { get; set; }
    }

}
