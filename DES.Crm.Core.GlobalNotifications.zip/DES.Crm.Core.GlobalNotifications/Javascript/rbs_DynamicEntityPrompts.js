﻿//==================================================
// Declarations
//==================================================
//Array for fetchxml
var FetchXMLArray_ForPrompts = [];
var FinalDisplayList_ForPrompts = [];
var displayNotificaitonId = [];
var displayfinalmessage = [];
var displayNotificationType = [];
var displayrecipientType = [];
var displayrecipientArray = [];
var displayNotificaitonId1 = [];
var displayfinalmessage1 = [];
var displayNotificationType1 = [];
var displayrecipientType1 = [];
var displayrecipientArray1 = [];
var notificationId;
var PROMPTNOTIFICATION = "859770001";
var PRIMARYRECIPIENT = "859770000";
var SECONDARYRECIPIENT = "859770001";
var InfoNotificationType = "859770000";
var WarningNotificationType = "859770001";
var ErrorNotificationType = "859770002";
var SuccessNotificationType = "859770003";
var LoadingNotificationType = "859770004";
var QuestionNotificationType = "859770005";
var ACTIONTYPEJAVASCRIPT = "859770000";
var ACTIONTYPEWORKFLOW = "859770001";
var ACTIONTYPEACTION = "859770002";
var notificationRecipientId;
var PROMPTENABLED = "1";
var ACTIVECASE = "0";
var caseStatus;
var notification;

//Web API Function
var WebApiUtility = WebApiUtility || {};
WebApiUtility.GetRequest = function (query, mode) {
    var results = null;
    if (query != null && mode != null) {
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.0/" + query, mode);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    results = JSON.parse(this.response);
                }
            }
        };
        req.send();
    }
    return results;
};
//==========================================================
// Globally get the information of the User and Entity Id
//==========================================================
//var currentUserId = Xrm.Page.context.getUserId();
var currentUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
currentUserId = currentUserId.slice(1, -1);
caseId = caseId.slice(1, -1);
//==============================================================
// Get Case Notification by Category
//  This function will get the Cases and their Notifications  
//==============================================================
function GetCaseNotifications(econtext) {
    var formContext = econtext.getFormContext();
    var caseId = formContext.data.entity.getId();
    var queryForFetchXML;
    var queryCategory;
    var FetchedCategories;
    var notificationCategory;
    var notificationId;
    var strUIMessage;
    var recipientType;
    var notificationType;
    var finalMessage;
    var currentdate = formatDate(new Date());
    var p = 0;
    var q = 0;// Deliberately declaring this index because there may not be same number of prompts as fetchxml
    var arrayElement = 0; //Element specifically initialized for Displaying prompt messages
    var checkCaseStatusQuery;
    //==========================================================
    // Get the Notification only if the current Case is ACTIVE
    //=========================================================    
    debugger
    checkCaseStatusQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                               "<entity name='incident'>" +
                                     "<attribute name='statecode' />" +
                                        "<filter type='and'>" +
                                         "<condition attribute='incidentid' operator='eq' value='" + caseId + "' />" +
                                     "</filter>" +
                               "</entity>" +
                               "</fetch>";

    //var FetchCaseStatus = XrmServiceToolkit.Soap.Fetch(checkCaseStatusQuery);
    var encodedCaseFetchXML = encodeURIComponent(checkCaseStatusQuery);
    var casefetchXMLResult = WebApiUtility.GetRequest("incidents?fetchXml=" + encodedCaseFetchXML, false);
    if (casefetchXMLResult != undefined && casefetchXMLResult != null && casefetchXMLResult.value[0] != undefined) {
        //caseStatus = FetchCaseStatus[0].attributes["statecode"].value;
        caseStatus = casefetchXMLResult.value[0].statecode;
    }
    if (caseStatus == ACTIVECASE) // ONLY IF the CASE IS ACTIVE NOTIFICATION NEEDS TO COME UP
    {
        //==========================================================================
        // Fetch the Notifications of the Categories & Fetchxml pertaining to them
        //==========================================================================
        queryForFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                               "<entity name='rbs_notification'>" +
                               "<attribute name='rbs_notificationid' />" +
                               "<filter type='and'>" +
                                   "<condition attribute='rbs_notificationdisplaytype' operator='eq' value='" + PROMPTNOTIFICATION + "' />" + //Prompt                                                           
                                   "<condition attribute='rbs_promptenabled' operator='eq' value='" + PROMPTENABLED + "' />" + //Prompt Enabled = Yes
                                   "<condition attribute='rbs_regarding' operator='eq' value='" + caseId + "' />" +
                               "</filter>" +
                               "<link-entity name='rbs_notificationcategories' alias='notificationcategory' link-type='inner' to='rbs_notificationcategoryid' from='rbs_notificationcategoriesid'>" +
                                   "<attribute name='rbs_fetchcriteria'/>" + // FETCH CRITERIA ATTRIBUTE
                                   "<filter type='and'>" +
                                       "<condition attribute='rbs_fetchcriteria' operator='not-null'/>" +
                                   "</filter>" +
                               "</link-entity>" +
							   "<link-entity name='rbs_notificationrecipient' from='rbs_notification' to='rbs_notificationid' alias='recipient'>" +
									"<attribute name='rbs_notificationrecipientid' />" +
									"<attribute name='rbs_recipienttype' />" +
									"<attribute name='rbs_user' />" +
									"<filter type='and'>" +
										"<condition attribute='rbs_user' operator='eq' value=' " + currentUserId + "' />" +
										"<condition attribute='rbs_lastacknowledgedon' operator='null' />" +
									"</filter>" +
									"</link-entity>" +
                               "</entity>" +
                               "</fetch>";
        //==========================================================================
        // Replace the fetchxml with appropriate variables
        //==========================================================================
        //var FetchedNotifications = XrmServiceToolkit.Soap.Fetch(queryForFetchXML);
        var encodedNotificationFetchXML = encodeURIComponent(queryForFetchXML);
        var notificationfetchXMLResult = WebApiUtility.GetRequest("rbs_notifications?fetchXml=" + encodedNotificationFetchXML, false);
        if (notificationfetchXMLResult.value.length > 0) {
            for (i = 0; i < notificationfetchXMLResult.value.length; i++) {
                if (notificationfetchXMLResult.value[i]["notificationcategory.rbs_fetchcriteria"] != null) {
                    FetchXMLArray_ForPrompts[i] = notificationfetchXMLResult.value[i]["notificationcategory.rbs_fetchcriteria"];

                }
            }
        }
        FetchXMLArray_ForPrompts = FetchXMLArray_ForPrompts.filter(function (item, index, inputArray) {
            return inputArray.indexOf(item) == index;
        });

        //******************************************Team Notifation ******************************//
        //==========================================================
        //Get FetchXML for Query Team Notification
        //====================================================
        var queryTeamNotifications = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                    "<entity name='rbs_notification'>" +
                       "<attribute name='rbs_notificationid' />" +
                       "<attribute name='rbs_notificationtype' />" +
                        "<attribute name='rbs_notificationmessageid' />" +
                       "<attribute name='rbs_notificationcategoryid' />" +
                      "<attribute name='rbs_reactivationperiod' />" +
                       "<attribute name='rbs_notificationdisplaytype' />" +
                         "<attribute name='rbs_notificationpriority' />" +
                         "<attribute name='rbs_regarding' />" +
                      "<order attribute='rbs_name' descending='false' />" +
                         "<filter type='and'>" +
                         "<condition attribute='rbs_notificationdisplaytype' operator='in'>" +
                                          "<value>859770001</value>" +
                                        "</condition>" +
                                      "<condition attribute='rbs_applicablefrom' operator='le' value='" + formatDate(new Date()) + "' />" +
                                      "<condition attribute='rbs_regarding' operator='eq' value= '" + caseId + "' />" +
                                      "<filter type='or'>" +
                                          "<condition attribute='rbs_notificationexpiredon' operator='null' />" +
                                       "</filter>" +
                                       "<filter type='or'>" +
                                          "<condition attribute='rbs_applicabletill' operator='null' />" +
                                          "<condition attribute='rbs_applicabletill' operator='ge' value='" + formatDate(new Date()) + "' />" +
                                        "</filter>" +
                              "</filter>" +
                               "<link-entity name='rbs_notificationcategories' from='rbs_notificationcategoriesid' to='rbs_notificationcategoryid' link-type='outer' alias='category'>" +
                                "<attribute name='rbs_fetchcriteria' />" +
                                "<attribute name='rbs_primaryentityname' />" +
                              "</link-entity>" +
                      "<link-entity name='team' from='teamid' to='rbs_team' link-type='inner' alias='team'>" +
                           "<attribute name='teamid' />" +
                        "<link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>" +
                          "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='user'>" +
                            "<filter type='and'>" +
                              "<condition attribute='systemuserid' operator='eq' value='" + currentUserId + "' />" +
                            "</filter>" +
                          "</link-entity>" +
                        "</link-entity>" +
                      "</link-entity>" +
                    "</entity>" +
                  "</fetch>";
        var encodedTeamFetchXML = encodeURIComponent(queryTeamNotifications);
        var teamNotifications = WebApiUtility.GetRequest("rbs_notifications?fetchXml=" + encodedTeamFetchXML, false);
        var FetchTeamNotifications = teamNotifications != undefined && teamNotifications != null ? teamNotifications.value : null;


        //==========================================================
        //Get FetchXML for Query User Notification
        //====================================================

        var queryUserNotifications = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
                                   "<entity name='rbs_notificationrecipient' >" +
                                     "<attribute name='rbs_lastacknowledgedon' />" +
                                     "<attribute name='rbs_notificationrecipientid' />" +
                                     "<attribute name='rbs_recipienttype' />" +
                                     "<filter>" +
                                       "<condition attribute='rbs_user' operator='eq' value='" + currentUserId + "' />" +
                                     "</filter>" +
                                     "<link-entity name='rbs_notification' from='rbs_notificationid' to='rbs_notification' link-type='inner'  alias='nf'>" +
                                       "<attribute name='rbs_notificationtype' />" +
                                       "<attribute name='rbs_notificationmessageid' />" +
                                         "<attribute name='rbs_notificationcategoryid' />" +
                                            "<attribute name='rbs_notificationid' />" +
                                            "<attribute name='rbs_reactivationperiod' />" +
                                            "<attribute name='rbs_notificationdisplaytype' />" +
                                              "<attribute name='rbs_notificationpriority' />" +
                                              "<attribute name='rbs_regarding' />" +
                                         "<filter type='and'>" +
                                         "<condition attribute='rbs_notificationdisplaytype' operator='in'>" +
                                                "<value>859770001</value>" +
                                              "</condition>" +
                                              "<condition attribute='rbs_regarding' operator='eq' value='" + caseId + "' />" +
                                            "<condition attribute='rbs_applicablefrom' operator='le' value='" + formatDate(new Date()) + "' />" +
                                            "<filter type='or'>" +
                                                "<condition attribute='rbs_notificationexpiredon' operator='null' />" +
                                             "</filter>" +
                                             "<filter type='or'>" +
                                                "<condition attribute='rbs_applicabletill' operator='null' />" +
                                                "<condition attribute='rbs_applicabletill' operator='ge' value='" + formatDate(new Date()) + "' />" +
                                              "</filter>" +
                                            "</filter>" +
                                          "<link-entity name='rbs_notificationcategories' from='rbs_notificationcategoriesid' to='rbs_notificationcategoryid' link-type='outer' alias='category'>" +
                                           "<attribute name='rbs_fetchcriteria' />" +
                                             "<attribute name='rbs_primaryentityname' />" +
                                         "</link-entity>" +
                                     "</link-entity>" +
                                     "</entity>" +
                                     "</fetch>";



        var encodedUserFetchXML = encodeURIComponent(queryUserNotifications);
        var userNotifications = WebApiUtility.GetRequest("rbs_notificationrecipients?fetchXml=" + encodedUserFetchXML, false);
        var FetchUserNotifications = userNotifications != undefined && userNotifications != null ? userNotifications.value : null;

        var UserNotifications = [];
        var TeamNotifications = [];

        if (FetchUserNotifications != null)
            for (var i = 0; i < FetchUserNotifications.length; i++) {
                if (FetchUserNotifications[i] != undefined && FetchUserNotifications[i] != null) {
                    if (FetchUserNotifications[i]["nf.rbs_notificationmessageid@OData.Community.Display.V1.FormattedValue"] != null && FetchUserNotifications[i]["nf.rbs_notificationmessageid@OData.Community.Display.V1.FormattedValue"] != "undefined") {
                        var rbs_AckDate = null, Category = null, FetchEntity = null, rbs_NotificationPriority, RecipientType = null;
                        var rbs_reactivatenotification = 0;
                        //TODO: work on category part
                        if (FetchUserNotifications[i]["category.rbs_fetchcriteria"] != null && FetchUserNotifications[i]["category.rbs_fetchcriteria"] != "undefined"
                               && FetchUserNotifications[i]["category.rbs_fetchcriteria"].trim() != "")
                            Category = FetchUserNotifications[i]["category.rbs_fetchcriteria"];
                        if (FetchUserNotifications[i]["category.rbs_primaryentityname"] != null && FetchUserNotifications[i]["category.rbs_primaryentityname"] != "undefined"
                               && FetchUserNotifications[i]["category.rbs_primaryentityname"].trim() != "")
                            FetchEntity = FetchUserNotifications[i]["category.rbs_primaryentityname"];
                        if (FetchUserNotifications[i]["nf.rbs_reactivationperiod"] != null && FetchUserNotifications[i]["nf.rbs_reactivationperiod"] != "undefined")
                            rbs_reactivatenotification = FetchUserNotifications[i]["nf.rbs_reactivationperiod"];
                        if (FetchUserNotifications[i]["nf.rbs_notificationcategoryid"] != null && FetchUserNotifications[i]["nf.rbs_notificationcategoryid"] != "undefined")
                            NotificationCategory = FetchUserNotifications[i]["nf.rbs_notificationcategoryid@OData.Community.Display.V1.FormattedValue"];
                        if (FetchUserNotifications[i]["rbs_lastacknowledgedon"] != null && FetchUserNotifications[i]["rbs_lastacknowledgedon"] != "undefined")
                            rbs_AckDate = FetchUserNotifications[i]["rbs_lastacknowledgedon"];
                        if (FetchUserNotifications[i]["rbs_recipienttype"] != null && FetchUserNotifications[i]["rbs_recipienttype"] != "undefined")
                            RecipientType = FetchUserNotifications[i]["rbs_recipienttype"];
                        if (FetchUserNotifications[i]["rbs_notificationrecipientid"] != null && FetchUserNotifications[i]["rbs_notificationrecipientid"] != "undefined")
                            nfRecipientId = FetchUserNotifications[i]["rbs_notificationrecipientid"];
                        if (FetchUserNotifications[i]["nf.rbs_notificationpriority"] != null && FetchUserNotifications[i]["nf.rbs_notificationpriority"] != "undefined")
                            rbs_NotificationPriority = FetchUserNotifications[i]["nf.rbs_notificationpriority"];

                        UserNotifications.push({ notification: FetchUserNotifications[i]["nf.rbs_notificationid"], notificationRecipientId: nfRecipientId, rbs_notificationcategoryid: NotificationCategory, notificationMsg: FetchUserNotifications[i]["nf.rbs_notificationmessageid@OData.Community.Display.V1.FormattedValue"], notificationType: FetchUserNotifications[i]["nf.rbs_notificationtype"], RecipientType: FetchUserNotifications[i]["rbs_recipienttype"], displayType: FetchUserNotifications[i]["nf.rbs_notificationdisplaytype"], AckDate: rbs_AckDate, notificationCategory: Category, reactivationDays: rbs_reactivatenotification, notificationRecepient: FetchUserNotifications[i]["nf.rbs_notificationid"], primaryEntityForCategory: FetchEntity, NotificationPriority: rbs_NotificationPriority })

                    }
                }
            }
        if (FetchTeamNotifications != null)
            for (var j = 0; j < FetchTeamNotifications.length; j++) {
                if (FetchTeamNotifications[j]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"] != null && FetchTeamNotifications[j]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"] != "undefined") {
                    var Category = null, FetchEntity = null;
                    var rbs_reactivatenotification = 0;
                    if (FetchTeamNotifications[j]["rbs_reactivationperiod"] != null && FetchTeamNotifications[j]["rbs_reactivationperiod"] != "undefined")
                        rbs_reactivatenotification = FetchTeamNotifications[j]["rbs_reactivationperiod"];
                    if (FetchTeamNotifications[j]["category.rbs_fetchcriteria"] != null && FetchTeamNotifications[j]["category.rbs_fetchcriteria"] != "undefined" &&
                          FetchTeamNotifications[j]["category.rbs_fetchcriteria"].trim() != "")
                        Category = FetchTeamNotifications[j]["category.rbs_fetchcriteria"];
                    if (FetchTeamNotifications[j]["category.rbs_primaryentityname"] != null && FetchTeamNotifications[j]["category.rbs_primaryentityname"] != "undefined" &&
                        FetchTeamNotifications[j]["category.rbs_primaryentityname"].trim() != "")
                        FetchEntity = FetchTeamNotifications[j]["category.rbs_primaryentityname"];
                    if (FetchTeamNotifications[j]["_rbs_notificationcategoryid_value"] != null && FetchTeamNotifications[j]["_rbs_notificationcategoryid_value"] != "undefined")
                        var NotificationCategory1 = FetchTeamNotifications[j]["_rbs_notificationcategoryid_value@OData.Community.Display.V1.FormattedValue"];
                    if (FetchTeamNotifications[j]["rbs_notificationpriority"] != null && FetchTeamNotifications[j]["rbs_notificationpriority"] != "undefined")
                        rbs_NotificationPriority = FetchTeamNotifications[j]["rbs_notificationpriority"];
                    TeamNotifications.push({ notification: FetchTeamNotifications[j]["rbs_notificationid"], notificationMsg: FetchTeamNotifications[j]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"], notificationType: FetchTeamNotifications[j]["rbs_notificationtype"], displayType: FetchTeamNotifications[j]["rbs_notificationdisplaytype"], rbs_notificationcategoryid: NotificationCategory1, notificationCategory: Category, reactivationDays: rbs_reactivatenotification, primaryEntityForCategory: FetchEntity, NotificationPriority: rbs_NotificationPriority });
                }
            }

        //check if the items in team notification already exists in user


        if (TeamNotifications != undefined && TeamNotifications != null && TeamNotifications.length > 0) {
            for (var k = 0; k < TeamNotifications.length; k++) {
                var filterArry = UserNotifications.filter(function (item) {
                    return item.notification == TeamNotifications[k].notification;
                });

                //match exists
                if (filterArry.length > 0) {
                    //in case of a global notification 
                    if (filterArry[0].displayType == 859770001) {
                        // and no ack date for the current user as a recepient
                        //if multiple check if contains an entry with ack date ==null if so add to dsiplay
                        var tempArray = filterArry.filter(function (element) {
                            return element.AckDate == null;
                        });
                        if (tempArray.length > 0) {
                            notificationId = tempArray[0].notification;
                            strUIMessage = tempArray[0].notificationMsg;
                            notificationType = tempArray[0].notificationType;
                            recipientType = tempArray[0].RecipientType;
                            notificationRecipientId = tempArray[0].notificationRecipientId;
                            notificationCategory = tempArray[0].rbs_notificationcategoryid;
                            if (notificationCategory == "Letter Sent") {

                                if (formContext.getAttribute("new_testfield").getValue() != null && formContext != null && formContext != undefined) {
                                    //letterDate = FinalDisplayList_ForPrompts[i].attributes["case.new_testfield"].value;
                                    letterDate = formContext.getAttribute("new_testfield").getValue();
                                    if (letterDate != null) {
                                        finalMessage = GetLetterFormattedMessage(strUIMessage, letterDate);

                                        if ((finalMessage != null) && (notificationType != null)) {

                                            displayNotificaitonId[p] = notificationId;
                                            displayfinalmessage[p] = finalMessage;
                                            displayNotificationType[p] = notificationType;
                                            displayrecipientType[p] = PRIMARYRECIPIENT;//recipientType;
                                            displayrecipientArray[p] = notificationRecipientId;
                                            //======================================= 
                                            // Incrementing the displaycounter
                                            //======================================= 
                                            p++;
                                        }
                                    }
                                }
                            }
                            else if (notificationCategory == "90 Day Extension") {
                                debugger
                                if (formContext.getAttribute("rbs_90day_extensionexpiry").getValue() != null && formContext != null && formContext != undefined) {
                                    ninetyDayExpiryDate = formContext.getAttribute("rbs_90day_extensionexpiry").getValue();//FinalDisplayList_ForPrompts[i]["case.rbs_90day_extensionexpiry"];
                                    if (ninetyDayExpiryDate != null) {

                                        finalMessage = Get90DayExtensionFormattedMessage(strUIMessage, ninetyDayExpiryDate);
                                        if ((finalMessage != null) && (notificationType != null)) {
                                            //if (i == 0) {
                                            displayNotificaitonId[p] = notificationId;
                                            displayfinalmessage[p] = finalMessage;
                                            displayNotificationType[p] = notificationType;
                                            displayrecipientType[p] = PRIMARYRECIPIENT;//recipientType;
                                            displayrecipientArray[p] = notificationRecipientId;
                                            //======================================= 
                                            // Incrementing the displaycounter
                                            //======================================= 
                                            p++;
                                            //}
                                        }
                                    }
                                }
                            }

                            //if (displayNotificaitonId.length > 0) {
                            //    DisplayAlertMessages(displayNotificaitonId[arrayElement], displayfinalmessage[arrayElement], displayNotificationType[arrayElement], displayrecipientType[arrayElement], displayrecipientArray[arrayElement], arrayElement);
                            //}

                        }

                        // displayNotifications.push({ MessageArray: tempArray[0] });

                        //no entry with Ackdate==null for the user as a recepient, which means ackdate has data, so check if reactivation period has data if so proceed
                        /*
                    else if (filterArry[0].reactivationDays > 0) {
                        //ack date has data for all elements , sort it in descending order based on date
                        var sortedArray = filterArry.sort(function (a, b) {
                            return b.AckDate - a.AckDate;
                        });
                        if (sortedArray.length > 0) {
                            //get the highest ack date and check the difference
                            var CutoffDate = sortedArray[0].AckDate.setTime(new Date(sortedArray[0].AckDate).getTime() + (sortedArray[0].reactivationDays * 24 * 60 * 60 * 1000));
                            if (Today.getTime() >= CutoffDate)
                                displayNotifications.push({ MessageArray: sortedArray[0] });
                        }
                    }*/
                        ///if no user entry but team is present
                    }
                }
                else {
                    if (TeamNotifications[k].displayType == 859770001) {
                        notificationId = TeamNotifications[k].notification;
                        var queryTeamNotificationsRec = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                     "<entity name='rbs_notification' >" +
                                       "<attribute name='rbs_notificationcategoryid' />" +
                                       "<attribute name='rbs_notificationmessageid' />" +
                                       "<attribute name='rbs_name' />" +
                                       "<filter type='and' >" +
                                         "<condition attribute='rbs_regarding' operator='eq' value='" + caseId + "' />" +
                                         "<condition attribute='rbs_notificationdisplaytype' operator='eq' value='859770001' />" +
                                         "<condition attribute='rbs_applicablefrom' operator='le' value='" + formatDate(new Date()) + "' />" +
                                         "<condition attribute='rbs_notificationid' operator='eq' value= '" + notificationId + "' />" +
                                       "</filter>" +
                                       "<filter type='or' >" +
                                         "<condition attribute='rbs_notificationexpiredon' operator='null' />" +
                                       "</filter>" +
                                       "<filter type='or' >" +
                                         "<condition attribute='rbs_applicabletill' operator='null' />" +
                                         "<condition attribute='rbs_applicabletill' operator='ge' value='" + formatDate(new Date()) + "'  />" +
                                       "</filter>" +
                                       "<link-entity name='rbs_notificationrecipient' from='rbs_notification' to='rbs_notificationid' >" +
                                         "<attribute name='rbs_name' />" +
                                         "<attribute name='rbs_recipienttypename' />" +
                                         "<attribute name='rbs_notificationrecipientid' />" +
                                         "<attribute name='rbs_lastacknowledgedon' />" +
                                         "<attribute name='rbs_user' />" +
                                         "<attribute name='rbs_username' />" +
                                         "<filter>" +
                                           "<condition attribute='rbs_user' operator='eq' value= '" + currentUserId + "' /> " +
                                         "</filter>" +
                                       "</link-entity> " +
                                     "</entity>" +
                                   "</fetch> ";
                        var encodedNotificationRecFetchXML = encodeURIComponent(queryTeamNotificationsRec);
                        var notificationRecfetchXMLResult = WebApiUtility.GetRequest("rbs_notifications?fetchXml=" + encodedNotificationRecFetchXML, false);
                        if (notificationRecfetchXMLResult.value.length == 0) {
                            //nomatch which means the notification is not yet acknowledged so add to display array

                            strUIMessage = TeamNotifications[k].notificationMsg;
                            notificationType = TeamNotifications[k].notificationType;
                            recipientType = TeamNotifications[k].RecipientType;
                            notificationRecipientId = TeamNotifications[k].notificationRecipientId;
                            notificationCategory = TeamNotifications[k].rbs_notificationcategoryid;
                            if (notificationCategory == "Letter Sent") {

                                if (formContext.getAttribute("new_testfield").getValue() != null && formContext != null && formContext != undefined) {
                                    //letterDate = FinalDisplayList_ForPrompts[i].attributes["case.new_testfield"].value;
                                    letterDate = formContext.getAttribute("new_testfield").getValue();
                                    if (letterDate != null) {
                                        finalMessage = GetLetterFormattedMessage(strUIMessage, letterDate);

                                        if ((finalMessage != null) && (notificationType != null)) {

                                            displayNotificaitonId[p] = notificationId;
                                            displayfinalmessage[p] = finalMessage;
                                            displayNotificationType[p] = notificationType;
                                            displayrecipientType[p] = PRIMARYRECIPIENT;//recipientType;
                                            displayrecipientArray[p] = null;//notificationRecipientId;
                                            //======================================= 
                                            // Incrementing the displaycounter
                                            //======================================= 
                                            p++;

                                        }
                                    }
                                }
                            }
                            else if (notificationCategory == "90 Day Extension") {
                                debugger
                                if (formContext.getAttribute("rbs_90day_extensionexpiry").getValue() != null && formContext != null && formContext != undefined) {
                                    ninetyDayExpiryDate = formContext.getAttribute("rbs_90day_extensionexpiry").getValue();//FinalDisplayList_ForPrompts[i]["case.rbs_90day_extensionexpiry"];
                                    if (ninetyDayExpiryDate != null) {

                                        finalMessage = Get90DayExtensionFormattedMessage(strUIMessage, ninetyDayExpiryDate);
                                        if ((finalMessage != null) && (notificationType != null)) {
                                            //if (i == 0) {
                                            displayNotificaitonId[p] = notificationId;
                                            displayfinalmessage[p] = finalMessage;
                                            displayNotificationType[p] = notificationType;
                                            displayrecipientType[p] = PRIMARYRECIPIENT; //recipientType;
                                            displayrecipientArray[p] = null; //notificationRecipientId;
                                            //======================================= 
                                            // Incrementing the displaycounter
                                            //======================================= 
                                            p++;

                                            //}
                                        }
                                    }
                                }
                            }
                            //if (displayNotificaitonId.length > 0) {
                            //    DisplayAlertMessages(displayNotificaitonId[arrayElement], displayfinalmessage[arrayElement], displayNotificationType[arrayElement], displayrecipientType[arrayElement], displayrecipientArray[arrayElement], arrayElement);
                            //}


                        }

                    }

                }
                // displayNotifications.push({ MessageArray: TeamNotifications[k] });
            }

        }


        //******************************************Team Notifation End ******************************//



        //==========================================================================
        // Get the Fetchxml into an array
        //==========================================================================
        if (FetchXMLArray_ForPrompts.length > 0) {
            for (var t = 0; t < FetchXMLArray_ForPrompts.length; t++) {
                queryCategory = FetchXMLArray_ForPrompts[t];//Fetch xml is contained here
                queryCategory = queryCategory.replace("caseId", caseId);
                queryCategory = queryCategory.replace("fromdate", currentdate);
                queryCategory = queryCategory.replace("tilldate", currentdate);
                queryCategory = queryCategory.replace("currentUserId", currentUserId);
                if (queryCategory != null) {

                    //FetchedCategories = XrmServiceToolkit.Soap.Fetch(queryCategory);///Get the prompt messsages
                    var encodedNotificationCatFetchXML = encodeURIComponent(queryCategory);
                    var notificationCatfetchXMLResult = WebApiUtility.GetRequest("rbs_notifications?fetchXml=" + encodedNotificationCatFetchXML, false);
                    if (notificationCatfetchXMLResult.value.length > 0) {
                        for (var i = 0; i < notificationCatfetchXMLResult.value.length; i++) {

                            FinalDisplayList_ForPrompts[i] = notificationCatfetchXMLResult.value[i];

                            if (FinalDisplayList_ForPrompts[i]) {
                                if (FinalDisplayList_ForPrompts[i] != null && FinalDisplayList_ForPrompts[i].rbs_notificationid != null && FinalDisplayList_ForPrompts[i].rbs_notificationid != "undefined")
                                    notificationId = FinalDisplayList_ForPrompts[i].rbs_notificationid;
                                if (FinalDisplayList_ForPrompts[i] != null && FinalDisplayList_ForPrompts[i]["_rbs_notificationcategoryid_value@OData.Community.Display.V1.FormattedValue"] != null && FinalDisplayList_ForPrompts[i]["_rbs_notificationcategoryid_value@OData.Community.Display.V1.FormattedValue"] != "undefined")
                                    notificationCategory = FinalDisplayList_ForPrompts[i]["_rbs_notificationcategoryid_value@OData.Community.Display.V1.FormattedValue"]; //FinalDisplayList_ForPrompts[i].rbs_notificationcategoryid.formattedValue;
                                if (FinalDisplayList_ForPrompts[i] != null && FinalDisplayList_ForPrompts[i]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"] != null && FinalDisplayList_ForPrompts[i]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"] != "undefined")
                                    strUIMessage = FinalDisplayList_ForPrompts[i]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"]; //FinalDisplayList_ForPrompts[i].rbs_notificationmessageid.formattedValue;
                                if (FinalDisplayList_ForPrompts[i] != null && FinalDisplayList_ForPrompts[i].rbs_notificationtype != null && FinalDisplayList_ForPrompts[i].rbs_notificationtype != "undefined")
                                    notificationType = FinalDisplayList_ForPrompts[i].rbs_notificationtype;
                                if (FinalDisplayList_ForPrompts[i] != null && FinalDisplayList_ForPrompts[i]["recipient.rbs_notificationrecipientid"] != null && FinalDisplayList_ForPrompts[i]["recipient.rbs_notificationrecipientid"] != "undefined")
                                    notificationRecipientId = FinalDisplayList_ForPrompts[i]["recipient.rbs_notificationrecipientid"];  //FinalDisplayList_ForPrompts[i]["recipient.rbs_notificationrecipientid"]
                                if (FinalDisplayList_ForPrompts[i] != null && FinalDisplayList_ForPrompts[i]["recipient.rbs_recipienttype"] != null && FinalDisplayList_ForPrompts[i]["recipient.rbs_recipienttype"] != "undefined")
                                    recipientType = FinalDisplayList_ForPrompts[i]["recipient.rbs_recipienttype"];

                                var queryTeamNotificationsMatch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                                    "<entity name='rbs_notification'>" +
                                                       "<attribute name='rbs_notificationid' />" +
                                                       "<attribute name='rbs_notificationtype' />" +
                                                        "<attribute name='rbs_notificationmessageid' />" +
                                                       "<attribute name='rbs_notificationcategoryid' />" +
                                                      "<attribute name='rbs_reactivationperiod' />" +
                                                       "<attribute name='rbs_notificationdisplaytype' />" +
                                                         "<attribute name='rbs_notificationpriority' />" +
                                                         "<attribute name='rbs_regarding' />" +
                                                      "<order attribute='rbs_name' descending='false' />" +
                                                         "<filter type='and'>" +
                                                         "<condition attribute='rbs_notificationdisplaytype' operator='in'>" +
                                                                          "<value>859770001</value>" +
                                                                        "</condition>" +
                                                                      "<condition attribute='rbs_applicablefrom' operator='le' value='" + formatDate(new Date()) + "' />" +
                                                                      "<condition attribute='rbs_regarding' operator='eq' value= '" + caseId + "' />" +
                                                                      "<condition attribute='rbs_notificationid' operator='eq' value= '" + notificationId + "' />" +
                                                                      "<filter type='or'>" +
                                                                          "<condition attribute='rbs_notificationexpiredon' operator='null' />" +
                                                                       "</filter>" +
                                                                       "<filter type='or'>" +
                                                                          "<condition attribute='rbs_applicabletill' operator='null' />" +
                                                                          "<condition attribute='rbs_applicabletill' operator='ge' value='" + formatDate(new Date()) + "' />" +
                                                                        "</filter>" +
                                                              "</filter>" +
                                                               "<link-entity name='rbs_notificationcategories' from='rbs_notificationcategoriesid' to='rbs_notificationcategoryid' link-type='outer' alias='category'>" +
                                                                "<attribute name='rbs_fetchcriteria' />" +
                                                                "<attribute name='rbs_primaryentityname' />" +
                                                              "</link-entity>" +
                                                      "<link-entity name='team' from='teamid' to='rbs_team' link-type='inner' alias='team'>" +
                                                           "<attribute name='teamid' />" +
                                                        "<link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>" +
                                                          "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='user'>" +
                                                            "<filter type='and'>" +
                                                              "<condition attribute='systemuserid' operator='eq' value='" + currentUserId + "' />" +
                                                            "</filter>" +
                                                          "</link-entity>" +
                                                        "</link-entity>" +
                                                      "</link-entity>" +
                                                    "</entity>" +
                                                  "</fetch>";
                                var encodedNotificationTeamFetchXML = encodeURIComponent(queryTeamNotificationsMatch);
                                var notificationTeamfetchXMLResult = WebApiUtility.GetRequest("rbs_notifications?fetchXml=" + encodedNotificationTeamFetchXML, false);
                                if (notificationTeamfetchXMLResult.value.length == 0) {
                                    if ((notificationId != null) && (notificationCategory != null) && (strUIMessage != null) && (notificationRecipientId != null) && (recipientType != null)) {

                                        //========================================================================
                                        // The User should be  configured as a PRIMARY OR SECONDARY Recipient
                                        //========================================================================
                                        if (recipientType == PRIMARYRECIPIENT || recipientType == SECONDARYRECIPIENT) {

                                            if (notificationCategory == "Letter Sent") {
                                                debugger
                                                if (FinalDisplayList_ForPrompts[i]["case.new_testfield"] != null) {
                                                    letterDate = FinalDisplayList_ForPrompts[i]["case.new_testfield"];
                                                    if (letterDate != null) {
                                                        finalMessage = GetLetterFormattedMessage(strUIMessage, letterDate);

                                                        if ((finalMessage != null) && (notificationType != null)) {

                                                            displayNotificaitonId[p] = notificationId;
                                                            displayfinalmessage[p] = finalMessage;
                                                            displayNotificationType[p] = notificationType;
                                                            displayrecipientType[p] = recipientType;
                                                            displayrecipientArray[p] = notificationRecipientId;


                                                            //======================================= 
                                                            // Incrementing the displaycounter
                                                            //======================================= 
                                                            p++;
                                                        }
                                                    }
                                                }

                                            }
                                            else if (notificationCategory == "90 Day Extension") {
                                                debugger
                                                if (FinalDisplayList_ForPrompts[i]["case.rbs_90day_extensionexpiry"] != null) {
                                                    ninetyDayExpiryDate = FinalDisplayList_ForPrompts[i]["case.rbs_90day_extensionexpiry"];
                                                    if (ninetyDayExpiryDate != null) {

                                                        finalMessage = Get90DayExtensionFormattedMessage(strUIMessage, ninetyDayExpiryDate);
                                                        if ((finalMessage != null) && (notificationType != null)) {
                                                            //if (i == 0) {
                                                            displayNotificaitonId[p] = notificationId;
                                                            displayfinalmessage[p] = finalMessage;
                                                            displayNotificationType[p] = notificationType;
                                                            displayrecipientType[p] = recipientType;
                                                            displayrecipientArray[p] = notificationRecipientId;
                                                            //======================================= 
                                                            // Incrementing the displaycounter
                                                            //======================================= 
                                                            p++;
                                                            //}
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } //loop

                    }

                }
            }
            //================================================ 
            // If the DisplayAlertMessages does have content
            //Only the first array element
            //=============================================== 

        }
        if (displayNotificaitonId.length > 0) {
            DisplayAlertMessages(displayNotificaitonId[arrayElement], displayfinalmessage[arrayElement], displayNotificationType[arrayElement], displayrecipientType[arrayElement], displayrecipientArray[arrayElement], arrayElement);
        }


    }
}
//======================================= 
// Generic Functions
//=======================================
function formatDate(date1) {
    // format: YYYY-MM-DD
    if (date1 != "" && new Date(date1) != "Invalid Date") {
        //var d =new Date(date1);
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        return (curr_year + "-" + curr_month + "-" + curr_date);
    }

    return "";
}

function formatDate_MMDDYYYY(date1) {
    // format: MM-DD-YYYY
    if (date1 != "" && new Date(date1) != "Invalid Date") {
        var d = new Date();
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        return (curr_month + "-" + curr_date + "-" + curr_year);
    }

    return "";
}

function formatDate_DDMMYYYY(date1) {
    // format: DD-MM-YYYY
    if (date1 != "" && new Date(date1) != "Invalid Date") {
        var d = new Date();
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        return (curr_date + "-" + curr_month + "-" + curr_year);
    }
    return "";
}


//=======================================================================
//  Get the buttons and their associated function calls 
//  dynamically for the Messges being displayed
//=======================================================================
function DisplayAlertMessages(notificationId, finalMessage, notificationType, recipientType, displayrecipientId, arrayElement) {
    var dialogButtonName;
    var dialogActionType;
    var alertType;
    var messageDisplayType;
    var DialogButtonArray = new Array(2);
    var displayButtons = [];

    var queryDialogButtons = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                    "<entity name='rbs_dialogbuttons'>" +
                                        "<attribute name='rbs_dialogbuttonsid'/>" +
                                        "<attribute name='rbs_name'/>" +
                                        "<attribute name='rbs_notificationbuttonid'/>" +
                                        "<attribute name='rbs_description'/>" +
                                        "<attribute name='rbs_actiontype'/>" +
                                        "<attribute name='rbs_action'/>" +
                                        "<attribute name='rbs_sortorder'/>" +
                                        "<order descending='false' attribute='rbs_sortorder'/>" +
                                        "<filter type='and'>" +
                                                "<condition attribute='rbs_action' operator='not-null'/>" +
                                                "<condition attribute='statecode' value='0' operator='eq'/>" +
                                                "<condition attribute='rbs_sortorder' operator='not-null'/>" +
                                                "<condition attribute='rbs_actiontype' operator='not-null'/>" +
                                                "<condition attribute='rbs_notificationbuttonid' operator='eq' value='" + notificationId + "' />" +
                                        "</filter>" +
                                    "</entity>" +
                                    "</fetch>"
    // var FetchedNotificationButtonss = XrmServiceToolkit.Soap.Fetch(queryDialogButtons);
    var encodedDialogFetchXML = encodeURIComponent(queryDialogButtons);
    var dialogButtonResult = WebApiUtility.GetRequest("rbs_dialogbuttonses?fetchXml=" + encodedDialogFetchXML, false);

    for (var i = 0; i < dialogButtonResult.value.length; i++) {

        DialogButtonArray[i] = new Array(3);

        //======================================= 
        // Set the Message Display Type
        //======================================= 
        switch (notificationType) {
            case eval(InfoNotificationType):
                messageDisplayType = 'INFO';
                break;
            case eval(WarningNotificationType):
                messageDisplayType = 'WARNING';
                break;
            case eval(ErrorNotificationType):
                messageDisplayType = 'ERROR';
                break;
            case eval(SuccessNotificationType):
                messageDisplayType = 'SUCCESS';
                break;
            case eval(LoadingNotificationType):
                messageDisplayType = 'LOADING';
                break;
            case eval(QuestionNotificationType):
                messageDisplayType = 'QUESTION';
                break;
            default:
                messageDisplayType = 'INFO';
                break;
        }

        //==================================================  
        //  Dialog Button/Action/Action Type assignment 
        //==================================================  
        for (var j = 0; j < DialogButtonArray[i].length; j++) {
            if (j === 0) {
                //============= 
                // Button
                //============= 
                if (dialogButtonResult.value[i].rbs_name != null) {
                    DialogButtonArray[i][j] = dialogButtonResult.value[i].rbs_name;
                    dialogButtonName = DialogButtonArray[i][j];
                }
            }

            if (j == 1) {
                //============= 
                // Action
                //============= 
                if (dialogButtonResult.value[i].rbs_action != null) {
                    DialogButtonArray[i][j] = dialogButtonResult.value[i].rbs_action;
                }


            }
            if (j == 2) {
                //============= 
                // ActionType 
                //============= 
                if (dialogButtonResult.value[i].rbs_actiontype != null) {
                    DialogButtonArray[i][j] = dialogButtonResult.value[i].rbs_actiontype;
                    dialogActionType = DialogButtonArray[i][j];
                }
            }
        }

        //============================================================ 
        // Set the Display Buttons Dynamically and call the Functions        
        //============================================================ 

        displayButtons[i] = new Alert.Button(dialogButtonName, function (buttonLabel) {
            if (dialogActionType == ACTIONTYPEJAVASCRIPT) {
                if (recipientType == PRIMARYRECIPIENT) {
                    var dialogAction = null;
                    for (var element = 0; element < DialogButtonArray.length; element++) {
                        var dialogRow = DialogButtonArray[element];
                        if (dialogRow[0] == buttonLabel) {
                            dialogAction = dialogRow[1];
                            break;
                        }
                    }
                    notification = notificationId;
                    if (dialogAction != null)
                        eval(dialogAction);
                }
                arrayElement = arrayElement + 1;
                if (arrayElement < displayNotificaitonId.length) {
                    DisplayAlertMessages(displayNotificaitonId[arrayElement], displayfinalmessage[arrayElement], displayNotificationType[arrayElement], displayrecipientType[arrayElement], displayrecipientArray[arrayElement], arrayElement);
                }
            }

        }, false, false)


    }

    Alert.show(finalMessage, "<br>", displayButtons, messageDisplayType, 500, 000, null, true, null);

}
//=================================
//  90 Day Category formattting
//================================
function Get90DayExtensionFormattedMessage(msg, ninetyDayExpiryDate) {
    var formattedMessage = "";
    if (msg.indexOf("<rbs_90day_extensionexpiry>") != -1)
        formattedMessage = msg.replace("<rbs_90day_extensionexpiry>", formatDate_DDMMYYYY(ninetyDayExpiryDate));
    else
        formattedMessage = msg;
    return formattedMessage;

}
//==================================================
// Format the Post Message
//==================================================
function GetLetterFormattedMessage(msg, letterDate) {
    var formattedMessage = "";
    if (msg.indexOf("<new_testfield>") != -1)
        formattedMessage = msg.replace("<new_testfield>", formatDate_DDMMYYYY(letterDate)).split("[newline]").join("<br>");
    else
        formattedMessage = msg;
    return formattedMessage;
}
///==============================================================================
//  Common Functions
//  Function to Update the Acknowledgement for Notifications 
//===============================================================================
function updateNotificationRecipient(notificationRecipientId) {

    //rbs_notificationrecipientid
    Process.callAction("rbs_Marknotificationacknowledgement",
    [{
        key: "notification",
        type: Process.Type.EntityReference,
        value: { id: notificationRecipientId, entityType: "rbs_notification" }
    }, {
        key: "user",
        type: Process.Type.EntityReference,
        value: { id: currentUserId, entityType: "systemuser" }
    }],
    function (params) {
        // Success
        //for (var i = 0; i < params.length; i++) {
        //    //alert(params[i].key + "=" + params[i].value); 

        //}

    },
    function (e) {
        // Error
        alert(e);
    }
);

}
//==================
// Cancel Dialog
//==================
function CancelDialog() {
    //alert('Cancel');
}
// JavaScript source code
