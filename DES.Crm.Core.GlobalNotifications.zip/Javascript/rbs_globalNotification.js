
var WebApiUtility = WebApiUtility || {};
WebApiUtility.GetRequest = function (query, mode) {
    var results = null;
    if (query != null && mode != null) {
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.0/"+ query, mode);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    results = JSON.parse(this.response);
                }
            }
        };
        req.send();
    }
    return results;
};


// JavaScript source code
var INITIALISE = false;
var currentUserId = Xrm.Utility.getGlobalContext().userSettings.userId;
var NOTIFICATIONDISPLAYTYPE = "859770000";
var displayNotifications = [];
var NotificationLimit = 2;
var Today = new Date();
//============================================================================================
// Global Notification Function :
// The Bar Notification of Information, Question etc comes to all user
//============================================================================================
function GlobalNotification() {
    if (!INITIALISE) {

        //Query to retrieve user specific bar notifications
        debugger;
        var queryUserNotifications = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
                                       "<entity name='rbs_notificationrecipient' >" +
                                         "<attribute name='rbs_lastacknowledgedon' />" +
                                         "<attribute name='rbs_notificationrecipientid' />" +
                                         "<filter>" +
                                           "<condition attribute='rbs_user' operator='eq' value='" + currentUserId + "' />" +
                                         "</filter>" +
                                         "<link-entity name='rbs_notification' from='rbs_notificationid' to='rbs_notification' link-type='inner'  alias='nf'>" +
                                           "<attribute name='rbs_notificationtype' />" +
                                           "<attribute name='rbs_notificationmessageid' />" +
                                             "<attribute name='rbs_notificationcategoryid' />" +
                                                "<attribute name='rbs_notificationid' />" +
                                                "<attribute name='rbs_reactivationperiod' />" +
                                                "<attribute name='rbs_notificationdisplaytype' />" +
                                                  "<attribute name='rbs_notificationpriority' />" +
                                             "<filter type='and'>" +
                                             "<condition attribute='rbs_notificationdisplaytype' operator='in'>" +
                                                    "<value>859770000</value>" +
                                                  "</condition>" +
                                                "<condition attribute='rbs_applicablefrom' operator='le' value='" + formatDate(new Date()) + "' />" +
                                                "<filter type='or'>" +
                                                    "<condition attribute='rbs_notificationexpiredon' operator='null' />" +
                                                 "</filter>" +
                                                 "<filter type='or'>" +
                                                    "<condition attribute='rbs_applicabletill' operator='null' />" +
                                                    "<condition attribute='rbs_applicabletill' operator='ge' value='" + formatDate(new Date()) + "' />" +
                                                  "</filter>" +
                                                "</filter>" +
                                              "<link-entity name='rbs_notificationcategories' from='rbs_notificationcategoriesid' to='rbs_notificationcategoryid' link-type='outer' alias='category'>" +
                                               "<attribute name='rbs_fetchcriteria' />" +
                                                 "<attribute name='rbs_primaryentityname' />" +
                                             "</link-entity>" +
                                         "</link-entity>" +
                                         "</entity>" +
                                         "</fetch>";
            var queryTeamNotifications = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                      "<entity name='rbs_notification'>" +
                         "<attribute name='rbs_notificationid' />" +
                         "<attribute name='rbs_notificationtype' />" +
                          "<attribute name='rbs_notificationmessageid' />" +
                         "<attribute name='rbs_notificationcategoryid' />" +
                        "<attribute name='rbs_reactivationperiod' />" +
                         "<attribute name='rbs_notificationdisplaytype' />" +
                           "<attribute name='rbs_notificationpriority' />" +
                        "<order attribute='rbs_name' descending='false' />" +
                           "<filter type='and'>" +
                           "<condition attribute='rbs_notificationdisplaytype' operator='in'>" +
                                            "<value>859770000</value>" +
                                          "</condition>" +
                                        "<condition attribute='rbs_applicablefrom' operator='le' value='" + formatDate(new Date()) + "' />" +
                                        "<filter type='or'>" +
                                            "<condition attribute='rbs_notificationexpiredon' operator='null' />" +
                                         "</filter>" +
                                         "<filter type='or'>" +
                                            "<condition attribute='rbs_applicabletill' operator='null' />" +
                                            "<condition attribute='rbs_applicabletill' operator='ge' value='" + formatDate(new Date()) + "' />" +
                                          "</filter>" +
                                "</filter>" +
                                 "<link-entity name='rbs_notificationcategories' from='rbs_notificationcategoriesid' to='rbs_notificationcategoryid' link-type='outer' alias='category'>" +
                                  "<attribute name='rbs_fetchcriteria' />" +
                                  "<attribute name='rbs_primaryentityname' />" +
                                "</link-entity>" +
                        "<link-entity name='team' from='teamid' to='rbs_team' link-type='inner' alias='team'>" +
                             "<attribute name='teamid' />" +
                          "<link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>" +
                            "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='user'>" +
                              "<filter type='and'>" +
                                "<condition attribute='systemuserid' operator='eq' value='" + currentUserId + "' />" +
                              "</filter>" +
                            "</link-entity>" +
                          "</link-entity>" +
                        "</link-entity>" +
                      "</entity>" +

                    "</fetch>";
       
        var encodedUserFetchXML = encodeURIComponent(queryUserNotifications);
        var encodedTeamFetchXML = encodeURIComponent(queryTeamNotifications);
        var teamNotifications = WebApiUtility.GetRequest("rbs_notifications?fetchXml=" + encodedTeamFetchXML, false);
        var FetchTeamNotifications = teamNotifications != undefined && teamNotifications!= null ? teamNotifications.value:null;
      
        var userNotifications = WebApiUtility.GetRequest("rbs_notificationrecipients?fetchXml=" + encodedUserFetchXML, false);
        var FetchUserNotifications = userNotifications != undefined && userNotifications != null ? userNotifications.value : null;
        //To remove any earlier custom notifications being displayed to avoid same messages being repeated
        parent.$("#notifyWrapper").remove();
        var UserNotifications = [];
        var TeamNotifications = [];
        
        if (FetchUserNotifications != null)
        for (var i = 0; i < FetchUserNotifications.length; i++) {
            if(FetchUserNotifications[i] != undefined && FetchUserNotifications[i] != null)
            {
                if (FetchUserNotifications[i]["nf.rbs_notificationmessageid@OData.Community.Display.V1.FormattedValue"] != null && FetchUserNotifications[i]["nf.rbs_notificationmessageid@OData.Community.Display.V1.FormattedValue"] != "undefined") 
                {
                    var rbs_AckDate = null, Category = null, FetchEntity = null, rbs_NotificationPriority;
                    var rbs_reactivatenotification = 0;
                    //TODO: work on category part
                    if (FetchUserNotifications[i]["category.rbs_fetchcriteria"] != null && FetchUserNotifications[i]["category.rbs_fetchcriteria"] != "undefined"
                           && FetchUserNotifications[i]["category.rbs_fetchcriteria"].trim() != "")
                        Category = FetchUserNotifications[i]["category.rbs_fetchcriteria"];
                    if (FetchUserNotifications[i]["category.rbs_primaryentityname"] != null && FetchUserNotifications[i]["category.rbs_primaryentityname"] != "undefined"
                           && FetchUserNotifications[i]["category.rbs_primaryentityname"].trim() != "")
                        FetchEntity = FetchUserNotifications[i]["category.rbs_primaryentityname"];
                    if (FetchUserNotifications[i]["nf.rbs_reactivationperiod"] != null && FetchUserNotifications[i]["nf.rbs_reactivationperiod"] != "undefined")
                        rbs_reactivatenotification = FetchUserNotifications[i]["nf.rbs_reactivationperiod"];
                    if (FetchUserNotifications[i]["rbs_lastacknowledgedon"] != null && FetchUserNotifications[i]["rbs_lastacknowledgedon"] != "undefined")
                        rbs_AckDate = FetchUserNotifications[i]["rbs_lastacknowledgedon"];
                    if (FetchUserNotifications[i]["nf.rbs_notificationpriority"] != null && FetchUserNotifications[i]["nf.rbs_notificationpriority"] != "undefined")
                        rbs_NotificationPriority = FetchUserNotifications[i]["nf.rbs_notificationpriority"];
                    UserNotifications.push({ notification: FetchUserNotifications[i]["nf.rbs_notificationid"], notificationMsg: FetchUserNotifications[i]["nf.rbs_notificationmessageid@OData.Community.Display.V1.FormattedValue"], notificationType: FetchUserNotifications[i]["nf.rbs_notificationtype@OData.Community.Display.V1.FormattedValue"], displayType: FetchUserNotifications[i]["nf.rbs_notificationdisplaytype"], AckDate: rbs_AckDate, notificationCategory: Category, reactivationDays: rbs_reactivatenotification, notificationRecepient: FetchUserNotifications[i]["nf.rbs_notificationid"], primaryEntityForCategory: FetchEntity, NotificationPriority: rbs_NotificationPriority })

                }
            }
        }
        if (FetchTeamNotifications != null)
        for (var j = 0; j < FetchTeamNotifications.length; j++) {
            if (FetchTeamNotifications[j]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"] != null && FetchTeamNotifications[j]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"] != "undefined") {
                var Category = null, FetchEntity = null;
                var rbs_reactivatenotification = 0;
                if (FetchTeamNotifications[j]["rbs_reactivationperiod"] != null && FetchTeamNotifications[j]["rbs_reactivationperiod"] != "undefined")
                    rbs_reactivatenotification = FetchTeamNotifications[j]["rbs_reactivationperiod"];
                if (FetchTeamNotifications[j]["category.rbs_fetchcriteria"] != null && FetchTeamNotifications[j]["category.rbs_fetchcriteria"] != "undefined" && 
                      FetchTeamNotifications[j]["category.rbs_fetchcriteria"].trim() != "")
                    Category = FetchTeamNotifications[j]["category.rbs_fetchcriteria"];
                if (FetchTeamNotifications[j]["category.rbs_primaryentityname"] != null && FetchTeamNotifications[j]["category.rbs_primaryentityname"] != "undefined" &&
                    FetchTeamNotifications[j]["category.rbs_primaryentityname"].trim() != "")
                    FetchEntity = FetchTeamNotifications[j]["category.rbs_primaryentityname"];
                if (FetchTeamNotifications[j]["rbs_notificationpriority"] != null && FetchTeamNotifications[j]["rbs_notificationpriority"] != "undefined")
                    rbs_NotificationPriority = FetchTeamNotifications[j]["rbs_notificationpriority"];
                TeamNotifications.push({ notification: FetchTeamNotifications[j]["rbs_notificationid"], notificationMsg: FetchTeamNotifications[j]["_rbs_notificationmessageid_value@OData.Community.Display.V1.FormattedValue"], notificationType: FetchTeamNotifications[j]["rbs_notificationtype@OData.Community.Display.V1.FormattedValue"], displayType: FetchTeamNotifications[j]["rbs_notificationdisplaytype"], notificationCategory: Category, reactivationDays: rbs_reactivatenotification, primaryEntityForCategory: FetchEntity, NotificationPriority: rbs_NotificationPriority });
            }
        }
        displayNotifications = [];
        //check if the items in team notification already exists in user
        if (TeamNotifications != undefined && TeamNotifications != null && TeamNotifications.length > 0) {
            for (var k = 0; k < TeamNotifications.length; k++) {
                var filterArry = UserNotifications.filter(function (item) {
                    return item.notification == TeamNotifications[k].notification;
                });
                //match exists
                if (filterArry.length > 0) {
                    //in case of a global notification 
                    if (filterArry[0].displayType == 859770000) {
                        // and no ack date for the current user as a recepient
                        //if multiple check if contains an entry with ack date ==null if so add to dsiplay
                        var tempArray = filterArry.filter(function (element) {
                            return element.AckDate == null;
                        });
                        if (tempArray.length > 0)
                            displayNotifications.push({ MessageArray: tempArray[0] });
                            //no entry with Ackdate==null for the user as a recepient, which means ackdate has data, so check if reactivation period has data if so proceed
                            /*
                        else if (filterArry[0].reactivationDays > 0) {
                            //ack date has data for all elements , sort it in descending order based on date
                            var sortedArray = filterArry.sort(function (a, b) {
                                return b.AckDate - a.AckDate;
                            });
                            if (sortedArray.length > 0) {
                                //get the highest ack date and check the difference
                                var CutoffDate = sortedArray[0].AckDate.setTime(new Date(sortedArray[0].AckDate).getTime() + (sortedArray[0].reactivationDays * 24 * 60 * 60 * 1000));
                                if (Today.getTime() >= CutoffDate)
                                    displayNotifications.push({ MessageArray: sortedArray[0] });
                            }
                        }*/
                        ///if no user entry but team is present
                    }
                }
                else
                    //nomatch which means the notification is not yet acknowledged so add to display array
                    displayNotifications.push({ MessageArray: TeamNotifications[k]});
            }
        }        
        
        //check for user notifications
        //type=global & ackdate=null
        var globalRecepients = UserNotifications.filter(function (item) {
            return item.displayType == 859770000 && item.AckDate == null;
        });
        //type = global and reactivation>0 hybrid
        /*var hybridRecepients = UserNotifications.filter(function (item) {
            return item.displayType == 859770000 && item.reactivationDays > 0 && item.AckDate != null;
        });*/
        if (globalRecepients != null && globalRecepients.length > 0)
            CheckAndInsertNotificationtoDisplayArray(globalRecepients);
       /* if (hybridRecepients != null && hybridRecepients.length > 0) {
                //ack date has data for all elements , sort it in descending order based on date
                var sortedArray = hybridRecepients.sort(function (a, b) {
                    return b.AckDate - a.AckDate;
                });
                //get the highest ack date and check the difference
                var CutoffDate = sortedArray[0].AckDate.setTime(new Date (sortedArray[0].AckDate).getTime() + (sortedArray[0].reactivationDays * 24 * 60 * 60 * 1000));
                if (Today.getTime() >= CutoffDate)
                    CheckAndInsertNotificationtoDisplayArray(sortedArray[0]);
        }*/
        //check if display notification has any data 
        if (displayNotifications.length > 0) {
            //sort on priority
            //sort on priority
            displayNotifications = displayNotifications.sort(function (a, b) {
                return a.MessageArray.NotificationPriority - b.MessageArray.NotificationPriority;
            });
            var iterationLimit = 0;
            if (displayNotifications.length < NotificationLimit)
                //iterate for all display notifications
                iterationLimit = displayNotifications.length;
            else
                iterationLimit = NotificationLimit;
            for (var i = 0; i < iterationLimit; i++) {
                //region get record count based on fetchxml stored in fetch criteria
                //check if the current message contains a dynamic content to replace, it should have [count] in the message
                if (displayNotifications[i].MessageArray.notificationMsg.toLowerCase().indexOf("<count>") != -1) {
                    if (displayNotifications[i].MessageArray.notificationCategory != null && displayNotifications[i].MessageArray.primaryEntityForCategory != null) {
                        //send the fetchxml as 1st param and 2nd param as true to do pagination
                        
                        var categoryQuery = encodeURIComponent(displayNotifications[i].MessageArray.notificationCategory);
                        var recordsToRetrieve = WebApiUtility.GetRequest(displayNotifications[i].MessageArray.primaryEntityForCategory + "?fetchXml=" + categoryQuery, false);
                        if (recordsToRetrieve != null && recordsToRetrieve.value.length > 0) {                            
                            displayNotifications[i].MessageArray.notificationMsg = displayNotifications[i].MessageArray.notificationMsg.replace(/<count>/gi, recordsToRetrieve.value.length);
                            Notify.add(displayNotifications[i].MessageArray.notificationMsg,
                                  displayNotifications[i].MessageArray.notificationType.toUpperCase(),
                                 displayNotifications[i].MessageArray.notification,
                                 null,
                                     null
                                  );
                        }
                        //if count is 0 or if criteria is null or the fetchxml value doesnt have data do not show the notification
                    } //category is empty
                }
                else {//no category and no dynamic string replacement
                    Notify.add(displayNotifications[i].MessageArray.notificationMsg,
                          displayNotifications[i].MessageArray.notificationType.toUpperCase(),
                            displayNotifications[i].MessageArray.notification,
                         null,
                             null
                          );
                }
            }
        }
        INITIALISE = true;
    }
    //returning false to hide the Broadcast button after the Notifications are loaded
    return false;
}

function formatDate(date1) {
    // format: YYYY-MM-DD
    if (date1 != "") {
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        //return (curr_year + "-" + curr_month + "-" + curr_date);
        return date1.toISOString();
    }
    return "";
}
function CheckAndInsertNotificationtoDisplayArray(recepientArray) {
    if (recepientArray.length > 0) {
        for (var i = 0; i < recepientArray.length; i++) {
            var checkExists = displayNotifications.filter(function (item) {
                return item.MessageArray.notification == recepientArray[i].notification;
            });
            if (checkExists == null || checkExists.length == 0)
                displayNotifications.push({ MessageArray: recepientArray[i] });
        }
    }
    else if(recepientArray.notification!=null && recepientArray.notification!="undefined") {
        var checkExists = displayNotifications.filter(function (item) {
            return item.MessageArray.notification == recepientArray.notification;
        });
        if (checkExists == null || checkExists.length == 0)
        displayNotifications.push({ MessageArray: recepientArray })

    }
}
Notify.remove = function (uniqueId) {

    if (!Notify._initialised) { return; }

    // If no ID specified, remove all notifications
    if (uniqueId === null || uniqueId === undefined) {
        $("#notifyWrapper").slideUp(500, function () {
            for (var i = 0; i < Notify._notifications.length; i++) {
                $("#notifyNotification_" + Notify._notifications[i].id).remove();
            }

            Notify._notifications = [];
        });
    }
    else {
        // Accepts non-strings
        uniqueId = (uniqueId + "").toLowerCase();

        // Remove the notification
        var tempNotifications = [];
        for (var i = 0; i < Notify._notifications.length; i++) {
            if (Notify._notifications[i].id !== uniqueId) {
                tempNotifications.push(Notify._notifications[i]);
            }
        }
        Notify._notifications = tempNotifications;

        if (Notify._notifications.length == 0) {

            $("#notifyWrapper").slideUp(500, function () {

                $("#notifyNotification_" + uniqueId).remove();
            });
        }
        else {

            $("#notifyNotification_" + uniqueId).slideUp(500, function () { $(this).remove(); });
        }
    }
    updateNotificationRecipient(uniqueId);
}
function updateNotificationRecipient(notification) {
    try {

        var reqName = "rbs_Marknotificationacknowledgement";
        var clientUrl = Xrm.Utility.getGlobalContext().getClientUrl();
        var parameters = {
            "notification":
                  {
                      "@odata.type": "Microsoft.Dynamics.CRM.rbs_notification",//entity type
                      "rbs_notificationid": notification,//Record's guid
                  },
                  "user":
                  {
                      "@odata.type": "Microsoft.Dynamics.CRM.systemuser",
                      "systemuserid": currentUserId,
                  }             
        };
        //Create request
        var req = new XMLHttpRequest();
        req.open("POST", clientUrl + "/api/data/v9.0/" + reqName, false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");

        req.onreadystatechange = function () {

            if (this.readyState == 4 /* complete */) {
                req.onreadystatechange = null;

                if (this.status == 200 || this.status == 204) {
                    //success callback   
                    console.log("Success");
                } else {
                    //error callback      
                    console.log(JSON.parse(this.response));
                }
            }
        };
        req.send(JSON.stringify(parameters));

    } catch (e) {
        alert(e.message);
    }
}

