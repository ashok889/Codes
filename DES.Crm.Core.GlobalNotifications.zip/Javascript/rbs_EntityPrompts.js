///===========================
// Global Declarations
///===========================
var FinalDisplayList_ForPrompts = [];
var Text_ForPrompts = [];
var fieldNames = [];
var promtType = "";
var PROMPTNOTIFICATION = "859770001";

// NOTIFICATION CATEGORIES ADDED
var PHONECALLCATEGORY = "859770000"
var EXTENSIONCCCATEGORY = "859770001";
var LETTERSENTCATEGORY = "859770002"
var NEWPOSTADDEDCATEGORY = "859770003"
var CASESTAGEMOVEMENTCATEGORY = "859770004";
var CASEASSIGNMENTCATEGORY = "859770005"
var EXTENSIONNRCCATEGORY = "859770006";
var NINETYDAYNOTIFICATIONCATEGORY = "859770007";
var NOTIFICATIONCATEGORY = "";


var PROMPTENABLED = "1";//"859770000"; Prompt Enabled changed from Option Set to Radio Buttons
var PRIMARYRECIPIENT = "859770000";
var SECONDARYRECIPIENT = "859770001";
var matches = [];
var caseExtensionflag = true;
var latestPostDate;
//==========================================================
// Globally get the information of the User and Entity Id
//==========================================================
var currentUserId = Xrm.Page.context.getUserId();
var caseId = Xrm.Page.data.entity.getId();
///=======================================
//  Prepare and show Notifications
//========================================
function getPromptNotifications() {

    // 90Day Category
    PreparePromptNotificationsForCase('90DaysExtension');
    // Post Category only if the 90Day Prompt is already acknowledged
    if (caseExtensionflag == false) {
        PreparePromptNotificationsForCase('Post');
    }
}
///============================================= 
//  Function Speicific to Notificaion Category
//============================================== 
function PreparePromptNotificationsForCase(Category) {
    if (Category == '90DaysExtension') {
        NOTIFICATIONCATEGORY = NINETYDAYNOTIFICATIONCATEGORY;
        //Function to dynamically replace the Text field with field in the Form        
        getExtensionDuePromptTextForCase();
        getPromptNotificationsForCase(fieldNames, Category);
        if (FinalDisplayList_ForPrompts.length > 0) {
           
            ShowFinalPromptNotifications(Category);
        }
        else {
            // The Extention Notification is already acknowledged
            caseExtensionflag = false;
        }
    }
    else if (Category == 'Post') {
        // Function to get the latest Post that happened to this case
        //  This is kept as Current Day Date as of Now
        
        //latestPostDate = fetchLatestPostDate();
        FinalDisplayList_ForPrompts = []; // Reset the array as we are using this as common Array
        latestPostDate = formatDate(new Date());
        latestPostDate = new Date();
        if (latestPostDate != "") {
            getPromptNotificationsForCase(fieldNames, Category);
            if (FinalDisplayList_ForPrompts.length > 0) {

                ShowFinalPromptNotifications(Category);
            }
        }
    }

}
//=========================================================
// Generic function to fetch the record based on 
// Category
//=========================================================
function getPromptNotificationsForCase(fieldNames, Category) {
    debugger;
    if (Category == "Post") {
        NOTIFICATIONCATEGORY = NEWPOSTADDEDCATEGORY;

    }
    else if (Category == "90DaysExtension") {
        NOTIFICATIONCATEGORY = NINETYDAYNOTIFICATIONCATEGORY;

    }

    debugger;
    var queryForPrompt = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                        "<entity name='rbs_notification'>" +
                                            "<attribute name='rbs_notificationid' />" +
                                            "<attribute name='rbs_notificationmessageid' />" +
                                            "<attribute name='rbs_applicablefrom' />" +
                                            "<order attribute='rbs_applicablefrom' descending='false' />" +
                                            "<filter type='and'>" +
                                            "<condition attribute='rbs_applicablefrom' operator='on-or-before' value='" + formatDate(new Date()) + "' />" +
                                            "<condition attribute='rbs_notificationdisplaytype' operator='eq' value='" + PROMPTNOTIFICATION + "' />" + //Prompt                                                           
                                            "<condition attribute='rbs_notificationcategory' operator='eq' value='" + NOTIFICATIONCATEGORY + "' />" + //90 days Extension or POST
                                            "<condition attribute='rbs_promptenabled' operator='eq' value='" + PROMPTENABLED + "' />" + //Prompt Enabled = Yes
                                            "<condition attribute='rbs_regarding' operator='eq' value='" + caseId + "' />" +
                                                "<filter type='or'>" +
                                                    "<condition attribute='rbs_applicabletill' operator='null'/> " +
                                                    "<condition attribute='rbs_applicabletill' operator='on-or-after' value='" + formatDate(new Date()) + "' />" +
                                            "</filter>" +
                                            "</filter>" +
                                            "<link-entity name='rbs_notificationrecipient' from='rbs_notification' to='rbs_notificationid' alias='recipient'>" +
                                            "<attribute name='rbs_notificationrecipientid' />" +
                                            "<attribute name='rbs_recipienttype' />" +
                                            "<attribute name='rbs_user' />" +
                                                "<filter type='and'>" +
                                                    "<condition attribute='rbs_user' operator='eq' value='" + currentUserId + "' />" +
                                                    "<condition attribute='rbs_lastacknowledgedon' operator='null' />" +
                                                "</filter>" +
                                            "</link-entity>" +
                                            "<link-entity name='rbs_notificationmessages' from='rbs_notificationmessagesid' to='rbs_notificationmessageid' >" +
                                                    "<attribute name='rbs_notificationdescription' alias='rbs_notificationdescription' />" +
                                            "</link-entity>" +
                                            "<link-entity name='incident' alias='case' to='rbs_regarding' from='incidentid' link-type='outer' visible='false'>" +
                                                "<attribute name='ownerid'/>";
    if (Category == "90DaysExtension") {
        for (var i = 0; i < fieldNames.length; i++) {
            if (Xrm.Page.getAttribute(fieldNames[i]) != null) {
                queryForPrompt += "<attribute name='" + fieldNames[i] + "' alias= '" + fieldNames[i] + "' />"
            }
        }
    }
    queryForPrompt += "</link-entity>" +
"</entity>" +
"</fetch>";
    var FetchedNotifications = XrmServiceToolkit.Soap.Fetch(queryForPrompt);
    if (FetchedNotifications.length > 0) {
        FinalDisplayList_ForPrompts[0] = FetchedNotifications[0];
    }
}
//=========================================================
// This function is to get the specific text within the 
// Prompt Message that needs to be dynamically replaced 
// with the field on the Entity Form
//=========================================================
function getExtensionDuePromptTextForCase() {
    var strUIMessage = '';
    //Query to get Message Text    
    var queryExtensionDuePromptTextForCase = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                            "<entity name='rbs_notification'>" +
                                            "<attribute name='rbs_notificationmessageid' />" +
                                            "<filter type='and'>" +
                                                "<condition attribute='rbs_applicablefrom' operator='on-or-before' value='" + formatDate(new Date()) + "' />" +
                                                "<condition attribute='rbs_notificationdisplaytype' operator='eq' value='" + PROMPTNOTIFICATION + "' />" + //Prompt                                                           
                                                "<condition attribute='rbs_notificationcategory' operator='eq' value='" + NOTIFICATIONCATEGORY + "' />" + //90 days Extension// 859770001
                                                "<condition attribute='rbs_promptenabled' operator='eq' value='" + PROMPTENABLED + "' />" + //Prompt Enabled = Yes
                                                "<condition attribute='rbs_regarding' operator='eq' value='" + caseId + "' />" +
                                            "</filter>" +
                                            "<link-entity name='rbs_notificationrecipient' from='rbs_notification' to='rbs_notificationid' alias='recipient'>" +
                                                "<filter type='and'>" +
                                                "<condition attribute='rbs_user' operator='eq' value='" + currentUserId + "' />" +
                                                "<condition attribute='rbs_lastacknowledgedon' operator='null' />" +
                                                "</filter>" +
                                            "</link-entity>" +
                                            "</entity>" +
                                        "</fetch>";

    var FetchedExtensionDueText = XrmServiceToolkit.Soap.Fetch(queryExtensionDuePromptTextForCase);
    if (FetchedExtensionDueText.length > 0) {
        Text_ForPrompts[0] = FetchedExtensionDueText[0];
        strUIMessage = Text_ForPrompts["0"].attributes.rbs_notificationmessageid.formattedValue;
    }

    //regex to extract the field names from Notification Text
    if (strUIMessage.match(/<[^>]*>/g) != null) {
        matches = strUIMessage.match(/<[^>]*>/g);
        for (var i = 0; i < matches.length; i++) {
            var str = matches[i];
            fieldNames[i] = str.substring(1, str.length - 1);
        }
    }
}
//================================ 
// Get the Latest Post Date
// of this Case entity
//================================ 
function fetchLatestPostDate() {
    var queryLatestPostDateForCase = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' count='1'>" +
                                        "<entity name='post'>" +
                                            "<attribute name='createdon' />" +
                                            "<order attribute='createdon' descending='true' />" +
                                                "<filter type='and'>" +
                                                    "<condition attribute='text' operator='like' value='%&#91;CMP Post&#93;%' />" +
                                                    "<condition attribute='source' operator='eq' value='2' />" +
                                                "</filter>" +
                                                "<link-entity name='incident' from='incidentid' to='regardingobjectid' alias='aa'>" +
                                                    "<filter type='and'>" +
                                                        "<condition attribute='incidentid' operator='eq' value='" + caseId + "' />" +
                                                    "</filter>" +
                                                "</link-entity>" +
                                        "</entity>" +
                                    "</fetch>";

    var FetchedLatestPostDateForCase = XrmServiceToolkit.Soap.Fetch(queryLatestPostDateForCase);

    if (FetchedLatestPostDateForCase.length > 0) {
        return FetchedLatestPostDateForCase[0].attributes.createdon.value;
    }
    return "";
}
//==================================================
// Show the  Prompt Notifications
//===================================================
function ShowFinalPromptNotifications(Category) {
    var finalMessage = '';
    var strUIMessage = '';
    var recipientType;

    if (FinalDisplayList_ForPrompts[0]) {
        strUIMessage = FinalDisplayList_ForPrompts["0"].attributes.rbs_notificationmessageid.formattedValue;

        // Get the Recipient type 
        recipientType = FinalDisplayList_ForPrompts["0"].attributes["recipient.rbs_recipienttype"].value

        //========================================================================
        // The User should be  configured as a PRIMARY OR SECONDARY Recipient
        //========================================================================
        if (recipientType == PRIMARYRECIPIENT || recipientType == SECONDARYRECIPIENT)
        {
            debugger;
            if (Category == "90DaysExtension")
            {
                // Setting the Category for Next Prompt to Show
                //Category = "Post";
                finalMessage = Get90DayExtensionFormattedMessage(strUIMessage);

                Alert.show(finalMessage, "<br>" + (FinalDisplayList_ForPrompts["0"].attributes.rbs_notificationdescription != undefined ? FinalDisplayList_ForPrompts["0"].attributes.rbs_notificationdescription.value : ""),
                [
                    new Alert.Button("Ok", function () {
                        // Per the new Enhacement , this is commented 
                        // 1) Prompts should be visible to ALL the recipients classified as PRIMARY or SECONDARY
                        // 2) Prompts should be updated only by PRIMARY Users
                        // if (FinalDisplayList_ForPrompts["0"].attributes["case.ownerid"].id.toLowerCase() == currentUserId.substring(1, currentUserId.length - 1).toLowerCase())
                        // if (FinalDisplayList_ForPrompts["0"].attributes["recipient.rbs_user"].id.toLowerCase() == currentUserId.substring(1, currentUserId.length - 1).toLowerCase())
                        // Anyone who is a PRIMARYRECIPIENT can update the Notification Recipient Entity
                        if (recipientType == PRIMARYRECIPIENT) {
                            updateNotificationRecipient(FinalDisplayList_ForPrompts["0"].attributes["recipient.rbs_notificationrecipientid"].value);
                        }
                        PreparePromptNotificationsForCase('Post');
                    }, false, false),

                    new Alert.Button("Not Now", function ()
                    {
                        debugger;
                        PreparePromptNotificationsForCase('Post');
                    }, false, false)
                ], "INFO", 500, 000, null, true, null);

            }
            else if (Category == "Post")
            {

                debugger;
                finalMessage = GetNewPostAddedFormattedMessage(strUIMessage, latestPostDate);
                Alert.show(finalMessage, "<br>Please ensure to check posts under Summary section on this case.",
                [
                new Alert.Button("OK", function () {
                    // Per the new Enhacement , this is commented 
                    // 1) Prompts should be visible to ALL the recipients classified as PRIMARY or SECONDARY
                    // 2) Prompts should be updated only by PRIMARY Users
                    //if (FinalDisplayList_ForPrompts["0"].attributes["case.ownerid"].id.toLowerCase() == currentUserId.substring(1, currentUserId.length - 1).toLowerCase())
                    //if (FinalDisplayList_ForPrompts["0"].attributes["recipient.rbs_user"].id.toLowerCase() == currentUserId.substring(1, currentUserId.length - 1).toLowerCase())
                    // Anyone who is a PRIMARYRECIPIENT can update the Notification Recipient Entity
                    if (recipientType == PRIMARYRECIPIENT)
                        updateNotificationRecipient(FinalDisplayList_ForPrompts["0"].attributes["recipient.rbs_notificationrecipientid"].value);
                }, false, false),

                ], "INFO", 500, 200, null, true, null);
            }
        }
        else
        {
            if (Category == "90DaysExtension") {
                PreparePromptNotificationsForCase('Post');
            }
        }

    }
}

//==================================================
// Format the Post Message
//==================================================
function GetNewPostAddedFormattedMessage(msg, latestPostDate) {
    var formattedMessage = "";
    if (msg.indexOf("<PostDate>") != -1)
        formattedMessage = msg.replace("<PostDate>", formatDate_DDMMYYYY(latestPostDate)).split("[newline]").join("<br>");
    return formattedMessage;
}
//==================================================
// Format the 90 Day Extension Message
//==================================================
function Get90DayExtensionFormattedMessage(msg) {
    var formattedMessage = "";
    var placeHolder = '';
    // (FinalDisplayList_ForPrompts["0"].attributes["case.rbs_90day_extensionexpiry"] != undefined) ? FinalDisplayList_ForPrompts["0"].attributes["case.rbs_90day_extensionexpiry"].value : new Date("1900-01-01")
    for (var i = 0; i < matches.length; i++) {
        placeHolder = FinalDisplayList_ForPrompts["0"].attributes[fieldNames[i]] != undefined ? FinalDisplayList_ForPrompts["0"].attributes[fieldNames[i]].value : new Date("1900-01-01")
        if (msg.indexOf(matches[i]) != -1) {
            msg = msg.replace(matches[i], formatDate_DDMMYYYY(placeHolder)).split("[newline]").join("\r\n");
        }
    }
    return msg;
}
///==============================================================================
//  Common Functions
//  Function to Update the Acknowledgement for Notifications 
//===============================================================================
function updateNotificationRecipient(notificationRecipientId) {
    //rbs_notificationrecipientid
    Process.callAction("rbs_Marknotificationacknowledgement",
    [{
        key: "notificationrecipient",
        type: Process.Type.EntityReference,
        value: { id: notificationRecipientId, entityType: "rbs_notificationrecipient" }
    }],
    function (params) {
        // Success
        for (var i = 0; i < params.length; i++) {
            //alert(params[i].key + "=" + params[i].value); 
        }
    },
    function (e) {
        // Error
        alert(e);
    }
);

}


function formatDate(date1) {
    // format: YYYY-MM-DD
    if (date1 != "" && new Date(date1) != "Invalid Date") {
        //var d =new Date(date1);
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        return (curr_year + "-" + curr_month + "-" + curr_date);
    }
    //return
    return "";
}

function formatDate_MMDDYYYY(date1) {
    // format: MM-DD-YYYY
    if (date1 != "" && new Date(date1) != "Invalid Date") {
        var d = new Date();
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        return (curr_month + "-" + curr_date + "-" + curr_year);
    }

    return "";
}

function formatDate_DDMMYYYY(date1) {
    // format: DD-MM-YYYY
    if (date1 != "" && new Date(date1) != "Invalid Date") {
        var d = new Date();
        var curr_date = date1.getDate();
        var curr_month = date1.getMonth() + 1; //Months are zero based
        var curr_year = date1.getFullYear();
        return (curr_date + "-" + curr_month + "-" + curr_year);
    }
    return "";
}
// ===============================================================


