﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace CalculateRollupField
{
    public    class CalculateRollupOnContact :  IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            Guid ContactID = Guid.Empty;
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));
            // Obtain the organization service reference which you will need for  
            // web service calls.  
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];
                

              
                if(context.MessageName.ToLower() == "update")
                {
                    // Order ID
                    Entity OrderObj = service.Retrieve("salesorder", entity.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("customerid"));
                    if (OrderObj.Contains("customerid"))
                    {
                        ContactID = OrderObj.GetAttributeValue<EntityReference>("customerid").Id; //new Guid("614aa1fb-bee1-ed11-a81c-000d3af12373");//
                    }
                

                }

                else if (context.MessageName.ToLower() == "delete")
                {
                    Entity entityPreImage = (Entity)context.PreEntityImages["PreImage"];
                    if (entityPreImage.Contains("customerid"))
                    {
                        ContactID = entityPreImage.GetAttributeValue<EntityReference>("customerid").Id; //new Guid("614aa1fb-bee1-ed11-a81c-000d3af12373");//
                    }

                }


                    tracingService.Trace("Contact ID :" + (ContactID).ToString());
                try
                {
                    tracingService.Trace("Order  ID :" + (entity.Id).ToString());
                    CalculateRollupFieldRequest request = new CalculateRollupFieldRequest

                    {

                        Target = new EntityReference("contact", ContactID), // Entity Reference of record that needs updating

                        FieldName = "demo_totalrewardspoints" // Rollup Field Name

                    };

                    CalculateRollupFieldResponse response = (CalculateRollupFieldResponse)service.Execute(request);
                    tracingService.Trace("This is response of cal field:" + response);

                    Entity ContactObj = service.Retrieve("contact", ContactID, new Microsoft.Xrm.Sdk.Query.ColumnSet("demo_totalrewardspoints"));

                    if (ContactObj.Contains("demo_totalrewardspoints"))
                    {
                        Int32 rollupfieldTotalPoints = ContactObj.GetAttributeValue<Int32>("demo_totalrewardspoints"); //new Guid("614aa1fb-bee1-ed11-a81c-000d3af12373");//
                        tracingService.Trace("rollupfieldTotalPoints:" + rollupfieldTotalPoints);
                        //Entity contactobj = new Entity("contact");
                        ContactObj["demo_totalrewardspointscopy"] = Convert.ToInt32(rollupfieldTotalPoints);
                        service.Update(ContactObj);
                    }

                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin.", ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }
            }

            else if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is EntityReference)
            {

                // Obtain the target entity from the input parameters.  
                EntityReference entity = (EntityReference)context.InputParameters["Target"];
                
                Entity entityPreImage = (Entity)context.PreEntityImages["PreImage"];

                tracingService.Trace("Preimage ID :" + entityPreImage.Id);

                if (context.MessageName.ToLower() == "delete")
                {
                    
                    if (entityPreImage.Contains("customerid"))
                    {

                      string logicalName =  entityPreImage.GetAttributeValue<EntityReference>("customerid").LogicalName;
                        ContactID = entityPreImage.GetAttributeValue<EntityReference>("customerid").Id;
                        //ContactID = new Guid("e30807b3-61db-ed11-8847-6045bda569ef");//entityPreImage.GetAttributeValue<EntityReference>("customerid").Id; //new Guid("614aa1fb-bee1-ed11-a81c-000d3af12373");//
                        tracingService.Trace("Logical Name :" + logicalName);
                        tracingService.Trace("Contact GUID :" + ContactID);
                    }

                }


                tracingService.Trace("Contact ID :" + (ContactID).ToString());
                try
                {
                    tracingService.Trace("Order  ID :" + (entity.Id).ToString());
                    CalculateRollupFieldRequest request = new CalculateRollupFieldRequest

                    {

                        Target = new EntityReference("contact", ContactID), // Entity Reference of record that needs updating

                        FieldName = "demo_totalrewardspoints" // Rollup Field Name

                    };

                  //  CalculateRollupFieldResponse response = (CalculateRollupFieldResponse)service.Execute(request);
                    //tracingService.Trace("This is response of cal field:" + response);



                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin.", ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }


            }
        }
    }
}
