﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace CalculateRollupField
{
    public class CalculateRollupField : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            Guid OrderID = Guid.Empty; 
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.  
                Entity entity = (Entity)context.InputParameters["Target"];

                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                // Order ID
                Entity OrderLibeObj = service.Retrieve("salesorderdetail", entity.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("salesorderid"));
                if(OrderLibeObj.Contains("salesorderid"))
                {
                    OrderID = OrderLibeObj.GetAttributeValue<EntityReference>("salesorderid").Id; //new Guid("614aa1fb-bee1-ed11-a81c-000d3af12373");//
                }
                

                 tracingService.Trace("Order ID :" + (OrderID).ToString());
                try
                {
                    tracingService.Trace("Order Line ID :" +(entity.Id).ToString());
                    CalculateRollupFieldRequest request = new CalculateRollupFieldRequest

                    {
                  
                    Target = new EntityReference("salesorder", OrderID), // Entity Reference of record that needs updating

                        FieldName = "demo_totalloyalitypoints" // Rollup Field Name

                    };

                    CalculateRollupFieldResponse response = (CalculateRollupFieldResponse)service.Execute(request);
                    tracingService.Trace("This is response of cal field:" + response);

                    Entity OrderObj = service.Retrieve("salesorder", OrderID, new Microsoft.Xrm.Sdk.Query.ColumnSet("demo_totalloyalitypoints"));

                    if (OrderObj.Contains("demo_totalloyalitypoints"))
                    {
                        Int32 rollupfieldTotalPoints = OrderObj.GetAttributeValue<Int32>("demo_totalloyalitypoints"); //new Guid("614aa1fb-bee1-ed11-a81c-000d3af12373");//
                        tracingService.Trace("rollupfieldTotalPoints:" + rollupfieldTotalPoints);
                        Entity updateorder = new Entity("salesorder");
                        OrderObj["demo_totalloyaltypointscopy"] = Convert.ToInt32(rollupfieldTotalPoints);
                        service.Update(OrderObj);
                    }

                   

                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in FollowUpPlugin.", ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("FollowUpPlugin: {0}", ex.ToString());
                    throw;
                }
            }
        }
    }
}
