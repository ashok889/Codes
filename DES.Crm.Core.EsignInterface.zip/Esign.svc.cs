﻿using DES.Crm.Core.EsignInterface.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;

namespace DES.Crm.Core.EsignInterface
{
    public class Esign : IEsignService
    {
        string errMsg = string.Empty;

        public LibraryDocumentsWrapper GetLibraryDocuments(string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetLibraryDocuments.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskGetLibDocuments = adobeEchoSignApi.GetLibraryDocuments();

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskGetLibDocuments != null && !taskGetLibDocuments.IsFaulted)
                {
                    var libDocs = taskGetLibDocuments.Result;

                    return ConvertToWrapper(libDocs);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public LibraryDocumentInfoWrapper GetLibraryDocument(string libraryDocumentId, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetLibraryDocument.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskGetLibDocument = adobeEchoSignApi.GetLibraryDocument(libraryDocumentId);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskGetLibDocument != null && !taskGetLibDocument.IsFaulted)
                {
                    var libDoc = taskGetLibDocument.Result;

                    return ConvertToWrapper(libDoc);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public byte[] GetCombinedDocument(string libraryDocumentId, bool auditReport, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetCombinedDocument.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskHttpResponse = adobeEchoSignApi.GetCombinedDocument(libraryDocumentId, auditReport);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskHttpResponse != null && !taskHttpResponse.IsFaulted)
                {
                    var httpResponse = taskHttpResponse.Result;

                    return httpResponse.Content.ReadAsByteArrayAsync().Result;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public TransientDocumentResponseWrapper CreateTransientDocument(string fileName, byte[] fileContents, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in CreateTransientDocument.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskTransDocResponse = adobeEchoSignApi.CreateTransientDocument(fileName, fileContents);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskTransDocResponse != null && !taskTransDocResponse.IsFaulted)
                {
                    if (taskTransDocResponse.Exception != null && taskTransDocResponse.Exception.InnerException != null)
                    {
                        throw new Exception(taskTransDocResponse.Exception.InnerException.Message);
                    }

                    var transDocResponse = taskTransDocResponse.Result;

                    return ConvertToWrapper(transDocResponse);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public MegaSignCreationResponseWrapper CreateMegaSign(MegaSignCreationRequestWrapper megaSignCreationRequest, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in CreateMegaSign.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskMegaSignCreationResponse = adobeEchoSignApi.CreateMegaSign(ConvertToBase(megaSignCreationRequest));

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskMegaSignCreationResponse != null && !taskMegaSignCreationResponse.IsFaulted)
                {
                    var MegaSignCreationResponse = taskMegaSignCreationResponse.Result;

                    return ConvertToWrapper(MegaSignCreationResponse);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public AgreementCreationResponseWrapper CreateAgreement(AgreementCreationInfoWrapper agreementCreationInfo, string triggeringUserEmailAddress, string integrationKey)
        {
            errMsg += "\nEntered in CreateAgreement.";

            try
            {   
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";
                                
                var taskAgreementCreationResponse = adobeEchoSignApi.CreateAgreement(ConvertToBase(agreementCreationInfo));

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";
                
                if (taskAgreementCreationResponse != null && !taskAgreementCreationResponse.IsFaulted)
                {
                    var agreementCreationResponse = taskAgreementCreationResponse.Result;

                    return ConvertToWrapper(agreementCreationResponse);                    
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public MegaSignChildAgreementsWrapper GetMegaSignAgreements(string megaSignId, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetMegaSignAgreements.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskMegaSignAgreements = adobeEchoSignApi.GetMegaSignAgreements(megaSignId);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskMegaSignAgreements != null && !taskMegaSignAgreements.IsFaulted)
                {
                    var megaSignAgreements = taskMegaSignAgreements.Result;

                    return ConvertToWrapper(megaSignAgreements);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public AgreementInfoWrapper GetAgreement(string agreementId, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetAgreement.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskGetAgreement = adobeEchoSignApi.GetAgreement(agreementId);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskGetAgreement != null && !taskGetAgreement.IsFaulted)
                {
                    var agreement = taskGetAgreement.Result;

                    return ConvertToWrapper(agreement);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public AgreementsWrapper GetAgreements(string query, string externalId, string externalGroup, string externalNamespace, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetAgreements.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskGetAgreements = adobeEchoSignApi.GetAgreements(query, externalId, externalGroup, externalNamespace);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskGetAgreements != null && !taskGetAgreements.IsFaulted)
                {
                    var agreements = taskGetAgreements.Result;

                    return ConvertToWrapper(agreements);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public SigningUrlResponseWrapper GetAgreementSigningUrls(string agreementId, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetAgreementSigningUrls.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskGetAgreementSigningUrls = adobeEchoSignApi.GetAgreementSigningUrls(agreementId);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskGetAgreementSigningUrls != null && !taskGetAgreementSigningUrls.IsFaulted)
                {
                    var agreementSigningUrls = taskGetAgreementSigningUrls.Result;

                    return ConvertToWrapper(agreementSigningUrls);
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public byte[] GetAgreementFormDataCsv(string agreementId, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in GetAgreementFormDataCsv.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskHttpResponse = adobeEchoSignApi.GetAgreementFormDataCsv(agreementId);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskHttpResponse != null && !taskHttpResponse.IsFaulted)
                {
                    var httpResponse = taskHttpResponse.Result;

                    return httpResponse.Content.ReadAsByteArrayAsync().Result;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        public string DeleteAgreement(string agreementId, string triggeringUserEmailAddress, string integrationKey = null)
        {
            errMsg += "\nEntered in DeleteAgreement.";

            try
            {
                var adobeEchoSignApi = new AdobeEchoSign(HttpClientWrapper.GetAdobeHttpClient(triggeringUserEmailAddress, integrationKey));

                errMsg += "\nApi Object Created.";

                var taskHttpResponse = adobeEchoSignApi.DeleteAgreement(agreementId);

                errMsg += "\nResponse Object Prepared.";

                errMsg += "\nReturning Response.";

                if (taskHttpResponse != null && !taskHttpResponse.IsFaulted)
                {
                    var httpResponse = taskHttpResponse.Result;

                    return httpResponse;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Error", new FaultReason(errMsg + "\nError: " + (ex.InnerException != null ? ex.InnerException.Message : ex.Message)));
            }
        }

        private LibraryDocumentsWrapper ConvertToWrapper(LibraryDocuments libDocs)
        {
            LibraryDocumentsWrapper libDocList = new LibraryDocumentsWrapper();

            if (libDocs != null)
            {
                if (libDocs.libraryDocumentList != null)
                {
                    #region libDocList.LibraryDocumentList

                    List<LibraryDocumentWrapper> libraryDocumentList = new List<LibraryDocumentWrapper>();

                    foreach (LibraryDocument doc in libDocs.libraryDocumentList)
                    {
                        LibraryDocumentWrapper libDoc = new LibraryDocumentWrapper();

                        libDoc.LibraryDocumentId = doc.libraryDocumentId;

                        if(doc.libraryTemplateTypes != null)
                        {
                            libDoc.LibraryTemplateTypes = doc.libraryTemplateTypes.ToList<LibraryTemplateType>();
                        }

                        libDoc.Name = doc.name;
                        libDoc.ModifiedDate = doc.modifiedDate;
                        libDoc.Scope = doc.scope;

                        libraryDocumentList.Add(libDoc);
                    }

                    libDocList.LibraryDocumentList = libraryDocumentList;

                    #endregion
                }
            }

            return libDocList;
        }

        private LibraryDocumentInfoWrapper ConvertToWrapper(LibraryDocumentInfo libDocInfo)
        {
            LibraryDocumentInfoWrapper libDocInfoWrapper = new LibraryDocumentInfoWrapper();

            if (libDocInfo != null)
            {
                libDocInfoWrapper.LibraryDocumentId = libDocInfo.libraryDocumentId;
                libDocInfoWrapper.Name = libDocInfo.name;
                libDocInfoWrapper.Locale = libDocInfo.locale;
                libDocInfoWrapper.Message = libDocInfo.message;

                if (libDocInfo.securityOptions != null)
                {
                    libDocInfoWrapper.SecurityOptions = libDocInfo.securityOptions.ToList<LibDocSecurityOption>();
                }

                libDocInfoWrapper.Status = libDocInfo.status;

                if (libDocInfo.events != null)
                {
                    #region libDocInfoWrapper.Events

                    List<LibDocumentHistoryEventWrapper> libDocumentHistoryEventWrapperList = new List<LibDocumentHistoryEventWrapper>();

                    foreach (LibDocumentHistoryEvent evnt in libDocInfo.events)
                    {
                        LibDocumentHistoryEventWrapper evntWrapper = new LibDocumentHistoryEventWrapper();

                        evntWrapper.ActingUserEmail = evnt.actingUserEmail;
                        evntWrapper.ActingUserIpAddress = evnt.actingUserIpAddress;
                        evntWrapper.Comment = evnt.comment;
                        evntWrapper.Date = evnt.date;
                        evntWrapper.Description = evnt.description;

                        if (evnt.deviceLocation != null)
                        {
                            #region DeviceLocation

                            LibDocEventDeviceLocationWrapper libDocEventDeviceLocationWrapper = new LibDocEventDeviceLocationWrapper();
                            libDocEventDeviceLocationWrapper.Latitude = evnt.deviceLocation.latitude;
                            libDocEventDeviceLocationWrapper.Longitude = evnt.deviceLocation.longitude;

                            evntWrapper.DeviceLocation = libDocEventDeviceLocationWrapper;

                            #endregion
                        }

                        evntWrapper.ParticipantEmail = evnt.participantEmail;
                        evntWrapper.SynchronizationId = evnt.synchronizationId;
                        evntWrapper.Type = evnt.type;
                        evntWrapper.VaultEventId = evnt.vaultEventId;
                        evntWrapper.VersionId = evnt.versionId;

                        libDocumentHistoryEventWrapperList.Add(evntWrapper);
                    }

                    libDocInfoWrapper.Events = libDocumentHistoryEventWrapperList;

                    #endregion
                }

                if (libDocInfo.participants != null)
                {
                    #region libDocInfoWrapper.Participants

                    List<LibDocParticipantInfoWrapper> libDocParticipantInfoWrapperList = new List<LibDocParticipantInfoWrapper>();

                    foreach (LibDocParticipantInfo participant in libDocInfo.participants)
                    {
                        libDocParticipantInfoWrapperList.Add(SetLibDocInfoWrapperParticipants(participant));
                    }

                    libDocInfoWrapper.Participants = libDocParticipantInfoWrapperList;

                    #endregion
                }
            }

            return libDocInfoWrapper;
        }

        private LibDocParticipantInfoWrapper SetLibDocInfoWrapperParticipants(LibDocParticipantInfo participant)
        {
            LibDocParticipantInfoWrapper participantWrapper = new LibDocParticipantInfoWrapper();

            if (participant.alternateParticipants != null)
            {
                #region AlternateParticipants

                List<LibDocParticipantInfoWrapper> lstLibDocParticipantInfoWrapper = new List<LibDocParticipantInfoWrapper>();

                foreach (LibDocParticipantInfo libDocParticipantInfo in participant.alternateParticipants)
                {
                    LibDocParticipantInfoWrapper libDocParticipantInfoWrapper = SetLibDocInfoWrapperParticipants(libDocParticipantInfo);

                    lstLibDocParticipantInfoWrapper.Add(libDocParticipantInfoWrapper);
                }

                participantWrapper.AlternateParticipants = lstLibDocParticipantInfoWrapper;

                #endregion
            }

            participantWrapper.Company = participant.company;
            participantWrapper.Email = participant.email;
            participantWrapper.Name = participant.name;

            if (participant.roles != null)
            {
                participantWrapper.Roles = participant.roles.ToList<LibDocParticipantRole>();
            }

            if (participant.securityOptions != null)
            {
                participantWrapper.SecurityOptions = participant.securityOptions.ToList<ParticipantSecurityOption>();
            }

            participantWrapper.Status = participant.status;
            participantWrapper.Title = participant.title;

            return participantWrapper;
        }

        private MegaSignCreationResponseWrapper ConvertToWrapper(MegaSignCreationResponse megaSignCreationResponse)
        {
            MegaSignCreationResponseWrapper megaSignCreationResponseWrapper = new MegaSignCreationResponseWrapper();

            if (megaSignCreationResponse != null)
            {
                megaSignCreationResponseWrapper.MegaSignId = megaSignCreationResponse.megaSignId;
            }

            return megaSignCreationResponseWrapper;
        }

        private TransientDocumentResponseWrapper ConvertToWrapper(TransientDocumentResponse transDocResponse)
        {
            TransientDocumentResponseWrapper transDocWrapper = new TransientDocumentResponseWrapper();

            if (transDocResponse != null)
            {
                transDocWrapper.TransientDocumentId = transDocResponse.transientDocumentId;
                transDocWrapper.Code = transDocResponse.code;
            }

            return transDocWrapper;
        }

        private AgreementCreationResponseWrapper ConvertToWrapper(AgreementCreationResponse agreementCreationResponse)
        {
            AgreementCreationResponseWrapper agreementCreationResponseWrapper = new AgreementCreationResponseWrapper();

            if (agreementCreationResponse != null)
            {
                agreementCreationResponseWrapper.AgreementId = agreementCreationResponse.agreementId;
                agreementCreationResponseWrapper.EmbeddedCode = agreementCreationResponse.embeddedCode;
                agreementCreationResponseWrapper.Expiration = agreementCreationResponse.expiration;
                agreementCreationResponseWrapper.Url = agreementCreationResponse.url;
            }

            return agreementCreationResponseWrapper;
        }

        private MegaSignChildAgreementsWrapper ConvertToWrapper(MegaSignChildAgreements megaSignAgreements)
        {
            MegaSignChildAgreementsWrapper megaSignChildAgreementsWrapper = new MegaSignChildAgreementsWrapper();

            if (megaSignAgreements != null)
            {
                if (megaSignAgreements.megaSignChildAgreementList != null)
                {
                    #region megaSignChildAgreementsWrapper.MegaSignChildAgreementList

                    List<MegaSignChildAgreementWrapper> megaSignChildAgreementWrapperList = new List<MegaSignChildAgreementWrapper>();

                    foreach (MegaSignChildAgreement agreement in megaSignAgreements.megaSignChildAgreementList)
                    {
                        MegaSignChildAgreementWrapper megaSignChildAgreementWrapper = new MegaSignChildAgreementWrapper();
                        megaSignChildAgreementWrapper.AgreementId = agreement.agreementId;
                        megaSignChildAgreementWrapper.DisplayDate = agreement.displayDate;
                        megaSignChildAgreementWrapper.Esign = agreement.esign;
                        megaSignChildAgreementWrapper.Name = agreement.name;
                        megaSignChildAgreementWrapper.Status = agreement.status;

                        megaSignChildAgreementWrapperList.Add(megaSignChildAgreementWrapper);
                    }

                    megaSignChildAgreementsWrapper.MegaSignChildAgreementList = megaSignChildAgreementWrapperList;

                    #endregion
                }
            }

            return megaSignChildAgreementsWrapper;
        }

        private AgreementInfoWrapper ConvertToWrapper(AgreementInfo agreement)
        {
            AgreementInfoWrapper agreementInfoWrapper = new AgreementInfoWrapper();

            if (agreement != null)
            {
                agreementInfoWrapper.AgreementId = agreement.agreementId;

                if (agreement.events != null)
                {
                    #region agreementInfoWrapper.Events

                    List<DocumentHistoryEventWrapper> documentHistoryEventWrapperList = new List<DocumentHistoryEventWrapper>();

                    foreach (DocumentHistoryEvent documentHistoryEvent in agreement.events)
                    {
                        DocumentHistoryEventWrapper documentHistoryEventWrapper = new DocumentHistoryEventWrapper();

                        documentHistoryEventWrapper.ActingUserEmail = documentHistoryEvent.actingUserEmail;
                        documentHistoryEventWrapper.ActingUserIpAddress = documentHistoryEvent.actingUserIpAddress;
                        documentHistoryEventWrapper.Comment = documentHistoryEvent.comment;
                        documentHistoryEventWrapper.Date = documentHistoryEvent.date;
                        documentHistoryEventWrapper.Description = documentHistoryEvent.description;

                        if (documentHistoryEvent.deviceLocation != null)
                        {
                            #region DeviceLocation

                            DeviceLocationWrapper deviceLocationWrapper = new DeviceLocationWrapper();
                            deviceLocationWrapper.Latitude = documentHistoryEvent.deviceLocation.latitude;
                            deviceLocationWrapper.Longitude = documentHistoryEvent.deviceLocation.longitude;

                            documentHistoryEventWrapper.DeviceLocation = deviceLocationWrapper;

                            #endregion
                        }

                        documentHistoryEventWrapper.ParticipantEmail = documentHistoryEvent.participantEmail;
                        documentHistoryEventWrapper.SynchronizationId = documentHistoryEvent.synchronizationId;
                        documentHistoryEventWrapper.Type = documentHistoryEvent.type;
                        documentHistoryEventWrapper.VaultEventId = documentHistoryEvent.vaultEventId;
                        documentHistoryEventWrapper.VersionId = documentHistoryEvent.versionId;

                        documentHistoryEventWrapperList.Add(documentHistoryEventWrapper);
                    }

                    agreementInfoWrapper.Events = documentHistoryEventWrapperList;

                    #endregion
                }

                agreementInfoWrapper.Expiration = agreement.expiration;
                agreementInfoWrapper.Locale = agreement.locale;
                agreementInfoWrapper.Message = agreement.message;
                agreementInfoWrapper.Modifiable = agreement.modifiable;
                agreementInfoWrapper.Name = agreement.name;

                if (agreement.nextParticipantSetInfos != null)
                {
                    #region agreementInfoWrapper.NextParticipantSetInfos

                    List<NextparticipantsetinfoWrapper> nextparticipantsetinfoWrapperList = new List<NextparticipantsetinfoWrapper>();

                    foreach (Nextparticipantsetinfo nextparticipantsetinfo in agreement.nextParticipantSetInfos)
                    {
                        NextparticipantsetinfoWrapper nextparticipantsetinfoWrapper = new NextparticipantsetinfoWrapper();

                        if (nextparticipantsetinfo.nextParticipantSetMemberInfos != null)
                        {
                            #region nextparticipantsetinfoWrapper.NextParticipantSetMemberInfos

                            List<NextparticipantsetmemberinfoWrapper> nextparticipantsetmemberinfoWrapperList = new List<NextparticipantsetmemberinfoWrapper>();

                            foreach (Nextparticipantsetmemberinfo nextparticipantsetmemberinfo in nextparticipantsetinfo.nextParticipantSetMemberInfos)
                            {
                                NextparticipantsetmemberinfoWrapper nextparticipantsetmemberinfoWrapper = new NextparticipantsetmemberinfoWrapper();

                                nextparticipantsetmemberinfoWrapper.WaitingSince = nextparticipantsetmemberinfo.waitingSince;
                                nextparticipantsetmemberinfoWrapper.Email = nextparticipantsetmemberinfo.email;
                                nextparticipantsetmemberinfoWrapper.Name = nextparticipantsetmemberinfo.name;

                                nextparticipantsetmemberinfoWrapperList.Add(nextparticipantsetmemberinfoWrapper);
                            }

                            nextparticipantsetinfoWrapper.NextParticipantSetMemberInfos = nextparticipantsetmemberinfoWrapperList;

                            #endregion
                        }

                        nextparticipantsetinfoWrapperList.Add(nextparticipantsetinfoWrapper);
                    }

                    agreementInfoWrapper.NextParticipantSetInfos = nextparticipantsetinfoWrapperList;

                    #endregion
                }

                if (agreement.participantSetInfos != null)
                {
                    #region agreementInfoWrapper.ParticipantSetInfos

                    List<ParticipantSetInfoWrapper> participantSetInfoWrapperList = new List<ParticipantSetInfoWrapper>();

                    foreach (ParticipantSetInfo participantSetInfo in agreement.participantSetInfos)
                    {
                        participantSetInfoWrapperList.Add(ConvertToWrapper(participantSetInfo));
                    }

                    agreementInfoWrapper.ParticipantSetInfos = participantSetInfoWrapperList;

                    #endregion
                }

                if(agreement.securityOptions != null)
                agreementInfoWrapper.SecurityOptions = agreement.securityOptions.ToList<DocSecurityOption>();

                agreementInfoWrapper.Status = agreement.status;
            }

            return agreementInfoWrapper;
        }

        private ParticipantSetInfoWrapper ConvertToWrapper(ParticipantSetInfo participantSetInfo)
        {
            ParticipantSetInfoWrapper participantSetInfoWrapper = new ParticipantSetInfoWrapper();

            if (participantSetInfo != null)
            {
                participantSetInfoWrapper.Roles = participantSetInfo.roles;
                participantSetInfoWrapper.SecurityOptions = participantSetInfo.securityOptions;
                participantSetInfoWrapper.SigningOrder = participantSetInfo.signingOrder;
                participantSetInfoWrapper.Status = participantSetInfo.status;

                if (participantSetInfo.participantSetMemberInfos != null)
                {
                    #region participantSetInfoWrapper.ParticipantSetMemberInfos

                    List<ParticipantInfoWrapper> participantInfoWrapperList = new List<ParticipantInfoWrapper>();

                    foreach (ParticipantInfo participantInfo in participantSetInfo.participantSetMemberInfos)
                    {
                        ParticipantInfoWrapper participantInfoWrapper = new ParticipantInfoWrapper();

                        participantInfoWrapper.Company = participantInfo.company;
                        participantInfoWrapper.Email = participantInfo.email;
                        participantInfoWrapper.Name = participantInfo.name;

                        if(participantInfo.securityOptions != null)
                            participantInfoWrapper.SecurityOptions = participantInfo.securityOptions.ToList<ParticipantSecurityOption>();

                        participantInfoWrapper.Title = participantInfo.title;

                        if (participantInfo.alternateParticipants != null)
                            participantInfoWrapper.AlternateParticipants = ConvertToWrapper(participantInfo.alternateParticipants);
                        else
                            participantInfoWrapper.AlternateParticipants = null;

                        participantInfoWrapperList.Add(participantInfoWrapper);
                    }

                    participantSetInfoWrapper.ParticipantSetMemberInfos = participantInfoWrapperList;

                    #endregion
                }
            }

            return participantSetInfoWrapper;
        }

        private SigningUrlResponseWrapper ConvertToWrapper(SigningUrlResponse agreementSigningUrls)
        {
            SigningUrlResponseWrapper signingUrlResponseWrapper = new SigningUrlResponseWrapper();

            if (agreementSigningUrls != null)
            {
                signingUrlResponseWrapper.Code = agreementSigningUrls.code;
                signingUrlResponseWrapper.Message = agreementSigningUrls.message;

                if (agreementSigningUrls.signingUrlSetInfos != null)
                {
                    #region signingUrlResponseWrapper.SigningUrlSetInfos

                    List<SigningUrlSetInfoWrapper> signingUrlSetInfoWrapperList = new List<SigningUrlSetInfoWrapper>();

                    foreach (SigningUrlSetInfo signingUrls in agreementSigningUrls.signingUrlSetInfos)
                    {
                        SigningUrlSetInfoWrapper signingUrlSetInfoWrapper = new SigningUrlSetInfoWrapper();

                        if (signingUrls.signingUrls != null)
                        {
                            #region signingUrlSetInfoWrapper.SigningUrls

                            List<SigningUrlWrapper> signingUrlWrapperList = new List<SigningUrlWrapper>();

                            foreach (SigningUrl urls in signingUrls.signingUrls)
                            {
                                SigningUrlWrapper signingUrlWrapper = new SigningUrlWrapper();
                                signingUrlWrapper.Email = urls.email;
                                signingUrlWrapper.EsignUrl = urls.esignUrl;

                                signingUrlWrapperList.Add(signingUrlWrapper);
                            }

                            signingUrlSetInfoWrapper.SigningUrls = signingUrlWrapperList;

                            #endregion
                        }

                        signingUrlSetInfoWrapperList.Add(signingUrlSetInfoWrapper);
                    }

                    signingUrlResponseWrapper.SigningUrlSetInfos = signingUrlSetInfoWrapperList;

                    #endregion
                }
            }

            return signingUrlResponseWrapper;
        }

        private AgreementsWrapper ConvertToWrapper(Agreements agreements)
        {
            AgreementsWrapper agreementsWrapper = new AgreementsWrapper();
            if (agreements != null)
            {
                if (agreements.userAgreementList != null)
                {
                    List<UseragreementlistWrapper> lstUseragreementlistWrapper = new List<UseragreementlistWrapper>();

                    foreach (Useragreementlist useragreementlist in agreements.userAgreementList)
                    {
                        UseragreementlistWrapper useragreementlistWrapper = new UseragreementlistWrapper();
                        useragreementlistWrapper.AgreementId = useragreementlist.agreementId;
                        useragreementlistWrapper.DisplayDate = useragreementlist.displayDate;

                        if (useragreementlist.displayUserSetInfos != null)
                        {
                            #region DisplayUserSetInfos

                            List<DisplayusersetinfoWrapper> lstDisplayusersetinfoWrapper = new List<DisplayusersetinfoWrapper>();

                            foreach (Displayusersetinfo displayusersetinfo in useragreementlist.displayUserSetInfos)
                            {
                                DisplayusersetinfoWrapper displayusersetinfoWrapper = new DisplayusersetinfoWrapper();

                                if (displayusersetinfo.displayUserSetMemberInfos != null)
                                {
                                    #region DisplayUserSetMemberInfos

                                    List<DisplayusersetmemberinfoWrapper> lstDisplayusersetmemberinfoWrapper = new List<DisplayusersetmemberinfoWrapper>();

                                    foreach (Displayusersetmemberinfo displayusersetmemberinfo in displayusersetinfo.displayUserSetMemberInfos)
                                    {
                                        DisplayusersetmemberinfoWrapper displayusersetmemberinfoWrapper = new DisplayusersetmemberinfoWrapper();
                                        displayusersetmemberinfoWrapper.Company = displayusersetmemberinfo.company;
                                        displayusersetmemberinfoWrapper.Email = displayusersetmemberinfo.email;
                                        displayusersetmemberinfoWrapper.FullName = displayusersetmemberinfo.fullName;

                                        lstDisplayusersetmemberinfoWrapper.Add(displayusersetmemberinfoWrapper);
                                    }

                                    displayusersetinfoWrapper.DisplayUserSetMemberInfos = lstDisplayusersetmemberinfoWrapper;

                                    #endregion
                                }

                                lstDisplayusersetinfoWrapper.Add(displayusersetinfoWrapper);
                            }

                            useragreementlistWrapper.DisplayUserSetInfos = lstDisplayusersetinfoWrapper;

                            #endregion
                        }

                        useragreementlistWrapper.Esign = useragreementlist.esign;
                        useragreementlistWrapper.LatestVersionId = useragreementlist.latestVersionId;
                        useragreementlistWrapper.Name = useragreementlist.name;
                        useragreementlistWrapper.Status = useragreementlist.status;

                        lstUseragreementlistWrapper.Add(useragreementlistWrapper);
                    }

                    agreementsWrapper.UserAgreementList = lstUseragreementlistWrapper;
                }
            }

            return agreementsWrapper;
        }

        private MegaSignCreationRequest ConvertToBase(MegaSignCreationRequestWrapper megaSignCreationRequestWrapper)
        {
            MegaSignCreationRequest megaSignCreationRequest = new MegaSignCreationRequest();

            if (megaSignCreationRequestWrapper != null)
            {
                MegaSignCreationInfo megaSignCreationInfo = new MegaSignCreationInfo();

                if (megaSignCreationRequestWrapper.MegaSignCreationInfo != null)
                {
                    megaSignCreationInfo.callbackInfo = megaSignCreationRequestWrapper.MegaSignCreationInfo.CallbackInfo;

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.Ccs != null)
                        megaSignCreationInfo.ccs = megaSignCreationRequestWrapper.MegaSignCreationInfo.Ccs.ToArray();

                    megaSignCreationInfo.daysUntilSigningDeadline = megaSignCreationRequestWrapper.MegaSignCreationInfo.DaysUntilSigningDeadline;

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.ExternalId != null)
                    {
                        #region ExternalId

                        ExternalId externalId = new ExternalId();
                        externalId.group = megaSignCreationRequestWrapper.MegaSignCreationInfo.ExternalId.Group;
                        externalId.id = megaSignCreationRequestWrapper.MegaSignCreationInfo.ExternalId.Id;
                        externalId.nameSpace = megaSignCreationRequestWrapper.MegaSignCreationInfo.ExternalId.NameSpace;

                        megaSignCreationInfo.externalId = externalId;

                        #endregion
                    }

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.FileInfos != null)
                    {
                        #region FileInfos

                        List<FileInfo> lstFileInfo = new List<FileInfo>();

                        foreach (FileInfoWrapper fileInfoWrapper in megaSignCreationRequestWrapper.MegaSignCreationInfo.FileInfos)
                        {
                            FileInfo fileInfo = new FileInfo();

                            if (fileInfoWrapper.DocumentURL != null)
                            {
                                #region DocumentURL

                                URLFileInfo urlFileInfo = new URLFileInfo();
                                urlFileInfo.mimeType = fileInfoWrapper.DocumentURL.MimeType;
                                urlFileInfo.name = fileInfoWrapper.DocumentURL.Name;
                                urlFileInfo.url = fileInfoWrapper.DocumentURL.Url;

                                fileInfo.documentURL = urlFileInfo;

                                #endregion
                            }

                            fileInfo.libraryDocumentId = fileInfoWrapper.LibraryDocumentId;
                            fileInfo.libraryDocumentName = fileInfoWrapper.LibraryDocumentName;
                            fileInfo.transientDocumentId = fileInfoWrapper.TransientDocumentId;

                            lstFileInfo.Add(fileInfo);
                        }

                        megaSignCreationInfo.fileInfos = lstFileInfo.ToArray<FileInfo>();

                        #endregion
                    }

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.FormFieldLayerTemplates != null)
                    {
                        #region FormFieldLayerTemplates

                        List<FileInfo> lstFileInfo = new List<FileInfo>();

                        foreach (FileInfoWrapper fileInfoWrapper in megaSignCreationRequestWrapper.MegaSignCreationInfo.FormFieldLayerTemplates)
                        {
                            FileInfo fileInfo = new FileInfo();

                            if (fileInfoWrapper.DocumentURL != null)
                            {
                                #region DocumentURL

                                URLFileInfo urlFileInfo = new URLFileInfo();
                                urlFileInfo.mimeType = fileInfoWrapper.DocumentURL.MimeType;
                                urlFileInfo.name = fileInfoWrapper.DocumentURL.Name;
                                urlFileInfo.url = fileInfoWrapper.DocumentURL.Url;

                                fileInfo.documentURL = urlFileInfo;

                                #endregion
                            }

                            fileInfo.libraryDocumentId = fileInfoWrapper.LibraryDocumentId;
                            fileInfo.libraryDocumentName = fileInfoWrapper.LibraryDocumentName;
                            fileInfo.transientDocumentId = fileInfoWrapper.TransientDocumentId;

                            lstFileInfo.Add(fileInfo);
                        }

                        megaSignCreationInfo.formFieldLayerTemplates = lstFileInfo.ToArray<FileInfo>();

                        #endregion
                    }

                    megaSignCreationInfo.locale = megaSignCreationRequestWrapper.MegaSignCreationInfo.Locale;

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.MergeFieldInfo != null)
                    {
                        #region MergeFieldInfo

                        List<MergefieldInfo> lstMergeFieldInfo = new List<MergefieldInfo>();

                        foreach (MergefieldInfoWrapper mergefieldInfoWrapper in megaSignCreationRequestWrapper.MegaSignCreationInfo.MergeFieldInfo)
                        {
                            MergefieldInfo mergefieldInfo = new MergefieldInfo();

                            mergefieldInfo.defaultValue = mergefieldInfoWrapper.DefaultValue;
                            mergefieldInfo.fieldName = mergefieldInfoWrapper.FieldName;

                            lstMergeFieldInfo.Add(mergefieldInfo);
                        }

                        megaSignCreationInfo.mergeFieldInfo = lstMergeFieldInfo.ToArray<MergefieldInfo>();

                        #endregion
                    }

                    megaSignCreationInfo.mergeFileTransientId = megaSignCreationRequestWrapper.MegaSignCreationInfo.MergeFileTransientId;
                    megaSignCreationInfo.message = megaSignCreationRequestWrapper.MegaSignCreationInfo.Message;
                    megaSignCreationInfo.name = megaSignCreationRequestWrapper.MegaSignCreationInfo.Name;

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.PostSignOptions != null)
                    {
                        #region PostSignOptions

                        PostSignOptions postSignOptions = new PostSignOptions();
                        postSignOptions.redirectDelay = megaSignCreationRequestWrapper.MegaSignCreationInfo.PostSignOptions.RedirectDelay;
                        postSignOptions.redirectUrl = megaSignCreationRequestWrapper.MegaSignCreationInfo.PostSignOptions.RedirectUrl;

                        megaSignCreationInfo.postSignOptions = postSignOptions;

                        #endregion
                    }

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.RecipientSetInfos != null)
                    {
                        #region RecipientSetInfos

                        List<RecipientSetInfo> lstRecipientSetInfo = new List<RecipientSetInfo>();

                        foreach (RecipientSetInfoWrapper recipientSetInfoWrapper in megaSignCreationRequestWrapper.MegaSignCreationInfo.RecipientSetInfos)
                        {
                            RecipientSetInfo recipientSetInfo = new RecipientSetInfo();

                            if (recipientSetInfoWrapper.RecipientSetMemberInfos != null)
                            {
                                #region RecipientSetMemberInfos

                                List<RecipientInfo> lstRecipientInfo = new List<RecipientInfo>();

                                foreach (RecipientInfoWrapper recipientInfoWrapper in recipientSetInfoWrapper.RecipientSetMemberInfos)
                                {
                                    RecipientInfo recipientInfo = new RecipientInfo();
                                    recipientInfo.email = recipientInfoWrapper.Email;
                                    recipientInfo.fax = recipientInfoWrapper.Fax;

                                    if (recipientInfoWrapper.SecurityOptions != null)
                                    {
                                        #region RecipeintSecurityOption

                                        List<RecipientSecurityOption> lstRecipientSecurityOption = new List<RecipientSecurityOption>();

                                        foreach (RecipientSecurityOptionWrapper recipientSecurityOptionWrapper in recipientInfoWrapper.SecurityOptions)
                                        {
                                            RecipientSecurityOption recipientSecurityOption = new RecipientSecurityOption();
                                            recipientSecurityOption.authenticationMethod = recipientSecurityOptionWrapper.AuthenticationMethod;
                                            recipientSecurityOption.password = recipientSecurityOptionWrapper.Password;

                                            if (recipientSecurityOptionWrapper.PhoneInfos != null)
                                            {
                                                #region PhoneInfos

                                                List<PhoneInfo> lstPhoneInfo = new List<PhoneInfo>();

                                                foreach (PhoneInfoWrapper phoneInfoWrapper in recipientSecurityOptionWrapper.PhoneInfos)
                                                {
                                                    PhoneInfo phoneInfo = new PhoneInfo();
                                                    phoneInfo.countryCode = phoneInfoWrapper.CountryCode;
                                                    phoneInfo.phone = phoneInfoWrapper.Phone;

                                                    lstPhoneInfo.Add(phoneInfo);
                                                }

                                                recipientSecurityOption.phoneInfos = lstPhoneInfo.ToArray<PhoneInfo>();

                                                #endregion
                                            }

                                            lstRecipientSecurityOption.Add(recipientSecurityOption);
                                        }

                                        recipientInfo.securityOptions = lstRecipientSecurityOption.ToArray<RecipientSecurityOption>();

                                        #endregion
                                    }

                                    lstRecipientInfo.Add(recipientInfo);
                                }

                                recipientSetInfo.recipientSetMemberInfos = lstRecipientInfo.ToArray<RecipientInfo>();

                                #endregion
                            }

                            recipientSetInfo.recipientSetRole = recipientSetInfoWrapper.RecipientSetRole;

                            if (recipientSetInfoWrapper.SecurityOptions != null)
                            {
                                #region SecurityOption

                                List<RecipientSecurityOption> lstSecurityOption = new List<RecipientSecurityOption>();

                                foreach (RecipientSecurityOptionWrapper recipientSecurityOptionWrapper in recipientSetInfoWrapper.SecurityOptions)
                                {
                                    RecipientSecurityOption recipientSecurityOption = new RecipientSecurityOption();
                                    recipientSecurityOption.authenticationMethod = recipientSecurityOptionWrapper.AuthenticationMethod;
                                    recipientSecurityOption.password = recipientSecurityOptionWrapper.Password;

                                    if (recipientSecurityOptionWrapper.PhoneInfos != null)
                                    {
                                        #region PhoneInfos

                                        List<PhoneInfo> lstPhoneInfo = new List<PhoneInfo>();

                                        foreach (PhoneInfoWrapper phoneInfoWrapper in recipientSecurityOptionWrapper.PhoneInfos)
                                        {
                                            PhoneInfo phoneInfo = new PhoneInfo();
                                            phoneInfo.countryCode = phoneInfoWrapper.CountryCode;
                                            phoneInfo.phone = phoneInfoWrapper.Phone;

                                            lstPhoneInfo.Add(phoneInfo);
                                        }

                                        recipientSecurityOption.phoneInfos = lstPhoneInfo.ToArray<PhoneInfo>();

                                        #endregion
                                    }

                                    lstSecurityOption.Add(recipientSecurityOption);
                                }

                                recipientSetInfo.securityOptions = lstSecurityOption.ToArray<RecipientSecurityOption>();

                                #endregion
                            }

                            recipientSetInfo.signingOrder = recipientSetInfoWrapper.SigningOrder;

                            lstRecipientSetInfo.Add(recipientSetInfo);
                        }

                        megaSignCreationInfo.recipientSetInfos = lstRecipientSetInfo.ToArray<RecipientSetInfo>();

                        #endregion
                    }

                    megaSignCreationInfo.reminderFrequency = megaSignCreationRequestWrapper.MegaSignCreationInfo.ReminderFrequency;

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions != null)
                    {
                        #region SecurityOptions

                        SecurityOption securityOption = new SecurityOption();
                        securityOption.externalPassword = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.ExternalPassword;
                        securityOption.internalPassword = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.InternalPassword;
                        securityOption.kbaProtection = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.KbaProtection;
                        securityOption.openPassword = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.OpenPassword;
                        securityOption.passwordProtection = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.PasswordProtection;
                        securityOption.protectOpen = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.ProtectOpen;
                        securityOption.webIdentityProtection = megaSignCreationRequestWrapper.MegaSignCreationInfo.SecurityOptions.WebIdentityProtection;

                        megaSignCreationInfo.securityOptions = securityOption;

                        #endregion
                    }

                    megaSignCreationInfo.signatureType = megaSignCreationRequestWrapper.MegaSignCreationInfo.SignatureType;

                    if (megaSignCreationRequestWrapper.MegaSignCreationInfo.VaultingInfo != null)
                    {
                        #region VaultingInfo

                        VaultingInfo vaultingInfo = new VaultingInfo();
                        vaultingInfo.enabled = megaSignCreationRequestWrapper.MegaSignCreationInfo.VaultingInfo.Enabled;

                        megaSignCreationInfo.vaultingInfo = vaultingInfo;

                        #endregion
                    }
                }

                megaSignCreationRequest.megaSignCreationInfo = megaSignCreationInfo;
            }

            return megaSignCreationRequest;
        }

        private AgreementCreationInfo ConvertToBase(AgreementCreationInfoWrapper agreementCreationInfoWrapper)
        {
            AgreementCreationInfo agreementCreationInfo = new AgreementCreationInfo();

            if (agreementCreationInfoWrapper != null)
            {
                if (agreementCreationInfoWrapper.DocumentCreationInfo != null)
                {
                    #region DocumentCreationInfo

                    Documentcreationinfo documentcreationinfo = new Documentcreationinfo();

                    documentcreationinfo.callbackInfo = agreementCreationInfoWrapper.DocumentCreationInfo.CallbackInfo;

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.Ccs != null)
                        documentcreationinfo.ccs = agreementCreationInfoWrapper.DocumentCreationInfo.Ccs.ToArray();

                    documentcreationinfo.daysUntilSigningDeadline = agreementCreationInfoWrapper.DocumentCreationInfo.DaysUntilSigningDeadline;

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.ExternalId != null)
                    {
                        #region ExternalId

                        Externalid externalId = new Externalid();
                        externalId.group = agreementCreationInfoWrapper.DocumentCreationInfo.ExternalId.Group;
                        externalId.id = agreementCreationInfoWrapper.DocumentCreationInfo.ExternalId.Id;
                        externalId._namespace = agreementCreationInfoWrapper.DocumentCreationInfo.ExternalId.NameSpace;

                        documentcreationinfo.externalId = externalId;

                        #endregion
                    }

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.FileInfos != null)
                    {
                        #region FileInfos

                        List<FileInfo> lstFileInfo = new List<FileInfo>();

                        foreach (FileInfoWrapper fileInfoWrapper in agreementCreationInfoWrapper.DocumentCreationInfo.FileInfos)
                        {
                            FileInfo fileInfo = new FileInfo();

                            if (fileInfoWrapper.DocumentURL != null)
                            {
                                #region DocumentURL

                                URLFileInfo urlFileInfo = new URLFileInfo();
                                urlFileInfo.mimeType = fileInfoWrapper.DocumentURL.MimeType;
                                urlFileInfo.name = fileInfoWrapper.DocumentURL.Name;
                                urlFileInfo.url = fileInfoWrapper.DocumentURL.Url;

                                fileInfo.documentURL = urlFileInfo;

                                #endregion
                            }

                            fileInfo.libraryDocumentId = fileInfoWrapper.LibraryDocumentId;
                            fileInfo.libraryDocumentName = fileInfoWrapper.LibraryDocumentName;
                            fileInfo.transientDocumentId = fileInfoWrapper.TransientDocumentId;

                            lstFileInfo.Add(fileInfo);
                        }

                        documentcreationinfo.fileInfos = lstFileInfo.ToArray<FileInfo>();

                        #endregion
                    }

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.FormFieldLayerTemplates != null)
                    {
                        #region FormFieldLayerTemplates

                        List<FileInfo> lstFileInfo = new List<FileInfo>();

                        foreach (FileInfoWrapper fileInfoWrapper in agreementCreationInfoWrapper.DocumentCreationInfo.FormFieldLayerTemplates)
                        {
                            FileInfo fileInfo = new FileInfo();

                            if (fileInfoWrapper.DocumentURL != null)
                            {
                                #region DocumentURL

                                URLFileInfo urlFileInfo = new URLFileInfo();
                                urlFileInfo.mimeType = fileInfoWrapper.DocumentURL.MimeType;
                                urlFileInfo.name = fileInfoWrapper.DocumentURL.Name;
                                urlFileInfo.url = fileInfoWrapper.DocumentURL.Url;

                                fileInfo.documentURL = urlFileInfo;

                                #endregion
                            }

                            fileInfo.libraryDocumentId = fileInfoWrapper.LibraryDocumentId;
                            fileInfo.libraryDocumentName = fileInfoWrapper.LibraryDocumentName;
                            fileInfo.transientDocumentId = fileInfoWrapper.TransientDocumentId;

                            lstFileInfo.Add(fileInfo);
                        }

                        documentcreationinfo.formFieldLayerTemplates = lstFileInfo.ToArray<FileInfo>();

                        #endregion
                    }

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.FormFields != null)
                    {
                        #region FormFields

                        List<RequestFormField> lstRequestFormField = new List<RequestFormField>();

                        foreach (RequestFormFieldWrapper requestFormFieldWrapper in agreementCreationInfoWrapper.DocumentCreationInfo.FormFields)
                        {
                            RequestFormField requestFormField = new RequestFormField();
                            requestFormField.alignment = requestFormFieldWrapper.Alignment;
                            requestFormField.anyOrAll = requestFormFieldWrapper.AnyOrAll;
                            requestFormField.backgroundColor = requestFormFieldWrapper.BackgroundColor;
                            requestFormField.borderColor = requestFormFieldWrapper.BorderColor;
                            requestFormField.borderStyle = requestFormFieldWrapper.BorderStyle;
                            requestFormField.borderWidth = requestFormFieldWrapper.BorderWidth;
                            requestFormField.calculatedExpression = requestFormFieldWrapper.CalculatedExpression;

                            if (requestFormFieldWrapper.Conditions != null)
                            {
                                #region Conditions

                                List<FormFieldCondition> lstFormFieldCondition = new List<FormFieldCondition>();

                                foreach (FormFieldConditionWrapper formFieldConditionWrapper in requestFormFieldWrapper.Conditions)
                                {
                                    FormFieldCondition formFieldCondition = new FormFieldCondition();
                                    formFieldCondition.value = formFieldConditionWrapper.Value;
                                    formFieldCondition.whenFieldLocationIndex = formFieldConditionWrapper.WhenFieldLocationIndex;
                                    formFieldCondition.whenFieldName = formFieldConditionWrapper.WhenFieldName;

                                    lstFormFieldCondition.Add(formFieldCondition);
                                }

                                requestFormField.conditions = lstFormFieldCondition.ToArray<FormFieldCondition>();

                                #endregion
                            }

                            requestFormField.contentType = requestFormFieldWrapper.ContentType;
                            requestFormField.defaultValue = requestFormFieldWrapper.DefaultValue;
                            requestFormField.displayFormat = requestFormFieldWrapper.DisplayFormat;
                            requestFormField.displayFormatType = requestFormFieldWrapper.DisplayFormatType;
                            requestFormField.displayLabel = requestFormFieldWrapper.DisplayLabel;
                            requestFormField.fontColor = requestFormFieldWrapper.FontColor;
                            requestFormField.fontName = requestFormFieldWrapper.FontName;
                            requestFormField.fontSize = requestFormFieldWrapper.FontSize;
                            requestFormField.format = requestFormFieldWrapper.Format;
                            requestFormField.formatData = requestFormFieldWrapper.FormatData;
                            requestFormField.hidden = requestFormFieldWrapper.Hidden;

                            if(requestFormFieldWrapper.HiddenOptions != null)
                            requestFormField.hiddenOptions = requestFormFieldWrapper.HiddenOptions.ToArray<string>();

                            requestFormField.inputType = requestFormFieldWrapper.InputType;

                            if (requestFormFieldWrapper.Locations != null)
                            {
                                #region Locations

                                List<FormFieldLocation> lstFormFieldLocation = new List<FormFieldLocation>();

                                foreach (FormFieldLocationWrapper formFieldLocationWrapper in requestFormFieldWrapper.Locations)
                                {
                                    FormFieldLocation formFieldLocation = new FormFieldLocation();
                                    formFieldLocation.height = formFieldLocationWrapper.Height;
                                    formFieldLocation.left = formFieldLocationWrapper.Left;
                                    formFieldLocation.pageNumber = formFieldLocationWrapper.PageNumber;
                                    formFieldLocation.top = formFieldLocationWrapper.Top;
                                    formFieldLocation.width = formFieldLocationWrapper.Width;

                                    lstFormFieldLocation.Add(formFieldLocation);
                                }

                                requestFormField.locations = lstFormFieldLocation.ToArray<FormFieldLocation>();

                                #endregion
                            }

                            requestFormField.masked = requestFormFieldWrapper.Masked;
                            requestFormField.maskingText = requestFormFieldWrapper.MaskingText;
                            requestFormField.maxLength = requestFormFieldWrapper.MaxLength;
                            requestFormField.maxNumberValue = requestFormFieldWrapper.MaxNumberValue;
                            requestFormField.minLength = requestFormFieldWrapper.MinLength;
                            requestFormField.minNumberValue = requestFormFieldWrapper.MinNumberValue;
                            requestFormField.name = requestFormFieldWrapper.Name;
                            requestFormField.radioCheckType = requestFormFieldWrapper.RadioCheckType;
                            requestFormField.readOnly = requestFormFieldWrapper.ReadOnly;
                            requestFormField.recipientIndex = requestFormFieldWrapper.RecipientIndex;
                            requestFormField.regularExpression = requestFormFieldWrapper.RegularExpression;
                            requestFormField.required = requestFormFieldWrapper.Required;
                            requestFormField.showOrHide = requestFormFieldWrapper.ShowOrHide;
                            requestFormField.specialErrMsg = requestFormFieldWrapper.SpecialErrMsg;
                            requestFormField.specialFormula = requestFormFieldWrapper.SpecialFormula;
                            requestFormField.tooltip = requestFormFieldWrapper.Tooltip;

                            if(requestFormFieldWrapper.VisibleOptions != null)
                                requestFormField.visibleOptions = requestFormFieldWrapper.VisibleOptions.ToArray<string>();

                            lstRequestFormField.Add(requestFormField);
                        }

                        documentcreationinfo.formFields = lstRequestFormField.ToArray<RequestFormField>();

                        #endregion
                    }

                    documentcreationinfo.locale = agreementCreationInfoWrapper.DocumentCreationInfo.Locale;

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.MergeFieldInfo != null)
                    {
                        #region MergeFieldInfo

                        List<Mergefieldinfo> lstMergefieldinfo = new List<Mergefieldinfo>();

                        foreach (MergefieldInfoWrapper mergefieldInfoWrapper in agreementCreationInfoWrapper.DocumentCreationInfo.MergeFieldInfo)
                        {
                            Mergefieldinfo mergefieldinfo = new Mergefieldinfo();

                            mergefieldinfo.defaultValue = mergefieldInfoWrapper.DefaultValue;
                            mergefieldinfo.fieldName = mergefieldInfoWrapper.FieldName;

                            lstMergefieldinfo.Add(mergefieldinfo);
                        }

                        documentcreationinfo.mergeFieldInfo = lstMergefieldinfo.ToArray<Mergefieldinfo>();

                        #endregion
                    }

                    documentcreationinfo.message = agreementCreationInfoWrapper.DocumentCreationInfo.Message;
                    documentcreationinfo.name = agreementCreationInfoWrapper.DocumentCreationInfo.Name;

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.PostSignOptions != null)
                    {
                        #region PostSignOptions

                        Postsignoptions postsignoptions = new Postsignoptions();
                        postsignoptions.redirectDelay = agreementCreationInfoWrapper.DocumentCreationInfo.PostSignOptions.RedirectDelay;
                        postsignoptions.redirectUrl = agreementCreationInfoWrapper.DocumentCreationInfo.PostSignOptions.RedirectUrl;

                        documentcreationinfo.postSignOptions = postsignoptions;

                        #endregion
                    }

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.RecipientSetInfos != null)
                    {
                        #region RecipientSetInfos

                        List<RecipientSetInfo> lstRecipientSetInfo = new List<RecipientSetInfo>();

                        foreach (RecipientSetInfoWrapper recipientSetInfoWrapper in agreementCreationInfoWrapper.DocumentCreationInfo.RecipientSetInfos)
                        {
                            RecipientSetInfo recipientSetInfo = new RecipientSetInfo();

                            if (recipientSetInfoWrapper.RecipientSetMemberInfos != null)
                            {
                                #region RecipientSetMemberInfos

                                List<RecipientInfo> lstRecipientInfo = new List<RecipientInfo>();

                                foreach (RecipientInfoWrapper recipientInfoWrapper in recipientSetInfoWrapper.RecipientSetMemberInfos)
                                {
                                    RecipientInfo recipientInfo = new RecipientInfo();
                                    recipientInfo.email = recipientInfoWrapper.Email;
                                    recipientInfo.fax = recipientInfoWrapper.Fax;

                                    if (recipientInfoWrapper.SecurityOptions != null)
                                    {
                                        #region RecipeintSecurityOption

                                        List<RecipientSecurityOption> lstRecipientSecurityOption = new List<RecipientSecurityOption>();

                                        foreach (RecipientSecurityOptionWrapper recipientSecurityOptionWrapper in recipientInfoWrapper.SecurityOptions)
                                        {
                                            RecipientSecurityOption recipientSecurityOption = new RecipientSecurityOption();
                                            recipientSecurityOption.authenticationMethod = recipientSecurityOptionWrapper.AuthenticationMethod;
                                            recipientSecurityOption.password = recipientSecurityOptionWrapper.Password;

                                            if (recipientSecurityOptionWrapper.PhoneInfos != null)
                                            {
                                                #region PhoneInfos

                                                List<PhoneInfo> lstPhoneInfo = new List<PhoneInfo>();

                                                foreach (PhoneInfoWrapper phoneInfoWrapper in recipientSecurityOptionWrapper.PhoneInfos)
                                                {
                                                    PhoneInfo phoneInfo = new PhoneInfo();
                                                    phoneInfo.countryCode = phoneInfoWrapper.CountryCode;
                                                    phoneInfo.phone = phoneInfoWrapper.Phone;

                                                    lstPhoneInfo.Add(phoneInfo);
                                                }

                                                recipientSecurityOption.phoneInfos = lstPhoneInfo.ToArray<PhoneInfo>();

                                                #endregion
                                            }

                                            lstRecipientSecurityOption.Add(recipientSecurityOption);
                                        }

                                        recipientInfo.securityOptions = lstRecipientSecurityOption.ToArray<RecipientSecurityOption>();

                                        #endregion
                                    }

                                    lstRecipientInfo.Add(recipientInfo);
                                }

                                recipientSetInfo.recipientSetMemberInfos = lstRecipientInfo.ToArray<RecipientInfo>();

                                #endregion
                            }

                            recipientSetInfo.recipientSetRole = recipientSetInfoWrapper.RecipientSetRole;

                            if (recipientSetInfoWrapper.SecurityOptions != null)
                            {
                                #region SecurityOption

                                List<RecipientSecurityOption> lstSecurityOption = new List<RecipientSecurityOption>();

                                foreach (RecipientSecurityOptionWrapper recipientSecurityOptionWrapper in recipientSetInfoWrapper.SecurityOptions)
                                {
                                    RecipientSecurityOption recipientSecurityOption = new RecipientSecurityOption();
                                    recipientSecurityOption.authenticationMethod = recipientSecurityOptionWrapper.AuthenticationMethod;
                                    recipientSecurityOption.password = recipientSecurityOptionWrapper.Password;

                                    if (recipientSecurityOptionWrapper.PhoneInfos != null)
                                    {
                                        #region PhoneInfos

                                        List<PhoneInfo> lstPhoneInfo = new List<PhoneInfo>();

                                        foreach (PhoneInfoWrapper phoneInfoWrapper in recipientSecurityOptionWrapper.PhoneInfos)
                                        {
                                            PhoneInfo phoneInfo = new PhoneInfo();
                                            phoneInfo.countryCode = phoneInfoWrapper.CountryCode;
                                            phoneInfo.phone = phoneInfoWrapper.Phone;

                                            lstPhoneInfo.Add(phoneInfo);
                                        }

                                        recipientSecurityOption.phoneInfos = lstPhoneInfo.ToArray<PhoneInfo>();

                                        #endregion
                                    }

                                    lstSecurityOption.Add(recipientSecurityOption);
                                }

                                recipientSetInfo.securityOptions = lstSecurityOption.ToArray<RecipientSecurityOption>();

                                #endregion
                            }

                            recipientSetInfo.signingOrder = recipientSetInfoWrapper.SigningOrder;

                            lstRecipientSetInfo.Add(recipientSetInfo);
                        }

                        documentcreationinfo.recipientSetInfos = lstRecipientSetInfo.ToArray<RecipientSetInfo>();

                        #endregion
                    }

                    documentcreationinfo.reminderFrequency = agreementCreationInfoWrapper.DocumentCreationInfo.ReminderFrequency;

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions != null)
                    {
                        #region SecurityOptions

                        SecurityOption securityOption = new SecurityOption();
                        securityOption.externalPassword = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.ExternalPassword;
                        securityOption.internalPassword = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.InternalPassword;
                        securityOption.kbaProtection = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.KbaProtection;
                        securityOption.openPassword = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.OpenPassword;
                        securityOption.passwordProtection = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.PasswordProtection;
                        securityOption.protectOpen = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.ProtectOpen;
                        securityOption.webIdentityProtection = agreementCreationInfoWrapper.DocumentCreationInfo.SecurityOptions.WebIdentityProtection;

                        documentcreationinfo.securityOptions = securityOption;

                        #endregion
                    }

                    documentcreationinfo.signatureFlow = agreementCreationInfoWrapper.DocumentCreationInfo.SignatureFlow;
                    documentcreationinfo.signatureType = agreementCreationInfoWrapper.DocumentCreationInfo.SignatureType;

                    if (agreementCreationInfoWrapper.DocumentCreationInfo.VaultingInfo != null)
                    {
                        #region VaultingInfo

                        Vaultinginfo vaultinginfo = new Vaultinginfo();
                        vaultinginfo.enabled = agreementCreationInfoWrapper.DocumentCreationInfo.VaultingInfo.Enabled;

                        documentcreationinfo.vaultingInfo = vaultinginfo;

                        #endregion
                    }

                    agreementCreationInfo.documentCreationInfo = documentcreationinfo;

                    #endregion
                }

                if (agreementCreationInfoWrapper.Options != null)
                {
                    #region InteractiveOptions

                    InteractiveOptions interactiveOptions = new InteractiveOptions();

                    interactiveOptions.authoringRequested = agreementCreationInfoWrapper.Options.AuthoringRequested;
                    interactiveOptions.autoLoginUser = agreementCreationInfoWrapper.Options.AutoLoginUser;
                    interactiveOptions.locale = agreementCreationInfoWrapper.Options.Locale;
                    interactiveOptions.noChrome = agreementCreationInfoWrapper.Options.NoChrome;
                    interactiveOptions.sendThroughWeb = agreementCreationInfoWrapper.Options.SendThroughWeb;

                    if (agreementCreationInfoWrapper.Options.SendThroughWebOptions != null)
                    {
                        #region SendThroughWebOptions

                        SendThroughWebOptions sendThroughWebOptions = new SendThroughWebOptions();

                        if (agreementCreationInfoWrapper.Options.SendThroughWebOptions.FileUploadOptions != null)
                        {
                            #region FileUploadOptions

                            FileUploadOptions fileUploadOptions = new FileUploadOptions();
                            fileUploadOptions.libraryDocument = agreementCreationInfoWrapper.Options.SendThroughWebOptions.FileUploadOptions.LibraryDocument;
                            fileUploadOptions.localFile = agreementCreationInfoWrapper.Options.SendThroughWebOptions.FileUploadOptions.LocalFile;
                            fileUploadOptions.webConnectors = agreementCreationInfoWrapper.Options.SendThroughWebOptions.FileUploadOptions.WebConnectors;

                            sendThroughWebOptions.fileUploadOptions = fileUploadOptions;

                            #endregion
                        }

                        interactiveOptions.sendThroughWebOptions = sendThroughWebOptions;

                        #endregion
                    }

                    agreementCreationInfo.options = interactiveOptions;

                    #endregion
                }
            }

            return agreementCreationInfo;
        }
    }
}
