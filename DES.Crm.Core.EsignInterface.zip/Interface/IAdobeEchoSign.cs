﻿using Refit;
using System.Net.Http;
using System.Threading.Tasks;

namespace DES.Crm.Core.EsignInterface.Interface
{
    public interface IAdobeEchoSign
    {
        #region Transient Document
        [Multipart]
        [Post("/transientDocuments")]
        Task<TransientDocumentResponse> CreateTransientDocument(string fileName, byte[] fileContents);
        #endregion

        #region LibraryDocument

        [Post("/libraryDocuments")]
        Task<LibraryDocumentCreationResponse> PostLibraryDocument(LibraryCreationInfo libraryCreationInfo);

        [Get("/libraryDocuments")]
        Task<LibraryDocuments> GetLibraryDocuments();

        [Get("/libraryDocuments/{libraryDocumentId}")]
        Task<LibraryDocumentInfo> GetLibraryDocument(string libraryDocumentId);

        [Get("/libraryDocuments/{libraryDocumentId}/documents")]
        Task<Documents> GetDocuments(string libraryDocumentId);


        [Get("/libraryDocuments/{libraryDocumentId}/documents/{documentId}")]
        Task<HttpResponseMessage> GetDocument(string libraryDocumentId, string documentId);

        [Get("/libraryDocuments/{libraryDocumentId}/auditTrail")]
        Task<HttpResponseMessage> GetLibraryDocumentAuditTrail(string libraryDocumentId);

        [Get("/libraryDocuments/{libraryDocumentId}/combinedDocument")]
        Task<HttpResponseMessage> GetCombinedDocument(string libraryDocumentId, bool auditReport);

        #endregion

        #region MegaSign

        [Post("/megaSigns")]
        Task<MegaSignCreationResponse> CreateMegaSign(MegaSignCreationRequest megaSignCreationRequest);

        [Get("/megaSigns")]
        Task<MegaSigns> GetMegaSigns(string query);

        [Get("/megaSigns/{megaSignId}")]
        Task<MegaSignInfo> GetMegaSign(string megaSignId);

        [Get("/megaSigns/{megaSignId}/agreements")]
        Task<MegaSignChildAgreements> GetMegaSignAgreements(string megaSignId);

        #endregion

        #region Agreement
        [Post("/reminders")]
        Task<ReminderCreationResult> PostAgreementReminder(ReminderCreationInfo reminderCreationInfo);

        [Post("/agreements")]
        Task<AgreementCreationResponse> CreateAgreement(AgreementCreationInfo agreementCreationInfo);

        [Get("/agreements")]
        Task<Agreements> GetAgreements(string query, string externalId, string externalGroup, string externalNamespace);

        [Get("/agreements/{agreementId}")]
        Task<AgreementInfo> GetAgreement(string agreementId);

        [Get("/agreements/{agreementId}/documents/imageUrls")]
        Task<DocumentImageUrls> GetAgreementDocumentsImageUrls(string agreementId);

        [Get("/agreements/{agreementId}/documents/{documentId}/imageUrls")]
        Task<DocumentImageUrl> GetAgreementDocumentImageUrls(string agreementId, string documentId);

        [Get("/agreements/{agreementId}/documents/{documentId}/url")]
        Task<DocumentUrl> GetAgreementDocumentUrl(string agreementId, string documentId);

        [Get("/agreements/{agreementId}/documents")]
        Task<AgreementDocuments> GetAgreementDocuments(string agreementId);

        [Get("/agreements/{agreementId}/documents/{documentId}")]
        Task<HttpResponseMessage> GetAgreementDocument(string agreementId, string documentId);

        [Get("/agreements/{agreementId}/auditTrail")]
        Task<HttpResponseMessage> GetAgreementAuditTrailPdf(string agreementId);

        [Get("/agreements/{agreementId}/signingUrls")]
        Task<SigningUrlResponse> GetAgreementSigningUrls(string agreementId);

        [Get("/agreements/{agreementId}/combinedDocument")]
        Task<HttpResponseMessage> GetAgreementCombinedDocumentPdf(string agreementId);

        [Get("/agreements/{agreementId}/combinedDocument/url")]
        Task<DocumentUrl> GetAgreementCombinedDocumentUrl(string agreementId);

        [Get("/agreements/{agreementId}/combinedDocument/pagesInfo")]
        Task<CombinedDocumentPagesInfo> GetAgreementCombinedDocumentPagesInfo(string agreementId);

        [Get("/agreements/{agreementId}/formData")]
        Task<HttpResponseMessage> GetAgreementFormDataCsv(string agreementId);

        [Put("/agreements/{agreementId}/status")]
        Task<AgreementStatusUpdateResponse> PutAgreementStatus(string agreementId, AgreementStatusUpdateInfo agreementStatusUpdateInfo);

        [Delete("/agreements/{agreementId}/documents")]
        Task<string> DeleteAgreementDocuments(string agreementId);

        [Delete("/agreements/{agreementId}")]
        Task<string> DeleteAgreement(string agreementId);


        #endregion
    }
}