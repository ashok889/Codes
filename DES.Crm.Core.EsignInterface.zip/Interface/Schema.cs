﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DES.Crm.Core.EsignInterface.Interface
{
    #region TransientDocument

    public class TransientDocumentResponse
    {
        public string transientDocumentId { get; set; } // The unique identifier of the uploaded document that can be used in an agreement or a megaSign or widget creation call
        public string code { get; set; }
    }

    #endregion

    #region LibraryDocument

    public class LibraryCreationInfo
    {

        public LibraryDocumentCreationInfo libraryDocumentCreationInfo { get; set; } //Information about the library document you want to create,

        public InteractiveOptionsoptions interactiveOptions { get; set; } //Options for authoring and sending the agreement

    }

    public class LibraryDocumentCreationInfo
    {
        public LibraryTemplateType[] libraryTemplateTypes { get; set; } //  A list of one or more library template types,

        public FileInfo[] fileInfos { get; set; } //A list of one or more files (or references to files) that will be sent out for signature. If more than one file is provided, they will be combined into one PDF before being sent out. Note: Only one of the four parameters in every FileInfo object must be specified,

        public string name { get; set; } //The name of the agreement that will be used to identify it, in emails and on the website,

        public LibrarySharingMode librarySharingMode { get; set; } // Specifies who should have access to this library document
    }

    public class FileInfo
    {
        public string transientDocumentId { get; set; }
        public string libraryDocumentId { get; set; }
        public string libraryDocumentName { get; set; }
        public URLFileInfo documentURL { get; set; }
    }

    public class URLFileInfo
    {
        public string name { get; set; }
        public string url { get; set; }
        public string mimeType { get; set; }
    }

    public enum LibrarySharingMode
    {
        GROUP, // The library template can be used by everyone in the same group as the user that created it.,

        ACCOUNT, // The library template can be used by everyone in the same account as the user that created it.,

        USER  // The library template can only be used by the user that created it.
    }

    public class InteractiveOptionsoptions
    {
        public bool noChrome { get; set; } //Turn off Chrome for the URL generated,

        public bool authoringRequested { get; set; } //Indicates that authoring is requested prior to sending the document,

        public bool autoLoginUser { get; set; } //If user settings allow, automatically logs the user in
    }

    public class LibraryDocumentCreationResponse
    {

        public DateTime expiration { get; set; } //Expiration date for autologin. This is based on the user setting, API_AUTO_LOGIN_LIFETIME,

        public string agreementId { get; set; } //The unique identifier that can be used to refer to the library template,

        public string embeddedCode { get; set; } //Javascript snippet suitable for an embedded page taking a user to a URL,

        public string url { get; set; } //Standalone URL to direct end users to
    }

    public class LibraryDocuments
    {
        public LibraryDocument[] libraryDocumentList { get; set; }
    }

    public class LibraryDocument
    {
        public string libraryDocumentId { get; set; }
        public LibraryTemplateType[] libraryTemplateTypes { get; set; }
        public string name { get; set; }
        public DateTime modifiedDate { get; set; }
        public DocumentScope scope { get; set; }
    }

    public enum LibraryTemplateType
    {
        DOCUMENT,
        FORM_FIELD_LAYER
    }

    public enum DocumentScope
    {
        PERSONAL = 277810000,
        SHARED = 277810001,
        GLOBAL = 277810002
    }

    public class LibraryDocumentInfo
    {
        public string libraryDocumentId { get; set; } //A resource identifier that can be used to uniquely identify the library document in other apis,
        public string name { get; set; } //The name of the document, specified by the sender, 
        public string locale { get; set; } //The locale associated with this agreement - for example, en_US or fr_FR,
        public string message { get; set; } // The message associated with the document that the sender has provided, 
        public LibDocSecurityOption[] securityOptions { get; set; }   //Security information about the document that specifies whether or not a password is required to view and sign the document, 
        public LibDocStatus status { get; set; } //The current status of the document, 
        public LibDocumentHistoryEvent[] events { get; set; } //An ordered list of the events in the audit trail of this document, 
        public LibDocParticipantInfo[] participants { get; set; } //Information about all the participants of this document
    }

    public enum LibDocSecurityOption
    {
        OTHER, // In the future, options other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive the option, OTHER. You may need to update your client application to the latest version of the API to receive the new options,

        OPEN_PROTECTED // A password is required to open the document
    }

    public enum LibDocStatus
    {
        ABORTED, // The signature workflow has been cancelled by either the sender or the recipient. This is a terminal state,

        EXPIRED, // The document has passed the expiration date and can no longer be signed. This is a terminal state,

        SIGNED, // The document has been signed by all the requested parties. This is a terminal state,

        DOCUMENT_LIBRARY, // The status for agreements that are in the user's document library. This is a terminal state,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        ARCHIVED, // The document uploaded by the user into their document archive. This is a terminal state,

        OUT_FOR_SIGNATURE, // The document is currently waiting for one or more parties to sign it,

        WIDGET_WAITING_FOR_VERIFICATION, // The widget is currently waiting to be verified,

        APPROVED, // The document has been approved by all requested parties. If document has both signers and approvers, terminal status will be signed,

        WIDGET, // The status for the user's widgets. This is a terminal state,

        AUTHORING, // The document is waiting for the sender to position fields before it can be sent for signature,

        PREFILL, // The document is waiting for the sender to fill out fields before it can be sent for signature,

        OUT_FOR_APPROVAL, // The document is currently waiting to be approved,

        WAITING_FOR_REVIEW, // The document is currently waiting to be reviewed,

        WAITING_FOR_PAYMENT, // The document is waiting for payment in order to proceed,

        WAITING_FOR_VERIFICATION, // The document is currently waiting to be verified,

        WAITING_FOR_FAXIN, // The document is waiting for the sender to fax in the document contents before it can be sent for signature
    }

    public class LibDocumentHistoryEvent
    {
        public string vaultEventId { get; set; } //The identifier assigned by the vault provider for the vault event (if vaulted, otherwise null),

        public string participantEmail { get; set; } //Email address of the user that initiated the event,

        public string synchronizationId { get; set; } //A unique identifier linking offline events to synchronization events (specified for offline signing events and synchronization events, else null),

        public string description { get; set; } //A description of the audit event,

        public string versionId { get; set; } // An ID which uniquely identifies the version of the document associated with this audit event,

        public EventType type { get; set; } // Type of the document event,

        public DateTime date { get; set; }

        public string comment { get; set; } // The event comment. For RECALLED or REJECTED, the reason given by the user that initiates the event. For DELEGATE or SHARE, the message from the acting user to the participant,

        public string actingUserIpAddress { get; set; } // The IP address of the user that initiated the event,

        public LibDocEventDeviceLocation deviceLocation { get; set; } // Location of the device that created the event (This value may be null due to limited privileges),

        public string actingUserEmail { get; set; } // Email address of the user that initiated the event
    }

    public enum EventType
    {
        SHARED, // The document has been shared by a participant,

        DOCUMENTS_DELETED, // Document retention applied - all documents deleted,

        SIGNER_SUGGESTED_CHANGES, // Changes have been suggested by the signer on the document,

        EMAIL_BOUNCED, // The Email sent to a signer bounced and was not delivered,

        SIGNED, // The document has been signed,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        APPROVED, // The document has been approved,

        EXPIRED_AUTOMATICALLY, // The document automatically expired,

        VAULTED, // Document was vaulted,

        PRESIGNED, // The document was digitally Signed,

        APPROVAL_REQUESTED, // The document has been sent out for approval,

        ESIGNED, // The document has been eSigned,

        DELEGATED, // The document has been delegated by the signer,

        AGREEMENT_MODIFIED, // The agreement has been modified,

        AUTO_CANCELLED_CONVERSION_PROBLEM, // The document has been cancelled because of problems with processing,

        FAXED_BY_SENDER, // The document has been faxed in by the sender on behalf of the signer,

        PASSWORD_AUTHENTICATION_FAILED, // Signer failed all password authentication attempts,

        DIGSIGNED, // The document has been digitally Signed,

        KBA_AUTHENTICATED, // Signer successfully verified identity using Knowledge Based Authentication,

        SIGNATURE_REQUESTED, // The document has been sent out for signatures,

        EXPIRED, // The document has expired,

        REJECTED, // The document has been rejected by the signer,

        WEB_IDENTITY_AUTHENTICATED, // Signer provided web identity before viewing the document,

        UPLOADED_BY_SENDER, // The document has been uploaded by sender,

        WEB_IDENTITY_SPECIFIED, // Signer provided web identity after viewing the document,

        WIDGET_DISABLED, // The widget was disabled,

        CREATED, // The document has been created,

        OFFLINE_SYNC, // Offline events have been synchronized and recorded,

        REPLACED_SIGNER, // Signer was replaced by the sender,

        AUTO_DELEGATED, // The document has been automatically delegated by the signer,

        WIDGET_ENABLED, // The widget was enabled,

        EMAIL_VIEWED, // The document has been viewed,

        RECALLED, // The document has been cancelled by the sender,

        FAXIN_RECEIVED, // The faxed-in signature has been received,

        SENDER_CREATED_NEW_REVISION, // A new revision of the document has been created,

        USER_ACK_AGREEMENT_MODIFIED, // The agreement modification has been acknowledged,

        KBA_AUTHENTICATION_FAILED   // Signer failed all Knowledge Based Authentication authentication attempts
    }

    public class LibDocEventDeviceLocation
    {
        public int longitude { get; set; } ///Longitude coordinate,

        public int latitude { get; set; } // Latitude coordinate
    }

    public class LibDocParticipantInfo
    {
        public string title { get; set; } //The title of the participant, if available,

        public ParticipantSecurityOption[] securityOptions { get; set; }  // Security options that apply to the participant,

        public UserLibDocumentStatus status { get; set; }  // The participant's status with respect to the document,

        public string email { get; set; } // The email address of the participant,

        public LibDocParticipantRole[] roles { get; set; }  //  The current roles of the participant. A participant can have one or more roles,

        public string name { get; set; } // The name of the participant, if available,

        public string company { get; set; } // The company of the participant, if available,

        public LibDocParticipantInfo[] alternateParticipants { get; set; } // All the child participants of the current participant. The possible values for the status of these participants are, SHARE and DELEGATE
    }

    public enum ParticipantSecurityOption
    {
        PHONE, // The recipient must enter an access code sent to their phone to view and sign the document,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        KBA, // The participant must pass Knowledge Based Authentication to view and sign the document,

        WEB_IDENTITY, // The participant must provide a web identity to view and sign the document,

        PASSWORD   // The participant must enter a password to view and sign the document
    }

    public enum UserLibDocumentStatus
    {
        EXPIRED, // The document has expired,

        SIGNED, // The document has been signed and filed,

        WAITING_FOR_MY_APPROVAL, // The document is waiting for the current participant to approve,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        UNKNOWN, // The current status of the document is unknown,

        ARCHIVED, // The document has been archived,

        OUT_FOR_SIGNATURE, // The document is out for signature,

        APPROVED, // The document has been approved,

        HIDDEN, // The document is currently hidden,

        WAITING_FOR_MY_DELEGATION, // The document is waiting for the current participant to delegate,

        WAITING_FOR_MY_SIGNATURE, // The document is waiting for the current participant to sign,

        WAITING_FOR_AUTHORING, // The document is waiting to be authored,

        WIDGET, // The document is a widget,

        OUT_FOR_APPROVAL, // The document out for approval,

        RECALLED, // The document has been recalled by the sender,

        FORM, // The document is a form,

        NOT_YET_VISIBLE, // The document is not yet visible to the current participant,

        IN_REVIEW, // The document is in the review process,

        WAITING_FOR_MY_REVIEW, // The document is waiting for the current participant to review,

        PARTIAL, // The document is incomplete,

        WAITING_FOR_FAXIN   // The document is waiting for the signature to be faxed-in

    }

    public enum LibDocParticipantRole
    {
        SENDER, // Sender or originator of the document,
        SHARE, // Participant with whom the document has been shared,

        SIGNER, // Signer of the document,

        OTHER, // In the future, roles other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive role OTHER. You may need to update your client application to the latest version of the API to receive the new roles in those cases,

        DELEGATE_TO_SIGNER, // Delegate to signer of the document,

        CC, // Participant that is bound to the document as an observer, by the sender,

        DELEGATE_TO_APPROVER, // Delegate to approver of the document,

        APPROVER, // Approver of the document,

        DELEGATE   // Participant that is delegated to sign the document, by the signer

    }

    public class Documents
    {
        public Document[] documents { get; set; }
    }

    public class Document
    {
        public string documentId { get; set; }
        public string name { get; set; }
        public int numPages { get; set; }
        public string mimeType { get; set; }
        public string status { get; set; }
    }

    #endregion

    #region Megasign

    public class MegaSignCreationResponse
    {
        public string megaSignId { get; set; } //Unique identifier of the MegaSign parent agreement
    }

    public class MegaSignCreationRequest
    {
        public MegaSignCreationInfo megaSignCreationInfo { get; set; } //Information about the MegaSign you want to send
    }

    public class MegaSignCreationInfo
    {
        public string signatureType { get; set; } //(string) = ['ESIGN' or 'WRITTEN'] Specifies the type of signature you would like to request - written or eSignature. The possible values are ESIGN or WRITTEN,

        public FileInfo[] formFieldLayerTemplates { get; set; } //Specifies the form field layer template or source of form fields to apply on the files in this transaction. If specified, the FileInfo for this parameter must refer to a form field layer template via libraryDocumentId or libraryDocumentName, or if specified via transientDocumentId or documentURL, it must be of a supported file type. Note: Only one of the four parameters in every FileInfo object must be specified,

        public SecurityOption securityOptions { get; set; } // Sets optional secondary security parameters for your document,

        public string callbackInfo { get; set; } // A publicly accessible url to which Adobe Document Cloud will do an HTTP GET operation every time there is a new agreement event. HTTP authentication is supported using standard embedded syntax - i.e. http://username:password@your.server.com/path/to/file. Adobe Document Cloud can also ping your system using HTTP PUT with the final signed PDF. Please contact support@echosign.com if you wish to use this option.,

        public int daysUntilSigningDeadline { get; set; } // The number of days that remain before the document expires. You cannot sign the document after it expires,

        public string locale { get; set; } // The locale associated with this agreement - specifies the language for the signing page and emails, for example en_US or fr_FR. If none specified, defaults to the language configured for the agreement sender,

        public RecipientSetInfo[] recipientSetInfos { get; set; } // A list of one or more recipient sets. Currently a recipient set can have only one recipient.,

        public string[] ccs { get; set; } // A list of one or more email addresses that you want to copy on this transaction. The email addresses will each receive an email at the beginning of the transaction and also when the final document is signed. The email addresses will also receive a copy of the document, attached as a PDF file,

        public ExternalId externalId { get; set; } // A unique identifier for your transaction from an external system. You can use the ExternalID to search for your transaction through API,

        public VaultingInfo vaultingInfo { get; set; } // Sets the vaulting properties that allows Adobe Document Cloud to securely store documents with a vault provider,

        public string mergeFileTransientId { get; set; } // The merge file ID as returned from POST /transientDocuments. The merge file contains the details of all the Mega Sign recipients.,

        public string message { get; set; } // An optional message to the recipients, describing what is being sent or why their signature is required,

        public MergefieldInfo[] mergeFieldInfo { get; set; } // Optional default values for fields to merge into the document. The values will be presented to the signers for editable fields; for read-only fields the provided values will not be editable during the signing process. Merging data into fields is currently not supported when used with libraryDocumentId or libraryDocumentName. Only file and url are curently supported,

        public FileInfo[] fileInfos { get; set; } // A list of one or more files (or references to files) that will be sent out for signature. If more than one file is provided, they will be combined into one PDF before being sent out. Note: Only one of the four parameters in every FileInfo object must be specified,

        public string reminderFrequency { get; set; } // (string, optional) = ['DAILY_UNTIL_SIGNED' or 'WEEKLY_UNTIL_SIGNED'] Optional parameter that sets how often you want to send reminders to the recipients. The possible values are DAILY_UNTIL_SIGNED or WEEKLY_UNTIL_SIGNED,

        public PostSignOptions postSignOptions { get; set; } // URL and associated properties for the success page the user will be taken to after completing the signing process,

        public string name { get; set; } // The name of the agreement that will be used to identify it, in emails and on the website
    }

    public class SecurityOption
    {
        public string passwordProtection { get; set; } //Specifies if signers are required to enter a password to have access to sign the document. The possible values are NONE, EXTERNAL_USERS, INTERNAL_USERS, or ALL_USERS,

        public string kbaProtection { get; set; } // Signers need to pass Knowledge Based Authentication before they gain access to view and sign the document. The possible values are NONE, EXTERNAL_USERS, INTERNAL_USERS, or ALL_USERS,

        public string webIdentityProtection { get; set; } // Specifies if signers are required to provide their web identity, before they gain access to view and sign the document. The possible values are NONE, EXTERNAL_USERS, INTERNAL_USERS, or ALL_USERS,

        public bool protectOpen { get; set; } //If set to true, the document is always be encrypted with this password every time it is sent by email. Recipients need to provide the password to be able to view the PDF files,

        public string internalPassword { get; set; } //The secondary password that will be used to protect signing the document for internal signers. Note that Adobe Document Cloud will never show this password to anyone, so you will need to separately communicate it to any relevant parties. This password is applied only if password protection is specified for internal signers or all signers,

        public string externalPassword { get; set; } //The secondary password that will be used to protect signing the document for external signers. Note that Adobe Document Cloud will never show this password to anyone, so you will need to separately communicate it to any relevant parties. This password is applied only if password protection is specified for external signers or all signers,

        public string openPassword { get; set; } // The secondary password that will be used to secure the PDF document. Note that Adobe Document Cloud will never show this password to anyone, so you will need to separately communicate it to any relevant parties. This password is used only if protectOpen field is set to true
    }



    public class RecipientSetInfo
    {
        public RecipientInfo[] recipientSetMemberInfos { get; set; } // Information about the members of the recipient set,

        public RecipientSecurityOption[] securityOptions { get; set; } // Security options that apply to the recipient,

        [JsonConverter(typeof(StringEnumConverter))]
        public RecipientRole recipientSetRole { get; set; } //  Specify the role of recipient set,

        public int signingOrder { get; set; } //  Index indicating sequential signing group (specify for hybrid routing)
    }

    public class RecipientInfo
    {
        public RecipientSecurityOption[] securityOptions { get; set; } // Security options that apply to the recipient,
        public string fax { get; set; } //Fax of the recipient. This is required if email is not provided. Both fax and email can not be provided. In case of recipient set having more than one member, fax is not allowed,
        public string email { get; set; } //Email of the recipient. This is required if fax is not provided. Both fax and email can not be provided
    }

    public class RecipientSecurityOption
    {
        public AuthenticationMethod authenticationMethod { get; set; } // The authentication method for the recipients to have access to view and sign the document,

        public PhoneInfo[] phoneInfos { get; set; } // The phoneInfo required for the recipient to view and sign the document,

        public string password { get; set; } // The password required for the recipient to view and sign the document
    }

    public enum AuthenticationMethod
    {
        PHONE, // The recipient must enter an access code sent to their phone to view and sign the document. The user can request the access code via SMS or voice call before signing,

        INHERITED_FROM_DOCUMENT, // The recipient will use the authentication method specified in the securityOptions in DocumentCreationInfo,

        KBA, // The recipient must pass Knowledge Based Authentication to view and sign the document,

        WEB_IDENTITY, // The recipient must provide a web identity to view and sign the document,

        PASSWORD, // The recipient must enter a password to view and sign the document,

        NONE  // Authentication won't be used for this recipient
    }

    public class PhoneInfo
    {
        public string phone { get; set; } //The phone number required for the recipient to view and sign the document if authentication type is PHONE,

        public string countryCode { get; set; } // The phoneInfo country code required for the recipient to view and sign the document if authentication type is PHONE
    }

    public enum RecipientRole
    {
        SIGNER, // Signer,

        DELEGATE_TO_SIGNER, // Delegate to signer,

        DELEGATE_TO_APPROVER, // Delegate to approver,

        APPROVER  // Approver
    }
    public class ExternalId
    {
        public string id { get; set; } // An arbitrary value from your system, which can be specified at sending time and then later returned or queried,

        public string group { get; set; } // An arbitrary value from your system, which can be specified at sending time and then later returned or queried,

        [JsonProperty(PropertyName = "namespace")]
        public string nameSpace { get; set; } // Only supported value for the ExternalID namespace at this time is API_OTHER 
    }

    public class VaultingInfo
    {
        public bool enabled { get; set; } //For accounts set up for document vaulting and the option to enable per agreement, this determines whether the document is to be vaulted
    }

    public class MergefieldInfo
    {
        public string fieldName { get; set; } //The name of the field, 
        public string defaultValue { get; set; } //The default value of the field
    }

    public class PostSignOptions
    {
        public int redirectDelay { get; set; } //The delay (in seconds) before the user is taken to the success page. If this value is greater than 0, the user will first see the standard Adobe Document Cloud success message, and then after a delay will be redirected to your success page.,

        public string redirectUrl { get; set; } //A publicly accessible url to which the user will be sent after successfully completing the signing process.
    }

    public class MegaSigns
    {
        public MegaSign[] megaSignList { get; set; } //An array of MegaSign parent agreements
    }

    public class MegaSign
    {

        public DateTime displayDate { get; set; } // The display date for the MegaSign parent agreement,

        public UserDocumentStatus status { get; set; } // Current status of the MegaSign parent agreement from the user's perspective,

        public string name { get; set; } //Name of the MegaSign parent agreement,

        public bool esign { get; set; } //True if this is an eSign document,

        public string megaSignId { get; set; } // Unique identifier of the MegaSign parent agreement
    }

    public enum UserDocumentStatus
    {
        EXPIRED, // The document has expired,

        SIGNED, // The document has been completed,

        WAITING_FOR_MY_APPROVAL, // It is the current user's turn to approve the document,

        ARCHIVED, // The document has been archived in the user's account,

        OUT_FOR_SIGNATURE, // It is another user's turn to sign the document,

        APPROVED, // The document has been approved,

        WAITING_FOR_MY_DELEGATION, // It is the current user's turn to delegate the document,

        WAITING_FOR_MY_SIGNATURE, // It is the current user's turn to sign the document,

        WAITING_FOR_AUTHORING, // The document is waiting to be authored,

        WIDGET, // The document is a widget,

        OUT_FOR_APPROVAL, // It is another user's turn to approve the document,

        RECALLED, // The document was recalled before completion,

        FORM, // The document is a form that can be used to create new documents,

        WAITING_FOR_FAXIN  // The current user needs to fax in the original document
    }

    public class MegaSignInfo
    {

        public string message { get; set; } //The message associated with the document that the sender has provided,

        public DocSecurityOption[] securityOptions { get; set; } // Security information about the document that specifies whether or not a password is required to view and sign the document,

        public UserDocumentStatus megaSignStatus { get; set; } // Current status of the MegaSign parent agreement from the user's perspective,

        public DateTime expiration { get; set; } // The date after which the document can no longer be signed, if an expiration date is configured. The value is nil if an expiration date is not set for the document,

        public DocumentHistoryEvent[] events { get; set; } // An ordered list of the events in the audit trail of this document,

        public string name { get; set; } //The name of the document, specified by the sender,

        public string locale { get; set; } //The locale associated with this agreement - for example, en_US or fr_FR,

        public string megaSignId { get; set; } // Unique identifier of the MegaSign parent agreement

    }

    public enum DocSecurityOption
    {
        OTHER,// In the future, options other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive the option, OTHER. You may need to update your client application to the latest version of the API to receive the new options,

        OPEN_PROTECTED // A password is required to open the document
    }

    public class DocumentHistoryEvent
    {
        public string vaultEventId { get; set; } //The identifier assigned by the vault provider for the vault event (if vaulted, otherwise null),

        public string participantEmail { get; set; } //Email address of the user that initiated the event,

        public string synchronizationId { get; set; } // A unique identifier linking offline events to synchronization events (specified for offline signing events and synchronization events, else null),

        public string description { get; set; } //A description of the audit event,

        public string versionId { get; set; } //An ID which uniquely identifies the version of the document associated with this audit event,

        public AgreementEventType type { get; set; } //Type of the document event,

        public DateTime date { get; set; } //The date of the audit event,

        public string comment { get; set; } //The event comment. For RECALLED or REJECTED, the reason given by the user that initiates the event. For DELEGATE or SHARE, the message from the acting user to the participant,

        public string actingUserIpAddress { get; set; } //The IP address of the user that initiated the event,

        public DeviceLocation deviceLocation { get; set; } //Location of the device that created the event (This value may be null due to limited privileges),

        public string actingUserEmail { get; set; } // Email address of the user that initiated the event
    }

    public enum AgreementEventType
    {
        SHARED, // The document has been shared by a participant,

        DOCUMENTS_DELETED, // Document retention applied - all documents deleted,

        SIGNER_SUGGESTED_CHANGES, // Changes have been suggested by the signer on the document,

        EMAIL_BOUNCED, // The Email sent to a signer bounced and was not delivered,

        SIGNED, // The document has been signed,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        APPROVED, // The document has been approved,

        EXPIRED_AUTOMATICALLY, // The document automatically expired,

        VAULTED, // Document was vaulted,

        PRESIGNED, // The document was digitally Signed,

        APPROVAL_REQUESTED, // The document has been sent out for approval,

        ESIGNED, // The document has been eSigned,

        DELEGATED, // The document has been delegated by the signer,

        AGREEMENT_MODIFIED, // The agreement has been modified,

        AUTO_CANCELLED_CONVERSION_PROBLEM, // The document has been cancelled because of problems with processing,

        FAXED_BY_SENDER, // The document has been faxed in by the sender on behalf of the signer,

        PASSWORD_AUTHENTICATION_FAILED, // Signer failed all password authentication attempts,

        DIGSIGNED, // The document has been digitally Signed,

        KBA_AUTHENTICATED, // Signer successfully verified identity using Knowledge Based Authentication,

        SIGNATURE_REQUESTED, // The document has been sent out for signatures,

        EXPIRED, // The document has expired,

        REJECTED, // The document has been rejected by the signer,

        WEB_IDENTITY_AUTHENTICATED, // Signer provided web identity before viewing the document,

        UPLOADED_BY_SENDER, // The document has been uploaded by sender,

        WEB_IDENTITY_SPECIFIED, // Signer provided web identity after viewing the document,

        WIDGET_DISABLED, // The widget was disabled,

        CREATED, // The document has been created,

        OFFLINE_SYNC, // Offline events have been synchronized and recorded,

        REPLACED_SIGNER, // Signer was replaced by the sender,

        AUTO_DELEGATED, // The document has been automatically delegated by the signer,

        WIDGET_ENABLED, // The widget was enabled,

        EMAIL_VIEWED, // The document has been viewed,

        RECALLED, // The document has been cancelled by the sender,

        FAXIN_RECEIVED, // The faxed-in signature has been received,

        SENDER_CREATED_NEW_REVISION, // A new revision of the document has been created,

        USER_ACK_AGREEMENT_MODIFIED, // The agreement modification has been acknowledged,

        KBA_AUTHENTICATION_FAILED  // Signer failed all Knowledge Based Authentication authentication attempts
    }

    public class DeviceLocation
    {
        public int longitude { get; set; } // Longitude coordinate, 
        public int latitude { get; set; } // Latitude coordinate
    }

    public class MegaSignChildAgreements
    {
        public MegaSignChildAgreement[] megaSignChildAgreementList { get; set; } //A array of MegaSign child agreements
    }

    public class MegaSignChildAgreement
    {

        public DateTime displayDate { get; set; } // The display date for the agreement,

        public UserDocumentStatus status { get; set; } //The current status of the agreement from the user's perspective,

        public string name { get; set; } //Name of the Agreement,

        public string agreementId { get; set; } // The unique identifier of the agreement,

        public bool esign { get; set; } // True if this is an eSign document
    }

    #endregion

    #region Agreement

    public class Agreements
    {
        public Useragreementlist[] userAgreementList { get; set; }
    }

    public class Useragreementlist
    {
        public DateTime displayDate { get; set; }
        public UserDocumentStatus status { get; set; }
        public string name { get; set; }
        public Displayusersetinfo[] displayUserSetInfos { get; set; }
        public string agreementId { get; set; }
        public bool esign { get; set; }
        public string latestVersionId { get; set; }
    }

    public class Displayusersetinfo
    {
        public Displayusersetmemberinfo[] displayUserSetMemberInfos { get; set; }
    }

    public class Displayusersetmemberinfo
    {
        public string email { get; set; }
        public string company { get; set; }
        public string fullName { get; set; }
    }

    public class AgreementInfo
    {
        public string message { get; set; }
        public DocSecurityOption[] securityOptions { get; set; }
        public AgreementStatus status { get; set; }
        public bool modifiable { get; set; }
        public DateTime expiration { get; set; }
        public DocumentHistoryEvent[] events { get; set; }
        public ParticipantSetInfo[] participantSetInfos { get; set; }
        public string name { get; set; }
        public string locale { get; set; }
        public string agreementId { get; set; }
        public Nextparticipantsetinfo[] nextParticipantSetInfos { get; set; }
    }

    public enum AgreementStatus
    {
        ABORTED, // The signature workflow has been cancelled by either the sender or the recipient. This is a terminal state,

        EXPIRED, // The agreement has passed the expiration date and can no longer be signed. This is a terminal state,

        SIGNED, // The agreement has been signed by all the requested parties. This is a terminal state,

        DOCUMENT_LIBRARY, // The status for agreements that are in the user's template library. This is a terminal state,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        ARCHIVED, // The agreement uploaded by the user into their document archive. This is a terminal state,

        OUT_FOR_SIGNATURE, // The agreement is out for signature,

        WIDGET_WAITING_FOR_VERIFICATION, // The widget is currently waiting to be verified,

        APPROVED, // The agreement has been approved by all requested parties. If agreement has both signers and approvers, terminal status will be signed,

        WIDGET, // The status for the user's widgets. This is a terminal state,

        AUTHORING, // The agreement is waiting for the sender to position fields before it can be sent for signature,

        PREFILL, // The agreement is waiting for the sender to fill out fields before it can be sent for signature,

        OUT_FOR_APPROVAL, // The agreement out for approval,

        WAITING_FOR_REVIEW, // The agreement is currently waiting to be reviewed,

        WAITING_FOR_PAYMENT, // The agreement is waiting for payment in order to proceed,

        WAITING_FOR_VERIFICATION, // The agreement is currently waiting to be verified,

        WAITING_FOR_FAXIN // The agreement is waiting for the sender to fax in the document contents before it can be sent for signature
    }

    public class ParticipantSetInfo
    {
        public ParticipantSecurityOption[] securityOptions { get; set; } // Security options that apply to the participant,

        public UserAgreementStatus status { get; set; } // The participant set's status with respect to the widget,

        public ParticipantRole[] roles { get; set; } // The current roles of the participant set. A participant set can have one or more roles,

        public ParticipantInfo[] participantSetMemberInfos { get; set; } //  Information about the members of the recipient set,

        public int signingOrder { get; set; }//Index indicating sequential signing group (specified for hybrid routing)
    }

    public enum UserAgreementStatus
    {
        EXPIRED, // The agreement has expired,

        SIGNED, // The agreement has been signed and filed,

        WAITING_FOR_MY_APPROVAL, // The agreement is waiting for the current participant to approve,

        OTHER, // In the future, statuses other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive status OTHER. You may need to update your client application to the latest version of the API to receive the new statuses in those cases,

        UNKNOWN, // The current status of the agreement is unknown,

        ARCHIVED, // The agreement has been archived,

        OUT_FOR_SIGNATURE, // The agreement is out for signature,

        APPROVED, // The agreement has been approved,

        HIDDEN, // The agreement is currently hidden,

        WAITING_FOR_MY_DELEGATION, // The agreement is waiting for the current participant to delegate,

        WAITING_FOR_MY_SIGNATURE, // The agreement is waiting for the current participant to sign,

        WAITING_FOR_AUTHORING, // The agreement is waiting to be authored,

        WIDGET, // The agreement is a widget,

        OUT_FOR_APPROVAL, // The agreement out for approval,

        RECALLED, // The agreement has been recalled by the sender,

        FORM, // The agreement is a form,

        NOT_YET_VISIBLE, // The agreement is not yet visible to the current participant,

        IN_REVIEW, // The agreement is in the review process,

        WAITING_FOR_MY_REVIEW, // The agreement is waiting for the current participant to review,

        PARTIAL, // The agreement is incomplete,

        WAITING_FOR_FAXIN // The agreement is waiting for the signature to be faxed-in
    }

    public enum ParticipantRole
    {
        SENDER, // Sender or originator of the document,

        SHARE, // Participant with whom the document has been shared,

        SIGNER, // Signer of the document,

        OTHER, // In the future, roles other than those above may be added to the Adobe Document Cloud application. For backward compatibility reasons, existing API clients will receive role OTHER. You may need to update your client application to the latest version of the API to receive the new roles in those cases,

        DELEGATE_TO_SIGNER, // Delegate to signer of the document,

        CC, // Participant that is bound to the document as an observer, by the sender,

        DELEGATE_TO_APPROVER, // Delegate to approver of the document,

        APPROVER, // Approver of the document,

        DELEGATE  // Participant that is delegated to sign the document, by the signer
    }

    public class ParticipantInfo
    {
        public string title { get; set; }// The title of the participant, if available,

        public ParticipantSecurityOption[] securityOptions { get; set; }//Security options that apply to the participant,

        public string email { get; set; }// The email address of the participant,

        public string name { get; set; }// The name of the participant, if available,

        public string company { get; set; }// The company of the participant, if available,

        public ParticipantSetInfo alternateParticipants { get; set; }// All the child participants of the current participant. The possible values for the status of these participants are, SHARE and DELEGATE
    }

    public class Nextparticipantsetinfo
    {
        public Nextparticipantsetmemberinfo[] nextParticipantSetMemberInfos { get; set; }
    }

    public class Nextparticipantsetmemberinfo
    {
        public DateTime waitingSince { get; set; }
        public string email { get; set; }
        public string name { get; set; }
    }

    public class AgreementCreationResponse
    {
        public DateTime expiration { get; set; }
        public string agreementId { get; set; }
        public string embeddedCode { get; set; }
        public string url { get; set; }
    }

    public class AgreementCreationInfo
    {
        public Documentcreationinfo documentCreationInfo { get; set; } //Information about the document you want to send,
        public InteractiveOptions options { get; set; } //Options for authoring and sending the agreement
    }

    public class Documentcreationinfo
    {
        public string signatureType { get; set; } //Specifies the type of signature you would like to request - written or eSignature. The possible values are ESIGN or WRITTEN,
        public FileInfo[] formFieldLayerTemplates { get; set; } //Specifies the form field layer template or source of form fields to apply on the files in this transaction. If specified, the FileInfo for this parameter must refer to a form field layer template via libraryDocumentId or libraryDocumentName, or if specified via transientDocumentId or documentURL, it must be of a supported file type. Note: Only one of the four parameters in every FileInfo object must be specified,
        public SecurityOption securityOptions { get; set; } //Sets optional secondary security parameters for your document,
        public string callbackInfo { get; set; } //A publicly accessible url to which Adobe Document Cloud will do an HTTP GET operation every time there is a new agreement event. HTTP authentication is supported using standard embedded syntax - i.e. http://username:password@your.server.com/path/to/file. Adobe Document Cloud can also ping your system using HTTP PUT with the final signed PDF. Please contact support@echosign.com if you wish to use this option.,
        public int daysUntilSigningDeadline { get; set; } //The number of days that remain before the document expires. You cannot sign the document after it expires,
        public string locale { get; set; } //he locale associated with this agreement - specifies the language for the signing page and emails, for example en_US or fr_FR. If none specified, defaults to the language configured for the agreement sender,
        public RecipientSetInfo[] recipientSetInfos { get; set; } // A list of one or more recipient sets. A recipient set may have one or more recipients. If any member of the recipient set signs, the agreement is considered signed by the recipient set. For regular (non-MegaSign) documents, there is no limit on the number of electronic signatures in a single document. Written signatures are limited to four per document. This limit includes the sender if the sender's signature is also required,
        public string[] ccs { get; set; } //A list of one or more email addresses that you want to copy on this transaction. The email addresses will each receive an email at the beginning of the transaction and also when the final document is signed. The email addresses will also receive a copy of the document, attached as a PDF file,
        public Externalid externalId { get; set; } //A unique identifier for your transaction from an external system. You can use the ExternalID to search for your transaction through API,
        public Vaultinginfo vaultingInfo { get; set; }//Sets the vaulting properties that allows Adobe Document Cloud to securely store documents with a vault provider,
        public string signatureFlow { get; set; } //['SENDER_SIGNATURE_NOT_REQUIRED' or 'SENDER_SIGNS_LAST' or 'SENDER_SIGNS_FIRST' or 'SEQUENTIAL' or 'PARALLEL']: Selects the workflow you would like to use - whether the sender needs to sign before the recipient, after the recipient, or not at all. The possible values for this variable are SENDER_SIGNATURE_NOT_REQUIRED, SENDER_SIGNS_LAST, SENDER_SIGNS_FIRST, SEQUENTIAL or PARALLEL. Note: leave unspecified for hybrid routing,
        public RequestFormField[] formFields { get; set; } //Information of form fields of an agreement. PDF_SIGNATURE inputType field is currently not supported,
        public string message { get; set; } //An optional message to the recipients, describing what is being sent or why their signature is required,
        public Mergefieldinfo[] mergeFieldInfo { get; set; } //Optional default values for fields to merge into the document. The values will be presented to the signers for editable fields; for read-only fields the provided values will not be editable during the signing process. Merging data into fields is currently not supported when used with libraryDocumentId or libraryDocumentName. Only file and url are curently supported,
        public FileInfo[] fileInfos { get; set; }//A list of one or more files (or references to files) that will be sent out for signature. If more than one file is provided, they will be combined into one PDF before being sent out. Note: Only one of the four parameters in every FileInfo object must be specified,
        public string reminderFrequency { get; set; }//['DAILY_UNTIL_SIGNED' or 'WEEKLY_UNTIL_SIGNED']: Optional parameter that sets how often you want to send reminders to the recipients. The possible values are DAILY_UNTIL_SIGNED or WEEKLY_UNTIL_SIGNED,
        public Postsignoptions postSignOptions { get; set; }//URL and associated properties for the success page the user will be taken to after completing the signing process,
        public string name { get; set; }//The name of the agreement that will be used to identify it, in emails and on the website
    }

    public class Externalid
    {
        public string id { get; set; }
        public string group { get; set; }
        public string _namespace { get; set; }
    }

    public class Vaultinginfo
    {
        public bool enabled { get; set; }
    }

    public class Postsignoptions
    {
        public int redirectDelay { get; set; } //The delay (in seconds) before the user is taken to the success page. If this value is greater than 0, the user will first see the standard Adobe Document Cloud success message, and then after a delay will be redirected to your success page.,
        public string redirectUrl { get; set; } //A publicly accessible url to which the user will be sent after successfully completing the signing process.
    }

    public class RequestFormField
    {
        public string alignment { get; set; }
        public string borderStyle { get; set; }
        public string fontColor { get; set; }
        public string fontName { get; set; }
        public string borderColor { get; set; }
        public string displayLabel { get; set; }
        public string radioCheckType { get; set; }
        public string calculatedExpression { get; set; }
        public string backgroundColor { get; set; }
        public string formatData { get; set; }
        public int recipientIndex { get; set; }
        public string displayFormat { get; set; }
        public string contentType { get; set; }
        public int maxLength { get; set; }
        public FormFieldLocation[] locations { get; set; }
        public int minLength { get; set; }
        public string name { get; set; }
        public string inputType { get; set; }
        public string specialFormula { get; set; }
        public bool required { get; set; }
        public string defaultValue { get; set; }
        public int minNumberValue { get; set; }
        public int maxNumberValue { get; set; }
        public string regularExpression { get; set; }
        public string maskingText { get; set; }
        public string showOrHide { get; set; }
        public string specialErrMsg { get; set; }
        public string format { get; set; }
        public string fontSize { get; set; }
        public bool masked { get; set; }
        public string displayFormatType { get; set; }
        public string anyOrAll { get; set; }
        public FormFieldCondition[] conditions { get; set; }
        public bool readOnly { get; set; }
        public string borderWidth { get; set; }
        public bool hidden { get; set; }
        public string[] visibleOptions { get; set; }
        public string[] hiddenOptions { get; set; }
        public string tooltip { get; set; }
    }

    public class FormFieldLocation
    {
        public Double height { get; set; }
        public Double width { get; set; }
        public int pageNumber { get; set; }
        public Double left { get; set; }
        public Double top { get; set; }
    }

    public class FormFieldCondition
    {
        public string value { get; set; }
        public int whenFieldLocationIndex { get; set; }
        public string whenFieldName { get; set; }
    }

    public class Mergefieldinfo
    {
        public string fieldName { get; set; }
        public string defaultValue { get; set; }
    }

    public class InteractiveOptions
    {
        public bool noChrome { get; set; }
        public SendThroughWebOptions sendThroughWebOptions { get; set; }
        public bool sendThroughWeb { get; set; }
        public string locale { get; set; }
        public bool authoringRequested { get; set; }
        public bool autoLoginUser { get; set; }
    }

    public class SendThroughWebOptions
    {
        public FileUploadOptions fileUploadOptions { get; set; }
    }

    public class FileUploadOptions
    {
        public bool webConnectors { get; set; }
        public bool libraryDocument { get; set; }
        public bool localFile { get; set; }
    }

    public class DocumentImageUrls
    {
        public DocumentImageUrl[] supportingDocumentsImageUrls { get; set; }// A list of supporting document image URLs., 
        public DocumentImageUrl[] documentsImageUrls { get; set; }// A list of documents image URLs.
    }

    public class DocumentImageUrl
    {
        public ImageUrl imageUrls { get; set; }// A list of objects representing all image URLs.(one per imagesize).
    }

    public class ImageUrl
    {
        public string[] urls { get; set; }// An ordered list of image urls (one per page).,

        public bool imagesAvailable { get; set; }// true if images for the associated image size is available, else false.,

        public string imageSize { get; set; }//['FIXED_WIDTH_50px' or 'FIXED_WIDTH_250px' or 'FIXED_WIDTH_675px' or 'ZOOM_50_PERCENT' or 'ZOOM_75_PERCENT' or 'ZOOM_100_PERCENT' or 'ZOOM_125_PERCENT' or 'ZOOM_150_PERCENT' or 'ZOOM_200_PERCENT']: ImageSize corresponding to the imageUrl returned 
    }

    public class DocumentUrl
    {
        public string url { get; set; }//Secure URL of the document
    }

    public class AgreementDocuments
    {
        public SupportingDocument[] supportingDocuments { get; set; }//  A list of supporting documents. This is returned only if there are any supporting document in the agreement,

        public Document[] documents { get; set; } // A list of objects representing the documents
    }

    public class SupportingDocument
    {
        public string displayLabel { get; set; }// Display name of the document,

        public string supportingDocumentId { get; set; }//Id representing the document,

        public int numPages { get; set; }// Number of pages in the document,

        public string fieldName { get; set; }// The name of the supporting document field,

        public string mimeType { get; set; }// Mime-type of the document
    }

    public class SigningUrlResponse
    {
        public string message { get; set; }
        public string code { get; set; }
        public SigningUrlSetInfo[] signingUrlSetInfos { get; set; }// An array of urls for signer sets involved in this agreement.
    }

    public class SigningUrlSetInfo
    {
        public SigningUrl[] signingUrls { get; set; } //An array of urls for current signer set.
    }

    public class SigningUrl
    {
        public string email { get; set; }// The email address of the signer associated with this signing url,

        public string esignUrl { get; set; }// The email address of the signer associated with this signing url
    }



    public class CombinedDocumentPagesInfo
    {
        public DocumentPageInfo[] documentPagesInfo { get; set; }// List of basic information of all pages of Agreement's combined document.
    }

    public class DocumentPageInfo
    {
        public double height { get; set; }// Height of the page,

        public double rotation { get; set; }//Rotation angle of the page in clockwise direction in degree.,

        public double width { get; set; }// Width of the page,

        public int pageNumber { get; set; }// Number of the page in combined document starting from 1.
    }

    public class AgreementStatusUpdateInfo
    {
        public string value { get; set; }// ['CANCEL']: The state to which the agreement is to be updated. The only valid state for this variable is currently, CANCEL,

        public string comment { get; set; }// An optional comment describing to the recipient why you want to cancel the transaction,

        public bool notifySigner { get; set; }// Whether or not you would like the recipient to be notified that the transaction has been cancelled. The notification is mandatory if any party has already signed this document. The default value is false
    }

    public class AgreementStatusUpdateResponse
    {
        public string result { get; set; }// A status value showing the result of this operation
    }


    public class ReminderCreationInfo
    {

        public string agreementId { get; set; }// The agreement identifier,

        public string comment { get; set; }// An optional message sent to the recipients, describing what is being sent and why their signatures are required.
    }

    public class ReminderCreationResult
    {

        public string result { get; set; }// A status value indicating the result of the operation,

        public ParticipantEmailSetInfo participantEmailsSet { get; set; }//The info of the party (participant sets) that was reminded.
    }

    public class ParticipantEmailSetInfo
    {
        public ParticipantEmailInfo participantEmailSetInfo { get; set; }//The info about the members of the participant set
    }

    public class ParticipantEmailInfo
    {
        public string participantEmail { get; set; }// The email address of the user to whom the reminder was sent. This may either be the sender or the recipient of the document depending on the selected workflow, and on whose turn it was to sign. In the current release, the reminder is sent to that user that is currently expected to sign a given document
    }
    #endregion
}