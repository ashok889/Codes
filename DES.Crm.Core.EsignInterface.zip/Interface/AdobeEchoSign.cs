﻿using DES.Crm.Core.EsignInterface.Interface;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace DES.Crm.Core.EsignInterface
{
    public class AdobeEchoSign : IAdobeEchoSign
    {
        private HttpClient Client { get; set; }
        readonly Dictionary<string, Func<HttpClient, object[], object>> methodImpls;

        public AdobeEchoSign(HttpClient client)
        {
            var requestBuilder = RequestBuilder.ForType<IAdobeEchoSign>(null);
            methodImpls = requestBuilder.InterfaceHttpMethods.ToDictionary(k => k, v => requestBuilder.BuildRestResultFuncForMethod(v));
            Client = client;
        }

        #region TransientDocument

        public async Task<TransientDocumentResponse> CreateTransientDocument(string fileName, byte[] fileContents)
        {
            try
            {
                var relativePath = string.Empty;
                var methods = typeof(IAdobeEchoSign).GetMethods();
                foreach (var hma in from method in methods where method.Name.Equals("CreateTransientDocument") select method.GetCustomAttributes(true).OfType<HttpMethodAttribute>().First())
                {
                    relativePath = hma.Path;
                }
                var fileResponse = SendFileToServer(relativePath, fileName, fileContents);

                dynamic response = JsonConvert.DeserializeObject<TransientDocumentResponse>(fileResponse);

                var responseCode = response.code;
                if (responseCode != null)
                {
                    throw new Exception(fileResponse);
                }
                return response;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region LibraryDocument

        public async Task<LibraryDocumentCreationResponse> PostLibraryDocument(LibraryCreationInfo libraryCreationInfo)
        {
            var arguments = new object[] { libraryCreationInfo };
            return await (Task<LibraryDocumentCreationResponse>)methodImpls["PostLibraryDocument"](Client, arguments);
        }

        public async Task<LibraryDocuments> GetLibraryDocuments()
        {
            var arguments = new object[] { };
            return await (Task<LibraryDocuments>)methodImpls["GetLibraryDocuments"](Client, arguments);
        }

        public async Task<LibraryDocumentInfo> GetLibraryDocument(string libraryDocumentId)
        {
            var arguments = new object[] { libraryDocumentId };
            return await (Task<LibraryDocumentInfo>)methodImpls["GetLibraryDocument"](Client, arguments);
        }

        public async Task<Documents> GetDocuments(string libraryDocumentId)
        {
            var arguments = new object[] { libraryDocumentId };
            return await (Task<Documents>)methodImpls["GetDocuments"](Client, arguments);
        }

        public async Task<HttpResponseMessage> GetDocument(string libraryDocumentId, string documentId)
        {
            var arguments = new object[] { libraryDocumentId, documentId };
            return await (Task<HttpResponseMessage>)methodImpls["GetDocument"](Client, arguments);
        }

        public async Task<HttpResponseMessage> GetLibraryDocumentAuditTrail(string libraryDocumentId)
        {
            var arguments = new object[] { libraryDocumentId };
            return await (Task<HttpResponseMessage>)methodImpls["GetLibraryDocumentAuditTrail"](Client, arguments);
        }

        public async Task<HttpResponseMessage> GetCombinedDocument(string libraryDocumentId, bool auditReport)
        {
            var arguments = new object[] { libraryDocumentId, auditReport };
            return await (Task<HttpResponseMessage>)methodImpls["GetCombinedDocument"](Client, arguments);
        }



        #endregion

        #region MegaSign

        public async Task<MegaSignCreationResponse> CreateMegaSign(MegaSignCreationRequest megaSignCreationRequest)
        {
            try
            {
                var arguments = new object[] { megaSignCreationRequest };
                return await (Task<MegaSignCreationResponse>)methodImpls["CreateMegaSign"](Client, arguments);
            }
            catch (Exception ex)
            {
                throw new Exception(((Refit.ApiException)(ex)).Content.ToString());
            }

        }

        public async Task<MegaSigns> GetMegaSigns(string query)
        {
            var arguments = new object[] { query };
            return await (Task<MegaSigns>)methodImpls["GetMegaSigns"](Client, arguments);
        }

        public async Task<MegaSignInfo> GetMegaSign(string megaSignId)
        {
            var arguments = new object[] { megaSignId };
            return await (Task<MegaSignInfo>)methodImpls["GetMegaSign"](Client, arguments);
        }

        public async Task<MegaSignChildAgreements> GetMegaSignAgreements(string megaSignId)
        {
            try
            {
                var arguments = new object[] { megaSignId };
                return await (Task<MegaSignChildAgreements>)methodImpls["GetMegaSignAgreements"](Client, arguments);
            }
            catch (Exception ex)
            {
                throw new Exception(((Refit.ApiException)(ex)).Content.ToString());
            }

        }

        #endregion

        #region Agreement

        public async Task<ReminderCreationResult> PostAgreementReminder(ReminderCreationInfo reminderCreationInfo)
        {
            var arguments = new object[] { reminderCreationInfo };
            return await (Task<ReminderCreationResult>)methodImpls["PostAgreementReminder"](Client, arguments);
        }

        public async Task<AgreementCreationResponse> CreateAgreement(AgreementCreationInfo agreementCreationInfo)
        {
            try
            {
                var arguments = new object[] { agreementCreationInfo };
                return await (Task<AgreementCreationResponse>)methodImpls["CreateAgreement"](Client, arguments);
            }
            catch (Exception ex)
            {
                throw new Exception(((Refit.ApiException)(ex)).Content.ToString());
            }

        }

        public async Task<Agreements> GetAgreements(string query, string externalId, string externalGroup, string externalNamespace)
        {
            var arguments = new object[] { query, externalId, externalGroup, externalNamespace };
            return await (Task<Agreements>)methodImpls["GetAgreements"](Client, arguments);
        }

        public async Task<AgreementInfo> GetAgreement(string agreementId)
        {
            try
            {
                var arguments = new object[] { agreementId };
                return await (Task<AgreementInfo>)methodImpls["GetAgreement"](Client, arguments);
            }
            catch (Exception ex)
            {
                throw new Exception(((Refit.ApiException)(ex)).Content.ToString());
            }

        }

        public async Task<DocumentImageUrls> GetAgreementDocumentsImageUrls(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<DocumentImageUrls>)methodImpls["GetAgreementDocumentsImageUrls"](Client, arguments);
        }

        public async Task<DocumentImageUrl> GetAgreementDocumentImageUrls(string agreementId, string documentId)
        {
            var arguments = new object[] { agreementId, documentId };
            return await (Task<DocumentImageUrl>)methodImpls["GetAgreementDocumentImageUrls"](Client, arguments);
        }

        public async Task<DocumentUrl> GetAgreementDocumentUrl(string agreementId, string documentId)
        {
            var arguments = new object[] { agreementId, documentId };
            return await (Task<DocumentUrl>)methodImpls["GetAgreementDocumentUrl"](Client, arguments);
        }

        public async Task<AgreementDocuments> GetAgreementDocuments(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<AgreementDocuments>)methodImpls["GetAgreementDocuments"](Client, arguments);
        }

        public async Task<HttpResponseMessage> GetAgreementDocument(string agreementId, string documentId)
        {
            var arguments = new object[] { agreementId, documentId };
            return await (Task<HttpResponseMessage>)methodImpls["GetAgreementDocument"](Client, arguments);
        }

        public async Task<HttpResponseMessage> GetAgreementAuditTrailPdf(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<HttpResponseMessage>)methodImpls["GetAgreementAuditTrailPdf"](Client, arguments);
        }

        public async Task<SigningUrlResponse> GetAgreementSigningUrls(string agreementId)
        {
            try
            {
                var arguments = new object[] { agreementId };
                return await (Task<SigningUrlResponse>)methodImpls["GetAgreementSigningUrls"](Client, arguments);
            }
            catch (Exception ex)
            {
                throw new Exception(((Refit.ApiException)(ex)).Content.ToString());
            }

        }

        public async Task<HttpResponseMessage> GetAgreementCombinedDocumentPdf(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<HttpResponseMessage>)methodImpls["GetAgreementCombinedDocumentPdf"](Client, arguments);
        }

        public async Task<DocumentUrl> GetAgreementCombinedDocumentUrl(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<DocumentUrl>)methodImpls["GetAgreementCombinedDocumentUrl"](Client, arguments);
        }

        public async Task<CombinedDocumentPagesInfo> GetAgreementCombinedDocumentPagesInfo(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<CombinedDocumentPagesInfo>)methodImpls["GetAgreementCombinedDocumentPagesInfo"](Client, arguments);
        }

        public async Task<HttpResponseMessage> GetAgreementFormDataCsv(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return await (Task<HttpResponseMessage>)methodImpls["GetAgreementFormDataCsv"](Client, arguments);
        }

        public async Task<AgreementStatusUpdateResponse> PutAgreementStatus(string agreementId, AgreementStatusUpdateInfo agreementStatusUpdateInfo)
        {
            var arguments = new object[] { agreementId, agreementStatusUpdateInfo };
            return await (Task<AgreementStatusUpdateResponse>)methodImpls["GetAgreementCombinedDocumentUrl"](Client, arguments);
        }

        public Task<string> DeleteAgreementDocuments(string agreementId)
        {
            var arguments = new object[] { agreementId };
            return (Task<string>)methodImpls["DeleteAgreementDocuments"](Client, arguments);
        }

        public async Task<string> DeleteAgreement(string agreementId)
        {
            try
            {
                var arguments = new object[] { agreementId };
                return await (Task<string>)(methodImpls["DeleteAgreement"](Client, arguments));
            }
            catch (Exception ex)
            {
                throw new Exception(((Refit.ApiException)(ex)).Content.ToString());
            }

        }

        #endregion

        #region SharedMethods

        private string SendFileToServer(string relativePath, string fileName, byte[] fileContents)
        {
            var stringContents = string.Empty;

            string contentType = MimeMapping.GetMimeMapping(fileName);

            var requestMessage = new HttpRequestMessage(HttpMethod.Post, Client.BaseAddress + relativePath);
            requestMessage.Headers.ExpectContinue = false;

            var multiPartContent = new MultipartFormDataContent("----Boundary");
            var byteArrayContent = new ByteArrayContent(fileContents);
            byteArrayContent.Headers.Add("Content-Type", contentType);
            multiPartContent.Add(byteArrayContent, "File", fileName);
            requestMessage.Content = multiPartContent;
            Task<HttpResponseMessage> httpRequest = Client.SendAsync(requestMessage, HttpCompletionOption.ResponseContentRead, CancellationToken.None);
            HttpResponseMessage httpResponse = httpRequest.Result;
            HttpStatusCode statusCode = httpResponse.StatusCode;
            HttpContent responseContent = httpResponse.Content;

            if (responseContent != null)
            {
                Task<String> stringContentsTask = responseContent.ReadAsStringAsync();
                stringContents = stringContentsTask.Result;
            }

            return stringContents;
        }

        #endregion

    }
}

