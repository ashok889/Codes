﻿using DES.Crm.Core.EsignInterface.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace DES.Crm.Core.EsignInterface
{
    [ServiceContract]
    public interface IEsignService
    {
        /// <summary>
        /// GetLibraryDocuments
        /// </summary>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "getLibraryDocuments?triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        LibraryDocumentsWrapper GetLibraryDocuments(string triggeringUserEmailAddress, string integrationKey);
        
        /// <summary>
        /// GetCombinedDocument
        /// </summary>
        /// <param name="libraryDocumentId"></param>
        /// <param name="auditReport"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]        
        [WebInvoke(Method = "GET",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Bare,
            UriTemplate = "getCombinedDocument?libraryDocumentId={libraryDocumentId}&auditReport={auditReport}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        byte[] GetCombinedDocument(string libraryDocumentId, bool auditReport, string triggeringUserEmailAddress, string integrationKey);        

        /// <summary>
        /// GetLibraryDocument
        /// </summary>
        /// <param name="libraryDocumentId"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "getLibraryDocument?libraryDocumentId={libraryDocumentId}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        LibraryDocumentInfoWrapper GetLibraryDocument(string libraryDocumentId, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// CreateTransientDocument
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="fileContents"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "createTransientDocument?fileName={fileName}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        TransientDocumentResponseWrapper CreateTransientDocument(string fileName, byte[] fileContents, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// CreateMegaSign
        /// </summary>
        /// <param name="megaSignCreationRequest"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "createMegaSign?triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        MegaSignCreationResponseWrapper CreateMegaSign(MegaSignCreationRequestWrapper megaSignCreationRequest, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// CreateAgreement
        /// </summary>
        /// <param name="agreementCreationInfo"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "createAgreement?triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        AgreementCreationResponseWrapper CreateAgreement(AgreementCreationInfoWrapper agreementCreationInfo, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// GetMegaSignAgreements
        /// </summary>
        /// <param name="megaSignId"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",            
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "getMegaSignAgreements?megaSignId={megaSignId}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        MegaSignChildAgreementsWrapper GetMegaSignAgreements(string megaSignId, string triggeringUserEmailAddress, string integrationKey);


        /// <summary>
        /// GetAgreement
        /// </summary>
        /// <param name="agreementId">Adobe Agreement ID</param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "getAgreement?agreementId={agreementId}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        AgreementInfoWrapper GetAgreement(string agreementId, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// GetAgreements
        /// </summary>
        /// <param name="query"></param>
        /// <param name="externalId"></param>
        /// <param name="externalGroup"></param>
        /// <param name="externalNamespace"></param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "getAgreements?query={query}&externalId={externalId}&externalGroup={externalGroup}&externalNamespace={externalNamespace}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        AgreementsWrapper GetAgreements(string query, string externalId, string externalGroup, string externalNamespace, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// GetAgreementSigningUrls
        /// </summary>
        /// <param name="agreementId">Adobe Agreement ID</param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
           ResponseFormat = WebMessageFormat.Json,
           BodyStyle = WebMessageBodyStyle.Wrapped,
           UriTemplate = "getAgreementSigningUrls?agreementId={agreementId}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        SigningUrlResponseWrapper GetAgreementSigningUrls(string agreementId, string triggeringUserEmailAddress, string integrationKey);

        /// <summary>
        /// GetAgreementFormDataCsv
        /// </summary>
        /// <param name="agreementId">Adobe Agreement ID</param>
        /// <param name="triggeringUserEmailAddress">Mandatory. Adobe user email address</param>
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
           ResponseFormat = WebMessageFormat.Json,
           BodyStyle = WebMessageBodyStyle.Wrapped,
           UriTemplate = "getAgreementFormDataCsv?agreementId={agreementId}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        byte[] GetAgreementFormDataCsv(string agreementId, string triggeringUserEmailAddress, string integrationKey);


        /// <summary>
        /// DeleteAgreement
        /// </summary>
        /// <param name="agreementId">Adobe Agreement ID</param>        
        /// <param name="integrationKey">Set "string.Empty" if want to use default. Otherwise use Format: proxyserver=$proxyserver$;proxyserverport=$proxyserverport$;apiurlbase=$apiurlbase$;accesstoken=$decryptedaccesstoken$</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "GET",
           ResponseFormat = WebMessageFormat.Json,
           BodyStyle = WebMessageBodyStyle.Wrapped,
           UriTemplate = "deleteAgreement?agreementId={agreementId}&triggeringUserEmailAddress={triggeringUserEmailAddress}&integrationKey={integrationKey}")]
        string DeleteAgreement(string agreementId, string triggeringUserEmailAddress, string integrationKey);         
    }

    [DataContract]
    public class TestWrapper
    {
        string _name;
        List<TestSub> _value;

        [DataMember]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        [DataMember]
        public List<TestSub> Value
        {
            get { return _value; }
            set { _value = value; }
        }
    }

    [DataContract]
    public class TestSub
    {
        string _testSubName;

        [DataMember]
        public string TestSubName
        {
            get { return _testSubName; }
            set { _testSubName = value; }
        }
    }

    [DataContract]    
    public class LibraryDocumentsWrapper
    {
        List<LibraryDocumentWrapper> _libraryDocumentList;

        [DataMember]
        public List<LibraryDocumentWrapper> LibraryDocumentList
        {
            get { return _libraryDocumentList; }
            set { _libraryDocumentList = value; }
        }
    }

    [DataContract]
    public class LibraryDocumentWrapper
    {
        string _libraryDocumentId;
        List<LibraryTemplateType> _libraryTemplateTypes;
        string _name;
        DateTime _modifiedDate;
        DocumentScope _scope;

        [DataMember]
        public string LibraryDocumentId
        {
            get { return _libraryDocumentId; }
            set { _libraryDocumentId = value; }
        }

        [DataMember]
        public List<LibraryTemplateType> LibraryTemplateTypes
        {
            get { return _libraryTemplateTypes; }
            set { _libraryTemplateTypes = value; }
        }

        [DataMember]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        [DataMember]
        public DateTime ModifiedDate
        {
            get { return _modifiedDate; }
            set { _modifiedDate = value; }
        }

        [DataMember]
        public DocumentScope Scope
        {
            get { return _scope; }
            set { _scope = value; }
        }
    }

    [DataContract]
    public class LibraryDocumentInfoWrapper
    {
        string _libraryDocumentId; //A resource identifier that can be used to uniquely identify the library document in other apis,
        string _name; //The name of the document, specified by the sender, 
        string _locale; //The locale associated with this agreement - for example, en_US or fr_FR,
        string _message { get; set; } // The message associated with the document that the sender has provided, 
        List<LibDocSecurityOption> _securityOptions; //Security information about the document that specifies whether or not a password is required to view and sign the document, 
        LibDocStatus _status; //The current status of the document, 
        List<LibDocumentHistoryEventWrapper> _events; //An ordered list of the events in the audit trail of this document, 
        List<LibDocParticipantInfoWrapper> _participants; //Information about all the participants of this document

        [DataMember]
        public string LibraryDocumentId { get { return _libraryDocumentId; } set { _libraryDocumentId = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public string Locale { get { return _locale; } set { _locale = value; } }

        [DataMember]
        public string Message { get { return _message; } set { _message = value; } }

        [DataMember]
        public List<LibDocSecurityOption> SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public LibDocStatus Status { get { return _status; } set { _status = value; } }

        [DataMember]
        public List<LibDocumentHistoryEventWrapper> Events { get { return _events; } set { _events = value; } }

        [DataMember]
        public List<LibDocParticipantInfoWrapper> Participants { get { return _participants; } set { _participants = value; } }
    }

    [DataContract]
    public class LibDocumentHistoryEventWrapper
    {
        string _actingUserEmail;
        string _actingUserIpAddress;
        string _comment;
        DateTime _date;
        string _description;
        LibDocEventDeviceLocationWrapper _deviceLocation;
        string _participantEmail;
        string _synchronizationId;
        EventType _type;
        string _vaultEventId;
        string _versionId;

        [DataMember]
        public string ActingUserEmail { get { return _actingUserEmail; } set { _actingUserEmail = value; } }

        [DataMember]
        public string ActingUserIpAddress { get { return _actingUserIpAddress; } set { _actingUserIpAddress = value; } }

        [DataMember]
        public string Comment { get { return _comment; } set { _comment = value; } }

        [DataMember]
        public DateTime Date { get { return _date; } set { _date = value; } }

        [DataMember]
        public string Description { get { return _description; } set { _description = value; } }

        [DataMember]
        public LibDocEventDeviceLocationWrapper DeviceLocation { get { return _deviceLocation; } set { _deviceLocation = value; } }

        [DataMember]
        public string ParticipantEmail { get { return _participantEmail; } set { _participantEmail = value; } }

        [DataMember]
        public string SynchronizationId { get { return _synchronizationId; } set { _synchronizationId = value; } }

        [DataMember]
        public EventType Type { get { return _type; } set { _type = value; } }

        [DataMember]
        public string VaultEventId { get { return _vaultEventId; } set { _vaultEventId = value; } }

        [DataMember]
        public string VersionId { get { return _versionId; } set { _versionId = value; } }
    }

    [DataContract]
    public class LibDocEventDeviceLocationWrapper
    {
        int _longitude; ///Longitude coordinate,

        int _latitude; // Latitude coordinate

        [DataMember]
        public int Longitude { get { return _longitude; } set { _longitude = value; } }

        [DataMember]
        public int Latitude { get { return _latitude; } set { _latitude = value; } }
    }

    [DataContract]
    public class LibDocParticipantInfoWrapper
    {
        List<LibDocParticipantInfoWrapper> _alternateParticipants;
        string _company;
        string _email;
        string _name;
        List<LibDocParticipantRole> _roles;
        List<ParticipantSecurityOption> _securityOptions;
        UserLibDocumentStatus _status;
        string _title;

        [DataMember]
        public List<LibDocParticipantInfoWrapper> AlternateParticipants { get { return _alternateParticipants; } set { _alternateParticipants = value; } }

        [DataMember]
        public string Company { get { return _company; } set { _company = value; } }

        [DataMember]
        public string Email { get { return _email; } set { _email = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public List<LibDocParticipantRole> Roles { get { return _roles; } set { _roles = value; } }

        [DataMember]
        public List<ParticipantSecurityOption> SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public UserLibDocumentStatus Status { get { return _status; } set { _status = value; } }

        [DataMember]
        public string Title { get { return _title; } set { _title = value; } }
    }

    [DataContract]
    public class TransientDocumentResponseWrapper
    {
        string _transientDocumentId; // The unique identifier of the uploaded document that can be used in an agreement or a megaSign or widget creation call
        string _code;

        [DataMember]
        public string TransientDocumentId { get { return _transientDocumentId; } set { _transientDocumentId = value; } }

        [DataMember]
        public string Code { get { return _code; } set { _code = value; } }
    }

    [DataContract]
    public class MegaSignCreationResponseWrapper
    {
        string _megaSignId; //Unique identifier of the MegaSign parent agreement

        [DataMember]
        public string MegaSignId { get { return _megaSignId; } set { _megaSignId = value; } }
    }

    [DataContract]    
    public class MegaSignCreationRequestWrapper
    {
        MegaSignCreationInfoWrapper _megaSignCreationInfo; //Information about the MegaSign you want to send

        [DataMember]
        public MegaSignCreationInfoWrapper MegaSignCreationInfo { get { return _megaSignCreationInfo; } set { _megaSignCreationInfo = value; } }
    }

    [DataContract]
    public class MegaSignCreationInfoWrapper
    {
        string _signatureType; //(string) = ['ESIGN' or 'WRITTEN'] Specifies the type of signature you would like to request - written or eSignature. The possible values are ESIGN or WRITTEN,

        List<FileInfoWrapper> _formFieldLayerTemplates; //Specifies the form field layer template or source of form fields to apply on the files in this transaction. If specified, the FileInfo for this parameter must refer to a form field layer template via libraryDocumentId or libraryDocumentName, or if specified via transientDocumentId or documentURL, it must be of a supported file type. Note: Only one of the four parameters in every FileInfo object must be specified,

        SecurityOptionWrapper _securityOptions; // Sets Set "string.Empty" if want to use default secondary security parameters for your document,

        string _callbackInfo; // A publicly accessible url to which Adobe Document Cloud will do an HTTP GET operation every time there is a new agreement event. HTTP authentication is supported using standard embedded syntax - i.e. http://username:password@your.server.com/path/to/file. Adobe Document Cloud can also ping your system using HTTP PUT with the final signed PDF. Please contact support@echosign.com if you wish to use this option.,

        int _daysUntilSigningDeadline; // The number of days that remain before the document expires. You cannot sign the document after it expires,

        string _locale; // The locale associated with this agreement - specifies the language for the signing page and emails, for example en_US or fr_FR. If none specified, defaults to the language configured for the agreement sender,

        List<RecipientSetInfoWrapper> _recipientSetInfos; // A list of one or more recipient sets. Currently a recipient set can have only one recipient.,

        List<string> _ccs; // A list of one or more email addresses that you want to copy on this transaction. The email addresses will each receive an email at the beginning of the transaction and also when the final document is signed. The email addresses will also receive a copy of the document, attached as a PDF file,

        ExternalIdWrapper _externalId; // A unique identifier for your transaction from an external system. You can use the ExternalID to search for your transaction through API,

        VaultingInfoWrapper _vaultingInfo; // Sets the vaulting properties that allows Adobe Document Cloud to securely store documents with a vault provider,

        string _mergeFileTransientId; // The merge file ID as returned from POST /transientDocuments. The merge file contains the details of all the Mega Sign recipients.,

        string _message; // An Set "string.Empty" if want to use default message to the recipients, describing what is being sent or why their signature is required,

        List<MergefieldInfoWrapper> _mergeFieldInfo; // Set "string.Empty" if want to use default default values for fields to merge into the document. The values will be presented to the signers for editable fields; for read-only fields the provided values will not be editable during the signing process. Merging data into fields is currently not supported when used with libraryDocumentId or libraryDocumentName. Only file and url are curently supported,

        List<FileInfoWrapper> _fileInfos; // A list of one or more files (or references to files) that will be sent out for signature. If more than one file is provided, they will be combined into one PDF before being sent out. Note: Only one of the four parameters in every FileInfo object must be specified,

        string _reminderFrequency; // (string, Set "string.Empty" if want to use default) = ['DAILY_UNTIL_SIGNED' or 'WEEKLY_UNTIL_SIGNED'] Set "string.Empty" if want to use default parameter that sets how often you want to send reminders to the recipients. The possible values are DAILY_UNTIL_SIGNED or WEEKLY_UNTIL_SIGNED,

        PostSignOptionsWrapper _postSignOptions { get; set; } // URL and associated properties for the success page the user will be taken to after completing the signing process,

        string _name { get; set; } // The name of the agreement that will be used to identify it, in emails and on the website

        [DataMember]
        public string SignatureType { get { return _signatureType; } set { _signatureType = value; } }

        [DataMember]
        public List<FileInfoWrapper> FormFieldLayerTemplates { get { return _formFieldLayerTemplates; } set { _formFieldLayerTemplates = value; } }

        [DataMember]
        public SecurityOptionWrapper SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public string CallbackInfo { get { return _callbackInfo; } set { _callbackInfo = value; } }

        [DataMember]
        public int DaysUntilSigningDeadline { get { return _daysUntilSigningDeadline; } set { _daysUntilSigningDeadline = value; } }

        [DataMember]
        public string Locale { get { return _locale; } set { _locale = value; } }

        [DataMember]
        public List<RecipientSetInfoWrapper> RecipientSetInfos { get { return _recipientSetInfos; } set { _recipientSetInfos = value; } }

        [DataMember]
        public List<string> Ccs { get { return _ccs; } set { _ccs = value; } }

        [DataMember]
        public ExternalIdWrapper ExternalId { get { return _externalId; } set { _externalId = value; } }

        [DataMember]
        public VaultingInfoWrapper VaultingInfo { get { return _vaultingInfo; } set { _vaultingInfo = value; } }

        [DataMember]
        public string MergeFileTransientId { get { return _mergeFileTransientId; } set { _mergeFileTransientId = value; } }

        [DataMember]
        public string Message { get { return _message; } set { _message = value; } }

        [DataMember]
        public List<MergefieldInfoWrapper> MergeFieldInfo { get { return _mergeFieldInfo; } set { _mergeFieldInfo = value; } }

        [DataMember]
        public List<FileInfoWrapper> FileInfos { get { return _fileInfos; } set { _fileInfos = value; } }

        [DataMember]
        public string ReminderFrequency { get { return _reminderFrequency; } set { _reminderFrequency = value; } }

        [DataMember]
        public PostSignOptionsWrapper PostSignOptions { get { return _postSignOptions; } set { _postSignOptions = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }
    }

    [DataContract]
    public class FileInfoWrapper
    {
        string _transientDocumentId;
        string _libraryDocumentId;
        string _libraryDocumentName;
        URLFileInfoWrapper _documentURL;

        [DataMember]
        public string TransientDocumentId { get { return _transientDocumentId; } set { _transientDocumentId = value; } }

        [DataMember]
        public string LibraryDocumentId { get { return _libraryDocumentId; } set { _libraryDocumentId = value; } }

        [DataMember]
        public string LibraryDocumentName { get { return _libraryDocumentName; } set { _libraryDocumentName = value; } }

        [DataMember]
        public URLFileInfoWrapper DocumentURL { get { return _documentURL; } set { _documentURL = value; } }
    }

    [DataContract]
    public class URLFileInfoWrapper
    {
        string _mimeType;
        string _name;
        string _url;

        [DataMember]
        public string MimeType { get { return _mimeType; } set { _mimeType = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public string Url { get { return _url; } set { _url = value; } }
    }

    [DataContract]
    public class SecurityOptionWrapper
    {
        string _externalPassword;
        string _internalPassword;
        string _kbaProtection;
        string _openPassword;
        string _passwordProtection;
        bool _protectOpen;
        string _webIdentityProtection;

        [DataMember]
        public string ExternalPassword { get { return _externalPassword; } set { _externalPassword = value; } }

        [DataMember]
        public string InternalPassword { get { return _internalPassword; } set { _internalPassword = value; } }

        [DataMember]
        public string KbaProtection { get { return _kbaProtection; } set { _kbaProtection = value; } }

        [DataMember]
        public string OpenPassword { get { return _openPassword; } set { _openPassword = value; } }

        [DataMember]
        public string PasswordProtection { get { return _passwordProtection; } set { _passwordProtection = value; } }

        [DataMember]
        public bool ProtectOpen { get { return _protectOpen; } set { _protectOpen = value; } }

        [DataMember]
        public string WebIdentityProtection { get { return _webIdentityProtection; } set { _webIdentityProtection = value; } }
    }

    [DataContract]
    public class RecipientSetInfoWrapper
    {
        List<RecipientInfoWrapper> _recipientSetMemberInfos;
        RecipientRole _recipientSetRole;
        List<RecipientSecurityOptionWrapper> _securityOptions;
        int _signingOrder;

        [DataMember]
        public List<RecipientInfoWrapper> RecipientSetMemberInfos { get { return _recipientSetMemberInfos; } set { _recipientSetMemberInfos = value; } }

        [DataMember]
        public RecipientRole RecipientSetRole { get { return _recipientSetRole; } set { _recipientSetRole = value; } }

        [DataMember]
        public List<RecipientSecurityOptionWrapper> SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public int SigningOrder { get { return _signingOrder; } set { _signingOrder = value; } }
    }

    [DataContract]
    public class RecipientInfoWrapper
    {
        string _email;
        string _fax;
        List<RecipientSecurityOptionWrapper> _securityOptions;

        [DataMember]
        public string Email { get { return _email; } set { _email = value; } }

        [DataMember]
        public string Fax { get { return _fax; } set { _fax = value; } }

        [DataMember]
        public List<RecipientSecurityOptionWrapper> SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }
    }

    [DataContract]
    public class RecipientSecurityOptionWrapper
    {
        AuthenticationMethod _authenticationMethod;
        string _password;
        List<PhoneInfoWrapper> _phoneInfos;

        [DataMember]
        public AuthenticationMethod AuthenticationMethod { get { return _authenticationMethod; } set { _authenticationMethod = value; } }

        [DataMember]
        public string Password { get { return _password; } set { _password = value; } }

        [DataMember]
        public List<PhoneInfoWrapper> PhoneInfos { get { return _phoneInfos; } set { _phoneInfos = value; } }
    }

    [DataContract]
    public class PhoneInfoWrapper
    {
        string _countryCode;
        string _phone;

        [DataMember]
        public string CountryCode { get { return _countryCode; } set { _countryCode = value; } }

        [DataMember]
        public string Phone { get { return _phone; } set { _phone = value; } }
    }

    [DataContract]
    public class ExternalIdWrapper
    {
        string _group;
        string _id;

        [JsonProperty(PropertyName = "namespace")]
        string _nameSpace;

        [DataMember]
        public string Group { get { return _group; } set { _group = value; } }

        [DataMember]
        public string Id { get { return _id; } set { _id = value; } }

        [DataMember]
        public string NameSpace { get { return _nameSpace; } set { _nameSpace = value; } }
    }

    [DataContract]
    public class VaultingInfoWrapper
    {
        bool _enabled;

        [DataMember]
        public bool Enabled { get { return _enabled; } set { _enabled = value; } }
    }

    [DataContract]
    public class MergefieldInfoWrapper
    {
        string _defaultValue;
        string _fieldName;

        [DataMember]
        public string DefaultValue { get { return _defaultValue; } set { _defaultValue = value; } }

        [DataMember]
        public string FieldName { get { return _fieldName; } set { _fieldName = value; } }
    }

    [DataContract]
    public class PostSignOptionsWrapper
    {
        int _redirectDelay;
        string _redirectUrl;

        [DataMember]
        public int RedirectDelay { get { return _redirectDelay; } set { _redirectDelay = value; } }

        [DataMember]
        public string RedirectUrl { get { return _redirectUrl; } set { _redirectUrl = value; } }
    }

    [DataContract]
    public class AgreementCreationResponseWrapper
    {
        DateTime _expiration;
        string _agreementId;
        string _embeddedCode;
        string _url;

        [DataMember]
        public DateTime Expiration { get { return _expiration; } set { _expiration = value; } }

        [DataMember]
        public string AgreementId { get { return _agreementId; } set { _agreementId = value; } }

        [DataMember]
        public string EmbeddedCode { get { return _embeddedCode; } set { _embeddedCode = value; } }

        [DataMember]
        public string Url { get { return _url; } set { _url = value; } }
    }

    [DataContract]
    public class MegaSignChildAgreementsWrapper
    {
        List<MegaSignChildAgreementWrapper> _megaSignChildAgreementList; //A array of MegaSign child agreements

        [DataMember]
        public List<MegaSignChildAgreementWrapper> MegaSignChildAgreementList
        {
            get { return _megaSignChildAgreementList; }
            set { _megaSignChildAgreementList = value; }
        }
    }

    [DataContract]
    public class MegaSignChildAgreementWrapper
    {
        DateTime _displayDate; // The display date for the agreement,
        UserDocumentStatus _status; //The current status of the agreement from the user's perspective,
        string _name; //Name of the Agreement,
        string _agreementId; // The unique identifier of the agreement,
        bool _esign; // True if this is an eSign document

        [DataMember]
        public DateTime DisplayDate { get { return _displayDate; } set { _displayDate = value; } }

        [DataMember]
        public UserDocumentStatus Status { get { return _status; } set { _status = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public string AgreementId { get { return _agreementId; } set { _agreementId = value; } }

        [DataMember]
        public bool Esign { get { return _esign; } set { _esign = value; } }
    }

    [DataContract]
    public class AgreementInfoWrapper
    {
        string _message;
        List<DocSecurityOption> _securityOptions;
        AgreementStatus _status;
        bool _modifiable;
        DateTime _expiration;
        List<DocumentHistoryEventWrapper> _events;
        List<ParticipantSetInfoWrapper> _participantSetInfos;
        string _name;
        string _locale;
        string _agreementId;
        List<NextparticipantsetinfoWrapper> _nextParticipantSetInfos;

        [DataMember]
        public string Message { get { return _message; } set { _message = value; } }

        [DataMember]
        public List<DocSecurityOption> SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public AgreementStatus Status { get { return _status; } set { _status = value; } }

        [DataMember]
        public bool Modifiable { get { return _modifiable; } set { _modifiable = value; } }

        [DataMember]
        public DateTime Expiration { get { return _expiration; } set { _expiration = value; } }


        [DataMember]
        public List<DocumentHistoryEventWrapper> Events { get { return _events; } set { _events = value; } }

        [DataMember]
        public List<ParticipantSetInfoWrapper> ParticipantSetInfos { get { return _participantSetInfos; } set { _participantSetInfos = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public string Locale { get { return _locale; } set { _locale = value; } }

        [DataMember]
        public string AgreementId { get { return _agreementId; } set { _agreementId = value; } }

        [DataMember]
        public List<NextparticipantsetinfoWrapper> NextParticipantSetInfos { get { return _nextParticipantSetInfos; } set { _nextParticipantSetInfos = value; } }
    }

    [DataContract]
    public class DocumentHistoryEventWrapper
    {
        string _vaultEventId; //The identifier assigned by the vault provider for the vault event (if vaulted, otherwise null),
        string _participantEmail; //Email address of the user that initiated the event,
        string _synchronizationId; // A unique identifier linking offline events to synchronization events (specified for offline signing events and synchronization events, else null),
        string _description; //A description of the audit event,
        string _versionId; //An ID which uniquely identifies the version of the document associated with this audit event,
        AgreementEventType _type; //Type of the document event,
        DateTime _date; //The date of the audit event,
        string _comment; //The event comment. For RECALLED or REJECTED, the reason given by the user that initiates the event. For DELEGATE or SHARE, the message from the acting user to the participant,
        string _actingUserIpAddress; //The IP address of the user that initiated the event,
        DeviceLocationWrapper _deviceLocation; //Location of the device that created the event (This value may be null due to limited privileges),
        string _actingUserEmail; // Email address of the user that initiated the event

        [DataMember]
        public string VaultEventId { get { return _vaultEventId; } set { _vaultEventId = value; } }

        [DataMember]
        public string ParticipantEmail { get { return _participantEmail; } set { _participantEmail = value; } }

        [DataMember]
        public string SynchronizationId { get { return _synchronizationId; } set { _synchronizationId = value; } }

        [DataMember]
        public string Description { get { return _description; } set { _description = value; } }

        [DataMember]
        public string VersionId { get { return _versionId; } set { _versionId = value; } }

        [DataMember]
        public AgreementEventType Type { get { return _type; } set { _type = value; } }

        [DataMember]
        public DateTime Date { get { return _date; } set { _date = value; } }

        [DataMember]
        public string Comment { get { return _comment; } set { _comment = value; } }

        [DataMember]
        public string ActingUserIpAddress { get { return _actingUserIpAddress; } set { _actingUserIpAddress = value; } }

        [DataMember]
        public DeviceLocationWrapper DeviceLocation { get { return _deviceLocation; } set { _deviceLocation = value; } }

        [DataMember]
        public string ActingUserEmail { get { return _actingUserEmail; } set { _actingUserEmail = value; } }
    }

    [DataContract]
    public class DeviceLocationWrapper
    {
        int _longitude; // Longitude coordinate, 
        int _latitude; // Latitude coordinate

        [DataMember]
        public int Longitude { get { return _longitude; } set { _longitude = value; } }

        [DataMember]
        public int Latitude { get { return _latitude; } set { _latitude = value; } }
    }

    [DataContract]
    public class ParticipantSetInfoWrapper
    {
        ParticipantSecurityOption[] _securityOptions; // Security options that apply to the participant,
        UserAgreementStatus _status; // The participant set's status with respect to the widget,
        ParticipantRole[] _roles; // The current roles of the participant set. A participant set can have one or more roles,
        List<ParticipantInfoWrapper> _participantSetMemberInfos; //  Information about the members of the recipient set,
        int _signingOrder; //Index indicating sequential signing group (specified for hybrid routing)

        [DataMember]
        public ParticipantSecurityOption[] SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public UserAgreementStatus Status { get { return _status; } set { _status = value; } }

        [DataMember]
        public ParticipantRole[] Roles { get { return _roles; } set { _roles = value; } }

        [DataMember]
        public List<ParticipantInfoWrapper> ParticipantSetMemberInfos { get { return _participantSetMemberInfos; } set { _participantSetMemberInfos = value; } }

        [DataMember]
        public int SigningOrder { get { return _signingOrder; } set { _signingOrder = value; } }
    }

    [DataContract]
    public class ParticipantInfoWrapper
    {
        ParticipantSetInfoWrapper _alternateParticipants;
        string _company;
        string _email;
        string _name;
        List<ParticipantSecurityOption> _securityOptions;
        string _title;

        [DataMember]
        public ParticipantSetInfoWrapper AlternateParticipants { get { return _alternateParticipants; } set { _alternateParticipants = value; } }

        [DataMember]
        public string Company { get { return _company; } set { _company = value; } }

        [DataMember]
        public string Email { get { return _email; } set { _email = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public List<ParticipantSecurityOption> SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public string Title { get { return _title; } set { _title = value; } }
    }

    [DataContract]
    public class NextparticipantsetinfoWrapper
    {
        List<NextparticipantsetmemberinfoWrapper> _nextParticipantSetMemberInfos;

        [DataMember]
        public List<NextparticipantsetmemberinfoWrapper> NextParticipantSetMemberInfos
        {
            get { return _nextParticipantSetMemberInfos; }
            set { _nextParticipantSetMemberInfos = value; }
        }
    }

    [DataContract]
    public class NextparticipantsetmemberinfoWrapper
    {
        DateTime _waitingSince;
        string _email;
        string _name;

        [DataMember]
        public DateTime WaitingSince { get { return _waitingSince; } set { _waitingSince = value; } }

        [DataMember]
        public string Email { get { return _email; } set { _email = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }
    }

    [DataContract]
    public class SigningUrlResponseWrapper
    {
        string _message;
        string _code;
        List<SigningUrlSetInfoWrapper> _signingUrlSetInfos; // An array of urls for signer sets involved in this agreement.

        [DataMember]
        public string Message { get { return _message; } set { _message = value; } }

        [DataMember]
        public string Code { get { return _code; } set { _code = value; } }

        [DataMember]
        public List<SigningUrlSetInfoWrapper> SigningUrlSetInfos
        {
            get { return _signingUrlSetInfos; }
            set { _signingUrlSetInfos = value; }
        }
    }

    [DataContract]
    public class SigningUrlSetInfoWrapper
    {
        List<SigningUrlWrapper> _signingUrls; //An array of urls for current signer set.

        [DataMember]
        public List<SigningUrlWrapper> SigningUrls
        {
            get { return _signingUrls; }
            set { _signingUrls = value; }
        }
    }

    [DataContract]
    public class SigningUrlWrapper
    {
        string _email; // The email address of the signer associated with this signing url,
        string _esignUrl; // The email address of the signer associated with this signing url

        [DataMember]
        public string Email { get { return _email; } set { _email = value; } }

        [DataMember]
        public string EsignUrl { get { return _esignUrl; } set { _esignUrl = value; } }
    }

    [DataContract]    
    public class AgreementCreationInfoWrapper
    {
        DocumentcreationinfoWrapper _documentCreationInfo; //Information about the document you want to send,
        InteractiveOptionsWrapper _options; //Options for authoring and sending the agreement

        [DataMember]
        public DocumentcreationinfoWrapper DocumentCreationInfo { get { return _documentCreationInfo; } set { _documentCreationInfo = value; } }

        [DataMember]
        public InteractiveOptionsWrapper Options { get { return _options; } set { _options = value; } }
    }

    [DataContract]
    public class DocumentcreationinfoWrapper
    {
        string _signatureType; //Specifies the type of signature you would like to request - written or eSignature. The possible values are ESIGN or WRITTEN,
        List<FileInfoWrapper> _formFieldLayerTemplates; //Specifies the form field layer template or source of form fields to apply on the files in this transaction. If specified, the FileInfo for this parameter must refer to a form field layer template via libraryDocumentId or libraryDocumentName, or if specified via transientDocumentId or documentURL, it must be of a supported file type. Note: Only one of the four parameters in every FileInfo object must be specified,
        SecurityOptionWrapper _securityOptions; //Sets Set "string.Empty" if want to use default secondary security parameters for your document,
        string _callbackInfo; //A publicly accessible url to which Adobe Document Cloud will do an HTTP GET operation every time there is a new agreement event. HTTP authentication is supported using standard embedded syntax - i.e. http://username:password@your.server.com/path/to/file. Adobe Document Cloud can also ping your system using HTTP PUT with the final signed PDF. Please contact support@echosign.com if you wish to use this option.,
        int _daysUntilSigningDeadline; //The number of days that remain before the document expires. You cannot sign the document after it expires,
        string _locale; //he locale associated with this agreement - specifies the language for the signing page and emails, for example en_US or fr_FR. If none specified, defaults to the language configured for the agreement sender,
        List<RecipientSetInfoWrapper> _recipientSetInfos; // A list of one or more recipient sets. A recipient set may have one or more recipients. If any member of the recipient set signs, the agreement is considered signed by the recipient set. For regular (non-MegaSign) documents, there is no limit on the number of electronic signatures in a single document. Written signatures are limited to four per document. This limit includes the sender if the sender's signature is also required,
        List<string> _ccs; //A list of one or more email addresses that you want to copy on this transaction. The email addresses will each receive an email at the beginning of the transaction and also when the final document is signed. The email addresses will also receive a copy of the document, attached as a PDF file,
        ExternalIdWrapper _externalId; //A unique identifier for your transaction from an external system. You can use the ExternalID to search for your transaction through API,
        VaultingInfoWrapper _vaultingInfo;//Sets the vaulting properties that allows Adobe Document Cloud to securely store documents with a vault provider,
        string _signatureFlow; //['SENDER_SIGNATURE_NOT_REQUIRED' or 'SENDER_SIGNS_LAST' or 'SENDER_SIGNS_FIRST' or 'SEQUENTIAL' or 'PARALLEL']: Selects the workflow you would like to use - whether the sender needs to sign before the recipient, after the recipient, or not at all. The possible values for this variable are SENDER_SIGNATURE_NOT_REQUIRED, SENDER_SIGNS_LAST, SENDER_SIGNS_FIRST, SEQUENTIAL or PARALLEL. Note: leave unspecified for hybrid routing,
        List<RequestFormFieldWrapper> _formFields; //Information of form fields of an agreement. PDF_SIGNATURE inputType field is currently not supported,
        string _message; //An Set "string.Empty" if want to use default message to the recipients, describing what is being sent or why their signature is required,
        List<MergefieldInfoWrapper> _mergeFieldInfo; //Set "string.Empty" if want to use default default values for fields to merge into the document. The values will be presented to the signers for editable fields; for read-only fields the provided values will not be editable during the signing process. Merging data into fields is currently not supported when used with libraryDocumentId or libraryDocumentName. Only file and url are curently supported,
        List<FileInfoWrapper> _fileInfos; //A list of one or more files (or references to files) that will be sent out for signature. If more than one file is provided, they will be combined into one PDF before being sent out. Note: Only one of the four parameters in every FileInfo object must be specified,
        string _reminderFrequency;//['DAILY_UNTIL_SIGNED' or 'WEEKLY_UNTIL_SIGNED']: Set "string.Empty" if want to use default parameter that sets how often you want to send reminders to the recipients. The possible values are DAILY_UNTIL_SIGNED or WEEKLY_UNTIL_SIGNED,
        PostSignOptionsWrapper _postSignOptions; //URL and associated properties for the success page the user will be taken to after completing the signing process,
        string _name; //The name of the agreement that will be used to identify it, in emails and on the website

        [DataMember]
        public string SignatureType { get { return _signatureType; } set { _signatureType = value; } }

        [DataMember]
        public List<FileInfoWrapper> FormFieldLayerTemplates { get { return _formFieldLayerTemplates; } set { _formFieldLayerTemplates = value; } }

        [DataMember]
        public SecurityOptionWrapper SecurityOptions { get { return _securityOptions; } set { _securityOptions = value; } }

        [DataMember]
        public string CallbackInfo { get { return _callbackInfo; } set { _callbackInfo = value; } }

        [DataMember]
        public int DaysUntilSigningDeadline { get { return _daysUntilSigningDeadline; } set { _daysUntilSigningDeadline = value; } }

        [DataMember]
        public string Locale { get { return _locale; } set { _locale = value; } }

        [DataMember]
        public List<RecipientSetInfoWrapper> RecipientSetInfos { get { return _recipientSetInfos; } set { _recipientSetInfos = value; } }

        [DataMember]
        public List<string> Ccs { get { return _ccs; } set { _ccs = value; } }

        [DataMember]
        public ExternalIdWrapper ExternalId { get { return _externalId; } set { _externalId = value; } }

        [DataMember]
        public VaultingInfoWrapper VaultingInfo { get { return _vaultingInfo; } set { _vaultingInfo = value; } }

        [DataMember]
        public string SignatureFlow { get { return _signatureFlow; } set { _signatureFlow = value; } }

        [DataMember]
        public List<RequestFormFieldWrapper> FormFields { get { return _formFields; } set { _formFields = value; } }

        [DataMember]
        public string Message { get { return _message; } set { _message = value; } }

        [DataMember]
        public List<MergefieldInfoWrapper> MergeFieldInfo { get { return _mergeFieldInfo; } set { _mergeFieldInfo = value; } }

        [DataMember]
        public List<FileInfoWrapper> FileInfos { get { return _fileInfos; } set { _fileInfos = value; } }

        [DataMember]
        public string ReminderFrequency { get { return _reminderFrequency; } set { _reminderFrequency = value; } }

        [DataMember]
        public PostSignOptionsWrapper PostSignOptions { get { return _postSignOptions; } set { _postSignOptions = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }
    }

    [DataContract]
    public class RequestFormFieldWrapper
    {
        string _alignment;
        string _borderStyle;
        string _fontColor;
        string _fontName;
        string _borderColor;
        string _displayLabel;
        string _radioCheckType;
        string _calculatedExpression;
        string _backgroundColor;
        string _formatData;
        int _recipientIndex;
        string _displayFormat;
        string _contentType;
        int _maxLength;
        List<FormFieldLocationWrapper> _locations;
        int _minLength;
        string _name;
        string _inputType;
        string _specialFormula;
        bool _required;
        string _defaultValue;
        int _minNumberValue;
        int _maxNumberValue;
        string _regularExpression;
        string _maskingText;
        string _showOrHide;
        string _specialErrMsg;
        string _format;
        string _fontSize;
        bool _masked;
        string _displayFormatType;
        string _anyOrAll;
        List<FormFieldConditionWrapper> _conditions;
        bool _readOnly;
        string _borderWidth;
        bool _hidden;
        List<string> _visibleOptions;
        List<string> _hiddenOptions;
        string _tooltip;

        [DataMember]
        public string Alignment { get { return _alignment; } set { _alignment = value; } }

        [DataMember]
        public string BorderStyle { get { return _borderStyle; } set { _borderStyle = value; } }

        [DataMember]
        public string FontColor { get { return _fontColor; } set { _fontColor = value; } }

        [DataMember]
        public string FontName { get { return _fontName; } set { _fontName = value; } }

        [DataMember]
        public string BorderColor { get { return _borderColor; } set { _borderColor = value; } }

        [DataMember]
        public string DisplayLabel { get { return _displayLabel; } set { _displayLabel = value; } }

        [DataMember]
        public string RadioCheckType { get { return _radioCheckType; } set { _radioCheckType = value; } }

        [DataMember]
        public string CalculatedExpression { get { return _calculatedExpression; } set { _calculatedExpression = value; } }

        [DataMember]
        public string BackgroundColor { get { return _backgroundColor; } set { _backgroundColor = value; } }

        [DataMember]
        public string FormatData { get { return _formatData; } set { _formatData = value; } }

        [DataMember]
        public int RecipientIndex { get { return _recipientIndex; } set { _recipientIndex = value; } }

        [DataMember]
        public string DisplayFormat { get { return _displayFormat; } set { _displayFormat = value; } }

        [DataMember]
        public string ContentType { get { return _contentType; } set { _contentType = value; } }

        [DataMember]
        public int MaxLength { get { return _maxLength; } set { _maxLength = value; } }

        [DataMember]
        public List<FormFieldLocationWrapper> Locations { get { return _locations; } set { _locations = value; } }

        [DataMember]
        public int MinLength { get { return _minLength; } set { _minLength = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public string InputType { get { return _inputType; } set { _inputType = value; } }

        [DataMember]
        public string SpecialFormula { get { return _specialFormula; } set { _specialFormula = value; } }

        [DataMember]
        public bool Required { get { return _required; } set { _required = value; } }

        [DataMember]
        public string DefaultValue { get { return _defaultValue; } set { _defaultValue = value; } }

        [DataMember]
        public int MinNumberValue { get { return _minNumberValue; } set { _minNumberValue = value; } }

        [DataMember]
        public int MaxNumberValue { get { return _maxNumberValue; } set { _maxNumberValue = value; } }

        [DataMember]
        public string RegularExpression { get { return _regularExpression; } set { _regularExpression = value; } }

        [DataMember]
        public string MaskingText { get { return _maskingText; } set { _maskingText = value; } }

        [DataMember]
        public string ShowOrHide { get { return _showOrHide; } set { _showOrHide = value; } }

        [DataMember]
        public string SpecialErrMsg { get { return _specialErrMsg; } set { _specialErrMsg = value; } }

        [DataMember]
        public string Format { get { return _format; } set { _format = value; } }

        [DataMember]
        public string FontSize { get { return _fontSize; } set { _fontSize = value; } }

        [DataMember]
        public bool Masked { get { return _masked; } set { _masked = value; } }

        [DataMember]
        public string DisplayFormatType { get { return _displayFormatType; } set { _displayFormatType = value; } }

        [DataMember]
        public string AnyOrAll { get { return _anyOrAll; } set { _anyOrAll = value; } }

        [DataMember]
        public List<FormFieldConditionWrapper> Conditions { get { return _conditions; } set { _conditions = value; } }

        [DataMember]
        public bool ReadOnly { get { return _readOnly; } set { _readOnly = value; } }

        [DataMember]
        public string BorderWidth { get { return _borderWidth; } set { _borderWidth = value; } }

        [DataMember]
        public bool Hidden { get { return _hidden; } set { _hidden = value; } }

        [DataMember]
        public List<string> VisibleOptions { get { return _visibleOptions; } set { _visibleOptions = value; } }

        [DataMember]
        public List<string> HiddenOptions { get { return _hiddenOptions; } set { _hiddenOptions = value; } }

        [DataMember]
        public string Tooltip { get { return _tooltip; } set { _tooltip = value; } }
    }

    [DataContract]
    public class FormFieldLocationWrapper
    {
        Double _height;
        Double _width;
        int _pageNumber;
        Double _left;
        Double _top;

        [DataMember]
        public Double Height { get { return _height; } set { _height = value; } }

        [DataMember]
        public Double Width { get { return _width; } set { _width = value; } }

        [DataMember]
        public int PageNumber { get { return _pageNumber; } set { _pageNumber = value; } }

        [DataMember]
        public Double Left { get { return _left; } set { _left = value; } }

        [DataMember]
        public Double Top { get { return _top; } set { _top = value; } }
    }

    [DataContract]
    public class FormFieldConditionWrapper
    {
        string _value;
        int _whenFieldLocationIndex;
        string _whenFieldName;

        [DataMember]
        public string Value { get { return _value; } set { _value = value; } }

        [DataMember]
        public int WhenFieldLocationIndex { get { return _whenFieldLocationIndex; } set { _whenFieldLocationIndex = value; } }

        [DataMember]
        public string WhenFieldName { get { return _whenFieldName; } set { _whenFieldName = value; } }
    }

    [DataContract]
    public class InteractiveOptionsWrapper
    {
        bool _noChrome;
        SendThroughWebOptionsWrapper _sendThroughWebOptions;
        bool _sendThroughWeb;
        string _locale;
        bool _authoringRequested;
        bool _autoLoginUser;

        [DataMember]
        public bool NoChrome { get { return _noChrome; } set { _noChrome = value; } }

        [DataMember]
        public SendThroughWebOptionsWrapper SendThroughWebOptions { get { return _sendThroughWebOptions; } set { _sendThroughWebOptions = value; } }

        [DataMember]
        public bool SendThroughWeb { get { return _sendThroughWeb; } set { _sendThroughWeb = value; } }

        [DataMember]
        public string Locale { get { return _locale; } set { _locale = value; } }

        [DataMember]
        public bool AuthoringRequested { get { return _authoringRequested; } set { _authoringRequested = value; } }

        [DataMember]
        public bool AutoLoginUser { get { return _autoLoginUser; } set { _autoLoginUser = value; } }
    }

    [DataContract]
    public class SendThroughWebOptionsWrapper
    {
        FileUploadOptionsWrapper _fileUploadOptions;

        [DataMember]
        public FileUploadOptionsWrapper FileUploadOptions { get { return _fileUploadOptions; } set { _fileUploadOptions = value; } }
    }

    [DataContract]
    public class FileUploadOptionsWrapper
    {
        bool _webConnectors;
        bool _libraryDocument;
        bool _localFile;

        [DataMember]
        public bool WebConnectors { get { return _webConnectors; } set { _webConnectors = value; } }

        [DataMember]
        public bool LibraryDocument { get { return _libraryDocument; } set { _libraryDocument = value; } }

        [DataMember]
        public bool LocalFile { get { return _localFile; } set { _localFile = value; } }
    }

    [DataContract]
    public class AgreementsWrapper
    {
        List<UseragreementlistWrapper> _userAgreementList;

        [DataMember]
        public List<UseragreementlistWrapper> UserAgreementList { get { return _userAgreementList; } set { _userAgreementList = value; } }
    }

    [DataContract]
    public class UseragreementlistWrapper
    {
        DateTime _displayDate;
        UserDocumentStatus _status;
        string _name;
        List<DisplayusersetinfoWrapper> _displayUserSetInfos;
        string _agreementId;
        bool _esign;
        string _latestVersionId;

        [DataMember]
        public DateTime DisplayDate { get { return _displayDate; } set { _displayDate = value; } }

        [DataMember]
        public UserDocumentStatus Status { get { return _status; } set { _status = value; } }

        [DataMember]
        public string Name { get { return _name; } set { _name = value; } }

        [DataMember]
        public List<DisplayusersetinfoWrapper> DisplayUserSetInfos { get { return _displayUserSetInfos; } set { _displayUserSetInfos = value; } }

        [DataMember]
        public string AgreementId { get { return _agreementId; } set { _agreementId = value; } }

        [DataMember]
        public bool Esign { get { return _esign; } set { _esign = value; } }

        [DataMember]
        public string LatestVersionId { get { return _latestVersionId; } set { _latestVersionId = value; } }
    }

    [DataContract]
    public class DisplayusersetinfoWrapper
    {
        List<DisplayusersetmemberinfoWrapper> _displayUserSetMemberInfos;

        [DataMember]
        public List<DisplayusersetmemberinfoWrapper> DisplayUserSetMemberInfos { get { return _displayUserSetMemberInfos; } set { _displayUserSetMemberInfos = value; } }
    }

    [DataContract]
    public class DisplayusersetmemberinfoWrapper
    {
        string _email;
        string _company;
        string _fullName;

        [DataMember]
        public string Email { get { return _email; } set { _email = value; } }

        [DataMember]
        public string Company { get { return _company; } set { _company = value; } }

        [DataMember]
        public string FullName { get { return _fullName; } set { _fullName = value; } }
    }
}
