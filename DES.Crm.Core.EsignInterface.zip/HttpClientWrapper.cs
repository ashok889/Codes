﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Configuration;

namespace DES.Crm.Core.EsignInterface
{
    public static class HttpClientWrapper
    {
        public static HttpClient GetAdobeHttpClient(string triggeringUserEmailAddress, string integrationKey)
        {
            HttpClient rtnClient = null;
            var proxyServer = string.Empty;
            var proxyServerPort = 80;
            var baseUrl = string.Empty;
            var accessToken = string.Empty;
            var decryptedAccessToken = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(integrationKey))
                {
                    /*
                    //integrationKey format: proxyserver=FM-EU-LON-PROXY.fm.rbsgrp.net;proxyserverport=80;apiurlbase=https://api.na1.echosign.com:443/api/rest/v5;accesstoken=3AAABLblqZhDnupq-mUJNVNyTTRu8fm-AD7LOM8JmsMxHaYgwdPmPMYdEYD_V_8WwmlFM8b_ojhLorxEaxVFGR4JLvtHL3Pmp
                    string[] pairs = integrationKey.Split(';');
                    var results = new Dictionary<string, string>();
                    foreach (string pair in pairs)
                    {
                        string[] paramvalue = pair.Split('=');
                        results.Add(paramvalue[0], paramvalue[1]);
                    }
                     */

                    //integrationKey format: FM-EU-LON-PROXY.fm.rbsgrp.net;80;https://api.na1.echosign.com:443/api/rest/v5;3AAABLblqZhDnupq-mUJNVNyTTRu8fm-AD7LOM8JmsMxHaYgwdPmPMYdEYD_V_8WwmlFM8b_ojhLorxEaxVFGR4JLvtHL3Pmp
                    string[] values = integrationKey.Split(';');

                    var results = new Dictionary<string, string>();
                    results.Add("proxyserver", values[0]);
                    results.Add("proxyserverport", values[1]);
                    results.Add("apiurlbase", values[2]);
                    results.Add("encryptedaccesstoken", values[3]);

                    proxyServer = results["proxyserver"];
                    proxyServerPort = Convert.ToInt32(results["proxyserverport"]);
                    baseUrl = results["apiurlbase"];
                    accessToken = results["encryptedaccesstoken"];
                }
                else
                {
                    proxyServer = ConfigurationManager.AppSettings["proxyserver"];
                    proxyServerPort = Convert.ToInt32(ConfigurationManager.AppSettings["proxyserverport"]);
                    baseUrl = ConfigurationManager.AppSettings["apiurlbase"];
                    accessToken = ConfigurationManager.AppSettings["encryptedaccesstoken"];
                }

                //Decrypt the Access Token before sending it to Adobe for hand shaking.
                EncryptDecrypt.EncryptDecrypt ed = new EncryptDecrypt.EncryptDecrypt();
                decryptedAccessToken = ed.DecryptString(accessToken.ToString().Trim());

                if (CredentialCache.DefaultCredentials != null)
                {
                    triggeringUserEmailAddress = "email:" + triggeringUserEmailAddress;

                    var proxy = new WebProxy(proxyServer, proxyServerPort)
                    {
                        Credentials = CredentialCache.DefaultCredentials
                    };
                    //new NetworkCredential{Domain = "FM",UserName="<racfid>",Password="<pwd>"}  

                    var handler = new HttpClientHandler { Proxy = proxy };
                    rtnClient = new HttpClient(handler) { BaseAddress = new Uri(baseUrl) };
                    rtnClient.DefaultRequestHeaders.Add("Access-Token", decryptedAccessToken);
                    rtnClient.DefaultRequestHeaders.Add("x-api-user", triggeringUserEmailAddress);
                }

                return rtnClient;
            }
            catch (Exception exp)
            {
                throw new Exception(string.Format("integrationKey:{0};\nproxyServer:{1};proxyServerPort:{2};baseUrl:{3};accessToken:{4};triggeringUserEmailAddress:{5}.", integrationKey, proxyServer, proxyServerPort, baseUrl, accessToken, triggeringUserEmailAddress), exp);
            }
        }        
    }
}
