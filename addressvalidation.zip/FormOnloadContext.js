function form_onload(executionContext) {
		var formContext = executionContext.getFormContext();
		var wrControl = formContext.getControl("WebResource_MyWebResource");
		if (wrControl) {
		wrControl.getContentWindow().then(
		function (contentWindow) {
		contentWindow.setClientApiContext(Xrm, formContext);
			}
		)
	}
}
