var WebResource_PersonAddressSearch = "WebResource_AddressSearch";

PassExecutionContext = function (executionContext) {
    "use strict";
    if (!executionContext) {
        return false;
    }
	
   var formContext = executionContext.getFormContext();
   
    const myTimeout = setTimeout(function () {
        clearTimeout(myTimeout);
        var wrControl = formContext.getControl(WebResource_PersonAddressSearch);
        if (wrControl) {
            wrControl.getContentWindow().then(
                function (contentWindow) {
                    console.log("Log Content Window");
                    console.log(contentWindow);
                    console.log(contentWindow.setClientApiContext);
                    contentWindow.setClientApiContext(Xrm, formContext);
                }
            )
        }
    }, 3000);
};


OnLoadAddressSearch = function (executionContext) {
    "use strict";   
      PassExecutionContext(executionContext);
}


