﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DES.CRM.Core.EnvironmentParameter
{
    public class Common
    {
        public static decimal ParseDecimal(string value)
        {
            decimal result;
            if (value != string.Empty)
            {
                if (decimal.TryParse(value, out result))
                    return result;
            }

            return Decimal.Zero;
        }

        public static int ParseInt(string value)
        {
            int result;
            if (value != string.Empty)
            {
                if (int.TryParse(value, out result))
                    return result;
            }
            return 0;
        }

        public static async Task<string> CallAzureFunction(string aipUrl, string content, HttpClient httpClient)
        {
            var body = new StringContent(content);

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string outputContent = null;
            var result = await httpClient.PostAsync(aipUrl, body);
            if (result.Content != null)
            {
                outputContent = await result.Content.ReadAsStringAsync();
            }
            return outputContent;
        }
    }
}
