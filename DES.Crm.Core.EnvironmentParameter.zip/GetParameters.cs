﻿using System;
using System.Activities;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;


namespace DES.CRM.Core.EnvironmentParameter
{
    public class GetParameters : WorkFlowActivityBase
    {

        [Output("Parameter")]
        [ReferenceTarget("nwg_environmentparameter")]
        public OutArgument<EntityReference> ConfigurationRecord { get; set; }

        public override void ExecuteCRMWorkFlowActivity(CodeActivityContext context, LocalWorkflowContext crmWorkflowContext)
        {
            // --
            if (crmWorkflowContext == null)
            {
                throw new ArgumentNullException("crmWorkflowContext");
            }

            var service = crmWorkflowContext.OrganizationService;
            var tracing = crmWorkflowContext.TracingService;

            var serviceContext = new CrmServiceContext(service);

            var configuration = (from config in serviceContext.nwg_environmentparameterSet
                                 where config.nwg_name == "Parameters"
                                 select config).SingleOrDefault();

            if (configuration == null)
            {
                throw new InvalidPluginExecutionException("Can't find an Environment Parameter record named 'Parameters'. Please create one and name it 'Parameters'.");
            }

            ConfigurationRecord.Set(context, configuration.ToEntityReference());
        }
    }
}
