﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace Rbs.Crm.EDB.Workflow
{
    public interface IRbsJsonSerializer
    {
        string Serialize<TEntity>(TEntity entity) where TEntity : class, new();
        TEntity Deserialize<TEntity>(string entity) where TEntity : class, new();
    }

    public class RbsJsonSerializer : IRbsJsonSerializer
    {
        private ITracingService _tracingService;
        public RbsJsonSerializer(ITracingService tracingService)
        {
            _tracingService = tracingService;
        }

        public string Serialize<TEntity>(TEntity entity) where TEntity : class, new()
        {
            _tracingService.Trace("Getting MemoryStream...");
            using (MemoryStream stream = new MemoryStream())
            {
                _tracingService.Trace("Get Serialize Object...");
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(TEntity));
                _tracingService.Trace("Write Serialize Object...");
                serializer.WriteObject(stream, entity);
                _tracingService.Trace("return serialize string");
                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        public TEntity Deserialize<TEntity>(string entity) where TEntity : class, new()
        {
            _tracingService.Trace("Get (De)Serialize Object...");
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(TEntity));
            _tracingService.Trace("Getting MemoryStream...");
            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(entity)))
            {
                _tracingService.Trace("return deserialized object");
                return serializer.ReadObject(stream) as TEntity;
            }
        }
    }
}
