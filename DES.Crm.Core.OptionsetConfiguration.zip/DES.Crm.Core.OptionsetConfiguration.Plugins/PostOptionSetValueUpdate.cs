﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace DES.Crm.Core.OpConfig.Plugins
{
    public class PostOptionSetValueUpdate : Plugin
    {
        private readonly string preImageAlias = "PreImage";

        public PostOptionSetValueUpdate()
            : base(typeof(PostOptionSetValueUpdate))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(40, "Update", "rbs_optionsetvalue", new Action<LocalPluginContext>(ExecutePostOptionSetValueUpdate)));

            // Note : you can register for more events here if this plugin is not specific to an individual entity and message combination.
            // You may also need to update your RegisterFile.crmregister plug-in registration file to reflect any change.
        }

        protected void ExecutePostOptionSetValueUpdate(LocalPluginContext localContext)
        {
            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("localContext");
            }

            var context = localContext.PluginExecutionContext;
            var service = localContext.OrganizationService;
            var tracingService = localContext.TracingService;

            if (context != null && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var target = (Entity)context.InputParameters["Target"];
                if (target.LogicalName == "rbs_optionsetvalue")
                {
                    if (target.Attributes.Contains("rbs_name"))
                    {
                        int optionValue;

                        Entity preImageEntity = (context.PreEntityImages != null && context.PreEntityImages.Contains(this.preImageAlias)) ? context.PreEntityImages[this.preImageAlias] : null;

                        if (preImageEntity.Attributes.Contains("rbs_optionset"))
                        {
                            EntityReference enRefOptionSet = (EntityReference)preImageEntity.Attributes["rbs_optionset"];

                            Entity enOptionSet = service.Retrieve(enRefOptionSet.LogicalName, enRefOptionSet.Id, new ColumnSet("rbs_isglobal", "rbs_name", "rbs_entityname"));

                            bool isGlobal = (bool)enOptionSet.Attributes["rbs_isglobal"];
                            string optionSetLogicalName = enOptionSet.Attributes["rbs_name"].ToString();
                            string entityName = enOptionSet.Attributes.Contains("rbs_entityname") && enOptionSet.Attributes["rbs_entityname"] != null ? enOptionSet.Attributes["rbs_entityname"].ToString() : string.Empty;

                            string preOptionLabel = preImageEntity.Attributes["rbs_name"].ToString();
                            string postOptionLabel = target.Attributes["rbs_name"].ToString();

                            switch (isGlobal)
                            {
                                case true:
                                    optionValue = GetOptionSetValueToBeUpdated(service, isGlobal, preOptionLabel, optionSetLogicalName);

                                    tracingService.Trace("Metadata Optionsetvalue retrieved: " + optionValue);

                                    if (optionValue != -1)
                                        UpdateOptionSetItem(service, tracingService, isGlobal, optionSetLogicalName, postOptionLabel, optionValue, 1033);

                                    break;

                                case false:
                                    optionValue = GetOptionSetValueToBeUpdated(service, isGlobal, preOptionLabel, optionSetLogicalName, entityName);

                                    if (optionValue != -1)
                                        UpdateOptionSetItem(service, tracingService, isGlobal, optionSetLogicalName, postOptionLabel, optionValue, 1033, entityName);

                                    break;
                            }
                        }
                    }
                }
            }
        }

        private int GetOptionSetValueToBeUpdated(IOrganizationService service, bool isGlobal, string optionLabel, string optionSetLogicalName, string entityName = null)
        {
            if (isGlobal)
            {
                RetrieveOptionSetRequest retrieveOptionSetRequest = new RetrieveOptionSetRequest { Name = optionSetLogicalName };

                RetrieveOptionSetResponse retrieveOptionSetResponse = (RetrieveOptionSetResponse)service.Execute(retrieveOptionSetRequest);
                OptionSetMetadata retrievedOptionSetMetadata = (OptionSetMetadata)retrieveOptionSetResponse.OptionSetMetadata;

                var optionSetValue = (from o in retrievedOptionSetMetadata.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).FirstOrDefault();

                if (optionSetValue != null)
                    return (int)optionSetValue.Value;
                else
                    return -1;
            }
            else
            {
                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest { EntityLogicalName = entityName, LogicalName = optionSetLogicalName, RetrieveAsIfPublished = true };

                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);
                EnumAttributeMetadata attributeMetadata = (EnumAttributeMetadata)attributeResponse.AttributeMetadata;

                var optionSetValue = (from o in attributeMetadata.OptionSet.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).FirstOrDefault();

                if (optionSetValue != null)
                    return (int)optionSetValue.Value;
                else
                    return -1;
            }
        }

        private void UpdateOptionSetItem(IOrganizationService service, ITracingService tracingService, bool isGlobal, string optionSetLogicalName, string optionLabel, int optionValue, int languageCode, string entityName = null)
        {
            var updateOptionValueRequest = new UpdateOptionValueRequest();
            updateOptionValueRequest.Label = new Label(optionLabel, languageCode);
            updateOptionValueRequest.Value = optionValue;   // CRM defaulted, if not specified

            switch (isGlobal)
            {
                case true:
                    updateOptionValueRequest.OptionSetName = optionSetLogicalName;

                    break;

                case false:
                    updateOptionValueRequest.AttributeLogicalName = optionSetLogicalName;
                    updateOptionValueRequest.EntityLogicalName = entityName;

                    break;
            }

            service.Execute(updateOptionValueRequest);

            tracingService.Trace("Option Set Value updated successfully.");
        }
    }
}
