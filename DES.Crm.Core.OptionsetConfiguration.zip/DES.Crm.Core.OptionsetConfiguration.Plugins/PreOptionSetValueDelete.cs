﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.OpConfig.Plugins
{
    public class PreOptionSetValueDelete : Plugin
    {
        private readonly string preImageAlias = "PreImage";

        public PreOptionSetValueDelete()
            : base(typeof(PreOptionSetValueDelete))
        {
            base.RegisteredEvents.Add(new Tuple<int, string, string, Action<LocalPluginContext>>(20, "Delete", "rbs_optionsetvalue", new Action<LocalPluginContext>(ExecutePreOptionSetValueDelete)));

            // Note : you can register for more events here if this plugin is not specific to an individual entity and message combination.
            // You may also need to update your RegisterFile.crmregister plug-in registration file to reflect any change.
        }

        protected void ExecutePreOptionSetValueDelete(LocalPluginContext localContext)
        {
            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("localContext");
            }

            var context = localContext.PluginExecutionContext;
            var service = localContext.OrganizationService;
            var tracingService = localContext.TracingService;

            if (context != null && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
            {
                var target = (EntityReference)context.InputParameters["Target"];
                if (target.LogicalName == "rbs_optionsetvalue")
                {
                    Entity preImageEntity = (context.PreEntityImages != null && context.PreEntityImages.Contains(this.preImageAlias)) ? context.PreEntityImages[this.preImageAlias] : null;

                    tracingService.Trace("preImageEntity.Attributes.Contains(\"rbs_name\"): " + preImageEntity.Attributes.Contains("rbs_name"));

                    tracingService.Trace("preImageEntity.Attributes.Contains(\"rbs_optionset\"): " + preImageEntity.Attributes.Contains("rbs_optionset"));

                    if (preImageEntity.Attributes.Contains("rbs_name") && preImageEntity.Attributes.Contains("rbs_optionset"))
                    {
                        int optionValue;

                        EntityReference enRefOptionSet = (EntityReference)preImageEntity.Attributes["rbs_optionset"];

                        Entity enOptionSet = service.Retrieve(enRefOptionSet.LogicalName, enRefOptionSet.Id, new ColumnSet("rbs_isglobal", "rbs_name", "rbs_entityname"));

                        bool isGlobal = (bool)enOptionSet.Attributes["rbs_isglobal"];
                        string optionSetLogicalName = enOptionSet.Attributes["rbs_name"].ToString();
                        string entityName = enOptionSet.Attributes.Contains("rbs_entityname") && enOptionSet.Attributes["rbs_entityname"] != null ? enOptionSet.Attributes["rbs_entityname"].ToString() : string.Empty;

                        string preOptionLabel = preImageEntity.Attributes["rbs_name"].ToString();

                        bool isMappedToAnyRecord = false;

                        switch (isGlobal)
                        {
                            case true:

                                optionValue = GetOptionSetValueToBeRemoved(service, isGlobal, preOptionLabel, optionSetLogicalName);
                                
                                Dictionary<string, List<string>> lstEntityAttributes = new Dictionary<string, List<string>>();

                                RetrieveOptionSetRequest retrieveOptionSetRequest = new RetrieveOptionSetRequest { Name = optionSetLogicalName };
                                RetrieveOptionSetResponse retrieveOptionSetResponse = (RetrieveOptionSetResponse)service.Execute(retrieveOptionSetRequest);
                                OptionSetMetadata retrievedOptionSetMetadata = (OptionSetMetadata)retrieveOptionSetResponse.OptionSetMetadata;

                                RetrieveDependentComponentsRequest reqDependencies = new RetrieveDependentComponentsRequest();
                                reqDependencies.ObjectId = (Guid)retrievedOptionSetMetadata.MetadataId;
                                reqDependencies.ComponentType = 9;
                                RetrieveDependentComponentsResponse resDependencies = (RetrieveDependentComponentsResponse)service.Execute(reqDependencies);

                                if(resDependencies != null && resDependencies.EntityCollection != null && resDependencies.EntityCollection.Entities != null && resDependencies.EntityCollection.Entities.Count > 0)
                                {
                                    foreach(Entity enDependency in resDependencies.EntityCollection.Entities)
                                    {
                                        RetrieveAttributeRequest reqLocalOptionSet = new RetrieveAttributeRequest();
                                        reqLocalOptionSet.MetadataId = (Guid)enDependency.Attributes["dependentcomponentobjectid"];

                                        RetrieveAttributeResponse resLocalOptionSet = (RetrieveAttributeResponse)service.Execute(reqLocalOptionSet);

                                        List<string> lst = null;

                                        if (lstEntityAttributes.Keys.Contains(resLocalOptionSet.AttributeMetadata.EntityLogicalName))
                                        {
                                            lst = lstEntityAttributes[resLocalOptionSet.AttributeMetadata.EntityLogicalName];
                                            lst.Add(resLocalOptionSet.AttributeMetadata.LogicalName);
                                            lstEntityAttributes[resLocalOptionSet.AttributeMetadata.EntityLogicalName] = lst;
                                        }
                                        else
                                        {
                                            lst = new List<string>();
                                            lst.Add(resLocalOptionSet.AttributeMetadata.LogicalName);
                                            lstEntityAttributes.Add(resLocalOptionSet.AttributeMetadata.EntityLogicalName, lst);
                                        }
                                    }
                                }

                                if (optionValue != -1)
                                    foreach (var entity in lstEntityAttributes)
                                    {
                                        foreach (var attr in entity.Value)
                                        {
                                            if (ValidateifMappedToAnyRecord(service, tracingService, attr, optionValue, entity.Key))
                                            {
                                                isMappedToAnyRecord = true;
                                                break;
                                            }
                                        }
                                    }

                                break;

                            case false:
                                optionValue = GetOptionSetValueToBeRemoved(service, isGlobal, preOptionLabel, optionSetLogicalName, entityName);

                                if (optionValue != -1)
                                    if (ValidateifMappedToAnyRecord(service, tracingService, optionSetLogicalName, optionValue, entityName))
                                        isMappedToAnyRecord = true;

                                break;
                        }

                        tracingService.Trace("isMappedToAnyRecord: " + isMappedToAnyRecord);

                        if (isMappedToAnyRecord)
                            throw new InvalidPluginExecutionException("Please note that to delete any option set value, you first need to unmap it from all related records.");
                    }
                }
            }
        }

        private bool ValidateifMappedToAnyRecord(IOrganizationService service, ITracingService tracingService, string optionSetLogicalName, int optionValue, string entityName)
        {
            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='" + entityName + @"'>
                                    <attribute name='" + entityName + "id" + @"' />
                                    <filter type='and'>
                                      <condition attribute='" + optionSetLogicalName + @"' operator='eq' value='" + optionValue + @"' />
                                      <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                  </entity>
                                </fetch>";

            EntityCollection enColl = service.RetrieveMultiple(new FetchExpression(sFetch));

            if (enColl != null && enColl.Entities != null && enColl.Entities.Count > 0)
                return true;
            else
                return false;
        }

        private int GetOptionSetValueToBeRemoved(IOrganizationService service, bool isGlobal, string optionLabel, string optionSetLogicalName, string entityName = null)
        {
            if (isGlobal)
            {
                RetrieveOptionSetRequest retrieveOptionSetRequest = new RetrieveOptionSetRequest { Name = optionSetLogicalName };

                RetrieveOptionSetResponse retrieveOptionSetResponse = (RetrieveOptionSetResponse)service.Execute(retrieveOptionSetRequest);
                OptionSetMetadata retrievedOptionSetMetadata = (OptionSetMetadata)retrieveOptionSetResponse.OptionSetMetadata;

                var optionSetValue = (from o in retrievedOptionSetMetadata.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).FirstOrDefault();

                if (optionSetValue != null)
                    return (int)optionSetValue.Value;
                else
                    return -1;
            }
            else
            {
                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest { EntityLogicalName = entityName, LogicalName = optionSetLogicalName, RetrieveAsIfPublished = true };

                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);
                EnumAttributeMetadata attributeMetadata = (EnumAttributeMetadata)attributeResponse.AttributeMetadata;

                var optionSetValue = (from o in attributeMetadata.OptionSet.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).FirstOrDefault();

                if (optionSetValue != null)
                    return (int)optionSetValue.Value;
                else
                    return -1;
            }
        }
    }
}
