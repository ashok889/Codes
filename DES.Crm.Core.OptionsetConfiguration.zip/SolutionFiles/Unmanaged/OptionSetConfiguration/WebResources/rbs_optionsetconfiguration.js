function SetNotification() {
   Xrm.Page.ui.setFormNotification("Please note that to delete any option set value, you first need to unmap it from all related records.", "INFO", "DeleteNotification");
   Xrm.Page.ui.setFormNotification("Please ensure to publish changes after making modifications.", "INFO", "PublishNotification");
}