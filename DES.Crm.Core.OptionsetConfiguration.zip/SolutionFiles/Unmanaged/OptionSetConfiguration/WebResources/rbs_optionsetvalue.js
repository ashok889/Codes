function SetNotification() {
if(Xrm.Page.ui.getFormType() == 1) {
   Xrm.Page.ui.setFormNotification("Please ensure to publish changes after making modifications!", "INFO", "PublishNotification");
}
}