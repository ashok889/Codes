﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.OpConfig.Workflows
{
    public class SyncOptionsetConfiguration : CodeActivity
    {
        /// <summary>
        /// Executes the workflow activity.
        /// </summary>
        /// <param name="executionContext">The execution context.</param>
        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            tracingService.Trace("Entered SyncOptionsetConfiguration.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}",
                executionContext.ActivityInstanceId,
                executionContext.WorkflowInstanceId);

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            tracingService.Trace("SyncOptionsetConfiguration.Execute(), Correlation Id: {0}, Initiating User: {1}",
                context.CorrelationId,
                context.InitiatingUserId);

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            EntityCollection opConfigToUpdate = new EntityCollection();
            EntityCollection opConfigToDelete = new EntityCollection();

            Dictionary<Guid, List<Guid>> opValueToCreate = new Dictionary<Guid, List<Guid>>();
            Dictionary<Guid, List<Guid>> opValueToUpdate = new Dictionary<Guid, List<Guid>>();
            Dictionary<Guid, List<Guid>> opValueToDelete = new Dictionary<Guid, List<Guid>>();

            try
            {
                opConfigToDelete = RetrieveAllOptionSetsConfiguration(service);

                opValueToDelete = RetrieveAllOptionSetsValue(service);

                #region Prepare configuration for OptionSet Configuration of Global Option Sets

                RetrieveAllOptionSetsRequest optionSets = new RetrieveAllOptionSetsRequest();

                RetrieveAllOptionSetsResponse resp = (RetrieveAllOptionSetsResponse)service.Execute(optionSets);

                IEnumerable<OptionSetMetadataBase> globalOptionSets = resp.OptionSetMetadata.Where(w => w.OptionSetType.Value == OptionSetType.Picklist && (w.IsManaged == null || !(bool)w.IsManaged));

                foreach (var optionSet in globalOptionSets)
                {
                    Guid opConfigId = Guid.Empty;

                    CreateUpdateDeleteOptionSetConfiguration(service, opConfigToDelete, optionSet.Name, optionSet.DisplayName.LocalizedLabels[0].Label, null, true, out opConfigId);

                    var values = ((OptionSetMetadata)optionSet).Options.Select(s => s.Label.LocalizedLabels[0].Label).ToList();

                    CreateUpdateDeleteOptionSetValue(service, opValueToDelete, values, opConfigId);
                }

                #endregion

                #region Prepare configuration for OptionSet Configuration of Local Option Sets

                RetrieveAllEntitiesRequest reqEntities = new RetrieveAllEntitiesRequest();

                reqEntities.EntityFilters = EntityFilters.Attributes;

                RetrieveAllEntitiesResponse resEntitites = (RetrieveAllEntitiesResponse)service.Execute(reqEntities);

                foreach (var entityMetadata in resEntitites.EntityMetadata)
                {
                    foreach (var attributeMetadata in entityMetadata.Attributes.Where(w => w.AttributeType == AttributeTypeCode.Picklist && (w.IsManaged == null || !(bool)w.IsManaged) && (((EnumAttributeMetadata)w).OptionSet.IsGlobal == null || !(bool)((EnumAttributeMetadata)w).OptionSet.IsGlobal)))
                    {
                        Guid opConfigId = Guid.Empty;

                        CreateUpdateDeleteOptionSetConfiguration(service, opConfigToDelete, attributeMetadata.LogicalName, attributeMetadata.DisplayName.LocalizedLabels[0].Label, attributeMetadata.EntityLogicalName, false, out opConfigId);

                        var values = ((EnumAttributeMetadata)attributeMetadata).OptionSet.Options.Select(s => s.Label.LocalizedLabels[0].Label).ToList();

                        CreateUpdateDeleteOptionSetValue(service, opValueToDelete, values, opConfigId);
                    }
                }

                #endregion

                foreach (var optionSet in opValueToDelete.Values)
                {
                    foreach(var optionSetValue in optionSet)
                        service.Delete("rbs_optionsetvalue", optionSetValue);
                }

                foreach (var entity in opConfigToDelete.Entities)
                {
                    service.Delete(entity.LogicalName, entity.Id);
                }                
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
                throw new InvalidPluginExecutionException(ex.Message);
            }

            tracingService.Trace("Exiting SyncOptionsetConfiguration.Execute(), Correlation Id: {0}", context.CorrelationId);
        }

        private static EntityCollection RetrieveAllOptionSetsConfiguration(IOrganizationService service)
        {
            string sFetch = @" <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='rbs_optionsetconfiguration'>
                                    <attribute name='rbs_optionsetconfigurationid' />
                                    <order attribute='rbs_name' descending='false' />
                                  </entity>
                                </fetch>";

            return service.RetrieveMultiple(new FetchExpression(sFetch));
        }

        private static Dictionary<Guid, List<Guid>> RetrieveAllOptionSetsValue(IOrganizationService service)
        {
            string sFetch = @" <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='rbs_optionsetvalue'>
                                    <attribute name='rbs_optionsetvalueid' />
                                    <attribute name='rbs_name' />
                                    <attribute name='rbs_optionset' />
                                    <order attribute='rbs_optionset' descending='false' />
                                  </entity>
                                </fetch>";

            EntityCollection enColl = service.RetrieveMultiple(new FetchExpression(sFetch));

            if (enColl != null && enColl.Entities != null && enColl.Entities.Count > 0)
            {
                return enColl.Entities.GroupBy(g => ((EntityReference)g.Attributes["rbs_optionset"]).Id).ToDictionary(d => d.Key, d => d.Select(s => s.Id).ToList());
            }
            else
                return new Dictionary<Guid, List<Guid>>();
        }

        private static Guid RetrieveOptionSetConfiguration(IOrganizationService service, string schemaName, string entityName)
        {
            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='rbs_optionsetconfiguration'>
                                    <attribute name='rbs_optionsetconfigurationid' />
                                    <order attribute='rbs_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rbs_name' operator='eq' value='" + schemaName + @"' />
                                        {0}
                                    </filter>
                                  </entity>
                                </fetch>";

            if (entityName != null)
                sFetch = string.Format(sFetch, "<condition attribute='rbs_entityname' operator='eq' value='" + entityName + @"' />");

            EntityCollection enColl = service.RetrieveMultiple(new FetchExpression(sFetch));

            if (enColl != null && enColl.Entities != null && enColl.Entities.Count > 0)
                return enColl.Entities[0].Id;
            else
                return Guid.Empty;
        }

        private static Guid RetrieveOptionSetValue(IOrganizationService service, string value, Guid opConfigId)
        {
            string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='rbs_optionsetvalue'>
                                    <attribute name='rbs_optionsetvalueid' />
                                    <order attribute='rbs_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='rbs_name' operator='eq' value='" + value.Replace("&", "&amp;").Replace("'", "&apos;").Replace("<", "&lt;").Replace(">", "&gt;") + @"' />
                                      <condition attribute='rbs_optionset' operator='eq' value='" + opConfigId.ToString() + @"' />
                                    </filter>
                                  </entity>
                                </fetch>";

            EntityCollection enColl = service.RetrieveMultiple(new FetchExpression(sFetch));

            if (enColl != null && enColl.Entities != null && enColl.Entities.Count > 0)
                return enColl.Entities[0].Id;
            else
                return Guid.Empty;
        }

        

        private static void CreateUpdateDeleteOptionSetConfiguration(IOrganizationService service, EntityCollection opConfigToDelete, string name, string displayName, string entityName, bool isGlobal, out Guid opConfigId)
        {
            Entity en = new Entity("rbs_optionsetconfiguration");
            en.Attributes["rbs_name"] = name;
            en.Attributes["rbs_displayname"] = displayName;
            en.Attributes["rbs_entityname"] = entityName;
            en.Attributes["rbs_publisher"] = name != null && name.Contains("_") ? name.Substring(0, name.IndexOf("_")) : null;
            en.Attributes["rbs_isglobal"] = isGlobal;

            Guid retrieveRecordId = RetrieveOptionSetConfiguration(service, name, entityName);

            if (retrieveRecordId == Guid.Empty)
                opConfigId = service.Create(en);
            else
            {
                en.Id = retrieveRecordId;
                opConfigId = en.Id;
                service.Update(en);

                opConfigToDelete.Entities.Remove(opConfigToDelete.Entities.Where(w => w.Id.Equals(retrieveRecordId)).FirstOrDefault());
            }
        }

        private static void CreateUpdateDeleteOptionSetValue(IOrganizationService service, Dictionary<Guid, List<Guid>> opValueToDelete, List<string> values, Guid opConfigId)
        {
            foreach (var value in values)
            {
                Entity en = new Entity("rbs_optionsetvalue");
                en.Attributes["rbs_name"] = value;
                en.Attributes["rbs_optionset"] = new EntityReference("rbs_optionsetconfiguration", opConfigId);

                Guid retrieveRecordId = RetrieveOptionSetValue(service, value, opConfigId);

                if (retrieveRecordId == Guid.Empty)
                    service.Create(en);
                else
                {
                    /*
                    en.Id = retrieveRecordId;
                    service.Update(en);
                    */

                    var valuesForOptionSet = opValueToDelete[opConfigId];

                    valuesForOptionSet.Remove(retrieveRecordId);

                    opValueToDelete.Remove(opConfigId);
                    opValueToDelete.Add(opConfigId, valuesForOptionSet);
                }
            }
        }        
    }
}
