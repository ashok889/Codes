﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.OpConfig.Workflows
{
    public class AddRemoveOptionsetValue : CodeActivity
    {
        [Input("Action Type (Add; Remove)")]
        [RequiredArgument]
        public InArgument<string> ActionType { get; set; }

        [Input("OptionSet Field Schema Name")]
        [RequiredArgument]
        public InArgument<string> FieldName { get; set; }

        [Input("Entity Schema Name")]
        [RequiredArgument]
        public InArgument<string> EntityName { get; set; }

        [Input("Value")]
        [RequiredArgument]
        public InArgument<string> Value { get; set; }

        [Input("Language Code")]
        [RequiredArgument]
        public InArgument<int> LanguageCode { get; set; }

        [Input("Publisher")]
        [RequiredArgument]
        public InArgument<string> Publisher { get; set; }

        [Input("Is Global")]
        [RequiredArgument]
        public InArgument<bool> IsGlobal { get; set; }

        /// <summary>
        /// Executes the workflow activity.
        /// </summary>
        /// <param name="executionContext">The execution context.</param>
        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            if (tracingService == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve tracing service.");
            }

            tracingService.Trace("Entered AddRemoveOptionsetValue.Execute(), Activity Instance Id: {0}, Workflow Instance Id: {1}",
                executionContext.ActivityInstanceId,
                executionContext.WorkflowInstanceId);

            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();

            if (context == null)
            {
                throw new InvalidPluginExecutionException("Failed to retrieve workflow context.");
            }

            tracingService.Trace("AddRemoveOptionsetValue.Execute(), Correlation Id: {0}, Initiating User: {1}",
                context.CorrelationId,
                context.InitiatingUserId);

            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            try
            {
                int optionValue;
                string optionSetLogicalName = FieldName.Get(executionContext);
                string optionLabel = Value.Get(executionContext);
                int languageCode = LanguageCode.Get(executionContext);
                string entityName = EntityName.Get(executionContext);
                string publisher = Publisher.Get(executionContext);
                bool isGlobal = IsGlobal.Get(executionContext);
                int optionValuePrefix = GetOptionValuePrefixBasedOnPublisher(service, publisher);

                switch (ActionType.Get(executionContext).ToUpper())
                {
                    case "ADD":
                        switch (isGlobal)
                        {
                            case true:
                                RetrieveOptionSetRequest retrieveOptionSetRequest = new RetrieveOptionSetRequest { Name = optionSetLogicalName };

                                RetrieveOptionSetResponse retrieveOptionSetResponse = (RetrieveOptionSetResponse)service.Execute(retrieveOptionSetRequest);
                                OptionSetMetadata retrievedOptionSetMetadata = (OptionSetMetadata)retrieveOptionSetResponse.OptionSetMetadata;

                                var globalOptionList = (from o in retrievedOptionSetMetadata.Options select new { Value = o.Value }).ToList().Select(s => s.Value).ToList();
                                globalOptionList = globalOptionList.OrderBy(o => o.Value).ToList();

                                if ((from o in retrievedOptionSetMetadata.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).Count() == 0)
                                {
                                    optionValue = GetOptionSetValueToBeInserted(optionValuePrefix, globalOptionList);

                                    AddOptionSetItem(service, tracingService, isGlobal, optionSetLogicalName, optionLabel, optionValue, languageCode);
                                }
                                else
                                    tracingService.Trace("Option Set Value already exists.");

                                break;

                            case false:
                                var attributeRequest = new RetrieveAttributeRequest { EntityLogicalName = entityName, LogicalName = optionSetLogicalName, RetrieveAsIfPublished = true };

                                var attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);
                                var attributeMetadata = (EnumAttributeMetadata)attributeResponse.AttributeMetadata;

                                var optionList = (from o in attributeMetadata.OptionSet.Options select new { Value = o.Value }).ToList().Select(s => s.Value).ToList();
                                optionList = optionList.OrderBy(o => o.Value).ToList();

                                if ((from o in attributeMetadata.OptionSet.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).Count() == 0)
                                {
                                    optionValue = GetOptionSetValueToBeInserted(optionValuePrefix, optionList);

                                    AddOptionSetItem(service, tracingService, isGlobal, optionSetLogicalName, optionLabel, optionValue, languageCode, entityName);
                                }
                                else
                                    tracingService.Trace("Option Set Value already exists.");

                                break;
                        }

                        break;

                    case "REMOVE":

                        switch (isGlobal)
                        {
                            case true:
                                optionValue = GetOptionSetValueToBeRemoved(service, isGlobal, optionLabel, optionSetLogicalName);

                                if (optionValue != -1)
                                    RemoveOptionSetItem(service, tracingService, isGlobal, optionSetLogicalName, optionValue, languageCode);

                                break;

                            case false:
                                optionValue = GetOptionSetValueToBeRemoved(service, isGlobal, optionLabel, optionSetLogicalName, entityName);

                                if (optionValue != -1)
                                    RemoveOptionSetItem(service, tracingService, isGlobal, optionSetLogicalName, optionValue, languageCode, entityName);

                                break;
                        }

                        break;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
                throw new InvalidPluginExecutionException(ex.Message);
            }

            tracingService.Trace("Exiting AddRemoveOptionsetValue.Execute(), Correlation Id: {0}", context.CorrelationId);
        }

        private int GetOptionValuePrefixBasedOnPublisher(IOrganizationService service, string publisher)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >
                                <entity name='publisher' >
                                    <attribute name='customizationoptionvalueprefix' />
                                    <attribute name='customizationprefix' />
                                    <filter type='and' >
                                        <condition attribute='customizationprefix' operator='eq' value='{0}' />
                                    </filter>
                                </entity>
                            </fetch>";

            EntityCollection publisherCollection = service.RetrieveMultiple(new FetchExpression(string.Format(fetch, publisher)));

            if (publisherCollection != null && publisherCollection.Entities != null && publisherCollection.Entities.Count > 0)
            {
                // To do
                // What if more than one publisher exists with same prefix?

                if (publisherCollection.Entities[0].Contains("customizationoptionvalueprefix") && publisherCollection.Entities[0].Attributes["customizationoptionvalueprefix"] != null)
                    return ((int)publisherCollection.Entities[0].Attributes["customizationoptionvalueprefix"] * 10000);
            }
            return -1;
        }

        private int GetOptionSetValueToBeInserted(int optionValuePrefix, List<int?> optionList)
        {
            if (optionList.Count == 0)
            {
                return optionValuePrefix;
            }

            if (optionList.Count == 1)
            {
                if (optionList[0] == optionValuePrefix)
                    return (int)(optionList[0] + 1);
                else
                    return optionValuePrefix;
            }

            for (int counter = 0; counter < optionList.Count - 1; counter++)
            {
                if (optionList[0] == optionValuePrefix)
                {
                    if (optionList[counter + 1] != optionList[counter] + 1)
                        return (int)(optionList[counter] + 1);
                }
                else
                    return optionValuePrefix;
            }

            return (int)(optionList.LastOrDefault() + 1);
        }

        private int GetOptionSetValueToBeRemoved(IOrganizationService service, bool isGlobal, string optionLabel, string optionSetLogicalName, string entityName = null)
        {
            if (isGlobal)
            {
                RetrieveOptionSetRequest retrieveOptionSetRequest = new RetrieveOptionSetRequest { Name = optionSetLogicalName };

                RetrieveOptionSetResponse retrieveOptionSetResponse = (RetrieveOptionSetResponse)service.Execute(retrieveOptionSetRequest);
                OptionSetMetadata retrievedOptionSetMetadata = (OptionSetMetadata)retrieveOptionSetResponse.OptionSetMetadata;

                var optionSetValue = (from o in retrievedOptionSetMetadata.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).FirstOrDefault();

                if (optionSetValue != null)
                    return (int)optionSetValue.Value;
                else
                    return -1;
            }
            else
            {
                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest { EntityLogicalName = entityName, LogicalName = optionSetLogicalName, RetrieveAsIfPublished = true };

                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);
                EnumAttributeMetadata attributeMetadata = (EnumAttributeMetadata)attributeResponse.AttributeMetadata;

                var optionSetValue = (from o in attributeMetadata.OptionSet.Options where o.Label.LocalizedLabels[0].Label == optionLabel select new { Value = o.Value }).FirstOrDefault();

                if (optionSetValue != null)
                    return (int)optionSetValue.Value;
                else
                    return -1;
            }
        }

        private void AddOptionSetItem(IOrganizationService service, ITracingService tracingService, bool isGlobal, string optionSetLogicalName, string optionLabel, int optionValue, int languageCode, string entityName = null)
        {
            var insertOptionValueRequest = new InsertOptionValueRequest();
            insertOptionValueRequest.Label = new Label(optionLabel, languageCode);
            insertOptionValueRequest.Value = optionValue;   // CRM defaulted, if not specified

            switch (isGlobal)
            {
                case true:
                    insertOptionValueRequest.OptionSetName = optionSetLogicalName;

                    break;

                case false:
                    insertOptionValueRequest.AttributeLogicalName = optionSetLogicalName;
                    insertOptionValueRequest.EntityLogicalName = entityName;

                    break;
            }

            var optionSetValueAdded = ((InsertOptionValueResponse)service.Execute(insertOptionValueRequest)).NewOptionValue;

            tracingService.Trace("Option Set Value added successfully.");

            // To do: 
            // 'optionSetValueAdded' can be stored in a read-only whole number field on the configurable entity.

        }

        private void RemoveOptionSetItem(IOrganizationService service, ITracingService tracingService, bool isGlobal, string optionSetLogicalName, int optionValue, int languageCode, string entityName = null)
        {
            var deleteOptionValueRequest = new DeleteOptionValueRequest();
            deleteOptionValueRequest.Value = optionValue;

            switch (isGlobal)
            {
                case true:
                    deleteOptionValueRequest.OptionSetName = optionSetLogicalName;
                    break;

                case false:
                    deleteOptionValueRequest.AttributeLogicalName = optionSetLogicalName;
                    deleteOptionValueRequest.EntityLogicalName = entityName;
                    break;
            }

            var response = ((DeleteOptionValueResponse)service.Execute(deleteOptionValueRequest));

            tracingService.Trace("Option Set Value removed successfully.");
        }
    }
}
