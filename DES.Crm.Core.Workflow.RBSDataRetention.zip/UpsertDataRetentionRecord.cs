﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;


public sealed class UpsertDataRetentionRecord : CodeActivity
{

    #region Properties

    [Input("Name of the Record")]
    public InArgument<string> RecordName { get; set; }

    [Input("Record URL")]
    public InArgument<string> RecordURL { get; set; }

    [Input("Country Code")]
    public InArgument<string> CountryCode { get; set; }

    [Input("Integration Key")]
    public InArgument<string> IntegrationKey { get; set; }

    [Input("Override Status")]
    public InArgument<string> Status { get; set; }

    [Input("Override Action On Date")]
    public InArgument<DateTime> ActionOnDate { get; set; }

    [Input("Override Trigger Date ")]
    public InArgument<DateTime> TriggerDateAttribute { get; set; }


    #endregion

    IWorkflowContext context;
    ITracingService trace;
    IOrganizationServiceFactory serviceFactory;
    IOrganizationService service;
    protected override void Execute(CodeActivityContext executioncontext)
    {
        context = executioncontext.GetExtension<IWorkflowContext>();
        trace = executioncontext.GetExtension<ITracingService>();
        serviceFactory = executioncontext.GetExtension<IOrganizationServiceFactory>();
        service = serviceFactory.CreateOrganizationService(context.UserId);

        try
        {
            //Gets entityName and entityId
            string entityName = context.PrimaryEntityName;
            Guid entityId = context.PrimaryEntityId;

            //Try retrieving FROM rbs_dataretentionconfiguration
            //WHERE new_dataretentionconfiguration.rbs_entityname = entityName 

            string countryCode = executioncontext.GetValue(CountryCode) != null ? executioncontext.GetValue(CountryCode) : default(string);




            QueryExpression qeForRetrievingRetentionDetails = new QueryExpression("rbs_dataretentionconfiguration");
            qeForRetrievingRetentionDetails.ColumnSet.AllColumns = true;
            qeForRetrievingRetentionDetails.NoLock = true;
            qeForRetrievingRetentionDetails.Criteria.AddFilter(LogicalOperator.And);
            qeForRetrievingRetentionDetails.Criteria.AddCondition(new ConditionExpression("rbs_entityname", ConditionOperator.Equal, entityName));
            qeForRetrievingRetentionDetails.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
            if (countryCode != null)
                qeForRetrievingRetentionDetails.Criteria.AddCondition(new ConditionExpression("rbs_countrycode", ConditionOperator.Equal, countryCode));

            else qeForRetrievingRetentionDetails.Criteria.AddCondition(new ConditionExpression("rbs_countrycode", ConditionOperator.Null));

            EntityCollection configurationDetail = service.RetrieveMultiple(qeForRetrievingRetentionDetails);

            if (configurationDetail != null && configurationDetail.Entities != null && configurationDetail.Entities.Count > 0)
            {
                //Try retrieving FROM new_dataretentionrecord 
                //WHERE rbs_dataretentionrecord.new_entity = entityName
                //and rbs_dataretentionrecord.new_guid = entityId
                //and status reason of data retentionrecord is "In retention Period" or "Not In retention Period"

                QueryExpression qeForDataRetentionRecord = new QueryExpression("rbs_dataretentionrecord");
                qeForDataRetentionRecord.Criteria.AddFilter(LogicalOperator.And);
                qeForDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_entity", ConditionOperator.Equal, entityName));
                qeForDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.In, new int[] { 1, 859770001 }));
                qeForDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, entityId.ToString()));
                qeForDataRetentionRecord.NoLock = true;

                EntityCollection drRecord = service.RetrieveMultiple(qeForDataRetentionRecord);

                if (drRecord != null)
                {
                    //If cannot retrieve the new_dataretentionrecord (does not exist yet) then creates it
                    //If succesfully retrieve the new_dataretentionrecord then updates it

                    var drcRecord = configurationDetail.Entities.FirstOrDefault();
                    //get the last modified of the record to be pushed into the retention phase
                    // Entity EntityRecordGoingTobeInRetention = new Entity(entityName);
                    //EntityRecordGoingTobeInRetention = service.Retrieve(entityName, entityId, new ColumnSet("modifiedon"));


                    //Check if the Attribute OverRide On has value

                    DateTime attributeName = executioncontext.GetValue(TriggerDateAttribute);

                    DateTime triggerDate;

                    if (attributeName == DateTime.MinValue)
                    {
                        triggerDate = DateTime.UtcNow;
                    }

                    else
                    {
                        triggerDate = attributeName;
                        //bool checkIfAttributeExists = CommonMethods.ifAttributeExists(attributeName, context.PrimaryEntityName, service);

                        //if(checkIfAttributeExists)
                        //{
                        //    Entity entIncontext = service.Retrieve(context.PrimaryEntityName, context.PrimaryEntityId, new ColumnSet(attributeName));

                        //    triggerDate = entIncontext.GetAttributeValue<DateTime>(attributeName);

                        //}
                        //else
                        //{
                        //   throw new Exception("Attribute name in the override input parameter is Invalid ");
                        //}
                    }

                    //If succesfully then retrieves the rbs_dataretentionconfiguration record then gets values needed to create-update dataretentionrecord... 


                    int? actionAfterX = drcRecord.Attributes.Contains("rbs_actionafterx") ? drcRecord.GetAttributeValue<int>("rbs_actionafterx") : default(int);
                    int? actionAfterPeriod = drcRecord.Attributes.Contains("rbs_actionafterperiod") ? drcRecord.GetAttributeValue<OptionSetValue>("rbs_actionafterperiod").Value : default(int);
                    string actionAfterPeriodType = (actionAfterPeriod != 0) ? drcRecord.FormattedValues["rbs_actionafterperiod"].ToString() : default(string);
                    bool action = drcRecord.Attributes.Contains("rbs_action") ? drcRecord.GetAttributeValue<bool>("rbs_action") : default(bool);

                    DateTime actionOn = CommonMethods.CalculateRetentionDate(triggerDate, actionAfterX, actionAfterPeriodType);

                    trace.Trace("actionAfterX period type is " + actionAfterX);
                    trace.Trace("actionAfterPeriod is " + actionAfterPeriod);
                    trace.Trace("actionAfterPeriodType is " + actionAfterPeriodType);

                    Entity dataRetentionRecord = new Entity("rbs_dataretentionrecord");


                    if (executioncontext.GetValue(Status) == null)
                    {
                        if (drRecord.Entities != null && drRecord.Entities.Count > 0)
                        {
                            dataRetentionRecord = service.Retrieve("rbs_dataretentionrecord", drRecord.Entities[0].Id, new ColumnSet("rbs_dataretentionrecordid", "statuscode"));

                            dataRetentionRecord.Attributes["rbs_name"] = executioncontext.GetValue(RecordName);
                            dataRetentionRecord.Attributes["rbs_dataretentionconfigurationid"] = new EntityReference("rbs_dataretentionconfiguration", drcRecord.GetAttributeValue<Guid>("rbs_dataretentionconfigurationid"));
                            dataRetentionRecord.Attributes["rbs_entity"] = entityName;
                            dataRetentionRecord.Attributes["rbs_guid"] = entityId.ToString();
                            dataRetentionRecord.Attributes["rbs_url"] = executioncontext.GetValue(RecordURL);
                            dataRetentionRecord.Attributes["rbs_triggerdate"] = triggerDate;
                            dataRetentionRecord.Attributes["rbs_action"] = action;
                            dataRetentionRecord.Attributes["rbs_actionon"] = actionOn;
                            dataRetentionRecord.Attributes["rbs_ik"] = executioncontext.GetValue(IntegrationKey);
                            dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(1);// in Retention Period: 1
                            service.Update(dataRetentionRecord);
                            trace.Trace("Updated the data retention record with id" + drRecord.Entities[0].GetAttributeValue<Guid>("rbs_dataretentionrecordid").ToString());
                        }


                        else
                        //If cannot retrieve the new_dataretentionconfiguration (does not exist) then finishes execution
                        {
                            dataRetentionRecord.Attributes["rbs_name"] = executioncontext.GetValue(RecordName);
                            dataRetentionRecord.Attributes["rbs_dataretentionconfigurationid"] = new EntityReference("rbs_dataretentionconfiguration", drcRecord.GetAttributeValue<Guid>("rbs_dataretentionconfigurationid"));
                            dataRetentionRecord.Attributes["rbs_entity"] = entityName;
                            dataRetentionRecord.Attributes["rbs_guid"] = entityId.ToString();
                            dataRetentionRecord.Attributes["rbs_url"] = executioncontext.GetValue(RecordURL);
                            dataRetentionRecord.Attributes["rbs_triggerdate"] = triggerDate;
                            dataRetentionRecord.Attributes["rbs_action"] = action;
                            dataRetentionRecord.Attributes["rbs_actionon"] = actionOn;
                            dataRetentionRecord.Attributes["rbs_ik"] = executioncontext.GetValue(IntegrationKey);
                            dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(1);// in Retention Period: 1
                            Guid recordID = service.Create(dataRetentionRecord);
                            trace.Trace("created the data retention record with id is " + recordID);
                        }
                    }
                    else if (executioncontext.GetValue(Status).Trim().ToLower() == "not in retention period")
                    {
                        if (drRecord.Entities != null && drRecord.Entities.Count > 0)
                        {
                            dataRetentionRecord = service.Retrieve("rbs_dataretentionrecord", drRecord.Entities[0].Id, new ColumnSet("rbs_dataretentionrecordid", "statuscode"));

                            dataRetentionRecord.Attributes["rbs_name"] = executioncontext.GetValue(RecordName);
                            dataRetentionRecord.Attributes["rbs_dataretentionconfigurationid"] = new EntityReference("rbs_dataretentionconfiguration", drcRecord.GetAttributeValue<Guid>("rbs_dataretentionconfigurationid"));
                            dataRetentionRecord.Attributes["rbs_entity"] = entityName;
                            dataRetentionRecord.Attributes["rbs_guid"] = entityId.ToString();
                            dataRetentionRecord.Attributes["rbs_url"] = executioncontext.GetValue(RecordURL);
                            dataRetentionRecord.Attributes["rbs_triggerdate"] = triggerDate;
                            dataRetentionRecord.Attributes["rbs_action"] = action;
                            dataRetentionRecord.Attributes["rbs_ik"] = executioncontext.GetValue(IntegrationKey);

                            dataRetentionRecord.Attributes["rbs_actionon"] = (executioncontext.GetValue(ActionOnDate) != null) ? executioncontext.GetValue(ActionOnDate) : new DateTime(9999, 31, 12);
                            dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(859770001);//Not in Retention Period: 859770001

                            service.Update(dataRetentionRecord);
                            trace.Trace("Updated the data retention record with id" + drRecord.Entities[0].GetAttributeValue<Guid>("rbs_dataretentionrecordid").ToString());
                        }


                        else

                        {
                            trace.Trace("record name " + executioncontext.GetValue(RecordName));
                            dataRetentionRecord.Attributes["rbs_name"] = executioncontext.GetValue(RecordName);
                            dataRetentionRecord.Attributes["rbs_dataretentionconfigurationid"] = new EntityReference("rbs_dataretentionconfiguration", drcRecord.GetAttributeValue<Guid>("rbs_dataretentionconfigurationid"));
                            dataRetentionRecord.Attributes["rbs_entity"] = entityName;
                            dataRetentionRecord.Attributes["rbs_guid"] = entityId.ToString();
                            dataRetentionRecord.Attributes["rbs_url"] = executioncontext.GetValue(RecordURL);
                            dataRetentionRecord.Attributes["rbs_triggerdate"] = triggerDate;
                            dataRetentionRecord.Attributes["rbs_action"] = action;
                            dataRetentionRecord.Attributes["rbs_actionon"] = actionOn;
                            dataRetentionRecord.Attributes["rbs_ik"] = executioncontext.GetValue(IntegrationKey);
                            dataRetentionRecord.Attributes["rbs_actionon"] = (executioncontext.GetValue(ActionOnDate) != null) ? executioncontext.GetValue(ActionOnDate) : new DateTime(9999, 31, 12);
                            dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(859770001);//Not in Retention Period: 859770001

                            Guid recordID = service.Create(dataRetentionRecord);
                            trace.Trace("created the data retention record with id is " + recordID);
                        }
                    }
                    //else if(executioncontext.GetValue(Status) != null && executioncontext.GetValue(Status).Trim().ToLower() != "not in retention period")
                    //{
                    //   // trace.Trace("Invalid status, DR record not created, check for the Status passed in Input parameter of the workflkow");
                    //    throw new Exception("Invalid status, DR record not created, check for the Status passed in Input parameter of the workflkow");
                    //}
                }
                else { trace.Trace("qeForDataRetentionRecord didn't yield any results"); }
            }
            else
            {

                trace.Trace("Query Expression for Data Retention Configuration yeilded no results");
            }
        }
        catch (Exception e)
        {
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }
    }

}

