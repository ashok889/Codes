﻿ 
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

public sealed class UpdateGenericParentDataRetention : CodeActivity
{

    #region Properties     
    [Input("Parent Entity Reference")]
    public InArgument<string> ParentEntityReference { get; set; }
    //[Input("Parent Entity Name ")]
    //public InArgument<string> ParentEntityName { get; set; }
    [Input("Override Status (numeric value of OptionSet)")]
    public InArgument<int> Status { get; set; }
    [Input("Override Action On Date")]
    public InArgument<DateTime> ActionOnDate { get; set; }
    #endregion

    #region Class Variables
    IWorkflowContext context;
    ITracingService trace;
    IOrganizationServiceFactory serviceFactory;
    IOrganizationService service;
    #endregion

    protected override void Execute(CodeActivityContext executioncontext)
    {
        #region Initialize Service
        context = executioncontext.GetExtension<IWorkflowContext>();
        trace = executioncontext.GetExtension<ITracingService>();
        serviceFactory = executioncontext.GetExtension<IOrganizationServiceFactory>();
        service = serviceFactory.CreateOrganizationService(context.UserId);
        #endregion
        //==================================================================================================================
        // 1.We will be only passing one Parent Id and Logical Name at a time instead of Comma separated option
        //2.    For Example for the Parent Entity of Mortgage
        //a)    Update of Parent form child “Incident” (Case) ,   rbs_mortgageid and rbs_mortgage will be passed
        //b)	You will retrieve the  parent Mortgage Parent Guid  related to the Case from the Case record
        //c)	You will then get the record matching the Mortgage Guid and Mortgage Entity from the Data Retention record
        //d)	Update the record with Status and Action On Date
        //e)	If Action on Date is not available on Mortgage , get it from Child Case Entity and update the DataRetention Record
        //=================================================================================================================
        try
        { 
                Entity TargetRecord = (Entity)context.InputParameters["Target"];
                trace.Trace("Entity " + TargetRecord.LogicalName.ToString());
                
                string parentId = string.Empty;
                string parentEntityName = string.Empty;
                DateTime actionOn = DateTime.MinValue;
                DateTime actionOnChild = DateTime.MinValue;
            
                int parentStatusCode = 0;

                //============================================================================ 
                // Declare the arrays for getting the incoming the Entity and Lookup attribute
                //============================================================================ 
                string inputString = string.Empty;
                string[] entityArrayStrings = new string[] { };
                string[] attributeArrayStrings = new string[] { };

               
                trace.Trace("Action On " + actionOn.ToString());
                trace.Trace("Status Code  " + parentStatusCode.ToString());

                Guid primaryEntityId = context.PrimaryEntityId;
                string primaryEntity = context.PrimaryEntityName;
                string primaryKeyAttribute, primaryField;

                trace.Trace("Primary Entity Id  " + primaryEntityId.ToString());                         
                trace.Trace("Primary Entity    " + primaryEntity.ToString());

                //============================================================================ 
                //  Get the Primary Key attribute
                //============================================================================ 
                CommonMethods.GetPrimaryAttributes(service, primaryEntity, out primaryKeyAttribute, out primaryField);

                trace.Trace("Primary Key Attribute   " + primaryKeyAttribute);
                trace.Trace("Primary Field     " + primaryField);
                //============================================================================ 
                //  Retrieve the Parent Id for the Incoming Entity  
                //============================================================================ 
               //  parentId = executioncontext.GetValue<string>(ParentEntityReference);
               // parentEntityName = executioncontext.GetValue<string>(ParentEntityName);
                actionOn = executioncontext.GetValue<DateTime>(ActionOnDate);
                parentStatusCode = executioncontext.GetValue<int>(Status);


                if ((executioncontext != null) && (executioncontext.GetValue<string>(ParentEntityReference).ToString() != string.Empty))
                {
                    inputString = executioncontext.GetValue<string>(ParentEntityReference);
                    entityArrayStrings = inputString.Split(',');
                  
                    // Split to rbs_mortgageid.rbs_mortgage
                    // customerid.contact
                    if (entityArrayStrings.Length > 0)
                    {
                        foreach (string entityString in entityArrayStrings)
                        {
                        

                            if (entityString != String.Empty)
                            {

                                // Split to rbs_mortgageid & rbs_mortgage
                                 trace.Trace("INCOMING STRING     " + entityString);
                                //check the Trim of the entity String

                                attributeArrayStrings = entityString.Split('.');
                                parentId = attributeArrayStrings[0];
                                parentEntityName = attributeArrayStrings[1];
                                trace.Trace("Parent Id " + parentId.ToString());
                                trace.Trace("Parent Entity Name  " + parentEntityName.ToString());

                                QueryExpression qeCurrentChildRecord = new QueryExpression(primaryEntity);
                                qeCurrentChildRecord.ColumnSet = new ColumnSet(parentId);
                                qeCurrentChildRecord.Criteria.AddFilter(LogicalOperator.And);
                                qeCurrentChildRecord.Criteria.AddCondition(new ConditionExpression(primaryKeyAttribute, ConditionOperator.Equal, primaryEntityId));
                                qeCurrentChildRecord.NoLock = true;

                                EntityCollection currentChildRecords = service.RetrieveMultiple(qeCurrentChildRecord);

                                if (currentChildRecords != null && currentChildRecords.Entities != null && currentChildRecords.Entities.Count > 0)
                                {
                                    foreach (var currentChildRecord in currentChildRecords.Entities)// 
                                    {
                                        Guid parentGuid = currentChildRecord.Contains(parentId) ? currentChildRecord.GetAttributeValue<EntityReference>(parentId).Id : Guid.Empty;
                                        //trace.Trace("Parent Guid   " + parentGuid.ToString());
                                        actionOnChild = DateTime.MinValue;
                                        //===========================================================
                                        // if the Incoming Parent Date Value is not Min Value
                                        //  Get the action on Date of the Incident and assign it to action On 
                                        //=============================================================
                                        if (actionOn == DateTime.MinValue)
                                        {
                                            QueryExpression qeChildDataRetentionRecord = new QueryExpression("rbs_dataretentionrecord");
                                            qeChildDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_entity", ConditionOperator.Equal, primaryEntity));
                                            qeChildDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, primaryEntityId.ToString()));
                                            qeChildDataRetentionRecord.NoLock = true;

                                            EntityCollection drChildRecords = service.RetrieveMultiple(qeChildDataRetentionRecord);
                                            if (drChildRecords != null && drChildRecords.Entities != null && drChildRecords.Entities.Count > 0)
                                            {
                                                foreach (var drChildRecord in drChildRecords.Entities)
                                                {
                                                    actionOnChild = drChildRecord.Attributes.Contains("rbs_actionon") ? drChildRecord.GetAttributeValue<DateTime>("rbs_actionon") : DateTime.MinValue;
                                                    actionOn = actionOnChild;
                                                    // trace.Trace("Child action ON    " + actionOn.ToString());
                                                }
                                            }

                                        }
                                        //====================================================================
                                        //  Get the matching DR Record of the Parent from Data Retention Entity 
                                        //======================================================================== 
                                        QueryExpression qeParentDataRetentionRecord = new QueryExpression("rbs_dataretentionrecord");
                                        qeParentDataRetentionRecord.Criteria.AddFilter(LogicalOperator.And);
                                        qeParentDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_entity", ConditionOperator.Equal, parentEntityName));
                                        qeParentDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.In, new int[] { 1, 859770001 }));
                                        qeParentDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, parentGuid.ToString()));
                                        qeParentDataRetentionRecord.NoLock = true;


                                        EntityCollection drParentRecords = service.RetrieveMultiple(qeParentDataRetentionRecord);
                                        if (drParentRecords != null && drParentRecords.Entities != null && drParentRecords.Entities.Count > 0)
                                        {
                                            foreach (var drParentRecord in drParentRecords.Entities)// 
                                            {
                                                if (actionOnChild != DateTime.MinValue) // Update the Action on Date only if both parent and Child do not have min value
                                                {
                                                    drParentRecord.Attributes["rbs_actionon"] = actionOn;
                                                    //  trace.Trace("ACTION ON DATE " + actionOn.ToString());
                                                }
                                                if (parentStatusCode > 0)
                                                {
                                                    drParentRecord.Attributes["statuscode"] = new OptionSetValue(parentStatusCode);// in Retention Period: 1
                                                    service.Update(drParentRecord);
                                                    trace.Trace("Update the DR Record  happened successfully");
                                                }
                                                else
                                                {
                                                   trace.Trace("Update the DR Record  did not happen ");
                                                }
                                            }
                                        }
                                    }

                                }
                            }

                        }
                    }
                }
                       
        }
        catch (Exception e)
        {
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }
    } 
}

