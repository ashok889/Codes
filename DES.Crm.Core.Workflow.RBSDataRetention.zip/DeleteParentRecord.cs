﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;


public sealed class DeleteParentRecord : CodeActivity
{

    #region Properties
    [Input("Attribute Name")]
    [RequiredArgument()]
    public InArgument<string> AttributeName { get; set; }


    #endregion

    protected override void Execute(CodeActivityContext executionContext)
    {

        IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
        ITracingService trace = executionContext.GetExtension<ITracingService>();
        IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
        IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

        try
        {

            //RETRIEVES name of related entity and guid of the AttributeName and deletes it


            string AttributeNameValue = executionContext.GetValue(AttributeName);

            if (!string.IsNullOrEmpty(AttributeNameValue))
            {


                var childEntityName = context.PrimaryEntityName;

                Guid childEntityGuid = context.PrimaryEntityId;

                bool attributeExists = CommonMethods.ifAttributeExists(AttributeNameValue, childEntityName, service);

                if (attributeExists)
                {

                    string primaryKeyAttribute, primaryField;

                    CommonMethods.GetPrimaryAttributes(service, childEntityName, out primaryKeyAttribute, out primaryField);

                    if (primaryKeyAttribute != null)
                    {
                        QueryExpression qeForParentattributesValue = new QueryExpression(childEntityName);

                        qeForParentattributesValue.ColumnSet.AddColumn(AttributeNameValue);

                        qeForParentattributesValue.Criteria.AddCondition(new ConditionExpression(primaryKeyAttribute, ConditionOperator.Equal, childEntityGuid));

                        qeForParentattributesValue.NoLock = true;

                        trace.Trace("primary key attibute found is " + primaryKeyAttribute);

                        EntityCollection entCollection = service.RetrieveMultiple(qeForParentattributesValue);

                        if (entCollection != null && entCollection.Entities != null && entCollection.Entities.Count > 0)
                        {

                            foreach (var ent in entCollection.Entities)
                            {
                                if (ent.GetAttributeValue<EntityReference>(AttributeNameValue) != null && ent.GetAttributeValue<EntityReference>(AttributeNameValue).Id != Guid.Empty && ent.GetAttributeValue<EntityReference>(AttributeNameValue).LogicalName != null)
                                {
                                    EntityReference parentRecord = ent.GetAttributeValue<EntityReference>(AttributeNameValue);

                                    service.Delete(parentRecord.LogicalName, parentRecord.Id);

                                    trace.Trace("Deleted: " + parentRecord.LogicalName + " record with id: " + parentRecord.Id);

                                }

                            }

                        }
                        else
                        {
                            trace.Trace("qeForParentattributesValue didn't yield any results");
                        }

                    }
                    else
                    {
                        throw new Exception("Couldn't find primary Key attribute for " + childEntityName);
                    }
                }
                else { trace.Trace("Attribute " + AttributeNameValue + " doesn't exist for " + childEntityName); }

            }

            else
            {
                trace.Trace("AttributeNameValue is null or empty");
            }
        }
        catch (FaultException<OrganizationServiceFault> e)
        {
            //Handle the exception
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }

    }

}
