﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

public static class CommonMethods
{

    internal static string GetOptionsSetTextOnValue(IOrganizationService service, string entityName, string attributeName, int? option)
    {
        try
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            PicklistAttributeMetadata attributeMetadata = (PicklistAttributeMetadata)retrieveAttributeResponse?.AttributeMetadata;
            if (attributeMetadata == null) return string.Empty;
            var currentOption = attributeMetadata?.OptionSet?.Options?.FirstOrDefault(x => x.Value == option);
            return currentOption?.Label?.UserLocalizedLabel?.Label != null ? currentOption.Label.UserLocalizedLabel.Label : string.Empty;
        }
        catch (Exception)
        {

            return null;
        }

    }
    internal static DateTime CalculateRetentionDate(DateTime Date, decimal? retainAfterPeriod, string periodType)
    {
        try
        {
            DateTime dateCalculated;
            switch (periodType)
            {
                case "Years":
                    dateCalculated = Date.AddYears(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Months":
                    dateCalculated = Date.AddMonths(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Days":
                    dateCalculated = Date.AddDays(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Hours":
                    dateCalculated = Date.AddHours(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Minutes":
                    dateCalculated = Date.AddMinutes(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Seconds":
                    dateCalculated = Date.AddSeconds(Convert.ToInt16(retainAfterPeriod));
                    break;
                default:
                    dateCalculated = new DateTime(2100, 01, 01);
                    break;
            }

            return dateCalculated;
        }
        catch (Exception ex)
        {

            throw new InvalidPluginExecutionException(ex.Message);
        }


    }

    /// <summary> 
    /// Retrieve a CRM Entity's primarykey and primaryfield 
    /// </summary> 
    /// <param name="myMetadataService"></param> 
    /// <param name="entityName"></param> 
    /// <param name="primaryKey"></param> 
    /// <param name="primaryField"></param> 
    internal static void GetPrimaryAttributes(IOrganizationService service, string entityName, out string primaryKey, out string primaryField)
    {
        try
        {
            RetrieveEntityRequest retrieveEntityRequest = new RetrieveEntityRequest() { LogicalName = entityName, EntityFilters = EntityFilters.Entity };
            RetrieveEntityResponse retrieveEntityResponse = (RetrieveEntityResponse)service.Execute(retrieveEntityRequest);
            primaryKey = retrieveEntityResponse.EntityMetadata.PrimaryIdAttribute.ToString();
            primaryField = retrieveEntityResponse.EntityMetadata.PrimaryNameAttribute.ToString();
        }
        catch (Exception)
        {

            primaryKey = null;
            primaryField = null;
        }
    }
    internal static bool ifAttributeExists(string parentAttribute, string entityName, IOrganizationService service)
    {
        try
        {
            RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest() { EntityLogicalName = entityName, LogicalName = parentAttribute, RetrieveAsIfPublished = true };

            RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);

            if (attributeResponse.AttributeMetadata != null)
            { return true; }
            else { return false; }
        }
        catch (Exception)
        {

            return false;
        }
    }
    internal static bool ifRelationShipExists(string relationShipName, IOrganizationService service, out RetrieveRelationshipResponse relationShipResponseSend)
    {
        try
        {
            RetrieveRelationshipRequest relationShipRequest = new RetrieveRelationshipRequest() { Name = relationShipName, RetrieveAsIfPublished = true };

            RetrieveRelationshipResponse relationShipResponse = (RetrieveRelationshipResponse)service.Execute(relationShipRequest);

            if (relationShipResponse.RelationshipMetadata != null)
            {
                relationShipResponseSend = relationShipResponse;
                return true;
            }
            else
            {
                relationShipResponseSend = null;
                return false;
            }
        }
        catch (Exception)
        {
            relationShipResponseSend = null;
            return false;
        }
    }

}

