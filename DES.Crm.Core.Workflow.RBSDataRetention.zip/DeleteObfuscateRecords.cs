﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk;
using Microsoft.Crm.Sdk.Messages;


public sealed class DeleteObfuscateRecords : CodeActivity
{

    #region Properties

    [Input("Also Delete Data Retention Records?")]
    [RequiredArgument()]
    public InArgument<bool> AlsoDeleteDataRetentionRecord { get; set; }

    [Input("Default Obfuscation Text")]
    public InArgument<string> DefaultObfuscationText { get; set; }
    #endregion

    #region Class Variables

    IWorkflowContext context;
    ITracingService trace;
    IOrganizationServiceFactory serviceFactory;
    IOrganizationService service;
    #endregion
    protected override void Execute(CodeActivityContext executioncontext)
    {
        context = executioncontext.GetExtension<IWorkflowContext>();
        trace = executioncontext.GetExtension<ITracingService>();
        serviceFactory = executioncontext.GetExtension<IOrganizationServiceFactory>();
        service = serviceFactory.CreateOrganizationService(context.UserId);


        try
        {

            //In Retention Period (1), Deleted (10000000), 'Obfuscated' (100000001)

            //SETS STATUS TO Deleted (AND DELETE RECORDS)
            //RETRIEVES ALL RECORDS FROM rbs_dataretentionrecods where rbs_actionon >= DateTime.UtcNow  AND statuscode = Retention Period (1)

            QueryExpression qeForToBeDeletedObfuscatedRecords = new QueryExpression("rbs_dataretentionrecord");
            qeForToBeDeletedObfuscatedRecords.ColumnSet = new ColumnSet("rbs_entity", "rbs_guid", "rbs_action", "statuscode");
            qeForToBeDeletedObfuscatedRecords.Criteria.AddFilter(LogicalOperator.And);
            qeForToBeDeletedObfuscatedRecords.Criteria.AddCondition(new ConditionExpression("rbs_dataretentionrecordid", ConditionOperator.Equal, context.PrimaryEntityId));
            qeForToBeDeletedObfuscatedRecords.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.In, new int[] { 1 }));//Retention Period (1)

            qeForToBeDeletedObfuscatedRecords.NoLock = true;

            //code commented after the execute workflow approach considered for this workflow
            //qeForToBeDeletedObfuscatedRecords.Criteria.AddCondition(new ConditionExpression("rbs_actionon",ConditionOperator.LessEqual, DateTime.UtcNow));
            //qeForToBeDeletedObfuscatedRecords.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.Equal,1));

            EntityCollection recordsToBeDeletedObfuscated = service.RetrieveMultiple(qeForToBeDeletedObfuscatedRecords);

            if (recordsToBeDeletedObfuscated != null && recordsToBeDeletedObfuscated.Entities != null && recordsToBeDeletedObfuscated.Entities.Count > 0)
            {
                ///FOR EACH rbs_dataretentionrecod 
                foreach (var item in recordsToBeDeletedObfuscated.Entities)
                {
                    // Entity record type to be deleted or obfuscated
                    var entityName = item.GetAttributeValue<string>("rbs_entity");

                    trace.Trace("Entity Name " + entityName);
                    // recordid  to be deleted or obfuscated
                    Guid recordToBeDeletedOrObfuscatdId = Guid.Parse(item.GetAttributeValue<string>("rbs_guid").ToString());
                    trace.Trace("GUID " + recordToBeDeletedOrObfuscatdId);
                    Entity dataRetentionRecord = new Entity(item.LogicalName, item.Id);
                    ////IF rbs_dataretentionrecod.rbs_action = 0 (Delete)
                    string primaryKeyAttribute, primaryField;
                    CommonMethods.GetPrimaryAttributes(service, entityName, out primaryKeyAttribute, out primaryField);

                    trace.Trace("PrimaryKeyAttribute: " + primaryKeyAttribute);

                    EntityCollection check = CheckRecordExists(entityName, primaryKeyAttribute, recordToBeDeletedOrObfuscatdId);


                    if (item.GetAttributeValue<bool>("rbs_action") == false)
                    {
                        ////DELETE RECORD WHERE EntityName = rbs_dataretentionrecod.rbs_entity AND Guid = rbs_dataretentionrecod.rbs_guid 

                        if (check.Entities.Count > 0)
                        {
                            service.Delete(entityName, recordToBeDeletedOrObfuscatdId);

                            trace.Trace("Deleted the " + entityName + " record, with id = " + recordToBeDeletedOrObfuscatdId + " .");

                            // Delete the audit history related to the record
                            DeleteRecordChangeHistoryRequest delAuditLog = new DeleteRecordChangeHistoryRequest
                            {
                                Target = new EntityReference(entityName, recordToBeDeletedOrObfuscatdId)
                            };
                            DeleteRecordChangeHistoryResponse deleteAuditResponse = (DeleteRecordChangeHistoryResponse)service.Execute(delAuditLog);
                            if (deleteAuditResponse.DeletedEntriesCount != 0)
                                trace.Trace("Deleted the " + entityName + " record's audit history .");
                            // retrieve value whether to delete DataRetentionRecord from input parameter AlsoDeleteDataRetentionRecord
                            bool deleteDataRetentionRecord = executioncontext.GetValue<bool>(AlsoDeleteDataRetentionRecord);

                            ////If AlsoDeleteDataRetentionRecord = true
                            /////Deletes current DataRetentionRecord
                            if (deleteDataRetentionRecord == true)
                            {
                                service.Delete(item.LogicalName, item.Id);
                            }
                            ////Else
                            /////Sets Status Reason of DataRetentionRecord to 'Deleted' (100000000)
                            else
                            {
                                dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(100000000);
                                service.Update(dataRetentionRecord);
                                trace.Trace("Updated the status of " + item.LogicalName + " record, with id = " + item.Id + " from " + item.FormattedValues["statuscode"] + " to  deleted");
                            }
                        }
                        else
                        {
                            dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(859770000);
                            service.Update(dataRetentionRecord);
                            trace.Trace("Updated DRRecord status to Record Not Found");
                        }
                    }
                    ////ELSE IF rbs_dataretentionrecod.rbs_action = 1 (Obfuscate)
                    else if (item.GetAttributeValue<bool>("rbs_action") == true)
                    {

                        if (check.Entities.Count > 0)
                        {
                            ////RETRIEVES RECORD WHERE EntityName = rbs_dataretentionrecod.rbs_entity AND Guid = rbs_dataretentionrecod.rbs_guid INTO RecordToBeObfuscated                                                                     

                            string obfuscationText = executioncontext.GetValue<string>(DefaultObfuscationText);

                            ////RETRIEVES COLLECTION OF ATTRIBUTES (rbs_attributename) TO BE OBFUSCATED FROM rbs_dataretentionobfusctedattribute 
                            ////WHERE rbs_entityname = rbs_dataretentionrecod.rbs_entity INTO AttrubutesToBeObfuscated

                            QueryExpression qeForAttributesToBeObfuscated = new QueryExpression("rbs_dataretentionobfusctedattribute");
                            qeForAttributesToBeObfuscated.ColumnSet = new ColumnSet("rbs_attributename");
                            qeForAttributesToBeObfuscated.Criteria.AddFilter(LogicalOperator.And);
                            qeForAttributesToBeObfuscated.Criteria.AddCondition(new ConditionExpression("rbs_entityname", ConditionOperator.Equal, entityName));
                            qeForAttributesToBeObfuscated.NoLock = true;

                            EntityCollection attributesToBeObfuscated = new EntityCollection();
                            // trace.Trace(QErbs_dataretentionobfusctedattribute.ToString());
                            attributesToBeObfuscated = service.RetrieveMultiple(qeForAttributesToBeObfuscated);

                            if (attributesToBeObfuscated != null && attributesToBeObfuscated.Entities != null && attributesToBeObfuscated.Entities.Count > 0)
                            {

                                Entity recordToBeObfuscated = new Entity(entityName, recordToBeDeletedOrObfuscatdId);

                                foreach (var itemtoBeObfuscated in attributesToBeObfuscated.Entities)
                                {
                                    if (!string.IsNullOrEmpty(itemtoBeObfuscated.GetAttributeValue<string>("rbs_attributename")))
                                    {
                                        string attribute = itemtoBeObfuscated.GetAttributeValue<string>("rbs_attributename").Trim();
                                        trace.Trace("Attribute to be obfuscated is " + attribute);
                                        recordToBeObfuscated.Attributes[attribute] = obfuscationText;
                                    }

                                }
                                //Finally update the record to be obfuscated with the new obfuscated values 
                                service.Update(recordToBeObfuscated);
                                trace.Trace("Obfuscated the " + entityName + " record, with id = " + recordToBeDeletedOrObfuscatdId + " .");

                            }
                            else
                            {
                                trace.Trace("qeForAttributesToBeObfuscated could not yield any results.");
                            }
                            //retrieve value whether to delete DataRetentionRecord from input parameter AlsoDeleteDataRetentionRecord                         
                            bool deleteDataRetentionRecord = executioncontext.GetValue(AlsoDeleteDataRetentionRecord);

                            ////If AlsoDeleteDataRetentionRecord = true
                            /////Deletes current DataRetentionRecord
                            if (deleteDataRetentionRecord == true)
                            {
                                service.Delete(item.LogicalName, item.Id);
                            }
                            ////Else
                            /////Sets Status Reason of DataRetentionRecord to 'Obfuscated' (100000001)
                            else
                            {
                                dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(100000001);
                                service.Update(dataRetentionRecord);
                                trace.Trace("Updated the status of " + item.LogicalName + ", with id = " + item.Id + " from " + item.FormattedValues["statuscode"] + " to  obfuscated");
                            }
                        }
                        else
                        {
                            dataRetentionRecord.Attributes["statuscode"] = new OptionSetValue(859770000);// Record Not Found
                            service.Update(dataRetentionRecord);
                            trace.Trace("Updated DRRecord status to Record Not Found");
                        }


                    }
                }

            }


            else { trace.Trace("Query Expression qeForToBeDeletedObfuscatedRecords didn't yield any results"); }


        }
        catch (Exception e)
        {
            //Handle the exception
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }

    }

    private EntityCollection CheckRecordExists(string entityName, string primaryKeyAttribute, Guid recordToBeDeletedOrObfuscatdId)
    {
        QueryExpression QE_CheckRecordExists = new QueryExpression(entityName);
        QE_CheckRecordExists.Criteria.AddFilter(LogicalOperator.And);
        QE_CheckRecordExists.Criteria.AddCondition(primaryKeyAttribute, ConditionOperator.Equal, recordToBeDeletedOrObfuscatdId);// recordToBeDeletedOrObfuscatdId);
        QE_CheckRecordExists.NoLock = true;

        var check = service.RetrieveMultiple(QE_CheckRecordExists);
        return check;
    }
}
