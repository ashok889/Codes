﻿// -----------------------------------------------------------------------
// <copyright file="IDataAccessManager.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace Rbs.Adobe.Esign

{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public interface IDataAccessManager
    {
        void SendHeartBeat(string serviceName, DateTime? lastHeartBeat);
    }
}
