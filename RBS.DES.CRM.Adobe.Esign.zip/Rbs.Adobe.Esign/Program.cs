﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using AdobeSignNet;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Configuration;
using AdobeSignNet.AdobeSign;


namespace Rbs.Adobe.Esign
{

 
    public class Esign
    {
       

        public static int Main(string[] args)
        {
            Console.WriteLine("Starting Main" + args.Length.ToString());
            try
            {
                Console.WriteLine("Inside Try");

                //   var ApiURL = "https://api.eu1.echosign.com:443/api/rest/v5/";
                var accessToken = "";
                string environment = "";
                //accessToken = "3AAABLblqZhAp7IOK77sn3AYOfm7ECvDEMb64gqzhzu-IXNK9DgtRqpXpNKNR-WO-OFykK4WEs8og0BRhlkO_sQ8TS1mxS15l";
                //environment = "EsignUerTest";
                // Uncomment in case of debugging

                if (args.Length > 0)
                {
                    accessToken = args[0].ToString();
                    environment = args[1].ToString();
                   

                }
                else
                {
                    throw new Exception("Arguments missing");
                }
                Console.WriteLine("Running Job for Environment :" + environment );



                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Esign esign = new Esign();

                string connString = ConfigurationManager.AppSettings["ESignUer"];
                Console.WriteLine("Configuration connString Received" + connString);
                String EsignApi = ConfigurationManager.AppSettings["RbsAdobeApiURL"];
                Console.WriteLine("Configuration EsignApi Received" + EsignApi);
                esign.FetchAdobeUserDetail(EsignApi, accessToken, connString, environment).Wait();
                Console.WriteLine("FetchAdobeUserDetail function execution completed");
                //  esign.FetchAdobeUserDetail(ConfigurationManager.AppSettings["RbsAdobeApiURL"], ConfigurationManager.AppSettings["RbsAdobeAccessToken"]);

                //Console.WriteLine("Please press key to continue");
                //Console.ReadLine(); // To debug the Async process+

                return 0;
                


            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Message : " + ex.Message.ToString());
                throw;
                return 1;


            }


        }

        // being used
        public  async Task FetchAdobeUserDetail(string RbsAdobeApiURL, string RbsAdobeAccessToken, string connString,string environment)
        {
            Console.WriteLine("Inside FetchAdobeUserDetail");
            try
            {


                AdobeSignNet.RestAPI RbsAdobeApi = new AdobeSignNet.RestAPI(RbsAdobeApiURL, RbsAdobeAccessToken);
                AdobeSignNet.AdobeObject Rbsobj = new AdobeSignNet.AdobeObject(RbsAdobeApi);
               

                var us = await Rbsobj.GetUsers();
                int x = 0;
                Console.WriteLine("Inside Rbsobj");

                System.Data.DataTable tblEsignUser = GetEsignUserDataTable();

                foreach (var usk in us.userInfoList)
                {
                    Console.WriteLine("User Full Name : " + WebUtility.HtmlDecode(us.userInfoList[x].fullNameOrEmail));


                    var Use = Rbsobj.GetUserDetail(us.userInfoList[x].userId);




                    Console.WriteLine("User Initials" + Use.Result.initials);
                    // Console.ReadLine();

                    tblEsignUser.Rows.Add(GetEsignUserDataRow(us.userInfoList[x].userId, tblEsignUser, Rbsobj, environment));
                    x++;

                }
                Console.WriteLine("User truncate");

                
                truncateEntries(connString, environment);

                Console.WriteLine("Bulk Insert" + environment.ToString());
                bulkinsert(tblEsignUser, connString);

              

               
            }
            catch(Exception ex)
            {
                throw;

            }

           
        } 


        private static string GetConnectionString(string connectionStringName)
        {
            var connectionString = ConfigurationManager.ConnectionStrings[connectionStringName];
            if (connectionString == null)
            {
                // throw CreateMissingConnectionStringConfiguration(connectionStringName);
            }

            return connectionString.ConnectionString;
        }

        public void UpsertCRMData(string entityName, System.Data.DataTable tblCRMData)
        {
            SqlManager sqlManager = new SqlManager();
            string storedProcedureName = string.Empty;
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@TableVar", tblCRMData);



            sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure, storedProcedureName, param);

        }
        public System.Data.DataTable GetEsignUserDataTable()
        {
            System.Data.DataTable tblEsignUser = new System.Data.DataTable();

            tblEsignUser.Columns.Add("firstName", typeof(string));
            tblEsignUser.Columns.Add("lastName", typeof(string));
            tblEsignUser.Columns.Add("email", typeof(string));
            tblEsignUser.Columns.Add("company", typeof(string));
            tblEsignUser.Columns.Add("initials", typeof(string));
            tblEsignUser.Columns.Add("locale", typeof(string));
            tblEsignUser.Columns.Add("channel", typeof(string));
            tblEsignUser.Columns.Add("account", typeof(string));
            tblEsignUser.Columns.Add("group", typeof(string));
            tblEsignUser.Columns.Add("groupId", typeof(string));
            tblEsignUser.Columns.Add("accountType", typeof(string));
            tblEsignUser.Columns.Add("userStatus", typeof(string));
            tblEsignUser.Columns.Add("optIn", typeof(string));
            tblEsignUser.Columns.Add("environment", typeof(string));


            return tblEsignUser;

        }

        private DataRow GetEsignUserDataRow(string Use, System.Data.DataTable tblEsignUser, AdobeSignNet.AdobeObject Rbsobj,string environment)
        {
            
            var User = Rbsobj.GetUserDetail(Use);


            DataRow drEsignUser = tblEsignUser.NewRow();
            if (User.Result.firstName != null)
            {

                drEsignUser["firstName"] = WebUtility.HtmlDecode(User.Result.firstName.ToString());
            }
            if (User.Result.lastName != null)
            {

                drEsignUser["lastName"] = WebUtility.HtmlDecode(User.Result.lastName.ToString());
            }
            if (User.Result.email != null)
            {

                drEsignUser["email"] = WebUtility.HtmlDecode(User.Result.email.ToString());
            }
            if (User.Result.company != null)
            {

                drEsignUser["company"] = WebUtility.HtmlDecode(User.Result.company.ToString());
            }
            if (User.Result.initials != null)
            {

                drEsignUser["initials"] = WebUtility.HtmlDecode(User.Result.initials.ToString());
            }
            if (User.Result.locale != null)
            {

                drEsignUser["locale"] = WebUtility.HtmlDecode(User.Result.locale.ToString());
            }
            if (User.Result.account != null)
            {

                drEsignUser["account"] = WebUtility.HtmlDecode(User.Result.account.ToString());
            }
            if (User.Result.group != null)
            {

                drEsignUser["group"] = WebUtility.HtmlDecode(User.Result.group.ToString());
            }
            if (User.Result.groupId != null)
            {

                drEsignUser["groupId"] = WebUtility.HtmlDecode(User.Result.groupId.ToString());
            }
            if (User.Result.accountType != null)
            {

                drEsignUser["accountType"] = WebUtility.HtmlDecode(User.Result.accountType.ToString());

            }
            if (User.Result.userStatus != null)
            {

                drEsignUser["userStatus"] = WebUtility.HtmlDecode(User.Result.userStatus.ToString());
            }

            if (User.Result.optIn != null)
            {

                drEsignUser["optIn"] = WebUtility.HtmlDecode(User.Result.optIn.ToString());
            }


            drEsignUser["environment"] = environment;






            return drEsignUser;

        }

        //public async void FetchAdobeUserDetail(string RbsAdobeApiURL, string RbsAdobeAccessToken)
        //{


        //    AdobeSignNet.RestAPI RbsAdobeApi = new AdobeSignNet.RestAPI(RbsAdobeApiURL, RbsAdobeAccessToken);
        //    AdobeSignNet.AdobeObject Rbsobj = new AdobeSignNet.AdobeObject(RbsAdobeApi);




        //    Application RbsxlAutomationApp = new Application();
        //    String RbsAutomationSheet = ConfigurationManager.AppSettings["RbsAdobeUserDetails"];
        //    Workbook RbsxlAutoWorkbook = RbsxlAutomationApp.Workbooks.Open(RbsAutomationSheet);
        //    if (RbsxlAutoWorkbook.Sheets.Count > 0)
        //    {

        //        var us = await Rbsobj.GetUsers();
        //        int x = 0;

        //        foreach (var usk in us.userInfoList)
        //        {

        //            Console.WriteLine("User Full Name : " + us.userInfoList[x].fullNameOrEmail);
        //            var Use = Rbsobj.GetUserDetail(us.userInfoList[x].userId);

        //            Console.WriteLine("User Initials" + Use.Result.initials);
        //            // Console.ReadLine();

        //            foreach (_Worksheet xlWorksheet in RbsxlAutoWorkbook.Sheets)
        //            {

        //                Range xlRange = xlWorksheet.UsedRange;
        //                //  int rowcount = xlRange.Rows.Count;
        //                int colCount = xlRange.Columns.Count;

        //                for (int i = 1; i <= colCount; i++)
        //                {

        //                    if (xlWorksheet.Cells[1, i] != null && xlWorksheet.Cells[1, i].Value2 != null)
        //                    {
        //                        string attribute = (xlWorksheet.Cells[1, i].Value2.ToString().Trim());

        //                        if (attribute == "firstName")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.firstName.ToString();

        //                        }
        //                        else if (attribute == "lastName")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.lastName.ToString();

        //                        }
        //                        else if (attribute == "email")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.email.ToString();
        //                        }
        //                        else if (attribute == "company")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.company.ToString();
        //                        }
        //                        else if (attribute == "initials")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.initials.ToString();
        //                        }
        //                        else if (attribute == "locale")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.locale.ToString();
        //                        }
        //                        else if (attribute == "channel")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.channel.ToString();
        //                        }
        //                        else if (attribute == "account")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.account.ToString();

        //                        }

        //                        else if (attribute == "group")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.group.ToString();
        //                        }
        //                        else if (attribute == "groupId")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.groupId.ToString();
        //                        }
        //                        else if (attribute == "accountType")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.accountType.ToString();
        //                        }
        //                        else if (attribute == "userStatus")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.userStatus.ToString();
        //                        }

        //                        else if (attribute == "optIn")
        //                        {
        //                            xlWorksheet.Cells[x + 2, i].Value2 = Use.Result.optIn.ToString();
        //                        }


        //                    }




        //                }
        //                RbsxlAutoWorkbook.Save();
        //            }




        //            x++;
        //            //  Console.ReadLine();
        //        }



        //    }

        //    RbsxlAutoWorkbook.Close();
        //    RbsxlAutomationApp.Quit();
        //}

        public void truncateEntries(string connString, string environment)
        {
            // string connString = ConfigurationManager.AppSettings["ESignUer"];
            using (SqlConnection connection = new SqlConnection(connString))
            {

                try
                {

                    // Create the command to execute! With the wrong name of the table (Depends on your Database tables)
                    SqlCommand errorCommand = new SqlCommand("DELETE FROM [Esign_User_Details] WHERE [environment] = @Environment;", connection);
                    // Execute the command, here the error will pop up!
                    // But since we're catching the code block's errors, it will be displayed inside the console.
                    errorCommand.Parameters.Add("@Environment", SqlDbType.NVarChar);
                    errorCommand.Parameters["@Environment"].Value = environment;

                    connection.Open();
                    errorCommand.ExecuteNonQuery();
                    connection.Close();
                }
                // catch block
                catch (SqlException er)
                {
                    // Since there is no such column as someErrorColumn (Depends on your Database tables)
                    // SQL Server will throw an error.
                    Console.WriteLine("There was an error reported by SQL Server during truncate Entries for Environment  "+ environment + er.Message);
                }
            }
        }

        public void bulkinsert(System.Data.DataTable tblEsignUser, string connString)
        {


            using (SqlConnection connection = new SqlConnection(connString))

            {
                SqlBulkCopy bulkCopy = new SqlBulkCopy(

            connection,

            SqlBulkCopyOptions.TableLock |

            SqlBulkCopyOptions.FireTriggers |

            SqlBulkCopyOptions.UseInternalTransaction,

            null

            );

                // set the destination table name

                bulkCopy.DestinationTableName = "dbo.Esign_User_Details";
                try
                {

                    connection.Open();


                    // write the data in the "dataTable"

                    bulkCopy.WriteToServer(tblEsignUser);

                    connection.Close();

                }
                catch (Exception ex)
                {
                    Console.WriteLine("There was an error reported by SQL Server during Bulk Insert for Above Environment  "  + ex.Message);


                }


            }


        }

    }



}
