﻿// -----------------------------------------------------------------------
// <copyright file="ISqlManager.cs" company="Microsoft">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

using System.Data;
using System.Data.SqlClient;

namespace Rbs.Adobe.Esign
{
    /// <summary>
    /// interface for sql manager
    /// </summary>
    public interface ISqlManager
    {
        SqlDataReader ExecuteReader(string connectionString, CommandType commandType, string commandText);

        SqlDataReader ExecuteReader(string connectionString, CommandType commandType, string commandText,
            params SqlParameter[] commandParameters);

        SqlDataReader ExecuteReader(SqlConnection connection, SqlTransaction transaction, CommandType commandType,
            string commandText, SqlParameter[] commandParameters);

        SqlDataReader ExecuteReader(string connectionString, string storedProcName, params object[] parameterValues);

        int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText);

        int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText,
           params SqlParameter[] commandParameters);

        int ExecuteNonQuery(SqlConnection connection, CommandType commandType, string commandText,
            params SqlParameter[] commandParameters);

        //int ExecuteNonQuery(string connectionString, CommandType commandType, string storedProcName);
    }
}
