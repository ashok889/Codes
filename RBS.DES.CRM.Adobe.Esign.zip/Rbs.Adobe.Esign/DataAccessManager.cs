﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataAccessManager.cs" company="RBS GBM">
//     Copyright © RBS GBM 2010
// </copyright>
// <summary>
//   Define the "DataAccessManager.cs" type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Xml;
//using RBS.CRM.ASU.DataServices.Common;
////using RBS.CRM.ASU.DataServices.Common.Entities;
//using RBS.CRM.ASU.DataServices.Common.Exceptions;
////using RBS.CRM.ASU.DataServices.Common.Events;
//using RBS.CRM.ASU.DataServices.DataAccess.Data;
//using RBS.CRM.ASU.DataServices.DataAccess.Entities;

namespace Rbs.Adobe.Esign
{
    /// <summary>
    /// Database common 
    /// </summary>
    public partial class DataAccessManager : IDataAccessManager
    {
       /// <summary>
        /// Function to log the heart beat of the service
       /// </summary>
       /// <param name="serviceName">name of the service</param>
       /// <param name="coreLastBeat"></param>
       /// <param name="serviceLastBeat"></param>
        public void SendHeartBeat(string serviceName, DateTime? lastHeartBeat)
        {
            try
            {
                SqlParameter[] param = new SqlParameter[3];
                param[0] = new SqlParameter("ServiceName", serviceName);
                param[1] = new SqlParameter("HostName", Environment.MachineName);
                param[2] = new SqlParameter("LastHeartBeat", lastHeartBeat);
               

                SqlManager sqlManager = new SqlManager();
               // sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure,                                            DataConstants.USPSERVICEHEARTBEATUPDATE, param);
            }
            catch (Exception exception)
            {
                throw new Exception(
                    string.Format(
                        "Could not send the heardbeat for service {0}", serviceName), exception);
            }
        }

        //public string GetLastExtractedToken(string entityName)
        //{
        //    string lastExtractedToken = string.Empty;
        //    SqlManager sqlManager = new SqlManager();  

        //    SqlParameter[] param = new SqlParameter[1];
        //    param[0] = new SqlParameter("@EntityName", entityName);

        // //   var result = sqlManager.ExecuteReader(ConnectionStrings.CrmStaging,CommandType.StoredProcedure, DataConstants.GetLastExtractedToken, param);

        //    if (result.HasRows)
        //    {
        //        while (result.Read())
        //        {
        //            lastExtractedToken = result[0].ToString();
        //            break;
        //        }
        //    }
        //    else
        //    {
        //        throw new Exception( string.Format( "Error: Tracking Token Record not avilable for the Entity: {0}", entityName));
        //    }

        //    result.Close();

        //    return lastExtractedToken;
        //}

        public void UpdateLastExtractedToken(string entityName, string lastExtractedToken)
        {
            SqlManager sqlManager = new SqlManager();  

            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@EntityName", entityName);
            param[1] = new SqlParameter("@LastExtractedToken", lastExtractedToken);

           // sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure, DataConstants.UpdateLastExtractedToken, param);  
              
        }

        public void UpsertCRMData(string entityName, DataTable tblCRMData)
        {
            SqlManager sqlManager = new SqlManager();
            string storedProcedureName = string.Empty;
            SqlParameter[] param = new SqlParameter[1]; 
            param[0] = new SqlParameter("@TableVar", tblCRMData);

           

            sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure, storedProcedureName, param);

        }

        public void DeleteCRMData(string entityName, DataTable tblEntityReference)
        {
            SqlManager sqlManager = new SqlManager(); 
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@EntityName", entityName);
            param[1] = new SqlParameter("@TableVar", tblEntityReference);  
        //    sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure, DataConstants.DeleteCRMData, param);
        }

        //public static void SetResourceLock(string processName, bool releaseFlag)
        //{
        //    try
        //    {
        //        var param = new SqlParameter[4];
        //        param[0] = new SqlParameter("ProcessName", processName);
        //        param[1] = new SqlParameter("LockStatus", releaseFlag);
        //        param[2] = new SqlParameter("LockHolder", "DataSyncService");
        //        param[3] = new SqlParameter("isLocked", false) {Direction = ParameterDirection.Output};

        //        var sqlManager = new SqlManager();
        //        sqlManager.ExecuteNonQuery(ConnectionStrings.CrmStaging, CommandType.StoredProcedure,
        //                                    DataConstants.SETRESOURCELOCK, param);

        //    }
        //    catch (Exception exception)
        //    {
        //        throw new Exception(
        //            string.Format(
        //                "Could not set the Resource Lock for service {0}", processName), exception);
        //    }
        //}

    }
}

