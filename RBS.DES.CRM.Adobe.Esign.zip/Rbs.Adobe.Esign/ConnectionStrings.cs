﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ConnectionStrings.cs" company="RBS GBM">
//   Copyright © RBS GBM 2010
// </copyright>
// <summary>
//   Static configuration class for managing connection strings
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Configuration;
using System.Globalization;

namespace Rbs.Adobe.Esign

{
    /// <summary>
    /// Static configuration class for managing connection strings
    /// </summary>
    public static class ConnectionStrings
    {
        /// <summary>
        /// The name of the sales force connection string
        /// </summary>
        public const string SalesForceName = "SalesForce";

        /// <summary>
        /// The name of the sales force connection string
        /// </summary>
        public const string ConnectName = "Connect";

        /// <summary>
        /// The name of the sales force connection string
        /// </summary>
        public const string ConnectStaticName = "ConnectStatic";

        /// <summary>
        /// The name of the sales force connection string
        /// </summary>
        public const string CrmStagingName = "CRMASUStaging";
            
        /// <summary>
        /// Gets the SalesForce connection string.
        /// </summary>
        /// <value>The SalesForce connection string.</value>
        public static string SalesForce
        {
            get
            {
                return GetConnectionString(SalesForceName);
            }
        }

        /// <summary>
        /// Gets the Connect connection string.
        /// </summary>
        /// <value>The Connect connection string.</value>
        public static string Connect
        {
            get
            {
                return GetConnectionString(ConnectName);
            }
        }

        /// <summary>
        /// Gets the ConnectStatic connection string.
        /// </summary>
        /// <value>The ConnectStatic connection string.</value>
        public static string ConnectStatic
        {
            get
            {
                return GetConnectionString(ConnectStaticName);
            }
        }

        /// <summary>
        /// Gets the ConnectPlus connection string.
        /// </summary>
        /// <value>The ConnectPlus connection string.</value>
        public static string CrmStaging
        {
            get
            {
                return GetConnectionString(CrmStagingName);
            }
        }

        /// <summary>
        /// Gets the connection string.
        /// </summary>
        /// <param name="connectionStringName">Name of the connection string.</param>
        /// <returns>The connection string.</returns>
        private static string GetConnectionString(string connectionStringName)
        {
            var connectionString = ConfigurationManager.ConnectionStrings[connectionStringName];
            if (connectionString == null)
            {
                throw CreateMissingConnectionStringConfiguration(connectionStringName);
            }

            return connectionString.ConnectionString;
        }

        /// <summary>
        /// Creates a missing connection string configuration exception.
        /// </summary>
        /// <param name="connectionName">Name of the connection.</param>
        /// <returns>A <see cref="ConfigurationErrorsException"/> representing the error.</returns>
        private static ConfigurationErrorsException CreateMissingConnectionStringConfiguration(string connectionName)
        {
            return new ConfigurationErrorsException(
                string.Format(CultureInfo.CurrentCulture, "Connection string \"{0}\" has not been configured in the ConnectionStrings " +
                    "section of the application configuration file.", connectionName));
        }
    }
}
