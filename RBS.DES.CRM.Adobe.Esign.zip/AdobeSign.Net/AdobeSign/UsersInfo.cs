﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace AdobeSignNet.AdobeSign
{
    [DataContract]
    public class UsersInfo
    {
        [DataMember]
        public List<UserInfo> userInfoList { get; set; }


        [DataContract]
        public class UserInfo
        {
            [DataMember(EmitDefaultValue = false)]
            public string email { get; set; }

            [DataMember(EmitDefaultValue = false)]
            public string fullNameOrEmail { get; set; }




            [DataMember(EmitDefaultValue = false)]
            public string groupId { get; set; }
            [DataMember(EmitDefaultValue = false)]
            public string userId { get; set; }

        }

    }

  
}
