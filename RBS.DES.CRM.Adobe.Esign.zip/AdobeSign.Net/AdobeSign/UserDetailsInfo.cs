﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace AdobeSignNet.AdobeSign
{
    [DataContract]
    public class UserDetailsInfo
    {
      
        [DataMember(EmitDefaultValue = false)]
        public string email { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string groupId { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string userStatus { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string account { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string accountType { get; set; }

        //[DataMember(EmitDefaultValue = false)]
        //public string capabilityFlags { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string channel { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string company { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string firstName { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string group { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string initials { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string lastName { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string locale { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string optIn { get; set; }
        [DataMember(EmitDefaultValue = false)]
        public string passwordExpiration { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string phone { get; set; }


        //public string roles { get; set; }

        //[DataMember(EmitDefaultValue = false)]
        [DataMember(EmitDefaultValue = false)]
        public string title { get; set; }








    }
}
