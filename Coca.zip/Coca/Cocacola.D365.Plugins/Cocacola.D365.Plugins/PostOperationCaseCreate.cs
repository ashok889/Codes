﻿// <copyright file="PostOperationCaseCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationCaseCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Create, "incident", StageEnum.PostOperation, ExecutionModeEnum.Synchronous, "", "Coke_PostOperationCaseCreate", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationCaseCreate Plugin.
    /// </summary>
    public class PostOperationCaseCreate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationCaseCreate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            
            CaseHelper helper = new CaseHelper();
            Incident target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<Incident>() : null;

            
            if (target != null)
            {
                tracingService.Trace("Inside PostOperation Case Create");
                EntityReference newowner = helper.SetOwnerAsTeamAndUpdateQueueitemOncreateAndUpdateOfOwner(context, service, adminService, tracingService, target);
                if (newowner != null)
                {
                    helper.ShareParentCaseWithChildCaseTeam(context, service, adminService, tracingService, target, newowner);
                }
            }
        }
    }
}
