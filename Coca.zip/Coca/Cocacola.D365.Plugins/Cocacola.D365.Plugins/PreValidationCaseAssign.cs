﻿// <copyright file="PostOperationCaseCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationCaseCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    [CrmPluginRegistration(MessageNameEnum.Assign, "incident", StageEnum.PreValidation, ExecutionModeEnum.Synchronous, "", "Coke_PreValidationCaseAssign", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationCaseCreate Plugin.
    /// </summary>
    public class PreValidationCaseAssign : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreValidationCaseAssign"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            var caseHelper = new CaseHelper();
            EntityReference target = null;
            EntityReference assignee = null;

            if (context.InputParameters != null)
            {
                if (context.InputParameters.Contains("Target"))
                {
                    if(context.InputParameters["Target"] is EntityReference)
                    {
                        target = (EntityReference)context.InputParameters["Target"];
                    }
                }
                if (context.InputParameters.Contains("Assignee"))
                {
                    if (context.InputParameters["Assignee"] is EntityReference)
                    {
                        assignee = (EntityReference)context.InputParameters["Assignee"];
                    }
                }
            }
            
            //test
            if(target != null && assignee != null && (assignee.LogicalName == "systemuser" || assignee.LogicalName == "team"))
            {
                tracingService.Trace("0:" + assignee.LogicalName);
                if (assignee.LogicalName == "systemuser")
                {
                    assignee = adminService.Retrieve(assignee.LogicalName, assignee.Id, new ColumnSet("coke_primaryteamid")).ToEntity<SystemUser>().coke_PrimaryTeamId;
                    tracingService.Trace("1:" + assignee.LogicalName );
                    tracingService.Trace("2:" + assignee.Id);
                }

                if(assignee != null)
                { 
                    var area = caseHelper.getArea(adminService, tracingService, target);
                    tracingService.Trace("3:" + assignee.LogicalName);
                    tracingService.Trace("4:" + assignee.Id);
                    var teamName = adminService.Retrieve(assignee.LogicalName, assignee.Id, new ColumnSet("name")).ToEntity<Team>().Name;

                    if (!teamName.StartsWith(area.coke_teamprefix))
                    {
                        throw new InvalidPluginExecutionException($"The team {teamName} you are trying to assign to doesn't belong to the selected area {area.coke_name}, please update either the area or the team in order to proceed with the assignment");
                    }
                }
            }
        }
    }
}
