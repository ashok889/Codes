﻿// <copyright file="PostOperationAsyncContactUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationAsyncContactUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "contact", StageEnum.PreOperation, ExecutionModeEnum.Synchronous, "coke_countryid", "Coke_PreOperationContactUpdate", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationAsyncContactUpdate Plugin.
    /// </summary>
    public class PreOperationContactUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationAsyncContactUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            ContactHelper helper = new ContactHelper();
            tracingService.Trace("ContactAsyncUpdatePlugin");

            Contact target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<Contact>() : null;
            
            if (target != null && target.Attributes.Contains("coke_countryid"))
            {
                helper.UpdateAddress3CountryField(context, service, adminService, tracingService, target);
            }
        }
    }
}