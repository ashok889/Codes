﻿// <copyright file="PostOperationQueueItemUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationQueueItemUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "queueitem", StageEnum.PostOperation, ExecutionModeEnum.Synchronous, "queueid", "Coke_PostOperationQueueItemUpdate", 1, IsolationModeEnum.Sandbox, Image1Attributes = "workerid,objectid", Image1Name = "PostImage", Image1Type = ImageTypeEnum.PostImage)]

    /// <summary>
    /// PostOperationQueueItemUpdate Plugin.
    /// </summary>
    public class PostOperationQueueItemUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationQueueItemUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            EntityReference newTeam = null;
            tracingService.Trace("UpdatePlugin");

            if (context.Depth > 1)
            {
                tracingService.Trace("Depth return: " + context.Depth);
                return;
            }

            QueueItem target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<QueueItem>() : null;

            QueueItem postImage = context.PostEntityImages != null && context.PostEntityImages.Contains("PostImage") ?
                 context.PostEntityImages["PostImage"].ToEntity<QueueItem>() : null;

            QueueItemHelper helper = new QueueItemHelper();

            if (target != null && target.Attributes.Contains("queueid") && postImage != null && (postImage.ObjectId.LogicalName == Incident.EntityLogicalName || postImage.ObjectId.LogicalName == coke_escalationtask.EntityLogicalName))
            {
                tracingService.Trace("Inside Update");
                newTeam = helper.UpdateOwnerOnCase(context, service, adminService, tracingService, target, postImage);
                if (newTeam != null)
                {
                    if (postImage.ObjectId.LogicalName == Incident.EntityLogicalName)
                    {
                        helper.ShareParentCaseWithChildCaseTeamOnUpdate(context, service, adminService, tracingService, target, newTeam, postImage);
                    }
                    else if (postImage.ObjectId.LogicalName == coke_escalationtask.EntityLogicalName)
                    {
                        helper.ShareCasewithEscalationTaskTeamOnUpdate(context, service, adminService, tracingService, target, newTeam, postImage);
                    }
                }
            }
        }
    }
}
