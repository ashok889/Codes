﻿// <copyright file="PreOperationEscalationTaskCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PreOperationEscalationTaskCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Create, "coke_escalationtask", StageEnum.PreOperation, ExecutionModeEnum.Synchronous, "", "Coke_PreOperationEscalationTaskCreate", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PreOperationEscalationTaskCreate Plugin.
    /// </summary>
    public class PreOperationEscalationTaskCreate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOperationEscalationTaskCreate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            EscalationTaskHelper helper = new EscalationTaskHelper();
            coke_escalationtask target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<coke_escalationtask>() : null;

            if (context.MessageName.Equals("Create", StringComparison.OrdinalIgnoreCase) && target != null && target.Attributes.Contains("coke_customer"))
            {
                tracingService.Trace("Inside Create Customer");
                helper.SetSLAOnPreOperationTargetEntity(context, service, adminService, tracingService, target, null);
            }

            if (context.MessageName.Equals("Create", StringComparison.OrdinalIgnoreCase) && target != null && target.Attributes.Contains("regardingobjectid") && target.RegardingObjectId.LogicalName == Incident.EntityLogicalName)
            {
                tracingService.Trace("Inside Create Incident");
                helper.AutoPopulateFields(context, service, adminService, tracingService, target);
            }
        }
    }
}
