﻿// <copyright file="EmailHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the EmailHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// EmailHelper class.
    /// </summary>
    public class EmailHelper
    {
        /// <summary>
        /// Associate Email Attachments With Case
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="emailEntity">Target Entity</param>
        [ExcludeFromCodeCoverage]
        public void AssociateEmailAttachmentsWithCase(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Entity emailEntity)
        {
            try
            {
                if (emailEntity != null && emailEntity.Attributes.Contains("regardingobjectid") && emailEntity.Attributes["regardingobjectid"] != null)
                {
                    // Get Attachment Count
                    tracingService.Trace("Get Attachment Count");
                    this.GetEmailAttachments(context, service, adminService, tracingService, emailEntity);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("ex.Message = {0}", ex.Message);
                tracingService.Trace("ex.StackTrace = {0}", ex.StackTrace);
            }
        }

        /// <summary>
        /// Get Email Attachments
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="emailEntity">Target Entity</param>
        [ExcludeFromCodeCoverage]
        public void GetEmailAttachments(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Entity emailEntity)
        {
            Entity email = service.Retrieve(emailEntity.LogicalName, emailEntity.Id, new ColumnSet("attachmentcount"));
            int attCount = (int)email["attachmentcount"];
            tracingService.Trace("Attachment count = " + attCount.ToString());

            if (attCount > 0)
            {
                // Get all attachments
                QueryExpression queryAtt = new QueryExpression("activitymimeattachment");
                queryAtt.ColumnSet = new ColumnSet(new string[] { "activityid", "attachmentid", "filename", "body", "mimetype", "subject" });
                queryAtt.Criteria = new FilterExpression();
                queryAtt.Criteria.FilterOperator = LogicalOperator.And;
                queryAtt.Criteria.AddCondition(new ConditionExpression("activityid", ConditionOperator.Equal, email.Id));
                queryAtt.NoLock = true;
                EntityCollection entityCollection = service.RetrieveMultiple(queryAtt);
                var entities = entityCollection.Entities;

                tracingService.Trace("Entities count = " + entities.Count());

                foreach (var result in entities)
                {
                    tracingService.Trace("Inside the for loop");
                    tracingService.Trace("Attributes count = " + result.Attributes.Count());

                    // Instantiate an Annotation object.
                    Entity annotation = new Entity("annotation");

                    if (result.Attributes.Contains("subject"))
                    {
                        tracingService.Trace("subject = " + result.Attributes["subject"].ToString());
                        annotation["subject"] = result.Attributes["subject"].ToString() + " " + " :" + "Attachment -" + result.Attributes["filename"].ToString();
                    }
                    else
                    {
                        tracingService.Trace("subject not found");
                        annotation["subject"] = "Attachment From Incoming Email";
                    }

                    if (result.Attributes.Contains("filename"))
                    {
                        tracingService.Trace("filename = " + result.Attributes["filename"].ToString());
                        annotation["filename"] = result.Attributes["filename"].ToString();
                    }
                    else
                    {
                        tracingService.Trace("filename not found");
                        annotation["filename"] = "Undefined.txt";
                    }

                    if (result.Attributes.Contains("mimetype"))
                    {
                        tracingService.Trace("mimetype = " + result.Attributes["mimetype"].ToString());
                        annotation["mimetype"] = result.Attributes["mimetype"].ToString();
                    }
                    else
                    {
                        tracingService.Trace("mimetype not found");
                        annotation["mimetype"] = "plain/text";
                    }

                    if (result.Attributes.Contains("body"))
                    {
                        annotation["documentbody"] = result.Attributes["body"];
                    }

                    string entitytype = "incident";
                    Guid caseId = (emailEntity.Attributes["regardingobjectid"] as EntityReference).Id;
                    annotation["objectid"] = new Microsoft.Xrm.Sdk.EntityReference(entitytype, caseId);
                    annotation["objecttypecode"] = entitytype;

                    // Create a Note with the attachment
                    service.Create(annotation);
                }
            }
        }

        /// <summary>
        /// Set Is Unknown Sender Flag 
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="targetEmail">Target Entity</param>
        internal void SetIsUnknownSenderFlag(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Email targetEmail)
        {
            var unknownSender = true;

            if (targetEmail.DirectionCode == false && targetEmail.From != null && targetEmail.From.Any())
            {
                tracingService.Trace("targetEmail.DirectionCode == false && targetEmail.From != null && targetEmail.From.Count() > 0");

                EntityCollection from = targetEmail.GetAttributeValue<EntityCollection>("from");
                EntityCollection to = targetEmail.GetAttributeValue<EntityCollection>("to");

                QueryExpression queryExpCC = new QueryExpression()
                {
                    EntityName = "coke_customconfigurations",
                    ColumnSet = new ColumnSet("coke_value", "coke_key"),
                    Criteria = new FilterExpression()
                    {
                        Conditions = { new ConditionExpression("coke_key", ConditionOperator.Equal, "emailForUnknownSenders") }
                    }
                };

                EntityCollection entColCC = service.RetrieveMultiple(queryExpCC);
                if (entColCC.Entities.Count > 0)
                {
                    string customConfigValue = entColCC.Entities[0].Attributes["coke_value"].ToString();
                    tracingService.Trace("Comma Seperated Custom Confg Values" + customConfigValue);
                    string[] colEmailIds = customConfigValue.Split(',');

                    if (to != null && to.Entities.Count > 0)
                    {
                        tracingService.Trace("Email's TO count greater then 0");
                        foreach (var item in to.Entities)
                        {
                            string addressUsed = item.GetAttributeValue<string>("addressused");
                            tracingService.Trace("TO - " + addressUsed);
                            if (!Array.Exists(colEmailIds, element => element.ToLower() == addressUsed.ToLower()))
                            {
                                tracingService.Trace("Returning as TO Email does not exist in Custom Configuration.");
                                return;
                            }
                        }
                    }
                }

                if (targetEmail.Contains("regardingobjectid") && targetEmail.Attributes["regardingobjectid"] != null && ((EntityReference)targetEmail.Attributes["regardingobjectid"]).LogicalName.ToLower() == "incident")
                {
                    tracingService.Trace("Returning as Regarding not set to any Case");
                    return;
                }

                if (from != null && from.Entities.Count > 0)
                {
                    foreach (var item in from.Entities)
                    {
                        EntityReference partyId = item.GetAttributeValue<EntityReference>("partyid");
                        string addressUsedFrom = item.GetAttributeValue<string>("addressused");
                        tracingService.Trace("From - " + addressUsedFrom);
                        if (partyId != null && item.GetAttributeValue<EntityReference>("partyid").LogicalName.ToLower() == "contact")
                        {
                            unknownSender = false;
                            tracingService.Trace("Setting Unknownsender flag to false as From contains Contact " + item.GetAttributeValue<EntityReference>("partyid").Name);
                            break;
                        }
                        else if (partyId != null && item.GetAttributeValue<EntityReference>("partyid").LogicalName.ToLower() == "systemuser")
                        {
                            tracingService.Trace("from field contains System User.");
                            QueryExpression queryExpContactFrom = new QueryExpression()
                            {
                                EntityName = "contact",
                                ColumnSet = new ColumnSet("emailaddress1", "emailaddress2", "emailaddress3"),
                                Criteria = new FilterExpression()
                                {
                                    FilterOperator = LogicalOperator.Or,
                                    Conditions =
                                    {
                                         new ConditionExpression("emailaddress1", ConditionOperator.Equal, addressUsedFrom),
                                         new ConditionExpression("emailaddress2", ConditionOperator.Equal, addressUsedFrom),
                                         new ConditionExpression("emailaddress3", ConditionOperator.Equal, addressUsedFrom)
                                    }
                                }
                            };

                            EntityCollection entColContactFrom = service.RetrieveMultiple(queryExpContactFrom);
                            if (entColContactFrom != null && entColContactFrom.Entities.Count > 0)
                            {
                                unknownSender = false;
                                tracingService.Trace("Setting Unknownsender flag to false as Email " + addressUsedFrom + " associated with System User is also associated with Contact");
                                break;
                            }
                        }
                    }
                }
            }

            if (targetEmail.DirectionCode == false && unknownSender)
            {
                tracingService.Trace("targetEmail.DirectionCode == false && unknownSender == true");
                Email emailToUpdate = new Email();
                emailToUpdate.Id = targetEmail.Id;
                emailToUpdate.coke_IsUnknownSender = unknownSender;
                adminService.Update(emailToUpdate);
            }
        }
    }
}
