﻿// <copyright file="CaseHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the CaseHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// CaseHelper class.
    /// </summary>
    public class CaseHelper
    {
        /// <summary>
        /// CaseOrigin values
        /// </summary>
        enum CaseOrigin
        {
            Phone = 1,
            Email = 2,
            WalkUp = 5,
            Chat = 6,
            DA = 7,
            Web = 8
        };

        /// <summary>
        /// Set Owner As Team And Update Queue item On Case Reactivation
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="caseEntity">Target Entity</param>
        /// <param name="postImage">Post Image</param>
        /// <returns>Return the owner</returns>
        public EntityReference SetOwnerAsTeamAndUpdateQueueitemOnCaseReactivation(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity, Incident postImage)
        {
            tracingService.Trace("PostImage {0} ", postImage);
            EntityReference newOwner = null;
            if (context.MessageName == "Update" && caseEntity.StateCode == 0)
            {
                Guid currentUserId = context.InitiatingUserId;
                QueryExpression query = new QueryExpression(SystemUser.EntityLogicalName);
                tracingService.Trace("Step0 ");
                query.ColumnSet.AddColumn("coke_primaryteamid");
                tracingService.Trace("Step00 ");
                query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, currentUserId);
                tracingService.Trace("Building User Query 1");
                LinkEntity link = new LinkEntity(SystemUser.EntityLogicalName, Team.EntityLogicalName, "coke_primaryteamid", "teamid", JoinOperator.LeftOuter);
                tracingService.Trace("Building User Query 2");
                link.EntityAlias = "team";
                link.Columns.AddColumns("queueid");
                query.LinkEntities.Add(link);
                tracingService.Trace("User Query Built");
                query.NoLock = true;
                var user = adminService.RetrieveMultiple(query).Entities[0].ToEntity<SystemUser>();
                tracingService.Trace("User Retrieved");
                EntityReference queueId = user.GetAttributeValue<AliasedValue>("team.queueid") != null ?
                    user.GetAttributeValue<AliasedValue>("team.queueid").Value as EntityReference : null;
                tracingService.Trace("Queue identified");
                newOwner = user.coke_PrimaryTeamId;
                tracingService.Trace("New Owner Identified");
                if (newOwner != null)
                {
                    Incident incidentToUpdate = new Incident();
                    incidentToUpdate.Id = caseEntity.Id;
                    incidentToUpdate.OwnerId = newOwner;
                    adminService.Update(incidentToUpdate);
                    this.ExecuteAddToQueueItemRequest(adminService, queueId, caseEntity.ToEntityReference(), user.ToEntityReference());
                    return newOwner;
                }
                else
                {
                    if (postImage != null)
                    {
                        tracingService.Trace("postImage.OwnerId.Id {0} ", postImage.OwnerId.Id);
                        EntityReference teamQueueId = service.Retrieve("team", postImage.OwnerId.Id, new ColumnSet("queueid")).ToEntity<Team>().QueueId;
                        this.ExecuteAddToQueueItemRequest(adminService, teamQueueId, caseEntity.ToEntityReference(), null);
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Retrieve Sla By parameters
        /// </summary>
        /// <param name="adminService">Admin Organization Service</param>
        /// <param name="entitytype">Entity Type</param>
        /// <param name="region">EntityReference Region</param>  
        /// <returns>Return SLA</returns>
        public EntityReference RetrieveSlaByparameters(IOrganizationService adminService, int entitytype, EntityReference region)
        {
            QueryExpression query = new QueryExpression(coke_slaconfiguration.EntityLogicalName);
            query.ColumnSet.AddColumns("slaid");
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            if (region != null)
            {
                query.Criteria.AddCondition("coke_regionid", ConditionOperator.Equal, region.Id);
            }
            else
            {
                query.Criteria.AddCondition("coke_regionid", ConditionOperator.Null);
            }

            query.Criteria.AddCondition("slaid", ConditionOperator.NotNull);
            query.NoLock = true;
            var slas = adminService.RetrieveMultiple(query);
            if (slas != null && slas.Entities != null && slas.Entities.Count > 0)
            {
                return slas.Entities[0]["slaid"] as EntityReference;
            }

            return null;
        }

        /// <summary>
        /// Set Owner As Team And Update Queue item On create And Update Of Owner
        /// </summary>
        /// <param name="context">IPluginExecutionContext context</param>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>
        /// <param name="caseEntity">Incident caseEntity</param>
        /// <returns>Return new owner</returns>
        public EntityReference SetOwnerAsTeamAndUpdateQueueitemOncreateAndUpdateOfOwner(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity)
        {
            EntityReference owner = null;
            EntityReference newOwner;



            if (context.MessageName == "Create" && caseEntity.CaseOriginCode != null &&
                (caseEntity.CaseOriginCode.Value == (int)CaseOrigin.Web || caseEntity.CaseOriginCode.Value == (int)CaseOrigin.DA) &&
                caseEntity.CustomerId != null && caseEntity.CustomerId.LogicalName == Contact.EntityLogicalName)
            {
                CaseOrigin originCode = (CaseOrigin)caseEntity.CaseOriginCode.Value;

                // get lookup entities
                tracingService.Trace("Orgin is Web or DA");
                var contact = adminService.Retrieve(Contact.EntityLogicalName, caseEntity.CustomerId.Id, new ColumnSet("coke_countryid")).ToEntity<Contact>();

                String country = null;
                if (contact.coke_countryid != null)
                {
                    var countryEntity = service.Retrieve("coke_country", contact.coke_countryid.Id, new ColumnSet("coke_name", "coke_countryabbr")).ToEntity<coke_country>();
                    country = countryEntity?.coke_CountryAbbr;
                }

                EntityCollection workloadAssignmentConfigs = null;
                List<Tuple<string, EntityReference>> filterOptions = new List<Tuple<string, EntityReference>>()
                {
                    new Tuple<string, EntityReference>(country, caseEntity.coke_HRProcess),
                    new Tuple<string, EntityReference>(null, caseEntity.coke_HRProcess),
                    new Tuple<string, EntityReference>(country, null),
                    new Tuple<string, EntityReference>(null, null)
                };

                foreach (Tuple<string, EntityReference> option in filterOptions)
                {
                    workloadAssignmentConfigs = getWorkLoadAssignments(adminService, tracingService, coke_workloadassignmentconfiguration_coke_entitytype.Case, originCode, caseEntity.coke_Area, option.Item1, option.Item2);

                    if (workloadAssignmentConfigs != null && workloadAssignmentConfigs.Entities.Count > 0)
                        break;
                }

                if (workloadAssignmentConfigs != null && workloadAssignmentConfigs.Entities.Count() > 0 && workloadAssignmentConfigs.Entities[0] != null)
                {
                    tracingService.Trace("workloadAssignmentConfigs is not null");
                    var workloadAssignmentConfig = workloadAssignmentConfigs.Entities[0].ToEntity<coke_workloadassignmentconfiguration>();

                    foreach (KeyValuePair<string, object> attr in workloadAssignmentConfig.Attributes)
                    {
                        tracingService.Trace("workloadAssignmentConfig keys and value : " + attr.Key + " : " + attr.Value);
                    }

                    if (workloadAssignmentConfig != null && workloadAssignmentConfig.coke_AssignToTeam != null)
                    {
                        tracingService.Trace("Workloadassignment Not Null");
                        tracingService.Trace("AssignCase team assignment");
                        Incident caseEntityToUpdate = new Incident();
                        caseEntityToUpdate.Id = caseEntity.Id;
                        caseEntityToUpdate.OwnerId = workloadAssignmentConfig.coke_AssignToTeam;
                        adminService.Update(caseEntityToUpdate);
                        owner = caseEntityToUpdate.OwnerId;
                    }
                }
            }
            else if (context.MessageName == "Create" && caseEntity.OwnerId == null)
            {
                owner = adminService.Retrieve("incident", caseEntity.Id, new ColumnSet("ownerid")).ToEntity<Incident>().OwnerId;
            }
            else if (context.MessageName == "Update" && caseEntity.OwnerId == null)
            {
                return null;
            }
            else
            {
                owner = caseEntity.OwnerId;
            }

            tracingService.Trace("Before If");
            if (owner.LogicalName != Team.EntityLogicalName)
            {
                tracingService.Trace("inside if");
                QueryExpression query = new QueryExpression(SystemUser.EntityLogicalName);
                query.ColumnSet.AddColumn("coke_primaryteamid");
                query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, owner.Id);
                LinkEntity link = new LinkEntity(SystemUser.EntityLogicalName, Team.EntityLogicalName, "coke_primaryteamid", "teamid", JoinOperator.LeftOuter);
                link.EntityAlias = "team";
                link.Columns.AddColumns("queueid");
                query.LinkEntities.Add(link);
                query.NoLock = true;
                var user = adminService.RetrieveMultiple(query).Entities[0].ToEntity<SystemUser>();
                EntityReference queueId = user.GetAttributeValue<AliasedValue>("team.queueid").Value as EntityReference;
                newOwner = user.coke_PrimaryTeamId;

                if (newOwner == null)
                {
                    throw new InvalidPluginExecutionException("Primary team is mandatory to create or assign case.");
                }

                Incident incidentToUpdate = new Incident();
                incidentToUpdate.Id = caseEntity.Id;
                incidentToUpdate.OwnerId = newOwner;
                adminService.Update(incidentToUpdate);
                this.ExecuteAddToQueueItemRequest(adminService, queueId, caseEntity.ToEntityReference(), owner);
                tracingService.Trace("if end");
                return newOwner;
            }
            else
            {
                tracingService.Trace("Add to Queue req for Owner == Team");
                EntityReference queueId = service.Retrieve("team", owner.Id, new ColumnSet("queueid")).ToEntity<Team>().QueueId;
                tracingService.Trace("queueId {0}", queueId);
                tracingService.Trace("Owner {0}", owner);
                this.ExecuteAddToQueueItemRequest(adminService, queueId, caseEntity.ToEntityReference(), null);
                newOwner = owner;
                return newOwner;
            }
        }

        private EntityCollection getWorkLoadAssignments(IOrganizationService adminService, ITracingService tracingService, coke_workloadassignmentconfiguration_coke_entitytype type, CaseOrigin originCode, EntityReference area, String country, EntityReference process)
        {
            tracingService.Trace($"[getWorkLoadAssignments] (Type: {type}, Origin: {originCode}, Area: {area?.Id}, Country: {country}, Process: {process})");
            QueryExpression query = new QueryExpression(coke_workloadassignmentconfiguration.EntityLogicalName);
            query.ColumnSet.AddColumns("coke_assigntoteam");
            query.Criteria.AddCondition("coke_entitytype", ConditionOperator.Equal, (int)type);
            query.Criteria.AddCondition("coke_caseorigin", ConditionOperator.Equal, (int)originCode);
            query.Criteria.AddCondition("coke_area", ConditionOperator.Equal, area.Id);
            if (process != null)
            {
                query.Criteria.AddCondition("coke_process", ConditionOperator.Equal, process.Id);
            }
            if (country != null)
            {
                query.Criteria.AddCondition("coke_countryabbr", ConditionOperator.Equal, country);
            }
            else
            {
                query.Criteria.AddCondition("coke_countryabbr", ConditionOperator.Null);
            }
            query.NoLock = true;

            return adminService.RetrieveMultiple(query);
        }

        /// <summary>
        /// Share Parent Case With Child Case Team
        /// </summary>
        /// <param name="context">IPluginExecutionContext context</param>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>
        /// <param name="caseEntity">Incident caseEntity</param>
        /// <param name="newOwner">EntityReference newOwner</param>  
        public void ShareParentCaseWithChildCaseTeam(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity, EntityReference newOwner)
        {
            if (caseEntity.ParentCaseId != null && newOwner != null)
            {
                Guid teamId = newOwner.Id;
                IList<Entity> teamRole = GetTeamRole(adminService, teamId);
                Entity configRole = GetConfigValueForSecurityRole(adminService);
                List<string> teamRoleNames = teamRole.Select(x => x.GetAttributeValue<string>("name").ToString()).ToList();
                if (teamRoleNames.Any(x => x == configRole.GetAttributeValue<string>("coke_value")))
                {
                    var teamReference = new EntityReference(Team.EntityLogicalName, newOwner.Id);
                    GrantAccessRequest grant = new GrantAccessRequest();
                    grant.Target = new EntityReference(caseEntity.ParentCaseId.LogicalName, caseEntity.ParentCaseId.Id);

                    PrincipalAccess principal = new PrincipalAccess();
                    principal.Principal = teamReference;
                    principal.AccessMask = AccessRights.ReadAccess;
                    grant.PrincipalAccess = principal;
                    try
                    {
                        adminService.Execute(grant);
                    }
                    catch (Exception)
                    {
                        throw new InvalidPluginExecutionException("Error during plugin execution");
                    }
                }
            }
        }

        /// <summary>
        /// Share Parent Case With Child Case Team On Update
        /// </summary>
        /// <param name="context">IPluginExecutionContext context</param>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>
        /// <param name="caseEntity">Incident caseEntity</param>
        /// <param name="newOwner">EntityReference newOwner</param>  
        /// <param name="postImage">Incident postImage</param>  
        public void ShareParentCaseWithChildCaseTeamOnUpdate(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity, EntityReference newOwner, Incident postImage)
        {
            tracingService.Trace("Inside Case Share Update");
            if (context.MessageName == "Update" && postImage != null && postImage.ParentCaseId != null)
            {
                tracingService.Trace("postImage.ParentCaseId {0} ", postImage.ParentCaseId.Id);

                if (postImage.OwnerId != null)
                {
                    tracingService.Trace("postImage.OwnerId {0} ", postImage.OwnerId.Id);
                    Guid teamId = postImage.OwnerId.Id;
                    tracingService.Trace("teamId{0} ", teamId);
                    IList<Entity> teamRole = GetTeamRole(adminService, teamId);
                    Entity configRole = GetConfigValueForSecurityRole(adminService);
                    List<string> teamRoleNames = teamRole.Select(x => x.GetAttributeValue<string>("name").ToString()).ToList();
                    if (teamRoleNames.Any(x => x == configRole.GetAttributeValue<string>("coke_value")))
                    {
                        var teamReference = new EntityReference(Team.EntityLogicalName, postImage.OwnerId.Id);
                        GrantAccessRequest grant = new GrantAccessRequest();
                        grant.Target = new EntityReference(postImage.ParentCaseId.LogicalName, postImage.ParentCaseId.Id);

                        PrincipalAccess principal = new PrincipalAccess();
                        principal.Principal = teamReference;
                        principal.AccessMask = AccessRights.ReadAccess;
                        grant.PrincipalAccess = principal;
                        try
                        {
                            adminService.Execute(grant);
                        }
                        catch (Exception)
                        {
                            throw new InvalidPluginExecutionException("Error during plugin execution");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Execute Add To Queue Item Request
        /// </summary>
        /// <param name="adminService">IOrganizationService adminService</param>
        /// <param name="destinationQueueId">EntityReference destinationQueueId</param>
        /// <param name="caseEntityReference">EntityReference caseEntityReference</param>  
        /// <param name="workerId">EntityReference workerId</param>
        public void ExecuteAddToQueueItemRequest(IOrganizationService adminService, EntityReference destinationQueueId, EntityReference caseEntityReference, EntityReference workerId)
        {
            AddToQueueRequest req = new AddToQueueRequest()
            {
                DestinationQueueId = destinationQueueId.Id,
                Target = caseEntityReference
            };
            req.QueueItemProperties = new QueueItem()
            {
                WorkerId = workerId
            };
            adminService.Execute(req);
        }

        /// <summary>
        /// Populate Escalated By
        /// </summary>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="case">Incident target</param>  
        public coke_area getArea(IOrganizationService adminService, ITracingService tracingService, EntityReference target)
        {
            var _case = adminService.Retrieve(target.LogicalName, target.Id, new ColumnSet("coke_area")).ToEntity<Incident>();
            var _area = adminService.Retrieve(coke_area.EntityLogicalName, _case.coke_Area.Id, new ColumnSet("coke_name", "coke_teamprefix")).ToEntity<coke_area>();
            tracingService.Trace($"Retrieved area: {_area.coke_name}");
            return _area;
        }


        /// <summary>
        /// Populate Escalated By
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Incident target</param>  
        public void PopulateEscalatedBy(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident target)
        {
            if (target.Attributes.Contains("statuscode") && target.Attributes["statuscode"] != null && target.StatusCode == incident_statuscode.Escalated)
            {
                target.Attributes["coke_escalatedby"] = new EntityReference("systemuser", context.InitiatingUserId);
            }
        }

        /// <summary>
        /// Populate Task Current Time
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="queueItemEntity">QueueItem queueItemEntity</param>
        [ExcludeFromCodeCoverage]
        internal static void PopulateTaskCurrentTime(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, QueueItem queueItemEntity)
        {
            if (queueItemEntity != null && queueItemEntity.Attributes.Contains("workerid") && queueItemEntity.Attributes["workerid"] != null)
            {
                // (new Entityreference(queueItemEntity.Attributes["objectid"])).Id
                Task taskEntity = new Task();
                taskEntity.Id = queueItemEntity.ObjectId.Id;
                taskEntity.Attributes["coke_workstarteddate"] = DateTime.UtcNow;
                service.Update(taskEntity);
            }
        }

        /// <summary>
        /// Assign Case On Create
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="targetIncident">Incident targetIncident</param>  
        /// <returns>Return Config values</returns>
        [ExcludeFromCodeCoverage]
        internal Incident AssignCaseOnCreate(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident targetIncident)
        {
            if (targetIncident.CaseOriginCode != null && targetIncident.CustomerId != null && targetIncident.CustomerId.LogicalName == Contact.EntityLogicalName)
            {
                var contact = service.Retrieve(Contact.EntityLogicalName, targetIncident.CustomerId.Id, new ColumnSet("address1_country")).ToEntity<Contact>();
                if (contact.Address1_Country == null)
                {
                    return null;
                }

                var originCode = targetIncident.CaseOriginCode.Value;
                var country = contact.Address1_Country;
                QueryExpression query = new QueryExpression(coke_workloadassignmentconfiguration.EntityLogicalName);
                query.Criteria.AddCondition("coke_entitytype", ConditionOperator.Equal, 850480000);
                query.Criteria.AddCondition("coke_caseorigin", ConditionOperator.Equal, originCode);
                query.ColumnSet.AddColumns("coke_assigntoqueue", "coke_assigntoteam");
                query.Criteria.AddCondition("coke_country", ConditionOperator.Equal, country);
                query.NoLock = true;
                EntityCollection workloadAssignmentConfigs = service.RetrieveMultiple(query);

                if (workloadAssignmentConfigs == null || workloadAssignmentConfigs.Entities == null || workloadAssignmentConfigs.Entities.Count == 0)
                {
                    return null;
                }

                var workloadAssignmentConfig = workloadAssignmentConfigs.Entities[0].ToEntity<coke_workloadassignmentconfiguration>();
                if (workloadAssignmentConfig.coke_AssignToTeam != null)
                {
                    tracingService.Trace("AssignCase team assignment");
                    var incidentToUpdate = new Incident();
                    incidentToUpdate.Id = targetIncident.Id;
                    incidentToUpdate.OwnerId = workloadAssignmentConfig.coke_AssignToTeam;
                    service.Update(incidentToUpdate);
                    targetIncident.OwnerId = workloadAssignmentConfig.coke_AssignToTeam;
                }
            }

            return null;
        }

        /// <summary>
        /// Open Escalation Task Check
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Incident targetIncident</param>
        /// <param name="preImage">Incident preImage</param>
        [ExcludeFromCodeCoverage]
        internal void OpenEscalationTaskCheck(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident target, Incident preImage)
        {
            QueryExpression query = new QueryExpression(coke_escalationtask.EntityLogicalName);
            query.ColumnSet.AddColumns("statecode", "subject");
            query.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, preImage.Id);
            query.NoLock = true;
            var tasks = adminService.RetrieveMultiple(query);
            tracingService.Trace("et.Subject + et.StateCode.Value");

            foreach (var task in tasks.Entities)
            {
                var et = task.ToEntity<coke_escalationtask>();
                tracingService.Trace(et.Subject + et.StateCode.Value);
            }
        }

        /// <summary>
        /// Populate Reactivated On Reactivated By And Resolved On Attributes
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="caseEntity">Target Entity</param>
        internal void PopulateResolvedAndReactivedTimeFields(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity)
        {
            if (context.MessageName == "Update" && caseEntity.StateCode == 0)
            {
                caseEntity.coke_reactivatedby = new EntityReference("systemuser", context.InitiatingUserId);
                caseEntity.coke_reactivatedon = DateTime.UtcNow;
            }

            if (context.MessageName == "Update" && caseEntity.StateCode == IncidentState.Resolved)
            {
                caseEntity.coke_resolvedon = DateTime.UtcNow;
            }
        }

        /// <summary>
        /// Set SLA On PreOperation Target Entity
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Incident targetIncident</param>
        /// <param name="preImage">Incident preImage</param>
        /// <returns>Return SLA</returns>
        internal EntityReference SetSLAOnPreOperationTargetEntity(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident target, Incident preImage)
        {
            EntityReference ownerRef = null;
            EntityReference region = null;
            EntityReference slaRef = null;
            tracingService.Trace("SetSLAOnPreOperationTargetEntity method");

            if (target.OwnerId != null)
            {
                ownerRef = target.OwnerId;
            }
            else if (context.MessageName != "Create")
            {
                ownerRef = preImage.OwnerId;
            }

            tracingService.Trace("SetSLAOnPreOperationTargetEntity method4");

            if (context.MessageName == "Create" && ownerRef == null)
            {
                ownerRef = new EntityReference(SystemUser.EntityLogicalName, context.UserId);
            }

            if (ownerRef != null && ownerRef.LogicalName == SystemUser.EntityLogicalName)
            {
                tracingService.Trace("Owner is User");
                QueryExpression query = new QueryExpression(SystemUser.EntityLogicalName);
                query.ColumnSet.AddColumns("coke_regionid");
                tracingService.Trace("Owner is User1");

                query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, ownerRef.Id);
                LinkEntity link = new LinkEntity(SystemUser.EntityLogicalName, Team.EntityLogicalName, "coke_primaryteamid", "teamid", JoinOperator.LeftOuter);
                link.Columns.AddColumns("coke_regionid");
                link.EntityAlias = "team";
                query.LinkEntities.Add(link);
                query.NoLock = true;
                EntityCollection entcol = adminService.RetrieveMultiple(query);
                if (entcol != null && entcol.Entities.Count > 0)
                {
                    var user = adminService.RetrieveMultiple(query).Entities[0];
                    tracingService.Trace("Owner is User2");

                    if (user.GetAttributeValue<AliasedValue>("team.coke_regionid") != null)
                    {
                        region = user.GetAttributeValue<AliasedValue>("team.coke_regionid").Value as EntityReference;
                    }
                    else if (user.GetAttributeValue<EntityReference>("coke_regionid") != null)
                    {
                        tracingService.Trace("Owner is User3");

                        region = user.GetAttributeValue<EntityReference>("coke_regionid");
                    }
                }
            }
            else if (ownerRef != null && ownerRef.LogicalName == Team.EntityLogicalName)
            {
                tracingService.Trace("Owner is team");

                var team = adminService.Retrieve("team", ownerRef.Id, new ColumnSet("coke_regionid")).ToEntity<Team>();
                if (team.coke_RegionId != null)
                {
                    region = team.coke_RegionId;
                }
            }

            if (region == null)
            {
                tracingService.Trace("Region is null: owner: ", ownerRef != null ? ownerRef.Id.ToString() : "null");
                return null;
            }

            if (slaRef == null)
            {
                slaRef = this.RetrieveSlaByparameters(adminService, (int)coke_slaconfiguration_coke_entitytype.Case, region);
                tracingService.Trace("SLA Retrieve with Region" + slaRef);
            }

            if (slaRef == null)
            {
                slaRef = this.RetrieveSlaByparameters(adminService, (int)coke_slaconfiguration_coke_entitytype.Case, null);
                tracingService.Trace("Last Retrieve With Region = null" + slaRef);
            }

            if (slaRef != null)
            {
                target["slaid"] = slaRef;
                return slaRef;
            }

            return null;
        }

        /// <summary>
        /// Auto Populate Contact Fields
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="caseEntity">Incident caseEntity</param>
        internal void AutoPopulateContactFields(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity)
        {
            if (caseEntity != null && caseEntity.CustomerId != null && caseEntity.CustomerId.LogicalName == Contact.EntityLogicalName)
            {
                Contact contactEntity = service.Retrieve("contact", caseEntity.CustomerId.Id, new ColumnSet("preferredcontactmethodcode", "coke_countryid", "coke_regionid")).ToEntity<Contact>();
                coke_country countryEntity = null;



                if (contactEntity.PreferredContactMethodCode != null)
                {
                    caseEntity.Attributes["coke_preferredmethodofcontact"] = contactEntity.Attributes["preferredcontactmethodcode"];
                }

                if (contactEntity.coke_countryid != null)
                {
                    countryEntity = service.Retrieve("coke_country", contactEntity.coke_countryid.Id, new ColumnSet("coke_name", "coke_countryabbr")).ToEntity<coke_country>();

                    if (countryEntity != null && !caseEntity.Attributes.Contains("coke_workcountry"))
                    {
                        caseEntity.coke_workcountry = countryEntity.coke_CountryAbbr;
                    }
                }

                if (contactEntity.coke_RegionId != null && !caseEntity.Attributes.Contains("coke_workregionid"))
                {
                    caseEntity.coke_workregionid = contactEntity.coke_RegionId;
                }
            }
        }

        /// <summary>
        /// Auto Populate Contact Fields
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="caseEntity">Incident caseEntity</param>
        internal void AutoPopulateContactFieldsOnCustomerUpdate(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity)
        {
            if (caseEntity != null && caseEntity.CustomerId != null && caseEntity.CustomerId.LogicalName == Contact.EntityLogicalName)
            {
                Contact contactEntity = service.Retrieve("contact", caseEntity.CustomerId.Id, new ColumnSet("coke_countryid", "coke_regionid")).ToEntity<Contact>();
                coke_country countryEntity = null;

                if (contactEntity.coke_countryid != null)
                {
                    countryEntity = service.Retrieve("coke_country", contactEntity.coke_countryid.Id, new ColumnSet("coke_name", "coke_countryabbr")).ToEntity<coke_country>();

                    if (countryEntity != null)
                    {
                        caseEntity.coke_workcountry = countryEntity.coke_CountryAbbr;
                    }
                }

                if (contactEntity.coke_RegionId != null)
                {
                    caseEntity.coke_workregionid = contactEntity.coke_RegionId;
                }
            }
        }

        internal void AutoPopulateKBSearch(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity, Incident preImage)
        {

            if (caseEntity.Attributes.Contains("customerid") && caseEntity.Attributes.Contains("title"))
            {
                if (caseEntity != null && caseEntity.coke_workregionid != null && caseEntity.coke_workcountry.ToString() != string.Empty && caseEntity.Title.ToString() != string.Empty)
                {
                    caseEntity.coke_KBSearch = caseEntity.Title + "," + caseEntity.coke_workregionid.Name + "," + caseEntity.coke_workcountry;
                }
            }
            else if (context.MessageName == "Update" && caseEntity.Attributes.Contains("title") && !caseEntity.Attributes.Contains("customerid"))
            {

                caseEntity.coke_KBSearch = caseEntity.Title + "," + preImage.coke_workregionid.Name + "," + preImage.coke_workcountry;
            }
            else if (context.MessageName == "Update" && !caseEntity.Attributes.Contains("title") && caseEntity.Attributes.Contains("customerid"))
            {

                caseEntity.coke_KBSearch = preImage.Title + "," + caseEntity.coke_workregionid.Name + "," + caseEntity.coke_workcountry;
            }

        }

        /// <summary>
        /// Auto Populate Contact Fields
        /// </summary>
        /// <param name="context">IPluginExecutionContext Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="caseEntity">Incident caseEntity</param>
        internal void SetIsExecutive(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Incident caseEntity)
        {
            if (caseEntity != null && (
                    (caseEntity.CustomerId != null && caseEntity.CustomerId.LogicalName == Contact.EntityLogicalName) ||
                    (caseEntity.coke_OnBehalfofCustomerId != null && caseEntity.coke_OnBehalfofCustomerId.LogicalName == Contact.EntityLogicalName)))
            {
                List<EntityReference> contactReferences = new List<EntityReference>();
                contactReferences.Add(caseEntity.coke_OnBehalfofCustomerId);
                contactReferences.Add(caseEntity.CustomerId);

                QueryExpression query = new QueryExpression(Contact.EntityLogicalName);
                query.ColumnSet.AddColumn("coke_compensationgradefromjobprofile");
                query.Criteria.FilterOperator = LogicalOperator.Or;

                contactReferences
                    .Where(entity => entity != null)
                    .Distinct()
                    .ToList()
                    .ForEach(entity => query.Criteria.AddCondition("contactid", ConditionOperator.Equal, entity.Id));

                query.NoLock = true;

                var contacts = adminService.RetrieveMultiple(query).Entities
                                .ToList()
                                .Select(entity => entity.ToEntity<Contact>())
                                .Where(contact =>
                                {
                                    int grade = 0;
                                    if (int.TryParse(contact.coke_compensationgradefromjobprofile, out grade))
                                    {
                                        return (18 <= grade);
                                    }
                                    return false;
                                });

                caseEntity.coke_IsExecutive = contacts.Count() > 0;

            }
        }


        /// <summary>
        /// Get The Team Role
        /// </summary>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="teamId">Guid teamId</param>
        /// <returns>Return Team Role</returns>
        private static IList<Entity> GetTeamRole(IOrganizationService service, Guid teamId)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
            <entity name='role'>
            <attribute name='name' />
            <attribute name='businessunitid' />
            <attribute name='roleid' />
            <order attribute='name' descending='false' />
            <link-entity name='teamroles' from='roleid' to='roleid' visible='false' intersect='true'>
            <link-entity name='team' from='teamid' to='teamid' alias='ab'>
            <filter type='and'>
            <condition attribute='teamid' operator='eq' value= '" + teamId + "' /> </filter> </link-entity></link-entity> </entity></fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList();
        }

        /// <summary>
        /// Get Config Value For Security Role
        /// </summary>
        /// <param name="service">IOrganizationService service</param>
        /// <returns>Return Config values</returns>
        private static Entity GetConfigValueForSecurityRole(IOrganizationService service)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            <entity name='coke_customconfigurations'>
            <attribute name='coke_customconfigurationsid' />
            <attribute name='coke_key' />
            <attribute name='coke_value' />
            <order attribute='coke_key' descending='false' />
            <filter type='and'>
            <condition attribute='coke_key' operator='eq' value='Tier2Role' />
            </filter>
            </entity>
            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault();
        }
    }
}