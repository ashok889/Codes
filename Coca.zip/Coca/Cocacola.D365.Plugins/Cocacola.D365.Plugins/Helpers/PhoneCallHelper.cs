﻿// <copyright file="PhoneCallHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PhoneCallHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using System.Linq;
    using Microsoft.Xrm.Sdk;

    /// <summary>
    /// PhoneCallHelper class.
    /// </summary>
    public class PhoneCallHelper
    {
        /// <summary>
        /// Create Post On Contact Based On Authentication
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Entity PhoneCall</param>
        /// <param name="postImage">Entity PhoneCall PostImage</param>
        internal void CreatePostOnContactBasedOnAuthentication(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, PhoneCall target, PhoneCall postImage)
        {
            if (target.coke_AuthenticationStatus == coke_phonecall_coke_authenticationstatus.Authenticated || target.coke_AuthenticationStatus == coke_phonecall_coke_authenticationstatus.AuthenticationFailed)
            {
                Entity caller = postImage.From != null ? postImage.From.First() : null;
                if (caller != null && caller.GetAttributeValue<EntityReference>("partyid") != null && caller.GetAttributeValue<EntityReference>("partyid").LogicalName == Contact.EntityLogicalName)
                {
                    Post post = new Post();
                    post.RegardingObjectId = caller.GetAttributeValue<EntityReference>("partyid");
                    post.Text = "Authentication attempted. Status: " + (postImage.coke_AuthenticationStatus == coke_phonecall_coke_authenticationstatus.Authenticated ? "Pass" : "Fail") + ". Fields used: " + postImage.coke_AuthenticationQuestionsPassed;
                    service.Create(post);
                }
            }
        }
    }
}
