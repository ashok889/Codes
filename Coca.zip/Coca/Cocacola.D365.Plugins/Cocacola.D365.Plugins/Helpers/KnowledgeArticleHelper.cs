﻿// <copyright file="KnowledgeArticleHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the KnowledgeArticleHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Messages;
    using Microsoft.Xrm.Sdk.Metadata;
    using Microsoft.Xrm.Sdk.Query;
    
    /// <summary>
    /// KnowledgeArticleHelper class.
    /// </summary>
    public class KnowledgeArticleHelper
    {
        /// <summary>
        /// Restrict KB Article Update After Approval
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="queueItemEntity">Entity QueueItem</param>
        /// <param name="preImage">Entity PreImage</param>
        internal void RestrictKBArticleUpdateAfterApproval(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, KnowledgeArticle queueItemEntity, KnowledgeArticle preImage)
        {

            SystemUser user = service.Retrieve(SystemUser.EntityLogicalName, context.UserId, new ColumnSet("windowsliveid")).ToEntity<SystemUser>();
            
            if (
                (preImage.StatusCode == knowledgearticle_statuscode.Approved && (null == user?.WindowsLiveID || !user.WindowsLiveID.Equals("x37308@coca-cola.com"))) 
                || preImage.StatusCode == knowledgearticle_statuscode.Published 
                || preImage.StatusCode == knowledgearticle_statuscode.Scheduled)
            {
                throw new InvalidPluginExecutionException("An approved or published knowledge article cannot be updated.");
            }
        }

        /// <summary>
        /// Validate Status Reason
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Entity Target</param>
        /// <param name="preImage">Entity PreImage</param>
        internal void ValidateStatusReason(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Entity target, Entity preImage)
        {
            tracingService.Trace("Inside the function");

            // cancelled
            if (target.Attributes.Contains("statuscode") && ((((OptionSetValue)target.Attributes["statuscode"]).Value == 6) || (((OptionSetValue)target.Attributes["statuscode"]).Value == 7)))
            {
                tracingService.Trace("Status reason changed to published or scheduled");
                if (preImage.Attributes.Contains("statuscode") && (((OptionSetValue)preImage.Attributes["statuscode"]).Value != 5 && ((OptionSetValue)preImage.Attributes["statuscode"]).Value != 6))
                {
                    tracingService.Trace("PreImage Status reason is not Approved");
                    throw new InvalidPluginExecutionException("Please approve the article before publishing it.");
                }
            }
        }

        internal string AutoPopulateGeographyInKeywords(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, KnowledgeArticle kb)
        {
            System.Text.StringBuilder search = new System.Text.StringBuilder();
            string keywords = string.Empty;

            if (kb == null) return string.Empty;

            var target = service.Retrieve(kb.LogicalName, kb.Id,
                  new ColumnSet(new string[] { "title", "keywords", "statuscode", "coke_geography" })).ToEntity<KnowledgeArticle>();

            if (kb.coke_Geography == null)
                kb.coke_Geography = target.coke_Geography;

            tracingService.Trace(target.StatusCode.ToString());

            if (kb.StatusCode == knowledgearticle_statuscode.Approved && kb.coke_Geography != coke_knowledgearticle_coke_geography.Global)
            {
                keywords = target.Keywords == null ? string.Empty : target.Keywords;

                QueryExpression query = new QueryExpression("coke_knowledgearticle_coke_region"); //relationshipname
                query.ColumnSet.AllColumns = true;
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("knowledgearticleid", ConditionOperator.Equal, target.Id);

                EntityCollection kbr = service.RetrieveMultiple(query);

                foreach (Entity rec in kbr.Entities)
                {
                    Entity reg = service.Retrieve("coke_region", rec.GetAttributeValue<System.Guid>("coke_regionid"),
                        new ColumnSet(new string[] { "coke_name" }));
                    
                    if (reg.Attributes.ContainsKey("coke_name"))
                    {
                        string name = reg.GetAttributeValue<string>("coke_name");

                        if (!(keywords.Split(',').Any(word => word.Trim().Equals(name))))
                        {
                            if (search.ToString().Length > 1)
                                search.Append(",");

                            search.Append(name);
                        }
                    }
                }


                if (kb.coke_Geography == coke_knowledgearticle_coke_geography.Country)
                {
                    query = new QueryExpression("coke_knowledgearticle_coke_country"); //relationshipname
                    query.ColumnSet.AllColumns = true;
                    query.Criteria = new FilterExpression();
                    query.Criteria.AddCondition("knowledgearticleid", ConditionOperator.Equal, target.Id);

                    EntityCollection kbc = service.RetrieveMultiple(query);

                    foreach (Entity rec in kbc.Entities)
                    {
                        Entity reg = service.Retrieve("coke_country", rec.GetAttributeValue<System.Guid>("coke_countryid"),
                            new ColumnSet(new string[] { "coke_countryabbr" }));

                        string name = reg.GetAttributeValue<string>("coke_countryabbr");

                        if (!(keywords.Split(',').Any(word => word.Trim().Equals(name))))
                        {
                            if (search.ToString().Length > 1)
                                search.Append(",");

                            search.Append(name);
                        }
                    }
                }

                if (!string.IsNullOrEmpty(search.ToString()))
                {
                    if (!string.IsNullOrEmpty(keywords))
                        keywords = string.Format("{0}{1} {2}", keywords, ", ", search.ToString());
                    else
                        keywords = search.ToString();
                }
            }

            tracingService.Trace("Search string is: " + keywords);
            return keywords;
        }

        /// <summary>
        /// Validate Logged In User Security Role
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Entity Target</param>
        internal void ValidateLoggedInUserSecurityRole(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Entity target)
        {
            tracingService.Trace("Inside the Validate Logged in user security role function");
            List<string> loggedInUserRoles = this.RetrieveLoggedInUserRole(context, service, tracingService);
            List<string> allowedRoles = this.RetrieveCustomConfigurationRoles(service, tracingService);

            if (!loggedInUserRoles.Any(m => allowedRoles.Contains(m)))
            {
                tracingService.Trace("Security role not found");
                throw new InvalidPluginExecutionException("User does not have privilege to Create or update the record.");
            }
        }

        /// <summary>
        /// Retrieve Logged In User Role
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="tracingService">TracingService tracingService</param>
        /// <returns>return logged in user</returns>
        internal List<string> RetrieveLoggedInUserRole(IPluginExecutionContext context, IOrganizationService service, ITracingService tracingService)
        {
            tracingService.Trace("inside RetrieveLoggedInUserRole function 1");
            List<string> userRoles = new List<string>();
            Guid loggedInUserId = context.UserId;
            QueryExpression qe = new QueryExpression("systemuserroles");
            qe.ColumnSet.AddColumns("systemuserid");
            qe.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, loggedInUserId);
            LinkEntity link = qe.AddLink("role", "roleid", "roleid", JoinOperator.Inner);
            link.EntityAlias = "role2";
            link.Columns.AddColumns("roleid", "name");
            qe.NoLock = true;
            EntityCollection results = service.RetrieveMultiple(qe);

            tracingService.Trace("before foreach of retrieve logged in users");
            foreach (Entity userrole in results.Entities)
            {
                tracingService.Trace("userrole" + userRoles);
                tracingService.Trace("inside foreach of retrieve logged in users");
                if (userrole.Attributes.Contains("role2.name"))
                {
                    tracingService.Trace("if userrole contains role 2");
                    userRoles.Add((userrole.Attributes["role2.name"] as AliasedValue).Value.ToString());
                }
            }

            return userRoles;
        }

        /// <summary>
        /// Retrieve Custom Configuration Roles
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="tracingService">TracingService tracingService</param>
        /// <returns>return config roles</returns>
        internal List<string> RetrieveCustomConfigurationRoles(IOrganizationService service, ITracingService tracingService)
        {
            tracingService.Trace("Inside RetrieveCustomConfigurationRoles function 2");
            List<string> configRoles = new List<string>();

            QueryExpression qe = new QueryExpression("coke_customconfigurations");
            qe.ColumnSet.AddColumns("coke_value");
            qe.Criteria.AddCondition("coke_key", ConditionOperator.Equal, "KnowledgeArticleCreateRoles");
            qe.NoLock = true;
            EntityCollection results = service.RetrieveMultiple(qe);

            if (results != null && results.Entities.Count > 0)
            {
                tracingService.Trace("if result not null");
                Entity ey = results.Entities[0];
                if (ey.Attributes.Contains("coke_value") && ey["coke_value"] != null)
                {
                    tracingService.Trace("if coke value has values");
                    string roles = ey["coke_value"].ToString();
                    tracingService.Trace("roles" + roles.ToString());
                    configRoles = roles.Split(',').ToList<string>();
                    tracingService.Trace("Configroles comma separated" + configRoles.ToString());
                }
            }

            return configRoles;
        }

        private static string GetOptionSetValueLabel(string entityName, string fieldName, int optionSetValue, IOrganizationService service)
        {
            if (optionSetValue < 1) return string.Empty;

            var attReq = new RetrieveAttributeRequest();

            attReq.EntityLogicalName = entityName;

            attReq.LogicalName = fieldName;

            attReq.RetrieveAsIfPublished = true;

            var attResponse = (RetrieveAttributeResponse)service.Execute(attReq);

            var attMetadata = (EnumAttributeMetadata)attResponse.AttributeMetadata;

            return attMetadata.OptionSet.Options.Where(x => x.Value == optionSetValue).FirstOrDefault().Label.UserLocalizedLabel.Label;
        }

        internal void ClearRelatedEntities(IOrganizationService service, ITracingService tracingService, Entity target, String schema, String entityName, String field)
        {
            var qe = new QueryExpression(schema);
            qe.ColumnSet.AddColumns(field);
            qe.Criteria.AddCondition("knowledgearticleid", ConditionOperator.Equal, target.Id);
            var results = service.RetrieveMultiple(qe);

            var collection = new EntityReferenceCollection();

            foreach (Entity entity in results.Entities)
            {
                collection.Add(new EntityReference(entityName, entity.GetAttributeValue<System.Guid>(field)));
            }

            service.Disassociate(KnowledgeArticle.EntityLogicalName, target.Id, new Relationship(schema), collection);
        }

        internal void AssociateRegionRelatedEntities(IOrganizationService service, ITracingService tracingService, KnowledgeArticle target)
        {
            if (target.coke_Region == null) return;

            List<String> items = new List<String>();

            foreach(String item in target.coke_Region.Replace("[", "").Replace("]", "").Split(','))
            {
                items.Add(item.Replace("\"", ""));
            }

            // get region
            var qeRegion = new QueryExpression("coke_region");
            qeRegion.ColumnSet.AddColumns("coke_regionid","coke_name");
            qeRegion.Criteria.FilterOperator = LogicalOperator.Or;
            items.ForEach(item => qeRegion.Criteria.AddCondition("coke_name", ConditionOperator.Equal, item));
            var resultsRegion = service.RetrieveMultiple(qeRegion);


            // get existing relationships
            var qe = new QueryExpression("coke_knowledgearticle_coke_region");
            qe.ColumnSet.AddColumns("coke_regionid");
            qe.Criteria.AddCondition("knowledgearticleid", ConditionOperator.Equal, target.Id);
            var results = service.RetrieveMultiple(qe);

            var disassociationCollection = new EntityReferenceCollection();
            var associationCollection = new EntityReferenceCollection();

            // disassociate
            foreach (Entity entity in results.Entities)
            {
                if (!resultsRegion.Entities.Any(region => ((coke_region)region).coke_regionId == entity.GetAttributeValue<System.Guid>("coke_regionid")))
                {
                    disassociationCollection.Add(new EntityReference(coke_region.EntityLogicalName, entity.GetAttributeValue<System.Guid>("coke_regionid")));
                }
            }

            // associate
            foreach (coke_region region in resultsRegion.Entities)
            {
                if (!results.Entities.Any(entity => ((coke_region)region).coke_regionId == entity.GetAttributeValue<System.Guid>("coke_regionid")))
                {
                    if (region.coke_regionId != null)
                    {
                        associationCollection.Add(new EntityReference(coke_region.EntityLogicalName, (Guid)region.coke_regionId));
                    }
                }
            }


            if (disassociationCollection.Count > 0)
            {
                service.Disassociate(KnowledgeArticle.EntityLogicalName, target.Id, new Relationship("coke_knowledgearticle_coke_region"), disassociationCollection);
            }

            if (associationCollection.Count > 0)
            {
                service.Associate(KnowledgeArticle.EntityLogicalName, target.Id, new Relationship("coke_knowledgearticle_coke_region"), associationCollection);
            }
        }

        internal void AssociateCountryRelatedEntities(IOrganizationService service, ITracingService tracingService, KnowledgeArticle target)
        {

            if (target.coke_Country == null) return;

            List<String> items = new List<String>();

            foreach (String item in target.coke_Country.Replace("[", "").Replace("]", "").Split(','))
            {
                items.Add(item.Replace("\"", ""));
            }

            // get country
            var qeCountry = new QueryExpression("coke_country");
            qeCountry.ColumnSet.AddColumns("coke_countryid", "coke_countryabbr");
            qeCountry.Criteria.FilterOperator = LogicalOperator.Or;
            items.ForEach(item => qeCountry.Criteria.AddCondition("coke_countryabbr", ConditionOperator.Equal, item));
            var resultsCountry = service.RetrieveMultiple(qeCountry);

            // get existing relationships
            var qe = new QueryExpression("coke_knowledgearticle_coke_country");
            qe.ColumnSet.AddColumns("coke_countryid");
            qe.Criteria.AddCondition("knowledgearticleid", ConditionOperator.Equal, target.Id);
            var results = service.RetrieveMultiple(qe);

            var disassociationCollection = new EntityReferenceCollection();
            var associationCollection = new EntityReferenceCollection();

            // disassociate
            foreach (Entity entity in results.Entities)
            {
                if(!resultsCountry.Entities.Any(country => ((coke_country)country).coke_countryId == entity.GetAttributeValue<System.Guid>("coke_countryid"))) 
                { 
                    disassociationCollection.Add(new EntityReference(coke_country.EntityLogicalName, entity.GetAttributeValue<System.Guid>("coke_countryid")));
                }
            }

            // associate
            foreach (coke_country country in resultsCountry.Entities)
            {
                if (!results.Entities.Any(entity => ((coke_country)country).coke_countryId == entity.GetAttributeValue<System.Guid>("coke_countryid")))
                {
                    if(country.coke_countryId != null)
                    { 
                        associationCollection.Add(new EntityReference(coke_country.EntityLogicalName, (Guid)country.coke_countryId));
                    }
                }
            }


            if (disassociationCollection.Count > 0) 
            {
                service.Disassociate(KnowledgeArticle.EntityLogicalName, target.Id, new Relationship("coke_knowledgearticle_coke_country"), disassociationCollection);
            }

            if (associationCollection.Count > 0)
            {
                service.Associate(KnowledgeArticle.EntityLogicalName, target.Id, new Relationship("coke_knowledgearticle_coke_country"), associationCollection);
            }
        }
    }
}