﻿// <copyright file="EscalationTaskHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the EscalationTaskHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// EscalationTaskHelper class.
    /// </summary>
    public class EscalationTaskHelper
    {
        /// <summary>
        /// Set Owner As Team And Update Queue item On create And Update Of Owner
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="coke_escalationtaskEntity">Target Entity</param>
        /// <returns>Return the owner</returns>
        public EntityReference SetOwnerAsTeamAndUpdateQueueitemOncreateAndUpdateOfOwner(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, coke_escalationtask coke_escalationtaskEntity)
        {
            EntityReference owner = null;
            EntityReference newOwner = null;
            if (context.MessageName == "Create" && coke_escalationtaskEntity.OwnerId == null)
            {
                owner = adminService.Retrieve("coke_escalationtask", coke_escalationtaskEntity.Id, new ColumnSet("ownerid")).ToEntity<coke_escalationtask>().OwnerId;
            }
            else if (context.MessageName == "Update" && coke_escalationtaskEntity.OwnerId == null)
            {
                return null;
            }
            else
            {
                owner = coke_escalationtaskEntity.OwnerId;
            }

            if (owner.LogicalName != Team.EntityLogicalName)
            {
                QueryExpression query = new QueryExpression(SystemUser.EntityLogicalName);
                query.ColumnSet.AddColumn("coke_primaryteamid");
                query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, owner.Id);
                LinkEntity link = new LinkEntity(SystemUser.EntityLogicalName, Team.EntityLogicalName, "coke_primaryteamid", "teamid", JoinOperator.Inner);
                link.EntityAlias = "team";
                link.Columns.AddColumns("queueid");
                query.LinkEntities.Add(link);
                query.NoLock = true;
                var user = adminService.RetrieveMultiple(query).Entities[0].ToEntity<SystemUser>();
                EntityReference queueId = user.GetAttributeValue<AliasedValue>("team.queueid") != null ? user.GetAttributeValue<AliasedValue>("team.queueid").Value as EntityReference : null;
                newOwner = user.coke_PrimaryTeamId;

                if (newOwner == null)
                {
                    throw new InvalidPluginExecutionException("Primary team is mandatory to create or assign case.");
                }

                coke_escalationtask coke_escalationtaskToUpdate = new coke_escalationtask();
                coke_escalationtaskToUpdate.Id = coke_escalationtaskEntity.Id;
                coke_escalationtaskToUpdate.OwnerId = newOwner;
                adminService.Update(coke_escalationtaskToUpdate);
                this.ExecuteAddToQueueItemRequest(adminService, queueId, coke_escalationtaskEntity.ToEntityReference(), owner);
                return newOwner;
            }
            else
            {
                EntityReference queueId = service.Retrieve("team", owner.Id, new ColumnSet("queueid")).ToEntity<Team>().QueueId;
                this.ExecuteAddToQueueItemRequest(adminService, queueId, coke_escalationtaskEntity.ToEntityReference(), null);
                newOwner = owner;
                return newOwner;
            }
        }

        /// <summary>
        /// Share Case with Escalation Task Team
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="coke_escalationtaskEntity">Target Entity</param>
        /// <param name="newOwner">EntityReference newOwner</param>
        public void ShareCasewithEscalationTaskTeam(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, coke_escalationtask coke_escalationtaskEntity, EntityReference newOwner)
        {
            if (coke_escalationtaskEntity.RegardingObjectId != null)
            {
                QueryExpression queryTeam = new QueryExpression(Team.EntityLogicalName);
                queryTeam.ColumnSet.AddColumns("teamid", "name");
                queryTeam.Criteria.AddCondition("teamid", ConditionOperator.Equal, newOwner.Id);
                queryTeam.NoLock = true;
                var owningTeam = adminService.RetrieveMultiple(queryTeam).Entities[0].ToEntity<Team>();
                if (owningTeam != null)
                {
                    Guid teamId = owningTeam.Id;
                    tracingService.Trace("teamId{0} ", teamId);
                    IList<Entity> teamRole = GetTeamRole(adminService, teamId);
                    Entity configRole = GetConfigValueForSecurityRole(adminService);
                    List<string> teamRoleNames = teamRole.Select(x => x.GetAttributeValue<string>("name").ToString()).ToList();
                    if (teamRoleNames.Any(x => x == configRole.GetAttributeValue<string>("coke_value")))
                    {
                        QueryExpression query = new QueryExpression(Incident.EntityLogicalName);
                        query.Criteria.AddCondition("incidentid", ConditionOperator.Equal, coke_escalationtaskEntity.RegardingObjectId.Id);
                        query.NoLock = true;
                        var regardingCase = adminService.RetrieveMultiple(query).Entities[0].ToEntity<Incident>();
                        var teamReference = new EntityReference(Team.EntityLogicalName, newOwner.Id);
                        GrantAccessRequest grant = new GrantAccessRequest();
                        grant.Target = new EntityReference(regardingCase.LogicalName, regardingCase.Id);

                        PrincipalAccess principal = new PrincipalAccess();
                        principal.Principal = teamReference;
                        principal.AccessMask = AccessRights.ReadAccess;
                        grant.PrincipalAccess = principal;
                        try
                        {
                            adminService.Execute(grant);
                        }
                        catch (Exception)
                        {
                            throw new InvalidPluginExecutionException("Error during plugin execution");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Share Case with Escalation Task Team On Update
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="coke_escalationtaskEntity">Target Entity</param>
        /// <param name="newOwner">EntityReference newOwner</param>
        /// <param name="postImage">Entity postImage</param>
        public void ShareCasewithEscalationTaskTeamOnUpdate(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, coke_escalationtask coke_escalationtaskEntity, EntityReference newOwner, coke_escalationtask postImage)
        {
            if (postImage.RegardingObjectId != null && postImage.OwnerId != null)
            {
                Guid teamId = postImage.OwnerId.Id;
                tracingService.Trace("teamId{0} ", teamId);
                IList<Entity> teamRole = GetTeamRole(adminService, teamId);
                Entity configRole = GetConfigValueForSecurityRole(adminService);
                List<string> teamRoleNames = teamRole.Select(x => x.GetAttributeValue<string>("name").ToString()).ToList();
                if (teamRoleNames.Any(x => x == configRole.GetAttributeValue<string>("coke_value")))
                {
                    var teamReference = new EntityReference(Team.EntityLogicalName, postImage.OwnerId.Id);
                    GrantAccessRequest grant = new GrantAccessRequest();
                    grant.Target = new EntityReference(postImage.RegardingObjectId.LogicalName, postImage.RegardingObjectId.Id);

                    PrincipalAccess principal = new PrincipalAccess();
                    principal.Principal = teamReference;
                    principal.AccessMask = AccessRights.ReadAccess;
                    grant.PrincipalAccess = principal;
                    try
                    {
                        adminService.Execute(grant);
                    }
                    catch (Exception)
                    {
                        throw new InvalidPluginExecutionException("Error during plugin execution");
                    }
                }
            }
        }

        /// <summary>
        /// Execute Add To Queue Item Request
        /// </summary>
        /// <param name="adminService">IOrganizationService adminService</param>
        /// <param name="destinationQueueId">EntityReference destinationQueueId</param>
        /// <param name="coke_escalationtaskEntityReference">EntityReference escalation task</param>  
        /// <param name="workerId">EntityReference workerId</param>  
        public void ExecuteAddToQueueItemRequest(IOrganizationService adminService, EntityReference destinationQueueId, EntityReference coke_escalationtaskEntityReference, EntityReference workerId)
        {
            AddToQueueRequest req = new AddToQueueRequest()
            {
                DestinationQueueId = destinationQueueId.Id,
                Target = coke_escalationtaskEntityReference
            };
            req.QueueItemProperties = new QueueItem()
            {
                WorkerId = workerId
            };
            adminService.Execute(req);
        }

        /// <summary>
        /// Retrieve Sla By parameters
        /// </summary>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="entityType">integer entityType</param>
        /// <param name="region">EntityReference region</param>  
        /// <returns>return sla</returns>
        public EntityReference RetrieveSlaByparameters(IOrganizationService adminService, int entityType, EntityReference region)
        {
            QueryExpression query = new QueryExpression(coke_slaconfiguration.EntityLogicalName);
            query.ColumnSet.AddColumns("slaid");
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            if (region != null)
            {
                query.Criteria.AddCondition("coke_regionid", ConditionOperator.Equal, region.Id);
            }
            else
            {
                query.Criteria.AddCondition("coke_regionid", ConditionOperator.Null);
            }

            query.Criteria.AddCondition("slaid", ConditionOperator.NotNull);

            query.NoLock = true;
            var slas = adminService.RetrieveMultiple(query);
            if (slas != null && slas.Entities != null && slas.Entities.Count > 0)
            {
                return slas.Entities[0]["slaid"] as EntityReference;
            }

            return null;
        }

        /// <summary>
        /// Populate Escalated By
        /// </summary>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="case">Incident target</param>  
        public coke_area getArea(IOrganizationService adminService, ITracingService tracingService, EntityReference target)
        {
            var _task = adminService.Retrieve(target.LogicalName, target.Id, new ColumnSet("coke_areaid")).ToEntity<coke_escalationtask>();
            var _area = adminService.Retrieve(coke_area.EntityLogicalName, _task.coke_AreaId.Id, new ColumnSet("coke_name","coke_teamprefix")).ToEntity<coke_area>();
            tracingService.Trace($"Retrieved area: {_area.coke_name}");
            return _area;
        }

        /// <summary>
        /// Set SLA On Pre Operation Target Entity
        /// </summary>
        /// <param name="context">IPluginExecutionContext context</param>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>
        /// <param name="target">Entity target</param>  
        /// <param name="preImage">Entity preImage</param>
        /// <returns>return sla reference</returns>
        internal EntityReference SetSLAOnPreOperationTargetEntity(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, coke_escalationtask target, coke_escalationtask preImage)
        {
            EntityReference ownerRef = null;
            EntityReference region = null;
            EntityReference slaRef = null;
            tracingService.Trace("SetSLAOnPreOperationTargetEntity method");

            if (target.OwnerId != null)
            {
                ownerRef = target.OwnerId;
            }
            else if (context.MessageName != "Create")
            {
                ownerRef = preImage.OwnerId;
            }

            tracingService.Trace("SetSLAOnPreOperationTargetEntity method4");

            if (context.MessageName == "Create" && ownerRef == null)
            {
                ownerRef = new EntityReference(SystemUser.EntityLogicalName, context.UserId);
            }

            if (ownerRef != null && ownerRef.LogicalName == SystemUser.EntityLogicalName)
            {
                tracingService.Trace("Owner is User");
                QueryExpression query = new QueryExpression(SystemUser.EntityLogicalName);
                query.ColumnSet.AddColumns("coke_regionid");
                tracingService.Trace("Owner is User1");

                query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, ownerRef.Id);
                LinkEntity link = new LinkEntity(SystemUser.EntityLogicalName, Team.EntityLogicalName, "coke_primaryteamid", "teamid", JoinOperator.Inner);
                link.Columns.AddColumns("coke_regionid");
                link.EntityAlias = "team";
                query.LinkEntities.Add(link);
                query.NoLock = true;
                var user = adminService.RetrieveMultiple(query).Entities[0];
                tracingService.Trace("Owner is User2");

                if (user.GetAttributeValue<AliasedValue>("team.coke_regionid") != null)
                {
                    region = user.GetAttributeValue<AliasedValue>("team.coke_regionid").Value as EntityReference;
                }
                else if (user.GetAttributeValue<EntityReference>("coke_regionid") != null)
                {
                    tracingService.Trace("Owner is User3");

                    region = user.GetAttributeValue<EntityReference>("coke_regionid");
                }
            }
            else if (ownerRef != null && ownerRef.LogicalName == Team.EntityLogicalName)
            {
                tracingService.Trace("Owner is team");

                var team = adminService.Retrieve("team", ownerRef.Id, new ColumnSet("coke_regionid")).ToEntity<Team>();
                if (team.coke_RegionId != null)
                {
                    region = team.coke_RegionId;
                }
            }

            tracingService.Trace("SetSLAOnPreOperationTargetEntity method5");

            if (region == null)
            {
                tracingService.Trace("Region is null: owner: ", ownerRef != null ? ownerRef.Id.ToString() : "null");
                return null;
            }

            if (slaRef == null)
            {
                slaRef = this.RetrieveSlaByparameters(adminService, (int)coke_slaconfiguration_coke_entitytype.EscalationTask, region);
                tracingService.Trace("SLA Retrieve" + slaRef);
            }

            tracingService.Trace("SetSLAOnPreOperationTargetEntity method7");

            if (slaRef == null)
            {
                slaRef = this.RetrieveSlaByparameters(adminService, (int)coke_slaconfiguration_coke_entitytype.EscalationTask, null);
                tracingService.Trace("Last Retrieve" + slaRef);
            }

            if (slaRef != null)
            {
                target["slaid"] = slaRef;
                return slaRef;
            }

            return null;
        }

        /// <summary>
        /// Auto Populate Fields
        /// </summary>
        /// <param name="context">IPluginExecutionContext context</param>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="adminService">IOrganizationService adminService</param>
        /// <param name="tracingService">ITracingService tracingService</param>
        /// <param name="target">Entity target</param>
        internal void AutoPopulateFields(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, coke_escalationtask target)
        {
            if (target.RegardingObjectId != null)
            {
                tracingService.Trace("Regarding Object Id" + target.RegardingObjectId.Id.ToString());
                Incident caseEntity = service.Retrieve("incident", target.RegardingObjectId.Id, new ColumnSet("coke_workcountry", "coke_workregionid", "coke_hrprocess", "coke_hrsubprocessid", "coke_categoryid", "coke_urgency", "casetypecode", "customerid", "prioritycode","coke_area")).ToEntity<Incident>();

                if (caseEntity.Attributes.Contains("coke_workcountry") && !target.Attributes.Contains("coke_workcountry"))
                {
                    target.coke_workcountry = caseEntity.coke_workcountry;
                }

                if (caseEntity.Attributes.Contains("coke_workregionid") && !target.Attributes.Contains("coke_workregionid"))
                {
                    target.coke_workregionid = caseEntity.coke_workregionid;
                }

                if (caseEntity.Attributes.Contains("coke_hrprocess") && !target.Attributes.Contains("coke_hrprocessid"))
                {
                    target.coke_HrProcessId = caseEntity.coke_HRProcess;
                }

                if (caseEntity.Attributes.Contains("coke_hrsubprocessid") && !target.Attributes.Contains("coke_hrsubprocessid"))
                {
                    target.coke_HRSubprocessId = caseEntity.coke_HRSubprocessId;
                }

                if (caseEntity.Attributes.Contains("coke_categoryid") && !target.Attributes.Contains("coke_categoryid"))
                {
                    target.coke_CategoryId = caseEntity.coke_CategoryId;
                }

                if (caseEntity.Attributes.Contains("coke_urgency") && !target.Attributes.Contains("coke_urgency"))
                {
                    target.coke_urgency = (coke_escalationtask_coke_urgency)caseEntity.coke_Urgency;
                }

                if (caseEntity.Attributes.Contains("casetypecode") && !target.Attributes.Contains("coke_casetype"))
                {
                    target.coke_casetype = (coke_escalationtask_coke_casetype)caseEntity.CaseTypeCode;
                }

                if (caseEntity.Attributes.Contains("customerid") && !target.Attributes.Contains("coke_customer"))
                {
                    target.coke_customer = caseEntity.CustomerId;
                }

                if (caseEntity.Attributes.Contains("prioritycode") && !target.Attributes.Contains("coke_priority"))
                {
                    target.coke_priority = (coke_escalationtask_coke_priority)caseEntity.PriorityCode;
                }

                if (caseEntity.Attributes.Contains("coke_area") && !target.Attributes.Contains("coke_areaid"))
                {
                    target.coke_AreaId = caseEntity.coke_Area;
                }
            }
        }

        /// <summary>
        /// Get Team Role   
        /// </summary>
        /// <param name="service">IOrganizationService service</param>
        /// <param name="teamId">Guid teamId</param>
        /// <returns>return team role</returns>
        private static IList<Entity> GetTeamRole(IOrganizationService service, Guid teamId)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
            <entity name='role'>
            <attribute name='name' />
            <attribute name='businessunitid' />
            <attribute name='roleid' />
            <order attribute='name' descending='false' />
            <link-entity name='teamroles' from='roleid' to='roleid' visible='false' intersect='true'>
            <link-entity name='team' from='teamid' to='teamid' alias='ab'>
            <filter type='and'>
            <condition attribute='teamid' operator='eq' value= '" + teamId + "' /> </filter> </link-entity></link-entity> </entity></fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList();
        }

        /// <summary>
        /// Get Config Value For Security Role
        /// </summary>
        /// <param name="service">IOrganizationService service</param>
        /// <returns>return config values for security role</returns>
        private static Entity GetConfigValueForSecurityRole(IOrganizationService service)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            <entity name='coke_customconfigurations'>
            <attribute name='coke_customconfigurationsid' />
            <attribute name='coke_key' />
            <attribute name='coke_value' />
            <order attribute='coke_key' descending='false' />
            <filter type='and'>
            <condition attribute='coke_key' operator='eq' value='Tier2Role' />
            </filter>
            </entity>
            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault();
        }
    }
}