﻿// <copyright file="QueueItemHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the QueueItemHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// QueueItemHelper class.
    /// </summary>
    public class QueueItemHelper
    {
        /// <summary>
        /// Update Owner On Case
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>  
        /// <param name="target">QueueItem target</param>
        /// <param name="postImage">Entity PostImage</param>
        /// <returns>Return the owner's team</returns>
        public EntityReference UpdateOwnerOnCase(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, QueueItem target, QueueItem postImage)
        {
            QueryExpression query = new QueryExpression(Team.EntityLogicalName);
            query.ColumnSet.AddColumn("teamid");
            query.Criteria.AddCondition("queueid", ConditionOperator.Equal, target.QueueId.Id);

            query.NoLock = true;
            var teams = adminService.RetrieveMultiple(query).Entities.ToList<Entity>();
            if (teams != null && teams.Count > 0)
            {
                Entity objectid = service.Retrieve(postImage.ObjectId.LogicalName, postImage.ObjectId.Id, new ColumnSet("ownerid"));
                if (teams.All((team) => { return team.Id != ((EntityReference)objectid["ownerid"]).Id; }))
                {
                    Entity objectToupdate = new Entity(objectid.LogicalName);
                    objectToupdate.Id = objectid.Id;
                    objectToupdate["ownerid"] = teams[0].ToEntityReference();
                    adminService.Update(objectToupdate);
                    return teams[0].ToEntityReference();
                }
            }

            return null;
        }

        /// <summary>
        /// Share Parent Case With Child Case Team On Update
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>  
        /// <param name="target">QueueItem target</param>
        /// <param name="newTeam">EntityReference newTeam</param>
        /// <param name="postImage">Entity PostImage</param>
        public void ShareParentCaseWithChildCaseTeamOnUpdate(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, QueueItem target, EntityReference newTeam, QueueItem postImage)
        {
            Entity objectId = service.Retrieve(postImage.ObjectId.LogicalName, postImage.ObjectId.Id, new ColumnSet("ownerid", "parentcaseid"));
            if (objectId != null && objectId.Contains("parentcaseid") && ((EntityReference)objectId["parentcaseid"]).Id != Guid.Empty)
            {
                Guid teamId = newTeam.Id;
                IList<Entity> teamRole = GetTeamRole(adminService, teamId);
                Entity configRole = GetConfigValueForSecurityRole(adminService);
                List<string> teamRoleNames = teamRole.Select(x => x.GetAttributeValue<string>("name").ToString()).ToList();
                Entity parentCase = service.Retrieve(postImage.ObjectId.LogicalName, ((EntityReference)objectId["parentcaseid"]).Id, new ColumnSet("incidentid"));
                if (teamRoleNames.Any(x => x == configRole.GetAttributeValue<string>("coke_value")))
                {
                    var teamReference = new EntityReference(Team.EntityLogicalName, postImage.OwnerId.Id);
                    GrantAccessRequest grant = new GrantAccessRequest();
                    grant.Target = new EntityReference(parentCase.LogicalName, parentCase.Id);

                    PrincipalAccess principal = new PrincipalAccess();
                    principal.Principal = teamReference;
                    principal.AccessMask = AccessRights.ReadAccess;
                    grant.PrincipalAccess = principal;
                    try
                    {
                        adminService.Execute(grant);
                    }
                    catch (Exception)
                    {
                        throw new InvalidPluginExecutionException("Error during plugin execution");
                    }
                }
            }
        }

        /// <summary>
        /// Share Case with Escalation Task Team On Update
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>  
        /// <param name="target">QueueItem target</param>
        /// <param name="newTeam">EntityReference newTeam</param>
        /// <param name="postImage">Entity PostImage</param>
        public void ShareCasewithEscalationTaskTeamOnUpdate(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, QueueItem target, EntityReference newTeam, QueueItem postImage)
        {
            Entity objectId = service.Retrieve(postImage.ObjectId.LogicalName, postImage.ObjectId.Id, new ColumnSet("ownerid", "regardingobjectid"));
            if (objectId != null && objectId.Contains("regardingobjectid") && ((EntityReference)objectId["regardingobjectid"]).Id != Guid.Empty)
            {
                Guid teamId = newTeam.Id;
                IList<Entity> teamRole = GetTeamRole(adminService, teamId);
                Entity configRole = GetConfigValueForSecurityRole(adminService);
                List<string> teamRoleNames = teamRole.Select(x => x.GetAttributeValue<string>("name").ToString()).ToList();
                if (teamRoleNames.Any(x => x == configRole.GetAttributeValue<string>("coke_value")))
                {
                    QueryExpression query = new QueryExpression(Incident.EntityLogicalName);
                    query.Criteria.AddCondition("incidentid", ConditionOperator.Equal, ((EntityReference)objectId["regardingobjectid"]).Id);
                    query.NoLock = true;
                    var regardingCase = adminService.RetrieveMultiple(query).Entities[0].ToEntity<Incident>();
                    var teamReference = new EntityReference(Team.EntityLogicalName, postImage.OwnerId.Id);
                    GrantAccessRequest grant = new GrantAccessRequest();
                    grant.Target = new EntityReference(regardingCase.LogicalName, regardingCase.Id);

                    PrincipalAccess principal = new PrincipalAccess();
                    principal.Principal = teamReference;
                    principal.AccessMask = AccessRights.ReadAccess;
                    grant.PrincipalAccess = principal;
                    try
                    {
                        adminService.Execute(grant);
                    }
                    catch (Exception)
                    {
                        throw new InvalidPluginExecutionException("Error during plugin execution");
                    }
                }
            }
        }

        /// <summary>
        /// Populate Task Current Time
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">IOrganizationService adminService</param>  
        /// <param name="tracingService">ITracingService tracingService</param>  
        /// <param name="queueItemEntity">QueueItem queueItemEntity</param>
        /// <param name="postImage">Entity PostImage</param>
        internal void PopulateTaskCurrentTime(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, QueueItem queueItemEntity, QueueItem postImage)
        {
            Task taskEntity = new Task();

            if (postImage != null && postImage.Attributes.Contains("workerid") && postImage.Attributes["workerid"] != null)
            {
                tracingService.Trace("Inside PostImage Update");
                tracingService.Trace(postImage.ObjectId.Id.ToString());
                taskEntity.Id = postImage.ObjectId.Id;
                tracingService.Trace(postImage.ObjectId.Id.ToString());
                taskEntity.Attributes["coke_workstarteddate"] = DateTime.UtcNow;
                tracingService.Trace("Current time" + DateTime.UtcNow);
            }
            else if (queueItemEntity != null)
            {
                tracingService.Trace("Inside target Create");
                taskEntity.Id = queueItemEntity.ObjectId.Id;
                taskEntity.Attributes["coke_workstarteddate"] = DateTime.UtcNow;
            }

            service.Update(taskEntity);
        }

        /// <summary>
        /// Get Team Role
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="teamId">Guid teamId</param>
        /// <returns>returns team role</returns>
        private static IList<Entity> GetTeamRole(IOrganizationService service, Guid teamId)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
            <entity name='role'>
            <attribute name='name' />
            <attribute name='businessunitid' />
            <attribute name='roleid' />
            <order attribute='name' descending='false' />
            <link-entity name='teamroles' from='roleid' to='roleid' visible='false' intersect='true'>
            <link-entity name='team' from='teamid' to='teamid' alias='ab'>
            <filter type='and'>
            <condition attribute='teamid' operator='eq' value= '" + teamId + "' /> </filter> </link-entity></link-entity> </entity></fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList();
        }

        /// <summary>
        /// Get Config Value For Security Role
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <returns>returns config role</returns>
        private static Entity GetConfigValueForSecurityRole(IOrganizationService service)
        {
            string fetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            <entity name='coke_customconfigurations'>
            <attribute name='coke_customconfigurationsid' />
            <attribute name='coke_key' />
            <attribute name='coke_value' />
            <order attribute='coke_key' descending='false' />
            <filter type='and'>
            <condition attribute='coke_key' operator='eq' value='Tier2Role' />
            </filter>
            </entity>
            </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault();
        }
    }
}