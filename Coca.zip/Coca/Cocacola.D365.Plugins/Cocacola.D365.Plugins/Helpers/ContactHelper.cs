﻿// <copyright file="ContactHelper.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the ContactHelper Class.</summary>

namespace Cocacola.D365.Plugins.Helpers
{
    using Cocacola.D365.Plugins;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// ContactHelper class.
    /// </summary>
    public class ContactHelper
    {
        /// <summary>
        /// Create Post On Contact Based On Authentication
        /// </summary>
        /// <param name="context">IPluginExecution Context</param>
        /// <param name="service">Organization Service</param>
        /// <param name="adminService">Admin Organization Service</param>  
        /// <param name="tracingService">Tracing Service</param>  
        /// <param name="target">Contact target</param>
        /// <param name="postImage">Contact postImage</param>
        internal void CreatePostOnContactBasedOnAuthentication(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Contact target, Contact postImage)
        {
            if (postImage.coke_AuthenticationStatus == coke_contact_coke_authenticationstatus.Authenticated || postImage.coke_AuthenticationStatus == coke_contact_coke_authenticationstatus.AuthenticationFailed)
            {
                Post post = new Post();
                post.RegardingObjectId = target.ToEntityReference();
                post.Text = "Authentication attempted. Status: " + (postImage.coke_AuthenticationStatus == coke_contact_coke_authenticationstatus.Authenticated ? "Pass" : "Fail") + ". Fields used: " + postImage.coke_AuthenticationQuestionsPassed;
                service.Create(post);
            }
        }

        internal void UpdateAddress3CountryField(IPluginExecutionContext context, IOrganizationService service, IOrganizationService adminService, ITracingService tracingService, Contact target)
        {
            EntityReference country = target.coke_countryid;
            coke_country countryEntity = service.Retrieve("coke_country", target.coke_countryid.Id, new ColumnSet("coke_name", "coke_countryabbr")).ToEntity<coke_country>();
            target.Address3_Country = countryEntity.coke_CountryAbbr;
        }
    }
}
