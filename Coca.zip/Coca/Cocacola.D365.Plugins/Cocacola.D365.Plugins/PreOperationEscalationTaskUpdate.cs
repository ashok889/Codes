﻿// <copyright file="PreOperationEscalationTaskUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PreOperationEscalationTaskUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "coke_escalationtask", StageEnum.PreOperation, ExecutionModeEnum.Synchronous, "ownerid", "Coke_PreOperationEscalationTaskUpdate", 1, IsolationModeEnum.Sandbox, Image1Name = "PreImage", Image1Type = ImageTypeEnum.PreImage, Image1Attributes = "ownerid")]

    /// <summary>
    /// PreOperationEscalationTaskUpdate Plugin.
    /// </summary>
    public class PreOperationEscalationTaskUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOperationEscalationTaskUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            EscalationTaskHelper helper = new EscalationTaskHelper();
            coke_escalationtask target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<coke_escalationtask>() : null;

            coke_escalationtask preImage = context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage") ?
               context.PreEntityImages["PreImage"].ToEntity<coke_escalationtask>() : null;
            if (context.MessageName.Equals("Update", StringComparison.OrdinalIgnoreCase) && target != null && (target.Attributes.Contains("ownerid") || target.Attributes.Contains("coke_escalationtype") || target.Attributes.Contains("prioritycode")))
            {
                tracingService.Trace("Inside Update");
                helper.SetSLAOnPreOperationTargetEntity(context, service, adminService, tracingService, target, preImage);
            }
        }
    }
}
