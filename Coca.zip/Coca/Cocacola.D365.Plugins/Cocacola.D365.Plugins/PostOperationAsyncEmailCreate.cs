﻿// <copyright file="PostOperationAsyncEmailCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationAsyncEmailCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Create, "email", StageEnum.PostOperation, ExecutionModeEnum.Asynchronous, "", "Coke_PostOperationAsyncEmailCreate", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationAsyncEmailCreate Plugin.
    /// </summary>
    public class PostOperationAsyncEmailCreate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationAsyncEmailCreate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            EmailHelper helper = new EmailHelper();
            Email targetEmail = (context.InputParameters["Target"] as Entity).ToEntity<Email>();
            tracingService.Trace("AssignCase Method");
            helper.SetIsUnknownSenderFlag(context, service, adminService, tracingService, targetEmail);
        }
    }
}
