﻿// <copyright file="PostOperationAsyncPhoneCallUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationAsyncPhoneCallUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "phonecall", StageEnum.PostOperation, ExecutionModeEnum.Asynchronous, "coke_authenticationstatus", "Coke_PostOperationAsyncPhoneCallUpdate", 1, IsolationModeEnum.Sandbox, Image1Name = "PostImage", Image1Type = ImageTypeEnum.PostImage, Image1Attributes = "from,coke_authenticationquestionspassed,coke_authenticationstatus,directioncode")]

    /// <summary>
    /// PostOperationAsyncPhoneCallUpdate Plugin.
    /// </summary>
    public class PostOperationAsyncPhoneCallUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationAsyncPhoneCallUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            PhoneCallHelper helper = new PhoneCallHelper();
            tracingService.Trace("PhonecallAsyncUpdatePlugin");

            PhoneCall target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<PhoneCall>() : null;

            PhoneCall postImage = context.PostEntityImages != null && context.PostEntityImages.Contains("PostImage") ?
                 context.PostEntityImages["PostImage"].ToEntity<PhoneCall>() : null;

            if (postImage != null && target != null && target.Attributes.Contains("coke_authenticationstatus") && postImage.DirectionCode == false)
            {
                tracingService.Trace("Initiating PostCreation");
                helper.CreatePostOnContactBasedOnAuthentication(context, service, adminService, tracingService, target, postImage);
            }
        }
    }
}
