﻿// <copyright file="PostOperationCaseUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationCaseUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "incident", StageEnum.PostOperation, ExecutionModeEnum.Synchronous, "ownerid,statecode,parentcaseid", "Coke_PostOperationCaseUpdate", 1, IsolationModeEnum.Sandbox, Image1Attributes = "ownerid,parentcaseid", Image1Name = "PostImage", Image1Type = ImageTypeEnum.PostImage, Image2Name = "PreImage", Image2Type = ImageTypeEnum.PreImage, Image2Attributes = "ownerid")]

    /// <summary>
    /// PostOperationCaseUpdate Plugin.
    /// </summary>
    public class PostOperationCaseUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationCaseUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            CaseHelper helper = new CaseHelper();
            Incident target = null;
            EntityReference newOwner = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<Incident>() : null;
            Incident postImage = context.PostEntityImages != null && context.PostEntityImages.Contains("PostImage") ?
                 context.PostEntityImages["PostImage"].ToEntity<Incident>() : null;

            Incident preImage = context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage") ?
                 context.PreEntityImages["PreImage"].ToEntity<Incident>() : null;
            if (context.Depth > 1)
            {
                tracingService.Trace("Depth return: " + context.Depth);
                return;
            }

            if (target != null && target.Attributes.Contains("ownerid"))
            {
                tracingService.Trace("Inside PostOperation Case Update"); 
                newOwner = helper.SetOwnerAsTeamAndUpdateQueueitemOncreateAndUpdateOfOwner(context, service, adminService, tracingService, target);
                tracingService.Trace("preImage {0}", preImage);
                if (newOwner != null && preImage != null && newOwner.Id != preImage.OwnerId.Id)
                {
                    tracingService.Trace("Inside postOperation If");
                    helper.ShareParentCaseWithChildCaseTeamOnUpdate(context, service, adminService, tracingService, target, newOwner, postImage);
                }
            }

            if (target != null && target.Attributes.Contains("statecode"))
            {
                tracingService.Trace("Inside Update");
                helper.SetOwnerAsTeamAndUpdateQueueitemOnCaseReactivation(context, service, adminService, tracingService, target, postImage);
            }
        }
    }
}
