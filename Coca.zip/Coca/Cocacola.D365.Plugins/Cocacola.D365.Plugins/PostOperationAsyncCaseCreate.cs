﻿// <copyright file="PostOperationAsyncCaseCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationAsyncCaseCreate Plugin.</summary>
//.....

namespace Cocacola.D365.Plugins
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;
    

    [CrmPluginRegistration( MessageNameEnum.Create, 
                            "incident", 
                            StageEnum.PostOperation, 
                            ExecutionModeEnum.Asynchronous, 
                            "",
                            "Coke_PostOperationAsyncCaseCreate",
                            1, 
                            IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationAsyncCaseCreate Plugin.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class PostOperationAsyncCaseCreate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostOperationAsyncCaseCreate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            CaseHelper helper = new CaseHelper();
            Incident targetIncident = (context.InputParameters["Target"] as Entity).ToEntity<Incident>();
            tracingService.Trace("AssignCase Method");
            helper.AssignCaseOnCreate(context, service, adminService, tracingService, targetIncident);
        }
    }
}
