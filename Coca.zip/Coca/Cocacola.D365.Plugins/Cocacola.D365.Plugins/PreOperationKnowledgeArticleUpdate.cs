﻿// <copyright file="PreOperationKnowledgeArticleUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PreOperationKnowledgeArticleUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "knowledgearticle", StageEnum.PreOperation, ExecutionModeEnum.Synchronous, "title,subjectid,keywords,description,content,statuscode,coke_geography,coke_region,coke_country", "Coke_PreOperationKnowledgeArticleUpdate", 1, IsolationModeEnum.Sandbox, Image1Attributes = "statuscode,isrootarticle,coke_geography", Image1Name = "PreImage", Image1Type = ImageTypeEnum.PreImage)]

    /// <summary>
    /// PreOperationKnowledgeArticleUpdate Plugin.
    /// </summary>
    public class PreOperationKnowledgeArticleUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOperationKnowledgeArticleUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracingService.Trace("UpdatePlugin");

            KnowledgeArticle target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<KnowledgeArticle>() : null;

            KnowledgeArticle preImage = context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage") ?
                 context.PreEntityImages["PreImage"].ToEntity<KnowledgeArticle>() : null;
            KnowledgeArticleHelper helper = new KnowledgeArticleHelper();


            // Check for updates after KB is Approved or published
            if (target != null && preImage != null && preImage.IsRootArticle == false && (target.Attributes.Contains("title") || target.Attributes.Contains("subjectid") || target.Attributes.Contains("keywords")
                || target.Attributes.Contains("description") || target.Attributes.Contains("content")))
            {
                tracingService.Trace("Inside Update");
                helper.ValidateLoggedInUserSecurityRole(context, service, adminService, tracingService, target);
                helper.RestrictKBArticleUpdateAfterApproval(context, service, adminService, tracingService, null, preImage);
            }

            if (target != null && preImage != null && preImage.IsRootArticle == false && target.Attributes.Contains("statuscode"))
            {
                helper.ValidateStatusReason(context, service, adminService, tracingService, target, preImage);
            }

            if (target != null && target.Attributes.ContainsKey("statuscode"))
            {
                var search = helper.AutoPopulateGeographyInKeywords(context, service, adminService, tracingService, target);

                if (!string.IsNullOrEmpty(search))
                {
                    target.Keywords = search;
                }
            }
        }
    }
}
