﻿// <copyright file="PostOperationKnowledgeArticleCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PostOperationKnowledgeArticleCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Create, "knowledgearticle", StageEnum.PostOperation, ExecutionModeEnum.Synchronous, "coke_geography,coke_region,coke_country", "Coke_PostOperationKnowledgeArticleCreate", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PostOperationKnowledgeArticleCreate Plugin.
    /// </summary>
    public class PostOperationKnowledgeArticleCreate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOperationKnowledgeArticleUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            tracingService.Trace("Post Create Plugin");

            KnowledgeArticle target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<KnowledgeArticle>() : null;

            
            KnowledgeArticleHelper helper = new KnowledgeArticleHelper();

            if (target != null)
            {
                switch (target.coke_Geography)
                {
                    case coke_knowledgearticle_coke_geography.Global:
                        helper.ClearRelatedEntities(service, tracingService, target, "coke_knowledgearticle_coke_country", coke_country.EntityLogicalName, "coke_countryid");
                        helper.ClearRelatedEntities(service, tracingService, target, "coke_knowledgearticle_coke_region", coke_region.EntityLogicalName, "coke_regionid");
                        target.coke_Region = "";
                        target.coke_Country = "";
                        break;
                    case coke_knowledgearticle_coke_geography.Regional:
                        helper.ClearRelatedEntities(service, tracingService, target, "coke_knowledgearticle_coke_country", coke_country.EntityLogicalName, "coke_countryid");
                        helper.AssociateRegionRelatedEntities(service, tracingService, target);
                        target.coke_Country = "";
                        break;
                    default:
                        helper.AssociateCountryRelatedEntities(service, tracingService, target);
                        helper.AssociateRegionRelatedEntities(service, tracingService, target);
                        break;
                }
            }
        }
    }
}
