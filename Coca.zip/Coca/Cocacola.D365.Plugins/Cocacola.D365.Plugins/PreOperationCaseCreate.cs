﻿// <copyright file="PreOperationCaseCreate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PreOperationCaseCreate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Create, "incident", StageEnum.PreOperation, ExecutionModeEnum.Synchronous, "", "Coke_PreOperationCaseCreate", 1, IsolationModeEnum.Sandbox)]

    /// <summary>
    /// PreOperationCaseCreate Plugin.
    /// </summary>
    public class PreOperationCaseCreate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOperationCaseCreate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            CaseHelper helper = new CaseHelper();
            Incident target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<Incident>() : null;

            if (context.MessageName.Equals("Create", StringComparison.OrdinalIgnoreCase) && target != null && target.Attributes.Contains("customerid"))
            {
                tracingService.Trace("Inside Create");
                helper.AutoPopulateContactFields(context, service, adminService, tracingService, target);
                helper.AutoPopulateKBSearch(context, service, adminService, tracingService, target ,null);
                helper.SetSLAOnPreOperationTargetEntity(context, service, adminService, tracingService, target, null);
                helper.SetIsExecutive(context, service, adminService, tracingService, target);
            }
        }
    }
}
