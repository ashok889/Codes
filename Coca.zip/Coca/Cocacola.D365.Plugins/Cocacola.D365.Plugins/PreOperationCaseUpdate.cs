﻿// <copyright file="PreOperationCaseUpdate.cs" company="MS">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <summary>Implements the PreOperationCaseUpdate Plugin.</summary>

namespace Cocacola.D365.Plugins
{
    using System;
    using Cocacola.D365.Plugins.Helpers;
    using Microsoft.Xrm.Sdk;

    [CrmPluginRegistration(MessageNameEnum.Update, "incident", StageEnum.PreOperation, ExecutionModeEnum.Synchronous, "ownerid,coke_onbehalfofcustomerid,statecode,statuscode,customerid,title", "Coke_PreOperationCaseUpdate", 1, IsolationModeEnum.Sandbox, Image1Name = "PreImage", Image1Type = ImageTypeEnum.PreImage, Image1Attributes = "ownerid,statecode,coke_workregionid,coke_workcountry,title")]

    /// <summary>
    /// PreOperationCaseUpdate Plugin.
    /// </summary>
    public class PreOperationCaseUpdate : IPlugin
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOperationCaseUpdate"/> class.
        /// </summary>
        /// <param name="serviceProvider">Service Provider</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService adminService = serviceFactory.CreateOrganizationService(null);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            CaseHelper helper = new CaseHelper();
            Incident target = null;
            target = (context.InputParameters != null && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity && ((Entity)context.InputParameters["Target"]) != null) ?
                  ((Entity)context.InputParameters["Target"]).ToEntity<Incident>() : null;

            Incident preImage = context.PreEntityImages != null && context.PreEntityImages.Contains("PreImage") ?
               context.PreEntityImages["PreImage"].ToEntity<Incident>() : null;
            if (context.MessageName.Equals("Update", StringComparison.OrdinalIgnoreCase) && target != null && (target.Attributes.Contains("ownerid") || target.Attributes.Contains("casetypecode") || target.Attributes.Contains("prioritycode")))
            {
                tracingService.Trace("Inside Update");
                helper.SetSLAOnPreOperationTargetEntity(context, service, adminService, tracingService, target, preImage);
            }

            if (target != null && target.Attributes.Contains("statuscode"))
            {
                helper.PopulateEscalatedBy(context, service, adminService, tracingService, target);
            }

            if (target != null && target.Attributes.Contains("statecode"))
            {
                helper.PopulateResolvedAndReactivedTimeFields(context, service, adminService, tracingService, target);
            }

            if (target != null && target.Attributes.Contains("customerid"))
            {
                helper.AutoPopulateContactFieldsOnCustomerUpdate(context, service, adminService, tracingService, target);
            }
            if (preImage != null && target != null && (target.Attributes.Contains("customerid") ||  target.Attributes.Contains("title")))
            {
                helper.AutoPopulateKBSearch(context, service, adminService, tracingService, target , preImage); 
            }

            if (target != null && (target.Attributes.Contains("customerid") || target.Attributes.Contains("coke_onbehalfofcustomerid")))
            {
                helper.SetIsExecutive(context, service, adminService, tracingService, target);
            }
        }
    }
}
