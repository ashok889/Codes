﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ServiceModel;
using System.ServiceModel.Description;

// These namespaces are found in the Microsoft.Xrm.Sdk.dll assembly
// found in the SDK\bin folder.
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using DES.Crm.Core.Common.Security;

// This namespace is found in Microsoft.Crm.Sdk.Proxy.dll assembly
// found in the SDK\bin folder.
using Microsoft.Crm.Sdk.Messages;
using System.Net;
using System.Web;
using System.IO;

namespace RBS.CRM.ViewCreationUtility
{

    /// <summary>
    ///  Prerequisites
    /// only compatible with 8.2
    /// 1. CRMOrgName , USername , Password 
    /// Automation Excelfile Path , DataExcel path needs to be updated 
    /// </summary>
    public class WorkWithViews
    {
        #region Class Level Members
        /// <summary>
        /// Stores the organization service proxy.
        /// </summary>
        private OrganizationServiceProxy _serviceProxy;

        //private const String _customEntityName = "new_bankaccount";
        private Guid _customViewId;
        private Guid _deactivatedViewId;
        private SavedQueryState _viewOriginalState;
        private OptionSetValue _viewOriginalStatus;
        static string path;
        #endregion Class Level Members

        #region How To Sample Code
        /// <summary>
        /// Create a view.
        /// Retrieve Views
        /// Deactivate a view
        /// </summary>
        /// <param name="serverConfig">Contains server connection information.</param>
        /// <param name="promptForDelete">When True, the user will be prompted to delete all
        /// created entities.</param>
        /// <param name="promptForReactivate">When True, the user will be prompted to reactivate
        /// a view that was deactivated.</param>
        ///// 
        public void Run(ServerConnection.Configuration serverConfig, bool promptForDelete, bool promptForReactivate)
        {
            try
            {

                // Connect to the Organization service. 
                // The using statement assures that the service proxy will be properly disposed.
                using (_serviceProxy = new OrganizationServiceProxy(serverConfig.OrganizationUri, serverConfig.HomeRealmUri, serverConfig.Credentials, serverConfig.DeviceCredentials))
                {
                    // This statement is required to enable early-bound type support.
                    _serviceProxy.EnableProxyTypes();

                    WorkWithViews app = new WorkWithViews();
                    // The Run method has an additional parameter to prompt for reactivation of a view.

                    String RenukaSheet = ConfigurationManager.AppSettings["ExcelDataPath"];
                    Application xlApp = new Application();
                    Workbook xlWorkbook = xlApp.Workbooks.Open(RenukaSheet);
                    EntityMetadata[] entityMetadata = GetEntities(_serviceProxy);
                    if (xlWorkbook.Sheets.Count > 0)
                    {
                        foreach (_Worksheet xlWorksheet in xlWorkbook.Sheets)
                        {
                            Range xlRange = xlWorksheet.UsedRange;
                            int rowCount = xlRange.Rows.Count;
                            int colCount = xlRange.Columns.Count;

                            List<string> attributes = new List<string>();
                            for (int i = 1; i <= colCount; i++)
                            {



                                //write the value to the Grid  


                                if (xlRange.Cells[1, i] != null && xlRange.Cells[1, i].Value2 != null)
                                {
                                    attributes.Add(xlRange.Cells[1, i].Value2.ToString().Trim());

                                }
                            }

                            if (attributes != null && attributes.Count > 0)
                            {

                                EntityRecord(attributes, xlRange, entityMetadata, _serviceProxy);


                                // Create entity record
                                break;


                                System.String layoutXm = @"";
                                System.String fetchXm = @"";
                                System.String name = String.Empty;
                                System.String description = String.Empty;
                                System.String returnedTypeCode = String.Empty;




                                //if (xlRange.Cells[j, 1] != null && xlRange.Cells[j, 1].Value2 != null)
                                //{
                                //    var layout = (xlRange.Cells[j, 1].Value2.Trim());
                                //    layoutXm = (layoutXm + layout);
                                //}

                                //if (xlRange.Cells[j, 2] != null && xlRange.Cells[j, 1].Value2 != null)
                                //{
                                //    var fetch = (xlRange.Cells[j, 2].Value2.Trim());
                                //    fetchXm = (fetchXm + fetch);

                                //}
                                //if (xlRange.Cells[j, 3] != null && xlRange.Cells[j, 3].Value2 != null)
                                //{
                                //    name = (xlRange.Cells[j, 3].Value2.Trim());
                                //}
                                //if (xlRange.Cells[j, 4] != null && xlRange.Cells[j, 4].Value2 != null)
                                //{
                                //    description = (xlRange.Cells[j, 4].Value2.Trim());
                                //}
                                //if (xlRange.Cells[j, 5] != null && xlRange.Cells[j, 5].Value2 != null)
                                //{
                                //    returnedTypeCode = (xlRange.Cells[j, 5].Value2.Trim());
                                //}

                                //SavedQuery sq1 = new SavedQuery
                                //{
                                //    Name = name,
                                //    Description = description,
                                //    ReturnedTypeCode = returnedTypeCode,
                                //    FetchXml = fetchXm,
                                //    LayoutXml = layoutXm,
                                //    QueryType = 0
                                //};

                                //_customViewId = _serviceProxy.Create(sq1);
                                //Console.WriteLine("A new view with the name {0} was created.", sq1.Name);



                           
                     


                                }
                            

                        }
                    }

                        // Create the view.
                        //<snippetWorkWithViews1>
                        System.String layoutXml =
@"<grid name='resultset' jump='title' select='1' preview='1' icon='1' object='112' >
  <row name='result' id='incidentid' >
    <cell name='ticketnumber' width='150' imageproviderfunctionname='' imageproviderwebresource='$webresource:' />
    <cell name='statecode' width='125' imageproviderfunctionname='' imageproviderwebresource='$webresource:' />
    <cell name='a_c46adc9d7b2ae71181121458d041f8e8.rbs_accountnumber' width='200' disableSorting='1' imageproviderfunctionname='' imageproviderwebresource='$webresource:' />
    <cell name='createdby' width='150' imageproviderfunctionname='' imageproviderwebresource='$webresource:' />
    <cell name='createdon' width='100' imageproviderfunctionname='' imageproviderwebresource='$webresource:' />
  </row>
</grid>";

                    System.String fetchXml =
                    @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='incident'>
    <attribute name='createdon' />
    <attribute name='createdby' />
    <attribute name='statecode' />
    <attribute name='ticketnumber' />
    <attribute name='incidentid' />
    <order attribute='createdon' descending='true' />
    <filter type='and'>
      <filter type='or'>
        <condition attribute='incidentid' operator='eq' uiname='49424236_1-28/11/2019' uitype='incident' value='{E4682FCC-C911-EA11-A811-000D3AB61631}' />
        <condition attribute='incidentid' operator='eq' uiname='59020302_1-27/11/2019' uitype='incident' value='{8ABDA01A-F710-EA11-A811-000D3AB615A7}' />
      </filter>
    </filter>
    <link-entity name='rbs_mortgage' from='rbs_mortgageid' to='rbs_mortgageid' visible='false' link-type='outer' alias='a_c46adc9d7b2ae71181121458d041f8e8'>
      <attribute name='rbs_accountnumber' />
    </link-entity>
  </entity>
</fetch>";

                    SavedQuery sq = new SavedQuery                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
                    {
                        Name = "A New Custom Public View",
                        Description = "A Saved Query created in code",
                        ReturnedTypeCode = "incident",
                        FetchXml = fetchXml,
                        LayoutXml = layoutXml,
                        QueryType = 0
                    };

             //       _customViewId = _serviceProxy.Create(sq);
             //       Console.WriteLine("A new view with the name {0} was created.", sq.Name);
                    //</snippetWorkWithViews1>


                    // Retrieve Views
                    //<snippetWorkWithViews2>
                    QueryExpression mySavedQuery = new QueryExpression
                    {
                        ColumnSet = new ColumnSet("savedqueryid", "name", "querytype", "isdefault", "returnedtypecode", "isquickfindquery"),
                        EntityName = SavedQuery.EntityLogicalName,
                        Criteria = new FilterExpression
                        {
                            Conditions =
            {
                new ConditionExpression
                {
                    AttributeName = "querytype",
                    Operator = ConditionOperator.Equal,
                    Values = {0}
                },
                new ConditionExpression
                {
                    AttributeName = "returnedtypecode",
                    Operator = ConditionOperator.Equal,
                    Values = {Opportunity.EntityTypeCode}
                }
            }
                        }
                    };
                    RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = mySavedQuery };

                    RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)_serviceProxy.Execute(retrieveSavedQueriesRequest);

                    DataCollection<Entity> savedQueries = retrieveSavedQueriesResponse.EntityCollection.Entities;

                    //Display the Retrieved views
                    foreach (Entity ent in savedQueries)
                    {
                        SavedQuery rsq = (SavedQuery)ent;
                        Console.WriteLine("{0} : {1} : {2} : {3} : {4} : {5},", rsq.SavedQueryId, rsq.Name, rsq.QueryType, rsq.IsDefault, rsq.ReturnedTypeCode, rsq.IsQuickFindQuery);
                    }
                    //</snippetWorkWithViews2>

                    // Deactivate a view
                    //<snippetWorkWithViews3>
                    System.String SavedQueryName = "Closed Opportunities in Current Fiscal Year";
                    QueryExpression ClosedOpportunitiesViewQuery = new QueryExpression
                    {
                        ColumnSet = new ColumnSet("savedqueryid", "statecode", "statuscode"),
                        EntityName = SavedQuery.EntityLogicalName,
                        Criteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression
                                {
                                    AttributeName = "querytype",
                                    Operator = ConditionOperator.Equal,
                                    Values = {0}
                                },
                                new ConditionExpression
                                {
                                    AttributeName = "returnedtypecode",
                                    Operator = ConditionOperator.Equal,
                                    Values = {Opportunity.EntityTypeCode}
                                },
                                                new ConditionExpression
                                {
                                    AttributeName = "name",
                                    Operator = ConditionOperator.Equal,
                                    Values = {SavedQueryName}
                                }
                            }
                        }
                    };

                 //   RetrieveMultipleRequest retrieveOpportuntiesViewRequest = new RetrieveMultipleRequest { Query = ClosedOpportunitiesViewQuery };

                 //   RetrieveMultipleResponse retrieveOpportuntiesViewResponse = (RetrieveMultipleResponse)_serviceProxy.Execute(retrieveOpportuntiesViewRequest);

                  //  SavedQuery OpportunityView = (SavedQuery)retrieveOpportuntiesViewResponse.EntityCollection.Entities[0];
                  //  _viewOriginalState = (SavedQueryState)OpportunityView.StateCode;
                  //  _viewOriginalStatus = OpportunityView.StatusCode;


                    //SetStateRequest ssreq = new SetStateRequest
                    //{
                    //    EntityMoniker = new EntityReference(SavedQuery.EntityLogicalName, (Guid)OpportunityView.SavedQueryId),
                    //    State = new OptionSetValue((int)SavedQueryState.Inactive),
                    //    Status = new OptionSetValue(2)
                    //};
                  //  _serviceProxy.Execute(ssreq);
                    //</snippetWorkWithViews3>
                  //  _deactivatedViewId = (Guid)OpportunityView.SavedQueryId;


                  //  DeleteRequiredRecords(promptForDelete);
                  //  ReactivateDeactivatedView(promptForReactivate);
                }
            }

            // Catch any service fault exceptions that Microsoft Dynamics CRM throws.
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault>)
            {
                // You can handle an exception here or pass it back to the calling method.
                throw;
            }
        }

        public static Guid EntityRecord( List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, IOrganizationService service)
        {
            Guid RecordID = Guid.Empty;
            try
            {


                int rowCount = xlRange.Rows.Count;
                int colCount = xlRange.Columns.Count;

                for (int i = 2; i <= rowCount; i++)
                {
                    Console.WriteLine("Row" + i);

                    if (xlRange.Cells[i, 1] != null && xlRange.Cells[i, 1].Value2 != null && (xlRange.Cells[i, 2] != null && xlRange.Cells[i, 2].Value2 != null))
                    {
                        string value = xlRange.Cells[i, 1].Value2.Trim();
                        string entityName = "userquery";
                        EntityMetadata entityMetad = null;
                        entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == entityName.ToLower()).FirstOrDefault();
                        if (entityMetad == null)
                            entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == entityName.ToLower()).FirstOrDefault();
                        if (entityMetad != null)
                        {
                            List<AttributeMetadata> attributeMetadata = RetrieveAttributeMetadata(service, entityName);

                            if (value.ToLower() == "c")
                            {
                                //Create record
                                RecordID = CreateViewRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata,  service);
                            }
                            else if (value.ToLower() == "u")
                            {//Update record
                            //    RecordID = UpdateViewRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);

                            }
                            else if (value.ToLower() == "d")
                            {
                                //Delete record
                              //  DeleteViewRecord(i, colCount, entityName, attributeMetadata, attribute, xlRange, entityMetadata, isActivity, service);
                            }


                        }                       

                    }

                  



                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "EntityRecord");
            }
            return RecordID;

        }
        public static Guid CreateViewRecord(int i, int colCount, string entityName, List<AttributeMetadata> attributeMetadata, List<String> attribute, Range xlRange, EntityMetadata[] entityMetadata, IOrganizationService service)
        {

            Guid entityId = Guid.Empty;
            try
            {



                SavedQuery objEntity = new SavedQuery
                {
                    //Name = name,
                    //Description = description,
                    //ReturnedTypeCode = returnedTypeCode,
                    //FetchXml = fetchXm,
                    //LayoutXml = layoutXm,
                    //QueryType = 0
                };

                string ReturnedTypeCode = xlRange.Cells[i, 2].Value2.ToString().Trim();
                  objEntity.ReturnedTypeCode = ReturnedTypeCode;

                int Count = 0;



                for (int j = 3; j <= colCount; j++) // Put J =  index from where we want to read in excel.
                {

                    

                    //write the value to the Grid  


                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                    {
                        string value = xlRange.Cells[i, j].Value2.ToString().Trim();
                        string att = attribute[j - 1];
                        //Retrieve attribute from AttributeMetadata

                        // AttributeMetadata attMetadata = attributeMetadata.Find(x => x.DisplayName.LocalizedLabels.Count>0 && x.DisplayName.LocalizedLabels[0] !=null && x.DisplayName.LocalizedLabels[0].Label == att);
                        AttributeMetadata attMetadata = attributeMetadata.Find(x => x.LogicalName == att || (x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == att.ToLower()));


                        if (attMetadata != null)
                        {
                            att = attMetadata.LogicalName;

                            if (attMetadata.AttributeType == AttributeTypeCode.Boolean)
                            {
                                if (value.ToLower() == "yes")
                                    objEntity[att] = true;
                                else if (value.ToLower() == "no")
                                    objEntity[att] = false;
                                else
                                    objEntity[att] = (Boolean)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Integer)
                            {
                                objEntity[att] = (Int32)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Decimal)
                            {
                                objEntity[att] = (Decimal)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Double)
                            {
                                objEntity[att] = (Double)xlRange.Cells[i, j].Value2;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.DateTime)
                            {
                                double d = (Double)(xlRange.Cells[i, j].Value2);
                                DateTime dateTime = DateTime.FromOADate(d).Date;
                                objEntity[att] = dateTime;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.String)
                            {
                                objEntity[att] = value.Trim();
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Picklist)
                            {
                                int? optionSetValue = GetOptionsSetValueForLabel(service, entityName, att, xlRange.Cells[i, j].Value2.ToString().Trim());
                                if (optionSetValue != null)
                                {
                                    int optionsetValue = Convert.ToInt32(optionSetValue);
                                    objEntity[att] = new OptionSetValue(optionsetValue);
                                }
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Lookup)
                            {
                                string parentEntity = string.Empty;

                                if (att == "regardingobjectid")
                                {
                                    String[] values = value.Split(',');

                                    EntityMetadata entityMetad = null;
                                    entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == values[0].ToLower()).FirstOrDefault();
                                    if (entityMetad == null)
                                        entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == values[0].ToLower()).FirstOrDefault();
                                    if (entityMetad != null)
                                    {

                                        parentEntity = entityMetad.LogicalName;
                                        //    isActivity = entityMetad.IsActivity;
                                        value = values[1].ToString();
                                    }

                                }
                                else
                                {
                                    parentEntity = ((LookupAttributeMetadata)attMetadata).Targets[0];

                                }


                                EntityMetadata entityMetad_PE = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
                                if (entityMetad_PE != null)
                                {
                                    if (entityMetad_PE.PrimaryNameAttribute != null)
                                    {
                                        //Retrieve Record
                                        Guid parentEntityId = RetrieveEntityRecord(parentEntity, entityMetad_PE.PrimaryNameAttribute, value, entityMetadata, service);
                                        if (parentEntityId != Guid.Empty)
                                            objEntity[att] = new EntityReference(parentEntity, parentEntityId);
                                    }
                                }


                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Money)
                            {
                                objEntity[att] = new Money((Decimal)xlRange.Cells[i, j].Value2);
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Memo)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.BigInt)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Uniqueidentifier)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Status)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.State)
                            {
                                objEntity[att] = value;
                            }
                            else if (attMetadata.AttributeType == AttributeTypeCode.Customer)
                            {
                                if (((LookupAttributeMetadata)attMetadata).Targets.Count() > 0)
                                {
                                    foreach (string ent in ((LookupAttributeMetadata)attMetadata).Targets)
                                    {
                                        string parentEntity = ent;

                                        EntityMetadata entityMetad = entityMetadata.Where(x => x.LogicalName == parentEntity).FirstOrDefault();
                                        if (entityMetad != null)
                                        {
                                            if (entityMetad.PrimaryNameAttribute != null)
                                            {
                                                //Retrieve Record
                                                Guid parentEntityId = RetrieveEntityRecord(parentEntity, entityMetad.PrimaryNameAttribute, value, entityMetadata, service);

                                                if (parentEntityId != Guid.Empty)
                                                {
                                                    objEntity[att] = new EntityReference(parentEntity, parentEntityId);
                                                    break;
                                                }

                                            }
                                        }
                                    }
                                }
                            }



                            Count++;

                        }

                    }
                }

                WorkWithViews views = new WorkWithViews();
                views._customViewId = service.Create(objEntity);

                Console.WriteLine("A new view with the name {0} was created.", objEntity.Name);

              


            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "CreateEntityRecord");
            }

            return entityId;

        }

        public static Guid RetrieveEntityRecord(string entityName, string attribute, string value, EntityMetadata[] entityMetadata,  IOrganizationService service)
        {
            string primaryKey = entityName;

            Guid parentId = Guid.Empty;
            try
            {
                EntityMetadata entityMetad = null;
                entityMetad = entityMetadata.Where(x => x.LogicalName.ToLower() == entityName.ToLower()).FirstOrDefault();
                if (entityMetad == null)
                    entityMetad = entityMetadata.Where(x => x.DisplayName != null && x.DisplayName.UserLocalizedLabel != null && x.DisplayName.UserLocalizedLabel.Label != null && x.DisplayName.UserLocalizedLabel.Label.ToLower() == entityName.ToLower()).FirstOrDefault();
                if (entityMetad != null)
                {
                 //   isActivity = entityMetad.IsActivity;

                }


                // Set activity for activity type of entities
                //if (isActivity != null && isActivity == true)
                //    primaryKey = "activity";

                string fetchXML =
                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='" + entityName + @"'>
    <attribute name='" + primaryKey + @"id' />
  <attribute name='createdon' />
  <order attribute='createdon' descending='true' />
  <filter type='and'>
      <condition attribute='" + attribute + @"' operator='eq' value='" + value + @"' />
    </filter>
  </entity>
</fetch>";




                EntityCollection ecEntities = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ecEntities != null && ecEntities.Entities != null && ecEntities.Entities.Count > 0)
                {
                    parentId = new Guid(ecEntities.Entities[0][primaryKey + "id"].ToString());
                }

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveEntityRecord");
            }
            return parentId;
        }
        public static int? GetOptionsSetValueForLabel(IOrganizationService service, string entityName, string attributeName, string selectedLabel)
        {
            int? selectedOptionValue = null;
            try
            {
                RetrieveAttributeRequest retrieveAttributeRequest = new
                RetrieveAttributeRequest
                {
                    EntityLogicalName = entityName,
                    LogicalName = attributeName,
                    RetrieveAsIfPublished = true
                };
                // Execute the request.
                RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
                // Access the retrieved attribute.
                Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)
                retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
                OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();

                foreach (OptionMetadata oMD in optionList)
                {
                    if (oMD.Label.LocalizedLabels[0].Label.ToString().ToLower() == selectedLabel.ToLower())
                    {
                        selectedOptionValue = oMD.Value.Value;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "GetOptionsSetValueForLabel");
            }
            return selectedOptionValue;

        }
        public static EntityMetadata[] GetEntities(IOrganizationService organizationService)
        {
            EntityMetadata[] entities = null;
            try
            {

                RetrieveAllEntitiesRequest metaDataRequest = new RetrieveAllEntitiesRequest();
                RetrieveAllEntitiesResponse metaDataResponse = new RetrieveAllEntitiesResponse();
                metaDataRequest.EntityFilters = EntityFilters.Entity;

                // Execute the request.

                metaDataResponse = (RetrieveAllEntitiesResponse)organizationService.Execute(metaDataRequest);

                entities = metaDataResponse.EntityMetadata;


            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "GetEntities");
            }
            return entities;
        }
        public static void ErrorLogging(Exception ex, string className, string methodName)
        {
            try
            {

                string strPath = path + "Log.txt";
                //string strPath = @"C:\\RoleSwitchLogs\\Log.txt";
                if (!File.Exists(strPath))
                {
                    File.Create(strPath).Dispose();
                }
                using (StreamWriter sw = File.AppendText(strPath))
                {
                    sw.WriteLine("=============Error Logging ===========");
                    sw.WriteLine("===========Start============= " + DateTime.Now);
                    sw.WriteLine("Class Name: " + className + ", Method Name: " + methodName);
                    sw.WriteLine("Error Message: " + ex.Message);
                    sw.WriteLine("Inner Exception: " + ex.InnerException);
                    sw.WriteLine("Stack Trace: " + ex.StackTrace);
                    sw.WriteLine("===========End============= " + DateTime.Now);

                }
            }

            catch (Exception er)
            {

                throw er;
            }

        }
        public static List<AttributeMetadata> RetrieveAttributeMetadata(IOrganizationService service, string entityName)
        {
            List<AttributeMetadata> attributeMetadata = null;
            try
            {
                RetrieveEntityRequest req = new RetrieveEntityRequest();
                req.RetrieveAsIfPublished = true;
                req.LogicalName = entityName;
                req.EntityFilters = EntityFilters.Attributes;

                RetrieveEntityResponse resp = (RetrieveEntityResponse)service.Execute(req);
                attributeMetadata = resp.EntityMetadata.Attributes.ToList();

            }
            catch (Exception ex)
            {
                ErrorLogging(ex, "TestDataCreation", "RetrieveAttributeMetadata");
            }
            return attributeMetadata;
        }

        /// <summary>
        /// Deletes the custom view that was created for this sample.
        /// <param name="prompt">Indicates whether to prompt the user to delete the records created in this sample.</param>
        /// </summary>
        public void DeleteRequiredRecords(bool prompt)
        {
            bool deleteView = true;

            if (prompt)
            {
                Console.WriteLine("\nDo you want this custom view deleted? (y/n)");
                String answer = Console.ReadLine();

                deleteView = (answer.StartsWith("y") || answer.StartsWith("Y"));
            }

            if (deleteView)
            {
                _serviceProxy.Delete(SavedQuery.EntityLogicalName, _customViewId);
                Console.WriteLine("The view has been deleted.");
            }
        }
        /// <summary>
        /// Reactivates the view that was deactivated for this sample.
        /// <param name="prompt">Indicates whether to prompt the user to reactivate the view deactivated in this sample.</param>
        /// </summary>
        public void ReactivateDeactivatedView(bool prompt)
        {
            bool reactivateView = true;

            if (prompt)
            {
                Console.WriteLine("\nDo you want to reactivate the \"Closed Opportunities in Current Fiscal Year\" view? (y/n)");
                String answer = Console.ReadLine();

                reactivateView = (answer.StartsWith("y") || answer.StartsWith("Y"));
            }

            if (reactivateView)
            {
                SetStateRequest reactivateViewRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(SavedQuery.EntityLogicalName, _deactivatedViewId),
                    State = new OptionSetValue((int)_viewOriginalState),
                    Status = _viewOriginalStatus
                };
                _serviceProxy.Execute(reactivateViewRequest);
                Console.WriteLine("The view has been reactivated.");
            }
        }

        #endregion How To Sample Code

        #region Main
        /// <summary>
        /// Slightly modified Main() method used by most SDK samples.
        /// </summary>
        /// <param name="args"></param>
        static public void Main(string[] args)
        {
            try
            {
               string pwd = DES.Crm.Core.Common.Security.DataProtect.EncryptString(ConfigurationManager.AppSettings["CRMPassword"].ToString());
                // Obtain the target organization's Web address and client logon 
                // credentials from the user.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServerConnection serverConnect = new ServerConnection();
                ServerConnection.Configuration config = serverConnect.GetServerConfiguration();

                WorkWithViews app = new WorkWithViews();
                // The Run method has an additional parameter to prompt for reactivation of a view.
                app.Run(config, true, true);
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                Console.WriteLine("The application terminated with an error.");
                Console.WriteLine("Timestamp: {0}", ex.Detail.Timestamp);
                Console.WriteLine("Code: {0}", ex.Detail.ErrorCode);
                Console.WriteLine("Message: {0}", ex.Detail.Message);
                Console.WriteLine("Plugin Trace: {0}", ex.Detail.TraceText);
                Console.WriteLine("Inner Fault: {0}",
                    null == ex.Detail.InnerFault ? "No Inner Fault" : "Has Inner Fault");
            }
            catch (System.TimeoutException ex)
            {
                Console.WriteLine("The application terminated with an error.");
                Console.WriteLine("Message: {0}", ex.Message);
                Console.WriteLine("Stack Trace: {0}", ex.StackTrace);
                Console.WriteLine("Inner Fault: {0}",
                    null == ex.InnerException.Message ? "No Inner Fault" : ex.InnerException.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine("The application terminated with an error.");
                Console.WriteLine(ex.Message);

                // Display the details of the inner exception.
                if (ex.InnerException != null)
                {
                    Console.WriteLine(ex.InnerException.Message);

                    FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> fe = ex.InnerException
                        as FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault>;
                    if (fe != null)
                    {
                        Console.WriteLine("Timestamp: {0}", fe.Detail.Timestamp);
                        Console.WriteLine("Code: {0}", fe.Detail.ErrorCode);
                        Console.WriteLine("Message: {0}", fe.Detail.Message);
                        Console.WriteLine("Plugin Trace: {0}", fe.Detail.TraceText);
                        Console.WriteLine("Inner Fault: {0}",
                            null == fe.Detail.InnerFault ? "No Inner Fault" : "Has Inner Fault");
                    }
                }
            }
            // Additional exceptions to catch: SecurityTokenValidationException, ExpiredSecurityTokenException,
            // SecurityAccessDeniedException, MessageSecurityException, and SecurityNegotiationException.

            finally
            {

                Console.WriteLine("Press <Enter> to exit.");
                Console.ReadLine();
            }

        }
        #endregion Main
    }
}

