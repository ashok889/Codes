﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace O365ManagementAPI
{
    public class AuditGeneralItem
    {
        public DateTime CreationTime { get; set; }
        public string Id { get; set; }
        public string Operation { get; set; }
        public string OrganizationId { get; set; }
        public int RecordType { get; set; }
        public string ResultStatus { get; set; }
        public string UserKey { get; set; }
        public int UserType { get; set; }
        public int Version { get; set; }
        public string Workload { get; set; }
        public string ClientIP { get; set; }
        public string ObjectId { get; set; }
        public string UserId { get; set; }
        public string CrmOrganizationUniqueName { get; set; }
        public List<object> Fields { get; set; }
        public string InstanceUrl { get; set; }
        public string ItemType { get; set; }
        public string ItemUrl { get; set; }
        public string UserAgent { get; set; }
        public string CorrelationId { get; set; }
        public string EntityId { get; set; }
        public string EntityName { get; set; }
        public string Message { get; set; }
        public string PrimaryFieldValue { get; set; }
        public string Query { get; set; }
        public string QueryResults { get; set; }
        public string ServiceContextId { get; set; }
        public string ServiceContextIdType { get; set; }
        public string ServiceName { get; set; }
        public string SystemUserId { get; set; }
        public string UserUpn { get; set; }
    }
}
