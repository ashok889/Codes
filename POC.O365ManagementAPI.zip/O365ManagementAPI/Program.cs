﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace O365ManagementAPI
{
    class Program
    {
        static bool generalSubscriptionEnabled = false;

        static void Main(string[] args)
        {
            MainAsync(args).GetAwaiter().GetResult();
        }
        static async Task MainAsync(string[] args)
        {
            var tenantId = "a493f1bb-6b19-451d-ba36-eb8833aa48e1";
            var clientId = "c5093b3e-a634-4179-81f6-a43ab128e70e";
            var secret = "VcKQxy0E95vH2dOCpdNFlXJygulqUuqo6KZnEwOmc+A=";

            var messageHandler = new OAuthMessageHandler(tenantId, clientId, secret, new HttpClientHandler());

            var audits = new List<AuditGeneralItem>();

            using (HttpClient httpClient = new HttpClient(messageHandler))
            {
                httpClient.BaseAddress = new Uri("https://manage.office.com");
                httpClient.Timeout = new TimeSpan(0, 2, 0);   //2 minutes
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                // Check existing subscriptions
                await CheckGeneralSubscription(httpClient);

                if (!generalSubscriptionEnabled)
                {
                    await EnableGeneralSubscription(httpClient);
                }
                else
                {
                    // example url for query audit logs from certain time period
                    // https://manage.office.com/api/v1.0/$tenantGUID/activity/feed/subscriptions/content?contentType=Audit.SharePoint&startTime=2017-10-13T00:00&endTime=2017-10-13T11:59'

                    string url = "https://manage.office.com/api/v1.0/tenantId/activity/feed/subscriptions/content?contentType=Audit.General&startTime=2018-09-01T00:00&endTime=2018-09-04T00:00";

                    var listResp = await httpClient.GetAsync(url);
                    var listResponse = listResp.EnsureSuccessStatusCode();
                    var listBody = await listResp.Content.ReadAsStringAsync();

                    var list = JsonConvert.DeserializeObject<List<AuditGeneralContentUri>>(listBody);

                    foreach (var uri in list)
                    {
                        var itemResp = await httpClient.GetAsync(uri.contentUri);
                        var itemResponse = itemResp.EnsureSuccessStatusCode();
                        var itemBoby = await itemResp.Content.ReadAsStringAsync();
                        var item = JsonConvert.DeserializeObject<List<AuditGeneralItem>>(itemBoby);

                        audits.Add(item[0]);
                    }

                    // convert logs into xml format and save to local file
                    var xmlOutput = GetXMLFromObject(audits);

                    XmlDocument xdoc = new XmlDocument();
                    xdoc.LoadXml(xmlOutput);

                    var filename = "logs_" + DateTime.Now.ToString("yyyyMMdd",CultureInfo.CreateSpecificCulture("en-US")) + ".xml";
                    xdoc.Save(@"C:\Dev\AuditLog\" + filename);

                    Console.WriteLine("Processing completed");
                }
                           
            }

        }

        private static async Task CheckGeneralSubscription(HttpClient httpClient)
        {
            // list existing audit content subscriptions
            string endpoint = $"/api/v1.0/tenantId/activity/feed/subscriptions/list";

            HttpRequestMessage message = new HttpRequestMessage(new HttpMethod("GET"), endpoint);

            var resp = await httpClient.SendAsync(message, HttpCompletionOption.ResponseHeadersRead);
            var subscriptionResponse = resp.EnsureSuccessStatusCode();

            var subscription = await resp.Content.ReadAsStringAsync();
            var list = JsonConvert.DeserializeObject<List<AuditSubscription>>(subscription);
            if (list.Count == 0)
            {
                generalSubscriptionEnabled = false;
            }
            else
            {
                // check subscription content type contain "Audit.General"
                foreach (var sub in list)
                {
                    if (sub.contentType.Equals("Audit.General"))
                    {
                        generalSubscriptionEnabled = true;
                    }
                }
            }



        }

        private static async Task EnableGeneralSubscription(HttpClient httpClient)
        {
            // start specific audit content subscription
            string endpoint = $"/api/v1.0/tenantId/activity/feed/subscriptions/start?contentType=Audit.General";

            HttpRequestMessage message = new HttpRequestMessage(new HttpMethod("POST"), endpoint);

            var resp = await httpClient.SendAsync(message, HttpCompletionOption.ResponseHeadersRead);
            var subscriptionResponse = resp.EnsureSuccessStatusCode();

            Console.WriteLine("Audit General subscription enabled.");
        }

        private static string GetXMLFromObject(object o)
        {
            StringWriter sw = new StringWriter();
            XmlTextWriter tw = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(o.GetType());
                tw = new XmlTextWriter(sw);
                serializer.Serialize(tw, o);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                sw.Close();
                if (tw != null)
                {
                    tw.Close();
                }
            }
            return sw.ToString();
        }
    }

    

    /// <summary>
    ///Custom HTTP message handler that uses OAuth authentication thru ADAL.
    /// </summary>
    class OAuthMessageHandler : DelegatingHandler
    {
        private AuthenticationHeaderValue authHeader;

        public OAuthMessageHandler(string tenantId, string clientId, string secret, HttpMessageHandler innerHandler)
            : base(innerHandler)
        {
            // var authUrl = $"https://login.microsoftonline.com/{tenantId}/oauth2/token";
 
            var authUrl = $"https://login.microsoftonline.com/{tenantId}/oauth2/token";
            AuthenticationContext authenticationContext = new AuthenticationContext(authUrl, false);
            var clientCredential = new ClientCredential(clientId, secret);
            AuthenticationResult authResult = authenticationContext.AcquireTokenAsync("https://manage.office.com", clientCredential).Result;
            authHeader = new AuthenticationHeaderValue("Bearer", authResult.AccessToken);
        }

        protected override Task<HttpResponseMessage> SendAsync(
                 HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            request.Headers.Authorization = authHeader;
            return base.SendAsync(request, cancellationToken);
        }
    }

}
