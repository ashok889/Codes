﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace O365ManagementAPI
{
    public class AuditSubscription
    {
        public string contentType { get; set; }
        public string status { get; set; }
        public object webhook { get; set; }
    }
    
}
