﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace O365ManagementAPI
{
    class AuditGeneralContentUri
    {
        public string contentUri { get; set; }
        public string contentId { get; set; }
        public string contentType { get; set; }
        public DateTime contentCreated { get; set; }
        public DateTime contentExpiration { get; set; }
    }
}
