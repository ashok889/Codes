﻿using Microsoft.Xrm.Tooling.Connector;
using Rbs.D365.EcmIntegrate.Model;
using Rbs.D365.EcmIntegrate.WebApplication.Exceptions;
using Rbs.D365.EcmIntegrate.WebApplication.Logging;
using Rbs.D365.EcmIntegrate.WebApplication.Models;
using Rbs.D365.EcmIntegrate.WebApplication.Properties;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using WebGrease.Css.Extensions;
using Document = Rbs.D365.EcmIntegrate.Model.Document;

namespace Rbs.D365.EcmIntegrate.WebApplication
{
    /// <summary>
    /// Utility
    /// </summary>
    public class Utility
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Utility" /> class.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="user">The user.</param>
        public Utility(Logger log, IPrincipal user)
        {
            Log = log;
            User = user;
        }

        #endregion

        #region Private Properties

        /// <summary>
        /// Gets or sets the log.
        /// </summary>
        /// <value>
        /// The log.
        /// </value>
        private Logger Log { get; }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <value>
        /// The user.
        /// </value>
        private IPrincipal User { get; }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the CRM error.
        /// </summary>
        /// <value>
        /// The CRM error.
        /// </value>
        public string CrmError { get; set; }

        /// <summary>
        /// Gets or sets the CRM exception.
        /// </summary>
        /// <value>
        /// The CRM exception.
        /// </value>
        public Exception CrmException { get; set; }

        /// <summary>
        /// Gets a value indicating whether this instance is authenticated.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is authenticated; otherwise, <c>false</c>.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2234:PassSystemUriObjectsInsteadOfStrings")]
        public bool IsAuthenticated
        {
            get
            {
                try
                {
                    ServicePointManager.Expect100Continue = true;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    WindowsIdentity windowsIdentity = (WindowsIdentity)User.Identity;
                    WindowsImpersonationContext windowsImpersonationContext = windowsIdentity.Impersonate();
                    using (windowsImpersonationContext)
                    {
                        using (HttpClientHandler httpClientHandler = new HttpClientHandler { UseDefaultCredentials = true })
                        {
                            using (HttpClient httpClient = new HttpClient(httpClientHandler))
                            {
                                httpClient.BaseAddress = new Uri(ConfigurationManager.AppSettings["EcmIntegrationWebApi"]);
                                Task<HttpResponseMessage> task = httpClient.GetAsync("api/authentication");
                                task.Wait();
                                if (!task.Result.IsSuccessStatusCode)
                                {
                                    return false;
                                }
                                Task<bool> content = task.Result.Content.ReadAsAsync<bool>();
                                content.Wait();
                                return content.Result;
                            }
                        }
                    }
                }
                catch
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Gets the record types.
        /// </summary>
        /// <value>
        /// The record types.
        /// </value>
        /// <exception cref="WebApplicationException"></exception>
        public IEnumerable<string> RecordTypes
        {
            get
            {
                Collection<string> recordTypes = new Collection<string>();
                Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1,
                    LogLevel.Debug);
                //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
                //Connect to Dynamics 365...
                using (CrmServiceClient crmServiceClient =
                    new CrmServiceClient(ConfigurationManager
                        .ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365]
                        .ConnectionString))
                {
                    Log.Log(
                        Resources
                            .EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1,
                        LogLevel.Debug);
                    Log.Log(
                        Resources
                            .EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1,
                        LogLevel.Debug);
                    //Check for successful authentication with Dynamics 365...
                    if (!crmServiceClient.IsReady)
                    {
                        Log.Log(
                            Resources.EcmController_IsAuthenticated_An_error_occurred_when_connecting_to_Dynamics_365_1,
                            LogLevel.Warning);
                        Log.Log(crmServiceClient.LastCrmError, LogLevel.Error);
                        return recordTypes;
                    }

                    Log.Log(Resources.EcmController_IsAuthenticated_Instantiating_Dynamics_365_context___1,
                        LogLevel.Debug);
                    //Instantiate Dynamics 365 Service Context...
                    using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                    {
                        Log.Log(
                            Resources
                                .EcmController_SetViewBagProperties_Set_Collection_for_Record_Types_Drop_Down_List_1,
                            LogLevel.Debug);
                        //Set Collection for Record Types Drop Down List.
                        xrmServiceContext.RecordTypeSet.OrderBy(rt => rt.RecordTypeName).Select(rt => rt.RecordTypeName)
                            .ForEach(n => recordTypes.Add(n));
                    }
                }

                return recordTypes;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the entity.
        /// </summary>
        /// <param name="entityId">The entity identifier.</param>
        /// <param name="entityName">Name of the entity.</param>
        /// <returns></returns>
        public Entity GetEntity(Guid entityId, string entityName)
        {
            Log.Log(Resources.EcmController_GetEntity_Getting_the_entity___1, LogLevel.Information);
            //Instantiate Entity...
            Entity entity = new Entity
            {
                EntityId = entityId,
                EntityName = entityName,
                Language = Language.ENG,
                Company = RBSCompany.RBS,
                Jurisdiction = RBSJurisdiction.GBR,
                Classification = RBSClassification.Public,
                HighRiskRecord = RBSHighRiskRecord.Historical
            };
            Log.Log(Resources.EcmController_GetEntity_Returning_entity___1, LogLevel.Information);
            return entity;
        }

        /// <summary>
        /// Gets the existing entity.
        /// </summary>
        /// <param name="entityId">The entity identifier.</param>
        /// <param name="entityName">Name of the entity.</param>
        /// <returns></returns>
        /// <exception cref="WebApplicationException">The document could not be found in Dynamics 365!</exception>
        public Entity GetExistingEntity(Guid entityId, string entityName)
        {
            Log.Log(Resources.EcmController_GetExistingEntity_Getting_the_Entity___1, LogLevel.Information);
            Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1, LogLevel.Debug);
            //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
            //Connect to Dynamics 365...
            using (CrmServiceClient crmServiceClient =
                new CrmServiceClient(ConfigurationManager.ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365].ConnectionString))
            {
                Log.Log(Resources.EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1, LogLevel.Debug);
                Log.Log(Resources.EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1, LogLevel.Debug);
                //Check for successful authentication with Dynamics 365...
                if (!crmServiceClient.IsReady)
                {
                    Log.Log(Resources.EcmController_IsAuthenticated_An_error_occurred_when_connecting_to_Dynamics_365_1, LogLevel.Error);
                    Log.Log(crmServiceClient.LastCrmError, LogLevel.Error);
                    CrmError = crmServiceClient.LastCrmError;
                    CrmException = crmServiceClient.LastCrmException;
                    throw crmServiceClient.LastCrmException;
                }
                Log.Log(Resources.EcmController_IsAuthenticated_Instantiating_Dynamics_365_context___1, LogLevel.Debug);
                //Instantiate Dynamics 365 Service Context...
                using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                {
                    Log.Log(Resources.EcmController_GetExistingEntity_Get_Document_from_Dynamics_365___1, LogLevel.Debug);
                    Document document = xrmServiceContext.DocumentSet.FirstOrDefault(d => d.Id == entityId);
                    Log.Log(Resources.EcmController_GetExistingEntity_Check_if_Document_is_null___1, LogLevel.Debug);
                    if (document?.DocumentId == null)
                    {
                        Log.Log(Resources.EcmController_GetExistingEntity_The_Document_could_not_be_found_1, LogLevel.Error);
                        throw new WebApplicationException(Resources.EcmController_GetExistingEntity_The_document_could_not_be_found_in_Dynamics_365_1);
                    }
                    Log.Log(Resources.EcmController_GetExistingEntity_Instantiating_the_entity___1, LogLevel.Debug);
                    //Instantiate Entity...
                    Entity entity = new Entity
                    {
                        EntityId = entityId,
                        EntityName = entityName,
                        RecordType = document.RecordType != null ? xrmServiceContext.RecordTypeSet.FirstOrDefault(r => r.RecordTypeId == document.RecordType.Id)?.RecordTypeName : string.Empty,
                        Jurisdiction = (RBSJurisdiction)document.RBSJurisdiction.Value,
                        PersonalInfo = document.RBSPersonalInformation.HasValue && document.RBSPersonalInformation.Value,
                        Classification = (RBSClassification)document.RBSClassification.Value,
                        Company = (RBSCompany)document.RBSCompany.Value,
                        Language = (Language)document.Language.Value,
                        IsCustomerVisibleDocument = document.IsCustomerVisibleDocument.HasValue && document.IsCustomerVisibleDocument.Value,
                        HighRiskRecord = (RBSHighRiskRecord)document.RBSHighRiskRecord.Value
                    };
                    Log.Log(Resources.EcmController_GetExistingEntity_Returning_the_Entity___1, LogLevel.Information);
                    return entity;
                }
            }
        }

        #endregion
    }
}