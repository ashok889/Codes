﻿namespace Rbs.D365.EcmIntegrate.WebApplication.Logging
{
    /// <summary>
    /// Log Level
    /// </summary>
    public enum LogLevel
    {
        /// <summary>
        /// The information
        /// </summary>
        Information,

        /// <summary>
        /// The debug
        /// </summary>
        Debug,

        /// <summary>
        /// The warning
        /// </summary>
        Warning,

        /// <summary>
        /// The error
        /// </summary>
        Error
    }
}