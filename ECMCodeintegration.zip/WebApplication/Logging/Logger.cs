﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Threading;
using Rbs.D365.EcmIntegrate.WebApplication.Properties;

namespace Rbs.D365.EcmIntegrate.WebApplication.Logging
{
    /// <summary>
    /// Logger
    /// </summary>
    public class Logger : ILogger, IDisposable
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Logger" /> class.
        /// </summary>
        /// <param name="logFileName">Name of the log file.</param>
        /// <param name="eventLogName">Name of the event log.</param>
        /// <param name="isDebuggingEnabled">if set to <c>true</c> [is debugging enabled].</param>
        /// <param name="logPath">The log path.</param>
        /// <param name="domain">The domain.</param>
        /// <param name="userName">Name of the user.</param>
        /// <param name="password">The password.</param>
        public Logger(string logFileName, string eventLogName, bool isDebuggingEnabled, string logPath, string domain, string userName, string password)
        {
            IsDebuggingEnabled = isDebuggingEnabled;
            InitializeLogFile(logFileName, logPath);
            InitializeEventLog(eventLogName);
            Domain = domain;
            UserName = userName;
            Password = password;
        }

        #endregion

        #region Private Properties

        /// <summary>
        /// Gets or sets the logger event log.
        /// </summary>
        /// <value>
        /// The logger event log.
        /// </value>
        private EventLog LoggerEventLog { get; set; }

        /// <summary>
        /// Gets or sets the name of the log file.
        /// </summary>
        /// <value>
        /// The name of the log file.
        /// </value>
        private string LogFileName { get; set; }
        
        /// <summary>
        /// Gets or sets the log path.
        /// </summary>
        /// <value>
        /// The log path.
        /// </value>
        private string LogPath { get; set; }

        /// <summary>
        /// Gets or sets the domain.
        /// </summary>
        /// <value>
        /// The domain.
        /// </value>
        private string Domain { get; set; }

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        private string UserName { get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>
        /// The password.
        /// </value>
        private string Password { get; set; }

        #endregion

        #region Public Properties
        
        /// <summary>
        /// Gets or sets a value indicating whether this instance is debugging enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is debugging enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsDebuggingEnabled { get; set; }

        #endregion

        #region Private Methods

        /// <summary>
        /// Initializes the log file.
        /// </summary>
        /// <param name="logFileName">Name of the log file.</param>
        /// <param name="logPath">The log path.</param>
        private void InitializeLogFile(string logFileName, string logPath)
        {
            LogPath = logPath;
            LogFileName = Path.Combine(LogPath, logFileName);
            if (File.Exists(LogFileName))
            {
                return;
            }
            //Create file...
            try
            {
                using (StreamWriter streamWriter = File.CreateText(LogFileName))
                {
                    streamWriter.WriteLine(Resources.Logger_InitializeLogFile_ECM_Integration_Log_File);
                    streamWriter.WriteLine(string.Format(CultureInfo.CurrentCulture, Resources.Logger_InitializeLogFile_Created____0_, DateTime.UtcNow));
                    streamWriter.WriteLine();
                }
            }
            catch (IOException)
            {
                Thread.Sleep(1000);
            }
        }

        /// <summary>
        /// Initializes the event log.
        /// </summary>
        /// <param name="eventLogName">Name of the event log.</param>
        /// <exception cref="NotImplementedException"></exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        private void InitializeEventLog(string eventLogName)
        {
            using (Impersonate impersonate = new Impersonate())
            {
                if (impersonate.ImpersonateValidUser(UserName, Domain, Password) && !EventLog.SourceExists(eventLogName))
                {
                    EventLog.CreateEventSource(eventLogName, Resources.Logger_InitializeEventLog_Application);
                } 
            }

            LoggerEventLog = new EventLog
            {
                Log = Resources.Logger_InitializeEventLog_Application,
                Source = eventLogName
            };
        }

        #endregion

        #region Protected Virtual Methods

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                LoggerEventLog?.Dispose();
            }
        }

        #endregion

        #region Public Methods
        
        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="logLevel">The log level.</param>
        /// <exception cref="NotImplementedException"></exception>
        public void Log(string message, LogLevel logLevel)
        {
            switch (logLevel)
            {
                case LogLevel.Information:
                    try
                    {
                        using (StreamWriter streamWriter = File.AppendText(LogFileName))
                        {
                            streamWriter.WriteLine(string.Format(CultureInfo.CurrentCulture, Resources.Logger_Log_Information________0_______1_, DateTime.UtcNow, message));
                        }
                    }
                    catch (IOException)
                    {
                        Thread.Sleep(1000);
                    }
                    break;
                case LogLevel.Debug:
                    if (IsDebuggingEnabled)
                    {
                        try
                        {
                            using (StreamWriter streamWriter = File.AppendText(LogFileName))
                            {
                                streamWriter.WriteLine(string.Format(CultureInfo.CurrentCulture, Resources.Logger_Log_Debug________0_______1_, DateTime.UtcNow, message));
                            }
                        }
                        catch (IOException)
                        {
                            Thread.Sleep(1000);
                        }
                    }
                    break;
                case LogLevel.Warning:
                    using (Impersonate impersonate = new Impersonate())
                    {
                        if (impersonate.ImpersonateValidUser(UserName, Domain, Password))
                        {
                            LoggerEventLog.WriteEntry(message, EventLogEntryType.Warning);  
                        }
                    }
                    try
                    {
                        using (StreamWriter streamWriter = File.AppendText(LogFileName))
                        {
                            streamWriter.WriteLine(string.Format(CultureInfo.CurrentCulture, Resources.Logger_Log_Warning____________0_______1_, DateTime.UtcNow, message));
                        }
                    }
                    catch (IOException)
                    {
                        Thread.Sleep(1000);
                    }
                    break;
                case LogLevel.Error:
                    using (Impersonate impersonate = new Impersonate())
                    {
                        if (impersonate.ImpersonateValidUser(UserName, Domain, Password))
                        {
                            LoggerEventLog.WriteEntry(message, EventLogEntryType.Error);  
                        }
                    }
                    try
                    {
                        using (StreamWriter streamWriter = File.AppendText(LogFileName))
                        {
                            streamWriter.WriteLine(string.Format(CultureInfo.CurrentCulture, Resources.Logger_Log_Error______________0_______1_, DateTime.UtcNow, message));
                        }
                    }
                    catch (IOException)
                    {
                        Thread.Sleep(1000);
                    }
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(logLevel), logLevel, null);
            }
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        #region Finalizers

        /// <summary>
        /// Finalizes an instance of the <see cref="Logger"/> class.
        /// </summary>
        ~Logger()
        {
            Dispose(false);
        }
        
        #endregion
    }
}