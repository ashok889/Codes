﻿namespace Rbs.D365.EcmIntegrate.WebApplication
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
    }
}
