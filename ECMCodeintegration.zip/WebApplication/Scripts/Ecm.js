﻿Dropzone.autoDiscover = false;
$(document).ready(function () {
    $("#uploadForm").dropzone({
        paramName: "files",
        clickable: "#previews",
        previewsContainer: "#previewFiles",
        maxFilesize: 500,
        autoProcessQueue: false,
        addRemoveLinks: true,
        uploadMultiple: true,
        parallelUploads: 100,
        maxFiles: 100,
        init: function () {
            var self = this;
            self.options.addRemoveLinks = true;
            self.on("complete",
                function (outcome) {
                    self.removeAllFiles();
                    if (outcome.xhr.responseText !== "undefined") {
                        try {
                            const jsonResult = JSON.parse(outcome.xhr.responseText);
                            if (jsonResult !== "undefined" && jsonResult["success"] !== "undefined" && typeof (jsonResult["success"]) === "boolean") {
                                if (JSON.parse(outcome.xhr.responseText)["success"]) {
                                    $.ajax({
                                        type: "get",
                                        url: $("#uploadForm").data("success"),
                                        dataType: "html",
                                        success: function (result) {
                                            $("#loaderContainer").modal("hide");
                                            $("#modalContainer").modal("show");
                                            $("#modalContent").html(result);
                                        }
                                    });
                                } else {
                                    if (!JSON.parse(outcome.xhr.responseText)["success"]) {
                                        $.ajax({
                                            type: "get",
                                            url: $("#uploadForm").data("uploaderror"),
                                            dataType: "html",
                                            success: function (result) {
                                                $("#loaderContainer").modal("hide");
                                                $("#modalContainer").modal("show");
                                                $("#modalContent").html(result);
                                                $("#errorMessage").text(JSON.parse(outcome.xhr.responseText)["response"]);
                                            }
                                        });
                                    }
                                }
                            } else {
                                $("#loaderContainer").modal("hide");
                                $("#modalContainer").modal("show");
                                $("#modalContent").html(JSON.parse(outcome.xhr.responseText));
                            }
                        } catch (e) {
                            $("#loaderContainer").modal("hide");
                            $("#modalContainer").modal("show");
                            $("#modalContent").html(outcome.xhr.responseText);
                        }
                    }
                });
            self.on("error", function (file, response) {
                $(file.previewElement).find(".dz-error-message").text(response);
                $.ajax({
                    type: "get",
                    url: $("#uploadForm").data("error"),
                    dataType: "html",
                    data: {
                        response: response
                    },
                    success: function (result) {
                        $("#loaderContainer").modal("hide");
                        $("#modalContainer").modal("show");
                        $("#modalContent").html(result);
                    }
                });
            });
            $("#uploadForm").on("submit",
                function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if ($("#uploadForm").valid()) {
                        if (self.getQueuedFiles().length > 0) {
                            $.ajax({
                                type: "get",
                                url: $("#uploadForm").data("spinner"),
                                dataType: "html",
                                success: function (result) {
                                    $("#modalContainer").modal("hide");
                                    $("#loaderContainer").modal("show");
                                    $("#loaderContainer").html(result);
                                    self.processQueue();
                                }
                            });
                        } else {
                            $.ajax({
                                type: "get",
                                url: $("#uploadForm").data("nofileselected"),
                                dataType: "html",
                                success: function (result) {
                                    $("#loaderContainer").modal("hide");
                                    $("#modalContainer").modal("show");
                                    $("#modalContent").html(result);
                                }
                            });
                        }
                    }
                });
        }
    });
    $("#updateForm").submit(function (e) {
        e.preventDefault();
        e.stopPropagation();
        if ($("#updateForm").valid()) {
            $("#successContainer").modal("hide");
            $("#errorContainer").modal("hide");
            $("#loaderContainer").modal("show");
            $.ajax({
                type: "post",
                url: $("#submitUpdate").data("url"),
                dataType: "html",
                data: ($("#updateForm")).serializeArray(),
                success: function (outcome) {
                    if (JSON.parse(outcome)["success"]) {
                        $("#successContainer").modal("show");
                        $("#errorContainer").modal("hide");
                        $("#loaderContainer").modal("hide");
                    } else {
                        $("#successContainer").modal("hide");
                        $("#errorContainer").modal("show");
                        $("#loaderContainer").modal("hide");
                        $("#errorMessage").text(JSON.parse(outcome)["response"]);
                    }
                }
            });
        }
    });
});