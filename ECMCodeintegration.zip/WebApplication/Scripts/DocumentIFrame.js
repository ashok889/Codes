﻿if (typeof (Xrm) === "undefined") {
    Xrm = {};
}

if (typeof (Xrm.Page) === "undefined") {
    Xrm.Page = {};
}

if (typeof (Xrm.Page.ui) === "undefined") {
    Xrm.Page.ui = {};
}

if (typeof (Rbs) === "undefined") {
    Rbs = {};
}

if (typeof (Rbs.Dynamics365) === "undefined") {
    Rbs.Dynamics365 = {};
}

Rbs.Dynamics365.DocumentIFrame = {
    ShowHideIFrame: function (iFrameName) {
        //Is it an update form?
        if (Xrm.Page.ui.getFormType() === 2) {
            //Yes - show IFrame
            Xrm.Page.getControl(iFrameName).setVisible(true);
        } else {
            //No - hide IFrame
            Xrm.Page.getControl(iFrameName).setVisible(false);
        }
    }
}