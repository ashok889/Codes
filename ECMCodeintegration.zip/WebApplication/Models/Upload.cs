﻿using System.Collections.Generic;

namespace Rbs.D365.EcmIntegrate.WebApplication.Models
{
    /// <summary>
    /// Upload
    /// </summary>
    public class Upload
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Upload"/> class.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="postedFiles">The posted files.</param>
        public Upload(Entity entity, IEnumerable<PostedFile> postedFiles)
        {
            Entity = entity;
            PostedFiles = postedFiles;
        }

        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        public Entity Entity { get; set; }

        /// <summary>
        /// Gets or sets the posted files.
        /// </summary>
        /// <value>
        /// The posted files.
        /// </value>
        public IEnumerable<PostedFile> PostedFiles { get; set; }
    }
}