﻿namespace Rbs.D365.EcmIntegrate.WebApplication.Models
{
    /// <summary>
    /// Application Error
    /// </summary>
    public class ApplicationError
    {
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the stack trace.
        /// </summary>
        /// <value>
        /// The stack trace.
        /// </value>
        public string StackTrace { get; set; }
    }
}