﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using Rbs.D365.EcmIntegrate.Model;
using Rbs.D365.EcmIntegrate.WebApplication.Exceptions;
using Rbs.D365.EcmIntegrate.WebApplication.Logging;
using Rbs.D365.EcmIntegrate.WebApplication.Models;
using Rbs.D365.EcmIntegrate.WebApplication.Properties;
using Entity = Rbs.D365.EcmIntegrate.WebApplication.Models.Entity;

namespace Rbs.D365.EcmIntegrate.WebApplication.Controllers
{
    /// <summary>
    /// ECM Controller
    /// </summary>
    /// <seealso cref="Controller" />
    public class EcmController : Controller
    {

        #region Private Properties

        /// <summary>
        /// Gets the utility.
        /// </summary>
        /// <value>
        /// The utility.
        /// </value>
        private Utility Utility => new Utility(Log, User);

        /// <summary>
        /// Gets the log path.
        /// </summary>
        /// <value>
        /// The log path.
        /// </value>
        private string LogPath => Server != null ? Server.MapPath("~") ?? Environment.CurrentDirectory : Environment.CurrentDirectory;

        /// <summary>
        /// Gets the log.
        /// </summary>
        /// <value>
        /// The log.
        /// </value>
        private Logger Log => new Logger(
            string.Format(CultureInfo.CurrentCulture,
                Resources.EcmController_Log_ECM_Integration_Log__0__UTC_txt,
                DateTime.UtcNow.Date.ToString(CultureInfo.CurrentCulture).Replace(
                    Resources.EcmController_Log__00_00_00,
                    string.Empty).Replace(Resources.EcmController_Log__,
                    string.Empty),
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[0] :
                    "NoDomainFound",
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[1] :
                    "NoUserFound"),
            Resources.EcmController_Log_ECM_Integration,
            HttpContext.IsDebuggingEnabled,
            LogPath,
            ConfigurationManager.AppSettings["EventLogDomain"],
            ConfigurationManager.AppSettings["EventLogUser"],
            ConfigurationManager.AppSettings["EventLogPassword"]);

        #endregion

        #region Private Methods


        /// <summary>
        /// Sets the view bag properties.
        /// </summary>
        private void SetViewBagProperties()
        {
            Log.Log(Resources.EcmController_SetViewBagProperties_Setting_View_Bag_Properties___1, LogLevel.Information);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_RBS_Company_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for RBS Company Drop Down List.
            ViewBag.Companies = EnumHelper.GetSelectList(typeof(RBSCompany)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_Classification_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for Classification Drop Down List.
            ViewBag.Classifications = EnumHelper.GetSelectList(typeof(RBSClassification)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_Language_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for Language Drop Down List.
            ViewBag.Languages = EnumHelper.GetSelectList(typeof(Language)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_Jurisdiction_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for Jurisdiction Drop Down List.
            ViewBag.Jurisdictions = EnumHelper.GetSelectList(typeof(RBSJurisdiction)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_HighRiskRecord_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for High Risk Record Drop Down List.
            ViewBag.HighRiskRecords = EnumHelper.GetSelectList(typeof(RBSHighRiskRecord)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Collection_for_Record_Types_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Collection for Record Types Drop Down List.
            IEnumerable<string> recordTypes = Utility.RecordTypes;
            Log.Log(Resources.EcmController_SetViewBagProperties_Set_Select_List_for_Record_Types_Drop_Down_List_1, LogLevel.Debug);
            //Set Select List for Record Types Drop Down List.
            ViewBag.RecordTypes = new SelectList(recordTypes).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Setting_View_Bag_Properties_completed_1, LogLevel.Information);
        }

        /// <summary>
        /// Sets the view bag properties.
        /// </summary>
        /// <param name="entity">The entity.</param>
        private void SetViewBagProperties(Entity entity)
        {
            Log.Log(Resources.EcmController_SetViewBagProperties_Setting_View_Bag_Properties_from_Entity___1, LogLevel.Information);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_RBS_Company_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for RBS Company Drop Down List.
            ViewBag.Companies = EnumHelper.GetSelectList(typeof(RBSCompany)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_Classification_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for Classification Drop Down List.
            ViewBag.Classifications = EnumHelper.GetSelectList(typeof(RBSClassification)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_Language_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for Language Drop Down List.
            ViewBag.Languages = EnumHelper.GetSelectList(typeof(Language)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_Jurisdiction_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for Jurisdiction Drop Down List.
            ViewBag.Jurisdictions = EnumHelper.GetSelectList(typeof(RBSJurisdiction)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Select_List_for_HighRiskRecord_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Select List for High Risk Record Drop Down List.
            ViewBag.HighRiskRecords = EnumHelper.GetSelectList(typeof(RBSHighRiskRecord)).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Instantiate_Collection_for_Record_Types_Drop_Down_List_1, LogLevel.Debug);
            //Instantiate Collection for Record Types Drop Down List.
            IEnumerable<string> recordTypes = Utility.RecordTypes;
            Log.Log(Resources.EcmController_SetViewBagProperties_Set_Select_List_for_Record_Types_Drop_Down_List_1, LogLevel.Debug);
            //Set Select List for Record Types Drop Down List.
            ViewBag.RecordTypes = new SelectList(recordTypes, entity.RecordType).OrderBy(x => x.Text);
            Log.Log(Resources.EcmController_SetViewBagProperties_Setting_View_Bag_Properties_completed_1, LogLevel.Information);
        }

        /// <summary>
        /// Returns the posted files.
        /// </summary>
        /// <param name="files">The files.</param>
        /// <returns></returns>
        private static IEnumerable<PostedFile> PostedFiles(IEnumerable<HttpPostedFileBase> files)
        {
            Collection<PostedFile> postedFiles = new Collection<PostedFile>();
            foreach (HttpPostedFileBase httpPostedFileBase in files)
            {
                byte[] fileData = new byte[httpPostedFileBase.ContentLength];
                httpPostedFileBase.InputStream.Read(fileData, 0, httpPostedFileBase.ContentLength);
                postedFiles.Add(new PostedFile(httpPostedFileBase.ContentLength, httpPostedFileBase.ContentType,
                    httpPostedFileBase.FileName, fileData));
            }

            return postedFiles;
        }

        /// <summary>
        /// Task to return the HTTP response message.
        /// </summary>
        /// <param name="requestUri">The request URI.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        private static Task<HttpResponseMessage> HttpResponseMessageTask(string requestUri, Upload value)
        {
            using (HttpClientHandler httpClientHandler = new HttpClientHandler { UseDefaultCredentials = true })
            {
                using (HttpClient httpClient = new HttpClient(httpClientHandler))
                {
                    httpClient.BaseAddress = new Uri(ConfigurationManager.AppSettings[Resources.EcmController_UploadDocument_EcmIntegrationWebApi]);
                    Task<HttpResponseMessage> httpResponseMessageTask = httpClient.PostAsJsonAsync(requestUri, value);
                    httpResponseMessageTask.Wait();
                    return httpResponseMessageTask;
                }
            }
        }

        /// <summary>
        /// Task to return the HTTP response message.
        /// </summary>
        /// <param name="requestUri">The request URI.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        private static Task<HttpResponseMessage> HttpResponseMessageTask(string requestUri, Entity value)
        {
            using (HttpClientHandler httpClientHandler = new HttpClientHandler { UseDefaultCredentials = true })
            {
                using (HttpClient httpClient = new HttpClient(httpClientHandler))
                {
                    httpClient.BaseAddress = new Uri(ConfigurationManager.AppSettings[Resources.EcmController_UploadDocument_EcmIntegrationWebApi]);
                    Task<HttpResponseMessage> httpResponseMessageTask = httpClient.PostAsJsonAsync(requestUri, value);
                    httpResponseMessageTask.Wait();
                    return httpResponseMessageTask;
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Returns the spinner view.
        /// </summary>
        /// <returns></returns>
        public ActionResult Spinner()
        {
            Log.Log(Resources.EcmController_Spinner_Starting_Spinner___1, LogLevel.Information);
            return PartialView(Resources.EcmController_Spinner_Spinner);
        }

        /// <summary>
        /// Returns the success view.
        /// </summary>
        /// <returns></returns>
        public ActionResult Success()
        {
            Log.Log(Resources.EcmController_Success_Returning_Success_View___1, LogLevel.Information);
            return PartialView(Resources.EcmController_Success_Success);
        }

        /// <summary>
        /// Returns the <strong>no file selected</strong> view.
        /// </summary>
        /// <returns></returns>
        public ActionResult NoFileSelected()
        {
            Log.Log(Resources.EcmController_NoFileSelected_Returning_No_File_Selected_View___1, LogLevel.Information);
            return PartialView(Resources.EcmController_NoFileSelected_NoFileSelected);
        }

        /// <summary>
        /// Returns the error view.
        /// </summary>
        /// <param name="errorMessage">The error message.</param>
        /// <returns></returns>
        public ActionResult Error(string errorMessage)
        {
            Log.Log(Resources.EcmController_Error_Returning_Error_View___1, LogLevel.Information);
            Log.Log(Resources.EcmController_Error_Setting_error_message___1, LogLevel.Debug);
            ApplicationError error = new ApplicationError
            {
                Message = errorMessage
            };
            Log.Log(Resources.EcmController_Error_Returning_Error_View___1, LogLevel.Debug);
            return PartialView(Resources.EcmController_Error_Error, error);
        }

        /// <summary>
        /// Returns the <strong>upload error</strong> view.
        /// </summary>
        /// <returns></returns>
        public ActionResult UploadError()
        {
            Log.Log(Resources.EcmController_UploadError_Returning_Upload_Error_View___1, LogLevel.Information);
            return PartialView(Resources.EcmController_UploadError_UploadError);
        }

        /// <summary>
        /// Returns the upload view.
        /// </summary>
        /// <param name="id">The entity identifier.</param>
        /// <param name="typename">Name of the entity.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "typename")]
        public ActionResult Upload(Guid id, string typename)
        {
            Log.Log(Resources.EcmController_Upload_Retrieving_Upload_View___1, LogLevel.Information);
            //Is the User Authenticated?
            if (!Utility.IsAuthenticated)
            {
                //Return No Permission View...
                Log.Log(Resources.EcmController_Upload_The_user_was_not_successfully_authenticated_1, LogLevel.Warning);
                return View(Resources.EcmController_Upload_NoPermission, new PermissionError { Identity = User.Identity, Error = Utility.CrmError, Exception = Utility.CrmException });
            }
            Log.Log(Resources.EcmController_Upload_Getting_Entity___1, LogLevel.Debug);
            //Get entity...
            Entity entity = Utility.GetEntity(id, typename);
            Log.Log(Resources.EcmController_GetEntity_Setting_the_View_Bag_Properties___1, LogLevel.Debug);
            SetViewBagProperties();
            Log.Log(Resources.EcmController_Upload_Returning_Upload_View___1, LogLevel.Information);
            //Return View...
            return View(entity);
        }

        /// <summary>
        /// Uploads the document and metadata.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="files">The files.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException">
        /// entity
        /// or
        /// entity
        /// </exception>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [SuppressMessage("Microsoft.Usage", "CA2234:PassSystemUriObjectsInsteadOfStrings")]
        [HttpPost]
        public ActionResult Upload(Entity entity, IEnumerable<HttpPostedFileBase> files)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException(nameof(entity));
                }
                if (!ModelState.IsValid)
                {
                    return Upload(entity.EntityId, entity.EntityName);
                }
                if (files == null)
                {
                    throw new ArgumentNullException(nameof(files));
                }
                Task<HttpResponseMessage> httpResponseMessageTask = HttpResponseMessageTask(Resources.EcmController_UploadDocument_api_upload, new Upload(entity, PostedFiles(files)));
                if (!httpResponseMessageTask.Result.IsSuccessStatusCode)
                {
                    return Json(new { success = false, response = httpResponseMessageTask.Exception?.Message ?? Resources.EcmController_UploadDocument_An_error_occurred_ });
                }
                Task<Result> content = httpResponseMessageTask.Result.Content.ReadAsAsync<Result>();
                content.Wait();
                SetViewBagProperties(entity);
                Result result = content.Result;
                return Json(!result.Success ? new { success = false, response = result.Response } : new { success = true, response = Resources.EcmController_UploadDocument_File_s__uploaded_1 });
            }
            catch (Exception exception)
            {
                return Json(new { success = false, response = exception.Message });
            }
        }

        /// <summary>
        /// Returns the download view.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="typename">The typename.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "typename")]
        public ActionResult Download(Guid id, string typename)
        {
            Log.Log(Resources.EcmController_Download_Opening_Download_View___1, LogLevel.Information);
            Log.Log(Resources.EcmController_UploadDocument_Is_the_User_Authenticated_1, LogLevel.Debug);
            //Is the User Authenticated?
            if (!Utility.IsAuthenticated)
            {
                Log.Log(Resources.EcmController_IsAuthenticated_User_is_not_Authenticated_1, LogLevel.Error);
                Log.Log(Utility.CrmError, LogLevel.Error);
                //Return No Permission View...
                return View(Resources.EcmController_Upload_NoPermission, new PermissionError { Identity = User.Identity, Error = Utility.CrmError, Exception = Utility.CrmException });
            }
            Log.Log(Resources.EcmController_Download_Check_if_type_name_is_null___1, LogLevel.Debug);
            //Check if type name is null...
            if (string.IsNullOrEmpty(typename))
            {
                Log.Log(Resources.EcmController_Download_Instantiate_exception___1, LogLevel.Debug);
                //Instantiate exception...
                Exception exception = new ArgumentNullException(nameof(typename));
                Log.Log(Resources.EcmController_Download_Instantiate_Error_View___1, LogLevel.Debug);
                //Instantiate Error View...
                ApplicationError error = new ApplicationError
                {
                    Message = exception.Message,
                    StackTrace = exception.StackTrace
                };
                Log.Log(exception.Message, LogLevel.Error);
                Log.Log(exception.StackTrace, LogLevel.Error);
                Log.Log(Resources.EcmController_Download_Return_error_response___1, LogLevel.Debug);
                //Return error response...
                return View(Resources.EcmController_Error_Error, error);
            }
            Log.Log(Resources.EcmController_Download_Get_entity___1, LogLevel.Debug);
            //Get entity...
            Entity entity = Utility.GetEntity(id, typename);
            Log.Log(Resources.EcmController_GetEntity_Setting_the_View_Bag_Properties___1, LogLevel.Debug);
            SetViewBagProperties();
            Log.Log(Resources.EcmController_Download_Return_View___1, LogLevel.Debug);
            //Return View...
            return View(entity);
        }

        /// <summary>
        /// Downloads the document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException">entity
        /// or
        /// entity</exception>
        /// <exception cref="WebApplicationException">Entity identifier is not specified
        /// or
        /// Entity is not a Document.
        /// or
        /// Document not found!
        /// or
        /// Service Client Credentials cannot be null</exception>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [SuppressMessage("Microsoft.Usage", "CA2234:PassSystemUriObjectsInsteadOfStrings")]
        [HttpPost]
        public ActionResult Download(Entity entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException(nameof(entity));
                }
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Task<HttpResponseMessage> httpResponseMessageTask = HttpResponseMessageTask(Resources.EcmController_DownloadDocument_api_download, entity);
                if (!httpResponseMessageTask.Result.IsSuccessStatusCode)
                {
                    Log.Log(Resources.EcmController_DownloadDocument_Instantiate_Error___1, LogLevel.Debug);
                    //Get error...
                    ApplicationError error = new ApplicationError
                    {
                        Message = httpResponseMessageTask.Exception?.Message,
                        StackTrace = httpResponseMessageTask.Exception?.StackTrace
                    };
                    Log.Log(httpResponseMessageTask.Exception?.Message, LogLevel.Error);
                    Log.Log(httpResponseMessageTask.Exception?.StackTrace, LogLevel.Error);
                    //Return error view...
                    return View(Resources.EcmController_Error_Error, error);
                }
                Task<Models.Document> content = httpResponseMessageTask.Result.Content.ReadAsAsync<Models.Document>();
                content.Wait();
                SetViewBagProperties(entity);
                return File(content.Result.ContentStream, MediaTypeNames.Application.Octet, content.Result.DocumentName);
            }
            catch (Exception exception)
            {
                Log.Log(Resources.EcmController_DownloadDocument_Instantiate_Error___1, LogLevel.Debug);
                //Get error...
                ApplicationError error = new ApplicationError
                {
                    Message = exception.Message,
                    StackTrace = exception.StackTrace
                };
                Log.Log(exception.Message, LogLevel.Error);
                Log.Log(exception.StackTrace, LogLevel.Error);
                //Return error view...
                return View(Resources.EcmController_Error_Error, error);
            }
        }

        /// <summary>
        /// Returns the update view.
        /// </summary>
        /// <param name="id">The entity identifier.</param>
        /// <param name="typename">Name of the entity.</param>
        /// <returns></returns>
        [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "typename")]
        public ActionResult Update(Guid id, string typename)
        {
            Log.Log(Resources.EcmController_Update_Instantiate_View___1, LogLevel.Debug);
            Log.Log(Resources.EcmController_UploadDocument_Is_the_User_Authenticated_1, LogLevel.Debug);
            //Is the User Authenticated?
            if (!Utility.IsAuthenticated)
            {
                Log.Log(Resources.EcmController_Update_User_was_not_authenticated_1, LogLevel.Error);
                //Return No Permission View...
                return View(Resources.EcmController_Upload_NoPermission, new PermissionError { Identity = User.Identity, Error = Utility.CrmError, Exception = Utility.CrmException });
            }
            Log.Log(Resources.EcmController_Download_Get_entity___1, LogLevel.Debug);
            //Get entity...
            Entity entity = Utility.GetExistingEntity(id, typename);
            Log.Log(Resources.EcmController_GetExistingEntity_Setting_the_View_Bag_Properties_based_on_the_Entity_values___1, LogLevel.Debug);
            SetViewBagProperties(entity);
            Log.Log(Resources.EcmController_Download_Return_View___1, LogLevel.Debug);
            //Return View...
            return View(entity);
        }

        /// <summary>
        /// Updates the metadata.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException">
        /// entity
        /// or
        /// entity
        /// </exception>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [SuppressMessage("Microsoft.Usage", "CA2234:PassSystemUriObjectsInsteadOfStrings")]
        [HttpPost]
        public ActionResult Update(Entity entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException(nameof(entity));
                }
                if (!ModelState.IsValid)
                {
                    return Update(entity.EntityId, entity.EntityName);
                }
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Task<HttpResponseMessage> httpResponseMessageTask = HttpResponseMessageTask(Resources.EcmController_Update_api_update, entity);
                if (!httpResponseMessageTask.Result.IsSuccessStatusCode)
                {
                    return Json(new { success = false, response = httpResponseMessageTask.Exception?.Message ?? Resources.EcmController_UploadDocument_An_error_occurred_ });
                }
                Task<Result> content = httpResponseMessageTask.Result.Content.ReadAsAsync<Result>();
                content.Wait();
                Result result = content.Result;
                SetViewBagProperties(entity);
                return Json(!result.Success ? new { success = false, response = result.Response } : new { success = true, response = Resources.EcmController_UploadDocument_File_s__uploaded_1 });
            }
            catch (Exception exception)
            {
                return Json(new { success = false, response = exception.Message });
            }
        }

        #endregion

    }
}