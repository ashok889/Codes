﻿namespace Rbs.D365.EcmIntegrate.WebApi.Logging
{
    /// <summary>
    /// Logger Interface
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="logLevel">The log level.</param>
        void Log(string message, LogLevel logLevel);
    }
}
