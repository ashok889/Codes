﻿using System;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;
using System.Web.Http;
using Rbs.D365.EcmIntegrate.WebApi.Logging;
using Rbs.D365.EcmIntegrate.WebApi.Properties;

namespace Rbs.D365.EcmIntegrate.WebApi.Controllers
{
    /// <summary>
    /// Authentication Controller
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    public class AuthenticationController : ApiController
    {
        #region Private Properties

        /// <summary>
        /// Gets the log path.
        /// </summary>
        /// <value>
        /// The log path.
        /// </value>
        private static string LogPath => HostingEnvironment.MapPath("~") ?? Environment.CurrentDirectory;

        /// <summary>
        /// Gets the utility.
        /// </summary>
        /// <value>
        /// The utility.
        /// </value>
        private Utility Utility => new Utility(Log, User);

        /// <summary>
        /// Gets the log.
        /// </summary>
        /// <value>
        /// The log.
        /// </value>
        private Logger Log => new Logger(
            string.Format(CultureInfo.CurrentCulture,
                Resources.EcmController_Log_ECM_Integration_Log__0__UTC_txt,
                DateTime.UtcNow.Date.ToString(CultureInfo.CurrentCulture).Replace(
                    Resources.EcmController_Log__00_00_00,
                    string.Empty).Replace(Resources.EcmController_Log__,
                    string.Empty),
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[0] :
                    "NoDomainFound",
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[1] :
                    "NoUserFound"),
            Resources.EcmController_Log_ECM_Integration,
            HttpContext.Current.IsDebuggingEnabled,
            LogPath,
            ConfigurationManager.AppSettings["EventLogDomain"],
            ConfigurationManager.AppSettings["EventLogUser"],
            ConfigurationManager.AppSettings["EventLogPassword"]);

        #endregion

        #region Public Methods

        /// <summary>
        /// Determines whether this instance is authenticated.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public Task<IHttpActionResult> IsAuthenticated()
        {
            return Task.FromResult<IHttpActionResult>(Ok(Utility.IsAuthenticated));
        }

        #endregion
    }
}
