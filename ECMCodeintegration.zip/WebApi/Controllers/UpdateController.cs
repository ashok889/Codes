﻿using System;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;
using System.Web.Http;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using Rbs.D365.EcmIntegrate.Model;
using Rbs.D365.EcmIntegrate.WebApi.Logging;
using Rbs.D365.EcmIntegrate.WebApi.Models;
using Rbs.D365.EcmIntegrate.WebApi.Properties;
using Document = Rbs.D365.EcmIntegrate.Model.Document;
using Entity = Rbs.D365.EcmIntegrate.WebApi.Models.Entity;

namespace Rbs.D365.EcmIntegrate.WebApi.Controllers
{
    /// <summary>
    /// Update Controller
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    public class UpdateController : ApiController
    {

        #region Private Properties

        /// <summary>
        /// Gets the log path.
        /// </summary>
        /// <value>
        /// The log path.
        /// </value>
        private static string LogPath => HostingEnvironment.MapPath("~") ?? Environment.CurrentDirectory;

        /// <summary>
        /// Gets the ecm.
        /// </summary>
        /// <value>
        /// The ecm.
        /// </value>
        private Utility Ecm => new Utility(Log, User);

        /// <summary>
        /// Gets the log.
        /// </summary>
        /// <value>
        /// The log.
        /// </value>
        private Logger Log => new Logger(
            string.Format(CultureInfo.CurrentCulture,
                Resources.EcmController_Log_ECM_Integration_Log__0__UTC_txt,
                DateTime.UtcNow.Date.ToString(CultureInfo.CurrentCulture).Replace(
                    Resources.EcmController_Log__00_00_00,
                    string.Empty).Replace(Resources.EcmController_Log__,
                    string.Empty),
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[0] :
                    "NoDomainFound",
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[1] :
                    "NoUserFound"),
            Resources.EcmController_Log_ECM_Integration,
            HttpContext.Current.IsDebuggingEnabled,
            LogPath,
            ConfigurationManager.AppSettings["EventLogDomain"],
            ConfigurationManager.AppSettings["EventLogUser"],
            ConfigurationManager.AppSettings["EventLogPassword"]);

        #endregion

        #region Public Methods

        /// <summary>
        /// Updates the metadata.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [HttpPost]
        public Task<IHttpActionResult> Update(Entity entity)
        {
            DateTime start = DateTime.UtcNow;
            Log.Log(Resources.EcmController_Update_Updating_metadata___1, LogLevel.Information);
            try
            {
                Log.Log(Resources.EcmController_Update_Return_exception_if_entity_is_null___1, LogLevel.Debug);
                //Return exception if entity is null...
                if (entity == null)
                {
                    Log.Log(Resources.EcmController_Update_Entity_is_null__Send_failure_response___1, LogLevel.Error);
                    //Return error...
                    return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = false, Response = new ArgumentNullException(nameof(entity)).Message }));
                }
                Log.Log(Resources.EcmController_Update_Were_there_any_validation_errors_1, LogLevel.Debug);
                //Were there any validation errors?
                if (!ModelState.IsValid)
                {
                    Log.Log(Resources.EcmController_Update_Model_State_is_not_Valid__Send_failure_response___1, LogLevel.Error);
                    //Return error...
                    return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = false, Response = Resources.EcmController_Update_Model_was_invalid_1 }));
                }
                Log.Log(Resources.EcmController_UploadDocument_Is_the_User_Authenticated_1, LogLevel.Debug);
                //Is the User Authenticated?
                if (!Ecm.IsAuthenticated)
                {
                    Log.Log(Resources.EcmController_UploadDocument_User_has_not_been_authenticated_1, LogLevel.Error);
                    //Return exception if user has not been authenticated...
                    return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = false, Response = Resources.EcmController_UploadDocument_User_has_not_been_authenticated_1 }));
                }
                Log.Log(Resources.EcmController_UploadDocument_Check_for_Current_User___1, LogLevel.Debug);
                //Check for Current User...
                if (Ecm.CurrentUser?.SystemUserId == null)
                {
                    Log.Log(Resources.EcmController_UploadDocument_Current_user_cannot_be_found_1, LogLevel.Error);
                    //Return exception if current user can't be found...
                    return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = false, Response = Resources.EcmController_UploadDocument_Current_user_cannot_be_found_1 }));
                }
                Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1, LogLevel.Debug);
                //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
                //Connect to Dynamics 365...
                using (CrmServiceClient crmServiceClient =
                    new CrmServiceClient(ConfigurationManager.ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365].ConnectionString))
                {
                    Log.Log(Resources.EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1, LogLevel.Debug);
                    //Check for successful authentication with Dynamics 365...
                    if (!crmServiceClient.IsReady)
                    {
                        Log.Log(Resources.EcmController_IsAuthenticated_An_error_occurred_when_connecting_to_Dynamics_365_1, LogLevel.Warning);
                        Log.Log(crmServiceClient.LastCrmError, LogLevel.Error);
                        //Dynamics 365 is not ready...
                        return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = false, Response = crmServiceClient.LastCrmError }));
                    }
                    Log.Log(Resources.EcmController_UploadDocument_Setting_the_calling_user_to_the_current_user______1, LogLevel.Debug);
                    //Set Calling User to Current User...
                    crmServiceClient.CallerId = Ecm.CurrentUser.SystemUserId.Value;
                    Log.Log(Resources.EcmController_IsAuthenticated_Instantiating_Dynamics_365_context___1, LogLevel.Debug);
                    //Instantiate Dynamics 365 Service Context...
                    if (UpdateDocument(entity, crmServiceClient, start, out IHttpActionResult update))
                    {
                        return Task.FromResult(update);
                    }
                }
                Log.Log(Resources.EcmController_Update_Set_View_Bag_Properties_by_Entity___1, LogLevel.Debug);
                //Set View Bag Properties by Entity...
                Log.Log(Resources.EcmController_Update_Metadata_updated__Send_success_response___1, LogLevel.Information);
                //Return a successful response...
                return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = true, Response = Resources.EcmController_Update_Metadata_updated_1 }));
            }
            catch (Exception exception)
            {
                return Task.FromResult(HandleException(entity, exception, start));
            }
        }

        /// <summary>
        /// Updates the document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="crmServiceClient">The CRM service client.</param>
        /// <param name="start">The start.</param>
        /// <param name="update">The update.</param>
        /// <returns></returns>
        private bool UpdateDocument(Entity entity, IOrganizationService crmServiceClient, DateTime start,
            out IHttpActionResult update)
        {
            using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
            {
                Log.Log(Resources.EcmController_UploadDocument_Get_Record_Type_from_Dynamics_365___1, LogLevel.Debug);
                //Get Record Type from Dynamics 365...
                RecordType crmRecordType = Ecm.GetRecordType(entity, xrmServiceContext);
                Log.Log(Resources.EcmController_UploadDocument_Get_Record_Class_from_Dynamics_365___1, LogLevel.Debug);
                //Get Record Class from Dynamics 365...
                RecordClass crmRecordClass = Ecm.GetRecordClass(xrmServiceContext, crmRecordType);
                Log.Log(Resources.EcmController_Update_Set_Record_Code___1, LogLevel.Debug);
                //Set Record Class Code...
                string recordClassCode = crmRecordClass?.RecordClassCode;
                Log.Log(Resources.EcmController_DownloadDocument_Get_the_Document_from_Dynamics_365___1, LogLevel.Debug);
                //Get the Document from Dynamics 365...
                Document document = xrmServiceContext.DocumentSet.FirstOrDefault(d => d.Id == entity.EntityId);
                Log.Log(Resources.EcmController_Update_Check_for_null_document___1, LogLevel.Debug);
                //Check for null document...
                if (document?.DocumentId == null)
                {
                    Log.Log(Resources.EcmController_DownloadDocument_Document_not_found_1, LogLevel.Error);
                    //Return error...
                    {
                        update = Ok(new
                            {success = false, response = Resources.EcmController_DownloadDocument_Document_not_found_1});
                        return true;
                    }
                }

                Log.Log(Resources.EcmController_Update_Send_the_Updated_Metadata_to_ECM___1, LogLevel.Debug);
                //Send the Updated Metadata to ECM...
                Ecm.SendUpdatedMetadataToEcm(entity, document.DocumentName, recordClassCode, document.CMISObjectIdentifier);
                Log.Log(Resources.EcmController_ValidateResponse_Update_the_Document_in_Dynamics_365___1, LogLevel.Debug);
                //Update the Document in Dynamics 365...
                Ecm.UpdateDocumentInDynamics365(entity, document, xrmServiceContext, start);
            }

            update = Ok(new Result { Success = true, Response = Resources.EcmController_Update_Metadata_updated_1 });
            return false;
        }

        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="exception">The exception.</param>
        /// <param name="start">The start.</param>
        /// <returns></returns>
        private IHttpActionResult HandleException(Entity entity, Exception exception, DateTime start)
        {
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Instantiate_new_access_log_recording___1,
                LogLevel.Debug);
            Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1,
                LogLevel.Debug);
            //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
            //Connect to Dynamics 365...
            using (CrmServiceClient crmServiceClient =
                new CrmServiceClient(ConfigurationManager
                    .ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365].ConnectionString))
            {
                Log.Log(
                    Resources
                        .EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1,
                    LogLevel.Debug);
                //Check for successful authentication with Dynamics 365...
                return !crmServiceClient.IsReady
                    ? Ok(new {success = false, response = exception.Message})
                    : CreateAccessLogForDocument(entity, crmServiceClient, exception, start);
                //Instantiate Dynamics 365 Service Context...
            }
        }

        /// <summary>
        /// Creates the access log for the document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="crmServiceClient">The CRM service client.</param>
        /// <param name="exception">The exception.</param>
        /// <param name="start">The start.</param>
        /// <returns></returns>
        private IHttpActionResult CreateAccessLogForDocument(Entity entity, IOrganizationService crmServiceClient,
            Exception exception, DateTime start)
        {
            using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
            {
                Log.Log(Resources.EcmController_DownloadDocument_Get_the_Document_from_Dynamics_365___1,
                    LogLevel.Debug);
                //Get the Document from Dynamics 365...
                Document document = xrmServiceContext.DocumentSet.FirstOrDefault(d => d.Id == entity.EntityId);
                Log.Log(Resources.EcmController_DownloadDocument_Check_if_Document_found_in_Dynamics_365___1,
                    LogLevel.Debug);
                //Check if Document found in Dynamics 365...
                if (document?.DocumentId == null)
                {
                    Log.Log(Resources.EcmController_DownloadDocument_Document_not_found_in_Dynamics_365_1,
                        LogLevel.Warning);
                    //Return error...
                    return Ok(new {success = false, response = exception.Message});
                }

                //Instantiate new access log recording...
                Ecm.CreateAccessLog(xrmServiceContext, document.Id,
                    string.Format(CultureInfo.CurrentCulture,
                        Resources.EcmController_UpdateDocumentInDynamics365__0__was_updated_at__1__UTC_by__2_1,
                        document.DocumentName,
                        document.ModifiedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                        document.ModifiedBy != null
                            ? ((SystemUser) crmServiceClient.Retrieve(SystemUser.EntityLogicalName,
                                document.ModifiedBy.Id, new ColumnSet(true)))?.FullName
                            : Ecm.CurrentUser?.FullName),
                    string.Format(CultureInfo.CurrentCulture,
                        Resources.EcmController_UpdateDocumentInDynamics365__0__was_updated_at__1__UTC_by__2_1,
                        document.DocumentName,
                        document.ModifiedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                        document.ModifiedBy != null
                            ? ((SystemUser) crmServiceClient.Retrieve(SystemUser.EntityLogicalName,
                                document.ModifiedBy.Id, new ColumnSet(true)))?.FullName
                            : Ecm.CurrentUser?.FullName),
                    new OptionSetValue((int) Model.Action.Update),
                    start,
                    DateTime.UtcNow,
                    AccessLogStatusReason.Failure);
                Log.Log(Resources.EcmController_Update_Metadata_not_updated__Send_failure_response___1, LogLevel.Error);
                //Return error...
                return Ok(new {success = false, response = exception.Message});
            }
        }
    }

    #endregion
}