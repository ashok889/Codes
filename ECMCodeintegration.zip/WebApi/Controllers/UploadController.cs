﻿using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;
using System.Web.Http;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using Rbs.D365.EcmIntegrate.Model;
using Rbs.D365.EcmIntegrate.WebApi.EcmService;
using Rbs.D365.EcmIntegrate.WebApi.Logging;
using Rbs.D365.EcmIntegrate.WebApi.Models;
using Rbs.D365.EcmIntegrate.WebApi.Properties;
using Document = Rbs.D365.EcmIntegrate.Model.Document;
using Entity = Rbs.D365.EcmIntegrate.WebApi.Models.Entity;

namespace Rbs.D365.EcmIntegrate.WebApi.Controllers
{
    /// <summary>
    /// Upload Controller
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    public class UploadController : ApiController
    {
        #region Private Properties

        /// <summary>
        /// Gets the log path.
        /// </summary>
        /// <value>
        /// The log path.
        /// </value>
        private static string LogPath => HostingEnvironment.MapPath("~") ?? Environment.CurrentDirectory;

        /// <summary>
        /// Gets the ecm.
        /// </summary>
        /// <value>
        /// The ecm.
        /// </value>
        private Utility Utility => new Utility(Log, User);

        /// <summary>
        /// Gets the log.
        /// </summary>
        /// <value>
        /// The log.
        /// </value>
        private Logger Log => new Logger(
            string.Format(CultureInfo.CurrentCulture,
                Resources.EcmController_Log_ECM_Integration_Log__0__UTC_txt,
                DateTime.UtcNow.Date.ToString(CultureInfo.CurrentCulture).Replace(
                    Resources.EcmController_Log__00_00_00,
                    string.Empty).Replace(Resources.EcmController_Log__,
                    string.Empty),
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[0] :
                    "NoDomainFound",
                User?.Identity != null &&
                !string.IsNullOrEmpty(User.Identity.Name) &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Any() &&
                User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2).Length == 2 ?
                    User.Identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[1] :
                    "NoUserFound"),
            Resources.EcmController_Log_ECM_Integration,
            HttpContext.Current.IsDebuggingEnabled,
            LogPath,
            ConfigurationManager.AppSettings["EventLogDomain"],
            ConfigurationManager.AppSettings["EventLogUser"],
            ConfigurationManager.AppSettings["EventLogPassword"]);

        #endregion

        #region Public Methods

        /// <summary>
        /// Uploads the file(s) and metadata.
        /// </summary>
        /// <param name="uploadContent">Content of the upload.</param>
        /// <returns></returns>
        /// <exception cref="HttpResponseException">
        /// </exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [HttpPost]
        public Task<IHttpActionResult> Upload(Upload uploadContent)
        {
            DateTime start = DateTime.UtcNow;
            Log.Log(Resources.EcmController_UploadDocument_Uploading_Document___1, LogLevel.Information);
            Log.Log(Resources.EcmController_UploadDocument_Instantiating_Document___1, LogLevel.Debug);
            //Instantiate Document...
            Document document = new Document();
            try
            {
                //Check if upload content is null.
                Log.Log(Resources.UploadController_Upload_Check_if_upload_content_is_null_, LogLevel.Debug);
                if (uploadContent == null)
                {
                    throw new ArgumentNullException(nameof(uploadContent));
                }
                if (uploadContent.Entity == null)
                {
                    throw new ArgumentNullException(nameof(uploadContent));
                }
                if (uploadContent.PostedFiles == null || !uploadContent.PostedFiles.Any())
                {
                    throw new ArgumentNullException(nameof(uploadContent));
                }
                Log.Log(Resources.EcmController_UploadDocument_Is_Model_valid_1, LogLevel.Debug);
                //Were there any validation errors?
                if (ModelState.IsValid)
                {
                    Log.Log(Resources.EcmController_UploadDocument_Model_is_valid_1, LogLevel.Debug);
                    Log.Log(Resources.EcmController_UploadDocument_Process_files___1, LogLevel.Debug);
                    foreach (PostedFile file in uploadContent.PostedFiles)
                    {
                        document = Response(uploadContent, file, start, out string response);
                        if (!string.IsNullOrEmpty(response))
                        {
                            return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = false, Response = response }));
                        }
                    }
                    Log.Log(Resources.EcmController_UploadDocument_Set_View_Bag_Properties_from_Entity___1, LogLevel.Debug);
                    //Set View Bag Properties from Entity...
                    Log.Log(Resources.EcmController_UploadDocument_Return_a_successful_response___1, LogLevel.Information);
                    //Return a successful response...
                    return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = true, Response = Resources.EcmController_UploadDocument_File_s__uploaded_1 }));
                }
            }
            catch (Exception exception)
            {
                return Task.FromResult(HandleException(document, exception, start));
            }
            Log.Log(Resources.EcmController_UploadDocument_Set_View_Bag_Properties_from_Entity___1, LogLevel.Debug);
            //Set View Bag Properties from Entity...
            Log.Log(Resources.EcmController_UploadDocument_Return_a_successful_response___1, LogLevel.Information);
            //Return a successful response...
            return Task.FromResult<IHttpActionResult>(Ok(new Result { Success = true, Response = Resources.EcmController_UploadDocument_File_s__uploaded_1 }));
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Responses the specified upload content.
        /// </summary>
        /// <param name="uploadContent">Content of the upload.</param>
        /// <param name="file">The file.</param>
        /// <param name="start">The start.</param>
        /// <param name="response">The response.</param>
        /// <returns></returns>
        private Document Response(Upload uploadContent, PostedFile file, DateTime start, out string response)
        {
            if (uploadContent == null)
            {
                throw new ArgumentNullException(nameof(uploadContent));
            }
            if (file == null)
            {
                throw new ArgumentNullException(nameof(file));
            }
            if (start == null)
            {
                throw new ArgumentNullException(nameof(start));
            }
            Document document = new Document();
            response = string.Empty;
            Log.Log(Resources.EcmController_UploadDocument_Check_if_the_file_is_null_or_has_no_content___1, LogLevel.Debug);
            //Check if the file is Null or has no content.
            if (file.ContentLength <= 0)
            {
                Log.Log(Resources.EcmController_UploadDocument_File_is_null_or_does_not_have_content_1, LogLevel.Error);
                //Return exception if file is null or does not have content...
                response = Resources.EcmController_UploadDocument_File_is_null_or_does_not_have_content_1;
            }

            Log.Log(Resources.EcmController_UploadDocument_Get_the_file_name___1, LogLevel.Debug);
            //Get the file name...
            string fileName = Path.GetFileName(file.FileName);
            Log.Log(Resources.EcmController_UploadDocument_Get_the_file_s_full_path___1, LogLevel.Debug);
            //Get the file's full path...
            string fullPath = Path.GetFullPath(file.FileName);
            Log.Log(
                Resources
                    .EcmController_UploadDocument_Check_to_see_if_the_browser_has_provided_the_full_path_of_the_file_or_blocked_it_for_security_reasons___1,
                LogLevel.Debug);
            //Check to see if the browser has provided the full path of the file or blocked it for security reasons...
            if (!string.IsNullOrEmpty(fileName) && !string.IsNullOrEmpty(fullPath))
            {
                Log.Log(
                    Resources
                        .EcmController_UploadDocument_The_browser_has_not_provided_the_full_path_of_the_file_and_has_blocked_it_for_security_reasons___1,
                    LogLevel.Debug);
                Log.Log(
                    Resources
                        .EcmController_UploadDocument_Save_the_file_to_the_temporary_directory_if_the_browser_has_blocked_the_full_path_of_the_file_for_security_reasons___1,
                    LogLevel.Debug);
                //Save the file to the temporary directory if the browser has blocked the full path of the file for security reasons...
                fullPath = Path.Combine(Path.GetTempPath(), fileName);
                File.WriteAllBytes(fullPath, file.Data);
            }

            Log.Log(Resources.EcmController_UploadDocument_Check_if_the_full_path_exists___1, LogLevel.Debug);
            //Check if the full path exists...
            if (string.IsNullOrEmpty(fullPath))
            {
                Log.Log(Resources.EcmController_UploadDocument_Full_path_was_not_found_1, LogLevel.Error);
                //Return exception if full path not found...
                response = Resources.EcmController_UploadDocument_Full_path_was_not_found_1;
            }

            Log.Log(Resources.EcmController_UploadDocument_Check_if_the_file_name_exists___1, LogLevel.Debug);
            //Check if the file name exists...
            if (string.IsNullOrEmpty(fileName))
            {
                Log.Log(Resources.EcmController_UploadDocument_File_name_was_not_found_1, LogLevel.Error);
                //Return exception if full path not found...
                response = Resources.EcmController_UploadDocument_File_name_was_not_found_1;
            }

            Log.Log(Resources.EcmController_UploadDocument_Is_the_User_Authenticated_1, LogLevel.Debug);
            //Is the User Authenticated?
            if (!Utility.IsAuthenticated)
            {
                Log.Log(Resources.EcmController_UploadDocument_User_has_not_been_authenticated_1, LogLevel.Error);
                //Return exception if user has not been authenticated...
                response = Resources.EcmController_UploadDocument_User_has_not_been_authenticated_1;
            }

            Log.Log(Resources.EcmController_UploadDocument_Check_for_Current_User___1, LogLevel.Debug);
            //Check for Current User...
            if (Utility.CurrentUser?.SystemUserId == null)
            {
                Log.Log(Resources.EcmController_UploadDocument_Current_user_cannot_be_found_1, LogLevel.Error);
                //Return exception if current user can't be found...
                response = Resources.EcmController_UploadDocument_Current_user_cannot_be_found_1;
            }

            Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1,
                LogLevel.Debug);
            //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
            //Connect to Dynamics 365...
            using (CrmServiceClient crmServiceClient =
                new CrmServiceClient(ConfigurationManager.ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365]
                    .ConnectionString))
            {
                Log.Log(Resources.EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1,
                    LogLevel.Debug);
                Log.Log(Resources.EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1,
                    LogLevel.Debug);
                //Check for successful authentication with Dynamics 365...
                if (!crmServiceClient.IsReady)
                {
                    Log.Log(Resources.EcmController_IsAuthenticated_An_error_occurred_when_connecting_to_Dynamics_365_1,
                        LogLevel.Warning);
                    Log.Log(crmServiceClient.LastCrmError, LogLevel.Error);
                    //Dynamics 365 is not ready...
                    response = crmServiceClient.LastCrmError;
                }

                if (string.IsNullOrEmpty(response) && Utility.CurrentUser?.SystemUserId != null)
                {
                    document = UploadDocument(uploadContent.Entity, crmServiceClient, fileName, start,
                        fullPath, Utility.CurrentUser.SystemUserId.Value);
                }
            }

            return document;
        }

        /// <summary>
        /// Uploads the document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="crmServiceClient">The CRM service client.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="start">The start.</param>
        /// <param name="fullPath">The full path.</param>
        /// <param name="callerId">The caller identifier.</param>
        private Document UploadDocument(Entity entity, CrmServiceClient crmServiceClient, string fileName, DateTime start,
            string fullPath, Guid callerId)
        {
            Log.Log(Resources.EcmController_UploadDocument_Setting_the_calling_user_to_the_current_user______1, LogLevel.Debug);
            //Set Calling User to Current User...
            crmServiceClient.CallerId = callerId;
            Log.Log(Resources.EcmController_IsAuthenticated_Instantiating_Dynamics_365_context___1, LogLevel.Debug);
            //Instantiate Dynamics 365 Service Context...
            using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
            {
                Log.Log(Resources.EcmController_UploadDocument_Get_Record_Type_from_Dynamics_365___1, LogLevel.Debug);
                //Get Record Type from Dynamics 365...
                RecordType crmRecordType = Utility.GetRecordType(entity, xrmServiceContext);
                Log.Log(Resources.EcmController_UploadDocument_Get_Record_Class_from_Dynamics_365___1, LogLevel.Debug);
                //Get Record Class from Dynamics 365...
                RecordClass crmRecordClass = Utility.GetRecordClass(xrmServiceContext, crmRecordType);
                Log.Log(Resources.EcmController_UploadDocument_Set_Record_Class_Code___1, LogLevel.Debug);
                //Set Record Class Code...
                string recordClassCode = crmRecordClass?.RecordClassCode;
                Log.Log(Resources.EcmController_UploadDocument_Create_the_Document_in_Dynamics_365___1, LogLevel.Debug);
                //Create the Document in Dynamics 365...
                Document document = Utility.CreateDocumentInDynamics365(entity, fileName, crmRecordType, crmServiceClient, start);
                Log.Log(Resources.EcmController_UploadDocument_Send_the_Document_to_ECM___1, LogLevel.Debug);
                //Send the Document to ECM...
                createDocumentResponse response = Utility.SendDocumentToEcm(entity, fileName, fullPath, recordClassCode);
                Log.Log(
                    Resources
                        .EcmController_UploadDocument_Validate_the_Response_from_ECM_and_delete_the_Document_in_Dynamics_365_if_no_Object_Identifier_is_returned_in_the_Response___1,
                    LogLevel.Debug);
                //Validate the Response from ECM and delete the Document in Dynamics 365 if no Object Identifier is returned in the Response...
                Utility.ValidateResponse(response, document, crmServiceClient);
                return document;
            }
        }

        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="exception">The exception.</param>
        /// <param name="start">The start.</param>
        /// <returns></returns>
        private IHttpActionResult HandleException(Document document, Exception exception, DateTime start)
        {
            Log.Log(Resources.EcmController_UploadDocument_Was_the_Document_saved_in_Dynamics_365_1, LogLevel.Debug);
            //Was the Document saved in Dynamics 365?
            if (!document.DocumentId.HasValue)
            {
                Log.Log(exception.Message, LogLevel.Error);
                return Ok(new Result { Success = false, Response = exception.Message });
            }

            Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1,
                LogLevel.Debug);
            //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
            //Connect to Dynamics 365...
            return CreateAccessLogForDocument(exception, document, start);
        }

        /// <summary>
        /// Creates the access log for the document.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="document">The document.</param>
        /// <param name="start">The start.</param>
        /// <returns></returns>
        private IHttpActionResult CreateAccessLogForDocument(Exception exception, Document document, DateTime start)
        {
            using (CrmServiceClient crmServiceClient =
                new CrmServiceClient(ConfigurationManager
                    .ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365]
                    .ConnectionString))
            {
                Log.Log(
                    Resources
                        .EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1,
                    LogLevel.Debug);
                //Check for successful authentication with Dynamics 365...
                if (!crmServiceClient.IsReady)
                {
                    Log.Log(Resources.EcmController_IsAuthenticated_An_error_occurred_when_connecting_to_Dynamics_365_1,
                        LogLevel.Error);
                    Log.Log(crmServiceClient.LastCrmError, LogLevel.Error);
                    Log.Log(exception.Message, LogLevel.Error);
                    return Ok(new Result { Success = false, Response = exception.Message });
                }

                Log.Log(Resources.EcmController_UploadDocument_Set_the_document_status_to_inactive___1, LogLevel.Debug);
                //Set the document status to inactive...
                document.DocumentStatusCode = DocumentStatus.Inactive;
                document.DocumentStatusReasonCode = DocumentStatusReason.Inactive;
                Log.Log(Resources.EcmController_UploadDocument_Update_the_document___1, LogLevel.Debug);
                //Update the document...
                crmServiceClient.Update(document);
                //Instantiate Dynamics 365 Service Context...
                using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                {
                    Log.Log(
                        Resources.EcmController_CreateDocumentInDynamics365_Instantiate_new_access_log_recording___1,
                        LogLevel.Debug);
                    //Instantiate new access log recording...
                    Utility.CreateAccessLog
                    (
                        xrmServiceContext,
                        document.Id,
                        string.Format(CultureInfo.CurrentCulture,
                            Resources.EcmController_CreateDocumentInDynamics365__0__was_created_at__1__UTC_by__2_1,
                            document.DocumentName,
                            document.CreatedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                            document.CreatedBy != null
                                ? ((SystemUser)crmServiceClient.Retrieve(SystemUser.EntityLogicalName,
                                    document.CreatedBy.Id,
                                    new ColumnSet(true)))?.FullName
                                : Utility.CurrentUser.FullName),
                        string.Format(CultureInfo.CurrentCulture,
                            Resources.EcmController_CreateDocumentInDynamics365__0__was_created_at__1__UTC_by__2_1,
                            document.DocumentName,
                            document.CreatedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                            document.CreatedBy != null
                                ? ((SystemUser)crmServiceClient.Retrieve(SystemUser.EntityLogicalName,
                                    document.CreatedBy.Id,
                                    new ColumnSet(true)))?.FullName
                                : Utility.CurrentUser.FullName),
                        new OptionSetValue((int)Model.Action.Create),
                        start,
                        DateTime.UtcNow,
                        AccessLogStatusReason.Failure
                    );
                }
                Log.Log(
                    Resources
                        .EcmController_ValidateResponse_An_error_occurred_while_uploading_the_document_to_the_CMIS_ECM_system_1,
                    LogLevel.Error);
                Log.Log(exception.Message, LogLevel.Error);
                return Ok(new Result { Success = false, Response = exception.Message });
            }
        }

        #endregion
    }
}
