﻿using System;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Principal;

namespace Rbs.D365.EcmIntegrate.WebApi
{
    /// <summary>
    /// Safe Native Methods
    /// </summary>
    [SuppressUnmanagedCodeSecurity]
    internal static class UnsafeNativeMethods
    {
        /// <summary>
        /// The user.
        /// </summary>
        /// <param name="lpszUserName">Name of the LPSZ user.</param>
        /// <param name="lpszDomain">The LPSZ domain.</param>
        /// <param name="lpszPassword">The LPSZ password.</param>
        /// <param name="dwType">Type of the dw.</param>
        /// <param name="dwProvider">The dw provider.</param>
        /// <param name="phToken">The ph token.</param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1045:DoNotPassTypesByReference", MessageId = "5#")]
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
        internal static extern int LogonUser(string lpszUserName,
            string lpszDomain,
            string lpszPassword,
            int dwType,
            int dwProvider,
            ref IntPtr phToken);

        /// <summary>
        /// Duplicates the token.
        /// </summary>
        /// <param name="hToken">The h token.</param>
        /// <param name="impersonationLevel">The impersonation level.</param>
        /// <param name="hNewToken">The h new token.</param>
        /// <returns></returns>
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern int DuplicateToken(IntPtr hToken,
            int impersonationLevel,
            ref IntPtr hNewToken);

        /// <summary>
        /// Reverts to self.
        /// </summary>
        /// <returns></returns>
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool RevertToSelf();

        /// <summary>
        /// Closes the handle.
        /// </summary>
        /// <param name="handle">The handle.</param>
        /// <returns></returns>
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CloseHandle(IntPtr handle);
    }


    /// <summary>
    /// Impersonate
    /// </summary>
    public class Impersonate : IDisposable
    {
        #region Public constant Fields

        /// <summary>
        /// The interactive
        /// </summary>
        public const int Interactive = 2;

        /// <summary>
        /// The provider default
        /// </summary>
        public const int ProviderDefault = 0;

        #endregion

        #region Private Fields

        /// <summary>
        /// The impersonation context
        /// </summary>
        private WindowsImpersonationContext _impersonationContext;

        #endregion

        #region Public Methods

        /// <summary>
        /// The user.
        /// </summary>
        /// <param name="lpszUserName">Name of the LPSZ user.</param>
        /// <param name="lpszDomain">The LPSZ domain.</param>
        /// <param name="lpszPassword">The LPSZ password.</param>
        /// <param name="dwType">Type of the dw.</param>
        /// <param name="dwProvider">The dw provider.</param>
        /// <param name="phToken">The ph token.</param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1045:DoNotPassTypesByReference", MessageId = "5#")]
        public static int User(string lpszUserName,
            string lpszDomain,
            string lpszPassword,
            int dwType,
            int dwProvider,
            ref IntPtr phToken)
        {
            return UnsafeNativeMethods.LogonUser(lpszUserName, lpszDomain, lpszPassword, dwType, dwProvider, ref phToken);
        }

        /// <summary>
        /// Duplicates the token.
        /// </summary>
        /// <param name="hToken">The h token.</param>
        /// <param name="impersonationLevel">The impersonation level.</param>
        /// <param name="hNewToken">The h new token.</param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "h")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1045:DoNotPassTypesByReference", MessageId = "2#")]
        public static int DuplicateToken(IntPtr hToken,
            int impersonationLevel,
            ref IntPtr hNewToken)
        {
            return UnsafeNativeMethods.DuplicateToken(hToken, impersonationLevel, ref hNewToken);
        }

        /// <summary>
        /// Reverts to self.
        /// </summary>
        /// <returns></returns>
        public static bool RevertToSelf()
        {
            return UnsafeNativeMethods.RevertToSelf();
        }

        /// <summary>
        /// Closes the handle.
        /// </summary>
        /// <param name="handle">The handle.</param>
        /// <returns></returns>
        public static bool CloseHandle(IntPtr handle)
        {
            return UnsafeNativeMethods.CloseHandle(handle);
        }

        /// <summary>
        /// Impersonates the valid user.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="domain">The domain.</param>
        /// <param name="password">The password.</param>
        /// <returns></returns>
        public bool ImpersonateValidUser(string userName, string domain, string password)
        {
            IntPtr token = IntPtr.Zero;
            IntPtr tokenDuplicate = IntPtr.Zero;

            if (RevertToSelf())
            {
                if (User(userName, domain, password, Interactive,
                        ProviderDefault, ref token) != 0)
                {
                    if (DuplicateToken(token, 2, ref tokenDuplicate) != 0)
                    {
                        using (WindowsIdentity tempWindowsIdentity = new WindowsIdentity(tokenDuplicate))
                        {
                            _impersonationContext = tempWindowsIdentity.Impersonate();
                            if (_impersonationContext != null)
                            {
                                CloseHandle(token);
                                CloseHandle(tokenDuplicate);
                                return true;
                            }
                        }
                    }
                }
            }
            if (token != IntPtr.Zero)
            {
                CloseHandle(token);
            }
            if (tokenDuplicate != IntPtr.Zero)
            {
                CloseHandle(tokenDuplicate);
            }
            return false;
        }

        #endregion

        #region Dispose

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposing)
            {
                return;
            }
            _impersonationContext?.Undo();
            _impersonationContext?.Dispose();
        }

        /// <summary>
        /// Finalizes an instance of the <see cref="Impersonate"/> class.
        /// </summary>
        ~Impersonate()
        {
            Dispose(false);
        }

        #endregion
    }
}