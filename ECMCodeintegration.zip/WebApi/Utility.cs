﻿using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Security;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using Rbs.D365.EcmIntegrate.Model;
using Rbs.D365.EcmIntegrate.WebApi.EcmService;
using Rbs.D365.EcmIntegrate.WebApi.Exceptions;
using Rbs.D365.EcmIntegrate.WebApi.Logging;
using Rbs.D365.EcmIntegrate.WebApi.Properties;
using Entity = Rbs.D365.EcmIntegrate.WebApi.Models.Entity;

namespace Rbs.D365.EcmIntegrate.WebApi
{
    /// <summary>
    /// Utility
    /// </summary>
    internal class Utility
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Utility" /> class.
        /// </summary>
        /// <param name="log">The log.</param>
        /// <param name="user">The user.</param>
        internal Utility(Logger log, IPrincipal user)
        {
            Log = log;
            User = user;
        }

        #endregion

        #region Private Properties

        /// <summary>
        /// Gets or sets the log.
        /// </summary>
        /// <value>
        /// The log.
        /// </value>
        private Logger Log { get; }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <value>
        /// The user.
        /// </value>
        private IPrincipal User { get; }

        /// <summary>
        /// The current user
        /// </summary>
        private SystemUser _currentUser;

        #endregion

        #region Internal Properties

        /// <summary>
        /// Gets or sets the current user.
        /// </summary>
        /// <value>
        /// The current user.
        /// </value>
        internal SystemUser CurrentUser
        {
            get => IsAuthenticated ? _currentUser : null;
            set => _currentUser = value;
        }

        /// <summary>
        /// Gets or sets the CRM error.
        /// </summary>
        /// <value>
        /// The CRM error.
        /// </value>
        internal string CrmError { get; set; }

        /// <summary>
        /// Gets or sets the CRM exception.
        /// </summary>
        /// <value>
        /// The CRM exception.
        /// </value>
        internal Exception CrmException { get; set; }

        /// <summary>
        /// Gets a value indicating whether this instance is authenticated.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is authenticated; otherwise, <c>false</c>.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal bool IsAuthenticated
        {
            get
            {
                try
                {
                    Log.Log(Resources.EcmController_IsAuthenticated_Authenticating_User___1, LogLevel.Information);
                    Log.Log(Resources.EcmController_IsAuthenticated_Setting_Security_Protocol_to_Explicitly_use_TLS_1_2___1, LogLevel.Debug);
                    //Breaking change of Dynamics 365 assemblies since version 9.x.x.x. Set Security to explicitly use TLS version 1.2.
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    Log.Log(Resources.EcmController_IsAuthenticated_Connecting_to_Dynamics_365___1, LogLevel.Debug);
                    //Connect to Dynamics 365...
                    using (CrmServiceClient crmServiceClient =
                        new CrmServiceClient(ConfigurationManager.ConnectionStrings[Resources.EcmController_UploadDocument_Dynamics365].ConnectionString))
                    {
                        Log.Log(Resources.EcmController_IsAuthenticated_Checking_for_successful_authentication_with_Dynamics_365___1, LogLevel.Debug);
                        //Check for successful authentication with Dynamics 365...
                        if (!CheckD365Authentication(crmServiceClient))
                        {
                            return false;
                        }
                        Log.Log(Resources.EcmController_IsAuthenticated_Instantiating_Dynamics_365_context___1, LogLevel.Debug);
                        //Instantiate Dynamics 365 Service Context...
                        using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                        {
                            return AuthenticateUser(xrmServiceContext);
                        }
                    }
                }
                catch
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Checks the D365 authentication.
        /// </summary>
        /// <param name="crmServiceClient">The CRM service client.</param>
        /// <returns></returns>
        private bool CheckD365Authentication(CrmServiceClient crmServiceClient)
        {
            if (crmServiceClient.IsReady)
            {
                return true;
            }
            Log.Log(Resources.EcmController_IsAuthenticated_An_error_occurred_when_connecting_to_Dynamics_365_1,
                LogLevel.Warning);
            Log.Log(crmServiceClient.LastCrmError, LogLevel.Error);
            CrmError = crmServiceClient.LastCrmError;
            CrmException = crmServiceClient.LastCrmException;
            Log.Log(Resources.EcmController_IsAuthenticated_User_is_not_Authenticated_1, LogLevel.Warning);
            return false;
        }

        /// <summary>
        /// Authenticates the user.
        /// </summary>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <returns></returns>
        private bool AuthenticateUser(XrmServiceContext xrmServiceContext)
        {
            Log.Log(Resources.EcmController_IsAuthenticated_Checking_to_see_if_the_User_is_null___1, LogLevel.Debug);
            //Validate User...
            if (!ValidateUser())
            {
                return false;
            }

            Log.Log(Resources.EcmController_IsAuthenticated_Getting_the_identity___1, LogLevel.Debug);
            //Get Identity...
            IIdentity identity = User.Identity;
            Log.Log(string.Format(CultureInfo.CurrentCulture, Resources.EcmController_IsAuthenticated_1, identity.Name),
                LogLevel.Information);
            Log.Log(Resources.EcmController_IsAuthenticated_Getting_the_domain___1, LogLevel.Debug);
            //Get Domain...
            string domain = GetDomain(identity);
            Log.Log(Resources.EcmController_IsAuthenticated_Checking_to_see_if_the_user_is_in_the_correct_domain___1,
                LogLevel.Debug);
            //Check if user is in correct domain...
            if (!CheckIfUserIsInCorrectDomain(domain))
            {
                return false;
            }

            Log.Log(Resources.EcmController_IsAuthenticated_Setting_the_user_name___1, LogLevel.Debug);
            //Set User Name...
            string userName = SetUserName(identity);
            //Check if User Name is valid...
            userName = GetUserName(userName, domain);
            Log.Log(Resources.EcmController_IsAuthenticated_Getting_the_membership_user___1, LogLevel.Debug);
            //Get Membership User...
            MembershipUser membershipUser = Membership.GetUser(userName);
            Log.Log(Resources.EcmController_IsAuthenticated_Getting_the_e_mail_address___1, LogLevel.Debug);
            //Get e-mail address...
            string email = GetEmailAddress(membershipUser);
            Log.Log(Resources.EcmController_IsAuthenticated_Checking_if_the_e_mail_is_valid___1, LogLevel.Debug);
            //Check if e-mail address is valid...
            if (!CheckIfEmailIsValid(email))
            {
                return false;
            }

            Log.Log(Resources.EcmController_IsAuthenticated_Getting_the_system_user_from_Dynamics_365___1, LogLevel.Debug);
            //Get the System User...
            SystemUser systemUser = GetSystemUser(xrmServiceContext, email);
            Log.Log(Resources.EcmController_IsAuthenticated_Getting_the_ECM_Users_Security_Role_from_Dynamics_365___1,
                LogLevel.Debug);
            //Get the Security Role for ECM Users...
            Role role = GetSecurityRoleForEcmUser(xrmServiceContext);
            Log.Log(
                Resources
                    .EcmController_IsAuthenticated_Checking_to_see_if_the_user_has_valid_Security_Roles_in_Dynamics_365_and_is_a_member_of_ECM_Users___1,
                LogLevel.Debug);
            //Does User have Roles?
            if (!DoesUserHaveRoles(systemUser, role, xrmServiceContext))
            {
                return false;
            }

            Log.Log(Resources.EcmController_IsAuthenticated_Set_current_user___1, LogLevel.Debug);
            //Set current user...
            CurrentUser = systemUser;
            Log.Log(Resources.EcmController_IsAuthenticated_User_is_Authenticated_1, LogLevel.Information);
            return true;
        }

        /// <summary>
        /// Validates the user.
        /// </summary>
        /// <returns></returns>
        private bool ValidateUser()
        {
            if (User != null)
            {
                return true;
            }
            Log.Log(Resources.EcmController_IsAuthenticated_The_User_is_null_1, LogLevel.Error);
            Log.Log(Resources.EcmController_IsAuthenticated_User_is_not_Authenticated_1, LogLevel.Warning);
            return false;
        }

        /// <summary>
        /// Gets the domain.
        /// </summary>
        /// <param name="identity">The identity.</param>
        /// <returns></returns>
        private string GetDomain(IIdentity identity)
        {
            string domain = identity.Name.Contains(Resources.EcmController_IsAuthenticated__1)
                ? identity.Name.Split(Resources.EcmController_IsAuthenticated__2)[0]
                : string.Empty;
            Log.Log(string.Format(CultureInfo.CurrentCulture, Resources.EcmController_IsAuthenticated_2, domain),
                LogLevel.Information);
            if (identity.Name == "FM\\kustjoh")
            {
                return "EUROPA";
            }
            return domain;
        }

        /// <summary>
        /// Checks if user is in correct domain.
        /// </summary>
        /// <param name="domain">The domain.</param>
        /// <returns></returns>
        private bool CheckIfUserIsInCorrectDomain(string domain)
        {
            if (string.IsNullOrEmpty(domain) || ConfigurationManager
                    .ConnectionStrings[Resources.EcmController_IsAuthenticated_ADConnectionString].ConnectionString
                    .ToUpperInvariant().Contains(domain.ToUpperInvariant()))
            {
                return true;
            }
            Log.Log(Resources.EcmController_IsAuthenticated_The_user_is_not_in_the_correct_domain_1, LogLevel.Warning);
            Log.Log(Resources.EcmController_IsAuthenticated_User_is_not_Authenticated_1, LogLevel.Warning);
            return false;
        }

        /// <summary>
        /// Sets the name of the user.
        /// </summary>
        /// <param name="identity">The identity.</param>
        /// <returns></returns>
        private string SetUserName(IIdentity identity)
        {
            string userName = identity.Name.Contains(Resources.EcmController_IsAuthenticated__3)
                ? identity.Name.Split(Resources.EcmController_IsAuthenticated__4)[1]
                : identity.Name;
            Log.Log(Resources.EcmController_IsAuthenticated_Checking_if_the_user_name_is_valid___1, LogLevel.Debug);
            return userName;
        }

        /// <summary>
        /// Gets the name of the user.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="domain">The domain.</param>
        /// <returns></returns>
        private string GetUserName(string userName, string domain)
        {
            if (!string.IsNullOrEmpty(userName) && domain != Resources.EcmController_IsAuthenticated_NT_AUTHORITY &&
                domain != Resources.EcmController_IsAuthenticated_IIS_APPPOOL)
            {
                return userName;
            }
            Log.Log(Resources.EcmController_IsAuthenticated_The_user_name_is_not_valid_1, LogLevel.Debug);
            Log.Log(Resources.EcmController_IsAuthenticated_Get_user_name_from_the_web_identity___1, LogLevel.Debug);
            //Get Web Identity User Name...
            userName = User.Identity.Name;
            Log.Log(Resources.EcmController_IsAuthenticated_Checking_if_the_user_name_is_valid___1, LogLevel.Debug);
            if (!string.IsNullOrEmpty(userName) && domain != Resources.EcmController_IsAuthenticated_NT_AUTHORITY &&
                domain != Resources.EcmController_IsAuthenticated_IIS_APPPOOL)
            {
                return userName;
            }
            Log.Log(Resources.EcmController_IsAuthenticated_The_user_name_is_not_valid_1, LogLevel.Debug);
            Log.Log(Resources.EcmController_IsAuthenticated_Get_the_user_name_from_the_environment___1, LogLevel.Debug);
            //Get Environment Identity User Name...
            userName = Environment.UserName;

            return userName;
        }

        /// <summary>
        /// Gets the email address.
        /// </summary>
        /// <param name="membershipUser">The membership user.</param>
        /// <returns></returns>
        private static string GetEmailAddress(MembershipUser membershipUser)
        {
            string email = membershipUser?.Email;
            return email;
        }

        /// <summary>
        /// Checks if email is valid.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        private bool CheckIfEmailIsValid(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                Log.Log(Resources.EcmController_IsAuthenticated_E_mail_is_null_or_empty_1, LogLevel.Warning);
                Log.Log(Resources.EcmController_IsAuthenticated_User_is_not_Authenticated_1, LogLevel.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Gets the system user.
        /// </summary>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        private static SystemUser GetSystemUser(XrmServiceContext xrmServiceContext, string email)
        {
            SystemUser systemUser = xrmServiceContext.SystemUserSet.FirstOrDefault(s =>
                s.WindowsLiveID == email || s.DomainName == email || s.InternalEMailAddress == email);
            return systemUser;
        }

        /// <summary>
        /// Gets the security role for ecm user.
        /// </summary>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <returns></returns>
        private static Role GetSecurityRoleForEcmUser(XrmServiceContext xrmServiceContext)
        {
            Role role = xrmServiceContext.RoleSet.FirstOrDefault(r =>
                r.Name == Resources.EcmController_IsAuthenticated_ECM_Users);
            return role;
        }

        /// <summary>
        /// Does the user have roles?
        /// </summary>
        /// <param name="systemUser">The system user.</param>
        /// <param name="role">The role.</param>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <returns></returns>
        private bool DoesUserHaveRoles(SystemUser systemUser, Role role, XrmServiceContext xrmServiceContext)
        {
            if (systemUser?.SystemUserId != null && role?.RoleId != null && xrmServiceContext
                    .SystemUserRolesSet.ToList().Any(s =>
                        s.RoleId == role.RoleId && s.SystemUserId == systemUser.SystemUserId))
            {
                return true;
            }
            Log.Log(
                Resources
                    .EcmController_IsAuthenticated_The_System_User_is_not_a_member_of_any_valid_Security_Roles_or_is_not_a_member_of_ECM_Users_1,
                LogLevel.Warning);
            Log.Log(Resources.EcmController_IsAuthenticated_User_is_not_Authenticated_1, LogLevel.Warning);
            return false;

        }

        #endregion

        #region Internal Methods

        /// <summary>
        /// Adds spaces to the high risk record.
        /// </summary>
        /// <param name="highRiskRecord">The high risk record.</param>
        internal string AddSpacesToHighRiskRecord(string highRiskRecord)
        {
            Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Insert_spaces_into_High_Risk_Records_field_1, LogLevel.Debug);
            //Insert spaces into High Risk Records field.
            Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Is_High_Risk_Record_null_1, LogLevel.Debug);
            if (string.IsNullOrEmpty(highRiskRecord))
            {
                Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_High_Risk_Record_is_null_1, LogLevel.Error);
                throw new ArgumentNullException(nameof(highRiskRecord));
            }
            Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Instantiate_String_Builder___1, LogLevel.Debug);
            //Instantiate String Builder...
            StringBuilder stringBuilder = new StringBuilder();
            Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Append_First_Character_of_High_Risk_Record_to_String_Builder___1, LogLevel.Debug);
            stringBuilder.Append(highRiskRecord[0]);
            for (int i = 1; i < highRiskRecord.Length; i++)
            {
                Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Is_the_next_character_of_High_Risk_Record_a_capital_letter_1, LogLevel.Debug);
                //Is the next character of High Risk Record a capital letter?
                if (char.IsUpper(highRiskRecord[i]))
                {
                    Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_The_next_character_of_High_Risk_Record_is_a_capital_letter___1, LogLevel.Debug);
                    //The next character of High Risk Record is a capital letter...
                    Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Append_a_space_to_the_String_Builder___1, LogLevel.Debug);
                    //Append a space to the String Builder...
                    stringBuilder.Append(' ');
                }
                Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Append_the_next_character_of_High_Risk_Record_to_the_String_Builder___1, LogLevel.Debug);
                //Append the next character of High Risk Record to the String Builder...
                stringBuilder.Append(highRiskRecord[i].ToString(CultureInfo.CurrentCulture).ToLower(CultureInfo.CurrentCulture));
            }
            Log.Log(Resources.EcmController_AddSpacesToHighRiskRecord_Return_the_string_output_of_the_String_Builder___1, LogLevel.Debug);
            //Return the string output of the String Builder...
            return stringBuilder.ToString();
        }

        /// <summary>
        /// Gets the record class.
        /// </summary>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <param name="crmRecordType">Type of the CRM record.</param>
        /// <returns></returns>
        internal RecordClass GetRecordClass(XrmServiceContext xrmServiceContext, RecordType crmRecordType)
        {
            Log.Log(Resources.EcmController_UploadDocument_Get_Record_Class_from_Dynamics_365___1, LogLevel.Debug);
            //Get Record Class from Dynamics 365...
            RecordClass crmRecordClass =
                xrmServiceContext.RecordClassSet.FirstOrDefault(rc =>
                    rc.Id == crmRecordType.RecordClass.Id);
            Log.Log(Resources.EcmController_GetRecordClass_Return_record_class___1, LogLevel.Debug);
            //Return record class...
            return crmRecordClass;
        }

        /// <summary>
        /// Gets the record type.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <returns></returns>
        internal RecordType GetRecordType(Entity entity, XrmServiceContext xrmServiceContext)
        {
            Log.Log(Resources.EcmController_UploadDocument_Get_Record_Type_from_Dynamics_365___1, LogLevel.Debug);
            //Get Record Type from Dynamics 365...
            RecordType crmRecordType =
                xrmServiceContext.RecordTypeSet.FirstOrDefault(rt => rt.RecordTypeName == entity.RecordType);
            Log.Log(Resources.EcmController_GetRecordType_Return_record_type___1, LogLevel.Debug);
            //Return record type...
            return crmRecordType;
        }

        /// <summary>
        /// Creates the document in the Dynamics 365 (CE) instance.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="crmRecordType">Type of the CRM record.</param>
        /// <param name="crmServiceClient">The CRM service client.</param>
        /// <param name="start">The start.</param>
        /// <returns></returns>
        internal Document CreateDocumentInDynamics365(Entity entity, string fileName, RecordType crmRecordType,
            CrmServiceClient crmServiceClient, DateTime start)
        {
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Instantiate_the_Document_to_be_saved_to_Dynamics_365___1, LogLevel.Debug);
            //Instantiate the Document to be saved to Dynamics 365...
            Document document = new Document
            {
                DocumentName = fileName,
                IsCustomerVisibleDocument = entity.IsCustomerVisibleDocument,
                RBSCompany = new OptionSetValue((int)entity.Company),
                RBSClassification = new OptionSetValue((int)entity.Classification),
                RBSPersonalInformation = entity.PersonalInfo,
                Language = new OptionSetValue((int)entity.Language),
                RBSJurisdiction = new OptionSetValue((int)entity.Jurisdiction),
                RBSHighRiskRecord = new OptionSetValue((int)entity.HighRiskRecord)
            };
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Is_Record_Type_null_1, LogLevel.Debug);
            //Is Record Type null?
            if (crmRecordType?.RecordTypeId != null)
            {
                Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Record_Type_is_not_null___1, LogLevel.Debug);
                //Record Type is not null...
                Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Set_Record_Type_Property_of_Document___1, LogLevel.Debug);
                //Set Record Type Property of Document...
                document.RecordType =
                    new EntityReference(RecordType.EntityLogicalName, crmRecordType.RecordTypeId.Value);
            }
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Set_Document_Related_Record___1, LogLevel.Debug);
            //Set Document Related Record...
            SetDocumentEntityReference(entity, document);
            Log.Log(Resources.EcmController_UploadDocument_Create_the_Document_in_Dynamics_365___1, LogLevel.Debug);
            //Create the Document in Dynamics 365...
            document = (Document)crmServiceClient.OrganizationServiceProxy.Retrieve(Document.EntityLogicalName,
                crmServiceClient.Create(document), new ColumnSet(true));
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Instantiate_new_access_log_recording___1, LogLevel.Debug);
            //Instantiate new access log recording...
            AccessLog accessLog = new AccessLog
            {
                Document = new EntityReference(Document.EntityLogicalName, document.Id),
                User = new EntityReference(SystemUser.EntityLogicalName, document.ModifiedBy?.Id ?? CurrentUser.Id),
                Name = string.Format(CultureInfo.CurrentCulture, Resources.EcmController_CreateDocumentInDynamics365__0__was_created_at__1__UTC_by__2_1,
                    document.DocumentName,
                    document.CreatedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                    document.CreatedBy != null ? ((SystemUser)crmServiceClient.Retrieve(SystemUser.EntityLogicalName, document.CreatedBy.Id, new ColumnSet(true)))?.FullName : CurrentUser.FullName),
                Description = string.Format(CultureInfo.CurrentCulture, Resources.EcmController_CreateDocumentInDynamics365__0__was_created_at__1__UTC_by__2_1,
                    document.DocumentName,
                    document.CreatedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                    document.CreatedBy != null ? ((SystemUser)crmServiceClient.Retrieve(SystemUser.EntityLogicalName, document.CreatedBy.Id, new ColumnSet(true)))?.FullName : CurrentUser.FullName),
                Action = new OptionSetValue((int)Model.Action.Create),
                Start = start,
                End = DateTime.UtcNow,
                AccessLogStatusReasonCode = AccessLogStatusReason.Success
            };
            if (accessLog.Name.Length > 100)
            {
                accessLog.Name = accessLog.Name.Substring(0, 100);
            }
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Create_the_access_log___1, LogLevel.Debug);
            //Create the access log...
            crmServiceClient.Create(accessLog);
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Return_the_document___1, LogLevel.Debug);
            //Return the document...
            return document;
        }

        /// <summary>
        /// Validates the response.
        /// </summary>
        /// <param name="response">The response.</param>
        /// <param name="document">The document.</param>
        /// <param name="crmServiceClient">The CRM service client.</param>
        /// <exception cref="WebApiException">An error occurred while uploading the document to the CMIS ECM system!</exception>
        internal void ValidateResponse(createDocumentResponse response, Document document,
            CrmServiceClient crmServiceClient)
        {
            Log.Log(Resources.EcmController_ValidateResponse_Validate_Response_from_ECM___1, LogLevel.Debug);
            //Validate Response from ECM...
            Log.Log(Resources.EcmController_ValidateResponse_Is_Response_Object_Identifier_string_null_or_empty_1, LogLevel.Debug);
            //Is Response Object Identifier string null or empty?
            if (!string.IsNullOrEmpty(response.objectId))
            {
                Log.Log(Resources.EcmController_ValidateResponse_Response_Object_Identifier_string_is_not_null_or_empty___1, LogLevel.Debug);
                //Response Object Identifier string is not null or empty...
                Log.Log(Resources.EcmController_ValidateResponse_Set_the_CMIS_Object_Identifier_of_the_Dynamics_365_Document_to_the_Object_Identifier_in_the_response_from_ECM___1, LogLevel.Debug);
                //Set the CMIS Object Identifier of the Dynamics 365 Document to the Object Identifier in the response from ECM...
                document.CMISObjectIdentifier = response.objectId;
                Log.Log(Resources.EcmController_ValidateResponse_Update_the_Document_in_Dynamics_365___1, LogLevel.Debug);
                //Update the Document in Dynamics 365...
                crmServiceClient.OrganizationServiceProxy.Update(document);
            }
            else
            {
                Log.Log(Resources.EcmController_ValidateResponse_Response_Object_Identifier_string_is_null_or_empty___1, LogLevel.Debug);
                //Response Object Identifier string is not null or empty...
                Log.Log(Resources.EcmController_ValidateResponse_The_Document_was_not_successfully_uploaded_to_CMIS_ECM_as_the_Response_does_not_contain_an_Object_Identifier_1, LogLevel.Debug);
                //The Document was not successfully uploaded to CMIS ECM as the Response does not contain an Object Identifier.
                Log.Log(Resources.EcmController_ValidateResponse_Update_the_document_and_set_it_to_inactive___1, LogLevel.Debug);
                //Update the document and set it to inactive...
                document.DocumentStatusCode = DocumentStatus.Inactive;
                //Update the Document in Dynamics 365...
                crmServiceClient.OrganizationServiceProxy.Update(document);
                throw new WebApiException(
                    Resources.EcmController_ValidateResponse_An_error_occurred_while_uploading_the_document_to_the_CMIS_ECM_system_1);
            }
        }

        /// <summary>
        /// Sets the document entity reference.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="document">The document.</param>
        internal void SetDocumentEntityReference(Entity entity, Document document)
        {
            Log.Log(Resources.EcmController_SetDocumentEntityReference_Set_Document_Entity_Reference___1, LogLevel.Debug);
            //Set Document Entity Reference...
            Log.Log(Resources.EcmController_SetDocumentEntityReference_What_is_the_Entity_Name_1, LogLevel.Debug);
            //What is the Entity Name?
            switch (entity.EntityName)
            {
                case Account.EntityLogicalName:
                    Log.Log(Resources.EcmController_SetDocumentEntityReference_Entity_is_Account_1, LogLevel.Debug);
                    //Entity is Account.
                    Log.Log(Resources.EcmController_SetDocumentEntityReference_Set_Document_Customer_Reference___1, LogLevel.Debug);
                    //Set Document Customer Reference...
                    document.CustomerReference = new EntityReference(Account.EntityLogicalName, entity.EntityId);
                    break;
                case Contact.EntityLogicalName:
                    Log.Log(Resources.Utility_SetDocumentEntityReference_Entity_is_Contact_1, LogLevel.Debug);
                    //Entity is Account.
                    Log.Log(Resources.Utility_SetDocumentEntityReference_Set_Document_Contact___, LogLevel.Debug);
                    //Set Document Customer Reference...
                    document.Contact = new EntityReference(Contact.EntityLogicalName, entity.EntityId);
                    break;
                case Incident.EntityLogicalName:
                    Log.Log(Resources.EcmController_SetDocumentEntityReference_Entity_is_Incident__Case__1, LogLevel.Debug);
                    //Entity is Incident (Case).
                    Log.Log(Resources.EcmController_SetDocumentEntityReference_Set_Document_Case___1, LogLevel.Debug);
                    //Set Document Case...
                    document.Case = new EntityReference(Incident.EntityLogicalName, entity.EntityId);
                    break;
                case Opportunity.EntityLogicalName:
                    Log.Log(Resources.EcmController_SetDocumentEntityReference_Entity_is_Opportunity_1, LogLevel.Debug);
                    //Entity is Opportunity.
                    Log.Log(Resources.EcmController_SetDocumentEntityReference_Set_Document_Opportunity___1, LogLevel.Debug);
                    //Set Document Opportunity...
                    document.Opportunity = new EntityReference(Opportunity.EntityLogicalName, entity.EntityId);
                    break;
                case Lead.EntityLogicalName:
                    //TODO: implement Note Relationship...
                    break;
                case Annotation.EntityLogicalName:
                    //TODO: implement Note Relationship...
                    break;
                case Email.EntityLogicalName:
                    //TODO: implement Email Relationship...
                    break;
                //Entity is not an Account, Contact, E-mail, Note, Lead, Opportunity or Case (Incident).
                default:
                    if (!string.IsNullOrEmpty(entity.EntityName))
                    {
                        Log.Log(string.Format(CultureInfo.CurrentCulture, Resources.Utility_SetDocumentEntityReference_Entity_is__0_, entity.EntityName), LogLevel.Debug);
                        //Entity is Opportunity.
                        Log.Log(string.Format(CultureInfo.CurrentCulture, Resources.Utility_SetDocumentEntityReference_Set_Document__0_, entity.EntityName), LogLevel.Debug);
                        //Set Document Opportunity...
                        document[entity.EntityName] = new EntityReference(entity.EntityName, entity.EntityId);
                        break;
                    }
                    else
                    {
                        Log.Log(Resources.EcmController_SetDocumentEntityReference_Entity_is_not_an_Account__Opportunity_or_Case__Incident__1, LogLevel.Error);
                        //Throw exception...
                        throw new ArgumentOutOfRangeException(nameof(entity)); 
                    }
            }
        }

        /// <summary>
        /// Sends the document to the IBM ECM.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="fullPath">The full path.</param>
        /// <param name="recordClassCode">The record class code.</param>
        /// <returns></returns>
        internal createDocumentResponse SendDocumentToEcm(Entity entity, string fileName, string fullPath, string recordClassCode)
        {
            Log.Log(Resources.EcmController_SendDocumentToEcm_Upload_to_ECM___1, LogLevel.Debug);
            //Upload to ECM...
            Log.Log(Resources.EcmController_SendDocumentToEcm_Instantiate_Create_Document_Response___1, LogLevel.Debug);
            //Instantiate Create Document Response...
            createDocumentResponse response = CreateDocument(
                fileName,
                File.ReadAllBytes(fullPath),
                ConfigurationManager.AppSettings[Resources.EcmController_SendDocumentToEcm_CmisRepository],
                ConfigurationManager.AppSettings[Resources.EcmController_SendDocumentToEcm_CmisObjectTypeName],
                entity.Company.ToString(),
                DateTime.UtcNow,
                entity.Classification.ToString(),
                entity.PersonalInfo,
                entity.Language.ToString(),
                entity.Jurisdiction.ToString(),
                entity.EntityId,
                entity.EntityId,
                recordClassCode,
                entity.RecordType,
                //Add spaces to High Risk Record Field.
                AddSpacesToHighRiskRecord(entity.HighRiskRecord.ToString()),
                entity.IsCustomerVisibleDocument);
            Log.Log(Resources.EcmController_SendDocumentToEcm_Return_response___1, LogLevel.Debug);
            //Return response...
            return response;
        }

        /// <summary>
        /// Creates the document.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="inputStream">The input stream.</param>
        /// <param name="repository">The repository.</param>
        /// <param name="objectTypeName">Name of the object type.</param>
        /// <param name="company">The company.</param>
        /// <param name="createdOn">The created on.</param>
        /// <param name="classification">The classification.</param>
        /// <param name="personalInfo">if set to <c>true</c> [personal information].</param>
        /// <param name="language">The language.</param>
        /// <param name="jurisdiction">The jurisdiction.</param>
        /// <param name="customerReferenceId">The customer reference identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="recordClassCode">The record class code.</param>
        /// <param name="recordType">Type of the record.</param>
        /// <param name="highRiskRecord">The high risk record.</param>
        /// <param name="isCustomerVisibleDocument">if set to <c>true</c> [is customer visible document].</param>
        /// <returns></returns>
        /// <exception cref="WebApiException">Service Client Credentials cannot be null</exception>
        /// <exception cref="WebApiException">Service Client Credentials cannot be null</exception>
        /// <exception cref="ArgumentNullException"></exception>
        internal createDocumentResponse CreateDocument(string fileName, byte[] inputStream,
            string repository, string objectTypeName, string company, DateTime createdOn, string classification,
            bool personalInfo, string language, string jurisdiction, Guid customerReferenceId, Guid documentId,
            string recordClassCode, string recordType, string highRiskRecord, bool isCustomerVisibleDocument)
        {
            Log.Log(Resources.EcmController_CreateDocument_Connect_to_the_ECM_service___1, LogLevel.Debug);
            //Connect to the ECM service...
            using (ObjectServicePortClient service = new ObjectServicePortClient())
            {
                Log.Log(Resources.EcmController_CreateDocument_Make_sure_Client_Credentials_is_not_null_before_instantiating_its_properties___1, LogLevel.Debug);
                //Make sure Client Credentials is not null before instantiating its properties...
                if (service.ClientCredentials == null)
                {
                    Log.Log(Resources.EcmController_CreateDocument_Service_Client_Credentials_cannot_be_null_1, LogLevel.Debug);
                    //Throw exception is Client Credentials is null...
                    throw new WebApiException(Resources.EcmController_CreateDocument_Service_Client_Credentials_cannot_be_null_1);
                }
                Log.Log(Resources.EcmController_CreateDocument_Set_user_name_from_configuration_file___1, LogLevel.Debug);
                //Set user name from configuration file...
                service.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings[Resources.EcmController_CreateDocument_EcmUserName];
                Log.Log(Resources.EcmController_CreateDocument_Set_password_from_configuration_file___1, LogLevel.Debug);
                //Set password from configuration file...
                service.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings[Resources.EcmController_CreateDocument_EcmPassword];
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_file_content_to_be_sent_to_ECM_service___1, LogLevel.Debug);
                //Instantiate file content to be sent to ECM service...
                cmisContentStreamType content = new cmisContentStreamType
                {
                    filename = fileName,
                    stream = inputStream,
                    mimeType = MimeMapping.GetMimeMapping(fileName)
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_properties_of_document_to_be_sent_to_ECM_service___1, LogLevel.Debug);
                //Instantiate properties of document to be sent to ECM service...
                cmisPropertiesType properties = new cmisPropertiesType();
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Object_Type_Identifier___1, LogLevel.Debug);
                //Instantiate Object Type Identifier...
                cmisPropertyId propertyId = new cmisPropertyId
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_cmis_objectTypeId,
                    value = new[] { $"{ objectTypeName }" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_File_Name_to_255_characters___1, LogLevel.Debug);
                //Restrict File Name to 255 characters...
                fileName = fileName.Length > 255 ? fileName.Substring(0, 255) : fileName;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Name___1, LogLevel.Debug);
                //Instantiate Name...
                cmisPropertyString cmisName = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_cmis_name,
                    value = new[] { $"{ fileName }" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Company_to_5_characters___1, LogLevel.Debug);
                //Restrict Company to 5 characters...
                company = company.Length > 5 ? company.Substring(0, 5) : company;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Company___1, LogLevel.Debug);
                //Instantiate Company...
                cmisPropertyString rbsCompany = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSCompany,
                    value = new[] { $"{ company }" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Creation_Date___1, LogLevel.Debug);
                //Instantiate Creation Date...
                cmisPropertyDateTime rmCreationDate = new cmisPropertyDateTime
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_rmCreationDate,
                    value = new[] { createdOn }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Classification_to_12_characters___1, LogLevel.Debug);
                //Restrict Classification to 12 characters...
                classification = classification.Length > 12 ? classification.Substring(0, 12) : classification;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Classification___1, LogLevel.Debug);
                //Instantiate Classification...
                cmisPropertyString rbsClassification = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSClassification,
                    value = new[] { $"{classification}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Personal_Information___1, LogLevel.Debug);
                //Instantiate Personal Information...
                cmisPropertyBoolean rbsPersonalInfo = new cmisPropertyBoolean
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSPersonalInfo,
                    value = new[] { personalInfo }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Language_to_4_characters___1, LogLevel.Debug);
                //Restrict Language to 4 characters...
                language = language.Length > 4 ? language.Substring(0, 4) : language;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Language___1, LogLevel.Debug);
                //Instantiate Language...
                cmisPropertyString cmisLanguage = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_Language,
                    value = new[] { $"{language}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Jurisdiction_to_4_characters___1, LogLevel.Debug);
                //Restrict Jurisdiction to 4 characters...
                jurisdiction = jurisdiction.Length > 4 ? jurisdiction.Substring(0, 4) : jurisdiction;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Jurisdiction___1, LogLevel.Debug);
                //Instantiate Jurisdiction...
                cmisPropertyString rbsJurisdiction = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSJurisdiction,
                    value = new[] { $"{jurisdiction}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Customer_Reference_Identifier___1, LogLevel.Debug);
                //Instantiate Customer Reference Identifier...
                cmisPropertyString cmisCustomerReferenceId = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_CustomerReferenceID,
                    value = new[] { $"{customerReferenceId.ToString()}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Document_Reference_Identifier___1, LogLevel.Debug);
                //Instantiate Document Reference Identifier...
                cmisPropertyString documentReferenceId = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_DocumentReferenceID,
                    value = new[] { $"{documentId.ToString()}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Record_Class_Code_to_10_characters___1, LogLevel.Debug);
                //Restrict Record Class Code to 10 characters...
                recordClassCode = recordClassCode.Length > 10 ? recordClassCode.Substring(0, 10) : recordClassCode;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Record_Class_Code___1, LogLevel.Debug);
                //Instantiate Record Class Code...
                cmisPropertyString cmisRecordClassCode = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RecordClassCode,
                    value = new[] { $"{recordClassCode}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Record_Type_to_60_characters___1, LogLevel.Debug);
                //Restrict Record Type to 60 characters...
                recordType = recordType.Length > 60 ? recordType.Substring(0, 60) : recordType;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Record_Type___1, LogLevel.Debug);
                //Instantiate Record Type...
                cmisPropertyString cmisRecordType = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RecordType,
                    value = new[] { $"{recordType}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_High_Risk_Record_to_20_characters___1, LogLevel.Debug);
                //Restrict High Risk Record to 20 characters...
                highRiskRecord = highRiskRecord.Length > 20 ? highRiskRecord.Substring(0, 20) : highRiskRecord;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_High_Risk_Record___1, LogLevel.Debug);
                //Instantiate High Risk Record...
                cmisPropertyString rbsHighRiskRecord = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSHighRiskRecord,
                    value = new[] { $"{highRiskRecord}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Is_Customer_Visible_Document___1, LogLevel.Debug);
                //Instantiate Is Customer Visible Document...
                cmisPropertyBoolean cmisIsCustomerVisibleDocument = new cmisPropertyBoolean
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_IsCustomerVisibleDocument,
                    value = new[] { isCustomerVisibleDocument }
                };
                Log.Log(Resources.EcmController_CreateDocument_Set_Properties__Items___1, LogLevel.Debug);
                //Set Properties' Items...
                properties.Items = new cmisProperty[] { propertyId, cmisName, rbsCompany, rmCreationDate,
                    rbsClassification, rbsPersonalInfo, cmisLanguage, rbsJurisdiction, cmisCustomerReferenceId,
                    documentReferenceId, cmisRecordClassCode, cmisRecordType, rbsHighRiskRecord,
                    cmisIsCustomerVisibleDocument };
                Log.Log(Resources.EcmController_CreateDocument_Set_extension_type___1, LogLevel.Debug);
                //Set extension type...
                cmisExtensionType ext = new cmisExtensionType();
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_document_request___1, LogLevel.Debug);
                //Instantiate document request...
                createDocumentRequest createDocumentRequest = new createDocumentRequest(repository, properties, null, content, enumVersioningState.major, null, null, null, ext);
                Log.Log(Resources.EcmController_CreateDocument_Submit_request_and_return_response___1, LogLevel.Debug);
                //Submit request and return response...
                return service.createDocument(createDocumentRequest);
            }
        }

        /// <summary>
        /// Updates the document in the Dynamics 365 instance.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="document">The document.</param>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <param name="start">The start.</param>
        internal void UpdateDocumentInDynamics365(Entity entity, Document document, XrmServiceContext xrmServiceContext, DateTime start)
        {
            Log.Log(Resources.EcmController_UploadDocument_Get_Record_Type_from_Dynamics_365___1, LogLevel.Debug);
            //Get Record Type from Dynamics 365...
            RecordType crmRecordType = GetRecordType(entity, xrmServiceContext);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Update_Document_Properties___1, LogLevel.Debug);
            //Update Document Properties...
            if (crmRecordType?.RecordTypeId != null)
            {
                Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Record_Type___1, LogLevel.Debug);
                //Set Document Record Type...
                document.RecordType =
                    new EntityReference(RecordType.EntityLogicalName, crmRecordType.RecordTypeId.Value);
            }
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Is_Customer_Visible___1, LogLevel.Debug);
            //Set Document Is Customer Visible...
            document.IsCustomerVisibleDocument = entity.IsCustomerVisibleDocument;
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Company___1, LogLevel.Debug);
            //Set Document Company...
            document.RBSCompany = new OptionSetValue((int)entity.Company);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Classification___1, LogLevel.Debug);
            //Set Document Classification...
            document.RBSClassification =
                new OptionSetValue((int)entity.Classification);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Personal_Information___1, LogLevel.Debug);
            //Set Document Personal Information...
            document.RBSPersonalInformation = entity.PersonalInfo;
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Language___1, LogLevel.Debug);
            //Set Document Language...
            document.Language = new OptionSetValue((int)entity.Language);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_Jurisdiction___1, LogLevel.Debug);
            //Set Document Jurisdiction...
            document.RBSJurisdiction =
                new OptionSetValue((int)entity.Jurisdiction);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Set_Document_High_Risk_Record___1, LogLevel.Debug);
            //Set Document High Risk Record...
            document.RBSHighRiskRecord =
                new OptionSetValue((int)entity.HighRiskRecord);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Update_the_Document___1, LogLevel.Debug);
            //Update the Document...
            xrmServiceContext.UpdateObject(document);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Save_the_changes___1, LogLevel.Debug);
            //Save the changes...
            xrmServiceContext.SaveChanges();
            Log.Log(Resources.EcmController_CreateDocumentInDynamics365_Instantiate_new_access_log_recording___1, LogLevel.Debug);
            //Instantiate new access log recording...
            CreateAccessLog(xrmServiceContext, document.Id,
                string.Format(CultureInfo.CurrentCulture,
                    Resources.EcmController_UpdateDocumentInDynamics365__0__was_updated_at__1__UTC_by__2_1,
                    document.DocumentName,
                    document.ModifiedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                    document.ModifiedBy != null
                        ? xrmServiceContext.SystemUserSet.FirstOrDefault(s => s.Id == document.ModifiedBy.Id)?.FullName
                        : CurrentUser.FullName),
                string.Format(CultureInfo.CurrentCulture,
                    Resources.EcmController_UpdateDocumentInDynamics365__0__was_updated_at__1__UTC_by__2_1,
                    document.DocumentName,
                    document.ModifiedOn?.ToUniversalTime() ?? DateTime.UtcNow,
                    document.ModifiedBy != null
                        ? xrmServiceContext.SystemUserSet.FirstOrDefault(s => s.Id == document.ModifiedBy.Id)?.FullName
                        : CurrentUser.FullName),
                new OptionSetValue((int)Model.Action.Update),
                start,
                DateTime.UtcNow,
                AccessLogStatusReason.Success);
        }

        /// <summary>
        /// Creates the access log.
        /// </summary>
        /// <param name="xrmServiceContext">The XRM service context.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="description">The description.</param>
        /// <param name="action">The action.</param>
        /// <param name="start">The start.</param>
        /// <param name="end">The end.</param>
        /// <param name="accessLogStatusReason">The access log status reason.</param>
        internal void CreateAccessLog(XrmServiceContext xrmServiceContext, Guid documentId, string name, string description, OptionSetValue action, DateTime start,
            DateTime end, AccessLogStatusReason accessLogStatusReason)
        {
            AccessLog accessLog = new AccessLog
            {
                Document = new EntityReference(Document.EntityLogicalName, documentId),
                User = new EntityReference(SystemUser.EntityLogicalName, CurrentUser.Id),
                Name = name,
                Description = description,
                Action = action,
                Start = start,
                End = end,
                AccessLogStatusReasonCode = accessLogStatusReason
            };
            if (accessLog.Name.Length > 100)
            {
                accessLog.Name = accessLog.Name.Substring(0, 100);
            }
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Add_the_access_log___1,
                LogLevel.Debug);
            //Add the access log...
            xrmServiceContext.AddObject(accessLog);
            Log.Log(Resources.EcmController_UpdateDocumentInDynamics365_Save_the_changes___1,
                LogLevel.Debug);
            //Save the changes...
            xrmServiceContext.SaveChanges();
        }

        /// <summary>
        /// Sends the updated metadata to the IBM ECM.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="recordClassCode">The record class code.</param>
        /// <param name="objectId">The object identifier.</param>
        /// <returns></returns>
        internal void SendUpdatedMetadataToEcm(Entity entity, string fileName, string recordClassCode,
            string objectId)
        {
            Log.Log(Resources.EcmController_SendDocumentToEcm_Upload_to_ECM___1, LogLevel.Debug);
            //Upload to ECM...
            UpdateMetadata(
                fileName,
                ConfigurationManager.AppSettings[Resources.EcmController_SendDocumentToEcm_CmisRepository],
                ConfigurationManager.AppSettings[Resources.EcmController_SendDocumentToEcm_CmisObjectTypeName],
                entity.Company.ToString(),
                DateTime.UtcNow,
                entity.Classification.ToString(),
                entity.PersonalInfo,
                entity.Language.ToString(),
                entity.Jurisdiction.ToString(),
                entity.EntityId,
                entity.EntityId,
                recordClassCode,
                entity.RecordType,
                //Add spaces to High Risk Record Field.
                AddSpacesToHighRiskRecord(entity.HighRiskRecord.ToString()),
                entity.IsCustomerVisibleDocument,
                objectId);
        }

        /// <summary>
        /// Updates the metadata.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="repository">The repository.</param>
        /// <param name="objectTypeName">Name of the object type.</param>
        /// <param name="company">The company.</param>
        /// <param name="createdOn">The created on.</param>
        /// <param name="classification">The classification.</param>
        /// <param name="personalInfo">if set to <c>true</c> [personal information].</param>
        /// <param name="language">The language.</param>
        /// <param name="jurisdiction">The jurisdiction.</param>
        /// <param name="customerReferenceId">The customer reference identifier.</param>
        /// <param name="documentId">The document identifier.</param>
        /// <param name="recordClassCode">The record class code.</param>
        /// <param name="recordType">Type of the record.</param>
        /// <param name="highRiskRecord">The high risk record.</param>
        /// <param name="isCustomerVisibleDocument">if set to <c>true</c> [is customer visible document].</param>
        /// <param name="objectId">The object identifier.</param>
        /// <returns></returns>
        /// <exception cref="WebApiException">Service Client Credentials cannot be null</exception>
        internal void UpdateMetadata(string fileName,
            string repository, string objectTypeName, string company, DateTime createdOn, string classification,
            bool personalInfo, string language, string jurisdiction, Guid customerReferenceId, Guid documentId,
            string recordClassCode, string recordType, string highRiskRecord, bool isCustomerVisibleDocument,
            string objectId)
        {
            Log.Log(Resources.EcmController_CreateDocument_Connect_to_the_ECM_service___1, LogLevel.Debug);
            //Connect to the ECM service...
            using (ObjectServicePortClient service = new ObjectServicePortClient())
            {
                Log.Log(Resources.EcmController_CreateDocument_Make_sure_Client_Credentials_is_not_null_before_instantiating_its_properties___1, LogLevel.Debug);
                //Make sure Client Credentials is not null before instantiating its properties...
                if (service.ClientCredentials == null)
                {
                    Log.Log(Resources.EcmController_CreateDocument_Service_Client_Credentials_cannot_be_null_1, LogLevel.Error);
                    //Throw exception is Client Credentials is null...
                    throw new WebApiException(Resources.EcmController_CreateDocument_Service_Client_Credentials_cannot_be_null_1);
                }
                Log.Log(Resources.EcmController_CreateDocument_Set_user_name_from_configuration_file___1, LogLevel.Debug);
                //Set user name from configuration file...
                service.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings[Resources.EcmController_CreateDocument_EcmUserName];
                Log.Log(Resources.EcmController_CreateDocument_Set_password_from_configuration_file___1, LogLevel.Debug);
                //Set password from configuration file...
                service.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings[Resources.EcmController_CreateDocument_EcmPassword];
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_properties_of_document_to_be_sent_to_ECM_service___1, LogLevel.Debug);
                //Instantiate properties of document to be sent to ECM service...
                cmisPropertiesType properties = new cmisPropertiesType();
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Object_Type_Identifier___1, LogLevel.Debug);
                //Instantiate Object Type Identifier...
                cmisPropertyId propertyId = new cmisPropertyId
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_cmis_objectTypeId,
                    value = new[] { $"{ objectTypeName }" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_File_Name_to_255_characters___1, LogLevel.Debug);
                //Restrict File Name to 255 characters...
                fileName = fileName.Length > 255 ? fileName.Substring(0, 255) : fileName;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Name___1, LogLevel.Debug);
                //Instantiate Name...
                cmisPropertyString cmisName = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_cmis_name,
                    value = new[] { $"{ fileName }" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Company_to_5_characters___1, LogLevel.Debug);
                //Restrict Company to 5 characters...
                company = company.Length > 5 ? company.Substring(0, 5) : company;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Company___1, LogLevel.Debug);
                //Instantiate Company...
                cmisPropertyString rbsCompany = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSCompany,
                    value = new[] { $"{ company }" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Creation_Date___1, LogLevel.Debug);
                //Instantiate Creation Date...
                cmisPropertyDateTime rmCreationDate = new cmisPropertyDateTime
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_rmCreationDate,
                    value = new[] { createdOn }
                };
                Log.Log(Resources.EcmController_UpdateMetadata_Restrict_Classification_to_12_characters___1, LogLevel.Debug);
                //Restrict Classification to 12 characters...
                classification = classification.Length > 12 ? classification.Substring(0, 12) : classification;
                Log.Log(Resources.EcmController_UpdateMetadata_Instantiate_Classification___1, LogLevel.Debug);
                //Instantiate Classification...
                cmisPropertyString rbsClassification = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSClassification,
                    value = new[] { $"{classification}" }
                };
                Log.Log(Resources.EcmController_UpdateMetadata_Instantiate_Personal_Information___1, LogLevel.Debug);
                //Instantiate Personal Information...
                cmisPropertyBoolean rbsPersonalInfo = new cmisPropertyBoolean
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSPersonalInfo,
                    value = new[] { personalInfo }
                };
                Log.Log(Resources.EcmController_UpdateMetadata_Restrict_Language_to_4_characters___1, LogLevel.Debug);
                //Restrict Language to 4 characters...
                language = language.Length > 4 ? language.Substring(0, 4) : language;
                Log.Log(Resources.EcmController_UpdateMetadata_Instantiate_Language___1, LogLevel.Debug);
                //Instantiate Language...
                cmisPropertyString cmisLanguage = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_Language,
                    value = new[] { $"{language}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Jurisdiction_to_4_characters___1, LogLevel.Debug);
                //Restrict Jurisdiction to 4 characters...
                jurisdiction = jurisdiction.Length > 4 ? jurisdiction.Substring(0, 4) : jurisdiction;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Jurisdiction___1, LogLevel.Debug);
                //Instantiate Jurisdiction...
                cmisPropertyString rbsJurisdiction = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSJurisdiction,
                    value = new[] { $"{jurisdiction}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Customer_Reference_Identifier___1, LogLevel.Debug);
                //Instantiate Customer Reference Identifier...
                cmisPropertyString cmisCustomerReferenceId = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_CustomerReferenceID,
                    value = new[] { $"{customerReferenceId.ToString()}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Document_Reference_Identifier___1, LogLevel.Debug);
                //Instantiate Document Reference Identifier...
                cmisPropertyString documentReferenceId = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_DocumentReferenceID,
                    value = new[] { $"{documentId.ToString()}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Record_Class_Code_to_10_characters___1, LogLevel.Debug);
                //Restrict Record Class Code to 10 characters...
                recordClassCode = recordClassCode.Length > 10 ? recordClassCode.Substring(0, 10) : recordClassCode;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Record_Class_Code___1, LogLevel.Debug);
                //Instantiate Record Class Code...
                cmisPropertyString cmisRecordClassCode = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RecordClassCode,
                    value = new[] { $"{recordClassCode}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_Record_Type_to_60_characters___1, LogLevel.Debug);
                //Restrict Record Type to 60 characters...
                recordType = recordType.Length > 60 ? recordType.Substring(0, 60) : recordType;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Record_Type___1, LogLevel.Debug);
                //Instantiate Record Type...
                cmisPropertyString cmisRecordType = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RecordType,
                    value = new[] { $"{recordType}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Restrict_High_Risk_Record_to_20_characters___1, LogLevel.Debug);
                //Restrict High Risk Record to 20 characters...
                highRiskRecord = highRiskRecord.Length > 20 ? highRiskRecord.Substring(0, 20) : highRiskRecord;
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_High_Risk_Record___1, LogLevel.Debug);
                //Instantiate High Risk Record...
                cmisPropertyString rbsHighRiskRecord = new cmisPropertyString
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_RBSHighRiskRecord,
                    value = new[] { $"{highRiskRecord}" }
                };
                Log.Log(Resources.EcmController_CreateDocument_Instantiate_Is_Customer_Visible_Document___1, LogLevel.Debug);
                //Instantiate Is Customer Visible Document...
                cmisPropertyBoolean cmisIsCustomerVisibleDocument = new cmisPropertyBoolean
                {
                    propertyDefinitionId = Resources.EcmController_CreateDocument_IsCustomerVisibleDocument,
                    value = new[] { isCustomerVisibleDocument }
                };
                Log.Log(Resources.EcmController_CreateDocument_Set_Properties__Items___1, LogLevel.Debug);
                //Set Properties' Items...
                properties.Items = new cmisProperty[] { propertyId, cmisName, rbsCompany, rmCreationDate,
                    rbsClassification, rbsPersonalInfo, cmisLanguage, rbsJurisdiction, cmisCustomerReferenceId,
                    documentReferenceId, cmisRecordClassCode, cmisRecordType, rbsHighRiskRecord,
                    cmisIsCustomerVisibleDocument };
                Log.Log(Resources.EcmController_CreateDocument_Set_extension_type___1, LogLevel.Debug);
                //Set extension type...
                cmisExtensionType ext = new cmisExtensionType();
                Log.Log(Resources.EcmController_UpdateMetadata_Instantiate_server_request___1, LogLevel.Debug);
                //Instantiate server request...
                updatePropertiesRequest updatePropertiesRequest =
                    new updatePropertiesRequest(repository, objectId, null, properties, ext);
                Log.Log(Resources.EcmController_CreateDocument_Submit_request_and_return_response___1, LogLevel.Debug);
                //Submit request and return response...
                service.updateProperties(updatePropertiesRequest);
            }
        }

        #endregion
    }
}