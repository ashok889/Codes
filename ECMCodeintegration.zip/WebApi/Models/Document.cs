﻿namespace Rbs.D365.EcmIntegrate.WebApi.Models
{
    /// <summary>
    /// Document
    /// </summary>
    public class Document
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Document"/> class.
        /// </summary>
        /// <param name="contentStream">The content stream.</param>
        /// <param name="documentName">Name of the document.</param>
        public Document(byte[] contentStream, string documentName)
        {
            ContentStream = contentStream;
            DocumentName = documentName;
        }

        /// <summary>
        /// Gets or sets the name of the document.
        /// </summary>
        /// <value>
        /// The name of the document.
        /// </value>
        public string DocumentName { get; set; }

        /// <summary>
        /// Gets or sets the content stream.
        /// </summary>
        /// <value>
        /// The content stream.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public byte[] ContentStream { get; set; }
    }
}