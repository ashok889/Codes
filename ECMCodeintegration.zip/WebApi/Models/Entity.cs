﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Rbs.D365.EcmIntegrate.Model;

namespace Rbs.D365.EcmIntegrate.WebApi.Models
{
    /// <summary>
    /// Entity
    /// </summary>
    public class Entity
    {
        /// <summary>
        /// Gets or sets the entity identifier.
        /// </summary>
        /// <value>
        /// The entity identifier.
        /// </value>
        [Required]
        [DisplayName("Entity Identifier")]
        public Guid EntityId { get; set; }

        /// <summary>
        /// Gets or sets the name of the entity.
        /// </summary>
        /// <value>
        /// The name of the entity.
        /// </value>
        [Required]
        [DisplayName("Entity Name")]
        public string EntityName { get; set; }

        /// <summary>
        /// Gets or sets the error message.
        /// </summary>
        /// <value>
        /// The error message.
        /// </value>
        [DisplayName("Error Message")]
        public string ErrorMessage { get; set; }
 
        /// <summary>
        /// Gets or sets the company.
        /// </summary>
        /// <value>
        /// The company.
        /// </value>
        [Required]
        [CLSCompliant(false)]
        public RBSCompany Company { get; set; }

        /// <summary>
        /// Gets or sets the classification.
        /// </summary>
        /// <value>
        /// The classification.
        /// </value>
        [Required]
        [CLSCompliant(false)]
        public RBSClassification Classification { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [personal information].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [personal information]; otherwise, <c>false</c>.
        /// </value>
        [Required]
        [Display(Name = "Personal Info")]
        public bool PersonalInfo { get; set; }

        /// <summary>
        /// Gets or sets the language.
        /// </summary>
        /// <value>
        /// The language.
        /// </value>
        [Required]
        [CLSCompliant(false)]
        public Language Language { get; set; }

        /// <summary>
        /// Gets or sets the jurisdiction.
        /// </summary>
        /// <value>
        /// The jurisdiction.
        /// </value>
        [Required]
        [CLSCompliant(false)]
        public RBSJurisdiction Jurisdiction { get; set; }

        /// <summary>
        /// Gets or sets the type of the record.
        /// </summary>
        /// <value>
        /// The type of the record.
        /// </value>
        [Required]
        [DisplayName("Record Type")]
        public string RecordType { get; set; }

        /// <summary>
        /// Gets or sets the high risk record.
        /// </summary>
        /// <value>
        /// The high risk record.
        /// </value>
        [Required]
        [DisplayName("High Risk Record")]
        [CLSCompliant(false)]
        public RBSHighRiskRecord HighRiskRecord { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is customer visible document.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is customer visible document; otherwise, <c>false</c>.
        /// </value>
        [Required]
        [DisplayName("Is Customer Visible Document?")]
        public bool IsCustomerVisibleDocument { get; set; }
    }
}