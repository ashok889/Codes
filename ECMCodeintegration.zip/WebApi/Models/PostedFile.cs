﻿namespace Rbs.D365.EcmIntegrate.WebApi.Models
{
    /// <summary>
    /// Posted File
    /// </summary>
    public class PostedFile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostedFile"/> class.
        /// </summary>
        /// <param name="contentLength">Length of the content.</param>
        /// <param name="contentType">Type of the content.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="data">The data.</param>
        public PostedFile(int contentLength, string contentType, string fileName, byte[] data)
        {
            ContentLength = contentLength;
            ContentType = contentType;
            FileName = fileName;
            Data = data;
        }

        /// <summary>
        /// Gets or sets the length of the content.
        /// </summary>
        /// <value>
        /// The length of the content.
        /// </value>
        public int ContentLength { get; set; }

        /// <summary>
        /// Gets or sets the type of the content.
        /// </summary>
        /// <value>
        /// The type of the content.
        /// </value>
        public string ContentType { get; set; }

        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>
        /// The name of the file.
        /// </value>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public byte[] Data { get; set; }
    }
}