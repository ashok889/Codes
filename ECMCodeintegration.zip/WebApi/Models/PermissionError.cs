﻿using System;
using System.Security.Principal;

namespace Rbs.D365.EcmIntegrate.WebApi.Models
{
    /// <summary>
    /// Permission Error
    /// </summary>
    public class PermissionError
    {
        /// <summary>
        /// Gets or sets the identity.
        /// </summary>
        /// <value>
        /// The identity.
        /// </value>
        public IIdentity Identity { get; set; }

        /// <summary>
        /// Gets or sets the error.
        /// </summary>
        /// <value>
        /// The error.
        /// </value>
        public string Error { get; set; }

        /// <summary>
        /// Gets or sets the exception.
        /// </summary>
        /// <value>
        /// The exception.
        /// </value>
        public Exception Exception { get; set; }
    }
}