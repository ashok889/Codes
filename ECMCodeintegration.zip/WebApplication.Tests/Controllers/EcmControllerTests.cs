﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Tooling.Connector;
using Moq;
using Rbs.D365.EcmIntegrate.Model;
using Rbs.D365.EcmIntegrate.WebApplication.Controllers;
using Rbs.D365.EcmIntegrate.WebApplication.Models;

namespace Rbs.D365.EcmIntegrate.WebApplication.Tests.Controllers
{
    /// <summary>
    /// ECM Controller Tests
    /// </summary>
    [TestClass]
    public class EcmControllerTests
    {
        /// <summary>
        /// Mocks the user.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public static void MockUser(ControllerBase controller)
        {
            //Validate
            if (controller == null)
            {
                throw new ArgumentNullException(nameof(controller));
            }

            //Mock the User...
            Mock<ControllerContext> controllerContextMock = new Mock<ControllerContext>();
            Mock<HttpContextBase> httpContextBaseMock = new Mock<HttpContextBase>();
            GenericIdentity genericIdentity = new GenericIdentity("europa\\kustjoh");
            GenericPrincipal genericPrincipal = new GenericPrincipal(genericIdentity, null);
            httpContextBaseMock.Setup(h => h.User).Returns(genericPrincipal);
            controllerContextMock.Setup(c => c.HttpContext).Returns(httpContextBaseMock.Object);
            controller.ControllerContext = controllerContextMock.Object;
        }
        
        /// <summary>
        /// Successes the test.
        /// </summary>
        [TestMethod]
        public void SuccessTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Mock the User...
                MockUser(controller);

                // Act
                ActionResult result = controller.Success();

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Spinners the test.
        /// </summary>
        [TestMethod]
        public void SpinnerTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Mock the User...
                MockUser(controller);

                // Act
                ActionResult result = controller.Spinner();

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Noes the file selected test.
        /// </summary>
        [TestMethod]
        public void NoFileSelectedTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Mock the User...
                MockUser(controller);

                // Act
                ActionResult result = controller.NoFileSelected();

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Errors the test.
        /// </summary>
        [TestMethod]
        public void ErrorTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Mock the User...
                MockUser(controller);

                // Act
                ActionResult result = controller.Error("Test");

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Uploads the request test.
        /// </summary>
        [TestMethod]
        public void UploadRequestTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Mock the User...
                MockUser(controller);

                //Instantiate Account...
                Mock<Account> account = new Mock<Account>();

                //Instantiate Incident...
                Mock<Incident> incident = new Mock<Incident>();

                //Instantiate Opportunity...
                Mock<Opportunity> opportunity = new Mock<Opportunity>();

                // Act
                ActionResult result = controller.Upload(account.Object.Id, Account.EntityLogicalName);

                // Assert
                Assert.IsNotNull(result);

                // Act
                result = controller.Upload(incident.Object.Id, Incident.EntityLogicalName);

                // Assert
                Assert.IsNotNull(result);

                // Act
                result = controller.Upload(opportunity.Object.Id, Opportunity.EntityLogicalName);

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Uploads the response test.
        /// </summary>
        [SuppressMessage("Microsoft.Maintainability",
            "CA1506:AvoidExcessiveClassCoupling")]
        [TestMethod]
        public void UploadResponseTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Set the User...
                Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("europa\\kustjoh"), null);
                //Mock the User...
                MockUser(controller);
                //Set Security to explicitly use TLS version 1.2.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                //Connect to Dynamics 365...
                using (CrmServiceClient crmServiceClient =
                    new CrmServiceClient(ConfigurationManager.ConnectionStrings["Dynamics365"].ConnectionString))
                {
                    //Instantiate Dynamics 365 Service Context...
                    using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                    {
                        //Instantiate Current User...
                        //controller.CurrentUser =
                        //    xrmServiceContext.SystemUserSet.FirstOrDefault(s =>
                        //        s.DomainName.Contains("johan.kustner@rbs.com"));

                        //Instantiate Account...
                        Account account = new Account
                        {
                            Name = "Test"
                        };

                        //Create the account and get its identifier...
                        Guid accountId = crmServiceClient.Create(account);

                        //Instantiate the entity...
                        Entity entity = new Entity
                        {
                            EntityId = accountId,
                            EntityName = Account.EntityLogicalName,
                            HighRiskRecord = RBSHighRiskRecord.HighRisk,
                            Classification = RBSClassification.Public,
                            RecordType = "Banking Customer Account Applications",
                            Company = RBSCompany.RBS,
                            Language = Language.ENG,
                            Jurisdiction = RBSJurisdiction.GBR,
                            PersonalInfo = false,
                            IsCustomerVisibleDocument = false
                        };

                        //Instantiate file name...
                        const string fileName = "test.txt";
                        const string fileText = "This is a test.";

                        //Create test file...
                        using (StreamWriter streamWriter = File.CreateText(Path.Combine(Path.GetTempPath(), fileName)))
                        {
                            streamWriter.WriteLine("This is a test.");
                        }

                        //Open the test file...
                        using (StreamReader streamReader = File.OpenText(Path.Combine(Path.GetTempPath(), fileName)))
                        {
                            //Instantiate File...
                            Mock<HttpPostedFileBase> httpPostedFileBase = new Mock<HttpPostedFileBase>();
                            httpPostedFileBase.Setup(h => h.FileName).Returns(fileName);
                            httpPostedFileBase.Setup(h => h.ContentType).Returns(MimeMapping.GetMimeMapping(fileName));
                            httpPostedFileBase.Setup(h => h.ContentLength).Returns(fileText.Length);
                            httpPostedFileBase.Setup(h => h.InputStream).Returns(streamReader.BaseStream);

                            //Add file to request files...
                            IEnumerable<HttpPostedFileBase> httpPostedFileBases = new List<HttpPostedFileBase>
                            {
                                httpPostedFileBase.Object

                            };

                            // Act
                            ActionResult result = controller.Upload(entity, httpPostedFileBases);

                            // Assert
                            Assert.IsNotNull(result);
                        }

                        //Delete all documents in the account...
                        foreach (Model.Document document in xrmServiceContext.DocumentSet.Where(d =>
                            d.CustomerReference.Id == accountId))
                        {
                            xrmServiceContext.DeleteObject(document);
                        }

                        xrmServiceContext.SaveChanges();

                        //Delete the account...
                        crmServiceClient.Delete(Account.EntityLogicalName, accountId);
                    }
                }
            }
        }

        /// <summary>
        /// Downloads the request test.
        /// </summary>
        [TestMethod]
        public void DownloadRequestTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {

                //Set the User...
                Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("europa\\kustjoh"), null);

                //Mock the User...
                MockUser(controller);

                // Act
                ActionResult result = controller.Download(It.IsAny<Guid>(), Model.Document.EntityLogicalName);

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Downloads the response document test.
        /// </summary>
        [TestMethod]
        public void DownloadResponseDocumentTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                Entity entity = new Entity
                {
                    EntityId = It.IsAny<Guid>(),
                    EntityName = Model.Document.EntityLogicalName
                };

                //Set the User...
                Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("europa\\kustjoh"), null);

                //Mock the User...
                MockUser(controller);

                // Act
                ActionResult result = controller.Download(entity);

                // Assert
                Assert.IsNotNull(result);
            }
        }

        /// <summary>
        /// Updates the request test.
        /// </summary>
        [TestMethod]
        public void UpdateRequestTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Mock the User...
                MockUser(controller);

                //Set Security to explicitly use TLS version 1.2.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                //Connect to Dynamics 365...
                using (CrmServiceClient crmServiceClient =
                    new CrmServiceClient(ConfigurationManager.ConnectionStrings["Dynamics365"].ConnectionString))
                {
                    //Instantiate Dynamics 365 Service Context...
                    using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                    {
                        //Instantiate Document...
                        Model.Document document = xrmServiceContext.DocumentSet.FirstOrDefault();

                        // Assert
                        Assert.IsNotNull(document);

                        // Act
                        ActionResult result = controller.Update(document.Id, Model.Document.EntityLogicalName);

                        // Assert
                        Assert.IsNotNull(result);
                    }
                }
            }
        }

        /// <summary>
        /// Updates the response test.
        /// </summary>
        [SuppressMessage("Microsoft.Maintainability",
            "CA1506:AvoidExcessiveClassCoupling")]
        [TestMethod]
        public void UpdateResponseTest()
        {
            // Arrange
            using (EcmController controller = new EcmController())
            {
                //Set the User...
                Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("europa\\kustjoh"), null);
                //Mock the User...
                MockUser(controller);
                //Set Security to explicitly use TLS version 1.2.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                //Connect to Dynamics 365...
                using (CrmServiceClient crmServiceClient =
                    new CrmServiceClient(ConfigurationManager.ConnectionStrings["Dynamics365"].ConnectionString))
                {
                    //Instantiate Dynamics 365 Service Context...
                    using (XrmServiceContext xrmServiceContext = new XrmServiceContext(crmServiceClient))
                    {
                        //Instantiate Current User...
                        //controller.CurrentUser =
                        //    xrmServiceContext.SystemUserSet.FirstOrDefault(s =>
                        //        s.DomainName.Contains("johan.kustner@rbs.com"));

                        //Instantiate Account...
                        Account account = new Account
                        {
                            Name = "Test"
                        };

                        //Create the account and get its identifier...
                        Guid accountId = crmServiceClient.Create(account);

                        //Instantiate the entity...
                        Entity entity = new Entity
                        {
                            EntityId = accountId,
                            EntityName = Account.EntityLogicalName,
                            HighRiskRecord = RBSHighRiskRecord.HighRisk,
                            Classification = RBSClassification.Public,
                            RecordType = "Banking Customer Account Applications",
                            Company = RBSCompany.RBS,
                            Language = Language.ENG,
                            Jurisdiction = RBSJurisdiction.GBR,
                            PersonalInfo = false,
                            IsCustomerVisibleDocument = false
                        };

                        //Instantiate file name...
                        const string fileName = "test.txt";
                        const string fileText = "This is a test.";

                        //Create test file...
                        using (StreamWriter streamWriter = File.CreateText(Path.Combine(Path.GetTempPath(), fileName)))
                        {
                            streamWriter.WriteLine("This is a test.");
                        }

                        //Open the test file...
                        using (StreamReader streamReader = File.OpenText(Path.Combine(Path.GetTempPath(), fileName)))
                        {
                            //Instantiate File...
                            Mock<HttpPostedFileBase> httpPostedFileBase = new Mock<HttpPostedFileBase>();
                            httpPostedFileBase.Setup(h => h.FileName).Returns(fileName);
                            httpPostedFileBase.Setup(h => h.ContentType).Returns(MimeMapping.GetMimeMapping(fileName));
                            httpPostedFileBase.Setup(h => h.ContentLength).Returns(fileText.Length);
                            httpPostedFileBase.Setup(h => h.InputStream).Returns(streamReader.BaseStream);

                            //Add file to request files...
                            IEnumerable<HttpPostedFileBase> httpPostedFileBases = new List<HttpPostedFileBase>
                            {
                                httpPostedFileBase.Object

                            };

                            // Act
                            ActionResult result = controller.Upload(entity, httpPostedFileBases);

                            // Assert
                            Assert.IsNotNull(result);


                            // Act
                            result = controller.Update(entity);

                            // Assert
                            Assert.IsNotNull(result);
                        }

                        //Delete all documents in the account...
                        foreach (Model.Document document in xrmServiceContext.DocumentSet.Where(d =>
                            d.CustomerReference.Id == accountId))
                        {
                            xrmServiceContext.DeleteObject(document);
                        }

                        xrmServiceContext.SaveChanges();

                        //Delete the account...
                        crmServiceClient.Delete(Account.EntityLogicalName, accountId);
                    }
                }
            }
        }
    }
}