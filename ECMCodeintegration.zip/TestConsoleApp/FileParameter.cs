﻿namespace Rbs.D365.EcmIntegrate.TestConsoleApp
{
    public static partial class PostRequest
    {
        /// <summary>
        /// File Parameter
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1034:NestedTypesShouldNotBeVisible")]
        public class FileParameter
        {
            /// <summary>
            /// Gets or sets the file.
            /// </summary>
            /// <value>
            /// The file.
            /// </value>
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
            public byte[] File { get; set; }

            /// <summary>
            /// Gets or sets the name of the file.
            /// </summary>
            /// <value>
            /// The name of the file.
            /// </value>
            public string FileName { get; set; }

            /// <summary>
            /// Gets or sets the type of the content.
            /// </summary>
            /// <value>
            /// The type of the content.
            /// </value>
            public string ContentType { get; set; }

            /// <summary>
            /// Initializes a new instance of the <see cref="FileParameter"/> class.
            /// </summary>
            /// <param name="file">The file.</param>
            public FileParameter(byte[] file) : this(file, null) { }

            /// <summary>
            /// Initializes a new instance of the <see cref="FileParameter"/> class.
            /// </summary>
            /// <param name="file">The file.</param>
            /// <param name="fileName">The file name.</param>
            public FileParameter(byte[] file, string fileName) : this(file, fileName, null) { }

            /// <summary>
            /// Initializes a new instance of the <see cref="FileParameter"/> class.
            /// </summary>
            /// <param name="file">The file.</param>
            /// <param name="fileName">The file name.</param>
            /// <param name="contentType">The content type.</param>
            public FileParameter(byte[] file, string fileName, string contentType)
            {
                File = file;
                FileName = fileName;
                ContentType = contentType;
            }
        }
    }
}
