﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading;
using Rbs.D365.EcmIntegrate.TestConsoleApp.Properties;

namespace Rbs.D365.EcmIntegrate.TestConsoleApp
{
    /// <summary>
    /// Upload Request Runner
    /// </summary>
    public class UploadRequestRunner
    {
        private byte[] _data;
        private readonly Collection<ExecutionResult> _results = new Collection<ExecutionResult>();

        /// <summary>
        /// Uploads the specified number of threads.
        /// </summary>
        /// <param name="numberOfThreads">The number of threads.</param>
        /// <returns></returns>
        public Collection<ExecutionResult> Upload(int numberOfThreads)
        {
            string filePath = ConfigurationManager.AppSettings["TestUploadFilePath"];

            using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                _data = new byte[fs.Length];
                fs.Read(_data, 0, _data.Length);
            }

            Thread[] threadPool = new Thread[numberOfThreads];

            for (int i = 0; i < numberOfThreads; i ++)
            {
                int threadNumber = i;
                Thread thread = new Thread(() => Run(filePath, threadNumber));
                threadPool[i] = thread;
                thread.Start();
            }

            foreach (Thread thread in threadPool)
            {
                thread.Join();
            }

            return _results;
        }

        /// <summary>
        /// Runs the specified file path.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <param name="threadNumber">The thread number.</param>
        private void Run(string filePath, int threadNumber)
        {
            ExecutionResult result = new ExecutionResult
            {
                RequestType = ExecutionResult.ExecutionType.Upload,
                ThreadNumber = threadNumber
            };

            string fileName = threadNumber + "_" + DateTime.Now.ToFileTime() + "_" + Path.GetFileName(filePath);
            string fileContentType = Path.GetExtension(filePath);
            // Generate post objects
            // TODO: Move file meta data settings to separate mapping file
            string testAccountId = ConfigurationManager.AppSettings["TestAccountId"];


            Dictionary<string, object> postParameters = new Dictionary<string, object>
            {
                { "filename", fileName },
                { "fileformat", fileContentType },
                { "files[0]", new PostRequest.FileParameter(_data, fileName, fileContentType) },
                { "Company", "RBS" },
                { "HighRiskRecord", "HighRisk" },
                { "Classification", "Internal" },
                { "Language", "ENG" },
                { "Jurisdiction", "GBR" },
                { "RecordType", "Balance Statements" },
                { "IsCustomerVisibleDocument", false },
                { "PersonalInfo", false },
                { "null", "" },
                { "EntityId", testAccountId },
                { "EntityName", "account" }
            };

            // Create request and receive response
            // Replace with local ECM service url for debug
            string uploadDocUrl = ConfigurationManager.AppSettings["UploadUrl"];
            const string userAgent = "VS Console";

            result.ThreadStartTime = DateTime.Now.ToLongTimeString();
            long start = DateTime.Now.ToFileTime();
            HttpWebResponse webResponse = PostRequest.MultipartFormDataPost(new Uri(uploadDocUrl), userAgent, postParameters);

            if (webResponse != null)
            {
                result.ThreadEndTime = DateTime.Now.ToLongTimeString();
                long end = DateTime.Now.ToFileTime();

                long seconds = (end - start) / 10000000;
                result.ExecutionTimeInSeconds = seconds ;

                // Process response
                // ReSharper disable once AssignNullToNotNullAttribute
                StreamReader responseReader = new StreamReader(webResponse.GetResponseStream());
                string fullResponse = responseReader.ReadToEnd();

                result.StatusCode = webResponse.StatusCode.ToString();
                result.Response = fullResponse;

                webResponse.Close();

                _results.Add(result);

                Console.WriteLine(Resources.UploadRequestRunner_Run_Upload_thread__0__completed_, threadNumber);
            }
            else
            {

                result.ThreadEndTime = "N/A";
                result.StatusCode = "No Response";

                _results.Add(result);

                Console.WriteLine(Resources.UploadRequestRunner_Run_Upload_thread__0__cannot_be_completed_, threadNumber);
            }
        }
    }
}
