﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace Rbs.D365.EcmIntegrate.TestConsoleApp
{
    /// <summary>
    /// Main
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <exception cref="Exception">Not able to read test threads number from configuration. {0}</exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes")]
        public static void Main()
        {
            int numberOfThreads;

            try
            {
                numberOfThreads = Convert.ToInt32(ConfigurationManager.AppSettings["NumberOfTestThreads"], CultureInfo.CurrentCulture);
            }
            catch (Exception ex)
            {
                throw new Exception("Not able to read test threads number from configuration. {0}", ex);
            }
            

            UploadRequestRunner uploadRequestRunner = new UploadRequestRunner();

            Collection<ExecutionResult> uploadResults = uploadRequestRunner.Upload(numberOfThreads);            

            DownloadRequestRunner downloadRequestRunner = new DownloadRequestRunner();
      
            Collection<ExecutionResult> downloadResults = downloadRequestRunner.Download(numberOfThreads);

            List<ExecutionResult> combined = uploadResults.Concat(downloadResults).ToList();

            string outputFilename = "TestResults_" + DateTime.Now.ToString("yyyyMMdd_hhmmss", CultureInfo.CurrentCulture) + ".xml";
            FileInfo file = new FileInfo(outputFilename);
            using (StreamWriter streamWriter = file.AppendText())
            {
                XmlSerializer writer = new XmlSerializer(typeof(List<ExecutionResult>));
                writer.Serialize(streamWriter, combined);
            }

            Console.ReadLine();
        }
    }
}



