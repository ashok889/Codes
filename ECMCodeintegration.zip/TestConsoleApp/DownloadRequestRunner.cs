﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Net;
using System.Threading;
using Rbs.D365.EcmIntegrate.TestConsoleApp.Properties;

namespace Rbs.D365.EcmIntegrate.TestConsoleApp
{
    /// <summary>
    /// Download Request Runner
    /// </summary>
    public class DownloadRequestRunner
    {
        private readonly Collection<ExecutionResult> _results = new Collection<ExecutionResult>();

        /// <summary>
        /// Downloads the specified number of threads.
        /// </summary>
        /// <param name="numberOfThreads">The number of threads.</param>
        /// <returns></returns>
        public Collection<ExecutionResult> Download(int numberOfThreads)
        {
            Thread[] threadPool = new Thread[numberOfThreads];

            for (int i = 0; i < numberOfThreads; i++)
            {
                int threadNumber = i;
                Thread thread = new Thread(() => Run(threadNumber));
                threadPool[i] = thread;
                thread.Start();
            }

            foreach (Thread thread in threadPool)
            {
                thread.Join();
            }

            return _results;
        }

        /// <summary>
        /// Runs the specified thread number.
        /// </summary>
        /// <param name="threadNumber">The thread number.</param>
        private void Run(int threadNumber)
        {

            ExecutionResult result = new ExecutionResult
            {
                RequestType = ExecutionResult.ExecutionType.Download,
                ThreadNumber = threadNumber
            };

            string testDownloadFileId = ConfigurationManager.AppSettings["TestDownloadFileId"];

            Dictionary<string, object> postParameters = new Dictionary<string, object>
            {
                { "EntityId", testDownloadFileId },
                { "EntityName", "rbs_document" }
            };

            // var downloadUrl = "https://localhost:44340/Ecm/DownloadDocument";
            // Replace with local ECM integration service url for debug

            string downloadUrl = ConfigurationManager.AppSettings["DownloadUrl"];
            string userAgent = "VS Console";

            result.ThreadStartTime = DateTime.Now.ToLongTimeString();
            long start = DateTime.Now.ToFileTime();
            HttpWebResponse webResponse = PostRequest.MultipartFormDataPost(new Uri(downloadUrl), userAgent, postParameters);

            if (webResponse != null)
            {
                result.ThreadEndTime = DateTime.Now.ToLongTimeString();
                long end = DateTime.Now.ToFileTime();

                long seconds = (end - start) / 10000000;
                result.ExecutionTimeInSeconds = seconds;
                result.StatusCode = webResponse.StatusCode.ToString();

                result.Response = webResponse.ContentType + "; "+ webResponse.Headers;

                webResponse.Close();

                _results.Add(result);

                Console.WriteLine(Resources.DownloadRequestRunner_Run_Download_thread__0__completed_, threadNumber);
            }
            else
            {
                result.ThreadEndTime = "N/A";
                result.StatusCode = "No Response";

                _results.Add(result);

                Console.WriteLine(Resources.DownloadRequestRunner_Run_Download_thread__0__cannot_be_completed_, threadNumber);
            }
        }
    }
}
