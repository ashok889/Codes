﻿
namespace Rbs.D365.EcmIntegrate.TestConsoleApp
{
    /// <summary>
    /// Execution Type
    /// </summary>
    public class ExecutionResult
    {
        /// <summary>
        /// Execution Type
        /// </summary>
        public enum ExecutionType
        {
            /// <summary>
            /// The upload
            /// </summary>
            Upload,

            /// <summary>
            /// The download
            /// </summary>
            Download
        }

        /// <summary>
        /// Gets or sets the type of the request.
        /// </summary>
        /// <value>
        /// The type of the request.
        /// </value>
        public ExecutionType RequestType { get; set; }

        /// <summary>
        /// Gets or sets the thread number.
        /// </summary>
        /// <value>
        /// The thread number.
        /// </value>
        public int ThreadNumber { get; set; }

        /// <summary>
        /// Gets or sets the thread start time.
        /// </summary>
        /// <value>
        /// The thread start time.
        /// </value>
        public string ThreadStartTime { get; set; }

        /// <summary>
        /// Gets or sets the thread end time.
        /// </summary>
        /// <value>
        /// The thread end time.
        /// </value>
        public string ThreadEndTime { get; set; }

        /// <summary>
        /// Gets or sets the execution time in seconds.
        /// </summary>
        /// <value>
        /// The execution time in seconds.
        /// </value>
        public double ExecutionTimeInSeconds { get; set; }

        /// <summary>
        /// Gets or sets the status code.
        /// </summary>
        /// <value>
        /// The status code.
        /// </value>
        public string StatusCode { get; set; }

        /// <summary>
        /// Gets or sets the response.
        /// </summary>
        /// <value>
        /// The response.
        /// </value>
        public string Response { get; set; }
    }
}
