﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;

namespace Rbs.D365.EcmIntegrate.TestConsoleApp
{
    /// <summary>
    /// Post Request
    /// </summary>
    public static partial class PostRequest
    {
        private static readonly Encoding Encoding = Encoding.UTF8;

        /// <summary>
        /// Posts the multipart form data.
        /// </summary>
        /// <param name="postUrl">The post URL.</param>
        /// <param name="userAgent">The user agent.</param>
        /// <param name="postParameters">The post parameters.</param>
        /// <returns></returns>
        public static HttpWebResponse MultipartFormDataPost(Uri postUrl, string userAgent, Dictionary<string, object> postParameters)
        {
            if (postUrl == null)
            {
                throw new ArgumentNullException(nameof(postUrl));
            }
            string formDataBoundary = string.Format(CultureInfo.CurrentCulture, "----------{0:N}", Guid.NewGuid());
            string contentType = "multipart/form-data; boundary=" + formDataBoundary;

            byte[] formData = GetMultipartFormData(postParameters, formDataBoundary);

            return PostForm(postUrl.AbsoluteUri, userAgent, contentType, formData);
        }

        /// <summary>
        /// Posts the form.
        /// </summary>
        /// <param name="postUrl">The post URL.</param>
        /// <param name="userAgent">The user agent.</param>
        /// <param name="contentType">Type of the content.</param>
        /// <param name="formData">The form data.</param>
        /// <returns></returns>
        /// <exception cref="NullReferenceException">request is not a http request</exception>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes")]
        private static HttpWebResponse PostForm(string postUrl, string userAgent, string contentType, byte[] formData)
        {
            if (!(WebRequest.Create(postUrl) is HttpWebRequest request))
            {
                throw new NullReferenceException("request is not a http request");
            }

            string username = ConfigurationManager.AppSettings["TestUser"];
            string password = ConfigurationManager.AppSettings["TestUserPassword"];

            request.Credentials = new NetworkCredential(username, password);
            // System.Net.CredentialCache.DefaultNetworkCredentials; 
            // Set up the request properties.
            request.Method = "POST";
            request.ContentType = contentType;
            request.UserAgent = userAgent;
            request.CookieContainer = new CookieContainer();
            request.ContentLength = formData.Length;

            // You could add authentication here as well if needed:
            // request.PreAuthenticate = true;
            // request.AuthenticationLevel = System.Net.Security.AuthenticationLevel.MutualAuthRequested;
            // request.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(System.Text.Encoding.Default.GetBytes("username" + ":" + "password")));

            // Send the form data to the request.
            try
            {
                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(formData, 0, formData.Length);
                }

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                return response;
            }
            catch (Exception)
            {
                return null;
            }


        }

        private static byte[] GetMultipartFormData(Dictionary<string, object> postParameters, string boundary)
        {
            byte[] formData;
            using (Stream formDataStream = new MemoryStream())
            {
                bool needsCrlf = false;

                foreach (KeyValuePair<string, object> param in postParameters)
                {
                    // Skip it on the first parameter, add it to subsequent parameters.
                    if (needsCrlf)
                        formDataStream.Write(Encoding.GetBytes("\r\n"), 0, Encoding.GetByteCount("\r\n"));

                    needsCrlf = true;

                    if (param.Value is FileParameter fileToUpload)
                    {
                        // Add just the first part of this param, since we will write the file data directly to the Stream
                        string header =
                            $"--{boundary}\r\nContent-Disposition: form-data; name=\"{param.Key}\"; filename=\"{fileToUpload.FileName ?? param.Key}\"\r\nContent-Type: {fileToUpload.ContentType ?? "application/octet-stream"}\r\n\r\n";

                        formDataStream.Write(Encoding.GetBytes(header), 0, Encoding.GetByteCount(header));

                        // Write the file data directly to the Stream, rather than serializing it to a string.
                        formDataStream.Write(fileToUpload.File, 0, fileToUpload.File.Length);
                    }
                    else
                    {
                        string postData =
                            string.Format(CultureInfo.CurrentCulture, "--{0}\r\nContent-Disposition: form-data; name=\"{1}\"\r\n\r\n{2}", boundary,
                                param.Key, param.Value);
                        formDataStream.Write(Encoding.GetBytes(postData), 0, Encoding.GetByteCount(postData));
                    }
                }

                // Add the end of the request.  Start with a newline
                string footer = "\r\n--" + boundary + "--\r\n";
                formDataStream.Write(Encoding.GetBytes(footer), 0, Encoding.GetByteCount(footer));

                // Dump the Stream into a byte[]
                formDataStream.Position = 0;
                formData = new byte[formDataStream.Length];
                formDataStream.Read(formData, 0, formData.Length);
            }

            return formData;
        }
    }
}
