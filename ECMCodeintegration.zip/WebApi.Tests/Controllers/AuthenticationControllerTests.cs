﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Rbs.D365.EcmIntegrate.WebApi.Tests.Controllers
{
    /// <summary>
    /// Authentication Controller Tests
    /// </summary>
    [TestClass]
    public class AuthenticationControllerTests
    {
        /// <summary>
        /// Determines whether [is authenticated] test.
        /// </summary>
        [TestMethod]
        public void IsAuthenticatedTest()
        {
            Assert.Fail();
        }
    }
}