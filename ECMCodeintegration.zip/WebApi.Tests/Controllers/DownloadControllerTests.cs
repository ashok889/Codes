﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Rbs.D365.EcmIntegrate.WebApi.Tests.Controllers
{
    /// <summary>
    /// Download Controller Tests
    /// </summary>
    [TestClass]
    public class DownloadControllerTests
    {
        /// <summary>
        /// Download test.
        /// </summary>
        [TestMethod]
        public void DownloadTest()
        {
            Assert.Fail();
        }
    }
}