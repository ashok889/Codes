﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Rbs.D365.EcmIntegrate.WebApi.Tests.Controllers
{
    /// <summary>
    /// Update Controller Tests
    /// </summary>
    [TestClass]
    public class UpdateControllerTests
    {
        /// <summary>
        /// Update test.
        /// </summary>
        [TestMethod]
        public void UpdateTest()
        {
            Assert.Fail();
        }
    }
}