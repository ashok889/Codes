﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Rbs.D365.EcmIntegrate.WebApi.Tests.Controllers
{
    /// <summary>
    /// Upload Controller Tests
    /// </summary>
    [TestClass]
    public class UploadControllerTests
    {
        /// <summary>
        /// Upload test.
        /// </summary>
        [TestMethod]
        public void UploadTest()
        {
            Assert.Fail();
        }
    }
}