﻿if (typeof (Gdpr) == "undefined")
{ Gdpr = {}; }

if (typeof (Gdpr.WarningNotifications) == "undefined")
{ Gdpr.WarningNotifications = {}; }

if (typeof (Gdpr.WarningNotifications.FormFunctions) == "undefined")
{ Gdpr.WarningNotifications.FormFunctions = {}; }

if (typeof (Gdpr.WarningNotifications.FormFunctions.OnSave) == "undefined")
{ Gdpr.WarningNotifications.FormFunctions.OnSave = {}; }

if (typeof (Gdpr.WarningNotifications.FormFunctions.OnLoad) == "undefined")
{ Gdpr.WarningNotifications.FormFunctions.OnLoad = {}; }

if (typeof (Gdpr.WarningNotifications.FormFunctions.OnChange) == "undefined")
{ Gdpr.WarningNotifications.FormFunctions.OnChange = {}; }


//Gdpr.WarningNotifications.FormFunctions.OnLoad.fieldsOnForm = [];
//Gdpr.WarningNotifications.FormFunctions.OnLoad.fetchList = [];



Gdpr.WarningNotifications.FormFunctions.OnLoad = {
    // JavaScript source code
    //    WARNINGNOTIFICATIONS.fetchList: var  [],
    //var fieldsOnForm = [],
    //var formContext,
    formContext: {},
    fieldsOnForm:[],
    fetchList: [],
    fetchAllSensitiveFields: function(executionContext, formType) {

        formContext = executionContext.getFormContext();
     
        Gdpr.WarningNotifications.FormFunctions.OnLoad.findFieldsOnForm();
        var selectQuery = "rbs_sensitivefieldses?$select=rbs_fieldname&$filter=rbs_entityname eq '" + formContext.data.entity.getEntityName() + "' and  statecode eq 0&$orderby=rbs_fieldname asc";
        var fieldResults = Gdpr.CommonFunctions.ApiCalls.GetRequest(selectQuery, false);
        fetchList = new Array();
        if (fieldResults != null) {
            for (var i = 0; i < fieldResults.value.length; i++) {

                fetchList[i] = fieldResults.value[i]["rbs_fieldname"];
            }
            Gdpr.WarningNotifications.FormFunctions.OnLoad.matchFieldsToRegisterEvents(formType);
        }
        else
        {
            //var alertString = {
            //    confirmButtonLabel: "Yes",
            //    text: this.statusText
            //};
            //var alertOptions = {
            //    height: 120,
            //    width: 260
            //};
            //Xrm.Navigation.openAlertDialog(alertString, alertOptions).then(function success(result) {
            //    console.log("Alert dialog closed");
            //}, function (error) {
            //    console.log(error.message);
            //});
        }       
    
    },
    findFieldsOnForm: function () {
        fieldsOnForm = new Array();
        formContext.data.entity.attributes.forEach( 
    
        function (attribute, index) {
      
            fieldsOnForm.push(attribute.getName());
        });
    },
    matchFieldsToRegisterEvents: function (formType)
    {                   
        for (var i = 0; i < fetchList.length; i++) {

            fieldsOnForm.find((function (element) {
                return element == fetchList[i]
            })) ? Gdpr.WarningNotifications.FormFunctions.OnLoad.RegisterEvents(fetchList[i],formType) : null
        }
    },
    RegisterEvents:function(arg1,formType) {

        if (typeof Xrm == 'undefined' || Xrm == null) setTimeout(function () { RegisterEvents(); }, 200);

        else {
            var warnUsers = function (executionContext) {


                var labelText = formContext.ui.controls.get(executionContext.getEventSource().getName()).getLabel();
                var linkText = "Contact";
                var level = "WARNING";
        
                var uniqueId = Math.floor(Math.random() * 50).toString();
                if (formType != undefined && formType != null && formType.toLowerCase() == "main")
                {        Notify.add("Only the minimum information required to support the individual or process must be recorded avoiding the capture of sensitive personal data where possible. For further guidance, contact your Privacy Officer.", "WARNING", "warningmessage",
                [
                {
                    type: "link",

                    text: "Contact",
                    callback: function () {
                        window.open("https://intranet.rbsres01.net/Legal/PrivacyandClientConfidentiality/Pages/default.aspx");
                    }
                }], 10);
                }
                    //       Xrm.Page.ui.setFormNotification(message, level, uniqueId);
                    //setTimeout(function () { Xrm.Page.ui.clearFormNotification(uniqueId); }, 10000);
                else { alert("Only the minimum information required to support the individual or process must be recorded avoiding the capture of sensitive personal data where possible. For further guidance, contact your Privacy Officer.\nhttps://intranet.rbsres01.net/Legal/PrivacyandClientConfidentiality/Pages/default.aspx"); }
          
           

            }

            formContext.getAttribute(arg1).addOnChange(warnUsers);

        }

    }

};