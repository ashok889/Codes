﻿if (typeof (Gdpr) == "undefined")
{ Gdpr = {}; }

if (typeof (Gdpr.WarningNotifications) == "undefined")
{ Gdpr.WarningNotifications = {}; }

if (typeof (Gdpr.WarningNotifications.ConfigureSensitiveFields) == "undefined")
{ Gdpr.WarningNotifications.ConfigureSensitiveFields = {}; }

//Events to Occur on Page Load
jQuery(document).ready(function ($) {
    document.getElementById("entitydropdown") != null ? Gdpr.WarningNotifications.ConfigureSensitiveFields.startSample(): setTimeout(function () { Gdpr.WarningNotifications.ConfigureSensitiveFields.startSample() }, 200);
    $('#close').click(function () { Gdpr.WarningNotifications.ConfigureSensitiveFields.resetControls(); return false; });

});
Gdpr.WarningNotifications.ConfigureSensitiveFields = {
    //Logical Name of the Entity Selected in the Entity Dropdown
         entityLogicalName:{},
    //Logical Name of the Attribute Selected in the Attribute Dropdown
         entityAttributeName:{},
    //An unordered list element to add Entity list items to
         entityResults:{},
         attributeResults:{},
    //An area to display messages
    message:{},

resetControls:function () 
{
    ///Summary
    ///Function to be called when either reset button is clicked or the Alert is Dismissed, to set the Page to it's default state on Page Load
    ///Summary

    $("#message").hide();
    message.innerText = "";

    $('#btnSaveRecord').removeAttr('disabled');

    entityLogicalName = (document.getElementById("entitydropdown").value = "default");
    entityAttributeName = (document.getElementById("attributedropdown").value = "default");
    document.getElementById("attributedropdown").length = 1;
},

createRecord:function () {
    ///Summary
    ///Function to be called on Save Button Call to create a record in the "Sensitive Fields" Entity
    ///Summary
    entityLogicalName = document.getElementById("entitydropdown").value;
    entityAttributeName = document.getElementById("attributedropdown").value;
    if ((entityLogicalName != "undefined" && entityLogicalName != null && entityLogicalName != "default") && (entityAttributeName != "undefined" && entityAttributeName != null && entityAttributeName != "default")) {

        var sensitiveRecord = {};
        sensitiveRecord.rbs_name = entityLogicalName + "_" + entityAttributeName;

        sensitiveRecord.rbs_fieldname = entityAttributeName;
        sensitiveRecord.rbs_entityname = entityLogicalName;

        //Create the Record
        SDK.JQuery.createRecord(
            sensitiveRecord,
            "rbs_sensitivefields",
           function () { Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, "Record Created!!", "success") },
            Gdpr.WarningNotifications.ConfigureSensitiveFields.errorHandler
          );

    }
    else {
        Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, "Entity/Attribute Values not selected", "warning");

    }
    document.getElementById("btnSaveRecord").setAttribute("disabled", "disabled");
},

errorHandler:function (error) {
    ///Summary
    ///Error  Callback
    ///Summary

    Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, error.message, "danger")

},

startSample:function () {
    ///<summary>
    /// Initializes the sample when the document is ready
    ///</summary>
    //Assign the global variables
    entityResults = document.getElementById("entitydropdown");
    entityLogicalName = document.getElementById("entitydropdown").value;
    message = document.getElementById("messagetext");
    //Set the Progresss Text
    Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, "Loading...", "info");

    //Retrieve entities
    Gdpr.Metadata.RetrieveAllEntities(Gdpr.Metadata.EntityFilters.Entity,
     false,
     Gdpr.WarningNotifications.ConfigureSensitiveFields.successRetrieveAllEntities,
     Gdpr.WarningNotifications.ConfigureSensitiveFields.errorRetrieveAllEntities);

   

},

successRetrieveAllEntities:function (entityMetadataCollection) {
    ///<summary>
    /// Receives the data from SDK.Metadata.RetrieveAllEntities and
    /// appends a option item to results for each one.
    ///</summary>

    //entityMetadataCollection.sort(function (a, b) {
    //    if (a.LogicalName < b.LogicalName)
    //    { return -1 }
    //    if (a.LogicalName > b.LogicalName)
    //    { return 1 }
    //    return 0;
    //});

    for (var i = 0; i < entityMetadataCollection.length; i++) {

        var entity = entityMetadataCollection[i];

        var entitySpan = document.createElement("option");

        //If fields do not have a customized Label,Schema Names will be displayed
        Gdpr.WarningNotifications.ConfigureSensitiveFields.setDropdownText(entitySpan, entity.DisplayName.UserLocalizedLabel != null ? entity.DisplayName.UserLocalizedLabel.Label : entity.SchemaName);

        entitySpan.value = entity.LogicalName;

        entitySpan.attributesRetrieved = false;

        entityResults.appendChild(entitySpan);

    }

    Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, "All Entities Loaded", "info");
},

errorRetrieveAllEntities: function (error) {
    ///<summary>
    /// Displays the error returned from  SDK.Metadata.RetrieveAllEntities if it fails.
    ///</summary>
    Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, error.message, "danger");

},
    
retrieveAttributes:function () {
///<summary>
/// Retrieves attributes for the entity list item that is clicked
///</summary>

    entityLogicalName = document.getElementById("entitydropdown").value;


Gdpr.Metadata.RetrieveEntity(Gdpr.Metadata.EntityFilters.Attributes,
entityLogicalName,
null,
false,
function (entityMetadata) { Gdpr.WarningNotifications.ConfigureSensitiveFields.successRetrieveEntity(entityLogicalName, entityMetadata); },
 Gdpr.WarningNotifications.ConfigureSensitiveFields.errorRetrieveEntity);





},

successRetrieveEntity:function (logicalName, entityMetadata) {
    ///<summary>
    /// Retrieves attributes for the entity list item that is clicked
    ///</summary>


    //entityMetadata.sort(function (a, b) {
    //    if (a.LogicalName < b.LogicalName)
    //    { return -1 }
    //    if (a.LogicalName > b.LogicalName)
    //    { return 1 }
    //    return 0;
    //});

    var theDropDown = document.getElementById("attributedropdown");
    theDropDown.options.length = 1;
    var numberOfOptions = theDropDown.options.length;



    var attributeResults = document.getElementById("attributedropdown");

    for (var i = 0; i < entityMetadata.length; i++) {
        var attribute = entityMetadata[i];
        //if (attribute.AttributeType == "String" || attribute.AttributeType == "Memo") {
            var attributeNode = document.createElement("option");
            Gdpr.WarningNotifications.ConfigureSensitiveFields.setDropdownText(attributeNode, attribute.DisplayName.UserLocalizedLabel != null ? attribute.DisplayName.UserLocalizedLabel.Label : attribute.SchemaName);
            attributeNode.value = attribute.LogicalName;
            attributeResults.appendChild(attributeNode);
       // }

    }


},

errorRetrieveEntity:function (error) {
    ///<summary>
    /// Displays the error returned from SDK.Metadata.RetrieveEntity if it fails.
    ///</summary>
    Gdpr.WarningNotifications.ConfigureSensitiveFields.setText(message, error.message, "danger");
   
},

setText:function (node, text, type) {
    ///<summary>
    /// setText and getText mitigate differences in how browsers set or get text content(innerText/textContent)
    ///setText here is used to set text in the Alert Messages and show them.
    ///</summary>
    if (typeof (node.innerText) != "undefined") {
        node.innerText = text;
        $("#message").removeClass();
        $("#message").addClass("alert alert-" + type + " fade in alert-dismissible");
        $("#message").show();
    }
    else {
        node.textContent = text;
        $("#message").removeClass();
        $("#message").addClass("alert alert-" + type + " fade in alert-dismissible");
        $("#message").show();
    }

},

setDropdownText:function (node, text) {
    ///Summary
    /////Adds the dropdown Text to Entity and Attribute Dropdowns 
    ///Summary
    if (typeof (node.innerText) != "undefined") {
        node.innerText = text;
    }
    else {
        node.textContent = text;

    }

},

getText:function (node) {
    if (typeof (node.innerText) != "undefined") {
        this
        return node.innerText;
    }
    else {
        return node.textContent;
    }
}

};
