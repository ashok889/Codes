﻿if (typeof (Gdpr) == "undefined")
{ Gdpr = {}; }

if (typeof (Gdpr.CommonFunctions) == "undefined")
{ Gdpr.CommonFunctions = {}; }

Gdpr.CommonFunctions.ApiCalls = {

    GetRequest: function (query, mode) {
        var results = null;
        if (query != null && mode != null) {
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.1/" + query, mode);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.onreadystatechange = function () {
                if (this.readyState === 4) {
                    req.onreadystatechange = null;
                    if (this.status === 200) {
                        results = JSON.parse(this.response);
                    }
                }
            };
            req.send();
        }
        return results;
    }
}

