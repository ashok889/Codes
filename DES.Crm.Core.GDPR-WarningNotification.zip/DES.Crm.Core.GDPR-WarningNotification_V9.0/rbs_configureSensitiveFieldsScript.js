// Logical Name of the Entity Selected in the Entity Dropdown
var entityLogicalName;
// Logical Name of the Attribute Selected in the Attribute Dropdown
var entityAttributeName;
// An unordered list element to add Entity list items to
var entityResults;
var attributeResults;
// An area to display messages
var message;

//Events to Occur on Page Load
$(document).ready(function () {
    document.getElementById("entitydropdown") != null ? startSample() : setTimeout(function () { startSample() }, 200);
    $('#close').click(function () { resetControls(); return false; });
                     
});

function resetControls() {
    ///Summary
    ///Function to be called when either reset button is clicked or the Alert is Dismissed, to set the Page to it's default state on Page Load
    ///Summary

    $("#message").hide();
    message.innerText = "";

    $('#btnSaveRecord').removeAttr('disabled');

    entityLogicalName = (document.getElementById("entitydropdown").value = "default");
    entityAttributeName = (document.getElementById("attributedropdown").value = "default");
    document.getElementById("attributedropdown").length = 1;
}

function createRecord() {
    ///Summary
    ///Function to be called on Save Button Call to create a record in the "Sensitive Fields" Entity
    ///Summary
    entityLogicalName = document.getElementById("entitydropdown").value;
    entityAttributeName = document.getElementById("attributedropdown").value;
    if ((entityLogicalName != "undefined" && entityLogicalName != null && entityLogicalName != "default") && (entityAttributeName != "undefined" && entityAttributeName != null && entityAttributeName != "default")) {

        var sensitiveRecord = {};
        sensitiveRecord.rbs_name = entityLogicalName + "_" + entityAttributeName;

        sensitiveRecord.rbs_fieldname = entityAttributeName;
        sensitiveRecord.rbs_entityname = entityLogicalName;

        //Create the Record
        SDK.JQuery.createRecord(
            sensitiveRecord,
            "rbs_sensitivefields",
           function () { setText(message, "Record Created!!", "success") },
            errorHandler
          );

    }
    else {
        setText(message, "Entity/Attribute Values not selected", "warning");
       
    }
    document.getElementById("btnSaveRecord").setAttribute("disabled", "disabled");
}

function errorHandler(error) {
    ///Summary
    ///Error  Callback
    ///Summary

    setText(message, error.message, "danger")

   
}

function startSample() {
    ///<summary>
    /// Initializes the sample when the document is ready
    ///</summary>
    //Assign the global variables
    entityResults = document.getElementById("entitydropdown");
    entityLogicalName = document.getElementById("entitydropdown").value;
    message = document.getElementById("messagetext");
   
    //Retrieve entities
    SDK.Metadata.RetrieveAllEntities(SDK.Metadata.EntityFilters.Entity,
     false,
     successRetrieveAllEntities,
     errorRetrieveAllEntities);

    //Set the Progresss Text
    setText(message, "Loading...","info");

}

function successRetrieveAllEntities(entityMetadataCollection) {
    ///<summary>
    /// Receives the data from SDK.Metadata.RetrieveAllEntities and
    /// appends a option item to results for each one.
    ///</summary>

    entityMetadataCollection.sort(function (a, b) {
        if (a.LogicalName < b.LogicalName)
        { return -1 }
        if (a.LogicalName > b.LogicalName)
        { return 1 }
        return 0;
    });

    for (var i = 0; i < entityMetadataCollection.length; i++) {

        var entity = entityMetadataCollection[i];

        var entitySpan = document.createElement("option");

        //If fields do not have a customized Label,Schema Names will be displayed
        setDropdownText(entitySpan, entity.DisplayName.UserLocalizedLabel!=null?entity.DisplayName.UserLocalizedLabel.Label:entity.SchemaName);
        entitySpan.value = entity.LogicalName;
        
        entitySpan.attributesRetrieved = false;
              
        entityResults.appendChild(entitySpan);
     
    }

    setText(message, "All Entities Loaded", "info");
}

function errorRetrieveAllEntities(error) {
    ///<summary>
    /// Displays the error returned from  SDK.Metadata.RetrieveAllEntities if it fails.
    ///</summary>
    setText(message, error.message,"danger");
   
}

function retrieveAttributes() {
    ///<summary>
    /// Retrieves attributes for the entity list item that is clicked
    ///</summary>

    entityLogicalName = document.getElementById("entitydropdown").value;


    SDK.Metadata.RetrieveEntity(SDK.Metadata.EntityFilters.Attributes,
    entityLogicalName,
    null,
    false,
    function (entityMetadata) { successRetrieveEntity(entityLogicalName, entityMetadata); },
    errorRetrieveEntity);





}

function successRetrieveEntity(logicalName, entityMetadata) {
    ///<summary>
    /// Retrieves attributes for the entity list item that is clicked
    ///</summary>


    entityMetadata.Attributes.sort(function (a, b) {
        if (a.LogicalName < b.LogicalName)
        { return -1 }
        if (a.LogicalName > b.LogicalName)
        { return 1 }
        return 0;
    });

    var theDropDown = document.getElementById("attributedropdown");
    theDropDown.options.length = 1;
    var numberOfOptions = theDropDown.options.length;



    var attributeResults = document.getElementById("attributedropdown");

    for (var i = 0; i < entityMetadata.Attributes.length; i++) {
        var attribute = entityMetadata.Attributes[i];
        if (attribute.AttributeType == "String" || attribute.AttributeType == "Memo")
        {
            var attributeNode = document.createElement("option");
            setDropdownText(attributeNode, attribute.DisplayName.UserLocalizedLabel != null ? attribute.DisplayName.UserLocalizedLabel.Label : attribute.SchemaName);
            attributeNode.value = attribute.LogicalName;
            attributeResults.appendChild(attributeNode);
        }

    }

   
}

function errorRetrieveEntity(error) {
    ///<summary>
    /// Displays the error returned from SDK.Metadata.RetrieveEntity if it fails.
    ///</summary>
    setText(message, error.message,"danger");
    if (alertFlag.checked == true)
        alert("Error!");
}

function setText(node, text, type) {
    ///<summary>
    /// setText and getText mitigate differences in how browsers set or get text content(innerText/textContent)
    ///setText here is used to set text in the Alert Messages and show them.
    ///</summary>
    if (typeof (node.innerText) != "undefined") {
        node.innerText = text;
        $("#message").removeClass();
        $("#message").addClass("alert alert-" + type + " fade in alert-dismissible");
        $("#message").show();
    }
    else {
        node.textContent = text;
        $("#message").removeClass();
        $("#message").addClass("alert alert-" + type + " fade in alert-dismissible");
        $("#message").show();
    }

}

function setDropdownText(node, text) {
    ///Summary
    /////Adds the dropdown Text to Entity and Attribute Dropdowns 
    ///Summary
    if (typeof (node.innerText) != "undefined") {
        node.innerText = text;
    }
    else {
        node.textContent = text;
    }

}

function getText(node) {
    if (typeof (node.innerText) != "undefined") {
        this
        return node.innerText;
    }
    else {
        return node.textContent;
    }
}

