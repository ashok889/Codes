﻿// JavaScript source code
// JavaScript source code
var fetchList = [];
var fieldsOnForm = [];


function fetchAllSensitiveFields(formType) {

    Xrm.Page.data.entity.attributes.forEach(
  function (attribute, index) {

      fieldsOnForm.push(attribute.getName());
  });

    var fetchExpression = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>" +
  "<entity name='rbs_sensitivefields' >" +
    "<attribute name='rbs_fieldname' />" +
    "<filter type='and' >" +
      "<condition attribute='rbs_entityname' operator='eq' value='" + Xrm.Page.data.entity.getEntityName() + "' />" +
      "<condition attribute='statecode' value='0' operator='eq'/>" +
    "</filter>" +
  "</entity>" +
"</fetch>";
    //  fetchList[0].attributes["rbs_fieldname"].value

    fetchList = XrmServiceToolkit.Soap.Fetch(fetchExpression);
    for (var i = 0; i < fetchList.length; i++) {

        fieldsOnForm.find((function (element) {
            return element == fetchList[i].attributes["rbs_fieldname"].value
        })) ? RegisterEvents(fetchList[i].attributes["rbs_fieldname"].value, formType) : null
    };




}
function RegisterEvents(arg1,formType) {

    if (typeof Xrm == 'undefined' || Xrm == null) setTimeout(function () { RegisterEvents(); }, 200);

    else {
        var warnUsers = function (executionContext) {


            var labelText = Xrm.Page.ui.controls.get(executionContext.getEventSource().getName()).getLabel();
            var linkText = "Contact";
            var level = "WARNING";
        
            var uniqueId = Math.floor(Math.random() * 50).toString();
            if(formType == "Main")
        {        Notify.add("Only the minimum information required to support the individual or process must be recorded avoiding the capture of sensitive personal data where possible. For further guidance, contact your Privacy Officer.", "WARNING", "warningmessage",
        [
        {
            type: "link",
            text: "Contact",
            callback: function () {
                window.open("https://intranet.rbsres01.net/Legal/PrivacyandClientConfidentiality/Pages/default.aspx");
            }
        }], 10);
        }
                //       Xrm.Page.ui.setFormNotification(message, level, uniqueId);
                //setTimeout(function () { Xrm.Page.ui.clearFormNotification(uniqueId); }, 10000);
            else { alert("Only the minimum information required to support the individual or process must be recorded avoiding the capture of sensitive personal data where possible. For further guidance, contact your Privacy Officer.\nhttps://intranet.rbsres01.net/Legal/PrivacyandClientConfidentiality/Pages/default.aspx"); }
           
           

        }

        Xrm.Page.getAttribute(arg1).addOnChange(warnUsers);


    }

}