if (typeof Rheem === "undefined") {
    var Rheem = {};
}
if (typeof Rheem.Jscripts === "undefined") {
    Rheem.Jscripts = {};
}
if (typeof Rheem.Jscripts === "undefined") {
    Rheem.Jscripts = {};
}
Rheem.Jscripts.Case_Ribbon = (function () {
    "use strict";
    let _formContext;

    var CaseApprovalStatus = {
        Approved: 535790001,
        Rejected: 535790002,
        PendingforApproval: 535790003,
    };

    var env = XrmUtilities.Helper.GetEnvironmentHelper(Xrm);

    function showHide_SendforApproval_Button(primaryControl) {
        var ctx = XrmUtilities.Helper.GetFormContextHelper(primaryControl);
        var FIELD = {
            Owner: ctx.getFieldWrapper("ownerid"),
            ApprovalStatus: ctx.getFieldWrapper("rhm_approvalstatus"),
            FormType: ctx.getFormType(),
        };
        if (
            FIELD.Owner.value[0].id.slice(1, -1) == env.getUserId().toUpperCase() &&
            FIELD.FormType != 1 &&
            (FIELD.ApprovalStatus.value == null ||
                FIELD.ApprovalStatus.value == CaseApprovalStatus.Rejected)
        ) {
            return true;
        }
        return false;
    }

    async function onClickOfPartOrder(formContext) {
        if (formContext) {
            let formContextHelper =
                XrmUtilities.Helper.GetFormContextHelper(formContext);
            let navigationHelper = XrmUtilities.Helper.GetNavigationHelper(Xrm);
            if ((await checkProductSerialNumber(formContextHelper)) <= 0) {
                formContextHelper.addFormNotification(
                    "Please add Product Serial Number before adding parts.",
                    "error",
                    "PRODUCT-SERIAL-NUMBER-NOT-EXISTS-NOTIFY-001"
                );
                return;
            } else {
                formContextHelper.clearFormNotification(
                    "PRODUCT-SERIAL-NUMBER-NOT-EXISTS-NOTIFY-001"
                );
            }
            navigationHelper.showProgressIndicator(
                "Please wait.. Loading - Custom Part Orders Page"
            );
            let globalContext = Xrm.Utility.getGlobalContext();
            let customerEntityType = formContext
                .getAttribute("customerid")
                .getValue()[0].entityType;
            let configurationFetchXML = `?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='rhm_rheemconfiguration'>
    <attribute name='rhm_rheemconfigurationid' />
    <attribute name='rhm_name' />
    <attribute name='rhm_value' />
    <attribute name='rhm_key' />
    <order attribute='rhm_name' descending='false' />
    <filter type='and'>
      <filter type='or'>
        <condition attribute='rhm_key' operator='eq' value='CPO-01' />
      </filter>
      <condition attribute='statecode' operator='eq' value='0' />
    </filter>
  </entity></fetch>`;
            let relatedContactsFetchXML = `?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
  <entity name='${customerEntityType}'>
    <attribute name='${customerEntityType === "account" ? "name" : "fullname"
                }' />
    <attribute name='telephone1' />
    <attribute name='${customerEntityType}id' />
    <attribute name='address1_postalcode' />
    <attribute name='address1_line3' />
    <attribute name='address1_line2' />
    <attribute name='address1_line1' />
    <attribute name='address1_stateorprovince' />
    <attribute name='address1_country' />
    <attribute name='address1_city' />
    <attribute name='address1_composite' />
    <attribute name='emailaddress1' />
    <order attribute='${customerEntityType === "account" ? "name" : "fullname"
                }' descending='false' />
    <filter type='and'>
      <condition attribute='statecode' operator='eq' value='0' />
    </filter>
     <link-entity name='incident' from='customerid' to='${customerEntityType}id' link-type='inner' alias='AccountOrContact'>
                     <attribute name="incidentid" /> 
     <filter type='and'>
        <condition attribute='incidentid' operator='eq' uitype='incident' value='${formContext.data.entity.getId()}' />
      </filter>
    </link-entity>
  </entity>
</fetch>`;
            let relatedProductSerialNumbersFetchXML = `?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
  <entity name='rhm_productserialnumber'>
    <attribute name='rhm_productserialnumberid' />
    <attribute name='rhm_serialnumber' />
                    <attribute name='rhm_modelnumber' />
    <order attribute='rhm_serialnumber' descending='false' />
    <link-entity name='rhm_productserialnumber_incident' from='rhm_productserialnumberid' to='rhm_productserialnumberid' visible='false' intersect='true'>
      <link-entity name='incident' from='incidentid' to='incidentid' alias='Case'>
      <attribute name='incidentid' />
        <filter type='and'>
          <condition attribute='incidentid' operator='eq' uitype='incident' value='${formContext.data.entity.getId()}' />
        </filter>
      </link-entity>
    </link-entity>
  </entity>
</fetch>`;

            let configurationRecords = await retriveRecordsHelper(
                "rhm_rheemconfiguration",
                configurationFetchXML
            );
            let relatedContactRecords = await retriveRecordsHelper(
                customerEntityType,
                relatedContactsFetchXML
            );
            let relatedProductSerialNumbers = await retriveRecordsHelper(
                "rhm_productserialnumber",
                relatedProductSerialNumbersFetchXML
            );
            let productSerialNumberContacts =
                await getproductSerialNumberContactRecords(relatedProductSerialNumbers);
            let data = {
                clientURL: globalContext.getClientUrl(),
                currentRecordWebAPIURL:
                    globalContext.getClientUrl() +
                    "/api/data/v9.2/" +
                    "incidents" +
                    "(" +
                    formContext.data.entity.getId().replace(/[{}]/g, "") +
                    ")",
                entityName: formContext.data.entity.getEntityName(),
                recordId: formContext.data.entity.getId().replace(/[{}]/g, ""),
                configurationRecords: configurationRecords,
                //relatedContactRecords: relatedContactRecords,
                realatedProductSerialNumberRecords: replaceDuplicates(
                    relatedProductSerialNumbers,
                    "rhm_serialnumber"
                ),
                kbarticlesSearchURL:
                    globalContext.getClientUrl() +
                    "/main.aspx?pagetype=kbsearch&showLang=1&enableSelection=1&navbar=off",
                fromProductSerialNumber: false,
                fromCase: true,
                productSerialNumberContactRecords: replaceDuplicates(
                    productSerialNumberContacts,
                    "fullname"
                ),
            };
            let pageInput = {
                pageType: "webresource",
                webresourceName: "/rhm_/CustomPages/PartOrder/Index.html",
                data: JSON.stringify(data),
            };
            let navigationOptions = {
                target: 2,
                width: 2000,
                position: 1,
                title: "New Part Order",
            };
            navigationHelper.closeProgressIndicator();
            Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                function success() {
                    // Run code on success
                },
                function error() {
                    // Handle errors
                }
            );
        }
    }

    async function getproductSerialNumberContactRecords(
        relatedProductSerialNumbers
    ) {
        try {
            let relatedContactsFetchXML = `?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >
    <entity name='contact' >
        <attribute name='fullname' />
        <attribute name='telephone1' />
        <attribute name='contactid' />
        <attribute name='address1_postalcode' />
        <attribute name='address1_line3' />
        <attribute name='address1_line2' />
        <attribute name='address1_line1' />
        <attribute name='address1_stateorprovince' />
        <attribute name='address1_country' />
        <attribute name='address1_city' />
        <attribute name='address1_composite' />
        <attribute name='emailaddress1' />
        <order attribute='fullname' descending='false' />
        <link-entity name='rhm_productserialnumber_contact' from='contactid' to='contactid' visible='false' intersect='true' >
            <link-entity name='rhm_productserialnumber' from='rhm_productserialnumberid' to='rhm_productserialnumberid' alias='ProductSerialNumber' >
                <attribute name='rhm_productserialnumberid' />
                <attribute name='rhm_serialnumber' />
                <attribute name='rhm_modelnumber' />
                <filter type='and'>
                    <condition attribute='rhm_productserialnumberid' operator='in'> {0}  </condition>
                </filter>
            </link-entity>
        </link-entity>
    </entity>
</fetch>`;
            if (relatedProductSerialNumbers) {
                let valueCondition = "";
                relatedProductSerialNumbers.forEach((eachObj, index) => {
                    valueCondition += `<value uiname='${eachObj.rhm_serialnumber}' uitype='rhm_productserialnumber'>{${eachObj.rhm_productserialnumberid}}</value>`;
                });
                relatedContactsFetchXML = relatedContactsFetchXML.replace(
                    "{0}",
                    valueCondition
                );
                return await retriveRecordsHelper("contact", relatedContactsFetchXML);
            }
        } catch (e) { }
    }

    async function retriveRecordsHelper(entity, fetchXML) {
        return await Xrm.WebApi.retrieveMultipleRecords(entity, fetchXML).then(
            function success(result) {
                return result.entities;
            },
            function (error) {
                Xrm.Utility.closeProgressIndicator();
                console.log(error.message);
                return;
            }
        );
    }

    function replaceDuplicates(array, keyToCheck) {
        let hash = new Map();
        for (let i = 0; i < array.length; i++) {
            if (!hash.has(array[i][keyToCheck])) hash.set(array[i][keyToCheck], 1);
            else {
                let count = hash.get(array[i][keyToCheck]);
                hash.set(array[i][keyToCheck], hash.get(array[i][keyToCheck]) + 1);
                array[i][keyToCheck] += "-" + count.toString();
            }
        }
        return array;
    }

    function showHide_Approve_Reject_Button(primaryControl) {
        var ctx = XrmUtilities.Helper.GetFormContextHelper(primaryControl);
        var FIELD = {
            Owner: ctx.getFieldWrapper("ownerid"),
            Approver: ctx.getFieldWrapper("rhm_approver"),
            ApprovalStatus: ctx.getFieldWrapper("rhm_approvalstatus"),
            FormType: ctx.getFormType(),
        };
        if (
            FIELD.Approver.value != null &&
            FIELD.Approver.value[0].id.slice(1, -1) ==
            env.getUserId().toUpperCase() &&
            FIELD.FormType != 1 &&
            FIELD.ApprovalStatus.value == CaseApprovalStatus.PendingforApproval
        ) {
            return true;
        }
        return false;
    }

    function onClickOfSendForApproval(primaryControl) {
        var ctx = XrmUtilities.Helper.GetFormContextHelper(primaryControl);
        Xrm.Navigation.navigateTo(
            {
                pageType: "custom",
                name: "rhm_sendforapprovaldialouge_cddc3",
                entityName: "Approval",
                recordId: ctx.getEntityRecordId(),
            },
            {
                target: 2,
                width: 595,
                height: 390,
                title: "Send the Case for Approval",
            }
        ).then(
            () => {
                console.log("success");
                formContext.data.refresh();
            },
            (e) => console.log(e)
        );
    }

    function onClickOfapproveCase(primaryControl) {
        var ctx = XrmUtilities.Helper.GetFormContextHelper(primaryControl);
        Xrm.Navigation.navigateTo(
            {
                pageType: "custom",
                name: "rhm_sendforapprovaldialouge_cddc3",
                entityName: "Approve",
                recordId: ctx.getEntityRecordId(),
            },
            {
                target: 2,
                width: 595,
                height: 390,
                title: "Are you sure you want to Approve?",
            }
        ).then(
            () => {
                console.log("success");
                formContext.data.refresh();
            },
            (e) => console.log(e)
        );
    }

    function onClickOfrejectCase(primaryControl) {
        var ctx = XrmUtilities.Helper.GetFormContextHelper(primaryControl);
        Xrm.Navigation.navigateTo(
            {
                pageType: "custom",
                name: "rhm_sendforapprovaldialouge_cddc3",
                entityName: "Reject",
                recordId: ctx.getEntityRecordId(),
            },
            {
                target: 2,
                width: 595,
                height: 390,
                title: "Are you sure you want to Reject?",
            }
        ).then(
            () => {
                console.log("success");
                formContext.data.refresh();
            },
            (e) => console.log(e)
        );
    }

    function onClickOfEscalate(formContext) {
        try {
            if (formContext) {
                let formContextHelper =
                    XrmUtilities.Helper.GetFormContextHelper(formContext);
                Xrm.Navigation.navigateTo(
                    {
                        pageType: "custom",
                        name: "rhm_escalatecase_66f59",
                        entityName: "Case",
                        recordId: formContextHelper.getEntityRecordId(),
                    },
                    {
                        target: 2,
                        width: 510,
                        height: 385,
                        title: "Escalate Case",
                    }
                ).then(
                    () => {
                        console.log("success");
                        formContextHelper.refreshFormData(true, null, null);
                        formContextHelper.getControl("Timeline").refresh();
                    },
                    (e) => {
                        console.log(e);
                        formContextHelper.addFormNotification(
                            "Case couldn't be escalated. Please contact System Administrator.",
                            "WARNING",
                            "ERROR-001"
                        );
                    }
                );
            }
        } catch (e) {
            console.log(e);
        }
    }

    async function onClickOfCheckOrder(formContext) {
        try {
            if (formContext) {
                let formContextHelper =
                    XrmUtilities.Helper.GetFormContextHelper(formContext);
                let navigationHelper = XrmUtilities.Helper.GetNavigationHelper(Xrm);
                _formContext = formContext;
                let globalContext = Xrm.Utility.getGlobalContext();
                let currentRecordId = formContextHelper.getEntityRecordId();
                let purchaseOrderNumberExists = false;
                let salesOrderNumberExists = false;
                let isValid = false;
                let fieldName = {
                    SalesOrder: "rhm_salesorder",
                    PurchaseOrder: "rhm_purchaseorder",
                };
                let salerOrderNumber = formContextHelper.getAttributeValue(
                    fieldName.SalesOrder
                );
                let purchaseOrderNumber = formContextHelper.getAttributeValue(
                    fieldName.PurchaseOrder
                );
                purchaseOrderNumberExists = purchaseOrderNumber ? true : false;
                salesOrderNumberExists = salerOrderNumber ? true : false;

                if (!purchaseOrderNumberExists && !salesOrderNumberExists) {
                    formContextHelper.getControl(fieldName.PurchaseOrder).setFocus();
                    formContextHelper.getControl(fieldName.SalesOrder).setFocus();
                    XrmUtilities.Common.UpdateRequiredLevel(
                        fieldName.PurchaseOrder,
                        "required"
                    );
                    XrmUtilities.Common.UpdateRequiredLevel(
                        fieldName.SalesOrder,
                        "required"
                    );
                    formContextHelper.addControlNotification(
                        fieldName.PurchaseOrder,
                        "Please enter the Purchase Order Order Number.",
                        "PURCHASE-ORDER-NUMBER-NOTIFY-001"
                    );

                    formContextHelper.addControlNotification(
                        fieldName.SalesOrder,
                        "Please enter the Sales Order Order Number.",
                        "SALES-ORDER-NUMBER-NOTIFY-001"
                    );
                } else {
                    XrmUtilities.Common.UpdateRequiredLevel(
                        fieldName.SalesOrder,
                        "required"
                    );
                    XrmUtilities.Common.UpdateRequiredLevel(
                        fieldName.PurchaseOrder,
                        "required"
                    );
                    formContextHelper.clearControlNotification(
                        fieldName.SalesOrder,
                        "SALES-ORDER-NUMBER-NOTIFY-001"
                    );
                    formContextHelper.clearControlNotification(
                        fieldName.PurchaseOrder,
                        "PURCHASE-ORDER-NUMBER-NOTIFY-001"
                    );
                    isValid = true;
                }

                if (isValid) {
                    navigationHelper.showProgressIndicator(
                        "Searching for Sales Orders by SO Number. Please wait.."
                    );
                    if (salesOrderNumberExists) {
                        let fetchXMLForSalesOrderBySONumber = buildSalesOrderFetchXML(
                            "name",
                            salerOrderNumber
                        );
                        let salesOrderRecords = await retriveRecordsHelper(
                            "salesorder",
                            fetchXMLForSalesOrderBySONumber
                        );
                        if (salesOrderRecords && salesOrderRecords.length > 0) {
                            openSalesOrder(salesOrderRecords[0].salesorderid);
                            associateSalesOrder(
                                currentRecordId,
                                buildRelatedSalesOrderArray(salesOrderRecords)
                            );
                            navigationHelper.closeProgressIndicator();
                        } else {
                            navigationHelper.showProgressIndicator(
                                "Fetching Sales Order from Oracle. Please wait.."
                            );
                            let actionPluginData = {
                                SalesOrderNumber: salerOrderNumber ? salerOrderNumber : "",
                                PurchaseOrderNumber: purchaseOrderNumber
                                    ? purchaseOrderNumber
                                    : "",
                                CaseRecordGuid: currentRecordId,
                            };
                            fetch(
                                globalContext.getClientUrl() +
                                "/api/data/v9.2/rhm_FetchSalesOrders",
                                {
                                    method: "POST",
                                    body: JSON.stringify(actionPluginData),
                                    headers: {
                                        Accept: "application/json",
                                        "Content-Type": "application/json; charset=utf-8",
                                        "OData-MaxVersion": "4.0",
                                        "OData-Version": "4.0",
                                    },
                                }
                            )
                                .then((response) => response.json())
                                .then(async function (data) {
                                    if (data.IsSuccess) {
                                        navigationHelper.showProgressIndicator(
                                            "Fetching Sales Order from Oracle - Completed."
                                        );
                                        let fetchXMLForSalesOrder = buildSalesOrderFetchXML(
                                            "name",
                                            salerOrderNumber
                                        );
                                        let salesOrderRecords = await retriveRecordsHelper(
                                            "salesorder",
                                            fetchXMLForSalesOrder
                                        );
                                        if (salesOrderRecords && salesOrderRecords.length > 0) {
                                            openSalesOrder(salesOrderRecords[0].salesorderid);
                                            associateSalesOrder(
                                                currentRecordId,
                                                salesOrderRecords[0].salesorderid
                                            );
                                            navigationHelper.closeProgressIndicator();
                                        } else {
                                            formContextHelper.addFormNotification(
                                                "Sales Order doesn't exists.",
                                                "ERROR",
                                                "SALES-ORDER-FETCH-ORACLE-NOT-EXISTS-001"
                                            );
                                            navigationHelper.closeProgressIndicator();
                                        }
                                    } else {
                                        formContextHelper.addFormNotification(
                                            "An error occurred while retrieving Sales Order. Please contact System Administrator.",
                                            "ERROR",
                                            "SALES-ORDER-FETCH-ORACLE-ERROR-001"
                                        );
                                        navigationHelper.closeProgressIndicator();
                                    }
                                });
                            //   getSalesOrderFromOracle(
                            //     salerOrderNumber,
                            //     purchaseOrderNumber,
                            //     currentRecordId,
                            //     formContextHelper,
                            //     navigationHelper
                            //   );
                        }
                    } else if (purchaseOrderNumberExists && !salesOrderNumberExists) {
                        navigationHelper.showProgressIndicator(
                            "Searching for Sales Order by PO Number. Please wait.."
                        );
                        let fetchXMLForSalesOrderByPONumber = buildSalesOrderFetchXML(
                            "rhm_ponumber",
                            purchaseOrderNumber
                        );
                        let salesOrderRecords = await retriveRecordsHelper(
                            "salesorder",
                            fetchXMLForSalesOrderByPONumber
                        );
                        if (salesOrderRecords && salesOrderRecords.length > 0) {
                            associateSalesOrder(
                                currentRecordId,
                                buildRelatedSalesOrderArray(salesOrderRecords)
                            );
                            let ordersTab = formContextHelper.getTab(
                                "Sales_Orders_Tab_Custom"
                            );
                            ordersTab.setFocus();
                            formContextHelper
                                .getControl("Sales_Orders_SubGrid_Custom")
                                .refresh();
                            navigationHelper.closeProgressIndicator();
                        } else {
                            navigationHelper.showProgressIndicator(
                                "Fetching Purchase Order from Oracle. Please wait.."
                            );
                            let actionPluginData = {
                                SalesOrderNumber: "",
                                PurchaseOrderNumber: purchaseOrderNumber
                                    ? purchaseOrderNumber
                                    : "",
                                CaseRecordGuid: currentRecordId,
                            };
                            fetch(
                                globalContext.getClientUrl() +
                                "/api/data/v9.2/rhm_FetchSalesOrders",
                                {
                                    method: "POST",
                                    body: JSON.stringify(actionPluginData),
                                    headers: {
                                        Accept: "application/json",
                                        "Content-Type": "application/json; charset=utf-8",
                                        "OData-MaxVersion": "4.0",
                                        "OData-Version": "4.0",
                                    },
                                }
                            )
                                .then((response) => response.json())
                                .then(async function (data) {
                                    if (data.IsSuccess) {
                                        let ordersTab = formContextHelper.getTab(
                                            "Sales_Orders_Tab_Custom"
                                        );
                                        ordersTab.setFocus();
                                        formContextHelper
                                            .getControl("Sales_Orders_SubGrid_Custom")
                                            .refresh();
                                        formContextHelper.addFormNotification(
                                            "Fetching Purchase Order from Oracle - Completed.",
                                            "INFO",
                                            "PURCHASE-ORDER-RETRIEVED-001"
                                        );
                                        navigationHelper.closeProgressIndicator();
                                    } else {
                                        formContextHelper.addFormNotification(
                                            "An error occurred while retrieving Purchase Order. Please contact System Administrator.",
                                            "ERROR",
                                            "SALES-ORDER-FETCH-ORACLE-ERROR-001"
                                        );
                                        navigationHelper.closeProgressIndicator();
                                    }
                                });
                            //   getSalesOrderFromOracle(
                            //     salerOrderNumber,
                            //     purchaseOrderNumber,
                            //     currentRecordId,
                            //     formContextHelper,
                            //     navigationHelper
                            //   );
                        }
                    }
                }
            }
        } catch (e) {
            formContextHelper.addFormNotification(
                "An error occurred while retrieving Sales Order. Please contact System Administrator.",
                "ERROR",
                "SALES-ORDER-FETCH-ORACLE-ERROR-001"
            );
            navigationHelper.closeProgressIndicator();
            console.log(e);
        }
    }

    function buildSalesOrderFetchXML(attributeName, value) {
        try {
            if (attributeName && value) {
                let fetchXml = `?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                        <entity name='salesorder'>
                                            <attribute name='name' />
                                             <attribute name='rhm_ponumber' />
                                            <attribute name='salesorderid' />
                                            <order attribute='createdon' descending='true' />
                                            <filter type='and'>
                                            <condition attribute='{0}' operator='eq' value='{1}' />
                                            </filter>
                                        </entity>
                                        </fetch>`;
                return fetchXml.replace("{0}", attributeName).replace("{1}", value);
            }
        } catch (e) {
            console.log(e);
        }
    }

    function openSalesOrder(salesorderId) {
        try {
            if (salesorderId) {
                let navigationHelper = XrmUtilities.Helper.GetNavigationHelper(Xrm);
                navigationHelper.openEntityForm(
                    { mode: "modal", widthInPercent: 180, heightInPercent: 180 },
                    "salesorder",
                    salesorderId,
                    null,
                    null
                );
            }
        } catch (e) {
            console.log(e);
        }
    }

    function buildRelatedSalesOrderArray(salesOrders) {
        try {
            let returnSalesOrder = [];
            if (salesOrders && salesOrders.length > 0) {
                for (let i = 0; i < salesOrders.length; i++) {
                    let salesOrderObj = {
                        entityType: "salesorder",
                        id: salesOrders[i].salesorderid,
                    };
                    returnSalesOrder.push(salesOrderObj);
                }
                return returnSalesOrder;
            }
            return null;
        } catch (e) {
            console.log(e);
        }
    }

    function associateSalesOrder(caseGuid, relatedSalesOrderGuids) {
        try {
            if (caseGuid && relatedSalesOrderGuids.length > 0) {
                let salesOrderAssociateRequest = {
                    getMetadata: () => ({
                        boundParameter: null,
                        parameterTypes: {},
                        operationType: 2,
                        operationName: "Associate",
                    }),

                    relationship: "rhm_SalesOrder_Incident_Incident",

                    target: {
                        entityType: "incident",
                        id: caseGuid,
                    },

                    relatedEntities: relatedSalesOrderGuids,
                };

                Xrm.WebApi.online.execute(salesOrderAssociateRequest).then(
                    (success) => {
                        console.log("Success", success);
                    },
                    (error) => {
                        console.log("Error", error);
                    }
                );
            }
        } catch (e) {
            console.log(e);
        }
    }

    async function getLatestSalesOrderInfo(
        url,
        salesOrderNumber,
        purchaseOrderNumber,
        caseRecordGuid
    ) {
        try {
            if ((salesOrderNumber || purchaseOrderNumber) && caseRecordGuid) {
                let requestBody = {
                    IsFromSalesOrder: false,
                    IsFromCase: true,
                    CaseGuid: caseRecordGuid.replace("{", "").replace("}", ""),
                    SalesOrderNumber: salesOrderNumber,
                    PurchaseOrderNumber: purchaseOrderNumber,
                };
                return await fetch(url, {
                    method: "POST",
                    body: JSON.stringify(requestBody),
                    headers: {
                        "Content-Type": "application/json",
                    },
                });
            }
        } catch (e) {
            console.log(e);
        }
    }

    async function getFlowRunURLFromConfiguration() {
        try {
            let fetchXML = `?fetchXml=<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
  <entity name='rhm_rheemconfiguration'>
    <attribute name='rhm_rheemconfigurationid' />
        <attribute name='rhm_value' />
    <filter type='and'>
      <condition attribute='rhm_name' operator='eq' value='Get Sales Order Info - Flow URL' />
    </filter>
  </entity>
</fetch>`;

            return await Xrm.WebApi.retrieveMultipleRecords(
                "rhm_rheemconfiguration",
                fetchXML
            ).then(
                function success(result) {
                    if (result.entities && result.entities.length > 0) {
                        return result.entities[0].rhm_value;
                    }
                },
                function (error) {
                    Xrm.Utility.closeProgressIndicator();
                    console.log(error.message);
                    return;
                }
            );
        } catch (error) {
            console.log(e);
        }
    }

    function getSalesOrderFromOracle(
        salerOrderNumber,
        purchaseOrderNumber,
        currentRecordId,
        formContextHelper,
        navigationHelper
    ) {
        try {
            getFlowRunURLFromConfiguration().then((response) => {
                getLatestSalesOrderInfo(
                    response,
                    salerOrderNumber ? salerOrderNumber : "",
                    purchaseOrderNumber ? purchaseOrderNumber : "",
                    currentRecordId
                )
                    .then(async (response) => {
                        if (response && response.status === 200) {
                            if (response.IsSalesOrderNumberSearch) {
                                navigationHelper.showProgressIndicator(
                                    "Fetching Sales Order from Oracle - Completed."
                                );
                                let fetchXMLForSalesOrder = buildSalesOrderFetchXML(
                                    "name",
                                    salerOrderNumber
                                );
                                let salesOrderRecords = await retriveRecordsHelper(
                                    "salesorder",
                                    fetchXMLForSalesOrder
                                );
                                if (salesOrderRecords && salesOrderRecords.length > 0) {
                                    openSalesOrder(salesOrderRecords[0].salesorderid);
                                    navigationHelper.closeProgressIndicator();
                                } else {
                                    formContextHelper.addFormNotification(
                                        "Sales Order doesn't exists.",
                                        "ERROR",
                                        "SALES-ORDER-FETCH-ORACLE-NOT-EXISTS-001"
                                    );
                                    navigationHelper.closeProgressIndicator();
                                }
                            } else {
                                let ordersTab = formContextHelper.getTab(
                                    "Sales_Orders_Tab_Custom"
                                );
                                ordersTab.setFocus();
                                formContextHelper
                                    .getControl("Sales_Orders_SubGrid_Custom")
                                    .refresh();
                                formContextHelper.addFormNotification(
                                    "Fetching Sales Order from Oracle - Completed.",
                                    "INFO",
                                    "PURCHASE-ORDER-RETRIEVED-001"
                                );
                                navigationHelper.closeProgressIndicator();
                            }
                        } else {
                            formContextHelper.addFormNotification(
                                "An error occurred while retrieving Sales Order. Please contact System Administrator.",
                                "ERROR",
                                "SALES-ORDER-FETCH-ORACLE-ERROR-001"
                            );
                            navigationHelper.closeProgressIndicator();
                        }
                    })
                    .catch((error) => {
                        console.log(error);
                        formContextHelper.clearFormNotification("SALES-ORDER-REFRESH");
                        formContextHelper.addFormNotification(
                            "An error occurred while refreshing Sales Order Info - Kindly contact the administrator.",
                            "INFO",
                            "SALES-ORDER-REFRESH-ERROR"
                        );
                        Xrm.Utility.closeProgressIndicator();
                    });
            });
        } catch (error) {
            console.log(error);
        }
    }

    function checkProductSerialNumber(ctx) {
        return new Promise(function (resolve, reject) {
            Xrm.WebApi.retrieveMultipleRecords(
                "rhm_productserialnumber_incident",
                "?$filter=incidentid eq '" + ctx.getEntityRecordId() + "'"
            ).then(
                function success(result) {
                    resolve(result.entities.length);
                },
                function (error) {
                    reject(error.message);
                }
            );
        });
    }

    function checkOrderGrid(ctx) {
        debugger;
        return new Promise(function (resolve, reject) {
            Xrm.WebApi.retrieveMultipleRecords(
                "rhm_salesorder_incident",
                "?$filter=incidentid eq '" + ctx.getEntityRecordId() + "'"
            ).then(
                function success(result) {
                    resolve(result.entities.length);
                },
                function (error) {
                    reject(error.message);
                }
            );
        });
    }


    function requiementFlagUpdate(fieldsList) {
        fieldsList.forEach(function (item) {
            item.RequirementLevel = true;
        });
        return fieldsList;
    }

    async function onClickOfResolveCase(primaryControl) {
        var ctx = XrmUtilities.Helper.GetFormContextHelper(primaryControl);
        var caseTypeDefaultCaseFlag = false;
        var caseDetailDefaultCaseFlag = false;
        var ResolveCaseFlag = false;
        var FIELD = {
            CaseSubType: ctx.getFieldWrapper("rhm_casesubtype"),
            CaseDetail: ctx.getFieldWrapper("rhm_casedetail"),
            Model: ctx.getFieldWrapper("rhm_model"),
            Quote: ctx.getFieldWrapper("rhm_quote"),
            Channel: ctx.getFieldWrapper("rhm_channel"),
            XRAYusernamelogin: ctx.getFieldWrapper("rhm_xrayusernamelogin"),
            ComplaintSource: ctx.getFieldWrapper("rhm_complaintsource"),
            ComplaintType: ctx.getFieldWrapper("rhm_complainttype"),
            Product: ctx.getFieldWrapper("rhm_product"),
            CustomerLocation: ctx.getFieldWrapper("rhm_customerlocation"),
            ModelNumber: ctx.getFieldWrapper("rhm_modelnumber"),
            ECommerceIssue: ctx.getFieldWrapper("rhm_ecommerceissue"),
            ECommerceSiteSource: ctx.getFieldWrapper("rhm_ecommercesitesource"),
            Issue: ctx.getFieldWrapper("rhm_issue"),
            WarrantyType: ctx.getFieldWrapper("rhm_warrantytype"),
            DenialReason: ctx.getFieldWrapper("rhm_denialreason"),
            ConversionType: ctx.getFieldWrapper("rhm_conversiontype"),
            CurrentProduct: ctx.getFieldWrapper("rhm_currentproduct"),
            LegalComplaintSource: ctx.getFieldWrapper("rhm_legalcomplaintsource"),
            iWarrantyQuestionType: ctx.getFieldWrapper("rhm_iwarrantyquestiontype"),
            AdjustmentMade: ctx.getFieldWrapper("rhm_adjustmentmade"),
            ReasonForAdjustment: ctx.getFieldWrapper("rhm_reasonforadjustment"),
            QuestionType: ctx.getFieldWrapper("rhm_questiontype"),
            TypeOfRequest: ctx.getFieldWrapper("rhm_typeofrequest"),
            ApplicationDetail: ctx.getFieldWrapper("rhm_applicationdetail"),
            ApplicationType: ctx.getFieldWrapper("rhm_applicationtype"),
            TypeOfClaim: ctx.getFieldWrapper("rhm_typeofclaim"),
            IncidentDate: ctx.getFieldWrapper("rhm_incidentdate"),
            BodilyInjury: ctx.getFieldWrapper("rhm_bodilyinjury"),
            ClaimantContact: ctx.getFieldWrapper("rhm_claimantcontact"),
            ClaimantHas_IsContactingTheirCarrier: ctx.getFieldWrapper(
                "rhm_claimanthasiscontactingtheircarrier"
            ),
            InstallationIssue: ctx.getFieldWrapper("rhm_installationissue"),
            DiagnosisCode: ctx.getFieldWrapper("rhm_diagnosiscode"),
            ContractorName: ctx.getFieldWrapper("rhm_contractorname"),
            Installer: ctx.getFieldWrapper("rhm_installer"),
            FieldTechnicianName: ctx.getFieldWrapper("rhm_fieldtechnicianname"),
            FieldOutcome: ctx.getFieldWrapper("rhm_fieldoutcome"),
            ProductType: ctx.getFieldWrapper("rhm_producttype"),
            ProductLine: ctx.getFieldWrapper("rhm_productline"),
            ModelRecommendation: ctx.getFieldWrapper("rhm_modelrecommendation"),
            InstallationLocation: ctx.getFieldWrapper("rhm_installationlocation"),
            TypeOfProductInquiry: ctx.getFieldWrapper("rhm_typeofproductinquiry"),
            InformationDocumentProvided: ctx.getFieldWrapper(
                "rhm_information_documentprovided"
            ),
            ControlsIssue: ctx.getFieldWrapper("rhm_controlsissue"),
            Approver: ctx.getFieldWrapper("rhm_approver"),
            CreatedOn: ctx.getFieldWrapper("createdon"),
            ContactType: ctx.FormContext.ui.quickForms.get("Customer_Information"),
            ReturnIssue: ctx.getFieldWrapper("rhm_returnissue"),
            Outcome: ctx.getFieldWrapper("rhm_outcome"),
            ReturnReason: ctx.getFieldWrapper("rhm_returnreason"),
            ClaimsIssue: ctx.getFieldWrapper("rhm_claimissue"),
            DateofScalingIssueResolved: ctx.getFieldWrapper(
                "rhm_dateofscalingissueresolved"
            ),
            ItemIssueType: ctx.getFieldWrapper("rhm_itemissuetype"),
            ItemType: ctx.getFieldWrapper("rhm_itemtype"),
            CancellationReason: ctx.getFieldWrapper("rhm_cancellationreason"),
            DiscrepancyIssue: ctx.getFieldWrapper("rhm_discrepancyissue"),
            ShipToIssueType: ctx.getFieldWrapper("rhm_shiptoissuetype"),
            ShipToIssueResolved: ctx.getFieldWrapper("rhm_shiptoissueresolved"),
            IssueEnquiry: ctx.getFieldWrapper("rhm_issueinquiry")
        };

        let fieldsList = [
            {
                fieldName: "DiscrepancyIssue",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "CancellationReason",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ItemIssueType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            { fieldName: "ItemType", showHideFlag: false, RequirementLevel: false },
            { fieldName: "Model", showHideFlag: false, RequirementLevel: false },
            { fieldName: "Quote", showHideFlag: false, RequirementLevel: false },
            { fieldName: "Channel", showHideFlag: false, RequirementLevel: false },
            {
                fieldName: "XRAYusernamelogin",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ComplaintSource",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ComplaintType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            { fieldName: "Product", showHideFlag: false, RequirementLevel: false },
            {
                fieldName: "CustomerLocation",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ModelNumber",
                showHideFlag: false,
                RequirementLevel: false,
            },
            { fieldName: "ItemStatus", showHideFlag: false, RequirementLevel: false },
            {
                fieldName: "PlanningCriteria",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "AvailableToPromiseATPquantity",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ProductPartNumber",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ECommerceIssue",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ECommerceSiteSource",
                showHideFlag: false,
                RequirementLevel: false,
            },
            { fieldName: "Issue", showHideFlag: false, RequirementLevel: false },
            {
                fieldName: "WarrantyType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "DenialReason",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ConversionType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "CurrentProduct",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "LegalComplaintSource",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "iWarrantyQuestionType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "AdjustmentMade",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ReasonForAdjustment",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "QuestionType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "TypeOfRequest",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ApplicationDetail",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ApplicationType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "TypeOfClaim",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "IncidentDate",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "BodilyInjury",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ClaimantContact",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ClaimantHas_IsContactingTheirCarrier",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "InstallationIssue",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "DiagnosisCode",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ContractorName",
                showHideFlag: false,
                RequirementLevel: false,
            },
            { fieldName: "Installer", showHideFlag: false, RequirementLevel: false },
            {
                fieldName: "FieldTechnicianName",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "FieldOutcome",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ProductType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ProductLine",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ModelRecommendation",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "InstallationLocation",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "TypeOfProductInquiry",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "InformationDocumentProvided",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ControlsIssue",
                showHideFlag: false,
                RequirementLevel: false,
            },
            { fieldName: "Outcome", showHideFlag: false, RequirementLevel: false },
            {
                fieldName: "ReturnIssue",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ReturnReason",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ClaimsIssue",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "DateofScalingIssueResolved",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ShipToIssueType",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "ShipToIssueResolved",
                showHideFlag: false,
                RequirementLevel: false,
            },
            {
                fieldName: "IssueEnquiry",
                showHideFlag: false,
                RequirementLevel: false,
            }
        ];

        if (FIELD.CaseDetail.hasData) {
            await showHideFieldsByCaseDetailName(FIELD.CaseDetail.value[0].name, fieldsList);
        }
        if (FIELD.CaseSubType.hasData && (FIELD.CaseSubType.value[0].name === "Internal / Partners" || FIELD.CaseSubType.value[0].name == "Web-based" || FIELD.CaseSubType.value[0].name == "Legal" || FIELD.CaseSubType.value[0].name == "Agency" || FIELD.CaseSubType.value[0].name == "Invoicing / Billing")) {
            showHideFieldsByCaseSubTypeName(FIELD.CaseSubType.value[0].name, fieldsList);
        }
        else {
            caseTypeDefaultCaseFlag = true;
        }
        async function showHideFieldsByCaseDetailName(caseDetailName, fieldsList) {
            try {
                if (caseDetailName) {
                    switch (caseDetailName) {
                        case "Pricing & Quotes":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["Model", "Quote"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        // case "Unit / Equipment Configuration":
                        //   break;

                        case "Warranty Returns for Inspection":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ReturnReason"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Xray Support":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["XRAYusernamelogin"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Availability / Checking Stock":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["Product", "ModelNumber"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Internal E-Commerce Issues":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ECommerceIssue", "ECommerceSiteSource"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "External (3rd Party) E-Commerce Issues":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ECommerceIssue", "ECommerceSiteSource"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Registration Issue":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["Issue"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Product Conversion":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ConversionType", "CurrentProduct"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "iWarranty Questions":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["iWarrantyQuestionType"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Adjustments":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["AdjustmentMade", "ReasonForAdjustment"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "General Coverage":
                        case "Labor Request":
                        case "Claims Status":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                                ResolveCaseFlag = true;
                                CrmService.IncidentRibbon.CommandBarActions.resolve();
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                            }
                            break;

                        case "General Return Questions":
                        case "General Registration Questions":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["QuestionType"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Registration Request":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["TypeOfRequest"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Product Related Inquiry":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["TypeOfProductInquiry", "ProductLine"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Dealer / Distributor / Pro Search":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["InformationDocumentProvided"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Documentation Request":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["InformationDocumentProvided", "ProductLine"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Sizing & Selection":
                            fieldsList = fieldsList.filter(function (e) {
                                return [
                                    "ModelRecommendation",
                                    "ApplicationType",
                                    "ApplicationDetail",
                                    "InstallationLocation",
                                    "ProductLine",
                                ].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Troubleshooting":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["DiagnosisCode"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Installation":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["InstallationIssue"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        // case "Rheem Dispatch":
                        //   break;

                        case "Controls Issue":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ControlsIssue"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Potential Claim / ESIS":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return [
                                    "TypeOfClaim",
                                    "IncidentDate",
                                    "ProductType",
                                    "BodilyInjury",
                                    "ClaimantContact",
                                    "ClaimantHas_IsContactingTheirCarrier",
                                ].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Return Issue":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ReturnIssue", "Outcome"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Claims Issue":
                            if ((await checkProductSerialNumber(ctx)) > 0) {
                                ctx.clearFormNotification("PSN");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach a Product Serial Number to the Case before resolving the Case",
                                    "error",
                                    "PSN"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ClaimsIssue"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Scaling Issues":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["DateofScalingIssueResolved"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Item Issues":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ItemIssueType", "ItemType"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Order Cancellations":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["CancellationReason"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Shipping / Freight / Logistics":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["DiscrepancyIssue"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Ship-To Issues":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ShipToIssueType", "ShipToIssueResolved"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Critical components": case "Order Status": case "Order Change": case "Order Returns/RMS": case "Order Tracking": case "Order Processing":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }

                        case "Part Allocation Orders":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                        default:
                            ctx.clearFormNotification("PSN");
                            caseDetailDefaultCaseFlag = true;
                    }
                } else {
                    showHide(fieldsList);
                }
            } catch (error) {
                console.log(error);
            }
        }

        async function showHideFieldsByCaseSubTypeName(caseSubTypeName, fieldsList) {
            try {
                if (caseSubTypeName) {
                    switch (caseSubTypeName) {
                        case "Web-based":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ComplaintSource", "ComplaintType"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Agency":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ComplaintSource", "DiagnosisCode"].includes(
                                    e.fieldName
                                );
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Legal":
                            fieldsList = fieldsList.filter(function (e) {
                                return [
                                    "ComplaintType",
                                    "DiagnosisCode",
                                    "LegalComplaintSource",
                                ].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Internal / Partners":
                            fieldsList = fieldsList.filter(function (e) {
                                return ["ComplaintType"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        case "Invoicing / Billing":
                            if ((await checkOrderGrid(ctx)) > 0) {
                                ctx.clearFormNotification("Order");
                            } else {
                                ResolveCaseFlag = true;
                                ctx.addFormNotification(
                                    "Please attach an Order to the Case before resolving the Case",
                                    "error",
                                    "Order"
                                );
                                return;
                            }
                            fieldsList = fieldsList.filter(function (e) {
                                return ["IssueEnquiry"].includes(e.fieldName);
                            });
                            setFieldRequired(requiementFlagUpdate(fieldsList));
                            break;

                        default:

                    }
                }
            } catch (error) {
                console.log(error);
            }
        }

        function setFieldRequired(fieldNames) {
            try {
                if (fieldNames && FIELD) {
                    for (let i = 0; i < fieldNames.length; i++) {
                        if (fieldNames[i]["RequirementLevel"] === true) {
                            FIELD[fieldNames[i]["fieldName"]].setRequired();
                            ResolveCaseFlag = true;
                        } else {
                            FIELD[fieldNames[i]["fieldName"]].setOptional();
                        }
                    }
                    if (ResolveCaseFlag == true) {
                        CrmService.IncidentRibbon.CommandBarActions.resolve();
                    }
                }
            } catch (error) {
                console.log(error);
            }
        }


        defaultReslovecase();

        function defaultReslovecase() {
            if (ResolveCaseFlag == true) {
                return;
            }
            else if ((caseDetailDefaultCaseFlag == true && caseTypeDefaultCaseFlag == true) || (caseDetailDefaultCaseFlag == false && caseTypeDefaultCaseFlag == true) || (caseDetailDefaultCaseFlag == true && caseTypeDefaultCaseFlag == false)) {
                CrmService.IncidentRibbon.CommandBarActions.resolve();
            }
        }
    }
    return {
        OnClickOfPartOrder: onClickOfPartOrder,
        OnClickOfEscalate: onClickOfEscalate,
        ShowHide_SendforApproval_Button: showHide_SendforApproval_Button,
        ShowHide_Approve_Reject_Button: showHide_Approve_Reject_Button,
        OnClickOfSendForApproval: onClickOfSendForApproval,
        OnClickOfapproveCase: onClickOfapproveCase,
        OnClickOfrejectCase: onClickOfrejectCase,
        OnClickOfCheckOrder: onClickOfCheckOrder,
        OnClickOfResolveCase: onClickOfResolveCase,
    };
})();