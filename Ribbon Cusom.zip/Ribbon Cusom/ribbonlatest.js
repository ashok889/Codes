function getUserTeam(primaryControl)
{

debugger;
var formContext = primaryControl;
var isTeammember = "false";
var currentLoggedInUserId = Xrm.Page.context.getUserId().replace("{", "").replace("}","");
    
	
var Entity = "team";
var Select = "?$select=teamid";
var Filter = "&$filter=name eq 'Intake' ";
 
parent.Xrm.WebApi.retrieveMultipleRecords(Entity, Select + Filter).then(
    function success(result) {

        for (var i = 0; i < result.entities.length; i++) {
            var teamId =result.entities[0].teamid;
            
              break;
              
		
        }    
        	var teamId1=teamId;
    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.0/teams(" + teamId1 + ")?$expand=teammembership_association($filter=systemuserid eq " + currentLoggedInUserId + ")", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
    req.setRequestHeader("Prefer", "odata.maxpagesize=10");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                if (results.teammembership_association.length > 0)
				{ 
				     alert("test");
                
                     // return true;
					 
					 isTeammember = "true";

					
			    }
                else
				{
				    alert("test1");
                    //return false;
					isTeammember = "false";
				}
            }
            else {
                alert(this.statusText);
				//return false;
				isTeammember = "false";
            }
        }
    };
    req.send();  

	 if(isTeammember == "true" )
	 {	 return true;
		 
		 
	 }
	 
	 else {
	 alert("test4");
	 return false;
	 }                
 
    
    },
    function (error) {
        console.log(error.message);
    }
);

	 
	 
}
