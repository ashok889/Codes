function getUserTeam(primaryControl)
{
	
	debugger;
	 var TeamID = "";
	 var returnvalue = "";
	 var isTeammember = "false";
    var userSettings = Xrm.Utility.getGlobalContext().userSettings; // userSettings is an object with user information.
    var current_User_Id = userSettings.userId; // The user's unique id
    var newid = current_User_Id.slice(1, -1);	
    var req = new XMLHttpRequest();
req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.2/teams?$select=teamid,name&$filter=name eq 'Fingerprinting'", false);
req.setRequestHeader("OData-MaxVersion", "4.0");
req.setRequestHeader("OData-Version", "4.0");
req.setRequestHeader("Accept", "application/json");
req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
req.onreadystatechange = function() {
    if (this.readyState === 4) {
        req.onreadystatechange = null;
        if (this.status === 200) {
            var results = JSON.parse(this.response);
            //for (var i = 0; i < results.value.length; i++) {
				if(results.value.length >0) {
                 TeamID = results.value[0].teamid;
				  returnvalue =  CheckTeamMembership(TeamID);
				  if(returnvalue == "true"){
					  
					 isTeammember = "true"; 
				  }
				  else {
				  isTeammember = "false"; 
				  }
				}
				
            //}
        } else {
            Xrm.Utility.alertDialog(this.statusText);
			isTeammember = 	"false";
        }
    }
};
req.send();
if(isTeammember == "true" )
	 {	 return true;
		 
		 
	 }
	 
	 else {
	 //alert("test4");
	 return false;
	 } 


}

function CheckTeamMembership(TeamID) 
{
	var isTeammember1 = "";
	//Get Membrship by TeamID
	    var userSettings = Xrm.Utility.getGlobalContext().userSettings; // userSettings is an object with user information.
    var current_User_Id = userSettings.userId; // The user's unique id
    var newid = current_User_Id.slice(1, -1);

var req1 = new XMLHttpRequest();
			req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.0/teams(" + TeamID + ")?$expand=teammembership_association($filter=systemuserid eq " + newid + ")", false);
			req1.setRequestHeader("OData-MaxVersion", "4.0");
			req1.setRequestHeader("OData-Version", "4.0");
			req1.setRequestHeader("Accept", "application/json");
			req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
			req1.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
			req1.setRequestHeader("Prefer", "odata.maxpagesize=10");
			req1.onreadystatechange = function () {
				if (this.readyState === 4) {
					req1.onreadystatechange = null; 
					if (this.status === 200) {
						var results = JSON.parse(this.response);
						if (results.teammembership_association.length > 0)
						{ 
							 //alert("test");
						
							 // return true;
							 
							 isTeammember1 = "true";
							 //IsTeamMember(isTeammember);

							
						}
						else
						{
							//alert("test1");
							//return false;
							isTeammember1 = "false";
							// IsTeamMember(isTeammember);
						}
					}
					else {
						//alert(this.statusText);
						//return false;
						isTeammember1 = "false";
						 //IsTeamMember(isTeammember);
					}
				}
			};
			req1.send();

 
return isTeammember1;

			
	
	
}