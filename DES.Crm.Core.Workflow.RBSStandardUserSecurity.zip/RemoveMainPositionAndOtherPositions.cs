﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.Collections.Generic;
using System.Linq;

namespace Security
{
    public sealed class RemoveMainPositionAndOtherPositions : CodeActivity
    {


        #region Properties

        [Input("User")]
        [ReferenceTarget("systemuser")]
        [RequiredArgument()]
        public InArgument<EntityReference> UserId { get; set; }


        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracer = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            Entity preImageEntity = context.PreEntityImages.Values.FirstOrDefault();
            // context.mess
            //
            Guid positionGuid = Guid.Empty;
            try
            {
                Guid userGuid = UserId.Get<EntityReference>(executionContext).Id;
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exceptions
                throw new InvalidPluginExecutionException(e.Message);
            }
        }
    }
}
