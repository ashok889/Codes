﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.Collections.Generic;
using System.Linq;

namespace Security
{
    public sealed class AssignSecurity : CodeActivity
    {


        #region Properties

        [Input("User")]
        [ReferenceTarget("systemuser")]
        [RequiredArgument()]
        public InArgument<EntityReference> UserId { get; set; }

        [Input("Position")]
        [ReferenceTarget("position")]
        public InArgument<EntityReference> PositionId { get; set; }

        [Input("Remove All Security Roles To User")]
        [Default("True")]
        public InArgument<bool> RemoveAllSecurityRolesToUserInAr { get; set; }

        [Input("Remove All Teams To User")]
        [Default("True")]
        public InArgument<bool> RemoveAllTeamsToUserInAr { get; set; }


        [Output("Result")]
        public OutArgument<bool> Result { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracer = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            Entity preImageEntity = context.PreEntityImages.Values.FirstOrDefault();
            // context.mess
            //
            Guid positionGuid = Guid.Empty;
            try
            {
                Guid userGuid = UserId.Get<EntityReference>(executionContext).Id;
                EntityReference Position = PositionId.Get<EntityReference>(executionContext);
                if (Position != null)
                {
                    positionGuid = PositionId.Get<EntityReference>(executionContext).Id;
                }

                // tracer.Trace(userGuid.ToString()  + "positionguid" + positionGuid.ToString());

                if (RemoveAllSecurityRolesToUserInAr.Get(executionContext) )
                {
                    RemoveAllSecurityRolesToUser(userGuid, service, tracer, context);
                }

                if (RemoveAllTeamsToUserInAr.Get(executionContext))
                {
                    RemoveAllTeamsToUser(userGuid, service, tracer, context);
                }

                Entity userObJ = service.Retrieve("systemuser", userGuid, new ColumnSet("isdisabled"));
                bool isDisable = userObJ.Attributes.Contains("isdisabled") ? userObJ.GetAttributeValue<bool>("isdisabled") : default(bool);
                tracer.Trace("Is Disable user:- " + "" + isDisable);

                if (!isDisable)
                {


                    //Assign BR to User of Main Position
                    AssignMPBusinessUnitToUser(userGuid, positionGuid, service, tracer, context);

                    //For Each SecurityRole / Position in Position.SecurityRoles / Positions
                    AssignMPSecurityRoleToUser(userGuid, positionGuid, service, tracer, context);

                    //For Each Team / Position in Position.Teams / Positions
                    AssignMPTeamToUser(userGuid, positionGuid, service, tracer, context);

                    //Assgning Other Position Role
                    AssignOPSecurityRoleToUser(userGuid, service, context, tracer);
                    //Assgning Other Position Team
                    AssignOPTeamToUser(userGuid, service, context, tracer);

                    ////Remove Current context(Deleted Record) Positiopn Role

                    //if (context.MessageName == "Delete" && context.PrimaryEntityName == "rbs_userposition")
                    //{
                    //    RemoveUserRoleForDeletedRecord();
                    //}

                }


            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exceptions
                throw new InvalidPluginExecutionException(e.Message);

            }

        }


       

        private void RemoveAllSecurityRolesToUser(Guid userGuid, IOrganizationService service, ITracingService tracer, IWorkflowContext context)
        {
           // tracer.Trace(userGuid.ToString());
            // tracer.Trace("This is start");
            //Guid  value = new Guid("dd4c62ee-46c5-e711-80eb-3863bb342b28");
            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
              <entity name='systemuser' >
                <attribute name='systemuserid' />
                <attribute name='fullname' />
                <filter>
                  <condition attribute='systemuserid' operator='eq' value= '" + userGuid + @"' />
                </filter>
                <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' intersect='true' >
                  <link-entity name='role' from='roleid' to='roleid' alias='role' >
                    <attribute name='name' />
                    <attribute name='roleid' />
                  </link-entity>
                </link-entity>
              </entity>
            </fetch>";
            var usersRolesColl = service.RetrieveMultiple(new FetchExpression(fetchXML));

            EntityReferenceCollection rolesCollection = new EntityReferenceCollection();

            foreach (Entity act in usersRolesColl.Entities)
            {
                Guid Role = (Guid)(((AliasedValue)act["role.roleid"]).Value);

                rolesCollection.Add(new EntityReference("role", Role));
            }

            if(rolesCollection.Count > 0)
                service.Disassociate("systemuser", userGuid, new Relationship("systemuserroles_association"), rolesCollection);

            //tracer.Trace("Removed all the security roles associated to " + userGuid + ". calling user id is " + context.UserId+ " Inititating User ID is "+context.InitiatingUserId);


        }

        private void RemoveAllTeamsToUser(Guid userGuid, IOrganizationService service, ITracingService tracer, IWorkflowContext context)
        {
            // tracer.Trace("this is step First");
            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'  >
                              <entity name='systemuser' >
                                <attribute name='systemuserid' />
                                <attribute name='fullname' />
                                <attribute name='businessunitid' />
                                <filter>
                                  <condition attribute='systemuserid' operator='eq' value= '" + userGuid + @"' />
                                </filter>
                                <link-entity name='teammembership' from='systemuserid' to='systemuserid' intersect='true' >
                                <link-entity name='team' from='teamid' to='teamid' alias='Team' >
                                    <attribute name='name' />
                                    <attribute name='teamid' />
                                    <attribute name='businessunitid' />
                                    <filter type='and' >
                                        <condition attribute='isdefault' value='0' operator='eq' />
                                    </filter>
                                </link-entity>
                                </link-entity>                              
                              </entity>
                            </fetch>";
            var usersRolesColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
            //tracer.Trace("This is remove");
            foreach (Entity act in usersRolesColl.Entities)
            {
                // Guid userBU = ((EntityReference)(act["businessunitid"])).Id;                
                // Guid teamBU = ((EntityReference)((AliasedValue)act.Attributes["Team.businessunitid"]).Value).Id;               
                   Guid team = (Guid)(((AliasedValue)act["Team.teamid"]).Value);
               
                    service.Disassociate("systemuser", userGuid, new Relationship("teammembership_association"), new EntityReferenceCollection() { new EntityReference("team", team) });
                
            }
            

            //tracer.Trace("Removed all the teams associated to" + userGuid + ". calling user id is " + context.UserId+ " Inititating User ID is " + context.InitiatingUserId);

        }

        private void AssignMPBusinessUnitToUser(Guid userGuid, Guid positionGuid, IOrganizationService service, ITracingService tracer, IWorkflowContext context)
        {

            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                              <entity name='position' >
                                <attribute name='rbs_businessunitid' />
                                <attribute name='name' />
                                <attribute name='positionid' />
                                <filter>
                                  <condition attribute='positionid' operator='eq'  value= '" + positionGuid + @"' />
                                </filter>
                              </entity>
                            </fetch>";
            var positionsColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
            //tracer.Trace("count: " + usersRolesColl.Entities.Count());
            //tracer.Trace("This is remove");
            string positionBUName="";

            if (positionsColl != null && positionsColl.Entities != null && positionsColl.Entities.Count > 0)
            {
                Entity mainPosition = positionsColl.Entities[0];

                Guid positionBUId = ((EntityReference)(mainPosition.Attributes["rbs_businessunitid"])).Id;
                positionBUName = ((EntityReference)(mainPosition.Attributes["rbs_businessunitid"])).Name;

                //SetBusinessSystemUserRequest changeUserBURequest = new SetBusinessSystemUserRequest();
                //changeUserBURequest.BusinessId = positionBUId;
                //changeUserBURequest.UserId = userGuid;
                //changeUserBURequest.ReassignPrincipal = new EntityReference("systemuser", userGuid);
                //service.Execute(changeUserBURequest);
                //tracer.Trace(positionBUName);
                Entity user = new Entity("systemuser");
                user.Id = userGuid;
                user["businessunitid"] = new EntityReference("systemuser", positionBUId);
                service.Update(user);
                // tracer.Trace("Bu Id: " + positionBUId.ToString());
                tracer.Trace("Bu updated to: " + positionBUName);

                //tracer.Trace("assigning Main Position Business Unit"+ positionBUName+" to"+ userGuid+ ". calling user id is "+ context.UserId + " Inititating User ID is " + context.InitiatingUserId);
            }
        }
        private void AssignMPSecurityRoleToUser(Guid userGuid, Guid positionGuid, IOrganizationService service, ITracingService tracer, IWorkflowContext context)
        {
           // tracer.Trace("This is assign role function");

            var listreturn = RetrievePositionSR(userGuid, positionGuid, service, tracer);
            //tracer.Trace("catching listreturn count: " + listreturn.Count().ToString());
            // tracer.Trace("User guid: " + userGuid.ToString());

            EntityReferenceCollection rolesCollection = new EntityReferenceCollection();

            foreach (var q in listreturn)
            {
                Guid positionRole = q;
                // tracer.Trace(positionRole.ToString());
                Entity ApplicationObj = (Entity)service.Retrieve("systemuser", userGuid, new ColumnSet(true));
                string userBUName = ((EntityReference)(ApplicationObj.Attributes["businessunitid"])).Name;

                tracer.Trace("userBU: " + userBUName);
                tracer.Trace("positionRoleId: " + positionRole.ToString());
                Entity RoleObj = (Entity)service.Retrieve("role", positionRole, new ColumnSet(true));
                string BUname = ((EntityReference)(RoleObj.Attributes["businessunitid"])).Name;
                tracer.Trace("RoleBU: " + BUname.ToString());

                rolesCollection.Add(RoleObj.ToEntityReference());
            }

            if (rolesCollection.Count > 0)
                service.Associate("systemuser", userGuid, new Relationship("systemuserroles_association"), rolesCollection);

            //tracer.Trace("assigning Main Position Security Role to"+userGuid +". calling user id is " +context.UserId + " Initiating User ID is " + context.InitiatingUserId);


        }
        private void AssignMPTeamToUser(Guid userGuid, Guid positionGuid, IOrganizationService service, ITracingService tracer, IWorkflowContext context)
        {
            var listreturn = RetrievePositionTeam(userGuid, positionGuid, service, tracer);

            foreach (var q in listreturn)
            {
                Guid positionTeamID = q;
                service.Associate("systemuser", userGuid, new Relationship("teammembership_association"), new EntityReferenceCollection() { new EntityReference("team", positionTeamID) });
            }
        }


        private List<Guid> RetrievePositionSR(Guid userGuid, Guid positionGuid, IOrganizationService service, ITracingService tracer)
        {
            //tracer.Trace("this is retrieve function");
            List<Guid> list = new List<Guid>();
            List<Guid> listPosition = new List<Guid>();
            Guid roleUserId = Guid.Empty;
            Guid positionRoleId = Guid.Empty;
            Guid positionBUId = Guid.Empty;



            string fetchXML1 = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                                <entity name='systemuser' >
                                <attribute name='systemuserid' />
                                <attribute name='fullname' />
                                <filter>
                                    <condition attribute='systemuserid' operator='eq' value= '" + userGuid + @"' />
                                </filter>
                                <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' intersect='true' >
                                    <link-entity name='role' from='roleid' to='roleid' alias='role' >
                                    <attribute name='name' />
                                    <attribute name='roleid' />
                                    </link-entity>
                                </link-entity>
                                </entity>
                            </fetch>";
            var usersRolesColl = service.RetrieveMultiple(new FetchExpression(fetchXML1));
            foreach (Entity actrole in usersRolesColl.Entities)
            {
                roleUserId = (Guid)(((AliasedValue)actrole["role.roleid"]).Value);
                string RoleName = ((AliasedValue)actrole["role.name"]).Value.ToString();
                list.Add(roleUserId);

            }
            if (positionGuid != Guid.Empty)
            { 
            //tracer.Trace(list.Count().ToString());
            Entity PositionObj = (Entity)service.Retrieve("position", positionGuid, new ColumnSet(true));
           
                positionBUId = ((EntityReference)(PositionObj.Attributes["rbs_businessunitid"])).Id;
            }

            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                              <entity name='position' >
                                <attribute name='rbs_businessunitid' />
                                <attribute name='name' />
                                <attribute name='positionid' />
                                <filter>
                                  <condition attribute='positionid' operator='eq'  value= '" + positionGuid + @"' />
                                </filter>
                                <link-entity name='rbs_positionsecurityrole' from='rbs_positionid' to='positionid' intersect='true' >
                                  <link-entity name='role' from='roleid' to='rbs_securityroleid' alias='role' >
                                    <attribute name='name' />
                                    <attribute name='roleid' /> 
                                    <filter>
                                      <condition attribute='businessunitid' operator='eq'  value= '" + positionBUId + @"' />
                                    </filter>                                   
                                  </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";
            var usersPositionRolesColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
            //tracer.Trace("This is remove");
            foreach (Entity act in usersPositionRolesColl.Entities)
            {
                positionRoleId = (Guid)(((AliasedValue)act["role.roleid"]).Value);
                // Prole.positionRoleName = act["name"].ToString();
                string positionRoleName = ((AliasedValue)act["role.name"]).Value.ToString();
                listPosition.Add(positionRoleId);
               // tracer.Trace("positionRoleId: " + positionRoleId.ToString());
            }

            var listreturn = listPosition.Except(list).ToList();
           // tracer.Trace("ListReturn Count: " + listreturn.Count().ToString());
            return listreturn;
        }
        private List<Guid> RetrievePositionTeam(Guid userGuid, Guid positionGuid, IOrganizationService service, ITracingService tracer)
        {
            List<Guid> list = new List<Guid>();
            List<Guid> listPosition = new List<Guid>();
            Guid userTeamID = Guid.Empty;
            Guid positionTeamId = Guid.Empty;

            string fetchXML1 = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false'  >
                            <entity name='systemuser' >
                            <attribute name='systemuserid' />
                            <attribute name='fullname' />
                            <attribute name='businessunitid' />
                            <filter>
                            <condition attribute='systemuserid' operator='eq' value= '" + userGuid + @"' />
                            </filter>
                            <link-entity name='teammembership' from='systemuserid' to='systemuserid' intersect='true' >
                            <link-entity name='team' from='teamid' to='teamid' alias='Team' >
                            <attribute name='name' />
                            <attribute name='teamid' />
                            <attribute name='businessunitid' />
                            </link-entity>
                            </link-entity>
                            </entity>
                        </fetch>";
            var usersTeamColl = service.RetrieveMultiple(new FetchExpression(fetchXML1));
            foreach (Entity actteam in usersTeamColl.Entities)
            {
                userTeamID = (Guid)(((AliasedValue)actteam["Team.teamid"]).Value);
                string teamName = ((AliasedValue)actteam["Team.name"]).Value.ToString();
                list.Add(userTeamID);

            }

            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                          <entity name='position' >
                            <attribute name='rbs_businessunitid' />
                            <attribute name='name' />
                            <attribute name='positionid' />
                            <filter>
                              <condition attribute='positionid' operator='eq' value= '" + positionGuid + @"' />
                            </filter>
                            <link-entity name='rbs_positionteam' from='rbs_positionid' to='positionid' >
                              <link-entity name='team' from='teamid' to='rbs_teamid' alias='team'>
                                <attribute name='name' />
                                <attribute name='teamid' />
                              </link-entity>
                            </link-entity>
                          </entity>
                        </fetch>";
            var usersPositionTeamColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
            //tracer.Trace("This is remove");
            foreach (Entity act in usersPositionTeamColl.Entities)
            {
                positionTeamId = (Guid)(((AliasedValue)act["team.teamid"]).Value);
                // Prole.positionRoleName = act["name"].ToString();
                string positionTeamName = ((AliasedValue)act["team.name"]).Value.ToString();
                listPosition.Add(positionTeamId);

            }

            var listreturn = listPosition.Except(list).ToList();
            return listreturn;

        }

        private void AssignOPSecurityRoleToUser(Guid userGuid, IOrganizationService service, IWorkflowContext context, ITracingService tracer)
        {
            var usersOtherPositionColl = RetrieveOtherpositionGuid(userGuid, service, tracer);
            foreach (Entity actOP in usersOtherPositionColl.Entities)
            {
                Guid userBUID = ((EntityReference)(actOP.Attributes["businessunitid"])).Id;
                Guid userpostionID = (Guid)(((AliasedValue)actOP["userposition.rbs_userpositionid"]).Value);
                string opName = ((EntityReference)((AliasedValue)actOP.Attributes["userposition.rbs_positionid"]).Value).Name;
                Guid opGUID = ((EntityReference)((AliasedValue)actOP.Attributes["userposition.rbs_positionid"]).Value).Id;
                Guid opBUID = ((EntityReference)((AliasedValue)actOP.Attributes["position.rbs_businessunitid"]).Value).Id;
                EntityReferenceCollection rolesCollection = null;
                // tracer.Trace(userBUID.ToString() + "OPBUID-" + opBUID.ToString());

                if (context.PrimaryEntityName == "systemuser" && userBUID == opBUID)
                {
                    rolesCollection = new EntityReferenceCollection();

                    var listreturn = RetrievePositionSR(userGuid, opGUID, service, tracer);
                    foreach (var q in listreturn)
                    {
                        Guid positionRole = q;

                        rolesCollection.Add(new EntityReference("role", positionRole));
                    }

                    if(rolesCollection.Count > 0)
                        service.Associate("systemuser", userGuid, new Relationship("systemuserroles_association"), rolesCollection);
                }

                else if (context.PrimaryEntityName == "rbs_userposition" && context.MessageName != "Delete" && userBUID == opBUID)
                {
                    rolesCollection = new EntityReferenceCollection();

                    var listreturn = RetrievePositionSR(userGuid, opGUID, service, tracer);
                    foreach (var q in listreturn)
                    {
                        Guid positionRole = q;

                        rolesCollection.Add(new EntityReference("role", positionRole));
                    }

                    if (rolesCollection.Count > 0)
                        service.Associate("systemuser", userGuid, new Relationship("systemuserroles_association"), rolesCollection);
                }
                else if (context.PrimaryEntityName == "rbs_userposition" && context.MessageName == "Delete" && context.PrimaryEntityId != userpostionID && userBUID == opBUID)
                {
                    rolesCollection = new EntityReferenceCollection();

                    var listreturn = RetrievePositionSR(userGuid, opGUID, service, tracer);
                    foreach (var q in listreturn)
                    {
                        Guid positionRole = q;

                        rolesCollection.Add(new EntityReference("role", positionRole));                        
                    }

                    if (rolesCollection.Count > 0)
                        service.Associate("systemuser", userGuid, new Relationship("systemuserroles_association"), rolesCollection);
                }

            }
        }

        private void AssignOPTeamToUser(Guid userGuid, IOrganizationService service, IWorkflowContext context, ITracingService tracer)
        {
            var usersOtherPositionColl = RetrieveOtherpositionGuid(userGuid, service, tracer);
            foreach (Entity actOP in usersOtherPositionColl.Entities)
            {
                Guid userpostionID = (Guid)(((AliasedValue)actOP["userposition.rbs_userpositionid"]).Value);
                string opName = ((EntityReference)((AliasedValue)actOP.Attributes["userposition.rbs_positionid"]).Value).Name;
                Guid opGUID = ((EntityReference)((AliasedValue)actOP.Attributes["userposition.rbs_positionid"]).Value).Id;
                if (context.PrimaryEntityName == "systemuser")
                {
                    var listreturn = RetrievePositionTeam(userGuid, opGUID, service, tracer);
                    foreach (var q in listreturn)
                    {
                        Guid positionTeamID = q;
                        service.Associate("systemuser", userGuid, new Relationship("teammembership_association"), new EntityReferenceCollection() { new EntityReference("team", positionTeamID) });
                    }
                }
                else if (context.PrimaryEntityName == "rbs_userposition" && context.MessageName != "Delete")
                {
                    var listreturn = RetrievePositionTeam(userGuid, opGUID, service, tracer);
                    foreach (var q in listreturn)
                    {
                        Guid positionTeamID = q;
                        service.Associate("systemuser", userGuid, new Relationship("teammembership_association"), new EntityReferenceCollection() { new EntityReference("team", positionTeamID) });
                    }

                }
                else if (context.PrimaryEntityName == "rbs_userposition" && context.MessageName == "Delete" && context.PrimaryEntityId != userpostionID)
                {
                    var listreturn = RetrievePositionTeam(userGuid, opGUID, service, tracer);
                    foreach (var q in listreturn)
                    {
                        Guid positionTeamID = q;
                        service.Associate("systemuser", userGuid, new Relationship("teammembership_association"), new EntityReferenceCollection() { new EntityReference("team", positionTeamID) });
                    }

                }
            }

        }


        private EntityCollection RetrieveOtherpositionGuid(Guid userGuid, IOrganizationService service, ITracingService tracer)
        {
            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                              <entity name='systemuser' >
                              <attribute name='businessunitid' />
                                <attribute name='systemuserid' />
                                <attribute name='fullname' />
                                <link-entity name='rbs_userposition' from='rbs_userid' to='systemuserid'  alias='userposition' >                               
                                  <attribute name='rbs_positionid' />
                                  <attribute name='rbs_userpositionid' />
                                  <attribute name='rbs_userid' />
                                  <filter>
                                    <condition attribute='rbs_userid' operator='eq' value= '" + userGuid + @"' />
                                  </filter>
                                <link-entity name='position' from='positionid' to='rbs_positionid' alias='position' >
                                 <attribute name='rbs_businessunitid' />
                                 </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";
            var usersOtherPositionColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
            return usersOtherPositionColl;
        }


    }
}
