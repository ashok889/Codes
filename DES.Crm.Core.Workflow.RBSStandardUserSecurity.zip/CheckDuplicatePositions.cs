﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;

namespace Security
{
    public class CheckDuplicatePositions : CodeActivity
    {
        #region Properties

        [Input("User")]
        [ReferenceTarget("systemuser")]
        [RequiredArgument]
        public InArgument<EntityReference> UserId { get; set; }
        

        [Output("IsDuplicate")]
        [DefaultAttribute("false")]
        public OutArgument<bool> IsDuplicate { get; set; }

        #endregion
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracer = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
           Guid positionGuid = Guid.Empty;
            try
            {

                Guid userGuid = UserId.Get<EntityReference>(executionContext).Id;

              

                if (userGuid != null)
                {
                   
                    if (context.InputParameters.Contains("Target") && context.MessageName == "Update" && context.InputParameters["Target"] is Entity)
                    {
                    
                        Entity ent = (Entity)context.InputParameters["Target"];
                        if(ent.LogicalName == "systemuser")
                        {
                            EntityReference positionGuidInContext = ent.GetAttributeValue<EntityReference>("positionid");
                            if (positionGuidInContext != null)
                            {  
                                bool duplicate = IsPositionDuplicate(userGuid, positionGuidInContext.Id, tracer, service, context);
                               // tracer.Trace("Position is duplicate? systemuser-update" + IsDuplicate);
                                IsDuplicate.Set(executionContext,duplicate);
                            }
                        }
                        if (ent.LogicalName == "rbs_userposition")
                        {
                            EntityReference positionGuidInContext = ent.GetAttributeValue<EntityReference>("rbs_positionid");
                            if (positionGuidInContext != null)
                            {
                                bool duplicate = IsPositionDuplicate(userGuid, positionGuidInContext.Id, tracer, service, context);
                                //tracer.Trace("Position is duplicate? user-position update" + duplicate);
                                IsDuplicate.Set(executionContext, duplicate);

                            }
                        }

                    }
                    if (context.InputParameters.Contains("Target") && context.MessageName == "Create" && context.InputParameters["Target"] is Entity)
                    {
                        Entity ent = (Entity)context.InputParameters["Target"];
                        if (ent.LogicalName == "rbs_userposition")
                        {
                            EntityReference positionGuidInContext = ent.GetAttributeValue<EntityReference>("rbs_positionid");
                            if(positionGuidInContext!=null)
                            {
                                //tracer.Trace("in Create , Guid of position is " + positionGuidInContext.Id);
                                bool duplicate = IsPositionDuplicate(userGuid, positionGuidInContext.Id, tracer, service, context);
                                //tracer.Trace("Position is duplicate? user-position create " + IsDuplicate);
                                IsDuplicate.Set(executionContext,duplicate );
                              
                            }
                        }
                    }

                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //Handle the exceptions
                throw new InvalidPluginExecutionException(e.Message);

            }

        }
        private bool IsPositionDuplicate(Guid userGuid, Guid positionGuid, ITracingService trace, IOrganizationService service,IWorkflowContext executionContext)
        {

            try
            {
                List<Guid> allPositionList = new List<Guid>();
                var otherPositionList = RetrieveOtherpositionGuid(userGuid, service, trace);
                var mainPosition = MainPositionGuid(userGuid, service, trace);

                foreach (Entity actOP in otherPositionList.Entities)
                {
                    allPositionList.Add(((EntityReference)((AliasedValue)actOP.Attributes["userposition.rbs_positionid"]).Value).Id);
                    
                }
                foreach (Entity act in mainPosition.Entities)
                {
                    if (act.Attributes.Contains("positionid"))
                    {
                        allPositionList.Add(((EntityReference)(act.Attributes["positionid"])).Id);
                     
                    }
                }

                if (CountOccurenceOfValue(allPositionList, positionGuid) > 0 && executionContext.MessageName == "Update")
                {
                   // trace.Trace("Position is Duplicate.");
                    return true;
                  
                }


                else if (CountOccurenceOfValue(allPositionList, positionGuid) > 1 && executionContext.MessageName == "Create")
                {
                   // trace.Trace("Position is Duplicate.");
                    return true;
                    
                }

                else
                {
                   // trace.Trace("Unknown Message");
                    return false;
                }
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                //trace.Trace("Exception Details" +e.StackTrace);
                throw new InvalidPluginExecutionException(e.Message);

            }

        }
        static int CountOccurenceOfValue(List<Guid> allPositionList, Guid positionGuid)
        {
            return ((from temp in allPositionList where temp.Equals(positionGuid) select temp).Count());
        }
        private EntityCollection RetrieveOtherpositionGuid(Guid userGuid, IOrganizationService service, ITracingService trace)
        {
            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                              <entity name='systemuser' >
                              <attribute name='businessunitid' />
                                <attribute name='systemuserid' />
                                <attribute name='fullname' />
                                <link-entity name='rbs_userposition' from='rbs_userid' to='systemuserid'  alias='userposition' >                               
                                  <attribute name='rbs_positionid' />
                                  <attribute name='rbs_userpositionid' />
                                  <attribute name='rbs_userid' />
                                  <filter>
                                    <condition attribute='rbs_userid' operator='eq' value= '" + userGuid + @"' />
                                  </filter>
                                <link-entity name='position' from='positionid' to='rbs_positionid' alias='position' >
                                 <attribute name='rbs_businessunitid' />
                                 </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";
            var usersOtherPositionColl = service.RetrieveMultiple(new FetchExpression(fetchXML));
            trace.Trace("other position Count is  "+usersOtherPositionColl.Entities.Count);
            return usersOtherPositionColl;
        }
        private EntityCollection MainPositionGuid(Guid userGuid, IOrganizationService service, ITracingService trace)
        {

            string fetchXML = @"<fetch version='1.0' output-format='xml - platform' mapping='logical' distinct='false' >
                                    <entity name='systemuser'>
                                    <attribute name='positionid'/>
                                      <filter type='and'>
                                          <condition attribute='systemuserid' value='" + userGuid + @"'  operator='eq'/>
                                           <condition operator='not-null' attribute='positionid'/>
                                       </filter>
                                     </entity> 
                                    </fetch>";
            var mainPosition = service.RetrieveMultiple(new FetchExpression(fetchXML));
            trace.Trace("Main position Count is  " + mainPosition.Entities.Count);
            return mainPosition;

        }
    }
}
