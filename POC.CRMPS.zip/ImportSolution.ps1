﻿#Define Parameters
param(
[string]$CrmUnmanagedSolutionPath,
[string]$CrmSolutionFileName,
[string]$TargetOrganisation,
[string]$UserName,
[string]$UserSecret,
[string]$CRMPSDLLPath,
[string]$Region = ''
)

trap
{
    write-output $_
    exit 1
}

Add-PSSnapin Microsoft.Xrm.Tooling.Connector

Write-Host "CrmSolutionPath:" $CrmUnmanagedSolutionPath 

Write-Host "CrmSolutionFileName:" $CrmSolutionFileName

Write-Host "TargetOrganisation:" $TargetOrganisation

Write-Host "UserName:" $UserName

 

#Script Location
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
Write-Host "Script Path: $scriptPath"

Import-Module $CRMPSDLLPath

$SecurePassword = $UserSecret | ConvertTo-SecureString -AsPlainText -Force

Write-Host "Importing Solution..."
if ($Region.Length > 0) 
{
    Import-Solution -UserName $UserName -Password $SecurePassword -OrgName $TargetOrganisation -SolutionName $CrmSolutionFileName -InputDir $CrmUnmanagedSolutionPath -Region $Region
}
else
{
    Import-Solution -UserName $UserName -Password $SecurePassword -OrgName $TargetOrganisation -SolutionName $CrmSolutionFileName -InputDir $CrmUnmanagedSolutionPath
}
Write-Host "Import Done."
