﻿#Define Parameters
param(
[string]$TargetOrganisation,
[string]$UserName,
[string]$UserSecret,
[string]$CRMPSDLLPath,
[string]$Region = ''
)

trap
{
    write-output $_
    exit 1
}

Add-PSSnapin Microsoft.Xrm.Tooling.Connector

Write-Host "TargetOrganisation:" $TargetOrganisation

Write-Host "UserName:" $UserName

 

#Script Location
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
Write-Host "Script Path: $scriptPath"

Import-Module $CRMPSDLLPath

$SecurePassword = $UserSecret | ConvertTo-SecureString -AsPlainText -Force


Write-Host "Publishing Customisations..."
if ($Region.Length > 0) 
{
    Publish-Solution -UserName $UserName -Password $SecurePassword -OrgName $TargetOrganisation -Region $Region
}
else
{
    Publish-Solution -UserName $UserName -Password $SecurePassword -OrgName $TargetOrganisation
}
Write-Host "Publish Done."