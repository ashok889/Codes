﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management.Automation;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Xrm.Sdk.WebServiceClient;
using System.IO;
using System.Security;
using System.Net;

namespace CRMPS
{
    [Cmdlet(VerbsData.Publish, "Solution")]
    public class PublishCustomisations : Cmdlet
    {
        protected override void ProcessRecord()
        {
            if (Password.Length == 0)
            {
                throw new Exception("No Password supplied");
            }
            if (UserName.Length == 0)
            {
                throw new Exception("No UserName supplied");
            }
            if (OrgName.Length == 0)
            {
                throw new Exception("No OrgName specified");
            }
            PublishCrmCustomisations();
        }

        private void PublishCrmCustomisations()
        {
            try
            {
                WebRequest.DefaultWebProxy = WebRequest.GetSystemWebProxy();
                WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;

                using (var crmSvc = new CrmServiceClient(crmUserId: UserName,
                crmPassword: Password, crmRegion: Region,
                    orgName: OrgName, isOffice365: true))
                {
                    var publishRequest = new PublishAllXmlRequest();

                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                    var endpoint = crmSvc.OrganizationServiceProxy.ServiceConfiguration.CurrentServiceEndpoint;
                    endpoint.Binding.SendTimeout = new TimeSpan(0, 50, 0);
                    endpoint.Binding.ReceiveTimeout = new TimeSpan(0, 50, 0);
                    crmSvc.OrganizationServiceProxy.ServiceConfiguration.CurrentServiceEndpoint = endpoint;

                    crmSvc.OrganizationServiceProxy.Timeout = new TimeSpan(0, 50, 0);

                    WriteObject($"Publishing org: {OrgName}");
                    var publishReponse = (PublishAllXmlResponse)crmSvc.Execute(publishRequest);
                }               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Parameter]
        public string UserName { get; set; }

        [Parameter]
        public SecureString Password { get; set; }

        [Parameter]
        public string OrgName { get; set; }

        [Parameter]
        public string Region { get; set; }

    }
}
