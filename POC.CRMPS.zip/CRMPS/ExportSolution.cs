﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management.Automation;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using System.IO;
using System.Security;
using System.Net;

namespace CRMPS
{
    [Cmdlet(VerbsData.Export, "Solution")]
    public class ExportSolution : Cmdlet
    {
        protected override void ProcessRecord()
        {
            ExportCRMSolution();
        }

        private void ExportCRMSolution()
        {
            try
            {
                WebRequest.DefaultWebProxy = WebRequest.GetSystemWebProxy();
                WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;

                using (var crmSvc = new CrmServiceClient(crmUserId: UserName, crmPassword: Password, crmRegion: Region,
                   orgName: OrgName, isOffice365: true))
                {

                    var exportSolutionRequest = new ExportSolutionRequest();
                    exportSolutionRequest.Managed = false;
                    exportSolutionRequest.SolutionName = SolutionName;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                    var endpoint = crmSvc.OrganizationServiceProxy.ServiceConfiguration.CurrentServiceEndpoint;
                    endpoint.Binding.SendTimeout = new TimeSpan(0, 20, 0);
                    endpoint.Binding.ReceiveTimeout = new TimeSpan(0, 20, 0);
                    crmSvc.OrganizationServiceProxy.ServiceConfiguration.CurrentServiceEndpoint = endpoint;

                    var exportSolutionResponse = (ExportSolutionResponse)crmSvc.Execute(exportSolutionRequest);

                    byte[] exportXml = exportSolutionResponse.ExportSolutionFile;
                    string filename = SolutionName + ".zip";
                    File.WriteAllBytes(OutputDir + filename, exportXml);

                    WriteObject(string.Format("Solution exported to {0}{1}.", OutputDir, filename));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Parameter]
        public string UserName { get; set; }

        [Parameter]
        public SecureString Password { get; set; }

        [Parameter]
        public string OrgName { get; set; }

        [Parameter]
        public string SolutionName { get; set; }

        [Parameter]
        public string OutputDir { get; set; }

        [Parameter]
        public string Region { get; set; }

    }
}
