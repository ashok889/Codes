﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management.Automation;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;
using System.IO;
using System.Security;
using System.Threading;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using System.ComponentModel;
using Microsoft.Xrm.Sdk;
using System.Net;

namespace CRMPS
{
    [Cmdlet(VerbsData.Import, "Solution")]
    public class ImportSolution : Cmdlet
    {
        protected override void ProcessRecord()
        {
            ImportCRMSolution();
        }

        private void ImportCRMSolution()
        {
            try
            {
                WebRequest.DefaultWebProxy = WebRequest.GetSystemWebProxy();
                WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;

                using (var crmSvc = new CrmServiceClient(crmUserId: UserName, crmPassword: Password, crmRegion: Region,
                    orgName: OrgName, isOffice365: true))
                {
                    Guid? asyncJobId = null;
                    string filename = SolutionName + ".zip";
                    var fileData = File.ReadAllBytes(InputDir + filename);
                    var importId = Guid.NewGuid();

                    Async = !string.IsNullOrEmpty(Async) ? Async : "True";

                    WriteObject($"Is Async: {Async}");

                    var importSolutionRequest = new ImportSolutionRequest
                    {
                        CustomizationFile = fileData,
                        ImportJobId = importId,
                        PublishWorkflows = true,
                        OverwriteUnmanagedCustomizations = true

                    };
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                    // increase timeouts
                    var endpoint = crmSvc.OrganizationServiceProxy.ServiceConfiguration.CurrentServiceEndpoint;
                    endpoint.Binding.SendTimeout = new TimeSpan(0, 50, 0);
                    endpoint.Binding.ReceiveTimeout = new TimeSpan(0, 50, 0);
                    crmSvc.OrganizationServiceProxy.ServiceConfiguration.CurrentServiceEndpoint = endpoint;

                    crmSvc.OrganizationServiceProxy.Timeout = new TimeSpan(0, 50, 0);

                    if (Async.ToUpper().Equals("TRUE"))
                    {
                        ExecuteAsyncRequest asyncRequest = new ExecuteAsyncRequest()
                        {
                            Request = importSolutionRequest
                        };

                        ExecuteAsyncResponse asyncResponse = (ExecuteAsyncResponse)crmSvc.Execute(asyncRequest);

                        asyncJobId = asyncResponse.AsyncJobId;

                        DateTime end = DateTime.Now.AddSeconds(600);
                        var done = false;
                        while (end >= DateTime.Now && done == false)
                        {
                            var asyncOperation = crmSvc.Retrieve("asyncoperation", asyncJobId.Value,
                                new ColumnSet("asyncoperationid", "statuscode", "message"));

                            switch (((OptionSetValue)asyncOperation["statuscode"]).Value)
                            {
                                //Succeeded
                                case 30:
                                    done = true;
                                    break;
                                // asyncJobId;
                                //Pausing //Canceling //Failed //Canceled
                                case 21:
                                case 22:
                                case 31:
                                case 32:
                                    throw new Exception($"Solution Import Failed: {  ((OptionSetValue)asyncOperation["statuscode"]).Value } { asyncOperation["message"].ToString() }");
                                default:
                                    break;
                            }
                        }
                    }
                    else
                    {
                        crmSvc.Execute(importSolutionRequest);
                    }
                   
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Parameter]
        public string UserName { get; set; }

        [Parameter]
        public SecureString Password { get; set; }

        [Parameter]
        public string OrgName { get; set; }

        [Parameter]
        public string SolutionName { get; set; }

        [Parameter]
        public string InputDir { get; set; }

        [Parameter]
        public string Async { get; set; }

        [Parameter]
        public string Region { get; set; }
    }
}
