﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DES.Crm.Core.EncryptDecrypt
{
    public partial class Encrypt : Form
    {
        public Encrypt()
        {
            InitializeComponent();
            rtb_EncryptedKey.Visible = false;
            lbl_encryptedKey.Visible = false;
            //EncryptDecrypt c = new EncryptDecrypt();
        }

        private void btn_Encrypt_Click(object sender, EventArgs e)
        {
            if (tb_Key.Text == "")
            {
                MessageBox.Show("Please enter a key to encrypt");
            }
            else
            {
                EncryptDecrypt c = new EncryptDecrypt();
                string encrypedKey = c.EncryptToString(tb_Key.Text.Trim());
                rtb_EncryptedKey.Visible = true;
                lbl_encryptedKey.Visible = true;
                rtb_EncryptedKey.Text = encrypedKey;
            }
        }

        private void rtb_EncryptedKey_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_encryptedKey_Click(object sender, EventArgs e)
        {

        }

        private void tb_Key_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_Key_Click(object sender, EventArgs e)
        {

        }
    }
}
