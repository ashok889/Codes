﻿namespace DES.Crm.Core.EncryptDecrypt
{
    partial class Encrypt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_encryptedKey = new System.Windows.Forms.Label();
            this.rtb_EncryptedKey = new System.Windows.Forms.RichTextBox();
            this.btn_Encrypt = new System.Windows.Forms.Button();
            this.tb_Key = new System.Windows.Forms.TextBox();
            this.lbl_Key = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_encryptedKey
            // 
            this.lbl_encryptedKey.AutoSize = true;
            this.lbl_encryptedKey.Location = new System.Drawing.Point(14, 147);
            this.lbl_encryptedKey.Name = "lbl_encryptedKey";
            this.lbl_encryptedKey.Size = new System.Drawing.Size(79, 13);
            this.lbl_encryptedKey.TabIndex = 9;
            this.lbl_encryptedKey.Text = "Encrypted Key:";
            this.lbl_encryptedKey.Click += new System.EventHandler(this.lbl_encryptedKey_Click);
            // 
            // rtb_EncryptedKey
            // 
            this.rtb_EncryptedKey.Location = new System.Drawing.Point(17, 163);
            this.rtb_EncryptedKey.Name = "rtb_EncryptedKey";
            this.rtb_EncryptedKey.Size = new System.Drawing.Size(718, 106);
            this.rtb_EncryptedKey.TabIndex = 8;
            this.rtb_EncryptedKey.Text = "";
            this.rtb_EncryptedKey.TextChanged += new System.EventHandler(this.rtb_EncryptedKey_TextChanged);
            // 
            // btn_Encrypt
            // 
            this.btn_Encrypt.Location = new System.Drawing.Point(17, 80);
            this.btn_Encrypt.Name = "btn_Encrypt";
            this.btn_Encrypt.Size = new System.Drawing.Size(190, 45);
            this.btn_Encrypt.TabIndex = 7;
            this.btn_Encrypt.Text = "Encrypt Key";
            this.btn_Encrypt.UseVisualStyleBackColor = true;
            this.btn_Encrypt.Click += new System.EventHandler(this.btn_Encrypt_Click);
            // 
            // tb_Key
            // 
            this.tb_Key.Location = new System.Drawing.Point(15, 45);
            this.tb_Key.Name = "tb_Key";
            this.tb_Key.Size = new System.Drawing.Size(718, 20);
            this.tb_Key.TabIndex = 6;
            this.tb_Key.TextChanged += new System.EventHandler(this.tb_Key_TextChanged);
            // 
            // lbl_Key
            // 
            this.lbl_Key.AutoSize = true;
            this.lbl_Key.Location = new System.Drawing.Point(12, 25);
            this.lbl_Key.Name = "lbl_Key";
            this.lbl_Key.Size = new System.Drawing.Size(109, 13);
            this.lbl_Key.TabIndex = 5;
            this.lbl_Key.Text = "Enter Integration Key:";
            this.lbl_Key.Click += new System.EventHandler(this.lbl_Key_Click);
            // 
            // Encrypt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 289);
            this.Controls.Add(this.lbl_encryptedKey);
            this.Controls.Add(this.rtb_EncryptedKey);
            this.Controls.Add(this.btn_Encrypt);
            this.Controls.Add(this.tb_Key);
            this.Controls.Add(this.lbl_Key);
            this.Name = "Encrypt";
            this.Text = "Encrypt Integration Key";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_encryptedKey;
        private System.Windows.Forms.RichTextBox rtb_EncryptedKey;
        private System.Windows.Forms.Button btn_Encrypt;
        private System.Windows.Forms.TextBox tb_Key;
        private System.Windows.Forms.Label lbl_Key;
    }
}